﻿/// <binding />
/*
This file in the main entry point for defining Gulp tasks and using Gulp plugins.
Click here to learn more. http://go.microsoft.com/fwlink/?LinkId=518007
*/
var ts = require('gulp-typescript');

var gulp = require('gulp'),
 rimraf = require('rimraf');
var del = require('del');

gulp.task('clean', function (cb) {
    return rimraf('./wwwroot/NodeLib/', cb)
});

gulp.task('copy:lib', function () {
    return gulp.src('node_modules/**/*')
        .pipe(gulp.dest('./wwwroot/NodeLib/'));
});

gulp.task('copy:systemjs', function () {
    return gulp.src(['Scripts/systemjs.config.js', 'Scripts/systemjs-angular-loader.js'])
        .pipe(gulp.dest('./wwwroot/'));
});
var tsProject = ts.createProject('Scripts/tsconfig.json', {
    typescript: require('typescript')
});
gulp.task('ts', function () {
    var tsResult = gulp.src("./Scripts/**/*.ts") // instead of gulp.src(...)
        .pipe(tsProject());

    return tsResult.js.pipe(gulp.dest('./wwwroot'));
});

gulp.task('watch', ['watch.ts', 'watch.html']);
gulp.task('watch.ts', ['ts'], function () {
    return gulp.watch('./Scripts/**/*.ts', ['ts']);
});

gulp.task('html', function () {
    gulp.src("Scripts/**/*.html")
        .pipe(gulp.dest("./wwwroot/"));
});

gulp.task('watch.html', ['html'], function () {
    gulp.watch("./Scripts/**/*.html", ["html"]);
});

gulp.task('default', ['watch']);

gulp.task('clean:aot', function () {
    return del([      
      // here we use a globbing pattern to match everything inside the `mobile` folder
      './aot',
      // we don't want to clean this file though so we negate the pattern
      'Scripts/app/**/*.js',
      'Scripts/app/**/*.js.map'
    ]);
});

gulp.task('aot', ['clean:aot']);
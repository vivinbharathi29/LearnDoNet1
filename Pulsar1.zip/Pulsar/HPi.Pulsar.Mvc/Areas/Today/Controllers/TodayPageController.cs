﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.Today.Contracts;
using HPi.Pulsar.Today.Contracts.Enumerators;
using HPi.Pulsar.UnitOfWork.Today.Contracts;
using HPi.Pulsar.UnitOfWork.Today.ViewModels;
using HPi.Pulsar.UnitOfWork.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace HPi.Pulsar.Mvc.Areas.Today.Controllers
{
    [Area("Today")]
    public class TodayPageController : BaseMvcController<ITodayPageUnitOfWork>
    {
        public TodayPageController(IApplicationServices applicationServices, ITodayPageUnitOfWork todaypageUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration)
            : base(applicationServices, todaypageUnitOfWork, configuration, currentProfile)
        {
            this.CurrentUserProfile = currentProfile;
        }

        #region Public Properties
        public ICurrentUserProfile CurrentUserProfile { get; }

        public int UserIdentity { get; set; }

        public string UserLoginName { get; set; }

        public string UserLoginDomain { get; set; }
        #endregion

        #region Constant
        private const string componentsAwaitingTestReviewStatus = "Test Review";

        private const string upcomingReleaseStatus = "Functional Test";

        private const string componentsAwaitingDeveloperReviewStatus = "Developer Review";

        private const int componentsAwaitingTestReviewManagerId = 0;

        private const string xUnitTesting = "XUnitTesting";

        private const string localTesting = "LocalTesting";
        #endregion

        #region SCM Feed Errors
        [ProducesResponseType(typeof(SCMFeedErrorViewModel[]), 200)]
        [ProducesResponseType(typeof(SCMFeedErrorViewModel[]), 400)]
        [Route("/today/TodayPage/GetScmFeedErrors")]
        public async Task<IActionResult> GetScmFeedErrors()
        {
            var scmFeedErrors = await this.UnitOfWork.GetSCMFeedErrorsAsync().ConfigureAwait(false);
            if (scmFeedErrors != null)
            {
                return this.Ok(scmFeedErrors);
            }
            return this.NotFound();
        }

        [ProducesResponseType(typeof(SCMFeedErrorViewModel[]), 200)]
        [ProducesResponseType(typeof(SCMFeedErrorViewModel[]), 400)]
        [Route("/today/TodayPage/GetXmlScmFeedErrors/{pbId}")]
        public async Task<IActionResult> GetSCMFeedErrors(int pbId)
        {
            string scmFeedErrors = await this.UnitOfWork.GetXMLSCMFeedErrorsAsync(pbId).ConfigureAwait(false);
            return this.Content(scmFeedErrors, "text/xml");
        }
        #endregion

        #region Missing System Board
        [ProducesResponseType(typeof(MissingSystemBoardIdViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingSystemBoardIdViewModel[]), 400)]
        [Route("/today/TodayPage/GetMissingSystemBoardIds")]
        public async Task<IActionResult> GetMissingSystemBoardIds()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2262;
            }
            else if (this.ApplicationMode == localTesting)
            {

                this.UserIdentity = 2262;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var missingSystemBoardIds = await this.UnitOfWork.GetMissingSystemBoardIdsAsync(this.UserIdentity).ConfigureAwait(false);
            if (missingSystemBoardIds != null)
            {
                return this.Ok(missingSystemBoardIds);
            }
            return this.NotFound();
        }
        #endregion

        #region Page Index
        [ProducesResponseType(typeof(TodayPageViewModel[]), 200)]
        [ProducesResponseType(typeof(TodayPageViewModel[]), 404)]
        public async Task<IActionResult> Index(int currentUserDivision, int currentUserPartner, int currentUserPartnerType)
        {
            var indexTodayPage = await this.UnitOfWork.IndexAsync(CurrentUserProfile.UserId, currentUserDivision, currentUserPartner, currentUserPartnerType).ConfigureAwait(false);
            if (indexTodayPage != null)
            {
                return this.Ok(indexTodayPage);
            }
            return this.NotFound();
        }
        #endregion

        #region PastDueScheduleItem
        [ProducesResponseType(typeof(PastDueScheduleItemViewModel[]), 200)]
        [ProducesResponseType(typeof(PastDueScheduleItemViewModel[]), 404)]
        public async Task<IActionResult> GetPastDueScheduleItems()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3206;
            }
            else if (this.ApplicationMode == localTesting)
            {

                this.UserIdentity = 3206;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var pastDueScheduleItems = await this.UnitOfWork.GetPastDueScheduleItemsAsync(this.UserIdentity).ConfigureAwait(false);
            if (pastDueScheduleItems != null)
            {
                return this.Ok(pastDueScheduleItems);
            }

            return this.NotFound();
        }
        #endregion

        #region SMRAlerts
        [HttpPost]
        [ProducesResponseType(typeof(SMRWaitingOnDeveloperViewModel[]), 200)]
        [ProducesResponseType(typeof(SMRWaitingOnDeveloperViewModel[]), 404)]
        [Route("/today/TodayPage/GetSmrAlertsNotStarted")]
        public async Task<IActionResult> GetSmrAlertsNotStarted([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 1382;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 1382;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var smrAlertsNotStarted = await this.UnitOfWork.GetSMRAlertsNotStartedAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (smrAlertsNotStarted != null)
            {
                return this.Ok(smrAlertsNotStarted);
            }

            return this.NotFound();
        }
        #endregion

        #region SMRNewRequests
        [HttpPost]
        [ProducesResponseType(typeof(NewSMRRequestViewModel[]), 200)]
        [ProducesResponseType(typeof(NewSMRRequestViewModel[]), 404)]
        [Route("/today/TodayPage/GetNewSmrRequests")]
        public async Task<IActionResult> GetNewSmrRequests([FromBody] PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3206;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3206;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var domain = CurrentUserProfile.LoginDomain == "asiapacific" ? "2" : "1";
            var newSmrRequests = await this.UnitOfWork.GetNewSMRRequestsAsync(this.UserIdentity, domain, pagination).ConfigureAwait(false);
            if (newSmrRequests != null)
            {
                return this.Ok(newSmrRequests);
            }

            return this.NotFound();
        }
        #endregion

        #region Items Awaiting Approval
        [HttpPost]
        [ProducesResponseType(typeof(ItemsAwaitingMyApprovalViewModel[]), 200)]
        [ProducesResponseType(typeof(ItemsAwaitingMyApprovalViewModel[]), 404)]
        [Route("/today/TodayPage/GetItemsAwaitingMyApproval")]
        public async Task<IActionResult> GetItemsAwaitingMyApproval([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var itemsAwaitingMyApproval = await this.UnitOfWork.GetItemsAwaitingMyApprovalAsync(this.UserIdentity, this.CurrentUserProfile.UserName, pagination).ConfigureAwait(false);
            if (itemsAwaitingMyApproval != null)
            {
                return this.Ok(itemsAwaitingMyApproval);
            }

            return this.NotFound();
        }
        #endregion

        #region AllOpenItemsIOwn
        [HttpPost]
        [ProducesResponseType(typeof(AllOpenItemsIOwnViewModel[]), 200)]
        [ProducesResponseType(typeof(AllOpenItemsIOwnViewModel[]), 404)]
        [Route("/today/TodayPage/GetAllOpenItemsIOwn")]
        public async Task<IActionResult> GetAllOpenItemsIOwn([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 949;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 949;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var allOpenItemsIOwn = await this.UnitOfWork.GetAllOpenItemsIOwnAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (allOpenItemsIOwn != null)
            {
                return this.Ok(allOpenItemsIOwn);
            }

            return this.NotFound();
        }
        #endregion

        #region Sub Section Row Count
        [ProducesResponseType(typeof(TodayPageSubsectionRowCountModel), 200)]
        [ProducesResponseType(typeof(TodayPageSubsectionRowCountModel), 404)]
        [Route("/today/TodayPage/GetSubsectionsRowCount")]
        public async Task<IActionResult> GetSubsectionsRowCount(TodayPageSubsectionEnum todayPageSubsection)
        {
            string productsInFavourites = CurrentUserProfile.Favourites;
            string productIds = productsInFavourites.Replace("P", "").Replace(",", "_");
            TodayPageSubsectionRowCountModel todayPageSubsectionsRowCount = await this.UnitOfWork.GetSubsectionsRowCountAsync(todayPageSubsection, CurrentUserProfile.UserId, CurrentUserProfile.ImpersonateId, productIds, CurrentUserProfile.LoginAuthName, CurrentUserProfile.LoginDomain, CurrentUserProfile.PMImpersonate.Value, this.GetCmPcPhWebMktImpersonateID(), CurrentUserProfile.SepmCount, CurrentUserProfile.PreInstall, CurrentUserProfile.WorkGroupId, CurrentUserProfile.ServiceCommodityManager, CurrentUserProfile.ProcurementEngineer).ConfigureAwait(false);
            if (todayPageSubsectionsRowCount != null)
            {
                return this.Ok(todayPageSubsectionsRowCount);
            }

            return this.NotFound();
        }
        #endregion

        #region RowCountForTabSubsections
        [HttpGet]
        [ProducesResponseType(typeof(TodayPageSubsectionRowCountModel), 200)]
        [ProducesResponseType(typeof(TodayPageSubsectionRowCountModel), 404)]
        [Route("/today/TodayPage/GetSubsectionsTabCount/{tabIndex}")]
        public async Task<IActionResult> GetSubsectionsTabCount(int tabIndex)
        {
            UserPrivilegeModel userPrivilege = new UserPrivilegeModel();
            string productsInFavourites = CurrentUserProfile.Favourites;
            userPrivilege.UserId = CurrentUserProfile.ImpersonateId.Value != 0 ? CurrentUserProfile.ImpersonateId.Value : CurrentUserProfile.UserId;
            userPrivilege.CurrentUserId = CurrentUserProfile.OriginalUserId;
            //userPrivilege.CurrentUserId = CurrentUserProfile.UserId;
            userPrivilege.Email = CurrentUserProfile.Email;
            userPrivilege.UserName = CurrentUserProfile.LoginAuthName;
            userPrivilege.DomainName = CurrentUserProfile.LoginDomain;
            userPrivilege.PMImpersonateId = (int)CurrentUserProfile.PMImpersonate;
            userPrivilege.ImpersonateId = (int)CurrentUserProfile.ImpersonateId;
            userPrivilege.CMPcPhWebMktImpersonateId = this.GetCmPcPhWebMktImpersonateID();
            userPrivilege.ProductIdList = productsInFavourites.Replace("P", "").Replace(",", "_");
            userPrivilege.StartDate = DateTime.Now.AddDays(-7);
            userPrivilege.TabIndex = tabIndex;
            TodayPageSubsectionRowCountModel todayPageSubsectionsRowCount = await this.UnitOfWork.GetRowCountOfTabSubsectionsAsync(userPrivilege).ConfigureAwait(false);
            if (todayPageSubsectionsRowCount != null)
            {
                return this.Ok(todayPageSubsectionsRowCount);
            }

            return this.NotFound();
        }
        #endregion

        #region TodayPageSectionAndSubsection
        [HttpGet]
        [ProducesResponseType(typeof(TodayPageSubsectionViewModel), 200)]
        [ProducesResponseType(typeof(TodayPageSubsectionViewModel), 404)]
        [Route("/today/TodayPage/GetTodayPageSubsections")]
        public async Task<IActionResult> GetTodayPageSubsections()
        {
            UserPrivilegeModel userPrivilege = new UserPrivilegeModel();
            userPrivilege.UserId = CurrentUserProfile.ImpersonateId.Value != 0 ? CurrentUserProfile.ImpersonateId.Value : CurrentUserProfile.UserId;
            userPrivilege.CurrentUserId = CurrentUserProfile.OriginalUserId;
            //userPrivilege.CurrentUserId = CurrentUserProfile.UserId;
            userPrivilege.PMImpersonateId = (int)CurrentUserProfile.PMImpersonate;
            userPrivilege.ImpersonateId = (int)CurrentUserProfile.ImpersonateId;
            userPrivilege.CMPcPhWebMktImpersonateId = this.GetCmPcPhWebMktImpersonateID();
            var todayPageSectionsAndSubsections = await this.UnitOfWork.GetTodayPageSubsectionsAsync(userPrivilege).ConfigureAwait(false);
            if (todayPageSectionsAndSubsections != null)
            {
                return this.Ok(todayPageSectionsAndSubsections);
            }

            return this.NotFound();
        }
        #endregion

        #region ChangeRequestClosedInLast7Days
        [HttpPost]
        [ProducesResponseType(typeof(CRClosedInLastSevenDaysViewModel[]), 200)]
        [ProducesResponseType(typeof(CRClosedInLastSevenDaysViewModel[]), 404)]
        [Route("/today/TodayPage/GetCRClosedInLastSevenDays")]
        public async Task<IActionResult> GetCRClosedInLastSevenDays([FromBody]PaginationModel pagination)
        {
            string productIds = string.Empty;
            string productsInFavourites = CurrentUserProfile.Favourites;
            if (!string.IsNullOrEmpty(productsInFavourites))
            {
                var productFavourites = productsInFavourites.Split(',').Select(x => x).Where(y => y.StartsWith("P")).ToArray().Aggregate((index, value) => index + "," + value);
                productIds = productFavourites.Replace("P", "").Replace(",", "_");
            }
            var issuesClosedInLastSevenDays = await this.UnitOfWork.GetCRClosedInLastSevenDaysAsync(productIds, pagination).ConfigureAwait(false);
            if (issuesClosedInLastSevenDays != null)
            {
                return this.Ok(issuesClosedInLastSevenDays);
            }

            return this.NotFound();
        }

        [ProducesResponseType(typeof(CRClosedInLastSevenDaysViewModel[]), 200)]
        [ProducesResponseType(typeof(CRClosedInLastSevenDaysViewModel[]), 404)]
        [Route("/today/TodayPage/GetCRClosedInLastSevenDaysExportToExcel")]
        public async Task<FileStreamResult> GetCRClosedInLastSevenDaysExportToExcel()
        {
            string fileName = string.Empty;
            string contentType = string.Empty;
            var stream = new MemoryStream();
            using (ExcelPackage package = new ExcelPackage())
            {
                PaginationModel pagination = new PaginationModel();
                pagination.Filters = new FilterModel[0];
                pagination.PageNo = 1;
                pagination.PageSize = 10000;
                string productIds = string.Empty;
                string productsInFavourites = CurrentUserProfile.Favourites;
                if (!string.IsNullOrEmpty(productsInFavourites))
                {
                    productIds = productsInFavourites.Replace("P", "").Replace(",", "_");
                }
                var issuesClosedInLastSevenDays = await this.UnitOfWork.GetCRClosedInLastSevenDaysAsync(productIds, pagination).ConfigureAwait(false);
                if (issuesClosedInLastSevenDays != null)
                {

                    ExcelWorksheet rptProductLocalization = package.Workbook.Worksheets.Add("CR Closed");
                    System.Drawing.Color headerColor = System.Drawing.ColorTranslator.FromHtml("#DCDCDC");
                    rptProductLocalization.Cells[1, 1].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 1].Value = "ID";
                    rptProductLocalization.Cells[1, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 1].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 1].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(1).Width = 10;

                    rptProductLocalization.Cells[1, 2].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 2].Value = "Product";
                    rptProductLocalization.Cells[1, 2].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 2].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(2).Width = 15;

                    rptProductLocalization.Cells[1, 3].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 3].Value = "Status";
                    rptProductLocalization.Cells[1, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 3].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 3].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(3).Width = 15;

                    rptProductLocalization.Cells[1, 4].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 4].Value = "Closed";
                    rptProductLocalization.Cells[1, 4].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 4].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 4].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(4).Width = 15;

                    rptProductLocalization.Cells[1, 5].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 5].Value = "Owner";
                    rptProductLocalization.Cells[1, 5].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 5].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 5].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(5).Width = 20;

                    rptProductLocalization.Cells[1, 6].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 6].Value = "Submitter";
                    rptProductLocalization.Cells[1, 6].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 6].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 6].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 6].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 6].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 6].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(6).Width = 20;

                    rptProductLocalization.Cells[1, 7].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 7].Value = "Summary";
                    rptProductLocalization.Cells[1, 7].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 7].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 7].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 7].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 7].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 7].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(7).Width = 80;

                    int rowNumber = 2;

                    List<string> regions = new List<string>();

                    for (int dataIndex = 0; dataIndex < issuesClosedInLastSevenDays.Length; dataIndex++)
                    {
                        rptProductLocalization.Cells[rowNumber, 1].Value = issuesClosedInLastSevenDays[dataIndex].Id;
                        rptProductLocalization.Cells[rowNumber, 2].Value = issuesClosedInLastSevenDays[dataIndex].DotsName;
                        rptProductLocalization.Cells[rowNumber, 3].Value = issuesClosedInLastSevenDays[dataIndex].Status;
                        rptProductLocalization.Cells[rowNumber, 4].Value = issuesClosedInLastSevenDays[dataIndex].Closed;
                        rptProductLocalization.Cells[rowNumber, 5].Value = issuesClosedInLastSevenDays[dataIndex].Owner;
                        rptProductLocalization.Cells[rowNumber, 6].Value = issuesClosedInLastSevenDays[dataIndex].Submitter;
                        rptProductLocalization.Cells[rowNumber, 7].Value = issuesClosedInLastSevenDays[dataIndex].Summary;
                        rowNumber = rowNumber + 1;
                    }
                }
                package.SaveAs(stream);
                fileName = "CR Closed.xlsx";
                contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                stream.Position = 0;
            }
            return File(stream, contentType, fileName);
        }
        #endregion

        #region DeveloperRequestsRemovalFromProduct
        [HttpPost]
        [ProducesResponseType(typeof(DeveloperRequestRemovalFromProductViewModel[]), 200)]
        [ProducesResponseType(typeof(DeveloperRequestRemovalFromProductViewModel[]), 404)]
        [Route("/today/TodayPage/GetDeveloperRequestsRemovalFromProduct")]
        public async Task<IActionResult> GetDeveloperRequestsRemovalFromProduct([FromBody] PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 7274;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 7274;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var developerRequestsRemovalFromProduct = await this.UnitOfWork.GetDeveloperRequestsRemovalFromProductAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (developerRequestsRemovalFromProduct != null)
            {
                return this.Ok(developerRequestsRemovalFromProduct);
            }

            return this.NotFound();
        }
        #endregion

        #region GetOpenSupportTicketsISubmitted
        [ProducesResponseType(typeof(OpenSupportTicketsISubmittedViewModel[]), 200)]
        [ProducesResponseType(typeof(OpenSupportTicketsISubmittedViewModel[]), 404)]
        [Route("/today/TodayPage/GetOpenSupportTicketsISubmitted")]
        public async Task<IActionResult> GetOpenSupportTicketsISubmitted()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var openSupportTicketsISubmitted = await this.UnitOfWork.GetOpenSupportTicketsISubmittedAsync(this.UserIdentity).ConfigureAwait(false);
            if (openSupportTicketsISubmitted != null)
            {
                return this.Ok(openSupportTicketsISubmitted);
            }

            return this.NotFound();
        }
        #endregion

        #region MyOpenTickets
        [HttpPost]
        [ProducesResponseType(typeof(MyOpenTicketsViewModel[]), 200)]
        [ProducesResponseType(typeof(MyOpenTicketsViewModel[]), 404)]
        [Route("/today/TodayPage/GetMyOpenTickets")]
        public async Task<IActionResult> GetMyOpenTickets([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID(); // 2245
            }
            var myOpenTickets = await this.UnitOfWork.GetMyOpenTicketsAsync(this.UserIdentity, this.CurrentUserProfile.UserName, pagination).ConfigureAwait(false);
            if (myOpenTickets != null)
            {
                return this.Ok(myOpenTickets);
            }

            return this.NotFound();
        }
        #endregion

        #region InactiveComponentsStillTargeted
        [ProducesResponseType(typeof(InactiveComponentsStillTargetedViewModel[]), 200)]
        [ProducesResponseType(typeof(InactiveComponentsStillTargetedViewModel[]), 400)]
        [Route("/today/TodayPage/GetInactiveComponentsStillTargeted")]
        public async Task<IActionResult> GetInactiveComponentsStillTargeted()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2116;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2116;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var inactiveComponentsStillTargeted = await this.UnitOfWork.GetInactiveComponentsStillTargetedAsync(2, this.UserIdentity).ConfigureAwait(false);
            if (inactiveComponentsStillTargeted != null)
            {
                return this.Ok(inactiveComponentsStillTargeted);
            }

            return this.NotFound();
        }
        #endregion

        #region DCRWorkflowMilestones
        [ProducesResponseType(typeof(DCRWorkflowDefinitionsViewModel[]), 200)]
        [ProducesResponseType(typeof(DCRWorkflowDefinitionsViewModel[]), 404)]
        [Route("/today/TodayPage/GetDcrWorkflowDefinitions")]
        public async Task<IActionResult> GetDcrWorkflowDefinitions()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 12785;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 12785;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var dcrWorkflowDefinitions = await this.UnitOfWork.GetDCRWorkflowDefinitionsAsync((int)this.UserIdentity).ConfigureAwait(false);
            if (dcrWorkflowDefinitions != null)
            {
                return this.Ok(dcrWorkflowDefinitions);
            }

            return this.NotFound();
        }
        #endregion

        #region Missing AV MarketingData
        [HttpPost]
        [ProducesResponseType(typeof(MissingAVMarketingDataViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingAVMarketingDataViewModel[]), 404)]
        [Route("/today/TodayPage/GetMissingAVMarketingData")]
        public async Task<IActionResult> GetMissingAVMarketingData([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2639;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2639;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var missingAVMarketingData = await this.UnitOfWork.GetMissingAVMarketingDataAsync(this.UserIdentity, this.CurrentUserProfile.UserName, pagination).ConfigureAwait(false);
            if (missingAVMarketingData != null)
            {
                return this.Ok(missingAVMarketingData);
            }

            return this.NotFound();
        }
        #endregion

        #region Missing AV Marketing Data BId
        [HttpPost]
        [ProducesResponseType(typeof(MissingAVMarketingDataViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingAVMarketingDataViewModel[]), 404)]
        [Route("/today/TodayPage/GetMissingAVMarketingDataBId/{bId}")]
        public async Task<IActionResult> GetMissingAVMarketingDataBId(int bId, [FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2639;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2639;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var missingAVMarketingData = await this.UnitOfWork.GetMissingAVMarketingDataBIdAsync(this.UserIdentity, this.CurrentUserProfile.UserName, pagination, bId).ConfigureAwait(false);
            if (missingAVMarketingData != null)
            {
                return this.Ok(missingAVMarketingData);
            }

            return this.NotFound();
        }
        #endregion

        #region MissingRequiredMilestone
        [ProducesResponseType(typeof(MissingRequiredMilestoneViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingRequiredMilestoneViewModel[]), 404)]
        [Route("/today/TodayPage/GetMissingRequiredMilestones")]
        public async Task<IActionResult> GetMissingRequiredMilestones()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var missingRequiredMilestones = await this.UnitOfWork.GetMissingRequiredMilestonesAsync(this.UserIdentity).ConfigureAwait(false);
            if (missingRequiredMilestones != null)
            {
                return this.Ok(missingRequiredMilestones);
            }

            return this.NotFound();
        }
        #endregion

        #region Observations
        [HttpPost]
        [ProducesResponseType(typeof(ObservationUnassignedViewModel[]), 200)]
        [ProducesResponseType(typeof(ObservationUnassignedViewModel[]), 404)]
        public async Task<IActionResult> GetObservationsUnassigned([FromBody]PaginationModel pagination, string type = "")
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2393;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2393;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var observationsUnassignedDetails = await this.UnitOfWork.GetObservationsUnassignedAsync(this.UserIdentity, type, pagination).ConfigureAwait(false);
            if (observationsUnassignedDetails != null)
            {
                return this.Ok(observationsUnassignedDetails);
            }

            return this.NotFound();
        }

        [ProducesResponseType(typeof(ObservationTransferRequestedViewModel[]), 200)]
        [ProducesResponseType(typeof(ObservationTransferRequestedViewModel[]), 404)]
        public async Task<IActionResult> GetObservationsTransferRequested([FromBody]PaginationModel pagination, string type = "")
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3463;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3463;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var observationsTransferRequestedDetails = await this.UnitOfWork.GetObservationsTransferRequestedAsync(this.UserIdentity, type, pagination).ConfigureAwait(false);
            if (observationsTransferRequestedDetails != null)
            {
                return this.Ok(observationsTransferRequestedDetails);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(HardwareObservationUnassignedViewModel[]), 200)]
        [ProducesResponseType(typeof(HardwareObservationUnassignedViewModel[]), 404)]
        [Route("/today/TodayPage/GetHardwareObservationsUnassigned")]
        public async Task<IActionResult> GetHardwareObservationsUnassigned([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 12033;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 12033;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var hardwareObservationsUnassignedDetails = await this.UnitOfWork.GetHardwareObservationsUnassignedAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (hardwareObservationsUnassignedDetails != null)
            {
                return this.Ok(hardwareObservationsUnassignedDetails);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(HardwareObservationTransferRequestedViewModel[]), 200)]
        [ProducesResponseType(typeof(HardwareObservationTransferRequestedViewModel[]), 404)]
        [Route("/today/TodayPage/GetHardwareObservationsTransferRequested")]
        public async Task<IActionResult> GetHardwareObservationsTransferRequested([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 12033;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 12033;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var hardwareObservationsTransferRequestedDetails = await this.UnitOfWork.GetHardwareObservationsTransferRequestedAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (hardwareObservationsTransferRequestedDetails != null)
            {
                return this.Ok(hardwareObservationsTransferRequestedDetails);
            }

            return this.NotFound();
        }
        #endregion

        #region SETestLead
        [ProducesResponseType(typeof(UnassignedTestLeadViewModel[]), 200)]
        [ProducesResponseType(typeof(UnassignedTestLeadViewModel[]), 400)]
        [Route("/today/TodayPage/GetUnassignedTestLeads")]
        public async Task<IActionResult> GetUnassignedTestLeads()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 1090;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 1090;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var missingSETestLeads = await this.UnitOfWork.GetUnassignedTestLeadsAsync(this.UserIdentity).ConfigureAwait(false);
            if (missingSETestLeads != null)
            {
                return this.Ok(missingSETestLeads);
            }

            return this.NotFound();
        }
        #endregion

        #region IHubJobsDidNotRunAsScheduled
        [ProducesResponseType(typeof(IHubJobsDidNotRunAsScheduledViewModel[]), 200)]
        [ProducesResponseType(typeof(IHubJobsDidNotRunAsScheduledViewModel[]), 400)]
        [Route("/today/TodayPage/GetIHubJobsDidNotRunAsScheduled/{offset}/{iHubOnly}")]
        public async Task<IActionResult> GetIHubJobsDidNotRunAsScheduled(int offset, bool iHubOnly)
        {
            var iHubJobsDidNotRunAsScheduled = await this.UnitOfWork.GetIHubJobsDidNotRunAsScheduledAsync(offset, iHubOnly).ConfigureAwait(false);
            if (iHubJobsDidNotRunAsScheduled != null)
            {
                return this.Ok(iHubJobsDidNotRunAsScheduled);
            }

            return this.NotFound();
        }
        #endregion

        #region SMRAwaitingApproval
        [ProducesResponseType(typeof(SMRAwaitingApprovalViewModel[]), 200)]
        [ProducesResponseType(typeof(SMRAwaitingApprovalViewModel[]), 404)]
        [Route("/today/TodayPage/GetSmrAwaitingApproval")]
        public async Task<IActionResult> GetSmrAwaitingApproval()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 7870;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 7870;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }

            var partnerId = CurrentUserProfile.PartnerId.HasValue ? CurrentUserProfile.PartnerId : 0;
            var smrAwaitingApproval = await this.UnitOfWork.GetSMRAwaitingApprovalAsync(this.UserIdentity, partnerId).ConfigureAwait(false);
            if (smrAwaitingApproval != null)
            {
                return this.Ok(smrAwaitingApproval);
            }

            return this.NotFound();
        }
        #endregion

        #region AVsNotRequested
        [ProducesResponseType(typeof(AVsNotRequestedViewModel[]), 200)]
        [ProducesResponseType(typeof(AVsNotRequestedViewModel[]), 404)]
        [Route("/today/TodayPage/GetAvsNotRequested")]
        public async Task<IActionResult> GetAvsNotRequested()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var avsNotRequested = await this.UnitOfWork.GetAVsNotRequestedAsync(this.UserIdentity).ConfigureAwait(false);
            if (avsNotRequested != null)
            {
                return this.Ok(avsNotRequested);
            }

            return this.NotFound();
        }
        #endregion

        #region SpareKits Not Mapped to Avs
        [HttpPost]
        [ProducesResponseType(typeof(SpareKitsNotMappedtoAvsViewModel[]), 200)]
        [ProducesResponseType(typeof(SpareKitsNotMappedtoAvsViewModel[]), 400)]
        [Route("/today/TodayPage/GetSpareKitsNotMappedtoAvs")]
        public async Task<IActionResult> GetSpareKitsNotMappedtoAvs([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 7190;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 7190;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var spareKitsNotMappedtoAvs = await this.UnitOfWork.GetSpareKitsNotMappedtoAvsAsync(this.UserIdentity, pagination).ConfigureAwait(false);

            if (spareKitsNotMappedtoAvs != null)
            {
                return this.Ok(spareKitsNotMappedtoAvs);
            }

            return this.NotFound();
        }
        #endregion

        #region SustainingProductSupport
        [HttpPost]
        [ProducesResponseType(typeof(SustainingProductSupportInTestViewModel[]), 200)]
        [ProducesResponseType(typeof(SustainingProductSupportInTestViewModel[]), 400)]
        [Route("/today/TodayPage/GetSustainingProductSupportInTest/{report}")]
        public async Task<IActionResult> GetSustainingProductSupportInTest(int report, [FromBody]PaginationModel pagination)
        {
            var sustainingProductSupportInTest = await this.UnitOfWork.GetSustainingProductSupportInTestAsync(report, pagination).ConfigureAwait(false);
            if (sustainingProductSupportInTest != null)
            {
                return this.Ok(sustainingProductSupportInTest);
            }
            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(SustainingProductSupportInCompleteViewModel[]), 200)]
        [ProducesResponseType(typeof(SustainingProductSupportInCompleteViewModel[]), 400)]
        [Route("/today/TodayPage/GetSustainingProductSupportInComplete/{report}")]
        public async Task<IActionResult> GetSustainingProductSupportInComplete(int report, [FromBody]PaginationModel pagination)
        {
            var sustainingProductSupportInComplete = await this.UnitOfWork.GetSustainingProductSupportInCompleteAsync(report, pagination).ConfigureAwait(false);
            if (sustainingProductSupportInComplete != null)
            {
                return this.Ok(sustainingProductSupportInComplete);
            }
            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(SustainingProductSupportInTestPendingViewModel[]), 200)]
        [ProducesResponseType(typeof(SustainingProductSupportInTestPendingViewModel[]), 400)]
        [Route("/today/TodayPage/GetSustainingProductSupportInTestPending/{report}")]
        public async Task<IActionResult> GetSustainingProductSupportInTestPending(int report, [FromBody]PaginationModel pagination)
        {
            var sustainingProductSupportInTestPending = await this.UnitOfWork.GetSustainingProductSupportInTestPendingAsync(report, pagination).ConfigureAwait(false);
            if (sustainingProductSupportInTestPending != null)
            {
                return this.Ok(sustainingProductSupportInTestPending);
            }
            return this.NotFound();
        }
        #endregion

        #region Product Missing PDM Team Member
        // <summary>
        [HttpGet]
        [ProducesResponseType(typeof(ProductMissingPDMTeamMemberViewModel[]), 200)]
        [ProducesResponseType(typeof(ProductMissingPDMTeamMemberViewModel[]), 400)]
        [Route("/today/TodayPage/GetProductMisssingPdmTeamMember")]
        public async Task<IActionResult> GetProductMisssingPdmTeamMember()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var productBrandDetails = await this.UnitOfWork.GetProductMisssingPDMTeamMemberAsync(this.UserIdentity).ConfigureAwait(false);
            if (productBrandDetails != null)
            {
                return this.Ok(productBrandDetails);
            }
            return this.NotFound();
        }
        #endregion

        #region AVs Not Mapped to SpareKit
        [HttpPost]
        [ProducesResponseType(typeof(AVsNotMappedtoSpareKitsViewModel[]), 200)]
        [ProducesResponseType(typeof(AVsNotMappedtoSpareKitsViewModel[]), 400)]
        [Route("/today/TodayPage/GetAvsNotMappedToSpareKits")]
        public async Task<IActionResult> GetAvsNotMappedToSpareKits([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 7190;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 7190;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var avsNotMappedToSpareKits = await this.UnitOfWork.GetAVsNotMappedtoSpareKitsAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (avsNotMappedToSpareKits != null)
            {
                return this.Ok(avsNotMappedToSpareKits);
            }
            return this.NotFound();
        }
        #endregion

        #region Components Awaiting Final Approval
        [HttpPost]
        [ProducesResponseType(typeof(ComponentsAwaitingFinalApprovalViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentsAwaitingFinalApprovalViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentsAwaitingFinalApproval")]
        public async Task<IActionResult> GetComponentsAwaitingFinalApproval([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 5895;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 5895;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var componentsAwaitingFinalApproval = await this.UnitOfWork.GetComponentsAwaitingFinalApprovalAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (componentsAwaitingFinalApproval != null)
            {
                return this.Ok(componentsAwaitingFinalApproval);
            }
            return this.NotFound();
        }
        #endregion

        #region MyWorkingList
        [HttpPost]
        [ProducesResponseType(typeof(MyWorkingListViewModel[]), 200)]
        [ProducesResponseType(typeof(MyWorkingListViewModel[]), 404)]
        [Route("/today/TodayPage/GetMyWorkings")]
        public async Task<IActionResult> GetMyWorkings([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var myWorkings = await this.UnitOfWork.GetMyWorkingListAsync(this.UserIdentity, this.CurrentUserProfile.UserId, pagination).ConfigureAwait(false);
            if (myWorkings != null)
            {
                return this.Ok(myWorkings);
            }
            return this.NotFound();
        }
        #endregion

        #region Products With Expired Service LifeDate
        [HttpPost]
        [ProducesResponseType(typeof(ProductsWithExpiredServiceLifeDateViewModel[]), 200)]
        [ProducesResponseType(typeof(ProductsWithExpiredServiceLifeDateViewModel[]), 404)]
        [Route("/today/TodayPage/GetProductsWithExpiredServiceLifeDate")]
        public async Task<IActionResult> GetProductsWithExpiredServiceLifeDate([FromBody]PaginationModel pagination)
        {
            var productsWithExpiredServiceLifeDate = await this.UnitOfWork.GetProductsWithExpiredServiceLifeDateAsync(pagination).ConfigureAwait(false);
            if (productsWithExpiredServiceLifeDate != null)
            {
                return this.Ok(productsWithExpiredServiceLifeDate);
            }
            return this.NotFound();
        }
        #endregion

        #region Users and Roles Requests 
        [HttpGet]
        [ProducesResponseType(typeof(UsersandRolesRequestsViewModel[]), 200)]
        [ProducesResponseType(typeof(UsersandRolesRequestsViewModel[]), 404)]
        [Route("/today/TodayPage/GetUserAndRoleRequests")]
        public async Task<IActionResult> GetUserAndRoleRequests()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = this.GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var userandRoleRequests = await this.UnitOfWork.GetUserAndRolesRequestsAsync(this.UserIdentity, CurrentUserProfile.ImpersonateId).ConfigureAwait(false);
            if (userandRoleRequests != null)
            {
                return this.Ok(userandRoleRequests);
            }
            return this.NotFound();
        }
        #endregion

        #region Create Simple AVs (Legacy Product)
        [HttpPost]
        [ProducesResponseType(typeof(LegacySimpleAVViewModel[]), 200)]
        [ProducesResponseType(typeof(LegacySimpleAVViewModel[]), 404)]
        [Route("/today/TodayPage/GetLegacySimpleAvsCreated")]
        public async Task<IActionResult> GetLegacySimpleAvsCreated([FromBody] PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var legacySimpleAvsCreated = await this.UnitOfWork.GetLegacySimpleAVsCreatedAsync((int)this.UserIdentity, pagination).ConfigureAwait(false);
            if (legacySimpleAvsCreated != null)
            {
                return this.Ok(legacySimpleAvsCreated);
            }
            return this.NotFound();
        }
        #endregion

        #region Create Simple AVs (Pulsar Product)
        [HttpPost]
        [ProducesResponseType(typeof(PulsarSimpleAVViewModel[]), 200)]
        [ProducesResponseType(typeof(PulsarSimpleAVViewModel[]), 404)]
        [Route("/today/TodayPage/GetPulsarSimpleAvsCreated")]
        public async Task<IActionResult> GetPulsarSimpleAvsCreated([FromBody] PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 6697;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 6697;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var pulsarSimpleAvsCreated = await this.UnitOfWork.GetPulsarSimpleAVsCreatedAsync((int)this.UserIdentity, pagination).ConfigureAwait(false);
            if (pulsarSimpleAvsCreated != null)
            {
                return this.Ok(pulsarSimpleAvsCreated);
            }
            return this.NotFound();
        }
        #endregion

        #region New Component Request
        [HttpPost]
        [ProducesResponseType(typeof(NewComponentRequestViewModel[]), 200)]
        [ProducesResponseType(typeof(NewComponentRequestViewModel[]), 404)]
        [Route("/today/TodayPage/GetNewComponentRequests")]
        public async Task<IActionResult> GetNewComponentRequests([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 1090;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 1090;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var newComponentRequest = await this.UnitOfWork.GetNewComponentRequestAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (newComponentRequest != null)
            {
                return this.Ok(newComponentRequest);
            }
            return this.NotFound();
        }
        #endregion

        #region New Components Released For My Products Two
        [HttpGet]
        [ProducesResponseType(typeof(NewComponentsReleasedForMyProductsTwoViewModel[]), 200)]
        [ProducesResponseType(typeof(NewComponentsReleasedForMyProductsTwoViewModel[]), 404)]
        [Route("/today/TodayPage/GetNewComponentsReleasedForMyProductsTwo")]
        public async Task<IActionResult> GetNewComponentsReleasedForMyProductsTwo()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 1644;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 1644;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var newComponentsReleased = await this.UnitOfWork.GetNewComponentsReleasedForMyProductsTwoAsync(this.UserIdentity).ConfigureAwait(false);
            if (newComponentsReleased != null)
            {
                return this.Ok(newComponentsReleased);
            }
            return this.NotFound();
        }
        #endregion

        #region Approval Requested Release To Production
        [HttpGet]
        [ProducesResponseType(typeof(ApprovalRequestedReleaseToProductionViewModel[]), 200)]
        [ProducesResponseType(typeof(ApprovalRequestedReleaseToProductionViewModel[]), 404)]
        [Route("/today/TodayPage/GetApprovalRequestedReleaseToProduction")]
        public async Task<IActionResult> GetApprovalRequestedReleaseToProduction()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 8680;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 8680;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var approvalRequestedReleaseToProduction = await this.UnitOfWork.GetApprovalRequestedReleaseToProductionAsync(this.UserIdentity).ConfigureAwait(false);
            if (approvalRequestedReleaseToProduction != null)
            {
                return this.Ok(approvalRequestedReleaseToProduction);
            }
            return this.NotFound();
        }
        #endregion

        #region AVs Deleted but Mapped to SpareKits
        [HttpPost]
        [ProducesResponseType(typeof(AVsDeletedbutMappedtoSpareKitsViewModel[]), 200)]
        [ProducesResponseType(typeof(AVsDeletedbutMappedtoSpareKitsViewModel[]), 404)]
        [Route("/today/TodayPage/GetDeletedAvsMappedToSpareKits")]
        public async Task<IActionResult> GetDeletedAvsMappedToSpareKits([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var avsDeletedButMappedToSpareKits = await this.UnitOfWork.GetAVsDeletedbutMappedtoSpareKitsAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (avsDeletedButMappedToSpareKits != null)
            {
                return this.Ok(avsDeletedButMappedToSpareKits);
            }
            return this.NotFound();
        }
        #endregion

        #region Component in Release Workflow Step
        [Route("today/todaypage/GetComponentsInWorkflowState")]
        [ProducesResponseType(typeof(ComponentsInWorkflowStateViewModel), 200)]
        [ProducesResponseType(typeof(ComponentsInWorkflowStateViewModel), 404)]
        public async Task<IActionResult> GetComponentsInWorkflowState(string value, int? devManagerId, [FromBody]PaginationModel pagination)
        {
            if (value == null)
            {
                value = "null";
            }
            var componentRelease = await this.UnitOfWork.GetComponentsInWorkflowStateAsync(value, devManagerId, pagination).ConfigureAwait(false);
            if (componentRelease != null)
            {
                return this.Ok(componentRelease);
            }
            return this.NotFound();
        }
        #endregion

        #region PHweb AVAction Items LegacyProduct
        [ProducesResponseType(typeof(PHwebAVActionItemsLegacyProductViewModel[]), 200)]
        [ProducesResponseType(typeof(PHwebAVActionItemsLegacyProductViewModel[]), 404)]
        public async Task<IActionResult> GetPHwebAVActionItemsLegacyProduct([FromBody]PaginationModel pagination, int? autoInputOnly)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 14136;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 14136;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }

            var phwebAVActionItemsLegacyProduct = await this.UnitOfWork.GetPHwebAVActionItemsLegacyProductAsync(pagination, this.CurrentUserProfile.UserName, this.UserIdentity, autoInputOnly).ConfigureAwait(false);
            if (phwebAVActionItemsLegacyProduct != null)
            {
                return this.Ok(phwebAVActionItemsLegacyProduct);
            }
            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(PHwebAVActionItemsLegacyProductViewModel[]), 200)]
        [ProducesResponseType(typeof(PHwebAVActionItemsLegacyProductViewModel[]), 404)]
        [Route("/today/TodayPage/GetPhWebAvActionItemsLegacyProductBId/{bId}")]
        public async Task<IActionResult> GetPhWebAvActionItemsLegacyProductBId([FromBody]PaginationModel pagination, int bId)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 14136;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 14136;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            int? autoInputOnly = null;
            var phwebAVActionItemsLegacyProduct = await this.UnitOfWork.GetPHwebAVActionItemsLegacyProductBIdAsync(pagination, (int)this.UserIdentity, bId, autoInputOnly).ConfigureAwait(false);
            if (phwebAVActionItemsLegacyProduct != null)
            {
                return this.Ok(phwebAVActionItemsLegacyProduct);
            }
            return this.NotFound();
        }
        #endregion

        #region SpareKits Not Structured to Family
        [HttpPost]
        [ProducesResponseType(typeof(SpareKitsNotStructuredtoFamilyViewModel[]), 200)]
        [ProducesResponseType(typeof(SpareKitsNotStructuredtoFamilyViewModel[]), 404)]
        [Route("/today/TodayPage/GetSpareKitsFamilyNotStructured")]
        public async Task<IActionResult> GetSpareKitsFamilyNotStructured([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 12533;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 12533;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var spareKitsFamilyNotStructured = await this.UnitOfWork.GetSpareKitsNotStructuredtoFamilyAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (spareKitsFamilyNotStructured != null)
            {
                return this.Ok(spareKitsFamilyNotStructured);
            }
            return this.NotFound();
        }
        #endregion

        #region Upcoming Release
        public async Task<IActionResult> GetUpcomingReleases(string value)
        {
            if (value == null)
            {
                value = "null";
            }

            var upcomingRelease = await this.UnitOfWork.GetUpcomingReleasesAsync(value).ConfigureAwait(false);
            if (upcomingRelease != null)
            {
                return this.Ok(upcomingRelease);
            }
            return this.NotFound();
        }
        #endregion

        #region Help And Support Upcoming Releases
        [ProducesResponseType(typeof(UpcomingReleasesViewModel[]), 200)]
        [ProducesResponseType(typeof(UpcomingReleasesViewModel[]), 404)]
        [ActionName("GetUpcomingReleasesHelpAndSupport")]
        [Route("/today/TodayPage/GetUpcomingReleasesHelpAndSupport")]
        public async Task<IActionResult> GetUpcomingReleases()
        {
            int reportId = 1;
            var upcomingReleases = await this.UnitOfWork.GetUpcomingReleasesAsync(reportId).ConfigureAwait(false);
            if (upcomingReleases != null)
            {
                return this.Ok(upcomingReleases);
            }
            return this.NotFound();
        }
        #endregion

        #region PH web AVAction Items Pulsar Product
        [HttpPost]
        [ProducesResponseType(typeof(PHwebAVActionItemsPulsarProductViewModel[]), 200)]
        [ProducesResponseType(typeof(PHwebAVActionItemsPulsarProductViewModel[]), 404)]
        [Route("/today/TodayPage/GetPhWebAvActionItemsPulsarProduct")]
        public async Task<IActionResult> GetPhWebAvActionItemsPulsarProduct([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 17777;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 17777;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var phWebAvActionItemsPulsarProduct = await this.UnitOfWork.GetPHwebAVActionItemsPulsarProductAsync(pagination, this.UserIdentity).ConfigureAwait(false);
            if (phWebAvActionItemsPulsarProduct != null)
            {
                return this.Ok(phWebAvActionItemsPulsarProduct);
            }
            return this.NotFound();
        }
        #endregion

        #region Features Requesting Root Component
        [HttpPost]
        [ProducesResponseType(typeof(FeaturesRequestingRootComponentsViewModel[]), 200)]
        [ProducesResponseType(typeof(FeaturesRequestingRootComponentsViewModel[]), 400)]
        [Route("/today/TodayPage/GetFeaturesRequestingRootComponents")]
        public async Task<IActionResult> GetFeaturesRequestingRootComponents([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3756;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3756;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var featuresRequestingRootComponents = await this.UnitOfWork.GetFeaturesRequestingRootComponentsAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (featuresRequestingRootComponents != null)
            {
                return this.Ok(featuresRequestingRootComponents);
            }
            return this.NotFound();
        }
        #endregion

        #region RecentVersionsReleased
        [ProducesResponseType(typeof(RecentVersionsReleasedViewModel[]), 200)]
        [ProducesResponseType(typeof(RecentVersionsReleasedViewModel[]), 404)]
        [Route("/today/TodayPage/GetRecentVersionsReleased")]
        public async Task<IActionResult> GetRecentVersionsReleased()
        {
            int reportId = 2;
            var recentVersionsReleased = await this.UnitOfWork.GetRecentVersionsReleasedAsync(reportId).ConfigureAwait(false);
            if (recentVersionsReleased != null)
            {
                return this.Ok(recentVersionsReleased);
            }
            return this.NotFound();
        }
        #endregion

        #region WWANEngineerAlerts
        [ProducesResponseType(typeof(FailedTTSComponentsToReviewViewModel[]), 200)]
        [ProducesResponseType(typeof(FailedTTSComponentsToReviewViewModel[]), 404)]
        [Route("/today/TodayPage/GetFailedTtsComponentsToReview")]
        public async Task<IActionResult> GetFailedTtsComponentsToReview()
        {
            var failedTtsComponents = await this.UnitOfWork.GetFailedTTSComponentsToReviewAsync().ConfigureAwait(false);
            if (failedTtsComponents != null)
            {
                return this.Ok(failedTtsComponents);
            }
            return this.NotFound();
        }
        #endregion

        #region Feature Root Requests Rejected 
        [HttpGet]
        [ProducesResponseType(typeof(FeatureRootRequestsRejectedViewModel[]), 200)]
        [ProducesResponseType(typeof(FeatureRootRequestsRejectedViewModel[]), 404)]
        [Route("/today/TodayPage/GetFeatureRootRequestsRejected")]
        public async Task<IActionResult> GetFeatureRootRequestsRejected()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3330;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3330;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var featureRootRequestsRejected = await this.UnitOfWork.GetFeatureRootRequestsRejectedAsync(this.UserIdentity).ConfigureAwait(false);
            if (featureRootRequestsRejected != null)
            {
                return this.Ok(featureRootRequestsRejected);
            }
            return this.NotFound();
        }
        #endregion

        #region MissingBaseUnitSubassemblyNumbers
        [ProducesResponseType(typeof(MissingBaseUnitSubassemblyNumbersViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingBaseUnitSubassemblyNumbersViewModel[]), 404)]
        [Route("/today/TodayPage/GetMissingBaseUnitSubassemblyNumbers")]
        public async Task<IActionResult> GetMissingBaseUnitSubassemblyNumbers()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 1018;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 1018;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var missingBaseUnitSubassemblyNumbers = await this.UnitOfWork.GetMissingBaseUnitSubassemblyNumbersAsync(this.UserIdentity).ConfigureAwait(false);
            if (missingBaseUnitSubassemblyNumbers != null)
            {
                return this.Ok(missingBaseUnitSubassemblyNumbers);
            }
            return this.NotFound();
        }
        #endregion

        #region Impersonate Name
        [Route("/today/TodayPage/GetImpersonateName")]
        public async Task<IActionResult> GetImpersonateName()
        {
            int? impersonateId = GetCmPcPhWebMktImpersonateID();
            var title = string.Empty;
            var subTitle = string.Empty;
            string impersonatename = string.Empty;
            if (impersonateId == 0)
            {
                title = string.Empty;
                subTitle = string.Empty;
            }
            else
            {
                impersonatename = await this.UnitOfWork.GetNameByImpersonateIdAsync(impersonateId.Value).ConfigureAwait(false);
                title = "-" + impersonatename;
                subTitle = "-" + impersonatename;
            }
            return this.Ok(new { title, subTitle, impersonatename, impersonateId });
        }
        #endregion

        #region MyActionItemsPastDue
        [HttpGet]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 400)]
        [Route("/today/TodayPage/GetPastDuesAlertTitle")]
        public async Task<IActionResult> GetPastDuesAlertTitle()
        {
            int impersonateId = GetCmPcPhWebMktImpersonateID();
            var title = string.Empty;
            if (impersonateId == 0)
            {
                title = "Past Due";
            }
            else
            {
                string impersonatename = await this.UnitOfWork.GetNameByImpersonateIdAsync(impersonateId).ConfigureAwait(false);
                title = "Schedule Alerts -" + impersonatename;
            }
            return this.Json(new { title });
        }

        [HttpPost]
        [ProducesResponseType(typeof(PastDuesViewModel[]), 200)]
        [ProducesResponseType(typeof(PastDuesViewModel[]), 400)]
        [Route("/today/TodayPage/GetPastDues")]
        public async Task<IActionResult> GetPastDues([FromBody] PaginationModel paginationInfo)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 716;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 716;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var pastDueAlertItems = await this.UnitOfWork.GetPastDuesAsync(this.UserIdentity, paginationInfo).ConfigureAwait(false);
            if (pastDueAlertItems != null)
            {
                return this.Ok(pastDueAlertItems);
            }
            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 400)]
        [Route("/today/TodayPage/GetPastDuesCount")]
        public async Task<IActionResult> GetPastDuesCount()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 716;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 716;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var pastDueAlertItemsCount = await this.UnitOfWork.GetPastDuesCountAsync(this.UserIdentity).ConfigureAwait(false);
            return this.Ok(pastDueAlertItemsCount);
        }

        public int GetUserIdentity()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = this.GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            return this.UserIdentity;
        }

        [HttpPost]
        [ProducesResponseType(typeof(PastDuesAlertViewModel[]), 200)]
        [ProducesResponseType(typeof(PastDuesAlertViewModel[]), 400)]
        [Route("/today/TodayPage/GetPastDueAlerts")]
        public async Task<IActionResult> GetPastDueAlerts([FromBody] PaginationModel paginationInfo)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 648;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 648;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var pastDueAlertItems = await this.UnitOfWork.GetPastDuesAlertAsync(this.UserIdentity, paginationInfo).ConfigureAwait(false);
            if (pastDueAlertItems != null)
            {
                return this.Ok(pastDueAlertItems);
            }
            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 400)]
        [Route("/today/TodayPage/GetPastDuesAlertCount")]
        public async Task<IActionResult> GetPastDuesAlertCount()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 648;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 648;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID(); // 648
            }
            var pastDueAlertItemsCount = await this.UnitOfWork.GetPastDuesAlertCountAsync(this.UserIdentity).ConfigureAwait(false);
            return this.Ok(pastDueAlertItemsCount);
        }
        #endregion

        #region Shared AV Actions
        [ProducesResponseType(typeof(SharedAVActionsViewModel[]), 200)]
        [ProducesResponseType(typeof(SharedAVActionsViewModel[]), 404)]
        [Route("/today/TodayPage/GetSharedAVActions")]
        public async Task<IActionResult> GetSharedAVActions([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 15947;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 15947;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var sharedAVActions = await this.UnitOfWork.GetSharedAVActionsAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (sharedAVActions != null)
            {
                return this.Ok(sharedAVActions);
            }
            return this.NotFound();
        }
        #endregion

        #region Component Awaiting Test Review
        [HttpPost]
        [ProducesResponseType(typeof(ComponentsAwaitingTestReviewViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentsAwaitingTestReviewViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentsAwaitingTestReview")]
        public async Task<IActionResult> GetComponentsAwaitingTestReview([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
                this.UserLoginDomain = "AUTH";
                this.UserLoginName = "parthasp";
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
                this.UserLoginDomain = "AUTH";
                this.UserLoginName = "parthasp";
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
                this.UserLoginDomain = CurrentUserProfile.LoginDomain;
                this.UserLoginName = CurrentUserProfile.LoginAuthName;
            }
            var componentsAwaitingTestReview = await this.UnitOfWork.GetComponentsAwaitingTestReviewAsync(componentsAwaitingTestReviewStatus, this.UserLoginName, this.UserLoginDomain, componentsAwaitingTestReviewManagerId, pagination).ConfigureAwait(false);
            if (componentsAwaitingTestReview != null)
            {
                return this.Ok(componentsAwaitingTestReview);
            }
            return this.NotFound();
        }
        #endregion

        #region Initial Offering Deactivate Simple AVs
        [ProducesResponseType(typeof(InitialOfferingDeactivateSimpleAVsViewModel[]), 200)]
        [ProducesResponseType(typeof(InitialOfferingDeactivateSimpleAVsViewModel[]), 404)]
        [Route("/today/TodayPage/GetInitialOfferingDeactivateSimpleAvs")]
        public async Task<IActionResult> GetInitialOfferingDeactivateSimpleAvs()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = this.GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var initialOfferingDeactivateSimpleAvs = await this.UnitOfWork.GetInitialOfferingDeactivateSimpleAVsAsync(this.UserIdentity).ConfigureAwait(false);
            if (initialOfferingDeactivateSimpleAvs != null)
            {
                return this.Ok(initialOfferingDeactivateSimpleAvs);
            }
            return this.NotFound();
        }
        #endregion

        #region MyActionItemsDueThisWeek
        [HttpPost]
        [ProducesResponseType(typeof(DueThisWeekViewModel[]), 200)]
        [ProducesResponseType(typeof(DueThisWeekViewModel[]), 400)]
        [Route("/today/TodayPage/GetDueThisWeek")]
        public async Task<IActionResult> GetDueThisWeek([FromBody] PaginationModel paginationInfo)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 567;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 567;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var dueThisWeek = await this.UnitOfWork.GetDueThisWeekAsync(this.UserIdentity, paginationInfo).ConfigureAwait(false);
            if (dueThisWeek != null)
            {
                return this.Ok(dueThisWeek);
            }
            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 400)]
        [Route("/today/TodayPage/GetDueThisWeekCount")]
        public async Task<IActionResult> GetDueThisWeekCount()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 567;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 567;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var dueThisWeekCount = await this.UnitOfWork.GetDueThisWeekCountAsync(this.UserIdentity).ConfigureAwait(false);
            return this.Ok(dueThisWeekCount);
        }
        #endregion

        #region My Observations
        [HttpPost]
        [ProducesResponseType(typeof(MyObservationViewModel[]), 200)]
        [ProducesResponseType(typeof(MyObservationViewModel[]), 400)]
        [Route("/today/TodayPage/GetMyObservations/{report}")]
        public async Task<IActionResult> GetMyObservations(int report, [FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 1054;
                this.UserLoginDomain = "AUTH";
                this.UserLoginName = "hsiehp";
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 1054;
                this.UserLoginDomain = "AUTH";
                this.UserLoginName = "hsiehp";
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
                this.UserLoginDomain = CurrentUserProfile.LoginDomain;
                this.UserLoginName = CurrentUserProfile.LoginAuthName;
            }
            var myObservations = await this.UnitOfWork.GetMyObservationsAsync(this.UserIdentity, report, this.UserLoginName, this.UserLoginDomain, pagination).ConfigureAwait(false);
            if (myObservations != null)
            {
                return this.Ok(myObservations);
            }
            return this.NotFound();
        }
        #endregion

        #region CRProposed
        [HttpPost]
        [ProducesResponseType(typeof(CRProposedViewModel[]), 200)]
        [ProducesResponseType(typeof(CRProposedViewModel[]), 400)]
        [Route("/today/TodayPage/GetCRProposed")]
        public async Task<IActionResult> GetCRProposed([FromBody]PaginationModel pagination)
        {
            string productIds = string.Empty;
            string productsInFavourites = CurrentUserProfile.Favourites;
            if (!string.IsNullOrEmpty(productsInFavourites))
            {
                var productFavourites = productsInFavourites.Split(',').Select(x => x).Where(y => y.StartsWith("P")).ToArray().Aggregate((index, value) => index + "," + value);
                productIds = productFavourites.Replace("P", "").Replace(",", "_");
            }
            var crProposed = await this.UnitOfWork.GetCRProposedAsync(productIds, pagination).ConfigureAwait(false);
            if (crProposed != null)
            {
                return this.Ok(crProposed);
            }
            return this.NotFound();
        }

        [ProducesResponseType(typeof(CRProposedViewModel[]), 200)]
        [ProducesResponseType(typeof(CRProposedViewModel[]), 404)]
        [Route("/today/TodayPage/GetCRProposedExportToExcel")]
        public async Task<FileStreamResult> GetCRProposedExportToExcel()
        {
            string fileName = string.Empty;
            string contentType = string.Empty;
            var stream = new MemoryStream();
            using (ExcelPackage package = new ExcelPackage())
            {
                PaginationModel pagination = new PaginationModel();
                pagination.Filters = new FilterModel[0];
                pagination.PageNo = 1;
                pagination.PageSize = 10000;
                string productIds = string.Empty;
                string productsInFavourites = CurrentUserProfile.Favourites;
                if (!string.IsNullOrEmpty(productsInFavourites))
                {
                    var productFavourites = productsInFavourites.Split(',').Select(x => x).Where(y => y.StartsWith("P")).ToArray().Aggregate((index, value) => index + "," + value);
                    productIds = productFavourites.Replace("P", "").Replace(",", "_");
                }
                var crProposed = await this.UnitOfWork.GetCRProposedAsync(productIds, pagination).ConfigureAwait(false);
                if (crProposed != null)
                {

                    ExcelWorksheet rptProductLocalization = package.Workbook.Worksheets.Add("CR Proposed");
                    System.Drawing.Color headerColor = System.Drawing.ColorTranslator.FromHtml("#DCDCDC");
                    rptProductLocalization.Cells[1, 1].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 1].Value = "ID";
                    rptProductLocalization.Cells[1, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 1].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 1].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(1).Width = 10;

                    rptProductLocalization.Cells[1, 2].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 2].Value = "Product";
                    rptProductLocalization.Cells[1, 2].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 2].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(2).Width = 20;

                    rptProductLocalization.Cells[1, 3].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 3].Value = "Status";
                    rptProductLocalization.Cells[1, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 3].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 3].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(3).Width = 15;

                    rptProductLocalization.Cells[1, 4].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 4].Value = "Owner";
                    rptProductLocalization.Cells[1, 4].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 4].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 4].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(4).Width = 20;

                    rptProductLocalization.Cells[1, 5].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 5].Value = "Submitter";
                    rptProductLocalization.Cells[1, 5].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 5].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 5].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(5).Width = 20;

                    rptProductLocalization.Cells[1, 6].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 6].Value = "Summary";
                    rptProductLocalization.Cells[1, 6].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 6].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 6].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 6].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 6].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 6].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(6).Width = 120;

                    int rowNumber = 2;

                    List<string> regions = new List<string>();

                    for (int dataIndex = 0; dataIndex < crProposed.Length; dataIndex++)
                    {
                        rptProductLocalization.Cells[rowNumber, 1].Value = crProposed[dataIndex].Id;
                        rptProductLocalization.Cells[rowNumber, 2].Value = crProposed[dataIndex].DotsName;
                        rptProductLocalization.Cells[rowNumber, 3].Value = crProposed[dataIndex].Status;
                        rptProductLocalization.Cells[rowNumber, 4].Value = crProposed[dataIndex].Owner;
                        rptProductLocalization.Cells[rowNumber, 5].Value = crProposed[dataIndex].Submitter;
                        rptProductLocalization.Cells[rowNumber, 6].Value = crProposed[dataIndex].Summary;
                        rowNumber = rowNumber + 1;
                    }
                }
                package.SaveAs(stream);
                fileName = "CR Proposed.xlsx";
                contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                stream.Position = 0;
            }
            return File(stream, contentType, fileName);
        }
        #endregion

        #region MyActionItemsOpenItemsISubmitted
        [HttpPost]
        [ProducesResponseType(typeof(OpenItemsISubmittedViewModel[]), 200)]
        [ProducesResponseType(typeof(OpenItemsISubmittedViewModel[]), 400)]
        [Route("/today/TodayPage/GetOpenItemsISubmitted")]
        public async Task<IActionResult> GetOpenItemsISubmitted([FromBody] PaginationModel paginationInfo)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 648;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 648;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var openItemsISubmitted = await this.UnitOfWork.GetOpenItemsISubmittedAsync(this.UserIdentity, paginationInfo).ConfigureAwait(false);
            if (openItemsISubmitted != null)
            {
                return this.Ok(openItemsISubmitted);
            }
            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 400)]
        [Route("/today/TodayPage/GetOpenItemsISubmittedCount")]
        public async Task<IActionResult> GetOpenItemsISubmittedCount()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 648;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 648;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var openItemsISubmittedCount = await this.UnitOfWork.GetOpenItemsISubmittedCountAsync(this.UserIdentity).ConfigureAwait(false);
            return this.Ok(openItemsISubmittedCount);
        }
        #endregion

        #region Functional Test Upcoming Release
        [ProducesResponseType(typeof(FunctionalTestUpcomingReleaseViewModel[]), 200)]
        [ProducesResponseType(typeof(FunctionalTestUpcomingReleaseViewModel[]), 404)]
        [Route("/today/TodayPage/GetFunctionalTestUpcomingReleases")]
        public async Task<IActionResult> GetFunctionalTestUpcomingReleases()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
                this.UserLoginDomain = "AUTH";
                this.UserLoginName = "parthasp";
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
                this.UserLoginDomain = "AUTH";
                this.UserLoginName = "parthasp";
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
                this.UserLoginDomain = CurrentUserProfile.LoginDomain;
                this.UserLoginName = CurrentUserProfile.LoginAuthName;
            }
            var functionalTestUpcomingReleases = await this.UnitOfWork.GetFunctionalTestUpcomingReleasesAsync(this.UserIdentity, upcomingReleaseStatus, this.UserLoginName, this.UserLoginDomain).ConfigureAwait(false);
            if (functionalTestUpcomingReleases != null)
            {
                return this.Ok(functionalTestUpcomingReleases);
            }
            return this.NotFound();
        }
        #endregion

        #region LinkedComponentsNotUsedByCommodityTeam
        [ProducesResponseType(typeof(LinkedComponentNotUsedByCommodityTeamViewModel[]), 200)]
        [ProducesResponseType(typeof(LinkedComponentNotUsedByCommodityTeamViewModel[]), 404)]
        [Route("/today/TodayPage/GetLinkedComponentsNotUsedByCommodityTeam")]
        public async Task<IActionResult> GetLinkedComponentsNotUsedByCommodityTeam()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2815;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2815;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var linkedComponentsNotUsed = await this.UnitOfWork.GetLinkedComponentsNotUsedByCommodityTeamAsync(this.UserIdentity).ConfigureAwait(false);
            if (linkedComponentsNotUsed != null)
            {
                return this.Ok(linkedComponentsNotUsed);
            }
            return this.NotFound();
        }
        #endregion

        #region Pending ZSRP Ready Dates
        [ProducesResponseType(typeof(PendingZSRPReadyDateViewModel[]), 200)]
        [ProducesResponseType(typeof(PendingZSRPReadyDateViewModel[]), 404)]
        [Route("/today/TodayPage/GetPendingZsrpReadyDates")]
        public async Task<IActionResult> GetPendingZsrpReadyDates()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3951;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3951;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }

            var pendingZsrpReadyDates = await this.UnitOfWork.GetPendingZSRPReadyDatesAsync(this.UserIdentity).ConfigureAwait(false);
            if (pendingZsrpReadyDates != null)
            {
                return this.Ok(pendingZsrpReadyDates);
            }
            return this.NotFound();
        }
        #endregion

        #region  Rejected AVs (Pulsar Product)
        [ProducesResponseType(typeof(AVPHwebRejectionItemViewModel[]), 200)]
        [ProducesResponseType(typeof(AVPHwebRejectionItemViewModel[]), 404)]
        [Route("/today/TodayPage/GetRejectedAvsPulsarProduct")]
        public async Task<IActionResult> GetRejectedAvsPulsarProduct([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 13006;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 13006;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var rejectedAvsPulsar = await this.UnitOfWork.GetRejectedAVsPulsarProductAsync(this.UserIdentity, this.CurrentUserProfile.UserName, pagination).ConfigureAwait(false);
            if (rejectedAvsPulsar != null)
            {
                return this.Ok(rejectedAvsPulsar);
            }
            return this.NotFound();
        }
        #endregion

        #region Components Awaiting Developer Review
        [ProducesResponseType(typeof(ComponentsAwaitingDeveloperReviewViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentsAwaitingDeveloperReviewViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentsAwaitingDeveloperReview")]
        public async Task<IActionResult> GetComponentsAwaitingDeveloperReview([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
                this.UserLoginDomain = "AUTH";
                this.UserLoginName = "parthasp";
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
                this.UserLoginDomain = "AUTH";
                this.UserLoginName = "parthasp";
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
                this.UserLoginDomain = CurrentUserProfile.LoginDomain;
                this.UserLoginName = CurrentUserProfile.LoginAuthName;
            }
            var componentsAwaitingDeveloperReview = await this.UnitOfWork.GetComponentsAwaitingDeveloperReviewAsync(this.UserIdentity, componentsAwaitingDeveloperReviewStatus, this.UserLoginName, this.UserLoginDomain, componentsAwaitingTestReviewManagerId, pagination).ConfigureAwait(false);
            if (componentsAwaitingDeveloperReview != null)
            {
                return this.Ok(componentsAwaitingDeveloperReview);
            }
            return this.NotFound();
        }
        #endregion

        #region Products with missing PM or End of Service Life date
        [HttpGet]
        [ProducesResponseType(typeof(ProductsPmOrEndOfServiceLifeDateViewModel[]), 200)]
        [ProducesResponseType(typeof(ProductsPmOrEndOfServiceLifeDateViewModel[]), 404)]
        [Route("/today/TodayPage/GetProductsWithNoServicePM")]
        public async Task<IActionResult> GetProductsWithNoServicePM()
        {
            bool isServicePM = false;
            if (this.ApplicationMode == xUnitTesting)
            {
                isServicePM = true;
            }
            else if (this.ApplicationMode == localTesting)
            {
                isServicePM = true;
            }
            else
            {
                isServicePM = CurrentUserProfile.ServicePM;
            }
            var productsPmOrEndOfServiceLifeDates = await this.UnitOfWork.GetProductsWithNoServicePMAsync(isServicePM).ConfigureAwait(false);
            if (productsPmOrEndOfServiceLifeDates != null)
            {
                return this.Ok(productsPmOrEndOfServiceLifeDates);
            }
            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(string[]), 200)]
        [ProducesResponseType(typeof(string[]), 404)]
        [Route("/today/TodayPage/GetProductsWithMissingServiceTitle")]
        public IActionResult GetProductsWithMissingServiceTitle()
        {
            string title = string.Empty;
            if (CurrentUserProfile.ServicePM == true)
            {
                title = "Products with missing PM or End of Service Life date";
            }
            else
            {
                title = "Products On Matrix With No Factory Engineer Assigned";
            }
            return this.Json(title);
        }
        #endregion

        #region Products With Missing HW PM
        [HttpPost]
        [ProducesResponseType(typeof(ProductsWithMissingHWPMViewModel[]), 200)]
        [ProducesResponseType(typeof(ProductsWithMissingHWPMViewModel[]), 404)]
        [Route("/today/TodayPage/GetProductsWithMissingHWPM")]
        public async Task<IActionResult> GetProductsWithMissingHWPM([FromBody]PaginationModel paginationInfo)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var productsWithMissingHWPM = await this.UnitOfWork.GetProductsWithMissingHWPMAsync(this.UserIdentity, paginationInfo).ConfigureAwait(false);
            if (productsWithMissingHWPM != null)
            {
                return this.Ok(productsWithMissingHWPM);
            }
            return this.NotFound();
        }
        #endregion

        #region Feature Naming Override Requested
        [ProducesResponseType(typeof(FeatureNamingOverrideRequestedViewModel[]), 200)]
        [ProducesResponseType(typeof(FeatureNamingOverrideRequestedViewModel[]), 404)]
        [Route("/today/TodayPage/GetFeatureNamingOverridesRequested")]
        public async Task<IActionResult> GetFeatureNamingOverridesRequested([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var featureNamingOverridesRequested = await this.UnitOfWork.GetFeatureNamingOverrideRequestedAsync(this.UserIdentity, this.CurrentUserProfile.UserName, pagination).ConfigureAwait(false);
            if (featureNamingOverridesRequested != null)
            {
                return this.Ok(featureNamingOverridesRequested);
            }
            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [Route("/today/TodayPage/SaveOverrideFeatureFeedback")]
        public async Task<IActionResult> SaveOverrideFeatureFeedback([FromBody]FeatureNamingOverrideRequestedViewModel featureNamingOverrideRequestedViewModel)
        {
            this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            var status = await this.UnitOfWork.TrySaveOverrideFeatureFeedbackAsync(featureNamingOverrideRequestedViewModel, this.UserIdentity, this.CurrentUserProfile.Email).ConfigureAwait(false);
            return this.Ok(status);
        }
        #endregion

        #region  Missing Subassembly Numbers (legacy)
        [HttpPost]
        [ProducesResponseType(typeof(MissingSubassemblyNumberslegacyViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingSubassemblyNumberslegacyViewModel[]), 404)]
        [Route("/today/TodayPage/GetMissingSubAssemblyLegacyNumbers")]
        public async Task<IActionResult> GetMissingSubAssemblyLegacyNumbers([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 1018;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 1018;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var missingSubassemblyNumberslegacy = await this.UnitOfWork.GetMissingSubassemblyNumberslegacyAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (missingSubassemblyNumberslegacy != null)
            {
                return this.Ok(missingSubassemblyNumberslegacy);
            }
            return this.NotFound();
        }



        //[HttpPost]
        [ProducesResponseType(typeof(MissingSubassemblyNumberslegacyViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingSubassemblyNumberslegacyViewModel[]), 404)]
        [Route("/today/TodayPage/GetMissingSubAssemblyLegacyExportToExcel")]
        public async Task<FileStreamResult> GetMissingSubAssemblyLegacyExportToExcel()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 1018;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 1018;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            string fileName = string.Empty;
            string contentType = string.Empty;
            var stream = new MemoryStream();
            using (ExcelPackage package = new ExcelPackage())
            {
                PaginationModel pagination = new PaginationModel();
                pagination.Filters = new FilterModel[0];
                pagination.PageNo = 1;
                pagination.PageSize = 10000;
                var missingSubassemblyNumbersData = await this.UnitOfWork.GetMissingSubassemblyNumberslegacyAsync(this.UserIdentity, pagination).ConfigureAwait(false);
                if (missingSubassemblyNumbersData != null)
                {

                    ExcelWorksheet rptProductLocalization = package.Workbook.Worksheets.Add("MissingSubassembly");
                    System.Drawing.Color headerColor = System.Drawing.ColorTranslator.FromHtml("#DCDCDC");
                    rptProductLocalization.Cells[1, 1].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 1].Value = "ID";
                    rptProductLocalization.Cells[1, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 1].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 1].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 1].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(1).Width = 10;

                    rptProductLocalization.Cells[1, 2].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 2].Value = "Product";
                    rptProductLocalization.Cells[1, 2].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 2].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(2).Width = 30;

                    rptProductLocalization.Cells[1, 3].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 3].Value = "Component";
                    rptProductLocalization.Cells[1, 3].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 3].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 3].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 3].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(3).Width = 60;

                    rptProductLocalization.Cells[1, 4].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 4].Value = "Business Segment";
                    rptProductLocalization.Cells[1, 4].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 4].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 4].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 4].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(4).Width = 30;

                    rptProductLocalization.Cells[1, 5].Style.Font.Bold = true;
                    rptProductLocalization.Cells[1, 5].Value = "Tagged Date";
                    rptProductLocalization.Cells[1, 5].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    rptProductLocalization.Cells[1, 5].Style.Fill.BackgroundColor.SetColor(headerColor);
                    rptProductLocalization.Cells[1, 5].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Cells[1, 5].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    rptProductLocalization.Column(5).Width = 30;

                    int rowNumber = 2;

                    List<string> regions = new List<string>();

                    for (int dataIndex = 0; dataIndex < missingSubassemblyNumbersData.Length; dataIndex++)
                    {
                        rptProductLocalization.Cells[rowNumber, 1].Value = missingSubassemblyNumbersData[dataIndex].Id;
                        rptProductLocalization.Cells[rowNumber, 2].Value = missingSubassemblyNumbersData[dataIndex].Product;
                        rptProductLocalization.Cells[rowNumber, 3].Value = missingSubassemblyNumbersData[dataIndex].Component;
                        rptProductLocalization.Cells[rowNumber, 4].Value = missingSubassemblyNumbersData[dataIndex].BusinessSegment;
                        rptProductLocalization.Cells[rowNumber, 5].Value = missingSubassemblyNumbersData[dataIndex].Created;
                        rowNumber = rowNumber + 1;
                    }
                }
                package.SaveAs(stream);
                fileName = "MissingSubAssembly.xlsx";
                contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                stream.Position = 0;
            }
            return File(stream, contentType, fileName);
        }
        #endregion

        #region  Get User Identity for CM, PC, PhWeb or Marketing Impersonate ID
        int GetCurrentUserIdOrCmPcPhWebMktImpersonateID()
        {
            int impersonateId;

            impersonateId = GetCmPcPhWebMktImpersonateID();

            if (impersonateId != 0)
            {
                return impersonateId;
            }
            else
            {
                if (CurrentUserProfile.ImpersonateId.Value != 0)
                    return CurrentUserProfile.ImpersonateId.Value;
                else
                    return CurrentUserProfile.UserId;
            }
        }

        int GetCmPcPhWebMktImpersonateID()
        {
            int impersonateId;

            impersonateId = 0;

            if (CurrentUserProfile.CMImpersonate.HasValue && CurrentUserProfile.CMImpersonate.Value != 0)
            {
                impersonateId = CurrentUserProfile.CMImpersonate.Value;
            }
            if (CurrentUserProfile.PCImpersonate.HasValue && CurrentUserProfile.PCImpersonate.Value != 0)
            {
                impersonateId = CurrentUserProfile.PCImpersonate.Value;
            }
            if (CurrentUserProfile.PhWebImpersonate.HasValue && CurrentUserProfile.PhWebImpersonate.Value != 0)
            {
                impersonateId = CurrentUserProfile.PhWebImpersonate.Value;
            }
            if (CurrentUserProfile.MarketingImpersonate.HasValue && CurrentUserProfile.MarketingImpersonate.Value != 0)
            {
                impersonateId = CurrentUserProfile.MarketingImpersonate.Value;
            }

            return impersonateId;
        }
        #endregion

        #region Missing Supplier Codes 
        [ProducesResponseType(typeof(MissingSupplierCodesViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingSupplierCodesViewModel[]), 404)]
        [Route("/today/TodayPage/GetMissingSupplierCodes")]
        public async Task<IActionResult> GetMissingSupplierCodes()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var missingSupplierCodes = await this.UnitOfWork.GetMissingSupplierCodesAsync(this.UserIdentity).ConfigureAwait(false);
            if (missingSupplierCodes != null)
            {
                return this.Ok(missingSupplierCodes);
            }
            return this.NotFound();
        }
        #endregion

        #region New Components Released For My Products One 
        [HttpPost]
        [ProducesResponseType(typeof(NewComponentsReleasedForMyProductsOneViewModel[]), 200)]
        [ProducesResponseType(typeof(NewComponentsReleasedForMyProductsOneViewModel[]), 404)]
        [Route("/today/TodayPage/GetNewComponentsReleasedForMyProductsOne")]
        public async Task<IActionResult> GetNewComponentsReleasedForMyProductsOne([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = CurrentUserProfile.UserId;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 7274;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var newComponentsReleasedForMyProductsOne = await this.UnitOfWork.GetNewComponentsReleasedForMyProductsOneAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (newComponentsReleasedForMyProductsOne != null)
            {
                return this.Ok(newComponentsReleasedForMyProductsOne);
            }
            return this.NotFound();
        }
        #endregion

        #region Component Name Change Linked To AV 
        [ProducesResponseType(typeof(ComponentNameChangeLinkedToAVViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentNameChangeLinkedToAVViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentNameChangeLinkedToAV")]
        public async Task<IActionResult> GetComponentNameChangeLinkedToAV()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 13114;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 13114;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var componentNameChangeLinkedToAV = await this.UnitOfWork.GetComponentNameChangeLinkedToAVAsync(this.UserIdentity).ConfigureAwait(false);
            if (componentNameChangeLinkedToAV != null)
            {
                if (componentNameChangeLinkedToAV.Length > 0)
                {
                    componentNameChangeLinkedToAV[0].UserId = this.UserIdentity;
                }
                return this.Ok(componentNameChangeLinkedToAV);
            }
            return this.NotFound();
        }
        #endregion

        #region  Application Errors Outstanding
        [ProducesResponseType(typeof(ApplicationErrorViewModel[]), 200)]
        [ProducesResponseType(typeof(ApplicationErrorViewModel[]), 404)]
        [Route("/today/TodayPage/GetApplicationErrorsOutstanding")]
        public async Task<IActionResult> GetApplicationErrorsOutstanding()
        {
            var applicationErrorsOutstanding = await this.UnitOfWork.GetApplicationErrorsOutstandingAsync().ConfigureAwait(false);
            if (applicationErrorsOutstanding != null)
            {
                return this.Ok(applicationErrorsOutstanding);
            }
            return this.NotFound();
        }
        #endregion

        #region Component Missing SubAssembly Or KitNumber
        [ProducesResponseType(typeof(ComponentMissingSubAssemblyOrKitNumberViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentMissingSubAssemblyOrKitNumberViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentsMissingSubAssemblyOrKitNumber")]
        public async Task<IActionResult> GetComponentsMissingSubAssemblyOrKitNumber()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3121;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3121;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var componentMissingSubAssemblyOrKitNumber = await this.UnitOfWork.GetComponentsMissingSubAssemblyOrKitNumberAsync(this.UserIdentity).ConfigureAwait(false);
            if (componentMissingSubAssemblyOrKitNumber != null)
            {
                return this.Ok(componentMissingSubAssemblyOrKitNumber);
            }
            return this.NotFound();
        }
        #endregion

        #region Component Alerts
        [HttpGet]
        [ProducesResponseType(typeof(ComponentPassedReleaseDateViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentPassedReleaseDateViewModel[]), 400)]
        [Route("/today/TodayPage/GetComponentsPassedPlannedReleaseDate/")]
        public async Task<IActionResult> GetComponentsPassedPlannedReleaseDate()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 982;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 982;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var componentsPassedPlannedReleaseDate = await this.UnitOfWork.GetComponentsPassedPlannedReleaseDateAsync(this.UserIdentity).ConfigureAwait(false);
            if (componentsPassedPlannedReleaseDate != null)
            {
                return this.Ok(componentsPassedPlannedReleaseDate);
            }
            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(CoreTeamWorkingListViewModel[]), 200)]
        [ProducesResponseType(typeof(CoreTeamWorkingListViewModel[]), 400)]
        [Route("/today/TodayPage/GetCoreTeamWorks/")]
        public async Task<IActionResult> GetCoreTeamWorks()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 5469;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 5469;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var coreTeamWorkings = await this.UnitOfWork.GetCoreTeamWorkingListAsync(this.UserIdentity).ConfigureAwait(false);
            if (coreTeamWorkings != null)
            {
                return this.Ok(coreTeamWorkings);
            }
            return this.NotFound();
        }
        #endregion

        #region EngineeringDevelopmentWorkingList
        [ProducesResponseType(typeof(EngineeringDevelopmentWorkingListViewModel[]), 200)]
        [ProducesResponseType(typeof(EngineeringDevelopmentWorkingListViewModel[]), 404)]
        [Route("/today/TodayPage/GetEngineeringDevelopmentWorks")]
        public async Task<IActionResult> GetEngineeringDevelopmentWorks()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            string state = "Eng. Development";
            var engineeringDevelopmentWorks = await this.UnitOfWork.GetEngineeringDevelopmentWorkingListAsync(state, this.UserIdentity).ConfigureAwait(false);
            if (engineeringDevelopmentWorks != null)
            {
                return this.Ok(engineeringDevelopmentWorks);
            }
            return this.NotFound();
        }
        #endregion

        #region Expired Pilot Schedule Dates
        [HttpGet]
        [ProducesResponseType(typeof(ExpiredPilotScheduleDatesViewModel[]), 200)]
        [ProducesResponseType(typeof(ExpiredPilotScheduleDatesViewModel[]), 400)]
        [Route("/today/TodayPage/GetExpiredPilotScheduleDates/")]
        public async Task<IActionResult> GetExpiredPilotScheduleDates()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3108;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3108;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var expiredPilotScheduleDates = await this.UnitOfWork.GetExpiredPilotScheduleDatesAsync(this.UserIdentity).ConfigureAwait(false);
            if (expiredPilotScheduleDates != null)
            {
                return this.Ok(expiredPilotScheduleDates);
            }
            return this.NotFound();
        }
        #endregion

        #region  Missing Service Subassembly Numbers
        [HttpPost]
        [ProducesResponseType(typeof(MissingServiceSubassemblyNumbersViewModel[]), 200)]
        [ProducesResponseType(typeof(MissingServiceSubassemblyNumbersViewModel[]), 404)]
        [Route("/today/TodayPage/GetMissingServiceSubassemblyNumbers")]
        public async Task<IActionResult> GetMissingServiceSubassemblyNumbers([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var missingServiceSubassemblyNumbers = await this.UnitOfWork.GetMissingServiceSubassemblyNumbersAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (missingServiceSubassemblyNumbers != null)
            {
                if (missingServiceSubassemblyNumbers.Length > 0)
                {
                    missingServiceSubassemblyNumbers[0].UserId = this.UserIdentity;
                }
            }
            if (missingServiceSubassemblyNumbers != null)
            {
                return this.Ok(missingServiceSubassemblyNumbers);
            }
            return this.NotFound();
        }
        #endregion

        #region Error Transmitting Files to Preinstall Server
        [HttpGet]
        [ProducesResponseType(typeof(ErrorTransmittingFilestoPreinstallServerViewModel[]), 200)]
        [ProducesResponseType(typeof(ErrorTransmittingFilestoPreinstallServerViewModel[]), 400)]
        [Route("/today/TodayPage/GetErrorTransmittingFilestoPreinstallServer/")]
        public async Task<IActionResult> GetErrorTransmittingFilestoPreinstallServer()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 4967;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 4967;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var errorTransmittingFilestoPreinstallServer = await this.UnitOfWork.GetErrorTransmittingFilestoPreinstallServerAsync(this.UserIdentity).ConfigureAwait(false);
            if (errorTransmittingFilestoPreinstallServer != null)
            {
                return this.Ok(errorTransmittingFilestoPreinstallServer);
            }
            return this.NotFound();
        }
        #endregion

        #region Image Tab Change to Localization (Pulsar Product) 
        [HttpGet]
        [ProducesResponseType(typeof(ImageTabChangetoLocalizationViewModel[]), 200)]
        [ProducesResponseType(typeof(ImageTabChangetoLocalizationViewModel[]), 400)]
        [Route("/today/TodayPage/GetImageTabChangeToLocalizations/")]
        public async Task<IActionResult> GetImageTabChangeToLocalizations()
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 4654;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 4654;
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var imageTabChangetoLocalization = await this.UnitOfWork.GetImageTabChangetoLocalizationAsync(this.UserIdentity, this.CurrentUserProfile.UserName).ConfigureAwait(false);
            if (imageTabChangetoLocalization != null)
            {
                return this.Ok(imageTabChangetoLocalization);
            }
            return this.NotFound();
        }
        #endregion

        #region Component In Test ODM Lead
        [HttpPost]
        [ProducesResponseType(typeof(ComponentInTestODMLeadViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentInTestODMLeadViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentInTestOdmLeads")]
        public async Task<IActionResult> GetComponentInTestOdmLeads([FromBody]PaginationModel paginationInfo)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 20584;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 20584;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var componentInTestOdmLeads = await this.UnitOfWork.GetComponentInTestODMLeadAsync(this.UserIdentity, paginationInfo).ConfigureAwait(false);//this.DeliverableIssueService.GetAllOpenItemsIOwn(employeeId, paginationInfo);
            if (componentInTestOdmLeads != null)
            {
                return this.Ok(componentInTestOdmLeads);
            }
            return this.NotFound();
        }
        #endregion

        #region Component In Test SE Lead
        [HttpPost]
        [ProducesResponseType(typeof(ComponentInTestSELeadViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentInTestSELeadViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentsInTestSELead")]
        public async Task<IActionResult> GetComponentsInTestSELead([FromBody]PaginationModel paginationInfo)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3813;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3813;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var componentInTestSELeads = await this.UnitOfWork.GetComponentInTestSELeadAsync(this.UserIdentity, paginationInfo).ConfigureAwait(false);//this.DeliverableIssueService.GetAllOpenItemsIOwn(employeeId, paginationInfo);
            if (componentInTestSELeads != null)
            {
                return this.Ok(componentInTestSELeads);
            }
            return this.NotFound();
        }
        #endregion

        #region Component In Test WWAN Lead
        [HttpPost]
        [ProducesResponseType(typeof(ComponentInTestWWanLeadViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentInTestWWanLeadViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentsInTestWwanLeads")]
        public async Task<IActionResult> GetComponentsInTestWwanLeads([FromBody]PaginationModel paginationInfo)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 3168;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 3168;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var componentInTestWwanLeads = await this.UnitOfWork.GetComponentInTestWWANLeadAsync(this.UserIdentity, paginationInfo).ConfigureAwait(false);
            if (componentInTestWwanLeads != null)
            {
                return this.Ok(componentInTestWwanLeads);
            }
            return this.NotFound();
        }
        #endregion

        #region My Product Alerts
        [HttpGet]
        [ProducesResponseType(typeof(FeatureRemovedFromPRLViewModel[]), 200)]
        [ProducesResponseType(typeof(FeatureRemovedFromPRLViewModel[]), 400)]
        [Route("/today/TodayPage/GetFeaturesRemovedFromPrl/")]
        public async Task<IActionResult> GetFeaturesRemovedFromPrl()
        {
            string userName = string.Empty;
            if (this.ApplicationMode == xUnitTesting)
            {
                userName = "Johnson, Jeffrey A";
                this.UserIdentity = 685;
            }
            else if (this.ApplicationMode == localTesting)
            {
                userName = "Johnson, Jeffrey A";
                this.UserIdentity = 685;
            }
            else
            {
                userName = this.CurrentUserProfile.UserName;
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            }
            var featureRemovedFromPrl = await this.UnitOfWork.GetFeatureRemovedFromPRLAsync(this.UserIdentity, userName).ConfigureAwait(false);
            if (featureRemovedFromPrl != null)
            {
                return this.Ok(featureRemovedFromPrl);
            }
            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 400)]
        [Route("/today/TodayPage/UpdateFeatureActionStatus/")]
        public async Task<IActionResult> UpdateFeatureActionStatus([FromBody]FeatureRemovedFromPRLViewModel featureRemovedFromPRLViewModel)
        {
            var status = await this.UnitOfWork.TryUpdateFeatureActionStatusAsync(featureRemovedFromPRLViewModel).ConfigureAwait(false);
            return this.Ok(status);
        }
        #endregion

        #region ComponentEndOfLifeDateExpired
        [HttpPost]
        [ProducesResponseType(typeof(ComponentEndOfLifeDateExpiredViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentEndOfLifeDateExpiredViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentsEndOfLifeDateExpired")]
        public async Task<IActionResult> GetComponentsEndOfLifeDateExpired([FromBody]PaginationModel pagination)
        {
            var serviceCommodityManager = CurrentUserProfile.ServiceCommodityManager;
            var procurementEngineer = CurrentUserProfile.ProcurementEngineer;
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 7498;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 7498;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var componentEndOfLifeDateExpired = await this.UnitOfWork.GetComponentEndOfLifeDateExpiredAsync(this.UserIdentity, pagination, serviceCommodityManager, procurementEngineer).ConfigureAwait(false);
            if (componentEndOfLifeDateExpired != null)
            {
                return this.Ok(componentEndOfLifeDateExpired);
            }
            return this.NotFound();
        }
        #endregion

        #region Hardware Components With No Part Number
        [HttpPost]
        [ProducesResponseType(typeof(HardwareComponentsWithNoPartNumberViewModel[]), 200)]
        [ProducesResponseType(typeof(HardwareComponentsWithNoPartNumberViewModel[]), 404)]
        [Route("/today/TodayPage/GetHardwareComponentsWithNoPartNumber")]
        public async Task<IActionResult> GetHardwareComponentsWithNoPartNumber([FromBody]PaginationModel pagination)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 2245;
            }
            else
            {
                this.UserIdentity = GetImpersonateIdOrUserId();
            }
            var hardwareComponentsWithNoPartNumber = await this.UnitOfWork.GetHardwareComponentsWithNoPartNumberAsync(this.UserIdentity, pagination).ConfigureAwait(false);
            if (hardwareComponentsWithNoPartNumber != null)
            {
                return this.Ok(hardwareComponentsWithNoPartNumber);
            }
            return this.NotFound();
        }
        #endregion

        #region Lead Product Synchronization
        [HttpPost]
        [ProducesResponseType(typeof(LeadProductDiscrepenciesViewModel[]), 200)]
        [ProducesResponseType(typeof(LeadProductDiscrepenciesViewModel[]), 404)]
        [Route("/today/TodayPage/GetLeadProductDiscrepencies/{leadProductId?}")]
        public async Task<IActionResult> GetLeadProductDiscrepencies([FromBody]PaginationModel paginationInfo, string leadProductId = "")
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 14109;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 14109;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            int reportId = 1;
            if (CurrentUserProfile.SepmCount > 0 || (CurrentUserProfile.PreInstall && CurrentUserProfile.WorkGroupId == 15))
            {
                if (CurrentUserProfile.SepmCount > 0 && CurrentUserProfile.PreInstall)
                {
                    reportId = 1;
                }
                else if (CurrentUserProfile.SepmCount > 0)
                {
                    reportId = 2;
                }
            }
            var leadProductDiscrepencies = await this.UnitOfWork.GetLeadProductDiscrepenciesAsync(this.UserIdentity, reportId, paginationInfo, leadProductId).ConfigureAwait(false);//this.DeliverableIssueService.GetAllOpenItemsIOwn(employeeId, paginationInfo);
            if (leadProductDiscrepencies != null)
            {
                if (leadProductDiscrepencies.Length > 0)
                {
                    leadProductDiscrepencies[0].UserId = this.UserIdentity;
                }
                return this.Ok(leadProductDiscrepencies);
            }
            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(LeadProductDiscrepenciesViewModel[]), 200)]
        [ProducesResponseType(typeof(LeadProductDiscrepenciesViewModel[]), 404)]
        [Route("/today/TodayPage/GetLeadProductDiscrepenciesProducts/{leadProductId?}")]
        public async Task<IActionResult> GetLeadProductDiscrepenciesProducts(string leadProductId = "")
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 14109;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 14109;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            PaginationModel paginationInfo = new PaginationModel();
            int report = 1;
            if (CurrentUserProfile.SepmCount > 0 && CurrentUserProfile.PreInstall == true)
            {
                report = 1;
            }
            else if (CurrentUserProfile.SepmCount > 0)
            {
                report = 2;
            }
            else
            {
                report = 1;
            }
            var leadProductDiscrepencies = await this.UnitOfWork.GetLeadProductListDiscrepenciesSummaryAsync(this.UserIdentity, report, paginationInfo, leadProductId).ConfigureAwait(false);
            if (leadProductDiscrepencies != null)
            {
                return this.Ok(leadProductDiscrepencies);
            }
            return this.NotFound();
        }
        #endregion

        #region New Components Released Summary
        [ProducesResponseType(typeof(LeadProductDiscrepenciesViewModel[]), 200)]
        [ProducesResponseType(typeof(LeadProductDiscrepenciesViewModel[]), 404)]
        [Route("/today/TodayPage/GetNewComponentsReleasedSummary/{productId?}")]
        public async Task<IActionResult> GetNewComponentsReleasedSummary(string productId = "")
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 15844;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 15844;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            var newComponentsReleasedSummary = await this.UnitOfWork.GetNewComponentsReleasedSummaryAsync(CurrentUserProfile.SepmCount, CurrentUserProfile.PreInstall, CurrentUserProfile.WorkGroupId, this.UserIdentity, productId).ConfigureAwait(false);
            if (newComponentsReleasedSummary != null)
            {
                return this.Ok(newComponentsReleasedSummary);
            }
            return this.NotFound();
        }
        #endregion

        #region Component In Functional Test
        [HttpPost]
        [ProducesResponseType(typeof(ComponentsInFunctionalTestViewModel[]), 200)]
        [ProducesResponseType(typeof(ComponentsInFunctionalTestViewModel[]), 404)]
        [Route("/today/TodayPage/GetComponentsInFunctionalTest")]
        public async Task<IActionResult> GetComponentsInFunctionalTest([FromBody]PaginationModel pagination)
        {
            var componentInFunctionalTest = await this.UnitOfWork.GetComponentInFunctionalTestAsync(CurrentUserProfile.LoginAuthName, CurrentUserProfile.LoginDomain, pagination).ConfigureAwait(false);
            if (componentInFunctionalTest != null)
            {
                return this.Ok(componentInFunctionalTest);
            }
            return this.NotFound();
        }
        #endregion

        #region New Component Released
        [ProducesResponseType(typeof(NewComponentsReleasedViewModel[]), 200)]
        [ProducesResponseType(typeof(NewComponentsReleasedViewModel[]), 404)]
        [Route("/today/TodayPage/GetNewComponentsReleased/{productId?}")]
        public async Task<IActionResult> GetNewComponentsReleased([FromBody]PaginationModel pagination, int? productId)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                this.UserIdentity = 15844;
            }
            else if (this.ApplicationMode == localTesting)
            {
                this.UserIdentity = 15844;
            }
            else
            {
                this.UserIdentity = GetPmIdOrImpersonateIdOrUserId();
            }
            if (productId == 0)
            {
                productId = null;
            }
            var newComponentsReleased = await this.UnitOfWork.GetNewComponentsReleasedAsync(CurrentUserProfile.SepmCount, CurrentUserProfile.PreInstall, CurrentUserProfile.WorkGroupId, this.UserIdentity, productId, pagination).ConfigureAwait(false);
            if (newComponentsReleased != null)
            {
                return this.Ok(newComponentsReleased);
            }
            return this.NotFound();
        }
        #endregion

        #region Get the User Browser Details
        [HttpGet]
        [Route("/today/TodayPage/GetUserBrowser/")]
        public async Task<IActionResult> GetUserBrowser()
        {
            string strMyBrowser = CurrentUserProfile.UserBrowser;
            string strBrowserWarning = "";
            bool compatibilityMode = false;
            if (strMyBrowser.IndexOf("Trident/7.0") > -1)
            {
                if (strMyBrowser.IndexOf("MSIE") > 0)
                {
                    if (strMyBrowser.IndexOf("compatible") > 0)
                    {
                        compatibilityMode = true;
                    }
                    else
                    {
                        compatibilityMode = false;
                    }
                }
                else
                {
                    compatibilityMode = false;
                }
            }
            else if (strMyBrowser.IndexOf("Trident/6.0") > -1)
            {
                if (strMyBrowser.IndexOf("MSIE 7.0") > -1)
                {
                    compatibilityMode = true;
                }
                else
                {
                    compatibilityMode = false;
                }
            }
            else if (strMyBrowser.IndexOf("Trident/5.0") > -1)
            {
                if (strMyBrowser.IndexOf("MSIE 7.0") > -1)
                {
                    compatibilityMode = true;
                }
                else
                {
                    compatibilityMode = false;
                }
            }
            else
            {
                compatibilityMode = false;
            }
            if (!compatibilityMode)
            {
                strBrowserWarning = "IE 11 with Enterprise Mode is the only Internet Explorer version supported now by IT and Pulsar. Please run it in Compatibility View.";
            }

            string result = await Task<string>.Run(() => strBrowserWarning);
            return this.Json(result);
        }
        #endregion

        #region Bulletins List
        [HttpGet]
        [ProducesResponseType(typeof(BulletinsViewModel), 200)]
        [ProducesResponseType(typeof(BulletinsViewModel), 404)]
        [Route("/today/TodayPage/GetBulletins/")]
        public async Task<IActionResult> GetBulletins()
        {
            var bulletins = await this.UnitOfWork.GetBulletinsAsync().ConfigureAwait(false);
            if (bulletins != null)
            {
                return this.Ok(bulletins);
            }
            return this.NotFound();
        }
        #endregion

        #region TodayPageUserSubsectionConfig
        [HttpGet]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("/today/TodayPage/UpsertTodayPageUserSubsectionConfig/")]
        public async Task<IActionResult> UpsertTodayPageUserSubsectionConfig(string SubSectionIds, int? defaultWorkProjectId)
        {
            this.UserIdentity = GetImpersonateIdOrUserId();
            var status = await this.UnitOfWork.UpsertTodayPageUserSubsectionConfigAsync(this.UserIdentity, SubSectionIds, defaultWorkProjectId).ConfigureAwait(false);
            return this.Json(status);
        }

        #endregion

        #region Today Page Subsection Configuration
        [HttpGet]
        [Route("/today/TodayPage/GetTodayPageSubsectionConfig/")]
        public async Task<IActionResult> GetTodayPageSubsectionConfig()
        {
            UserPrivilegeModel userPrivilege = new UserPrivilegeModel();
            string productsInFavourites = CurrentUserProfile.Favourites;
            userPrivilege.UserId = CurrentUserProfile.ImpersonateId.Value != 0 ? CurrentUserProfile.ImpersonateId.Value : CurrentUserProfile.UserId;
            userPrivilege.CurrentUserId = CurrentUserProfile.OriginalUserId;
            userPrivilege.Email = CurrentUserProfile.Email;
            userPrivilege.UserName = CurrentUserProfile.LoginAuthName;
            userPrivilege.DomainName = CurrentUserProfile.LoginDomain;
            userPrivilege.PMImpersonateId = (int)CurrentUserProfile.PMImpersonate;
            userPrivilege.ImpersonateId = (int)CurrentUserProfile.ImpersonateId;
            userPrivilege.CMPcPhWebMktImpersonateId = this.GetCmPcPhWebMktImpersonateID();
            userPrivilege.ProductIdList = productsInFavourites.Replace("P", "").Replace(",", "_");
            userPrivilege.StartDate = DateTime.Now.AddDays(-7);
            userPrivilege.TabIndex = 0;
            var todayPageSubsectionsconfig = await this.UnitOfWork.GetTodayPageSubsectionConfig(userPrivilege, this.CurrentUserProfile.LoginAuthName, this.CurrentUserProfile.LoginDomain).ConfigureAwait(false);
            return View(todayPageSubsectionsconfig);
        }
        #endregion

        #region SupportIssueDropDownValueFill
        [ProducesResponseType(typeof(SupportIssueTypeViewModel[]), 200)]
        [ProducesResponseType(typeof(SupportIssueTypeViewModel[]), 404)]
        [Route("/today/TodayPage/GetAllSupportIssueTypes")]
        public async Task<IActionResult> GetAllSupportIssueTypes()
        {
            var supportIssueTypes = await this.UnitOfWork.GetAllSupportIssueTypesAsync().ConfigureAwait(false);
            if (supportIssueTypes != null)
            {
                return this.Ok(supportIssueTypes);
            }
            return this.NotFound();
        }

        public async Task<IActionResult> GetAllSupportIssueStatus()
        {
            var supportIssueStatusList = await this.UnitOfWork.GetAllSupportIssueStatusAsync().ConfigureAwait(false);
            return this.Json(supportIssueStatusList);
        }

        public async Task<IActionResult> GetAllSupportProjects()
        {
            var supportProjectsList = await this.UnitOfWork.GetAllSupportProjectsAsync();
            return this.Json(supportProjectsList);
        }

        public async Task<IActionResult> GetAllSupportAdmin()
        {
            var supportAdminList = await this.UnitOfWork.GetAllSupportAdminsAsync().ConfigureAwait(false);
            return this.Json(supportAdminList);
        }

        public async Task<IActionResult> GetAllSupportCategories(int projectID)
        {
            var supportCategoryList = await this.UnitOfWork.GetAllSupportCategoriesAsync(projectID).ConfigureAwait(false);
            return this.Json(supportCategoryList);
        }
        #endregion

        #region Ticket
        [HttpGet]
        [ProducesResponseType(typeof(SupportTicketViewModel), 200)]
        [ProducesResponseType(typeof(SupportTicketViewModel), 404)]
        [Route("/today/TodayPage/Ticket/{id}")]
        public async Task<IActionResult> Ticket(int id)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                id = 2233;
            }
            else if (this.ApplicationMode == localTesting)
            {
                id = 2333;
            }
            var TicketInfo = await this.UnitOfWork.GetSupportTicketInfoAsync(id).ConfigureAwait(false);
            return Json(TicketInfo);
        }

        [HttpGet]
        [ProducesResponseType(typeof(SupportTicketViewModel), 200)]
        [ProducesResponseType(typeof(SupportTicketViewModel), 404)]
        [Route("/today/TodayPage/GetTicketInfo/{id}")]
        public async Task<IActionResult> GetTicketInfo(int id)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                id = 2233;
            }
            else if (this.ApplicationMode == localTesting)
            {
                id = 2333;
            }
            var TicketInfo = await this.UnitOfWork.GetSupportTicketInfoAsync(id, this.CurrentUserProfile.PulsarSystemAdmin).ConfigureAwait(false);
            TicketInfo.PulsarAdminorDeveloper = this.CurrentUserProfile.PulsarSystemAdmin;
            return View("Ticket", TicketInfo);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpdateTicket([FromBody]SupportTicketViewModel supportTicketViewModel, int? copyMe, string copyTeam)
        {
            supportTicketViewModel.CopyMe = copyMe == 1 ? true : false;
            supportTicketViewModel.CopyTeam = copyTeam == "on" ? true : false;
            var status = await this.UnitOfWork.TryUpdateSupportIssueTicketAsync(supportTicketViewModel, CurrentUserProfile.Email).ConfigureAwait(false);
            return Json(status);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpdateTicketInfo([FromBody]SupportTicketViewModel supportTicketViewModel)
        {
            //supportTicketViewModel.CopyMe = copyMe == 1 ? true : false;
            //supportTicketViewModel.CopyTeam = copyTeam == 1 ? true : false;
            var status = await this.UnitOfWork.TryUpdateSupportTicketAsync(supportTicketViewModel, CurrentUserProfile.Email).ConfigureAwait(false);
            return Json(status);
        }
        #endregion

        #region Get update Schedule Milestone
        [HttpGet]
        [ProducesResponseType(typeof(UpdateScheduleMilestoneViewModel), 200)]
        [ProducesResponseType(typeof(UpdateScheduleMilestoneViewModel), 404)]
        [Route("/today/TodayPage/GetUpdateScheduleMilestone/{scheduleDataId?}")]
        public async Task<IActionResult> GetUpdateScheduleMilestone(int? scheduleDataId)
        {
            var updateScheduleMilestone = await this.UnitOfWork.GetUpdateScheduleMilestoneAsync(Convert.ToInt32(scheduleDataId), this.CurrentUserProfile.ImpersonateId).ConfigureAwait(false);
            if (updateScheduleMilestone != null)
            {
                return this.Ok(updateScheduleMilestone);
            }
            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpdateScheduleMilestoneData([FromBody]UpdateScheduleMilestoneViewModel updateScheduleMilestoneViewModel)
        {
            var status = await this.UnitOfWork.UpdateScheduleMilestoneDataAsync(updateScheduleMilestoneViewModel, this.CurrentUserProfile.LoginAuthName).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region Ticket Preview
        [HttpGet]
        [ProducesResponseType(typeof(SupportTicketViewModel), 200)]
        [ProducesResponseType(typeof(SupportTicketViewModel), 404)]
        [Route("/today/TodayPage/TicketPreview/{id}")]
        public async Task<IActionResult> TicketPreview(int id)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                id = 2233;
            }
            else if (this.ApplicationMode == localTesting)
            {
                id = 2333;
            }
            var TicketInfo = await this.UnitOfWork.GetTicketPreviewAsync(id).ConfigureAwait(false);
            return Json(TicketInfo);
        }

        #endregion

        #region Today Action
        [HttpGet]
        [ProducesResponseType(typeof(TodayActionViewModel), 200)]
        [ProducesResponseType(typeof(TodayActionViewModel), 404)]
        [Route("/today/TodayPage/GetTodayAction/{id}")]
        public async Task<IActionResult> GetTodayAction(int id)
        {
            if (this.ApplicationMode == xUnitTesting)
            {
                id = 2233;
            }
            else if (this.ApplicationMode == localTesting)
            {
                id = 2333;
            }
            var TodayActionInfo = await this.UnitOfWork.GetTodayActionAsync(id).ConfigureAwait(false);
            return Json(TodayActionInfo);
        }
        #endregion

        #region Create Update AV
        [HttpPost]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 404)]
        [Route("/today/TodayPage/CreateAV/")]
        public async Task<IActionResult> CreateAV(int userId, string function, int avCreateID, int notActionable, int pulsar, int categoryID, string avCreateIDs)
        {
            this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            string content = await this.UnitOfWork.CreateAVAsync(this.UserIdentity, function, avCreateID, notActionable, pulsar, categoryID, avCreateIDs).ConfigureAwait(false);
            return this.Content(content);
        }

        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 404)]
        [Route("/today/TodayPage/UpdateAV/")]
        [HttpPost]
        public async Task<IActionResult> UpdateAV(int userId, string function, int avUpdateID, int notActionable, string avDetailID, int descriptionType)
        {
            this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateID();
            string content = await this.UnitOfWork.UpdateAVAsync(this.UserIdentity, function, avUpdateID, notActionable, avDetailID, descriptionType).ConfigureAwait(false);
            return this.Content(content);
        }
        #endregion Create Update AV

        #region Update DCRNo
        [HttpPost]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 404)]
        [Route("/today/TodayPage/UpdateDCRNo/")]
        public async Task<IActionResult> UpdateDCRNo(int userId, string function, int avDetailD, int dCRNo, int productBrandID)
        {
            string content = await this.UnitOfWork.UpdateDCRNoAsync(function, dCRNo, avDetailD, productBrandID).ConfigureAwait(false);
            return this.Content(content);
        }
        #endregion Update DCRNo

        #region Update Marketing Av Detail
        [HttpPost]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 404)]
        [Route("/today/TodayPage/UpdateMarketingAvDetail/")]
        public async Task<IActionResult> UpdateMarketingAvDetail(int userId, string function, int aVDetailID, int currentUser, DateTime discontinueDate, DateTime rTPDate, int bID)
        {
            string content = await this.UnitOfWork.UpdateMarketingAvDetailAsync(function, aVDetailID, currentUser, discontinueDate, rTPDate, bID).ConfigureAwait(false);
            return this.Content(content);
        }
        #endregion Update Marketing Av Detail

        #region Update PH Web AV Data
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/today/TodayPage/UpdatePHwebAVActionItemsLegacyProduct/")]
        public async Task<IActionResult> UpdatePHwebAVActionItemsLegacyProduct(UpdatePHWebAvActionItemViewModel phWebAVData)
        {
            var status = await this.UnitOfWork.TryUpdatePHwebAVActionItemsLegacyProductAsync(phWebAVData, this.CurrentUserProfile.UserName, this.CurrentUserProfile.Email).ConfigureAwait(false);
            return this.Ok(status);
        }
        #endregion Update PH Web AV Data

        #region Update SCMRejectedAVsActionItemComplete
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/today/TodayPage/UpdateSCMRejectedAVsActionItemComplete/{aVPHwebRejectionItemID}/{updatedBy}")]
        public async Task<IActionResult> UpdateSCMRejectedAVsActionItemComplete(int aVPHwebRejectionItemID, string updatedBy)
        {
            var status = await this.UnitOfWork.TryUpdateSCMRejectedAVsActionItemCompleteAsync(aVPHwebRejectionItemID, updatedBy).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region Pulsar Support
        // <summary>
        [HttpGet]
        [Route("/today/TodayPage/GetSupportDetails")]
        public async Task<IActionResult> GetSupportDetails(string tab, string ticketSearch, string ticketOwner, string ticketType, string ticketStatus, string ticketCategory, string ticketProject, string ticketTime, string ticketUserPriority, string ticketRootCause, string ticketPrevention, string articleOwner, string articleStatus, string articleProject, string articleCategory, string categoryOwner, string categoryStatus, string categoryProject, bool isTicketReset = false, bool? flag = true)
        {
            SupportViewModel supportDetail = await this.UnitOfWork.GetSupportDetailsAsync(CurrentUserProfile.UserId, ticketSearch, ticketOwner, ticketType, ticketStatus, ticketCategory, ticketProject, ticketTime, ticketUserPriority, ticketRootCause, ticketPrevention, articleOwner, articleStatus, articleProject, articleCategory, categoryOwner, categoryStatus, categoryProject, isTicketReset).ConfigureAwait(false);
            supportDetail.TabTicket = tab == null ? "active" : null;
            supportDetail.TabArticle = tab == "Articles" ? "active" : null;
            supportDetail.TabCategory = tab == "Categories" ? "active" : null;
            supportDetail.Flag = flag;
            supportDetail.PulsarAdminorDeveloper = this.CurrentUserProfile.PulsarSystemAdmin;
            supportDetail.PaginationConfig = new PaginationConfiguration();
            return View(supportDetail);
        }

        // <summary>
        public async Task<JsonResult> GetTicketDetails(string ticketSearch, string ticketOwner, string ticketProject, string ticketCategory, string ticketType, string ticketStatus, string ticketTime, string ticketUserPriority, string ticketRootCause, string ticketPrevention)
        {
            Type ticketData = typeof(TicketPreviewViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, ticketData);
            TicketPreviewViewModel[] ticketDetail = await this.UnitOfWork.GetTicketDetailsAsync(CurrentUserProfile.UserId, ticketSearch, ticketOwner, ticketProject, ticketCategory, ticketType, ticketStatus, ticketTime, ticketUserPriority, ticketRootCause, ticketPrevention, pagination).ConfigureAwait(false);
            var result = new
            {
                recordCountKey = ticketDetail.Length > 0 ? ticketDetail[0].RecordCount.ToString() : "0",
                responseDataKey = "dataList",
                dataList = ticketDetail
            };
            return Json(result, base.JsonSettings);
        }

        [HttpGet]
        [Route("/today/TodayPage/GetTicketDetailsforExcel")]
        public async Task<FileStreamResult> GetTicketDetailsforExcel(string ticketSearch, string ticketOwner, string ticketProject, string ticketCategory, string ticketType, string ticketStatus, string ticketTime, string ticketUserPriority, string ticketRootCause, string ticketPrevention)
        {
            Type ticketData = typeof(TicketPreviewViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, ticketData);
            pagination.PageNo = 0;
            pagination.PageSize = -1;
            TicketPreviewViewModel[] ticketDetail = await this.UnitOfWork.GetTicketDetailsAsync(CurrentUserProfile.UserId, ticketSearch, ticketOwner, ticketProject, ticketCategory, ticketType, ticketStatus, ticketTime, ticketUserPriority, ticketRootCause, ticketPrevention, pagination).ConfigureAwait(false);
            var fileName = "SupportTicket" + ".xlsx";
            var stream = new MemoryStream();
            string contentType = string.Empty;

            //creating Header Row
            using (ExcelPackage package = new ExcelPackage())
            {
                ExcelWorksheet supportWorkSheet = package.Workbook.Worksheets.Add("excelexport");
                using (ExcelRange range = supportWorkSheet.Cells["A1:K1"])
                {
                    System.Drawing.Color bgColor = System.Drawing.ColorTranslator.FromHtml("#C0C0C0");
                    System.Drawing.Color fontColor = System.Drawing.ColorTranslator.FromHtml("#000000");
                    range.Style.Font.Name = "Verdana";
                    range.Style.Font.Size = 9;
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(bgColor);
                    range.Style.Font.Color.SetColor(fontColor);
                    range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
                    range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }
                // headers
                supportWorkSheet.Cells[1, 1].Value = "ID";
                supportWorkSheet.Cells[1, 2].Value = "Project";
                supportWorkSheet.Cells[1, 3].Value = "Category";
                supportWorkSheet.Cells[1, 4].Value = "Submitter";
                supportWorkSheet.Cells[1, 5].Value = "Owner";
                supportWorkSheet.Cells[1, 6].Value = "Status";
                supportWorkSheet.Cells[1, 7].Value = "Age";
                supportWorkSheet.Cells[1, 8].Value = "Last Status Change";
                supportWorkSheet.Cells[1, 9].Value = "Summary";
                supportWorkSheet.Cells[1, 10].Value = "Created Date";
                supportWorkSheet.Cells[1, 11].Value = "Closed Date";
                // Rows
                int startDataRow = 2;
                foreach (var item in ticketDetail)
                {
                    supportWorkSheet.Cells[startDataRow, 1].Value = item.ID;
                    supportWorkSheet.Cells[startDataRow, 2].Value = item.ProjectName;
                    supportWorkSheet.Cells[startDataRow, 3].Value = item.Category;
                    supportWorkSheet.Cells[startDataRow, 4].Value = item.SubmitterName;
                    supportWorkSheet.Cells[startDataRow, 5].Value = item.OwnerName;
                    supportWorkSheet.Cells[startDataRow, 6].Value = item.Status;
                    supportWorkSheet.Cells[startDataRow, 7].Value = item.Age;
                    supportWorkSheet.Cells[startDataRow, 8].Value = item.DataLastUpdated;
                    supportWorkSheet.Cells[startDataRow, 9].Value = item.Summary;
                    supportWorkSheet.Cells[startDataRow, 10].Value = item.DateCreated;
                    supportWorkSheet.Cells[startDataRow, 11].Value = item.DateClosed;
                    startDataRow++;
                }
                using (ExcelRange range = supportWorkSheet.Cells["A2:G" + (startDataRow - 1).ToString()])
                {
                    range.Style.Font.Name = "Verdana";
                    range.Style.Font.Size = 8;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                }
                supportWorkSheet.Cells.AutoFitColumns(); // set autofit all columns based on content
                package.SaveAs(stream);
            }
            contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            stream.Position = 0;
            return File(stream, contentType, fileName);
        }


        public async Task<JsonResult> GetArticleDetails(string articleOwner, string articleStatus, string articleProject, string articleCategory)
        {
            Type articleData = typeof(SupportArticleViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, articleData);
            SupportArticleViewModel[] articleDetail = await this.UnitOfWork.GetArticleDetailsAsync(CurrentUserProfile.UserId, articleOwner, articleStatus, articleProject, articleCategory, pagination).ConfigureAwait(false);
            var result = new
            {
                recordCountKey = articleDetail.Length > 0 ? articleDetail[0].RecordCount.ToString() : "0",
                responseDataKey = "dataList",
                dataList = articleDetail
            };
            return Json(result, base.JsonSettings);
        }

        public async Task<JsonResult> GetCategoryDetails(string categoryOwner, string categoryStatus, string categoryProject)
        {
            Type categoryData = typeof(SupportCategoryViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, categoryData);
            SupportCategoryViewModel[] categoryDetail = await this.UnitOfWork.GetCategoryDetailsAsync(CurrentUserProfile.UserId, categoryOwner, categoryStatus, categoryProject, pagination).ConfigureAwait(false);
            var result = new
            {
                recordCountKey = categoryDetail.Length > 0 ? categoryDetail[0].RecordCount.ToString() : "0",
                responseDataKey = "dataList",
                dataList = categoryDetail
            };
            return Json(result, base.JsonSettings);
        }
        #endregion

        #region User Preference

        [HttpGet]
        [ProducesResponseType(typeof(UserPreferenceModel), 200)]
        [ProducesResponseType(typeof(UserPreferenceModel), 404)]
        [Route("/today/TodayPage/GetUserPreference")]
        public async Task<IActionResult> GetUserPreference()
        {
            var userPreference = await this.UnitOfWork.GetUserPreferenceAsync(CurrentUserProfile.UserId).ConfigureAwait(false);
            return this.Json(userPreference);
        }

        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/today/TodayPage/TryUpdateUserPreference/{isDefaultTab}")]
        public async Task<IActionResult> TryUpdateUserPreference(bool isDefaultTab)
        {
            bool isDefault = await this.UnitOfWork.TryUpdateUserPreferenceAsync(CurrentUserProfile.UserId, isDefaultTab).ConfigureAwait(false);
            return this.Json(isDefault);
        }

        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/today/TodayPage/TryUpdateUserPreferenceDefaultPulsarPlus/{isDefaultPulsarPlus}")]
        public async Task<IActionResult> TryUpdateUserPreferenceDefaultPulsarPlus(bool isDefaultPulsarPlus)
        {
            bool isDefault = await this.UnitOfWork.TryUpdateUserPreferenceDefaultPulsarPlusAsync(CurrentUserProfile.UserId, isDefaultPulsarPlus).ConfigureAwait(false);
            return this.Json(isDefault);
        }
        #endregion

        #region Favorite Tab Sorting

        [HttpGet]
        [ProducesResponseType(typeof(ReOrderViewModel), 200)]
        [ProducesResponseType(typeof(ReOrderViewModel), 404)]
        [Route("/today/TodayPage/GetFavoriteTabSort")]
        public async Task<IActionResult> GetFavoriteTabSort()
        {
            ReOrderViewModel reOrder = await this.UnitOfWork.GetFavoriteTabSortAsync(CurrentUserProfile.UserId, this.CurrentUserProfile.LoginAuthName, this.CurrentUserProfile.LoginDomain).ConfigureAwait(false);
            return this.View("FavoritesTabSort", reOrder);
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/today/TodayPage/UpdateFavorites/{favoitesCount}")]
        public async Task<bool> UpdateFavorites(int favoitesCount, [FromBody]List<FavoritesViewModel> favoritesItem)
        {
            return await this.UnitOfWork.TryUpdateFavoritesAsync(CurrentUserProfile.UserId, favoitesCount, favoritesItem[0].CurrentOrder, favoritesItem[0].RemovedOrder).ConfigureAwait(false);
        }

        #endregion

        #region Update Action Multi Approval
        //[HttpGet]
        //[ProducesResponseType(typeof(string), 200)]
        //[ProducesResponseType(typeof(string), 404)]
        //[Route("/today/TodayPage/UpdateActionMultiApproval/{selectedIds}/{approverStatus}/{approverComments}")]
        [HttpPost]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 404)]
        [Route("/today/TodayPage/UpdateActionMultiApproval/")]
        public async Task<int> UpdateActionMultiApproval(string selectedIds, int approverStatus, string approverComments, string layout = "")
        {
            int content = await this.UnitOfWork.UpdateActionMultiApprovalAsync(selectedIds, approverStatus, CurrentUserProfile, approverComments, layout).ConfigureAwait(false);
            return content;
        }
        #endregion

        #region App Error Main
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/today/TodayPage/AppErrorMain/{Id}/{CopyTo?}")]
        public async Task<IActionResult> AppErrorMain(int id, string copyTo)
        {

            var appicationErrorMain = await this.UnitOfWork.AppErrorMainAsync(id, copyTo, CurrentUserProfile.UserId).ConfigureAwait(false);
            return View("GetAppErrorMain", appicationErrorMain);
        }
        #endregion

        #region Support Category
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/today/TodayPage/SupportCategory/{Id?}")]
        public async Task<IActionResult> SupportCategory(int id)
        {
            var category = await this.UnitOfWork.SupportCategoryAsync(id).ConfigureAwait(false);
            return View("SupportCategory", category);
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/pmview/PmView/UpdateSupportCategory")]
        public async Task UpdateSupportCategory(int id, string name, int supportProjectId, string supportProjectName, int ownerId, bool active, string notificationList, string requiredFields)
        {
            await this.UnitOfWork.UpdateSupportCategoryAsync(id, name, supportProjectId, supportProjectName, ownerId, active, notificationList, requiredFields).ConfigureAwait(false);
        }
        #endregion

        #region Choose Today Page
        [HttpGet]
        [Route("/today/TodayPage/ChooseTodayPage")]
        public ActionResult ChooseTodayPage()
        {
            return this.View("ChooseTodayPage");
        }
        #endregion

        #region UpdateDCRWorkflowStatus
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        //[Route("/today/TodayPage/UpdateDCRWorkflow/{historyId}/{comments}/{dcrId}/{pvId}")]
        [Route("/today/TodayPage/UpdateDCRWorkflow/")]
        public async Task UpdateDCRWorkflow(int historyId, string comments, int dcrId, int pvId)
        {
            var serverName = CurrentUserProfile.LoginDomain;
            await this.UnitOfWork.UpdateDCRWorkflowAsync(historyId, comments, dcrId, pvId, CurrentUserProfile).ConfigureAwait(false);
        }
        #endregion

        #region ExcaliburLandingPage        

        [HttpGet]
        [Route("/today/TodayPage/RedirectLandingPage")]
        public IActionResult RedirectLandingPage()
        {
            //await this.UnitOfWork.RedirectLandingPage(CurrentUserProfile);
            bool loginOK = true;
            int currentUserId;
            int currentUserPartner;
            string currentuser = CurrentUserProfile.LoginDomain + "/" + CurrentUserProfile.LoginAuthName;
            if (currentuser.IndexOf('/') == 0)
            {
                loginOK = false;
            }
            else if (!((currentuser.Substring(0, 13) == "houhpqexcal03")
                || ((currentuser.Substring(0, 13) == "houhpqexcal05")
                || ((currentuser.Substring(0, 13) == "houphqexcal02")
                || ((currentuser.Substring(0, 8) == "americas")
                || ((currentuser.Substring(0, 7) == "atlanta")
                || ((currentuser.Substring(0, 8) == "atlanta2")
                || ((currentuser.Substring(0, 11) == "col-springs")
                || ((currentuser.Substring(0, 4) == "emea")
                || ((currentuser.Substring(0, 11) == "asiapacific")
                || ((currentuser.Substring(0, 7) == "asiapac")
                || ((currentuser.Substring(0, 5) == "boise")
                || ((currentuser.Substring(0, 7) == "europe2")
                || ((currentuser.Substring(0, 7) == "europe1")
                || ((currentuser.Substring(0, 7) == "cpqprod")
                || ((currentuser.Substring(0, 9) == "palo-alto")
                || ((currentuser.Substring(0, 9) == "vancouver")
                || (currentuser.Substring(0, 4).ToLower() == "auth"))))))))))))))))))
            {
                loginOK = false;
            }

            if (loginOK)
            {
                currentUserId = CurrentUserProfile.UserId;
                currentUserPartner = Convert.ToInt32(CurrentUserProfile.PartnerId);
                if (currentUserPartner == 9)
                {
                    //Response.Redirect "./mobilese/modusmain.asp"
                    return Redirect("./mobilese/modusmain.asp");
                }
                if (currentUserId == 0)
                {
                    //Response.Redirect "/pulsar/user/loginfailed"
                    return Redirect("/pulsar/user/loginfailed");
                }
                else
                {
                    if (HttpContext.Request.Query["path"].ToString() == "" || HttpContext.Request.Query["path"].ToString() == "/" || HttpContext.Request.Query["path"].ToString() == "/Excalibur/mobilese/today/today.asp")
                    {
                        return Redirect("../../../pulsarplus");
                    }
                }
            }
            else
            {
                return Redirect("/pulsar/user/loginfailed");
            }
            //return this.View("PulsarLanding");
            return Redirect("");
        }
        #endregion

        #region ApproverStatus
        [HttpGet]
        [Route("today/TodayPage/UpdateApproverStatus/{actionId}/{approvalId?}/{statusId?}")]
        public async Task<JsonResult> UpdateApproverStatus(int actionId, int? approvalId, int? statusId)
        {
            string status = await this.UnitOfWork.UpdateApproverStatusAsync(actionId, approvalId, statusId, CurrentUserProfile.Email).ConfigureAwait(false);
            return Json(status);
        }
        #endregion
    }
}
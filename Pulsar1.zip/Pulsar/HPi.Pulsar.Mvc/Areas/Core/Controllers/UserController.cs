﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Enumerators;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.UnitOfWork.Core.Contracts;
using HPi.Pulsar.UnitOfWork.Core.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HPi.Pulsar.Mvc.Areas.Core.Controllers
{
    [Area("Core")]
    public class UserController : BaseMvcController<IUserUnitOfWork>
    {
        public UserController(IApplicationServices applicationServices, IUserUnitOfWork iUserUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration)
            : base(applicationServices, iUserUnitOfWork, configuration, currentProfile)
        {
            this.currentUserProfile = currentProfile;
        }

        #region Service Properties
        private ICurrentUserProfile currentUserProfile { get; }
        #endregion

        #region Private Properties
        private int userIdentity { get; set; }
        #endregion

        #region ChooseEmployeeDialog
        public async Task<IActionResult> ChooseEmployee(DialogTypeEnum dialogType, int historyId, int productVersionId, int ownerId = 0, int Id = 0, bool isFromMvc = false)
        {
            int currentUserId = GetImpersonateIdOrUserId();
            var chooseEmployee = await this.UnitOfWork.ChooseEmployeeAsync(dialogType, currentUserProfile.ImpersonateId.Value, currentUserProfile.OriginalUserId, currentUserProfile.LoginDomain, currentUserProfile.LoginAuthName, (int)currentUserProfile.PulsarSystemAdmin, currentUserProfile.PMImpersonate.Value, currentUserId, currentUserProfile.CMImpersonate.Value, currentUserProfile.PCImpersonate.Value, currentUserProfile.PhWebImpersonate.Value, currentUserProfile.MarketingImpersonate.Value, historyId, productVersionId).ConfigureAwait(false);
            chooseEmployee.dialogType = dialogType;
            chooseEmployee.OwnerId = ownerId;
            chooseEmployee.Id = Id;
            chooseEmployee.IsFromMvc = isFromMvc;
            return View(chooseEmployee);
        }

        [HttpGet]
        [ProducesResponseType(typeof(IActionResult), 200)]
        [ProducesResponseType(typeof(IActionResult), 404)]
        public async Task<IActionResult> GetEmployees(DialogTypeEnum dialogType, string userNamePattern, int historyId, int productVersionId, int ownerId = 0, int id = 0, string filter = "")
        {
            int currentUserId = GetImpersonateIdOrUserId();
            ChooseEmployeeViewModel impersonationEmployees = await this.UnitOfWork.GetEmployeesAsync(dialogType, userNamePattern, currentUserProfile.OriginalUserId, currentUserProfile.ImpersonateId.Value, (int)currentUserProfile.PulsarSystemAdmin, currentUserProfile.LoginDomain, currentUserProfile.LoginAuthName, currentUserProfile.PMImpersonate.Value, currentUserId, historyId, productVersionId, ownerId, id, filter).ConfigureAwait(false);
            impersonationEmployees.dialogType = dialogType;
            return Json(impersonationEmployees);
        }

        [HttpGet]
        [ProducesResponseType(typeof(IActionResult), 200)]
        [ProducesResponseType(typeof(IActionResult), 404)]
        public async Task<IActionResult> SaveEmployee(DialogTypeEnum dialogType, int impersonateId, int historyId, int productVersionId)
        {
            int currentUserId = GetImpersonateIdOrUserId();
            ChooseEmployeeViewModel impersonationEmployees = await this.UnitOfWork.SaveEmployeeAsync(dialogType, currentUserProfile.OriginalUserId, impersonateId, (int)currentUserProfile.PulsarSystemAdmin, currentUserId, currentUserProfile.LoginAuthName, currentUserProfile.LoginDomain, historyId, productVersionId).ConfigureAwait(false);
            impersonationEmployees.dialogType = dialogType;
            return Json(impersonationEmployees);
        }
        #endregion

        #region Get Employees List for Address Book
        [HttpGet]
        [Route("core/User/AddressBook")]
        public async Task<IActionResult> AddressBook()
        {
            await Task.Delay(10);
            SelectEmployeeViewModel selectEmployeesViewModel = new SelectEmployeeViewModel();

            var addressList = Request.Query["AddressList"];
            var pageName = Request.Query["PageName"];

            selectEmployeesViewModel.SlectedAddressList = addressList;
            selectEmployeesViewModel.PageName = pageName;

            return View(selectEmployeesViewModel);
        }

        [HttpGet]
        [Route("core/User/SelectedEmployees")]
        [ProducesResponseType(typeof(IActionResult), 200)]
        [ProducesResponseType(typeof(IActionResult), 404)]
        public async Task<IActionResult> SelectedEmployees(string userNamePattern)
        {
            SelectEmployeeViewModel selectEmployeesViewModel = await this.UnitOfWork.GetEmployeeListAsync(userNamePattern).ConfigureAwait(false);
            return Json(selectEmployeesViewModel);
        }
        #endregion
    }
}

﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.UnitOfWork.Product.Contracts;
using HPi.Pulsar.UnitOfWork.Product.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HPi.Pulsar.Mvc.Areas.Product.Controllers
{

    [Area("Product")]
    public class DCRWorkflowDefinitionsController : BaseMvcController<IDCRWorkflowDefinitionsUnitOfWork>
    {
        public DCRWorkflowDefinitionsController(IApplicationServices applicationServices, IDCRWorkflowDefinitionsUnitOfWork iDCRWorkflowDefinitionsUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration)
            : base(applicationServices, iDCRWorkflowDefinitionsUnitOfWork, configuration, currentProfile)
        {
            this.CurrentUserProfile = currentProfile;
        }

        #region Service Properties
        public ICurrentUserProfile CurrentUserProfile { get; }
        #endregion

        #region Public Properties
        public int UserIdentity { get; set; }
        #endregion

        #region DCRWorkflowStatus
        [HttpGet]
        [ProducesResponseType(typeof(DCRWorkflowStatusViewModel[]), 200)]
        [ProducesResponseType(typeof(DCRWorkflowStatusViewModel[]), 404)]
        [Route("/product/DCRWorkflowDefinitions/GetDCRWorkflowStatus/{dcrId}/{pvId}/{milestoneComplete}")]
        public async Task<JsonResult> GetDCRWorkflowStatus(int dcrId, int pvId, string milestoneComplete)
        {
            if (this.ApplicationMode == "XUnitTesting")
            {
                this.UserIdentity = 12785;
            }
            else if (this.ApplicationMode == "LocalTesting")
            {
                this.UserIdentity = 12785;//GetCurrentUserIdOrCmPcPhWebMktImpersonateID()
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateId(); //12785;
            }
            var dcrWorkflowStatus = await this.UnitOfWork.GetDCRWorkflowStatus(dcrId, milestoneComplete, pvId, (int)this.UserIdentity).ConfigureAwait(false);
            return this.Json(dcrWorkflowStatus);
        }

        [ProducesResponseType(typeof(DCRWorkflowStatusViewModel[]), 200)]
        [ProducesResponseType(typeof(DCRWorkflowStatusViewModel[]), 404)]
        public async Task<JsonResult> GetDCRWorkflowEmailList(int dcrId, int pvId)
        {
            var dcrEmailList = await this.UnitOfWork.GetDCRWorkflowEmailList(dcrId, pvId).ConfigureAwait(false);
            return this.Json(dcrEmailList);
        }

        [HttpGet]
        [Route("/product/DCRWorkflowDefinitions/TerminateDCRWorkflow/{pvId}")]
        public async Task TerminateDCRWorkflow(int pvId)
        {
            if (this.ApplicationMode == "XUnitTesting")
            {
                this.UserIdentity = 12785;
            }
            else if (this.ApplicationMode == "LocalTesting")
            {
                this.UserIdentity = 12785;//GetCurrentUserIdOrCmPcPhWebMktImpersonateID()
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateId(); //12785;
            }
            await this.UnitOfWork.TerminateDCRWorkflow(pvId, (int)this.UserIdentity).ConfigureAwait(false);
        }
        #endregion

        #region UpdateDCRWorkflowStatus
        [HttpGet]
        [ProducesResponseType(typeof(DCRWorkflowStatusViewModel[]), 200)]
        [ProducesResponseType(typeof(DCRWorkflowStatusViewModel[]), 404)]
        [Route("/product/DCRWorkflowDefinitions/UpdateDCRWorkflowComments/{historyId}/{comments}/{dcrId}/{pvId}")]
        public async Task UpdateDCRWorkflowComments(int historyId, string comments, int dcrId, int pvId)
        {
            var serverName = CurrentUserProfile.LoginDomain;
            await this.UnitOfWork.UpdateDCRWorkflowComments(historyId, comments, dcrId, pvId, serverName).ConfigureAwait(false);
        }
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.UnitOfWork.Product.Contracts;
using HPi.Pulsar.UnitOfWork.Product.ViewModels;
using Infragistics.Web.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace HPi.Pulsar.Mvc.Areas.Product.Controllers
{


    [Area("Product")]
    public class ProductController : BaseMvcController<IProductUnitOfWork>
    {
        private const string hardwareMatrixFile = "HardwareMatrix.xlsx";
        public ProductController(IApplicationServices applicationServices, IProductUnitOfWork iProductUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration, IMemoryCache memoryCache)
            : base(applicationServices, iProductUnitOfWork, configuration, currentProfile)
        {
            this.CurrentUserProfile = currentProfile;
            this.MemoryCache = memoryCache;
        }

        #region Service Properties
        public ICurrentUserProfile CurrentUserProfile { get; }

        private IMemoryCache MemoryCache { get; set; }
        #endregion

        #region Public Properties
        public int UserIdentity { get; set; }
        #endregion

        #region Edit Exceptions
        [HttpGet]
        [ProducesResponseType(typeof(EditExceptionViewModel), 200)]
        [ProducesResponseType(typeof(EditExceptionViewModel), 404)]
        [Route("/product/Product/GetException/{productId}/{versionId}")]
        public async Task<IActionResult> GetException(int productId, int versionId)
        {
            var exceptionDetail = await this.UnitOfWork.GetExceptionAsync(productId, versionId).ConfigureAwait(false);

            if (exceptionDetail != null)
            {
                return this.Ok(exceptionDetail);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateException")]
        public async Task<IActionResult> UpdateException([FromBody]EditExceptionViewModel editExceptionViewModel)
        {
            var status = await this.UnitOfWork.TryUpdateExceptionAsync(editExceptionViewModel).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion Edit Exceptions

        #region ProductProperties

        [HttpGet]
        [ProducesResponseType(typeof(ProductPropertiesViewModel), 200)]
        [ProducesResponseType(typeof(ProductPropertiesViewModel), 404)]
        [Route("/product/Product/GetProductProperties/{productId}/")]
        public async Task<IActionResult> GetProductProperties(int productId)
        {
            ProductPropertiesViewModel productProperties = new ProductPropertiesViewModel();
            productProperties = await this.UnitOfWork.GetProductPropertiesAsync(productId, CurrentUserProfile.UserId, Convert.ToInt32(CurrentUserProfile.ActualUserId)).ConfigureAwait(false);
            productProperties.UserEmail = this.CurrentUserProfile.Email;
            if (productProperties != null)
            {
                return this.Ok(productProperties);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateProductVersionHWPM/")]
        public async Task<IActionResult> UpdateProductVersionHWPM([FromBody]ProductPropertiesViewModel productPropertiesViewModel)
        {
            var status = await this.UnitOfWork.TryUpdateProductVersionHWPMAsync(productPropertiesViewModel).ConfigureAwait(false);
            return Json(status);
        }
        #endregion

        #region GetTicket
        [HttpGet]
        [ProducesResponseType(typeof(SupportTicketViewModel), 200)]
        [ProducesResponseType(typeof(SupportTicketViewModel), 404)]
        [Route("/product/Product/Ticket/{id}")]
        public async Task<IActionResult> GetTicket(int id)
        {
            if (this.ApplicationMode == "XUnitTesting")
            {
                id = 2233;
            }
            else if (this.ApplicationMode == "LocalTesting")
            {
                id = 2333;
            }
            var ticketInfo = await this.UnitOfWork.GetSupportTicketInfoAsync(id, 1).ConfigureAwait(false);
            if (ticketInfo != null)
            {
                return this.Ok(ticketInfo);
            }

            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(ApplicationErrorViewModel), 200)]
        [ProducesResponseType(typeof(ApplicationErrorViewModel), 404)]
        [Route("/product/Product/GetApplicationErrorOutstanding/{id}")]
        public async Task<IActionResult> GetApplicationErrorsOutstanding(int id)
        {
            if (this.ApplicationMode == "XUnitTesting")
            {
                id = 178;
            }
            else if (this.ApplicationMode == "LocalTesting")
            {
                id = 178;
            }
            var applicationErrorInfo = await this.UnitOfWork.GetApplicationErrorOutstandingAsync(id, 1).ConfigureAwait(false);
            if (applicationErrorInfo != null)
            {
                return this.Ok(applicationErrorInfo);
            }

            return this.NotFound();
        }
        #endregion

        #region MyWorkingListAction
        [HttpGet]
        [ProducesResponseType(typeof(ActionViewModel), 200)]
        [ProducesResponseType(typeof(ActionViewModel), 404)]
        [Route("/product/Product/GetWorkingListAction")]
        public async Task<ActionResult> GetWorkingListAction(int? productId, int? Id, int? type, int? appErrorId, int working, int? roadmapId, int? ticketId)
        {
            int currentUserID = CurrentUserProfile.UserId;
            int currentUserEmail = CurrentUserProfile.UserId;
            int? defaultWorkingListProduct = CurrentUserProfile.DefaultWorkingListProduct;
            string userName = CurrentUserProfile.UserName;
            var actions = await this.UnitOfWork.GetWorkingListActionAsync(currentUserID, currentUserEmail, defaultWorkingListProduct, productId, Id, type, appErrorId, working, roadmapId, ticketId, userName).ConfigureAwait(false);
            if (actions != null)
            {
                return this.Ok(actions);
            }

            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(ProductVersionViewModel[]), 200)]
        [ProducesResponseType(typeof(ProductVersionViewModel[]), 404)]
        [Route("/product/Product/GetAllProductGroups")]
        public async Task<IActionResult> GetProductGroups(int? productVersionId, int productId, string productName)
        {
            var productGroups = await this.UnitOfWork.GetProductGroupsAsync(productVersionId, 0, string.Empty).ConfigureAwait(false);
            return this.Json(productGroups);

        }
        [HttpGet]
        [Route("/product/Product/GetAllEmployees")]
        public async Task<JsonResult> GetAllEmployees(string employeeType, int? ownerId, int id, int pageNo, int pageSize)
        {
            int currentUserid = CurrentUserProfile.UserId;
            var employees = await this.UnitOfWork.GetEmployeeByImpersonateAsync(employeeType, 0, pageNo, pageSize, ownerId, currentUserid, id).ConfigureAwait(false);
            if (employees != null)
            {
                if (employeeType == "Owner")
                {
                    return this.Json(employees.Owners, base.JsonSettings);
                }
                else if (employeeType == "Submitter")
                {
                    return this.Json(employees.Submitters, base.JsonSettings);
                }
                else
                {
                    return this.Json(employees, base.JsonSettings);
                }
            }

            return null;
        }

        [HttpGet]
        [ProducesResponseType(typeof(ActionRoadmapViewModel[]), 200)]
        [ProducesResponseType(typeof(ActionRoadmapViewModel[]), 404)]
        [Route("/product/Product/GetActionRoadMapByProductId/{productId}")]
        public async Task<ActionResult> GetActionRoadMapByProductId(int productId)
        {
            var actionRoadMap = await this.UnitOfWork.GetActionsRoadmapByProductIdAsync(productId).ConfigureAwait(false);
            if (actionRoadMap != null)
            {
                return this.Ok(actionRoadMap);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpsertDeliverableActionWeb([FromBody]ActionViewModel actionViewModel)
        {
            var status = await this.UnitOfWork.UpsertDeliverableActionWebAsync(actionViewModel, CurrentUserProfile.UserId, CurrentUserProfile.Email).ConfigureAwait(false);
            return this.Json(status);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpdatePilotStatus([FromBody]UpdatePilotStatusViewModel productDeliverable, int versionId)
        {
            var status = await this.UnitOfWork.UpdatePilotStatusAsync(productDeliverable, Convert.ToInt32(CurrentUserProfile.UserId), CurrentUserProfile.UserName, CurrentUserProfile.Email, versionId).ConfigureAwait(false);
            return this.Json(status);
        }

        [HttpGet]
        [ProducesResponseType(typeof(ProductDeliverableViewModel), 200)]
        [ProducesResponseType(typeof(ProductDeliverableViewModel), 404)]
        [Route("/product/Product/GetPilotStatus/{productId}/{versionId}")]
        public async Task<IActionResult> GetPilotStatus(int productId, int versionId)
        {
            var productDeliverable = await this.UnitOfWork.GetPilotStatusAsync(productId, versionId).ConfigureAwait(false);
            if (productDeliverable != null)
            {
                return this.Ok(productDeliverable);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpdatePilotStatusPulsar([FromBody]UpdatePilotStatusViewModel productDeliverable, string todayPageSection, int versionId)
        {
            var status = await this.UnitOfWork.UpdatePilotStatusPulsarAsync(productDeliverable, Convert.ToInt32(CurrentUserProfile.UserId), CurrentUserProfile.UserName, CurrentUserProfile.Email, versionId, todayPageSection).ConfigureAwait(false);
            return this.Json(status);
        }

        [HttpGet]
        [ProducesResponseType(typeof(ProductDeliverableViewModel), 200)]
        [ProducesResponseType(typeof(ProductDeliverableViewModel), 404)]
        public async Task<IActionResult> GetPilotStatusPulsar(int productId, int versionId, int productDeliverableReleaseId, int? defaultReleaseId, string todayPageSection)
        {
            var pilotStatus = await this.UnitOfWork.GetProductDeliverableReleaseAsync(productId, versionId, productDeliverableReleaseId, 0, "").ConfigureAwait(false);
            if (pilotStatus != null)
            {
                return this.Ok(pilotStatus);
            }

            return this.NotFound();
        }
        #endregion

        #region MyWorkingListReorder
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateDeliverableActionDisplayOrder")]
        public async Task<IActionResult> UpdateDeliverableActionDisplayOrder([FromBody]ReorderViewModel[] reorderList)
        {
            var status = await this.UnitOfWork.TryUpdateDeliverableActionDisplayOrderAsync(reorderList).ConfigureAwait(false);
            return this.Json(status);
        }

        [HttpGet]
        [ProducesResponseType(typeof(WorkingListReorderViewModel), 200)]
        [ProducesResponseType(typeof(WorkingListReorderViewModel), 404)]
        [Route("/product/Product/GetWorkingListOrder/{id}/{projectId}/{reportOption}")]
        public async Task<IActionResult> GetWorkingListOrder(int id, int projectId, int reportOption)
        {
            var workingListOrderDetail = await this.UnitOfWork.GetWorkingListOrderAsync(id, projectId, reportOption).ConfigureAwait(false);
            if (workingListOrderDetail != null)
            {
                return this.Ok(workingListOrderDetail);
            }

            return this.NotFound();
        }

        #endregion MyWorkingListReorder

        #region UpdateEOLDate
        [ProducesResponseType(typeof(VersionPropertiesViewModel[]), 200)]
        [ProducesResponseType(typeof(VersionPropertiesViewModel[]), 404)]
        [Route("/product/Product/GetVersionPropertiesForWeb/{id}/{typeId}")]
        public async Task<IActionResult> GetVersionPropertiesForWeb(int id, int typeId)
        {
            var versionProperties = await this.UnitOfWork.GetVersionPropertiesForWebAsync(id, typeId).ConfigureAwait(false);
            if (versionProperties != null)
            {
                return this.Ok(versionProperties);
            }

            return this.NotFound();
        }

        [Route("/product/Product/UpdateEOL/{id}/{eolDate}/{typeId}/{isChecked}")]
        public async Task UpdateEOL(int id, string eolDate, int typeId, bool isChecked)
        {
            await this.UnitOfWork.UpdateEOLAsync(id, eolDate, typeId, isChecked).ConfigureAwait(false);
        }
        #endregion

        #region Product/Update Qualification Status for Multi Test Status
        [HttpGet]
        [ProducesResponseType(typeof(MultiTestStatusViewModel), 200)]
        [ProducesResponseType(typeof(MultiTestStatusViewModel), 404)]
        [Route("/product/Product/GetProductQualificationForMultiTestStatus/{id}")]
        public async Task<IActionResult> GetProductQualificationForMultiTestStatus(int productId)
        {
            if (this.ApplicationMode == "XUnitTesting")
            {
                productId = 178;
            }
            else if (this.ApplicationMode == "LocalTesting")
            {
                productId = 178;
            }
            var multiTestStatusInfo = await this.UnitOfWork.GetProductQualificationForMultiTestStatusAsync(CurrentUserProfile.UserId, Convert.ToInt32(CurrentUserProfile.ActualUserId), productId, CurrentUserProfile.EngCoordinator).ConfigureAwait(false);
            if (multiTestStatusInfo != null)
            {
                return this.Ok(multiTestStatusInfo);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpdateProductQualificationForMultiTestStatus([FromBody]MultiTestStatusViewModel multiTestStatusViewModel)
        {
            this.UserIdentity = GetImpersonateIdOrUserId();
            var status = await this.UnitOfWork.UpdateProductQualificationForMultiTestStatusAsync(multiTestStatusViewModel, this.CurrentUserProfile.LoginAuthName).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region Update WWAN TTS Status
        [ProducesResponseType(typeof(VersionPropertiesViewModel[]), 200)]
        [ProducesResponseType(typeof(VersionPropertiesViewModel[]), 404)]
        //[Route("/product/Product/GetWWANTTSStatus/{id}")]
        public async Task<IActionResult> GetWWANTTSStatus(int id)
        {
            int typeId = 0;
            var wwanTTSStatus = await this.UnitOfWork.GetWWANTTSStatusAsync(id, typeId).ConfigureAwait(false);
            if (wwanTTSStatus != null)
            {
                return this.Ok(wwanTTSStatus);
            }

            return this.NotFound();
        }

        public async Task UpdateWWANTTSStatus([FromBody]VersionPropertiesViewModel versionPropertiesVM, int id, string currentUserEmail)
        {
            await this.UnitOfWork.UpdateWWANTTSAsync(versionPropertiesVM, id, this.CurrentUserProfile.Email).ConfigureAwait(false);
        }
        #endregion

        #region Update Deliverable Status
        [ProducesResponseType(typeof(VersionPropertiesViewModel[]), 200)]
        [ProducesResponseType(typeof(VersionPropertiesViewModel[]), 404)]
        public async Task<IActionResult> GetDeliverableStatus(string id, int statusId, int typeId)
        {
            int deliverableId = 0;
            if (id != null)
            {
                string[] ids = id.Split('_');
                if (Convert.ToInt32(ids[1]) > 0)
                {
                    deliverableId = Convert.ToInt32(ids[1]);
                }
                else
                {
                    deliverableId = Convert.ToInt32(ids[0]);
                }
            }

            var deliverableStatus = await this.UnitOfWork.GetDeliverableStatusAsync(deliverableId, statusId, typeId).ConfigureAwait(false);
            if (deliverableStatus != null)
            {
                return this.Ok(deliverableStatus);
            }

            return this.NotFound();
        }

        public async Task UpdateDeliverableStatus([FromBody]DeliverableStatusViewModel deliverableStatus, string deliverableIds, int typeId)
        {
            await this.UnitOfWork.UpdateDeliverableStatusAsync(deliverableStatus, this.CurrentUserProfile.UserId, deliverableIds, typeId, this.CurrentUserProfile.Email).ConfigureAwait(false);
        }
        #endregion

        #region AccessoryStatus
        [ProducesResponseType(typeof(ProductAccessoryStatusViewModel[]), 200)]
        [ProducesResponseType(typeof(ProductAccessoryStatusViewModel[]), 404)]
        public async Task<IActionResult> GetAccessoryStatus(int prodId, int versionId)
        {
            var accessoryStatus = await this.UnitOfWork.GetAccessoryStatusAsync(prodId, versionId).ConfigureAwait(false);
            if (accessoryStatus != null)
            {
                return this.Ok(accessoryStatus);
            }

            return this.NotFound();
        }

        public async Task<IActionResult> UpdateAccessoryStatus([FromBody]ProductAccessoryStatusViewModel accessoryStatus, int prodId, int versionId, bool chkStatus)
        {
            accessoryStatus.UserId = this.GetImpersonateIdOrUserId();
            accessoryStatus.Username = this.CurrentUserProfile.UserName;
            accessoryStatus.UserEmail = this.CurrentUserProfile.Email;
            bool status = await this.UnitOfWork.TryUpdateAccessoryStatusAsync(accessoryStatus, prodId, versionId, chkStatus).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region AdvancedSupport
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]

        public async Task<IActionResult> UpdateAdvancedSupport([FromBody]AdvancedSupportViewModel advancedSupport)
        {
            var status = await this.UnitOfWork.TryUpdateAdvancedSupportAsync(advancedSupport, CurrentUserProfile.UserId, CurrentUserProfile.UserName).ConfigureAwait(false);
            return this.Json(status);
        }

        [HttpGet]
        [ProducesResponseType(typeof(AdvancedSupportViewModel), 200)]
        [ProducesResponseType(typeof(AdvancedSupportViewModel), 404)]
        public async Task<IActionResult> GetAdvancedSupport(int prodRootId, int rootId, int productDeliverableReleaseId, string rowId, int productId)
        {
            AdvancedSupportViewModel advancedSupport = new AdvancedSupportViewModel();
            advancedSupport.ProdRootId = prodRootId;
            advancedSupport.RootId = rootId;
            advancedSupport.ProductDeliverableReleaseId = productDeliverableReleaseId;
            advancedSupport.ProductId = productId;

            var advancedSupports = await this.UnitOfWork.GetAdvancedSupportAsync(advancedSupport).ConfigureAwait(false);
            if (advancedSupports != null)
            {
                return this.Ok(advancedSupports);
            }

            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("/product/Product/GetDeliverableRootType")]
        public async Task<IActionResult> GetDeliverableRootType(int? rootId, int? versionId)
        {
            var deliverableRootType = await this.UnitOfWork.GetDeliverableRootTypeAsync(rootId, versionId).ConfigureAwait(false);
            if (deliverableRootType != null)
            {
                return this.Ok(deliverableRootType);
            }

            return this.NotFound();
        }
        [HttpGet]
        [ProducesResponseType(typeof(int?), 200)]
        [ProducesResponseType(typeof(int?), 404)]
        [Route("/product/Product/GetDeliverableRootCategory")]
        public async Task<IActionResult> GetDeliverableRootCategory(int rootId)
        {
            var deliverableRootCategory = await this.UnitOfWork.GetDeliverableRootCategoryAsync(rootId).ConfigureAwait(false);
            if (deliverableRootCategory != null)
            {
                return this.Ok(deliverableRootCategory);
            }

            return this.NotFound();
        }
        #endregion

        #region UpdateMilestonePlan
        [ProducesResponseType(typeof(ScheduleViewModel[]), 200)]
        [ProducesResponseType(typeof(ScheduleViewModel[]), 404)]
        [Route("/product/Product/GetDeliverableMilestoneList/{versionId}")]
        public async Task<IActionResult> GetDeliverableMilestoneList(int versionId)
        {
            var deliverableMilestone = await this.UnitOfWork.GetDeliverableMilestoneListAsync(versionId).ConfigureAwait(false);
            if (deliverableMilestone != null)
            {
                return this.Ok(deliverableMilestone);
            }

            return this.NotFound();
        }

        [Route("/product/Product/UpdateScheduleMilestonePlan/{idArray}/{dateArray}/{tagArray}/{dateIdArray}/{versionId}")]
        public async Task UpdateScheduleMilestonePlan(string idArray, string dateArray, string tagArray, string dateIdArray, int versionId)
        {
            await this.UnitOfWork.UpdateScheduleMilestonePlanAsync(idArray, dateArray, tagArray, dateIdArray, versionId).ConfigureAwait(false);
        }
        #endregion

        #region MultiEOLDate
        [ProducesResponseType(typeof(MultiEOLDateViewModel[]), 200)]
        [ProducesResponseType(typeof(MultiEOLDateViewModel[]), 404)]
        [Route("/product/Product/GetDeliverablesToUpdate/{idList}/{typeId}")]
        public async Task<IActionResult> GetDeliverablesToUpdate(string idList, int typeId)
        {
            var deliverablesToUpdate = await this.UnitOfWork.GetDeliverablesToUpdateAsync(idList, typeId).ConfigureAwait(false);
            if (deliverablesToUpdate != null)
            {
                return this.Ok(deliverablesToUpdate);
            }

            return this.NotFound();
        }

        [Route("/product/Product/UpdateMultiEOLDate/{idArray}/{eolDate}/{typeId}/{dateChange}")]
        public async Task UpdateMultiEOLDate(string idArray, string eolDate, int typeId, string dateChange)
        {
            await this.UnitOfWork.UpdateMultiEOLDateAsync(idArray, eolDate, typeId, dateChange).ConfigureAwait(false);
        }
        #endregion

        #region Deliverable Comparison
        [ProducesResponseType(typeof(DeliverableComparisonViewModel[]), 200)]
        [ProducesResponseType(typeof(DeliverableComparisonViewModel[]), 404)]
        [Route("/product/Product/GetDeliverableComparison/{rootId}/{prodId}")]
        public async Task<IActionResult> GetDeliverableComparison(int rootId, int prodId)
        {
            var deliverableComparison = await this.UnitOfWork.GetDeliverableComparisonAsync(rootId, prodId).ConfigureAwait(false);
            if (deliverableComparison != null)
            {
                return this.Ok(deliverableComparison);
            }

            return this.NotFound();
        }
        #endregion


        #region Hardware Qualification Status
        [HttpGet]
        [ProducesResponseType(typeof(QualificationStatusViewModel), 200)]
        [ProducesResponseType(typeof(QualificationStatusViewModel), 404)]
        [Route("/product/Product/GetQualStatus/{productId}/{versionId}")]
        public async Task<IActionResult> GetQualStatus(int productId, int versionId)
        {
            HPi.Pulsar.Infrastructure.Contracts.UserInfo.UserInfoModel userInfo = new HPi.Pulsar.Infrastructure.Contracts.UserInfo.UserInfoModel();
            userInfo.UserId = this.CurrentUserProfile.UserId;
            userInfo.Email = this.CurrentUserProfile.Email;
            userInfo.ServicePM = this.CurrentUserProfile.ServicePM;

            var qualificationStatusDetail = await this.UnitOfWork.GetQualStatusAsync(productId, versionId, userInfo).ConfigureAwait(false);
            if (qualificationStatusDetail != null)
            {
                return this.Ok(qualificationStatusDetail);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateQualStatus")]
        public async Task<IActionResult> UpdateQualStatus([FromBody]QualificationStatusViewModel qualificationStatus)
        {
            var status = await this.UnitOfWork.TryUpdateQualStatusAsync(qualificationStatus, this.CurrentUserProfile.UserId, this.CurrentUserProfile.CurrentName, this.CurrentUserProfile.Email).ConfigureAwait(false);
            return this.Json(status);
        }


        [HttpGet]
        [ProducesResponseType(typeof(SubassemblyListViewModel[]), 200)]
        [ProducesResponseType(typeof(SubassemblyListViewModel[]), 404)]
        [Route("/product/Product/GetSubassembly/{productId}/{versionId}")]
        public async Task<IActionResult> GetSubassembly(int productId, int versionId)
        {
            var subassemblyList = await this.UnitOfWork.GetSubassemblyAsync(productId, versionId).ConfigureAwait(false);
            if (subassemblyList != null)
            {
                return this.Ok(subassemblyList);
            }

            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(QualificationStatusViewModel), 200)]
        [ProducesResponseType(typeof(QualificationStatusViewModel), 404)]
        [Route("/product/Product/GetQualStatusRelease/{productId}/{versionId}/{releaseId}/{productDeliverableReleaseId}/{todayPageSection}")]
        public async Task<IActionResult> GetQualStatusRelease(int productId, int versionId, int releaseId, int productDeliverableReleaseId, string todayPageSection)
        {
            UserInfoModel userInfo = new UserInfoModel();
            userInfo.UserId = this.CurrentUserProfile.UserId;
            userInfo.Email = this.CurrentUserProfile.Email;
            userInfo.ServicePM = this.CurrentUserProfile.ServicePM;

            var qualificationStatusDetail = await this.UnitOfWork.GetQualStatusReleaseAsync(productId, releaseId, versionId, userInfo, productDeliverableReleaseId, todayPageSection).ConfigureAwait(false);
            if (qualificationStatusDetail != null)
            {
                return this.Ok(qualificationStatusDetail);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateQualStatusRelease")]
        public async Task<IActionResult> UpdateQualStatusRelease([FromBody]QualificationStatusViewModel qualificationStatus)
        {
            var status = await this.UnitOfWork.TryUpdateQualStatusReleaseAsync(qualificationStatus, this.CurrentUserProfile.UserId, this.CurrentUserProfile.CurrentName, this.CurrentUserProfile.Email).ConfigureAwait(false);
            return this.Json(status);
        }


        [HttpGet]
        [ProducesResponseType(typeof(SubassemblyListViewModel[]), 200)]
        [ProducesResponseType(typeof(SubassemblyListViewModel[]), 404)]
        [Route("/product/Product/GetSubassemblyListRelease/{productId}/{versionId}/{productDeliverableReleaseId}")]
        public async Task<IActionResult> GetSubassemblyListRelease(int productId, int versionId, int productDeliverableReleaseId)
        {
            var subassemblyList = await this.UnitOfWork.GetSubassemblyListReleaseAsync(productId, versionId, productDeliverableReleaseId).ConfigureAwait(false);
            if (subassemblyList != null)
            {
                return this.Ok(subassemblyList);
            }

            return this.NotFound();
        }


        #endregion Hardware Qualification Status

        #region MultiUpdateStatus/Component Test Lead

        [HttpPost]
        [ProducesResponseType(typeof(ComponentTestLeadViewModel), 200)]
        [ProducesResponseType(typeof(ComponentTestLeadViewModel), 404)]
        [Route("/product/Product/GetProductDeliverableInfoForComponentTestLead")]
        public async Task<IActionResult> GetProductDeliverableInfoForComponentTestLead([FromBody]ComponentTestLeadViewModel componentTestLeadViewModel)
        {
            var componentTestLead = await this.UnitOfWork.GetProductDeliverableInfoForComponentTestLeadAsync(CurrentUserProfile.UserId, CurrentUserProfile.Email, CurrentUserProfile.PartnerId, CurrentUserProfile.CommodityPM, componentTestLeadViewModel).ConfigureAwait(false);
            if (componentTestLead != null)
            {
                return this.Ok(componentTestLead);
            }

            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(ComponentTestLeadViewModel), 200)]
        [ProducesResponseType(typeof(ComponentTestLeadViewModel), 404)]
        [Route("/product/Product/GetUserLeadType")]
        public async Task<IActionResult> GetUserLeadType()
        {
            var componentTestLead = await this.UnitOfWork.GetUserLeadTypeAsync(CurrentUserProfile.UserId, CurrentUserProfile.CommodityPM).ConfigureAwait(false);
            if (componentTestLead != null)
            {
                return this.Ok(componentTestLead);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(ComponentTestLeadViewModel), 200)]
        [ProducesResponseType(typeof(ComponentTestLeadViewModel), 404)]
        [Route("/product/Product/UpdateProductDeliverableComponentTest")]
        public async Task<IActionResult> UpdateProductDeliverableComponentTest([FromBody]ComponentTestLeadViewModel componentTestLead)
        {
            var status = await this.UnitOfWork.TryUpdateProductDeliverableComponentTestAsync(componentTestLead, CurrentUserProfile.UserId, CurrentUserProfile.CurrentName).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region CompareRootOnLeadProduct
        [HttpGet]
        [ProducesResponseType(typeof(RootOnLeadProductViewModel[]), 200)]
        [ProducesResponseType(typeof(RootOnLeadProductViewModel[]), 404)]
        [Route("/product/Product/GetRequestedDeliverables/{rootId}/{productId}/{fusionRequirement}")]
        public async Task<IActionResult> GetRequestedDeliverables(int rootId, int productId, int fusionRequirement)
        {
            var requestedDeliverables = await this.UnitOfWork.GetRequestedDeliverablesAsync(rootId, productId, fusionRequirement).ConfigureAwait(false);
            if (requestedDeliverables != null)
            {
                return this.Ok(requestedDeliverables);
            }

            return this.NotFound();
        }
        #endregion

        #region ViewLeadProductExclusions

        [HttpGet]
        [ProducesResponseType(typeof(DeliverableVersionViewModel[]), 200)]
        [ProducesResponseType(typeof(DeliverableVersionViewModel[]), 404)]
        [Route("/product/Product/GetAllLeadProductExclusions")]
        public async Task<IActionResult> GetAllLeadProductExclusions()
        {
            DeliverableVersionViewModel[] deliverableVersion = await this.UnitOfWork.GetAllLeadProductExclusionsAsync(CurrentUserProfile.UserId).ConfigureAwait(false);
            if (deliverableVersion != null)
            {
                return this.Ok(deliverableVersion);
            }

            return this.NotFound();
        }
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/RemoveLeadProductExclusion")]
        public async Task<IActionResult> RemoveLeadProductExclusion(string removeLeadProductIds)
        {
            bool status = await this.UnitOfWork.TryRemoveLeadProductExclusionAsync(removeLeadProductIds).ConfigureAwait(false);
            return this.Json(status);
        }

        #endregion

        #region ExclusionMain
        [HttpPost]
        [ProducesResponseType(typeof(ExclusionMainViewModel), 200)]
        [ProducesResponseType(typeof(ExclusionMainViewModel), 404)]
        [Route("/product/Product/GetDeliverableVersionExclusions")]
        public async Task<IActionResult> GetDeliverableVersionExclusions([FromBody]ExclusionMainViewModel exclusionMain)
        {
            ExclusionMainViewModel exclusions = await this.UnitOfWork.GetDeliverableVersionExclusionsByVersionIdsAsync(exclusionMain.VersionIds, exclusionMain.ProductId, exclusionMain.RootId, exclusionMain.IsFusionRequirements).ConfigureAwait(false);
            if (exclusions != null)
            {
                return this.Ok(exclusions);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/AddLeadProductExclusions")]
        public async Task<IActionResult> AddLeadProductExclusions([FromBody]ExclusionMainViewModel exclusionMain)
        {
            bool status = await this.UnitOfWork.TryAddLeadProductExclusionsAsync(exclusionMain).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region Update Developer Approval
        //[ProducesResponseType(typeof(VersionPropertiesViewModel[]), 200)]
        //[ProducesResponseType(typeof(VersionPropertiesViewModel[]), 404)]
        //[Route("/product/Product/GetDeveloperApproval/{productDeliverableIds}/{partnerId}")]
        public async Task<IActionResult> GetDeveloperApproval(string productDeliverableIds, int partnerId)
        {
            var developerapproval = await this.UnitOfWork.GetDeveloperApprovalAsync(productDeliverableIds, this.CurrentUserProfile.PartnerId).ConfigureAwait(false);
            if (developerapproval != null)
            {
                return this.Ok(developerapproval);
            }

            return this.NotFound();
        }

        public async Task UpdateDeveloperApproval([FromBody]DeveloperApprovalViewModel developerApprovalVM, string idList, int typeId)
        {
            await this.UnitOfWork.UpdateDeveloperApprovalAsync(developerApprovalVM, this.CurrentUserProfile.UserId, idList, typeId, this.CurrentUserProfile.Email).ConfigureAwait(false);
        }
        #endregion

        #region DevRejectProductRequirement
        [HttpPost]
        [ProducesResponseType(typeof(DeveloperRequestProductRejectionViewModel[]), 200)]
        [ProducesResponseType(typeof(DeveloperRequestProductRejectionViewModel[]), 404)]
        //[Route("/product/Product/GetProductDeliverableSummary/{id}/{newValue}")]
        public async Task<IActionResult> GetProductDeliverableSummary([FromBody]string[] id, string newValue)
        {
            var productDeliverableSummary = await this.UnitOfWork.GetProductDeliverableSummaryAsync(id, newValue).ConfigureAwait(false);
            if (productDeliverableSummary != null)
            {
                return this.Ok(productDeliverableSummary);
            }

            return this.NotFound();
        }
        #endregion

        #region SaveDevNotification
        [HttpPost]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 404)]
        //[Route("/product/Product/SaveDevNotification/{multiId}/{newValue}/{comments?}")]
        public async Task<string> SaveDevNotification([FromBody]string[] multiId, string newValue, string comments = "")
        {
            this.UserIdentity = GetImpersonateIdOrUserId();
            var saveDevNotification = await this.UnitOfWork.SaveDevNotificationAsync(multiId, newValue, comments, UserIdentity, CurrentUserProfile.Name, CurrentUserProfile.Email).ConfigureAwait(false);
            return saveDevNotification;
        }
        #endregion

        #region View Lead Product Usage Exceptions
        [ProducesResponseType(typeof(LeadProductUsageExceptionsViewModel[]), 200)]
        [ProducesResponseType(typeof(LeadProductUsageExceptionsViewModel[]), 404)]
        public async Task<IActionResult> GetLeadProductUsageExceptions(int pmId)
        {
            var leadProductUsageExceptions = await this.UnitOfWork.GetLeadProductUsageExceptionsAsync(pmId).ConfigureAwait(false);
            if (leadProductUsageExceptions != null)
            {
                return this.Ok(leadProductUsageExceptions);
            }

            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateLeadProductUsageExceptions/{leadProductIds}/{types}")]
        public async Task<IActionResult> UpdateLeadProductUsageExceptions(string leadProductIds, string types)
        {
            int status = await this.UnitOfWork.UpdateLeadProductUsageExceptionsAsync(leadProductIds, types).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region AccessoryStatusPulsar
        [ProducesResponseType(typeof(ProductDeliverableViewModel[]), 200)]
        [ProducesResponseType(typeof(ProductDeliverableViewModel[]), 404)]
        public async Task<IActionResult> GetAccessoryStatusPulsar(int prodId, int versionId, int productDeliverableReleaseId, int? releaseId, string todayPageSection)
        {
            var accessoryStatusViewModel = await this.UnitOfWork.GetAccessoryStatusPulsarAsync(prodId, versionId, productDeliverableReleaseId, releaseId, todayPageSection).ConfigureAwait(false);
            return this.Json(accessoryStatusViewModel);
        }

        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        public async Task<JsonResult> UpdateAccessoryStatusPulsar([FromBody]ProductDeliverableViewModel accessoryStatusViewModel, int prodId, int versionId, int productDeliverableReleaseId, bool chkStatus)
        {
            accessoryStatusViewModel.UserId = this.GetImpersonateIdOrUserId();
            accessoryStatusViewModel.Username = this.CurrentUserProfile.UserName;
            accessoryStatusViewModel.UserEmail = this.CurrentUserProfile.Email;
            bool status = await this.UnitOfWork.TryUpdateAccessoryStatusPulsarAsync(accessoryStatusViewModel, prodId, versionId, productDeliverableReleaseId, chkStatus).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region AddAVNoToFeature

        [HttpGet]
        [ProducesResponseType(typeof(AvNoToFeatureViewModel), 200)]
        [ProducesResponseType(typeof(AvNoToFeatureViewModel), 404)]
        [Route("/product/Product/GetAVNoDescription/{productVersionId}/{productBrandId}/{scmCategoryId}")]
        public async Task<IActionResult> GetAVNoDescription(int productVersionId, int productBrandId, int scmCategoryId)
        {
            var exceptionDetail = await this.UnitOfWork.GetAVNoDescriptionAsync(productVersionId, productBrandId, scmCategoryId).ConfigureAwait(false);
            if (exceptionDetail != null)
            {
                return this.Ok(exceptionDetail);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateAvDetailFeatureID")]
        public async Task<IActionResult> UpdateAvDetailFeatureID([FromBody]AvNoToFeatureViewModel avNoToFeature)
        {
            avNoToFeature.UserId = GetCurrentUserIdOrCmPcPhWebMktImpersonateId();
            var status = await this.UnitOfWork.TryUpdateAvDetailFeatureIDAsync(avNoToFeature).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion AddAVNoToFeature

        #region Image Tab Change Show SCM
        [ProducesResponseType(typeof(ImageTabChangeSCMViewModel[]), 200)]
        [ProducesResponseType(typeof(ImageTabChangeSCMViewModel[]), 404)]
        [Route("/product/Product/GetImageTabChangeSCM/{productId}/{imageDefinitionId}")]
        public async Task<IActionResult> GetImageTabChangeSCM(int productId, int imageDefinitionId)
        {
            var imageTabChangeSCM = await this.UnitOfWork.GetImageTabChangeSCMAsync(productId, 0).ConfigureAwait(false);
            if (imageTabChangeSCM != null)
            {
                return this.Ok(imageTabChangeSCM);
            }

            return this.NotFound();
        }

        #endregion

        #region Test Status
        [HttpGet]
        [ProducesResponseType(typeof(TestLeadStatusViewModel), 200)]
        [ProducesResponseType(typeof(TestLeadStatusViewModel), 404)]
        [Route("/product/Product/GetTestStatus/{versionId}/{productId}/{fieldId}")]
        public async Task<IActionResult> GetTestStatus(int versionId, int productId, int fieldId)
        {
            HPi.Pulsar.Infrastructure.Contracts.UserInfo.UserInfoModel userInfo = new HPi.Pulsar.Infrastructure.Contracts.UserInfo.UserInfoModel();
            userInfo.UserId = this.CurrentUserProfile.UserId;
            userInfo.PartnerId = this.CurrentUserProfile.PartnerId;
            userInfo.Email = this.CurrentUserProfile.Email;
            var exceptionDetail = await this.UnitOfWork.GetTestStatusAsync(versionId, productId, fieldId, userInfo).ConfigureAwait(false);
            if (exceptionDetail != null)
            {
                return this.Ok(exceptionDetail);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateTestLeadStatus")]
        public async Task<IActionResult> UpdateTestLeadStatus([FromBody]TestLeadStatusViewModel testLeadStatus)
        {
            UserInfoModel userInfo = new UserInfoModel();
            userInfo.UserId = this.CurrentUserProfile.UserId;
            userInfo.LoginUserName = this.CurrentUserProfile.LoginAuthName;
            var status = await this.UnitOfWork.TryUpdateTestLeadStatus(testLeadStatus, userInfo).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion Test Status

        #region UpdateSupportedProducts

        [HttpGet]
        [ProducesResponseType(typeof(ProductSupportedViewModel), 200)]
        [ProducesResponseType(typeof(ProductSupportedViewModel), 404)]
        [Route("/product/Product/UpdateSupportedProducts/{versionId}")]
        public async Task<IActionResult> UpdateSupportedProducts(int versionId)
        {
            var updateSupportedProducts = await this.UnitOfWork.UpdateSupportedProductsAsync(versionId).ConfigureAwait(false);
            return this.Json(updateSupportedProducts);
        }

        #endregion

        #region Update SE Test Status
        [HttpGet]
        [ProducesResponseType(typeof(TestStatusPulsarViewModel), 200)]
        [ProducesResponseType(typeof(TestStatusPulsarViewModel), 404)]
        [Route("/product/Product/GetPulsarTestLeadStatus/{productId}/{releaseId}/{versionId}/{fieldId}/{todayPageSection}/{rowId}")]
        public async Task<IActionResult> GetPulsarTestLeadStatus(int productId, int releaseId, int versionId, int fieldId, string todayPageSection, int rowId)
        {
            int productReleaseDeliverableId = 0;
            var testLeadStatusPulsar = await this.UnitOfWork.GetPulsarTestLeadStatusAsync(productId, releaseId, versionId, fieldId, todayPageSection, rowId, productReleaseDeliverableId).ConfigureAwait(false);
            if (testLeadStatusPulsar != null)
            {
                return this.Ok(testLeadStatusPulsar);
            }

            return this.NotFound();
        }

        [HttpGet]
        [Route("/product/Product/UpdatePulsarTestLeadStatus/{productId}/{versionId}/{fieldId}/{cboStatus}/{productDeliverableReleaseId}/{received?}/{notes?}")]
        public async Task UpdatePulsarTestLeadStatus(int productId, int versionId, int fieldId, int cboStatus, int productDeliverableReleaseId, int? received = 0, string notes = "")
        {
            HPi.Pulsar.Product.Contracts.TestLeadStatusPulsarModel testLeadStatusPulsar = new HPi.Pulsar.Product.Contracts.TestLeadStatusPulsarModel();
            testLeadStatusPulsar.ProductId = productId;
            testLeadStatusPulsar.DeliverableId = versionId;
            testLeadStatusPulsar.FieldId = fieldId;
            testLeadStatusPulsar.UserId = GetImpersonateIdOrUserId();
            testLeadStatusPulsar.UserName = CurrentUserProfile.LoginDomain + "_" + CurrentUserProfile.CurrentName;
            testLeadStatusPulsar.StatusId = cboStatus;
            testLeadStatusPulsar.Notes = notes;
            testLeadStatusPulsar.UnitsReceived = received == 0 ? null : received;
            testLeadStatusPulsar.ProductDeliverableReleaseId = productDeliverableReleaseId;
            await this.UnitOfWork.UpdateTestLeadStatusPulsarAsync(testLeadStatusPulsar).ConfigureAwait(false);
        }
        #endregion

        #region Target Deliverable
        [HttpGet]
        [Route("/product/product/GetTargetDeliverableRootDetails/{productId}/{rootId}/{versionId}/{excludeFunComp?}")]
        public async Task<IActionResult> GetTargetDeliverableRootDetails(int productId, int rootId, int versionId, bool? excludeFunComp)
        {
            TargetAdvancedViewModel targetAdvanced = await this.UnitOfWork.GetTargetDeliverableRootDetailsAsync(productId, rootId, versionId, excludeFunComp).ConfigureAwait(false);

            if (targetAdvanced.LoadFailed)
            {
                if (!targetAdvanced.Active)
                {
                    targetAdvanced.Displaytext = "This deliverable is inactive.Please remove it from the Requirements tab or contact the developer to have it reactivated.";
                }
                else
                {
                    targetAdvanced.Displaytext = "Unable to load advanced targeting information";
                }
            }
            else
            {
                if (targetAdvanced.Version == "")
                {
                    targetAdvanced.Displaytext = "No Versions for selected Deliverable on Selected Product.";
                }
            }

            return View(targetAdvanced);
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateTargetAdvanced")]
        public async Task<IActionResult> UpdateTargetAdvanced([FromBody]List<TargetAdvancedViewModel> targetAdvanced)
        {
            int currentUserID = CurrentUserProfile.UserId;
            var apiResult = await this.UnitOfWork.UpdateTargetAdvancedAsync(targetAdvanced, currentUserID).ConfigureAwait(false);
            return this.Json(apiResult);
        }
        #endregion Target Deliverable

        #region Save Supported Products
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/SaveSupportedProducts")]
        public async Task<IActionResult> SaveSupportedProducts([FromBody]ProductSupportedViewModel productSupportedViewModel)
        {
            var updateSupportedProducts = await this.UnitOfWork.TrySaveSupportedProductsAsync(productSupportedViewModel).ConfigureAwait(false);
            return this.Json(updateSupportedProducts);
        }
        #endregion 

        #region Release Commodities

        [ProducesResponseType(typeof(ReleaseViewModel[]), 200)]
        [ProducesResponseType(typeof(ReleaseViewModel[]), 404)]
        [Route("/product/Product/ReleaseCommodities/{versionID}/{functionNo}")]
        public async Task<IActionResult> ReleaseCommodities(string versionID, string functionNo)
        {
            var releaseCommodities = await this.UnitOfWork.ReleaseCommoditiesAsync(versionID, functionNo).ConfigureAwait(false);
            if (releaseCommodities != null)
            {
                return this.Ok(releaseCommodities);
            }

            return this.NotFound();
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("product/product/SaveReleaseCommodities")]
        public async Task<IActionResult> SaveReleaseCommodities([FromBody]ReleaseViewModel[] releaseViewModel)
        {
            var saveReleaseCommodities = await this.UnitOfWork.TrySaveReleaseCommoditiesAsync(releaseViewModel, CurrentUserProfile.UserId, CurrentUserProfile.Email).ConfigureAwait(false);
            return this.Json(saveReleaseCommodities);
        }

        #endregion

        #region Product/Update Qualification Status for Multi Test Status Pulsar
        [HttpPost]
        [ProducesResponseType(typeof(MultiTestStatusViewModel), 200)]
        [ProducesResponseType(typeof(MultiTestStatusViewModel), 404)]        
        [Route("/product/Product/GetProductQualificationForMultiTestStatusPulsar/")]
        public async Task<IActionResult> GetProductQualificationForMultiTestStatusPulsar(ProductQualificationStatusViewModel productQualificationStatus)
        {
            if (this.ApplicationMode == "XUnitTesting")
            {
                productQualificationStatus.VersionList = "178";
            }
            else if (this.ApplicationMode == "LocalTesting")
            {
                productQualificationStatus.VersionList = "178";
            }
            var multiTestStatusInfo = await this.UnitOfWork.GetProductQualificationForMultiTestStatusPulsarAsync(productQualificationStatus.VersionList, CurrentUserProfile, productQualificationStatus.ProductId, productQualificationStatus.RootId, productQualificationStatus.VersionId, productQualificationStatus.BsId, productQualificationStatus.ShowOnlyTargetedRelease).ConfigureAwait(false);
            if (multiTestStatusInfo != null)
            {
                return this.Ok(multiTestStatusInfo);
            }

            return this.NotFound();
        }

        //[HttpPost]
        //[ProducesResponseType(typeof(int), 200)]
        //[ProducesResponseType(typeof(int), 404)]
        public async Task UpdateProductQualificationForMultiTestStatusPulsar([FromBody]UpdateMultiTestStatusPulsar multiTestStatusPulsar, string selectedIds)
        {
            var status = await this.UnitOfWork.TryUpdateQualificationForMultiTestStatusPulsarAsync(multiTestStatusPulsar, this.CurrentUserProfile, selectedIds).ConfigureAwait(false);
            //return this.Json(status);
        }
        #endregion

        #region programsCommodityPM
        [HttpGet]
        [Route("/product/product/GetProgramsCommodityPM/{productId}")]
        public async Task<IActionResult> GetProgramsCommodityPM(int productId)
        {
            var programCommodityPM = await this.UnitOfWork.GetprogramsCommodityPMAsync(productId, this.CurrentUserProfile).ConfigureAwait(false);
            return View("ProgramsCommodityPM", programCommodityPM);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("product/product/UpdateprogramsCommodityPM")]
        public async Task<IActionResult> UpdateprogramsCommodityPM(UpdateProgramCommodityViewModel programCommodity)
        {
            var status = await this.UnitOfWork.UpdateprogramsCommodityPMAsync(programCommodity, CurrentUserProfile.UserId).ConfigureAwait(false);
            return this.Json(status);
        }

        #endregion

        #region Schedule Milstone
        [HttpGet]
        [Route("product/product/GetScheduleMilestones/{productId}/{scheduleId}")]
        public async Task<IActionResult> GetScheduleMilestones(int productId, int scheduleId)
        {
            MilestoneListDataViewModel milestones = await this.UnitOfWork.GetScheduleMilestonesAsync(productId, scheduleId).ConfigureAwait(false);
            milestones.ProductId = productId;
            milestones.ScheduleId = scheduleId;
            return View(milestones);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("product/product/UpdateScheduleMilestones")]
        public async Task<IActionResult> UpdateScheduleMilestones([FromBody] MilestoneUpdateDataViewModel milestoneUpdateData)
        {
            string userName = CurrentUserProfile.UserName;
            string addedMilestones = milestoneUpdateData.AddedMilestones;
            string removedMilestones = milestoneUpdateData.RemovedMilestones;
            int productId = milestoneUpdateData.ProductId;
            var status = await this.UnitOfWork.UpdateScheduleMilestonesAsync(addedMilestones, removedMilestones, productId, userName).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion Schedule Milstone

        #region MilestonePulsar
        [HttpGet]
        [Route("/product/Product/GetMilestonePulsar/{id}/{actionName?}")]
        public async Task<IActionResult> GetMilestonePulsar(int id, string actionName)
        {
            var milestonePulsar = await this.UnitOfWork.GetMilestonePulsarAsync(id, actionName).ConfigureAwait(false);
            return View(milestonePulsar);
        }

        [HttpPost]
        public async Task UpdateMilestone([FromForm]MilestonePulsarViewModel milestonePulsarViewModel)
        {
            HPi.Pulsar.Product.Contracts.ScheduleDataModel scheduleData = new HPi.Pulsar.Product.Contracts.ScheduleDataModel();
            scheduleData.ProductVersion = new Pulsar.Product.Contracts.ProductVersionModel();
            scheduleData.ScheduleId = Convert.ToInt32(milestonePulsarViewModel.ScheduleId);
            scheduleData.ScheduleDataId = Convert.ToInt32(milestonePulsarViewModel.ScheduleDataId);
            scheduleData.ScheduleDefinitionDataId = Convert.ToInt32(milestonePulsarViewModel.ScheduleDefinitionDataId);
            scheduleData.PorEndDt = Convert.ToDateTime(milestonePulsarViewModel.POREnd);
            scheduleData.ProjectedStartDateOld = milestonePulsarViewModel.PlannedStartDateOld == null ? (DateTime?)null : Convert.ToDateTime(milestonePulsarViewModel.PlannedStartDateOld);
            scheduleData.ProjectedEndDateOld = milestonePulsarViewModel.PlannedEndDateOld == null ? (DateTime?)null : Convert.ToDateTime(milestonePulsarViewModel.PlannedEndDateOld);
            scheduleData.ProjectedStartDt = milestonePulsarViewModel.PlannedStartDate == null ? (DateTime?)null : Convert.ToDateTime(milestonePulsarViewModel.PlannedStartDate);
            scheduleData.ProjectedEndDt = milestonePulsarViewModel.PlannedEndDate == null ? (DateTime?)null : Convert.ToDateTime(milestonePulsarViewModel.PlannedEndDate);
            scheduleData.ActualStartDt = milestonePulsarViewModel.ActualStartDate == null ? (DateTime?)null : Convert.ToDateTime(milestonePulsarViewModel.ActualStartDate);
            scheduleData.ActualEndDt = milestonePulsarViewModel.ActualEndDate == null ? (DateTime?)null : Convert.ToDateTime(milestonePulsarViewModel.ActualEndDate);
            scheduleData.ProductVersion.ProductVersionId = Convert.ToInt32(milestonePulsarViewModel.ProductVersionId);
            scheduleData.ShowOnReportsYN = milestonePulsarViewModel.IsShowReports == "on" ? "Y" : "N";
            scheduleData.ItemNotes = milestonePulsarViewModel.Comments;
            scheduleData.ChangeNotes = milestonePulsarViewModel.ItemNotes;
            scheduleData.ItemPhase = Convert.ToInt32(milestonePulsarViewModel.PhaseId);
            scheduleData.OwnerId = milestonePulsarViewModel.OwnerId != null ? Convert.ToInt32(milestonePulsarViewModel.OwnerId) : (int?)null;
            scheduleData.MilestoneYN = Convert.ToString(milestonePulsarViewModel.IsMilestone);
            scheduleData.Program = milestonePulsarViewModel.Program;
            scheduleData.LastUpdUser = CurrentUserProfile.UserName;
            string currentUser = CurrentUserProfile.UserName;
            string currentEmail = CurrentUserProfile.Email;
            bool isSEPMProductsEditor = CurrentUserProfile.SepmCount > 0 ? true : false;
            int currentUserId = GetImpersonateIdOrUserId();
            await this.UnitOfWork.UpdateMilestoneAsync(scheduleData, currentUser, currentEmail, isSEPMProductsEditor, currentUserId).ConfigureAwait(false);
        }
        #endregion

        #region SubAssembly

        [Route("/product/Product/GetSubAssembly/{versionId}/{productId}/{rootId}/{idList?}")]
        public async Task<IActionResult> GetSubAssembly(int versionId, int productId, int rootId, string idList = "")
        {
            int showOnlyTargetedRelease = 0;
            string rowId = idList;
            idList = "";
            var releaseCommodities = await this.UnitOfWork.GetSubAssemblyAsync(versionId, productId, rootId, showOnlyTargetedRelease, rowId, idList, CurrentUserProfile.EngCoordinator, CurrentUserProfile.SAAdmin, CurrentUserProfile.ServiceCoordinator).ConfigureAwait(false);
            return View(releaseCommodities);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("product/product/UpdateSubAssembly")]
        public async Task<JsonResult> UpdateSubAssembly(SubAssemblyPulsarViewModel subAssemblyPulsarViewModel)
        {
            subAssemblyPulsarViewModel.UserId = this.CurrentUserProfile.UserId;
            subAssemblyPulsarViewModel.UserName = this.CurrentUserProfile.UserName;
            var status = await this.UnitOfWork.TryUpdateSubAssemblyAsync(subAssemblyPulsarViewModel).ConfigureAwait(false);
            return this.Json(status);
        }

        #endregion

        #region SubAssemblyPulsar

        [Route("/product/Product/GetSubAssemblyPulsar/{versionId}/{productId}/{rootId}/{releaseId}/{idList?}")]
        public async Task<IActionResult> GetSubAssemblyPulsar(int versionId, int productId, int rootId, int releaseId, string idList = "")
        {
            int showOnlyTargetedRelease = 0;
            string rowId = idList;
            idList = "";
            var releaseCommodities = await this.UnitOfWork.GetSubAssemblyPulsarAsync(versionId, productId, rootId, releaseId, showOnlyTargetedRelease, rowId, idList, CurrentUserProfile.EngCoordinator, CurrentUserProfile.SAAdmin, CurrentUserProfile.ServiceCoordinator).ConfigureAwait(false);
            return View(releaseCommodities);
        }

        [Route("/product/Product/GetSubAssemblyPulsar/{versionId}/{productId}/{rootId}/{releaseId}/{idList}/{showOnlyTargetedRelease}")]
        public async Task<IActionResult> GetSubAssemblyPulsar(int versionId, int productId, int rootId, int releaseId, string idList, int showOnlyTargetedRelease)
        {
            string rowId = idList;
            idList = "";
            var releaseCommodities = await this.UnitOfWork.GetSubAssemblyPulsarAsync(versionId, productId, rootId, releaseId, showOnlyTargetedRelease, rowId, idList, CurrentUserProfile.EngCoordinator, CurrentUserProfile.SAAdmin, CurrentUserProfile.ServiceCoordinator).ConfigureAwait(false);
            return View(releaseCommodities);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("product/product/UpdateSubAssemblyPulsar")]
        public async Task<JsonResult> UpdateSubAssemblyPulsar(SubAssemblyPulsarViewModel subAssemblyPulsarViewModel)
        {
            subAssemblyPulsarViewModel.UserId = this.CurrentUserProfile.UserId;
            subAssemblyPulsarViewModel.UserName = this.CurrentUserProfile.UserName;
            var status = await this.UnitOfWork.TryUpdateSubAssemblyPulsarAsync(subAssemblyPulsarViewModel).ConfigureAwait(false);
            return this.Json(status);
        }

        #endregion

        #region Change Distribution
        [HttpGet]
        [Route("/product/product/ChangeDistribution/{productId}/{versionId}/{rootId}/{releaseId}")]
        public async Task<IActionResult> ChangeDistribution(int productId, int versionId, int rootId)
        {
            var changeDistribution = await this.UnitOfWork.GetChangeDistributionAsync(productId, versionId, rootId).ConfigureAwait(false);
            return View(changeDistribution);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateDistributions([FromBody]ChangeDistributionUpdateViewModel ChangeDistributionUpdate)
        {
            var status = await this.UnitOfWork.UpdateDistributionsAsync(ChangeDistributionUpdate, CurrentUserProfile.UserId).ConfigureAwait(false);
            return this.Json(status);
        }

        #endregion

        #region  TargetDeliverableVersionWeb
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateTargetDeliverableVersionWeb")]
        public async Task<IActionResult> UpdateTargetDeliverableVersionWeb([FromBody]TargetDeliverableVersionWebViewModel targetDeliverableVersionWebViewModel)
        {
            this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateId();
            targetDeliverableVersionWebViewModel.UserId = this.UserIdentity;
            var targetDeliverableVersionWeb = await this.UnitOfWork.TryUpdateTargetDeliverableVersionWebAsync(targetDeliverableVersionWebViewModel).ConfigureAwait(false);
            return this.Json(targetDeliverableVersionWeb);
        }
        #endregion

        #region UpdateOverrideRequestedFeature

        public async Task<IActionResult> UpdateOverrideRequestedFeature(int featureId, int actionType, string function)
        {
            var targetDeliverableVersionWeb = await this.UnitOfWork.TryUpdateOverrideRequestedFeatureAsync(featureId, actionType, function, CurrentUserProfile.UserId, CurrentUserProfile.Email, CurrentUserProfile.UserName).ConfigureAwait(false);
            return this.Json(targetDeliverableVersionWeb);
        }

        #endregion

        #region Reject Feature Request
        [HttpGet]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 404)]
        [Route("product/Product/GetFeatureName/{id}")]
        public async Task<IActionResult> GetFeatureName(int id)
        {
            var featureName = await this.UnitOfWork.GetFeatureNameAsync(id).ConfigureAwait(false);
            if (featureName != null)
            {
                return this.Ok(featureName);
            }

            return this.NotFound();
        }

        [HttpPost]
        public async Task RejectFeatureRequest([FromBody]HPi.Pulsar.Product.Contracts.FeatureRootModel featureRoot)
        {
            featureRoot.RejectedByUserId = GetImpersonateIdOrUserId();
            await this.UnitOfWork.RejectFeatureRequestAsync(featureRoot).ConfigureAwait(false);
        }
        #endregion

        #region ChangeImages

        [HttpGet]
        [ProducesResponseType(typeof(ChangeImagesViewModel), 200)]
        [ProducesResponseType(typeof(ChangeImagesViewModel), 404)]
        public async Task<IActionResult> GetAllChangeImagesForProductFusion(int productId, int rootId, int versionId, int typeId)
        {
            var changeImages = await this.UnitOfWork.GetAllChangeImagesForProductFusionAsync(productId, rootId, versionId, typeId).ConfigureAwait(false);
            if (changeImages.DefaultImage.Count() > 0)
            {
                changeImages.IsSelectedAll = changeImages.DefaultImage.Where(x => x.CheckedStatus == "checked").Count() == changeImages.DefaultImage.Count();
            }
            if (changeImages.RestoreChangeImage.Count() > 0)
            {
                changeImages.IsRestoreSelectedAll = changeImages.RestoreChangeImage.Where(x => x.CheckedStatus == "checked").Count() == changeImages.RestoreChangeImage.Count();
            }
            return PartialView("ChangeImages", changeImages);
        }
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        public async Task<IActionResult> UpdateChangeImages(ChangeImagesViewModel changeImagesViewModel)
        {
            var status = await this.UnitOfWork.TryUpdateChangeImagesForProductFusionAsync(changeImagesViewModel, CurrentUserProfile.UserId).ConfigureAwait(false);
            return Json(status);
        }

        [HttpGet]
        [Route("product/Product/GetAllChangeImagesForProduct/{productId}/{rootId}/{versionId}/{typeId}")]
        public async Task<IActionResult> GetAllChangeImagesForProduct(int productId, int rootId, int versionId, int typeId)
        {
            var changeImages = await this.UnitOfWork.GetAllChangeImagesForProductAsync(productId, rootId, versionId, typeId).ConfigureAwait(false);
            return PartialView("GetChangeImages", changeImages);
        }
        #endregion

        #region Update Image Tab Change Show SCM
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateImageAddObsoleteLocalizedAV/{imageActionItemId}/{productVersionId}/{productBrandId}/{actionType}/{updatedBy}")]
        public async Task<IActionResult> UpdateImageAddObsoleteLocalizedAV(int imageActionItemId, int productVersionId, int productBrandId, int actionType, string updatedBy)
        {
            var status = await this.UnitOfWork.UpdateImageAddObsoleteLocalizedAVAsync(imageActionItemId, productVersionId, productBrandId, actionType, updatedBy).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region Support Articles List
        [HttpGet]
        [Route("product/product/GetSupportArticles/{id?}/{isList?}/{previewDetails?}/{previewURL?}/{previewSummary?}")]
        public async Task<IActionResult> GetSupportArticles(int? id, bool? isList, string previewDetails = "", string previewURL = "", string previewSummary = "")
        {
            var supportArticles = await this.UnitOfWork.GetSupportArticlesAsync(id, isList, previewDetails, previewURL, previewSummary).ConfigureAwait(false);
            return View(supportArticles);
        }
        #endregion Support Articles List

        #region Support Projects
        [HttpGet]
        [Route("/product/Product/GetSupportProjects/{cboProject?}/{cboCategory?}/{requiredText?}")]
        public async Task<IActionResult> GetSupportProjects(int? cboProject, int? cboCategory, string requiredText = "")
        {
            var supportProjects = await this.UnitOfWork.GetSupportProjectsAsync(cboProject, cboCategory, requiredText).ConfigureAwait(false);
            return View(supportProjects);
        }

        [HttpGet]
        [ProducesResponseType(typeof(CategoryList[]), 200)]
        [ProducesResponseType(typeof(CategoryList[]), 404)]
        [Route("/product/Product/GetSupportCategories/{projectId?}/{cboCategory?}")]
        public async Task<IActionResult> GetSupportCategories(int? projectId, int? cboCategory)
        {
            var supportCategories = await this.UnitOfWork.GetSupportCategoriesAsync(projectId, cboCategory).ConfigureAwait(false);
            if (supportCategories != null)
            {
                return this.Ok(supportCategories);
            }

            return this.NotFound();
        }


        [HttpPost]
        [ProducesResponseType(typeof(SupportProjectViewModel), 200)]
        [ProducesResponseType(typeof(SupportProjectViewModel), 404)]
        [Route("/product/Product/GetSearchResults/")]
        public async Task<IActionResult> GetSearchResults([FromBody]HPi.Pulsar.Product.Contracts.SupportIssueModel supportIssues)
        {
            var searchResults = await this.UnitOfWork.GetSearchResultsAsync(supportIssues).ConfigureAwait(false);
            if (searchResults != null)
            {
                return this.Ok(searchResults);
            }

            return this.NotFound();
        }

        [HttpPost]
        [Route("/product/Product/CancelSupport/")]
        public async Task CancelSupport([FromBody]SupportProjectViewModel support)
        {
            support.SubmitterId = GetImpersonateIdOrUserId();
            await this.UnitOfWork.CancelSupportAsync(support).ConfigureAwait(false);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("/product/Product/SaveSupport/")]
        public async Task<IActionResult> SaveSupport([FromBody]SupportProjectViewModel support)
        {
            string currentUserEmail = CurrentUserProfile.Email;
            string currentUserPartner = Convert.ToString(CurrentUserProfile.PartnerId);
            support.SubmitterId = GetImpersonateIdOrUserId();
            var saveSupport = await this.UnitOfWork.SaveSupportAsync(support, currentUserEmail, currentUserPartner).ConfigureAwait(false);
            return Json(saveSupport);
        }
        #endregion

        #region Query Actions
        [HttpGet]
        [Route("product/product/QueryActions/{id}/{type}/{category?}")]
        public IActionResult GetQueryActions(int id, int type, int? category)
        {
            int userId = CurrentUserProfile.UserId;
            byte? division = CurrentUserProfile.Division;
            var queryAction = new QueryActionViewModel(); //await this.UnitOfWork.QueryActions(id, type, userId);
            queryAction.Division = division == null ? "" : division.ToString();
            queryAction.Title = category == 1 ? "SKU Change Requests - Advanced Query" : "Action Item - Advanced Query";
            queryAction.UserId = userId;
            queryAction.QueryType = type;
            queryAction.ID = id;
            if (category.HasValue)
            {
                queryAction.CAT = Convert.ToInt32(category);
            }
            return View(queryAction);
        }

        public async Task<JsonResult> GetReportProfileDetails(int profileId)
        {
            int userId = CurrentUserProfile.UserId;
            var profileDetail = await this.UnitOfWork.GetReportProfileDetailsAsync(profileId, userId).ConfigureAwait(false);

            return Json(profileDetail, base.JsonSettings);
        }

        [HttpPost]
        [Route("product/product/UpdateProfile")]
        public async Task<JsonResult> UpdateProfile(QueryActionPostModel queryActionPost)
        {
            var result = await this.UnitOfWork.UpdateProfileAsync(queryActionPost).ConfigureAwait(false);
            return Json(result);
        }

        [HttpPost]
        [Route("product/product/AddProfile")]
        public async Task<JsonResult> AddProfile(QueryActionPostModel queryActionPost)
        {
            var result = await this.UnitOfWork.AddProfileAsync(queryActionPost).ConfigureAwait(false);
            return Json(result);
        }

        [HttpPost]
        [Route("product/product/RenameProfile")]
        public async Task<JsonResult> RenameProfile(int id, string profileName, int? employeeId)
        {
            var result = await this.UnitOfWork.RenameProfileAsync(id, profileName, employeeId).ConfigureAwait(false);
            return Json(result);
        }

        [HttpPost]
        [Route("product/product/DeleteProfile")]
        public async Task<JsonResult> DeleteProfile(int profileId, int? employeeId)
        {
            var result = await this.UnitOfWork.DeleteProfileAsync(profileId, employeeId).ConfigureAwait(false);
            return Json(result);
        }

        [Route("product/product/RemoveSharedProfile")]
        public async Task<JsonResult> RemoveSharedProfile(int sharingId)
        {
            var result = await this.UnitOfWork.RemoveSharedProfileAsync(sharingId).ConfigureAwait(false);
            return Json(result);
        }

        [HttpGet]
        [Route("product/product/ShareProfile/{id}")]
        public async Task<IActionResult> ShareProfile(int id, int? employeeId)
        {
            var result = await this.UnitOfWork.ShareProfileAsync(id, employeeId).ConfigureAwait(false);
            return View("ShareProfile", result);
        }

        public async Task<JsonResult> GetProducts(int id)
        {
            string key = "Products";
            var products = this.GetCache<List<SelectOptions>>(key);
            if (products == null)
            {
                products = await this.UnitOfWork.GetProductsAsync(id).ConfigureAwait(false);
                this.SetCache<List<SelectOptions>>(key, products);
            }

            return Json(products, base.JsonSettings);
        }

        public async Task<JsonResult> GetProfiles(int userId)
        {
            var profiles = await this.UnitOfWork.GetProfilesAsync(userId).ConfigureAwait(false);

            return Json(profiles, base.JsonSettings);
        }

        public async Task<JsonResult> GetProductGroups()
        {
            string key = "ProductGropus";
            var productGropus = this.GetCache<List<SelectOptions>>(key);
            if (productGropus == null)
            {
                productGropus = await this.UnitOfWork.GetProductGroupsAsync().ConfigureAwait(false);
                this.SetCache<List<SelectOptions>>(key, productGropus);
            }

            return Json(productGropus, base.JsonSettings);
        }

        public async Task<JsonResult> GetSubmitters()
        {
            string key = "Submitters";
            var submitters = this.GetCache<List<SelectOptions>>(key);
            if (submitters == null)
            {
                submitters = await this.UnitOfWork.GetSubmittersAsync().ConfigureAwait(false);
                this.SetCache<List<SelectOptions>>(key, submitters);
            }

            return Json(submitters, base.JsonSettings);
        }

        public async Task<JsonResult> GetApprovers()
        {
            string key = "Approvers";
            var approvers = this.GetCache<List<SelectOptions>>(key);
            if (approvers == null)
            {
                approvers = await this.UnitOfWork.GetApproversAsync().ConfigureAwait(false);
                this.SetCache<List<SelectOptions>>(key, approvers);
            }

            return Json(approvers, base.JsonSettings);
        }

        public async Task<JsonResult> GetOwners()
        {
            string key = "Owners";
            var owners = this.GetCache<List<SelectOptions>>(key);
            if (owners == null)
            {
                owners = await this.UnitOfWork.GetOwnersAsync().ConfigureAwait(false);
                this.SetCache<List<SelectOptions>>(key, owners);
            }

            return Json(owners, base.JsonSettings);
        }

        public async Task<JsonResult> GetProductLines()
        {
            string key = "ProductLines";
            var productLines = this.GetCache<List<SelectOptions>>(key);
            if (productLines == null)
            {
                productLines = await this.UnitOfWork.GetProductLinesAsync().ConfigureAwait(false);
                this.SetCache<List<SelectOptions>>(key, productLines);
            }

            return Json(productLines, base.JsonSettings);
        }

        public async Task<JsonResult> GetBusinessSegments()
        {
            string key = "BusinessSegment";
            var businessSegment = this.GetCache<List<SelectOptions>>(key);
            if (businessSegment == null)
            {
                businessSegment = await this.UnitOfWork.GetBusinessSegmentsAsync().ConfigureAwait(false);
                this.SetCache<List<SelectOptions>>(key, businessSegment);
            }

            return Json(businessSegment, base.JsonSettings);
        }

        [HttpPost]
        [Route("product/product/QueryActionReport")]
        public async Task<IActionResult> QueryActionReport([FromForm]QueryActionPostModel queryActionViewModel)
        {
            var ReportResult = await this.UnitOfWork.GetActionReportAdvancedAsync(queryActionViewModel).ConfigureAwait(false);

            return View(ReportResult);
        }

        [HttpPost]
        [Route("product/product/QueryActionReportExport")]
        public async Task<IActionResult> QueryActionReportExport([FromForm]QueryActionPostModel queryActionViewModel)
        {
            var ReportResult = await this.UnitOfWork.GetActionReportAdvancedAsync(queryActionViewModel).ConfigureAwait(false);

            return View(ReportResult);
        }

        #endregion

        #region FileUpload
        [HttpGet]
        [Route("/product/Product/FileUpload")]
        public async Task<IActionResult> FileUpload()
        {
            var fileUpload = new FileUploadViewModel { Folder = Request.Query[""], Title = Request.Query["Title"], ControlId = Convert.ToInt32(Request.Query["ControlId"]) };
            await Task.Delay(1);
            return View("FileUpload", fileUpload);
        }

        //[HttpPost]
        //[Route("/product/Product/SaveFilePath")]
        //public async Task<IActionResult> SaveFilePath(FileUploadViewModel file)
        //{            
        //    var fileLocation = string.Empty;
        //    var destinationFolder = Path.GetRandomFileName();
        //    var fileStorePath = "\\" + "\\PULSARJOBS02.auth.hpicorp.net\\ExcaliburFileStore$";
        //    if (!string.IsNullOrEmpty(file.FilePath))
        //    {
        //        var destPath = Path.Combine(fileStorePath, destinationFolder);
        //        if (!Directory.Exists(destPath))
        //        {
        //            Directory.CreateDirectory(destPath);
        //        }
        //        fileLocation = Path.Combine(destPath, Path.GetFileName(file.FilePath));
        //        System.IO.File.Copy(file.FilePath, fileLocation, true);
        //    }
        //    return this.Json(fileLocation);
        //}

        [HttpPost]
        [Route("/Product/Product/SaveFilePath/ControlId/")]
        public async Task<IActionResult> SaveFilePath(int ControlId, ICollection<IFormFile> files)
        {
            SaveFileUploadViewModel saveFileUpload = new SaveFileUploadViewModel();
            // full path to file in temp location
            var filePath = Path.GetTempFileName();
            var destinationFolder = Path.GetRandomFileName();
            var fileStorePath = "\\" + AppSettings.Get<string>("ServerName:FileStorePath");
            var destPath = Path.Combine(fileStorePath, destinationFolder);
            var fileLocation = "";
            foreach (var formFile in files)
            {
                if (formFile.Length > 0)
                {
                    if (!Directory.Exists(destPath))
                    {
                        Directory.CreateDirectory(destPath);
                    }
                    fileLocation = Path.Combine(destPath, Path.GetFileName(formFile.FileName));
                    using (var stream = new FileStream(fileLocation, FileMode.Create))
                    {
                        await formFile.CopyToAsync(stream).ConfigureAwait(false);
                        //formFile.CopyTo()
                    }

                }
            }

            saveFileUpload.ControlId = ControlId;
            saveFileUpload.FileLocation = fileLocation;
            return View("SaveFileUpload", saveFileUpload);
        }

        [HttpPost]
        [Route("/Product/Product/SaveImageFilePath")]
        public async Task<IActionResult> SaveImageFilePath(ICollection<IFormFile> files)
        {
            SaveFileUploadViewModel saveFileUpload = new SaveFileUploadViewModel();
            // full path to file in temp location
            var filePath = Path.GetTempFileName();
            var destinationFolder = Path.GetRandomFileName();
            var fileStorePath = "\\" + AppSettings.Get<string>("ServerName:FileStorePath");
            var destPath = Path.Combine(fileStorePath, destinationFolder);
            var fileLocation = "";
            var newFileLocation = "";
            foreach (var formFile in files)
            {
                if (formFile.Length > 0)
                {
                    if (!Directory.Exists(destPath))
                    {
                        Directory.CreateDirectory(destPath);
                    }
                    fileLocation = Path.Combine(destPath, Path.GetFileName(formFile.FileName));
                    using (var stream = new FileStream(fileLocation, FileMode.Create))
                    {
                        await formFile.CopyToAsync(stream).ConfigureAwait(false);
                        //formFile.CopyTo()
                    }

                    newFileLocation = Path.Combine(destPath, Regex.Replace(Path.GetFileName(formFile.FileName), @"\s", ""));
                    FileInfo f = new FileInfo(fileLocation);
                    f.CopyTo(newFileLocation);
                    f.Delete();
                }
            }
            saveFileUpload.FileLocation = newFileLocation;
            return this.Json(saveFileUpload);
        }

        #endregion

        #region EmailUsers

        [HttpGet]
        [Route("product/product/GetEmailUsers")]
        public async Task<IActionResult> GetEmailUsers()
        {
            await Task.Delay(1);
            return View("GetEmailUsers");
        }

        [HttpGet]
        [Route("product/product/GetEmailUsersDetails")]
        public async Task<IActionResult> GetEmailUsersDetails()
        {
            await Task.Delay(1);
            return View("GetEmailUsersDetails");
        }



        public async Task<IActionResult> GetEmailDetails(int ticketId)
        {
            EmployeeViewModel employee = new EmployeeViewModel();
            StringBuilder body = new StringBuilder();

            var ticketInfo = await this.UnitOfWork.GetSupportTicketInfoAsync(ticketId).ConfigureAwait(false);
            employee.Subject = "Pulsar Ticket System -#" + ticketInfo.ID + " - " + ticketInfo.Summary;
            employee.ToEmailIds = ticketInfo.OwnerEmail + ";" + ticketInfo.SubmitterEmail;
            body.Append("Ticket Information");
            body.Append(Environment.NewLine);
            body.Append(Environment.NewLine);
            body.Append("Working Notes -");
            body.Append(Environment.NewLine);
            body.Append(ticketInfo.Details);
            employee.EmailBody = body.ToString();
            return View("GetEmailTemplate", employee);
        }

        [HttpGet]
        [Route("product/product/GenerateUserEmails")]
        public async Task<IActionResult> GenerateUserEmails(EmployeeViewModel emailDetails)
        {
            emailDetails = await this.UnitOfWork.GetEmployeeEmailAsync(emailDetails).ConfigureAwait(false);
            emailDetails.Email = CurrentUserProfile.Email;
            return this.Json(emailDetails);
        }

        [HttpPost]
        [Route("product/product/SendEmailToUsers")]
        public async Task<IActionResult> SendEmailToUsers(EmployeeViewModel emailDetails)
        {
            var result = string.Empty;
            if (HttpContext.Request.IsHttps)
            {                
                if (emailDetails != null)
                {
                    emailDetails.CcRecipients = !string.IsNullOrEmpty(AppSettings.Get<string>("EmailConfiguration:MandateCCRecipients")) ? AppSettings.Get<string>("EmailConfiguration:mandateCCRecipients") : string.Empty;
                    try
                    {
                        result = await this.UnitOfWork.SendEmailToUsersAsync(emailDetails).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
            else
            {
                throw new Exception("Please use the PRP Secure URL for send the Email from your Name.");
            }
            
            return this.Json(result);
        }
        #endregion

        #region Milestone Pulsar Insert
        [HttpGet]
        [Route("product/product/LoadMilestonePulsar/{productVersionId?}/{scheduleId?}")]
        public async Task<IActionResult> LoadMilestonePulsar(string productVersionId = "", string scheduleId = "")
        {
            var milestonePulsar = default(MilestonePulsarViewModel);
            milestonePulsar = await this.UnitOfWork.LoadMilestonePulsarAsync(productVersionId, scheduleId).ConfigureAwait(false);
            return View("MilestoneInsertPulsar", milestonePulsar);
        }

        [HttpPost]
        [Route("product/product/SaveMilestonePulsar")]
        public async Task<IActionResult> SaveMilestonePulsar(MilestonePulsarViewModel milestonePulsar)
        {
            var message = string.Empty;
            if (milestonePulsar != null)
            {
                milestonePulsar.CurrentUserId = CurrentUserProfile.UserId;
                milestonePulsar.CurrentUserName = CurrentUserProfile.UserName;
                message = await this.UnitOfWork.SaveMilestonePulsarAsync(milestonePulsar).ConfigureAwait(false);
            }
            return this.Json(message);
        }
        #endregion

        #region GetActionReportForMobileSE

        [HttpGet]
        [Route("product/product/GetActionReportMobileSE/{actions}/{id}/{type}")]
        public async Task<IActionResult> GetActionReportMobileSE(int actions, int id, int type)
        {
            var actionReportMobileSEVM = await this.UnitOfWork.GetActionReportForMobileSEAsync(actions, id, type, this.CurrentUserProfile.UserId, this.CurrentUserProfile.UserName).ConfigureAwait(false);
            ViewData["Title"] = "Change Request";
            return View("GetActionReportMobileSE", actionReportMobileSEVM);
        }


        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("product/product/SendActionEmail")]
        public async Task<IActionResult> SendActionEmail(ActionReportMobileSEViewModel actionReportMobileSEMail)
        {
            var message = await this.UnitOfWork.SendActionEmailAsync(actionReportMobileSEMail, this.CurrentUserProfile.Email).ConfigureAwait(false);
            return this.Json(message);
        }

        #endregion

        #region MilestoneListMain
        [HttpGet]
        [Route("product/product/GetScheduleMilestoneData/{productId}/{scheduleId}")]
        public async Task<IActionResult> GetScheduleMilestoneData(int productId, int scheduleId)
        {
            MilestoneListDataViewModel milestones = await this.UnitOfWork.GetScheduleMilestonesAsync(productId, scheduleId).ConfigureAwait(false);
            milestones.ProductId = productId;
            milestones.ScheduleId = scheduleId;
            return View(milestones);
        }

        #endregion

        #region Av Marketing Detail
        [HttpGet]
        [Route("/product/product/GetAvMarketingDetail/{productVersionId}/{productBrandId}/{avDetailId}")]
        public async Task<IActionResult> GetAvMarketingDetail(int productVersionId, int productBrandId, int avDetailId)
        {
            var avMarketingDetails = await this.UnitOfWork.GetAvMarketingDetailAsync(productVersionId, productBrandId, avDetailId).ConfigureAwait(false);
            return View("AvMarketingDetail", avMarketingDetails);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        [Route("product/product/UpdatAvMarketingDetail")]
        public async Task<IActionResult> UpdatAvMarketingDetail([FromBody]UpdateAvMarketingDetail updateAvMarketingDetail)
        {
            var status = await this.UnitOfWork.UpdateAvMarketingDetailAsync(updateAvMarketingDetail, CurrentUserProfile.UserId, CurrentUserProfile.UserName).ConfigureAwait(false);
            return this.Json(status);
        }

        #endregion

        #region Deliverables
        [HttpGet]
        [Route("product/product/GetDeliverablesReport")]
        public async Task<IActionResult> GetDeliverablesReport(int hardwareMatrix, int commodityMatrix, int categoryId)
        {
            DeliverablesInputViewModel deliverablesInputViewModel = new DeliverablesInputViewModel();
            deliverablesInputViewModel.HardwareMatrix = hardwareMatrix;
            deliverablesInputViewModel.CommodityMatrix = commodityMatrix;
            deliverablesInputViewModel.PartnerId = CurrentUserProfile.PartnerId;
            deliverablesInputViewModel.EmployeeId = CurrentUserProfile.UserId;

            if (CurrentUserProfile.Division != null)
            {
                deliverablesInputViewModel.DivisionId = Convert.ToInt32(CurrentUserProfile.Division);
            }
            deliverablesInputViewModel.IsAdmin = CurrentUserProfile.IsSystemAdmin;

            var deliverablesViewModel = await this.UnitOfWork.GetDeliverablesReportAsync(deliverablesInputViewModel).ConfigureAwait(false);
            deliverablesViewModel.CategoryId = categoryId;
            deliverablesViewModel.HardwareMatrix = hardwareMatrix;
            deliverablesViewModel.ProductFilterLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:ProductFilterLimit"));
            deliverablesViewModel.ErrorMessage = string.Format(AppSettings.Get<string>("HWQualMatrix:ErrorMessage"), AppSettings.Get<string>("HWQualMatrix:ProductFilterLimit"));
            return View("Deliverables", deliverablesViewModel);
        }

        [HttpGet]
        [Route("product/Product/GetDeliverableRoots")]
        public async Task<IActionResult> GetDeliverableRoots(int pageNumber, int pageSize, int hardwareMatrix, int commodityMatrix,string searchString)
        {
            searchString = searchString == null ? string.Empty : searchString;
            var deliverablesRoots = await this.UnitOfWork.GetDeliverableRootsAsync(pageNumber, pageSize, hardwareMatrix, commodityMatrix, CurrentUserProfile.PartnerId,searchString).ConfigureAwait(false);
            return Json(deliverablesRoots);
        }

        [HttpGet]
        [Route("product/Product/GetUserSetting")]
        [ProducesResponseType(typeof(string[]), 200)] 
        [ProducesResponseType(typeof(string[]), 404)]
        public async Task<IActionResult> GetUserSetting()
        {
            var userSettings = await this.UnitOfWork.GetUserSettingAsync(CurrentUserProfile.UserId).ConfigureAwait(false);
            return this.Json(userSettings);
        }
        [HttpGet]
        [Route("product/Product/GetDevManagers")]
        [ProducesResponseType(typeof(EmployeeViewModel[]), 200)]
        [ProducesResponseType(typeof(EmployeeViewModel[]), 404)]
        public async Task<IActionResult> GetDevManagers()
        {
            var devManagers = await this.UnitOfWork.GetDevManagersAsync().ConfigureAwait(false);
            return this.Ok(devManagers);
        }
        [HttpGet]
        [Route("product/Product/GetAllProducts")]
        [ProducesResponseType(typeof(DeliverablesViewModel), 200)]
        [ProducesResponseType(typeof(DeliverablesViewModel), 404)]
        public async Task<IActionResult> GetAllProducts(int? id, int hardwareMatrix)
        {
            string key = "AllProducts" + hardwareMatrix.ToString();
            var deliverableProducts = this.GetCache<DeliverablesViewModel>(key);
            if (deliverableProducts == null)
            {
                deliverableProducts = await this.UnitOfWork.GetAllProductsAsync(id, hardwareMatrix).ConfigureAwait(false);
                this.SetCache<DeliverablesViewModel>(key, deliverableProducts);
            }
            return this.Ok(deliverableProducts);
        }
        #endregion

        #region AvFrame
        [HttpGet]
        [Route("/product/product/ShowAvData/{mode}/{productVersionId}/{avDetailId}/{productBrandId}/{userId}")]
        public async Task<IActionResult> ShowAvData(string mode, int productVersionId, int avDetailId, int productBrandId, string userId)
        {
            int currentUserId = GetImpersonateIdOrUserId();
            var showAvDataModel = await this.UnitOfWork.ShowAvDataAsync(mode, productVersionId, avDetailId, productBrandId, currentUserId, CurrentUserProfile.MarketingProductCount, CurrentUserProfile).ConfigureAwait(false);
            return View(showAvDataModel);
        }

        #endregion

        #region Sync Selected Products
        [HttpPost]
        [Route("/product/Product/SyncSelectedProducts")]
        public async Task<IActionResult> SyncSelectedProducts([FromBody]ProductViewModel productViewModel)
        {
            var status = default(bool);
            if (!string.IsNullOrEmpty(productViewModel.Product))
            {
                var userProfile = string.Concat(CurrentUserProfile.UserId, "_", CurrentUserProfile.UserName, "_", CurrentUserProfile.LoginDomain);
                status = await this.UnitOfWork.TrySyncSelectedProductsAsync(productViewModel.Product, userProfile).ConfigureAwait(false);
            }
            return this.Json(status);
        }
        #endregion

        #region Today Action        

        [HttpGet]
        [Route("/product/product/TodayAction/{deliverableIssueId}/{crType}/{prodId}/{categoryId}/{layout?}")]
        public async Task<IActionResult> TodayAction(int deliverableIssueId, string crType, int prodId, int categoryId, string layout)
        {
            var todayActionParams = await this.UnitOfWork.TodayActionAsync(deliverableIssueId, crType, CurrentUserProfile).ConfigureAwait(false);
            todayActionParams.Layout = layout;            
            return View("Action", todayActionParams);
        }

        [HttpGet]
        [Route("/product/product/GetTodayAction/{deliverableIssueId}/{crType}/{prodId}/{categoryId}/{layout?}")]
        public async Task<IActionResult> GetTodayAction(int deliverableIssueId, string crType, int? prodId, int categoryId, string layout)
        {
            var todayAction = await this.UnitOfWork.GetTodayActionAsync(deliverableIssueId, crType, CurrentUserProfile).ConfigureAwait(false);
            todayAction.Layout = layout;
            todayAction.ProductId = prodId;
            return View("TodayAction", todayAction);
        }

        [HttpGet]
        //[ProducesResponseType(typeof(bool), 200)]
        //[ProducesResponseType(typeof(bool), 404)]
        [Route("/product/product/GetTodayActionMain/{deliverableIssueId}/{crType}/{prodId}/{categoryId}")]
        public IActionResult GetTodayActionMain(int deliverableIssueId, string crType, int prodId, int categoryId)
        {
            TodayActionParams todayActionParams = new TodayActionParams();
            todayActionParams.DeliverableIssueId = deliverableIssueId;
            todayActionParams.CrType = crType;
            todayActionParams.ProdId = prodId;
            todayActionParams.CategoryId = categoryId;
            return View("TodayActionIndex", todayActionParams);
        }

        [HttpPost]
        [Route("/Product/Product/UpdateTodayAction")]
        public async Task UpdateTodayAction([FromForm]TodayActionUpdateViewModel todayAction)
        {
            var status = await this.UnitOfWork.UpdateTodayActionsAsync(todayAction, CurrentUserProfile).ConfigureAwait(false);
            //TodayActionViewModel todayactionmodel = new TodayActionViewModel();
            //todayactionmodel.SaveStatus = status;
            //return View("TodayActionSaveStatus", todayAction.Layout);
        }

        [HttpGet]
        [Route("/product/product/GetTodayActionPmView/{deliverableIssueId}/{crType}/{prodId}/{categoryId}")]
        public async Task<IActionResult> GetTodayActionPmView(int deliverableIssueId, string crType, int prodId, int categoryId)
        {
            var todayAction = this.GetCache<TodayActionViewModel>("TodayActionWithprodsearch");
            if (deliverableIssueId == 0)
            {
                //todayAction = this.GetCache<TodayActionViewModel>("TodayActionWithprodsearch");
                //var todayAction = await this.UnitOfWork.GetTodayActionPmView(deliverableIssueId, crType, CurrentUserProfile);
                if (todayAction == null)
                {
                    todayAction = await this.UnitOfWork.GetTodayActionPmViewAsync(deliverableIssueId, crType, CurrentUserProfile).ConfigureAwait(false);
                    this.SetCache<TodayActionViewModel>("TodayActionWithprodsearch", todayAction);
                }
            }
            else
            {
                todayAction = null;
                todayAction = await this.UnitOfWork.GetTodayActionPmViewAsync(deliverableIssueId, crType, CurrentUserProfile).ConfigureAwait(false);
            }

            return View("TodayActionPmView", todayAction);
        }

        [HttpGet]
        [Route("/product/product/GetTodayActionProdSearch")]
        public async Task<IActionResult> GetTodayActionProdSearch()
        {
            var todayAction = this.GetCache<TodayActionProdSearchViewModel>("prodsearch");
            if (todayAction == null)
            {
                todayAction = await this.UnitOfWork.GetTodayActionProdSearchAsync().ConfigureAwait(false);
                this.SetCache<TodayActionProdSearchViewModel>("prodsearch", todayAction);
            }

            return PartialView("TodayActionProductSearch", todayAction);
        }

        [HttpPost]
        //[Route("/product/product/GetTodayActionProdSearchById/")]
        public async Task<IActionResult> GetTodayActionProdSearchById(string productIds)
        {
            var actionItemDetail = await this.UnitOfWork.GetTodayActionProdSearchByIdAsync(productIds).ConfigureAwait(false);
            var result = new
            {
                //recordCountKey = actionItemDetail.Select(m => m.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = actionItemDetail
            };
            return Json(result, base.JsonSettings);
        }

        [HttpGet]
        [Route("/product/product/GetTodayActionProd")]
        public async Task<JsonResult> GetTodayActionProd()
        {
            var todayAction = this.GetCache<TodayActionProdSearchViewModel>("prodsearch");
            if (todayAction == null)
            {
                todayAction = await this.UnitOfWork.GetTodayActionProdSearchAsync().ConfigureAwait(false);
                this.SetCache<TodayActionProdSearchViewModel>("prodsearch", todayAction);
            }

            return Json(todayAction, base.JsonSettings);
        }

        #endregion

        #region AV Details
        [HttpGet]
        [Route("/Product/Product/GetAVDetails")]
        public async Task<IActionResult> GetAVDetails(int productVersionId, int productBrandId, int avDetailId, string mode, string abbreviation, string release, bool isMarketingUser, string scmCat, string fromTodayPage, string fID, string fName, string fRequiresRoot, string fComponentLinkage, string fComponentRootID, string fGPGDescription, string fMarketingDescriptionPMG, string fMarketingDescription, string fSCMCategoryIDSinglefeature, string aliasID, string platform)
        {
            var avDetails = await this.UnitOfWork.GetAVDetailsAsync(this.CurrentUserProfile.UserId, productVersionId, productBrandId, avDetailId, mode, release, isMarketingUser).ConfigureAwait(false);
            avDetails.Abbreviation = abbreviation;
            avDetails.isMarketingUser = isMarketingUser;
            avDetails.ProductVersionId = productVersionId;
            avDetails.QueryStringSCMCat = scmCat;
            avDetails.FromTodayPage = fromTodayPage;
            avDetails.BId = productBrandId;
            avDetails.FID = fID;
            avDetails.FName = fName;
            avDetails.FRequiresRoot = fRequiresRoot;
            avDetails.FComponentLinkage = fComponentLinkage;
            avDetails.FComponentRootID = fComponentRootID;
            avDetails.FGPGDescription = fGPGDescription;
            avDetails.FMarketingDescriptionPMG = fMarketingDescriptionPMG;
            avDetails.FMarketingDescription = fMarketingDescription;
            avDetails.FSCMCategoryIDSinglefeature = fSCMCategoryIDSinglefeature;
            avDetails.QueryStringAliasID = aliasID;
            avDetails.Platform = platform;
            return View("GetAVDetails", avDetails);
        }

        [HttpPost]
        [Route("/Product/Product/InsertAVDetail")]
        public async Task InsertAVDetail([FromForm]AVDetailViewModel avDetailInfo)
        {
            avDetailInfo.User = CurrentUserProfile.UserName;
            avDetailInfo.UserId = GetPmIdOrImpersonateIdOrUserId();
            await this.UnitOfWork.InserAsynctAVDetail(avDetailInfo).ConfigureAwait(false);
        }
        #endregion

        #region Hardware Matrix
        [HttpGet]
        [Route("/product/product/GetHardwareMatrix")]
        public async Task<IActionResult> GetHardwareMatrix(HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var matrixUrl = string.Empty;
            List<string> matrixUrls = new List<string>();
            Dictionary<string, string> drawBox = new Dictionary<string, string>();

            if (Request.Query.Count == 0)
            {
                hardwareMatrixInput.QueryString = string.Empty;
                hardwareMatrixInput.RequestQueryString = string.Empty;
            }
            else
            {
                foreach (var item in Request.Query)
                {
                    hardwareMatrixInput.QueryString += item.Key + "=" + item.Value + "&";
                    matrixUrl = item.Key.ToLower();
                    drawBox.Add(item.Key, item.Value);

                    matrixUrls.Add(matrixUrl);
                }
                hardwareMatrixInput.QueryString = hardwareMatrixInput.QueryString.Substring(0, hardwareMatrixInput.QueryString.Length - 1);
                hardwareMatrixInput.QueryStrings = matrixUrls;
                hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
                hardwareMatrixInput.InputValue = drawBox;
            }
            hardwareMatrixInput.UserId = this.CurrentUserProfile.UserId;
            hardwareMatrixInput.PartnerId = this.CurrentUserProfile.PartnerId.HasValue ? this.CurrentUserProfile.PartnerId.Value : default(int);
            hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
            var hardwareMatrixDetails = await this.UnitOfWork.GetHardwareMatrixAsync(hardwareMatrixInput).ConfigureAwait(false);
            if (hardwareMatrixInput.IsExcel == 1)
            {
                return View("GetProductHardwareMatrixExcelExport", hardwareMatrixDetails);
            }
            else
            {
                return View("GetProductHardwareMatrix", hardwareMatrixDetails);
            }
        }

        [HttpGet]
        [Route("/product/product/GetProductHardwareMatrixForExportExcel")]
        public async Task<IActionResult> GetProductHardwareMatrixForExportExcel(HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var matrixUrl = string.Empty;
            List<string> matrixUrls = new List<string>();
            Dictionary<string, string> drawBox = new Dictionary<string, string>();

            if (Request.Query.Count == 0)
            {
                hardwareMatrixInput.QueryString = string.Empty;
                hardwareMatrixInput.RequestQueryString = string.Empty;
            }
            else
            {
                foreach (var item in Request.Query)
                {
                    hardwareMatrixInput.QueryString += item.Key + "=" + item.Value + "&";
                    matrixUrl = item.Key.ToLower();
                    drawBox.Add(item.Key, item.Value);

                    matrixUrls.Add(matrixUrl);
                }
                hardwareMatrixInput.QueryString = hardwareMatrixInput.QueryString.Substring(0, hardwareMatrixInput.QueryString.Length - 1);
                hardwareMatrixInput.QueryStrings = matrixUrls;
                hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
                hardwareMatrixInput.InputValue = drawBox;
            }
            hardwareMatrixInput.UserId = this.CurrentUserProfile.UserId;
            hardwareMatrixInput.PartnerId = this.CurrentUserProfile.PartnerId.HasValue ? this.CurrentUserProfile.PartnerId.Value : default(int);
            hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
            hardwareMatrixInput.Type = 1;
            hardwareMatrixInput.IsExcel = 1;
            //HardwareMatrixViewModel hardwareMatrixDetails = new HardwareMatrixViewModel();
            GridModel grid = await GetProductHardwareMatrixModel(hardwareMatrixInput, null).ConfigureAwait(false);
            HardwareMatrixViewModel hardwareMatrixDetails = new HardwareMatrixViewModel();
            hardwareMatrixDetails.HardwareMatrixGrid = grid;
            return View("GetProductHardwareMatrixExcelExport", hardwareMatrixDetails);

        }
        [HttpGet]
        [Route("/product/product/GetProductHardwareMatrix")]
        public async Task<IActionResult> GetProductHardwareMatrix(HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var matrixUrl = string.Empty;
            List<string> matrixUrls = new List<string>();
            Dictionary<string, string> drawBox = new Dictionary<string, string>();

            if (Request.Query.Count == 0)
            {
                hardwareMatrixInput.QueryString = string.Empty;
                hardwareMatrixInput.RequestQueryString = string.Empty;
            }
            else
            {
                foreach (var item in Request.Query)
                {
                    hardwareMatrixInput.QueryString += item.Key + "=" + item.Value + "&";
                    matrixUrl = item.Key.ToLower();
                    drawBox.Add(item.Key, item.Value);

                    matrixUrls.Add(matrixUrl);
                }
                hardwareMatrixInput.QueryString = hardwareMatrixInput.QueryString.Substring(0, hardwareMatrixInput.QueryString.Length - 1);
                hardwareMatrixInput.QueryStrings = matrixUrls;
                hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
                hardwareMatrixInput.InputValue = drawBox;
            }
            hardwareMatrixInput.UserId = this.CurrentUserProfile.UserId;
            hardwareMatrixInput.PartnerId = this.CurrentUserProfile.PartnerId.HasValue ? this.CurrentUserProfile.PartnerId.Value : default(int);
            hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
            hardwareMatrixInput.GridColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:GridColumnLimit"));
            hardwareMatrixInput.ExcelColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));
            //HardwareMatrixViewModel hardwareMatrixDetails = new HardwareMatrixViewModel();
            hardwareMatrixInput.Type = 1;
            PaginationModel pagination = new PaginationModel();
            pagination.PageNo = 1;
            pagination.PageSize = 100;
            hardwareMatrixInput.Pagination = pagination;

            var hardwareMatrixDetail = await this.GetHardwareQualMatrix(hardwareMatrixInput, true).ConfigureAwait(false);
            GridModel grid = null;
            if (hardwareMatrixDetail != null)
            {
                if (hardwareMatrixDetail.RowData != null && hardwareMatrixDetail.RowData.Count() == 1)
                {
                    foreach (var columns in hardwareMatrixDetail.RowData[0])
                    {
                        if (columns.Key == "ErrorMessage")
                        {
                            ViewBag.ErrorMessage = string.Format(AppSettings.Get<string>("HWQualMatrix:ErrorMessage"), AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));
                            //return model;
                        }
                    }
                }
                else if (!string.IsNullOrEmpty(hardwareMatrixDetail.Products))
                {
                    var productCount = hardwareMatrixDetail.Products.Split(",").Count();
                    if (productCount <= hardwareMatrixInput.GridColumnLimit)
                    {
                        grid = await GetProductHardwareMatrixModel(hardwareMatrixInput, hardwareMatrixDetail).ConfigureAwait(false);
                    }
                    else if (productCount <= hardwareMatrixInput.ExcelColumnLimit)
                    {
                        ViewBag.ErrorMessage = "IsExcel";
                    }
                }
                if (!string.IsNullOrEmpty(hardwareMatrixDetail.Products) && !hardwareMatrixDetail.Products.Contains(","))
                {
                    hardwareMatrixInput.ProductTitle = hardwareMatrixDetail.Products + " ";
                }
            }
            var hardwareMatrixDetails = await this.UnitOfWork.GetProductHardwareMatrixAsync(hardwareMatrixInput).ConfigureAwait(false);
            hardwareMatrixDetails.HardwareMatrixGrid = grid;
            if (hardwareMatrixInput.IsExcel == 1)
            {
                return View("GetProductHardwareMatrixExcelExport", hardwareMatrixDetails);
            }
            else
            {
                return View("GetProductHardwareMatrix", hardwareMatrixDetails);
            }
        }


        [HttpPost]
        [Route("/product/product/GetProductHardwareMatrixDetails")]
        public async Task<IActionResult> GetProductHardwareMatrixDetails([FromForm]HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var matrixUrl = string.Empty;
            List<string> matrixUrls = new List<string>();
            Dictionary<string, string> drawBox = new Dictionary<string, string>();

            if (Request.Form.Count() == 0)
            {
                hardwareMatrixInput.QueryString = string.Empty;
                hardwareMatrixInput.RequestQueryString = string.Empty;
            }
            else
            {

                foreach (var item in Request.Form)
                {
                    if (!string.IsNullOrEmpty(item.Value))
                    {
                        switch (item.Key)
                        {
                            case "lstProducts":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstProducts + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstProducts);
                                break;
                            case "lstProductsPulsar":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstProductsPulsar + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstProductsPulsar);
                                break;
                            case "lstProductGroups":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstProductGroups + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstProductGroups);
                                break;
                            case "lstQualStatus":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstQualStatus + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstQualStatus);
                                break;
                            case "lstCategory":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstCategory + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstCategory);
                                break;
                            case "lstCommodityPM":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstCommodityPM + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstCommodityPM);
                                break;
                            case "lstDevManager":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstDevManager + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstDevManager);
                                break;
                            case "lstRoot":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstRoot + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstRoot);
                                break;
                            case "lstVendor":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstVendor + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstVendor);
                                matrixUrls.Add(matrixUrl);
                                break;
                            case "lstTeamID":

                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstTeamID + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstTeamID);
                                matrixUrls.Add(matrixUrl);
                                break;
                            case "txtStartDate":
                                hardwareMatrixInput.StartDate = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.StartDate + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.StartDate);
                                break;
                            case "txtEndDate":
                                hardwareMatrixInput.EndDate = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.EndDate + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.EndDate);
                                break;
                            case "txtSpecificPilotStatus":
                                hardwareMatrixInput.SpecificPilotStatus = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.SpecificPilotStatus + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.SpecificPilotStatus);
                                break;
                            case "txtSpecificQualStatus":
                                hardwareMatrixInput.SpecificQualStatus = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.SpecificQualStatus + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.SpecificQualStatus);
                                break;
                            case "cboHistoryRange":
                                hardwareMatrixInput.HistoryRange = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.HistoryRange + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.HistoryRange);
                                break;
                            case "txtHistoryDays":
                                hardwareMatrixInput.NoOfHistoryDays = Convert.ToInt32(item.Value);
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.NoOfHistoryDays + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.NoOfHistoryDays.ToString());
                                break;
                            default:
                                hardwareMatrixInput.QueryString += item.Key + "=" + item.Value + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, item.Value);
                                matrixUrls.Add(matrixUrl);
                                break;
                        }
                    }
                }

                hardwareMatrixInput.QueryString = hardwareMatrixInput.QueryString.Substring(0, hardwareMatrixInput.QueryString.Length - 1);
                hardwareMatrixInput.QueryStrings = matrixUrls;
                hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
                hardwareMatrixInput.InputValue = drawBox;
            }
            hardwareMatrixInput.UserId = this.CurrentUserProfile.UserId;
            hardwareMatrixInput.PartnerId = this.CurrentUserProfile.PartnerId.HasValue ? this.CurrentUserProfile.PartnerId.Value : default(int);
            hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
            //var hardwareMatrixDetails = await this.UnitOfWork.GetHardwareMatrix(hardwareMatrixInput);
            //return View("GetHardwareMatrix", hardwareMatrixDetails);
            if (hardwareMatrixInput.IsDeliverable == 1)
                hardwareMatrixInput.Type = 0;
            else
                hardwareMatrixInput.Type = 1;

            PaginationModel pagination = new PaginationModel();
            pagination.PageNo = 1;
            pagination.PageSize = 100;
            hardwareMatrixInput.Pagination = pagination;
            hardwareMatrixInput.GridColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:GridColumnLimit"));
            hardwareMatrixInput.ExcelColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));

            var hardwareMatrixDetail = await this.GetHardwareQualMatrix(hardwareMatrixInput, true).ConfigureAwait(false);
            GridModel grid = null;
            if (hardwareMatrixDetail != null)
            {
                if (hardwareMatrixDetail.RowData != null && hardwareMatrixDetail.RowData.Count() == 1)
                {
                    foreach (var columns in hardwareMatrixDetail.RowData[0])
                    {
                        if (columns.Key == "ErrorMessage")
                        {
                            ViewBag.ErrorMessage = string.Format(AppSettings.Get<string>("HWQualMatrix:ErrorMessage"), AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));
                            //return model;
                        }
                    }
                }
                else if (!string.IsNullOrEmpty(hardwareMatrixDetail.Products))
                {
                    var productCount = hardwareMatrixDetail.Products.Split(",").Count();
                    if (productCount <= hardwareMatrixInput.GridColumnLimit)
                    {
                        grid = await GetProductHardwareMatrixModel(hardwareMatrixInput, hardwareMatrixDetail).ConfigureAwait(false);
                    }
                    else if (productCount <= hardwareMatrixInput.ExcelColumnLimit)
                    {
                        ViewBag.ErrorMessage = "IsExcel";
                    }
                }
                if (!string.IsNullOrEmpty(hardwareMatrixDetail.Products) && !hardwareMatrixDetail.Products.Contains(","))
                {
                    hardwareMatrixInput.ProductTitle = hardwareMatrixDetail.Products + " ";
                }
            }
            //GridModel grid = await GetProductHardwareMatrixModel(hardwareMatrixInput, null);
            //var result = this.GetCache<HardwareMatrixViewModel>("hardwareMatrix" + CurrentUserProfile.UserId);
            //hardwareMatrixInput.ProductTitle = result != null ? (!string.IsNullOrEmpty(result.Products) && !result.Products.Contains(",") ? result.Products : string.Empty) : string.Empty;
            var hardwareMatrixDetails = await this.UnitOfWork.GetProductHardwareMatrixAsync(hardwareMatrixInput).ConfigureAwait(false);

            hardwareMatrixDetails.HardwareMatrixGrid = grid;
            if (hardwareMatrixInput.IsDeliverable == 1)
            {
                return Json(ViewBag.ErrorMessage);
            }
            else
            {
                if (hardwareMatrixInput.IsExcel == 1)
                {
                    return View("GetProductHardwareMatrixExcelExport", hardwareMatrixDetails);
                }
                else
                {
                    return View("GetProductHardwareMatrix", hardwareMatrixDetails);
                }
            }
        }

        public string GetAlphabetsCode(int number)
        {
            int start = (int)'A' - 1;
            if (number <= 26) return ((char)(number + start)).ToString();

            StringBuilder str = new StringBuilder();
            int nxt = number;

            List<char> chars = new List<char>();

            while (nxt != 0)
            {
                int rem = nxt % 26;
                if (rem == 0) rem = 26;

                chars.Add((char)(rem + start));
                nxt = nxt / 26;

                if (rem == 26) nxt = nxt - 1;
            }


            for (int i = chars.Count - 1; i >= 0; i--)
            {
                str.Append((char)(chars[i]));
            }

            return str.ToString();
        }
        public string AddQuotes(string html)
        {
            string regExp = "=([-:.a-zA-z0-9]+)";
            string replacement = "=\"$1\"";
            return Regex.Replace(html, regExp, replacement);
        }

        public string GetBetweenStrings(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }

        [HttpGet]
        [Route("/product/product/GetProductHardwareMatrixExportToExcelValidate")]
        public async Task<ActionResult> GetProductHardwareMatrixExportToExcelValidate(HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var message = string.Empty;
            PaginationModel pagination = new PaginationModel();
            pagination.PageNo = 1;
            pagination.PageSize = 1;
            hardwareMatrixInput.Pagination = pagination;
            hardwareMatrixInput.Type = 1;
            hardwareMatrixInput.GridColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:GridColumnLimit"));
            hardwareMatrixInput.ExcelColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));
            var hardwareMatrixDetails = await this.UnitOfWork.GetProductHardwareMatrixDataAsync(hardwareMatrixInput).ConfigureAwait(false);
            if (hardwareMatrixDetails.RowData.Count() == 1 && hardwareMatrixDetails.RowData[0].ContainsKey("ErrorMessage"))
            {
                foreach (var item in hardwareMatrixDetails.RowData[0].Values)
                {
                    message = string.Format(AppSettings.Get<string>("HWQualMatrix:ErrorMessage"), AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));
                }
                return this.Json(message);
            }
            else
            {
                message = "IsExcel";
                return this.Json(message);
            }

        }


        [HttpGet]
        [Route("/product/product/GetProductHardwareMatrixExportToExcel")]
        public async Task<ActionResult> GetProductHardwareMatrixExportToExcel(HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var downloadTokenValue = hardwareMatrixInput.DownloadToken;
            if (downloadTokenValue != null)
            {
                var expireDate = DateTime.Now;
                expireDate = expireDate.AddMonths(expireDate.Month + 12);
                Microsoft.AspNetCore.Http.CookieOptions option = new Microsoft.AspNetCore.Http.CookieOptions();
                option.Expires = expireDate;
                Response.Cookies.Append("QualMatrixDownloadToken", downloadTokenValue, option);
            }


            string contentType = string.Empty;
            var stream = new MemoryStream();


            PaginationModel pagination = new PaginationModel();
            pagination.PageNo = 1;
            pagination.PageSize = 10000;
            hardwareMatrixInput.Pagination = pagination;
            hardwareMatrixInput.Type = 1;
            hardwareMatrixInput.GridColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:GridColumnLimit"));
            hardwareMatrixInput.ExcelColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));

            var hardwareMatrixDetails = await this.UnitOfWork.GetProductHardwareMatrixDataAsync(hardwareMatrixInput).ConfigureAwait(false);
            using (ExcelPackage package = new ExcelPackage())
            {

                if (hardwareMatrixDetails != null && hardwareMatrixDetails.RowData != null)
                {
                    if (hardwareMatrixDetails.RowData.Count() > 0)
                    {
                        ExcelWorksheet hardwareMatrixWorksheet = package.Workbook.Worksheets.Add("HardwareMatrix");
                        int i = 1;
                        int rowIndex = 3;
                        int headerIndex = 1;
                        string styleColor = string.Empty;
                        string cellValue = string.Empty;
                        var htmlColumns = string.Empty;
                        if (!string.IsNullOrEmpty(hardwareMatrixDetails.PageTitle))
                        {
                            hardwareMatrixWorksheet.Cells[1, 1].Style.Font.SetFromFont(new Font("Verdana", 12));
                            hardwareMatrixWorksheet.Cells[1, 1].Style.Font.Bold = true;
                            hardwareMatrixWorksheet.Cells[1, 1].Value = hardwareMatrixDetails.PageTitle;
                            hardwareMatrixWorksheet.Cells["A1:L1"].Merge = true;
                        }
                        foreach (var columns in hardwareMatrixDetails.RowData)
                        {
                            if (headerIndex == 1)
                            {

                                foreach (var column in columns)
                                {
                                    if (column.Key == "QualStatus")
                                    {
                                        if (hardwareMatrixInput.ReportFormat == 2 || hardwareMatrixInput.ReportFormat == 5)
                                        {
                                            continue;
                                        }
                                        else if (!string.IsNullOrEmpty(hardwareMatrixDetails.Products))
                                        {
                                            var productCount = hardwareMatrixDetails.Products.Split(",").Count();
                                            if (productCount > 1)
                                            {
                                                continue;
                                            }
                                        }
                                    }
                                    var alphabets = this.GetAlphabetsCode(headerIndex) + i;
                                    if (column.Key == "GroupHeader" || column.Key == "FeatureNameDesc" || column.Key == "category"
                                      || column.Key == "TotalNoOfRows" || column.Key == "DeliverableName" || column.Key == "Vendor" || column.Key == "DeliverableVersionID"
                                      || column.Key == "RootID" || column.Key == "DelRootBase")
                                    {
                                        hardwareMatrixWorksheet.Column(i).Hidden = true;
                                    }
                                    else
                                    {
                                        if (column.Key == "FeatureNameDescDisplay")
                                        {
                                            hardwareMatrixWorksheet.Cells[2, i].Value = "ID";
                                            htmlColumns = column.Value.ToString();
                                            styleColor = this.GetBetweenStrings(htmlColumns, "style=", ">");
                                            if (styleColor.Contains(";"))
                                            {
                                                string[] styleColors = styleColor.Split(";");
                                                styleColor = styleColors[0].Replace("background-color:", "");
                                            }
                                            else
                                            {
                                                styleColor = styleColor.Replace("background-color:", "");
                                            }

                                            cellValue = this.GetBetweenStrings(htmlColumns, ">", "</div>");
                                            hardwareMatrixWorksheet.Cells[headerIndex + 2, i].Value = cellValue;
                                            Color yellowColFromHex = ColorTranslator.FromHtml(styleColor);
                                            hardwareMatrixWorksheet.Cells[headerIndex + 2, i].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                            hardwareMatrixWorksheet.Cells[headerIndex + 2, i].Style.Fill.BackgroundColor.SetColor(yellowColFromHex);
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.Bold = true;
                                            hardwareMatrixWorksheet.Cells[headerIndex + 2, i, headerIndex + 2, columns.Count - 1].Merge = true;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                        }
                                        else if (column.Key == "RohsGreenSpec")
                                        {
                                            hardwareMatrixWorksheet.Cells[2, i].Value = "Rohs/GreenSpec";
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.Bold = true;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].AutoFitColumns();
                                        }
                                        else if (column.Key == "ModelVendorPartNo")
                                        {
                                            hardwareMatrixWorksheet.Cells[2, i].Value = "Model/Vendor Part No.";
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.Bold = true;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].AutoFitColumns();
                                        }
                                        else if (column.Key == "HPPartNo")
                                        {
                                            hardwareMatrixWorksheet.Cells[2, i].Value = "HP Part No.";
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.Bold = true;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].AutoFitColumns();
                                        }
                                        else if (column.Key == "DCRHFCN")
                                        {
                                            hardwareMatrixWorksheet.Cells[2, i].Value = "DCR/HFCN";
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.Bold = true;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].AutoFitColumns();
                                        }
                                        else if (column.Key == "ACode")
                                        {
                                            hardwareMatrixWorksheet.Cells[2, i].Value = "A.Code";
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.Bold = true;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].AutoFitColumns();
                                        }
                                        else if (column.Key == "ReleaseNotes")
                                        {
                                            hardwareMatrixWorksheet.Cells[2, i].Value = "Release Notes";
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.Bold = true;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].AutoFitColumns();
                                        }
                                        else
                                        {
                                            hardwareMatrixWorksheet.Cells[2, i].Value = column.Key;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Font.Bold = true;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[2, i].AutoFitColumns();
                                        }
                                        Color tancolorHex = ColorTranslator.FromHtml("#FFFFE0");
                                        hardwareMatrixWorksheet.Cells[2, i].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                        hardwareMatrixWorksheet.Cells[2, i].Style.Fill.BackgroundColor.SetColor(tancolorHex);
                                        hardwareMatrixWorksheet.Cells[2, i].AutoFitColumns();
                                    }
                                    i = i + 1;
                                }

                            }
                            else
                            {
                                int columnIndex = 1;
                                bool isCategoryHeader = false;
                                bool isSubHeader = false;
                                styleColor = string.Empty;
                                cellValue = string.Empty;
                                htmlColumns = string.Empty;
                                foreach (var column in columns)
                                {
                                    if (column.Key == "QualStatus")
                                    {
                                        if (hardwareMatrixInput.ReportFormat == 2 || hardwareMatrixInput.ReportFormat == 5)
                                        {
                                            continue;
                                        }
                                        else if (!string.IsNullOrEmpty(hardwareMatrixDetails.Products))
                                        {
                                            var productCount = hardwareMatrixDetails.Products.Split(",").Count();
                                            if (productCount > 1)
                                            {
                                                continue;
                                            }
                                        }
                                    }
                                    var alphabetOnly = this.GetAlphabetsCode(columns.Count - 1);
                                    var alphabets = this.GetAlphabetsCode(columnIndex) + rowIndex;
                                    if (column.Key == "GroupHeader" || column.Key == "FeatureNameDesc" || column.Key == "category"
                                              || column.Key == "TotalNoOfRows" || column.Key == "DeliverableName" || column.Key == "Vendor" || column.Key == "DeliverableVersionID"
                                              || column.Key == "RootID" || column.Key == "DelRootBase")
                                    {

                                        hardwareMatrixWorksheet.Column(columnIndex).Hidden = true;
                                        if (column.Key == "GroupHeader" && column.Value == "1")
                                        {

                                            isCategoryHeader = true;

                                        }
                                        if (column.Key == "GroupHeader" && column.Value == "2")
                                        {

                                            isSubHeader = true;

                                        }
                                    }

                                    else
                                    {

                                        var lastAlphabet = this.GetAlphabetsCode(columns.Count()) + rowIndex;

                                        if (column.Value != null && column.Value.Contains("<div"))
                                        {
                                            htmlColumns = column.Value.ToString();
                                            styleColor = this.GetBetweenStrings(htmlColumns, "style=", ">");
                                            if (styleColor.Contains(";"))
                                            {
                                                string[] styleColors = styleColor.Split(";");
                                                styleColor = styleColors[0].Replace("background-color:", "");
                                            }
                                            else
                                            {
                                                styleColor = styleColor.Replace("background-color:", "");
                                            }

                                            // styleColor = styleColor.Replace("background-color:", "");

                                            cellValue = this.GetBetweenStrings(htmlColumns, ">", "</div>");
                                            if (isCategoryHeader)
                                            {
                                                hardwareMatrixWorksheet.Cells[alphabets].Value = cellValue;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Font.SetFromFont(new Font("Calibri", 11));
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells["G" + rowIndex + ":" + alphabetOnly + rowIndex].Merge = true;
                                            }
                                            else
                                            {
                                                hardwareMatrixWorksheet.Cells[alphabets].Value = cellValue;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Font.SetFromFont(new Font("Calibri", 11));
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            }


                                            if (!string.IsNullOrEmpty(styleColor) && styleColor != "\"\"" && !styleColor.Contains("#ffff99"))
                                            {
                                                Color yellowColFromHex = ColorTranslator.FromHtml(styleColor);
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                                if (isSubHeader)
                                                {
                                                    hardwareMatrixWorksheet.Cells["G" + rowIndex + ":" + alphabetOnly + rowIndex].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                    hardwareMatrixWorksheet.Cells["G" + rowIndex + ":" + alphabetOnly + rowIndex].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                                    hardwareMatrixWorksheet.Cells["G" + rowIndex + ":" + alphabetOnly + rowIndex].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                                    hardwareMatrixWorksheet.Cells["G" + rowIndex + ":" + alphabetOnly + rowIndex].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                                    hardwareMatrixWorksheet.Cells["G" + rowIndex + ":" + alphabetOnly + rowIndex].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                                    hardwareMatrixWorksheet.Cells["G" + rowIndex + ":" + alphabetOnly + rowIndex].Style.Fill.BackgroundColor.SetColor(yellowColFromHex);
                                                    hardwareMatrixWorksheet.Cells["G" + rowIndex + ":" + "R" + rowIndex].Merge = true;
                                                }
                                                else
                                                {
                                                    hardwareMatrixWorksheet.Cells[alphabets].Style.Fill.BackgroundColor.SetColor(yellowColFromHex);
                                                }
                                            }
                                            else if (styleColor.Contains("#ffff99"))
                                            {
                                                Color yellowColFromHex = ColorTranslator.FromHtml("255,255,255,153");
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Fill.BackgroundColor.SetColor(yellowColFromHex);
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                                hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                            }
                                        }
                                        else if (column.Value != null && column.Value.Contains("<a"))
                                        {
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            cellValue = this.GetBetweenStrings(column.Value, ">", "</a>");
                                            hardwareMatrixWorksheet.Cells[alphabets].Value = cellValue;
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                        }
                                        else
                                        {
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Font.SetFromFont(new Font("Calibri", 11));
                                            hardwareMatrixWorksheet.Cells[alphabets].Value = column.Value;
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                            hardwareMatrixWorksheet.Cells[alphabets].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                        }
                                    }
                                    columnIndex = columnIndex + 1;
                                }

                            }
                            rowIndex = rowIndex + 1;
                            headerIndex = headerIndex + 1;
                        }//loop
                    }
                }

                package.SaveAs(stream);

                contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                stream.Position = 0;
            }
            //return URL;
            return File(stream, contentType, hardwareMatrixFile);

        }

        public async Task<GridModel> GetProductHardwareMatrixModel(HardwareMatrixInputViewModel hardwareMatrixInput, HardwareMatrixViewModel hardwareMatrixDetails)
        {

            //var hardwareMatrixDetails = await this.GetHardwareQualMatrix(hardwareMatrixInput, true);

            GridModel model = new GridModel();
            model.ID = "hardwareMatrix";
            model.AutoGenerateColumns = false;
            model.Width = "100%";
            model.AutofitLastColumn = false;
            model.AlternateRowStyles = false;
            model.EnableHoverStyles = false;

            GridModel modelHeader = new GridModel();

            return await Task.Run(() =>
            {
                if (hardwareMatrixDetails != null && hardwareMatrixDetails.RowData != null)
                {
                    int count = 0;
                    if (hardwareMatrixDetails.RowData.Count() > 0)
                    {
                        foreach (var columns in hardwareMatrixDetails.RowData[0])
                        {

                            if (hardwareMatrixDetails.RowData.Count() == 1 && columns.Key == "ErrorMessage")
                            {
                                ViewBag.ErrorMessage = string.Format(AppSettings.Get<string>("HWQualMatrix:ErrorMessage"), AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));
                                return model;
                            }
                            if (columns.Key == "QualStatus")
                            {
                                if (hardwareMatrixInput.ReportFormat == 2 || hardwareMatrixInput.ReportFormat == 5)
                                {
                                    continue;
                                }
                                else if (!string.IsNullOrEmpty(hardwareMatrixDetails.Products))
                                {
                                    var productCount = hardwareMatrixDetails.Products.Split(",").Count();
                                    if (productCount > 1)
                                    {
                                        continue;
                                    }
                                }
                            }
                            count = count + 1;
                            GridColumn columnData = new GridColumn();
                            columnData.Key = columns.Key.Replace("/", "FRDSLS").Replace(@"\", "BCKSLS");

                            switch (columnData.Key)
                            {
                                case "GroupHeader":
                                case "FeatureNameDesc":
                                case "category":
                                case "TotalNoOfRows":
                                case "DeliverableName":
                                case "Vendor":
                                case "DeliverableVersionID":
                                case "RootID":
                                case "DelRootBase":
                                    columnData.Hidden = true;
                                    break;
                                case "HW":
                                case "FW":
                                case "Rev":
                                    columnData.Width = "6%";
                                    break;
                                case "FeatureNameDescDisplay":
                                    columnData.HeaderText = "ID";
                                    columnData.Width = "7%";
                                    break;
                                case "RohsGreenSpec":
                                    columnData.HeaderText = "Rohs/GreenSpec";
                                    columnData.Width = "5%";
                                    break;
                                case "ModelVendorPartNo":
                                    columnData.HeaderText = "Model/Vendor Part No.";
                                    columnData.Width = "6%";
                                    break;
                                case "HPPartNo":
                                    columnData.HeaderText = "HP Part No.";
                                    columnData.Width = "6%";
                                    break;
                                case "DCRHFCN":
                                    columnData.HeaderText = "DCR/HFCN";
                                    columnData.Width = "5%";
                                    break;
                                case "ACode":
                                    columnData.HeaderText = "A.Code";
                                    columnData.Width = "5%";
                                    break;
                                case "ReleaseNotes":
                                    columnData.HeaderText = "Release Notes";
                                    columnData.Width = "5%";
                                    break;
                                default:
                                    columnData.HeaderText = columns.Key;
                                    columnData.Width = "7%";
                                    break;
                            }

                            columnData.ColumnCssClass = columns.Key;
                            model.Columns.Add(columnData);
                        }

                        GridFiltering filtering = new GridFiltering();
                        filtering.Type = OpType.Remote;
                        filtering.FilterSummaryAlwaysVisible = false;
                        filtering.ShowNullConditions = false;
                        filtering.CaseSensitive = false;
                        filtering.ShowEmptyConditions = true;
                        filtering.Mode = FilterMode.Simple;
                        model.Features.Add(filtering);

                        GridSorting sorting = new GridSorting();
                        sorting.Mode = SortingMode.Multiple;
                        GridPaging paging = new GridPaging();
                        paging.Type = OpType.Remote;
                        var isdeleted = hardwareMatrixDetails.PageSizeOptions.Remove(5000);
                        paging.PageSizeList = hardwareMatrixDetails.PageSizeOptions;


                        paging.PageSize = 100;
                        paging.PageSizeDropDownLocation = "inpager";
                        paging.ShowPageSizeDropDown = true;
                        paging.ShowPrevNextPages = true;
                        paging.ShowFirstLastPages = true;
                        paging.ShowPagerRecordsLabel = true;
                        model.Features.Add(paging);
                        //model.Features.Add(sorting);

                        model.ResponseDataKey = "dataList";
                        string pulsarplus = string.Empty;
                        if (Request.Query != null && Request.Query.Keys.Count() > 0)
                        {
                            model.DataSourceUrl = "/pulsarplus/product/product/GetProductHardwareMatrixData" + Request.QueryString + "&IsExcel=" + hardwareMatrixInput.IsExcel;
                        }
                        else if (!string.IsNullOrEmpty(hardwareMatrixInput.RequestQueryString))
                        {
                            model.DataSourceUrl = "/pulsarplus/product/product/GetProductHardwareMatrixData?" + hardwareMatrixInput.RequestQueryString + "&IsExcel=" + hardwareMatrixInput.IsExcel;
                        }
                        else
                            model.DataSourceUrl = "/pulsarplus/product/product/GetProductHardwareMatrixData";


                        model.AlternateRowStyles = true;
                    }
                }
                return model;
            });
        }

        public async Task<JsonResult> GetProductHardwareMatrixData(HardwareMatrixInputViewModel hardwareMatrixInput)
        {

            //    GridModel model = await this.GetProductHardwareMatrixModel(hardwareMatrixInput);
            Type hardwareMatrix = typeof(HardwareMatrixViewModel);
            hardwareMatrixInput.Type = 1;
            hardwareMatrixInput.UserId = this.CurrentUserProfile.UserId;
            hardwareMatrixInput.GridColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:GridColumnLimit"));
            hardwareMatrixInput.ExcelColumnLimit = Convert.ToInt32(AppSettings.Get<string>("HWQualMatrix:ExcelColumnLimit"));
            if (hardwareMatrixInput.IsExcel == 1)
            {
                PaginationModel pagination = new PaginationModel();
                pagination.PageNo = 1;
                pagination.PageSize = 100000; // large page size to fetch all the rows for excel export
                hardwareMatrixInput.Pagination = pagination;
            }
            else
            {
                PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, hardwareMatrix);
                hardwareMatrixInput.Pagination = pagination;
            }

            HardwareMatrixViewModel qualMatrixReport = await this.GetHardwareQualMatrix(hardwareMatrixInput, false).ConfigureAwait(false);
            List<Dictionary<string, string>> qualMatrix = new List<Dictionary<string, string>>();
            if (qualMatrixReport != null && qualMatrixReport.RowData != null && qualMatrixReport.RowData.Count() > 0)
            {
                qualMatrix = qualMatrixReport.RowData;

                var count = qualMatrixReport.RowData[0]["TotalNoOfRows"].ToString();
                var result = new
                {
                    TotalRecordsCount = count,
                    pageSize = hardwareMatrixInput.Pagination.PageSize,
                    pageIndexUrlKey = "pageNo",
                    pageSizeUrlKey = "pageSize",
                    pageNo = hardwareMatrixInput.Pagination.PageNo,
                    responseDataKey = "dataList",
                    dataList = qualMatrix.AsQueryable() //.OrderBy(item=>item["DelRootBase"]).OrderBy(item => item["RootID"]).OrderBy(item => item["Vendor"]).OrderBy(item => item["DeliverableVersionID"])
                };
                return Json(result, base.JsonSettings);
            }
            else
            {
                return Json(null, base.JsonSettings);
            }

        }
        [HttpGet]
        [Route("/product/product/QuickReportsAvailability")]
        public async Task<IActionResult> QuickReportsAvailability()
        {
            var productStatus = 0;
            var product = string.Empty;
            var category = string.Empty;
            if (Request.Query.Count > 0)
            {
                productStatus = Convert.ToInt32(Request.Query["ProductStatus"]);
                product = Request.Query["lstproducts"];
                category = Request.Query["lstcategory"];
            }
            var reportAvailability = await this.UnitOfWork.GetQuickReportsAvailabilityAsync(productStatus, product, category).ConfigureAwait(false);
            return View("QuickReportsAvailability", reportAvailability);
        }

        public async Task<IActionResult> QuickReportsAvailabilityDetails(int productStatus, string productId, string categoryId)
        {
            Type hardwareMatrix = typeof(HardwareMatrixViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, hardwareMatrix);
            var quickReportsData = await this.UnitOfWork.QuickReportsAvailabilityDetailsAsync(productStatus, productId, categoryId, pagination).ConfigureAwait(false);
            var result = new
            {
                recordCountKey = quickReportsData.ReportsAvailable.Select(x => x.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = quickReportsData.ReportsAvailable
            };
            return Json(result, base.JsonSettings);
        }
        #endregion

        #region Lead Product Exceptions
        [HttpGet]
        [Route("product/product/GetLeadProductExceptions/{productId}/{rootId}/{versionIds}/{fusionRequirement}")]

        public async Task<IActionResult> GetLeadProductExceptions(int productId, int rootId, string versionIds, int fusionRequirement)
        {
            int releaseId = 0;
            if (fusionRequirement == 1)
            {
                LeadProducExceptionViewModel leadProducException = await this.UnitOfWork.GetProductVersionReleaseAsync(productId).ConfigureAwait(false);
                releaseId = leadProducException.ReleaseId;
                productId = leadProducException.Id;
            }

            var exceptions = await this.UnitOfWork.GetLeadProductExceptionsAsync(productId, rootId, versionIds, releaseId);
            return View(exceptions);
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/SaveProductVersionExceptions")]
        public async Task<IActionResult> SaveProductVersionExceptions([FromBody]LeadProducExceptionPostModel leadProducException)
        {
            var result = await this.UnitOfWork.TrySaveProductVersionExceptionsAsync(leadProducException).ConfigureAwait(false);
            return Json(result);
        }

        #endregion

        #region WhqlVerify
        [HttpGet]
        [Route("/product/product/GetWhqlVerifyDetails/{productId}")]
        public async Task<IActionResult> GetWhqlVerifyDetails(int productId)
        {
            var whqlVerifyDetails = await this.UnitOfWork.GetWhqlVerifyDetailsAsync(productId).ConfigureAwait(false);
            return View("GetWhqlVerifyDetails", whqlVerifyDetails);
        }

        public async Task<JsonResult> GetWhqlDeliverablesNotCertified(int productId)
        {
            Type compliance = typeof(ProductDeliverableViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, compliance);
            var whqlVerifyData = await this.UnitOfWork.GetWhqlVerifyNotCertifiedDataAsync(productId, pagination).ConfigureAwait(false);

            var result = new
            {
                recordCountKey = whqlVerifyData.ProductDeliverable.Select(x => x.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = whqlVerifyData.ProductDeliverable
            };

            return Json(result, base.JsonSettings);
        }

        public async Task<JsonResult> GetWhqlDeliverablesWithWaiver(int productId)
        {
            Type compliance = typeof(ProductDeliverableViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, compliance);
            var whqlWithWaiver = await this.UnitOfWork.GetWhqlDeliverablesWithWaiverAsync(productId, pagination).ConfigureAwait(false);

            var result = new
            {
                recordCountKey = whqlWithWaiver.ProductDeliverable.Select(x => x.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = whqlWithWaiver.ProductDeliverable
            };

            return Json(result, base.JsonSettings);
        }
        #endregion

        #region MdaCompliance
        [HttpPost]
        [Route("/product/product/GetMdaCompliance")]
        public async Task<IActionResult> GetMdaCompliance([FromForm]HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var mdaCompliance = await this.UnitOfWork.GetMdaComplianceAsync(hardwareMatrixInput).ConfigureAwait(false);
            return View("GetMdaCompliance", mdaCompliance);
        }

        public async Task<JsonResult> GetMdaComplianceDetails(string productId)
        {
            Type compliance = typeof(ProductDeliverableViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, compliance);
            var complianceData = await this.UnitOfWork.GetMdaComplianceDetailsAsync(productId, pagination).ConfigureAwait(false);

            var result = new
            {
                recordCountKey = complianceData.ProductDeliverable.Select(x => x.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = complianceData.ProductDeliverable
            };

            return Json(result, base.JsonSettings);
        }
        #endregion

        #region Get Products ByDeliverable Release

        [HttpGet]
        [Route("product/product/GetSubAssemblyNumbers")]
        public async Task<IActionResult> GetSubAssemblyNumbers(int rootId, int saType, int assigned, string mode, string subAssembly, int pvId, string selectedIds, int releaseId)
        {
            SubAssemblyMultiProductViewModel subAssemblyMultiProduct = await this.UnitOfWork.GetProductsByDeliverableReleaseAsync(rootId, saType, assigned, selectedIds, subAssembly).ConfigureAwait(false);
            subAssemblyMultiProduct.Assigned = assigned;
            subAssemblyMultiProduct.DrId = rootId;
            subAssemblyMultiProduct.Mode = mode;
            subAssemblyMultiProduct.PvId = pvId;
            subAssemblyMultiProduct.SubAssembly = subAssembly;
            subAssemblyMultiProduct.SaType = saType;
            subAssemblyMultiProduct.SelectedIds = selectedIds;

            if (assigned == 1)
            {
                subAssemblyMultiProduct.HeaderText = subAssemblyMultiProduct.HeaderText + subAssembly;
            }

            return View(subAssemblyMultiProduct);
        }
        #endregion

        #region MdaCompliance2015
        [HttpPost]
        [Route("/product/product/GetDeliverableMdaCompliance")]
        public async Task<IActionResult> GetDeliverableMdaCompliance([FromForm]HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var mdaCompliance = await this.UnitOfWork.GetDeliverableMdaComplianceAsync(hardwareMatrixInput).ConfigureAwait(false);
            return View("GetDeliverableMdaCompliance", mdaCompliance);
        }

        public async Task<JsonResult> GetDeliverableMdaComplianceDetails(string productId)
        {
            Type compliance = typeof(ProductDeliverableViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, compliance);
            var complianceData = await this.UnitOfWork.GetDeliverableMdaComplianceDetailsAsync(productId, pagination).ConfigureAwait(false);

            var result = new
            {
                recordCountKey = complianceData.ProductDeliverable.Select(x => x.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = complianceData.ProductDeliverable
            };

            return Json(result, base.JsonSettings);
        }
        #endregion

        [HttpPost]
        [Route("/product/product/GetHardwareMatrixDetails")]
        public async Task<IActionResult> GetHardwareMatrixDetails([FromForm]HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var matrixUrl = string.Empty;
            List<string> matrixUrls = new List<string>();
            Dictionary<string, string> drawBox = new Dictionary<string, string>();

            if (Request.Form.Count() == 0)
            {
                hardwareMatrixInput.QueryString = string.Empty;
                hardwareMatrixInput.RequestQueryString = string.Empty;
            }
            else
            {

                foreach (var item in Request.Form)
                {
                    if (!string.IsNullOrEmpty(item.Value))
                    {
                        switch (item.Key)
                        {
                            case "lstProducts":
                                hardwareMatrixInput.lstProducts = hardwareMatrixInput.HiddenProducts;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstProducts + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstProducts);
                                break;
                            case "lstProductsPulsar":
                                hardwareMatrixInput.lstProductsPulsar = hardwareMatrixInput.HiddenProductsPulsar;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstProductsPulsar + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstProductsPulsar);
                                break;
                            case "lstProductGroups":
                                hardwareMatrixInput.lstProductGroups = hardwareMatrixInput.HiddenProductGroups;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstProductGroups + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstProductGroups);
                                break;
                            case "lstQualStatus":
                                hardwareMatrixInput.lstQualStatus = hardwareMatrixInput.HiddenQualStatuses;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstQualStatus + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstQualStatus);
                                break;
                            case "lstCategory":
                                hardwareMatrixInput.lstCategory = hardwareMatrixInput.HiddenCategories;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstCategory + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstCategory);
                                break;
                            case "lstCommodityPM":
                                hardwareMatrixInput.lstCommodityPM = hardwareMatrixInput.HiddenCommodityPms;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstCommodityPM + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstCommodityPM);
                                break;
                            case "lstDevManager":
                                hardwareMatrixInput.lstDevManager = hardwareMatrixInput.HiddenDevManagers;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstDevManager + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstDevManager);
                                break;
                            case "lstRoot":
                                hardwareMatrixInput.lstRoot = hardwareMatrixInput.HiddenRoots;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstRoot + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstRoot);
                                break;
                            case "lstVendor":
                                hardwareMatrixInput.lstVendor = hardwareMatrixInput.HiddenVendors;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstVendor + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstVendor);
                                matrixUrls.Add(matrixUrl);
                                break;
                            case "lstTeamID":
                                hardwareMatrixInput.lstTeamID = hardwareMatrixInput.HiddenCoreTeams;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.lstTeamID + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.lstTeamID);
                                matrixUrls.Add(matrixUrl);
                                break;
                            case "txtStartDate":
                                hardwareMatrixInput.StartDate = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.StartDate + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.StartDate);
                                break;
                            case "txtEndDate":
                                hardwareMatrixInput.EndDate = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.EndDate + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.EndDate);
                                break;
                            case "txtSpecificPilotStatus":
                                hardwareMatrixInput.SpecificPilotStatus = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.SpecificPilotStatus + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.SpecificPilotStatus);
                                break;
                            case "txtSpecificQualStatus":
                                hardwareMatrixInput.SpecificQualStatus = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.SpecificQualStatus + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.SpecificQualStatus);
                                break;
                            case "cboHistoryRange":
                                hardwareMatrixInput.HistoryRange = item.Value;
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.HistoryRange + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.HistoryRange);
                                break;
                            case "txtHistoryDays":
                                hardwareMatrixInput.NoOfHistoryDays = Convert.ToInt32(item.Value);
                                hardwareMatrixInput.QueryString += item.Key + "=" + hardwareMatrixInput.NoOfHistoryDays + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, hardwareMatrixInput.NoOfHistoryDays.ToString());
                                break;
                            default:
                                hardwareMatrixInput.QueryString += item.Key + "=" + item.Value + "&";
                                matrixUrl = item.Key.ToLower();
                                drawBox.Add(item.Key, item.Value);
                                matrixUrls.Add(matrixUrl);
                                break;
                        }
                    }
                }

                hardwareMatrixInput.QueryString = hardwareMatrixInput.QueryString.Substring(0, hardwareMatrixInput.QueryString.Length - 1);
                hardwareMatrixInput.QueryStrings = matrixUrls;
                hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
                hardwareMatrixInput.InputValue = drawBox;
            }
            hardwareMatrixInput.UserId = this.CurrentUserProfile.UserId;
            hardwareMatrixInput.PartnerId = this.CurrentUserProfile.PartnerId.HasValue ? this.CurrentUserProfile.PartnerId.Value : default(int);
            hardwareMatrixInput.RequestQueryString = hardwareMatrixInput.QueryString;
            var hardwareMatrixDetails = await this.UnitOfWork.GetHardwareMatrixAsync(hardwareMatrixInput).ConfigureAwait(false);
            return View("GetHardwareMatrix", hardwareMatrixDetails);
        }

        #region cache
        private void SetCache<T>(string cacheKey, T value)
        {
            int duration = Convert.ToInt32(AppSettings.Get<string>("Cache:Duration"));
            this.MemoryCache.Set<T>(cacheKey, value, DateTimeOffset.Now.AddMilliseconds(duration));
        }

        private new T GetCache<T>(string cacheKey)
        {
            return this.MemoryCache.Get<T>(cacheKey);
        }
        #endregion cache

        [HttpGet]
        [Route("/product/Product/GetReleaseNotes/{id?}")]
        public async Task<IActionResult> GetReleaseNotes(int? id)
        {
            var releaseNotes = await this.UnitOfWork.GetReleaseNotesAsync(id).ConfigureAwait(false);
            return View("GetReleaseNotes", releaseNotes);
        }

        #region GetAction
        [HttpGet]
        [ProducesResponseType(typeof(ActionViewModel), 200)]
        [ProducesResponseType(typeof(ActionViewModel), 404)]
        [Route("/product/Product/GetAction/{productId}/{Id}/{type}/{appErrorId}/{working}/{roadmapId}/{ticketId}")]
        public IActionResult GetAction(int? productId, int? Id, int? type, int? appErrorId, int working, int? roadmapId, int? ticketId)
        {
            ActionDataViewModel actionData = new ActionDataViewModel();
            actionData.ProductId = productId;
            actionData.Id = Id;
            actionData.Type = type;
            actionData.appErrorId = appErrorId;
            actionData.Working = working;
            actionData.roadmapId = roadmapId;
            actionData.ticketId = ticketId;
            return View("GetAction", actionData);
        }


        [HttpGet]
        [ProducesResponseType(typeof(ActionViewModel), 200)]
        [ProducesResponseType(typeof(ActionViewModel), 404)]
        [Route("/product/Product/GetActionData/{productId}/{Id}/{type}/{appErrorId}/{working}/{roadmapId}/{ticketId}")]
        public async Task<IActionResult> GetActionData(int? productId, int? Id, int? type, int? appErrorId, int working, int? roadmapId, int? ticketId)
        {
            int currentUserID = CurrentUserProfile.UserId;
            int currentUserEmail = CurrentUserProfile.UserId;

            int? defaultWorkingListProduct = CurrentUserProfile.DefaultWorkingListProduct;
            string userName = CurrentUserProfile.UserName;
            var actions = await this.UnitOfWork.GetWorkingListActionAsync(currentUserID, currentUserEmail, defaultWorkingListProduct, productId, Id, type, appErrorId, working, roadmapId, ticketId, userName).ConfigureAwait(false);
            if (actions.DisplayOrder == null || actions.DisplayOrder == ' ')
            {
                actions.DisplayOrder = 0;
            }
            return Json(actions);
        }

        #endregion


        public async Task<HardwareMatrixViewModel> GetHardwareQualMatrix(HardwareMatrixInputViewModel hardwareMatrixInput, bool isCacheRequired)
        {
            string key = "hardwareMatrix" + hardwareMatrixInput.UserId.ToString();
            HardwareMatrixViewModel hardwareMatrixSearch = null;
            if (isCacheRequired == true)
            {
                hardwareMatrixSearch = await this.UnitOfWork.GetProductHardwareMatrixDataAsync(hardwareMatrixInput).ConfigureAwait(false);
                this.SetCache<HardwareMatrixViewModel>(key, hardwareMatrixSearch, true);
            }
            else
            {
                hardwareMatrixSearch = this.GetCache<HardwareMatrixViewModel>(key);
                if (hardwareMatrixSearch == null)
                {
                    hardwareMatrixSearch = await this.UnitOfWork.GetProductHardwareMatrixDataAsync(hardwareMatrixInput);
                    if (hardwareMatrixInput.Pagination == null || hardwareMatrixInput.Pagination.Filters == null)
                    {
                        this.SetCache<HardwareMatrixViewModel>(key, hardwareMatrixSearch, true);
                    }
                }
            }
            return hardwareMatrixSearch;
        }
        private void SetCache<T>(string cacheKey, T value, bool status)
        {
            int duration = 30000;
            this.MemoryCache.Set<T>(cacheKey, value, DateTimeOffset.Now.AddMilliseconds(duration));
        }

        [HttpGet]
        [Route("/product/product/GetProductReleaseCount")]
        public async Task<IActionResult> GetProductReleaseCount(HardwareMatrixInputViewModel hardwareMatrixInput)
        {
            var ProductReleaseCount = await this.UnitOfWork.GetProductReleaseCountAsync(hardwareMatrixInput).ConfigureAwait(false);
            return this.Json(ProductReleaseCount);
        }

        [HttpGet]
        [Route("/product/product/GetAllVendors")]
        public async Task<IActionResult> GetAllVendors()
        {
            var vendors = await this.UnitOfWork.GetAllVendorsAsync().ConfigureAwait(false);
            return this.Json(vendors, base.JsonSettings);
        }

        [HttpGet]
        [Route("/product/product/GetDeliverableVersionDevelopers")]
        public async Task<IActionResult> GetDeliverableVersionDevelopers()
        {
            var developers = await this.UnitOfWork.GetDeliverableVersionDevelopersAsync().ConfigureAwait(false);
            return this.Json(developers, base.JsonSettings);
        }

        [HttpGet]
        [Route("/product/product/GetTestStatuses")]
        public async Task<IActionResult> GetTestStatuses()
        {
            var testStatuses = await this.UnitOfWork.GetTestStatusesAsync().ConfigureAwait(false);
            return this.Json(testStatuses, base.JsonSettings);
        }

        [HttpGet]
        [Route("/product/product/GetLanguages")]
        public async Task<IActionResult> GetLanguages()
        {
            var languages = await this.UnitOfWork.GetLanguagesAsync().ConfigureAwait(false);
            return this.Json(languages, base.JsonSettings);
        }

        [HttpGet]
        [Route("/product/product/GetOperatingSystems")]
        public async Task<IActionResult> GetOperatingSystems()
        {
            var oSLookUps = await this.UnitOfWork.GetOperatingSystemsAsync().ConfigureAwait(false);
            return this.Json(oSLookUps, base.JsonSettings);
        }

        [HttpGet]
        [Route("/product/product/GetDeliverableCoreTeams")]
        public async Task<IActionResult> GetDeliverableCoreTeams()
        {
            var coreTeams = await this.UnitOfWork.GetDeliverableCoreTeamsAsync(CurrentUserProfile.PartnerId).ConfigureAwait(false);
            return this.Json(coreTeams, base.JsonSettings);
        }

        [HttpGet]
        [Route("/product/product/GetHWCategories")]
        public async Task<IActionResult> GetHWCategories(int isCommodityMatrix)
        {
            var categories = await this.UnitOfWork.GetHWCategoriesAsync(CurrentUserProfile.PartnerId, isCommodityMatrix).ConfigureAwait(false);
            return this.Json(categories, base.JsonSettings);
        }

        #region MyWorkingListReorder
        [HttpGet]
        [Route("/product/Product/GetWorkingList/{id}/{projectId}/{reportOption}")]
        public async Task<IActionResult> GetWorkingList(int id, int projectId, int reportOption)
        {
            var workListOrderDetail = await this.UnitOfWork.GetWorkingListAsync(id, projectId, reportOption).ConfigureAwait(false);
            return View("GetWorkingList", workListOrderDetail);
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/product/Product/UpdateWorkingList/{id}/{newOrder}")]
        public async Task<IActionResult> UpdateWorkingList(string id, string newOrder)
        {
            var status = await this.UnitOfWork.TryUpdateWorkingListAsync(id, newOrder).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion MyWorkingListReorder

        [HttpGet]
        [Route("/product/product/GetCommodityPMs")]
        public async Task<IActionResult> GetCommodityPMs()
        {
            var commodityPMs = await this.UnitOfWork.GetCommodityPMsAsync().ConfigureAwait(false);
            return this.Json(commodityPMs, base.JsonSettings);
        }

        #region AddProgram
        [HttpGet]
        [Route("/product/product/AddProgram")]
        public IActionResult AddProgram()
        {
            return View("AddProgram");
        }
        #endregion

        #region GetPlatform
        [HttpGet]
        [Route("/product/product/GetPlatform/{platFormId}/{productVersionId}/{productName}/{productFamily}/{businessSegmentId?}")]
        public IActionResult GetPlatform(int platFormId, int productVersionId, string productName, string productFamily, int? businessSegmentId)
        {
            PlatformDataViewModel platformData = new PlatformDataViewModel();
            platformData.PlatFormId = platFormId;
            platformData.ProductVersionId = productVersionId;
            platformData.ProductName = productName;
            platformData.ProductFamily = productFamily;
            platformData.BusinessSegmentId = businessSegmentId;
            return View("GetPlatForm", platformData);
        }

        [HttpGet]
        [Route("/product/product/GetPlatformData/{platFormId}/{productVersionId}/{productName}/{productFamily}/{businessSegmentId?}")]
        public async Task<IActionResult> GetPlatformData(int platFormId, int productVersionId, string productName, string productFamily, int? businessSegmentId)
        {
            var platFormData = await this.UnitOfWork.GetPlatformDataAsync(platFormId, productVersionId, productName, productFamily, businessSegmentId).ConfigureAwait(false);
            // return View("GetPlatForm");
            return this.Json(platFormData, base.JsonSettings);
        }

        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpdatePlatFormData([FromBody]PlatformDataViewModel platFormViewModel)
        {
            var status = await this.UnitOfWork.UpdatePlatFormDataAsync(platFormViewModel, CurrentUserProfile.UserId, CurrentUserProfile.Email).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        #region GetProductOS
        [HttpGet]
        [Route("/product/Product/GetProductOS/{productId?}")]
        public async Task<IActionResult> GetProductOS(int productId)
        {

            var productOS = await this.UnitOfWork.GetProductOSAsync(productId).ConfigureAwait(false);
            return View("AddProductOS", productOS);
        }

        [HttpPost]
        [Route("/Product/Product/UpdateProductOS")]
        public async Task<IActionResult> UpdateProductOS([FromForm]ProductOSViewModel productOSDetails)
        {
            if (productOSDetails.osLookup != null)
            {
                var status = await this.UnitOfWork.UpdateProductOSAsync(productOSDetails, CurrentUserProfile).ConfigureAwait(false);
            }
            return View("TodayActionSaveStatus");
        }
        #endregion

        #region ProductMarketingNames
        [HttpGet]
        [Route("/product/Product/GetMarketingNames")]
        public IActionResult GetProductMarketing()
        {
            ProductMarketingNamesViewModel productMarket = new ProductMarketingNamesViewModel();
            productMarket.PaginationConfig = new Infrastructure.Contracts.Models.PaginationConfiguration();
            return View("GetProductMarketingNames", productMarket);
        }

        public async Task<JsonResult> GetProductMarketingData()
        {
            Type productMarketing = typeof(ProductMarketingNamesViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, productMarketing);
            IEnumerable<ProductMarketingNamesViewModel> productMarketingData = await this.UnitOfWork.GetProductMarketingDataAsync(pagination).ConfigureAwait(false);

            var result = new
            {
                recordCountKey = productMarketingData.Select(m => m.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = productMarketingData
            };

            return Json(result, base.JsonSettings);
        }
        #endregion

        #region FCSEditPulsar
        [HttpGet]
        [Route("/product/Product/GetFCSPulsar/{productId?}/{fcsType}")]
        public async Task<IActionResult> GetFCSPulsar(int productId, string FcsType)
        {
            Type buildPlan = typeof(FCSEditPulsarViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, buildPlan);

            var productOS = await this.UnitOfWork.GetFCSPulsarAsync(productId, CurrentUserProfile, pagination).ConfigureAwait(false);
            productOS.FcsType = FcsType;
            return View("FCSEditPulsar", productOS);
        }

        //[HttpPost]        
        public async Task<JsonResult> GetFCSPulsarView(int productId, string fcsType)
        {
            Type buildPlan = typeof(FCSSelectPulsarViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, buildPlan);
            IEnumerable<FCSSelectPulsarViewModel> fcsData;
            if (fcsType == "pulsar")
            {
                fcsData = await this.UnitOfWork.GetFCSFusionPulsarViewAsync(productId, CurrentUserProfile, pagination).ConfigureAwait(false);
            }
            else if (fcsType == "legacy")
            {
                fcsData = await this.UnitOfWork.GetFCSLegacyViewAsync(productId, CurrentUserProfile, pagination).ConfigureAwait(false);
            }
            else
            {
                fcsData = await this.UnitOfWork.GetFCSFusionViewAsync(productId, CurrentUserProfile, pagination).ConfigureAwait(false);
            }

            var result = new
            {
                recordCountKey = fcsData.Select(m => m.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = fcsData
            };
            return Json(result, base.JsonSettings);
        }

        [HttpPost]
        [Route("/Product/Product/UpdateFCSPulsar")]
        public async Task<IActionResult> UpdateFCSPulsar([FromForm]UpdateFCSPulsarViewModel fusionFCSEdit)
        {
            var status = await this.UnitOfWork.TryUpdateFCSPulsarAsync(fusionFCSEdit, CurrentUserProfile).ConfigureAwait(false);
            return View("TodayActionSaveStatus");
        }
        #endregion

        #region UpdateStoredPath

        [Route("/product/Product/GetStoredPath")]
        public IActionResult GetStoredPath(string textFind, string textReplace)
        {
            var updatestoredpath = this.UnitOfWork.GetStoredPathAsync(textFind, textReplace);
            return View("GetStoredPathData", updatestoredpath);
        }

        public async Task<JsonResult> GetStoredPathData(string textFind, string textReplace)
        {
            Type storedpath = typeof(UpdateStoredPathDataViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, storedpath);


            IEnumerable<UpdateStoredPathDataViewModel> GetStoredPathData = await this.UnitOfWork.GetStoredPathDataAsync(textFind, textReplace, pagination).ConfigureAwait(false);

            var result = new
            {
                recordCountKey = GetStoredPathData.Select(m => m.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = GetStoredPathData
            };

            return Json(result, base.JsonSettings);
        }
        [HttpPost]
        [ProducesResponseType(typeof(int), 200)]
        [ProducesResponseType(typeof(int), 404)]
        public async Task<IActionResult> UpdateStoredPath(string updateFind, string updateReplace)
        {
            var status = await this.UnitOfWork.UpdateStoredPathAsync(updateFind, updateReplace).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        [HttpGet]
        [Route("/product/Product/GetUtilitiesMain")]
        public IActionResult GetUtilitiesMain()
        {
            return View("GetUtilitiesMain");
        }

        #region Documents Browse
        [HttpGet]
        [Route("/product/Product/GetDocuments")]
        public IActionResult GetDocuments()
        {
            var documents = this.UnitOfWork.GetDocumentsAsync();
            return View("GetDocuments", documents);
        }
        #endregion

        #region 
        [HttpGet]
        public async Task<IActionResult> GetProfileSharedProperties(int employeeId, int profileId, int addType, string canEdit, string canDelete)
        {
            ProfileSharedPropertiesViewModel profileSharedProperties = new ProfileSharedPropertiesViewModel();
            profileSharedProperties = await this.UnitOfWork.GetProfileSharePropertiesAsync(employeeId, profileId, addType).ConfigureAwait(false);
            profileSharedProperties.AddType = addType;
            profileSharedProperties.ProfileId = profileId;
            if (employeeId > 0)
            {
                profileSharedProperties.EmployeeId = employeeId;
                profileSharedProperties.Title = "Edit Permissions";
            }
            else if (addType != 2)
            {
                profileSharedProperties.Title = "Add Person";
            }
            else
            {
                profileSharedProperties.Title = "Add Group";
            }

            if (!string.IsNullOrWhiteSpace(canEdit))
                profileSharedProperties.CanEdit = canEdit.ToLower() == "true" ? true : false;

            if (!string.IsNullOrWhiteSpace(canDelete))
                profileSharedProperties.CanDelete = canDelete.ToLower() == "true" ? true : false;

            return View("GetProfileSharedProperties", profileSharedProperties);
        }

        public async Task<JsonResult> GetActiveEmployees()
        {
            var employees = await this.UnitOfWork.GetActiveEmployeesAsync().ConfigureAwait(false);

            return Json(employees, base.JsonSettings);
        }

        public async Task<JsonResult> GetEmployeeUserSetting(int employeeId)
        {
            var employees = await this.UnitOfWork.GetEmployeeUserSettingAsync(CurrentUserProfile.UserId, employeeId).ConfigureAwait(false);

            return Json(employees, base.JsonSettings);
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        public async Task<JsonResult> UpdateSharedProfile(ProfileSharedPropertiesViewModel reportProfileShared)
        {
            var employees = await this.UnitOfWork.UpdateSharedProfileAsync(reportProfileShared).ConfigureAwait(false);

            return Json(employees, base.JsonSettings);
        }

        #endregion

        [HttpGet]
        [Route("/product/product/GetCountries")]
        public IActionResult GetCountries()
        {
            CountriesViewModel countries = new CountriesViewModel();
            countries.PaginationConfig = new Infrastructure.Contracts.Models.PaginationConfiguration();
            return View("GetCountries", countries);
        }

        public async Task<IActionResult> GetCountriesData(int optionId, string optionName, string list, PaginationModel pagination)
        {
            var getCountries = await this.UnitOfWork.GetCountriesDataAsync(optionId, optionName, list, pagination).ConfigureAwait(false);
            var result = new
            {
                recordCountKey = getCountries.Count() > 0 ? getCountries.Select(x => x.RecordCount).First().ToString() : null,
                responseDataKey = "dataList",
                dataList = getCountries
            };
            return Json(result, base.JsonSettings);
        }
        #region suddenimpact
        [HttpGet]
        [Route("/product/Product/Getdeliverablesync")]
        public IActionResult GetDeliverableSync(string updateOk)
        {
            SuddenImpactDeliverableSyncViewModel deliverableSync = new SuddenImpactDeliverableSyncViewModel();
            deliverableSync.UpdateOk = updateOk;
            deliverableSync.PaginationConfig = new Infrastructure.Contracts.Models.PaginationConfiguration();
            return View("GetDeliverableSync", deliverableSync);
        }
        public async Task<JsonResult> GetDeliverableSyncData()
        {
            Type deliverableSync = typeof(SuddenImpactDeliverableSyncViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, deliverableSync);
            IEnumerable<SuddenImpactDeliverableSyncViewModel> deliverableSyncData = await this.UnitOfWork.GetDeliverableSyncDataAsync(pagination).ConfigureAwait(false);

            var result = new
            {
                recordCountKey = deliverableSyncData.Select(m => m.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = deliverableSyncData
            };

            return Json(result, base.JsonSettings);
        }
        public async Task<IActionResult> UpdateDeliverySync()
        {
            var status = await this.UnitOfWork.UpdateDeliverySyncAsync().ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion

        [HttpGet]
        [Route("/product/product/GetProgram/{id?}")]
        public async Task<IActionResult> GetProgram(int? id)
        {
            var program = await this.UnitOfWork.GetProgramAsync(id).ConfigureAwait(false);
            return View("GetProgram", program);
        }

        [HttpPost]
        [Route("/product/product/GetProgramData/")]
        public async Task<IActionResult> GetProgramData()
        {
            var program = await this.UnitOfWork.GetProgramDataAsync().ConfigureAwait(false);
            return this.Json(program);
        }
        #region deliveableroot

        [HttpGet]
        [Route("/product/Product/GetSelecteddeliveableroot")]
        public IActionResult GetSelecteddeliveableroot()
        {
            SelectedDeliveableRootViewModel deliverableRoot = new SelectedDeliveableRootViewModel();
            deliverableRoot.PaginationConfig = new Infrastructure.Contracts.Models.PaginationConfiguration();
            return View("GetSelectedDeliveableRoot", deliverableRoot);
        }

        public async Task<JsonResult> GetDeliverableRootMainData()
        {
            Type deliverableRoot = typeof(SelectedDeliveableRootViewModel);
            PaginationModel pagination = GetPaginationFromInfragisticsGrid(Request.Query, deliverableRoot);
            IEnumerable<SelectedDeliveableRootViewModel> GetDeliverableRootMainData = await this.UnitOfWork.GetDeliverableRootMainDataAsync(pagination).ConfigureAwait(false);

            var result = new
            {
                recordCountKey = GetDeliverableRootMainData.Select(m => m.RecordCount).FirstOrDefault().ToString(),
                responseDataKey = "dataList",
                dataList = GetDeliverableRootMainData
            };
            return Json(result, base.JsonSettings);
        }
        #endregion

        #region ProfileFilterAction
        [HttpPost]
        public async Task<IActionResult> DeliverableProfileFilterAction(ReportProfilePostModel reportProfile)
        {
            reportProfile.EmployeeId = CurrentUserProfile.UserId;
            var response = await this.UnitOfWork.DeliverableProfileFilterActionAsync(reportProfile);
            return Json(response);
        }
        #endregion
    }
}

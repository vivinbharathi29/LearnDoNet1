﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.UnitOfWork.Product.Contracts;
using HPi.Pulsar.UnitOfWork.Product.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HPi.Pulsar.Mvc.Areas.Product.Controllers
{

    [Area("Product")]
    public class IRSComponentUpdateController : BaseMvcController<IIRSComponentUpdateUnitOfWork>
    {
        public IRSComponentUpdateController(IApplicationServices applicationServices, IIRSComponentUpdateUnitOfWork iIRSComponentUpdateUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration)
            : base(applicationServices, iIRSComponentUpdateUnitOfWork, configuration, currentProfile)
        {
            this.CurrentUserProfile = currentProfile;
        }

        #region Service Properties
        public ICurrentUserProfile CurrentUserProfile { get; }
        #endregion

        #region Public Properties
        public int UserIdentity { get; set; }
        #endregion

        #region GetOSAndProductDropList
        [HttpPost]
        [ProducesResponseType(typeof(IRSComponentUpdateViewModel[]), 200)]
        [ProducesResponseType(typeof(IRSComponentUpdateViewModel[]), 404)]
        public async Task<JsonResult> GetOSAndProductDetails([FromBody]HPi.Pulsar.Product.Contracts.IrsComponentModel irsComponent)
        {
            var osProductDetails = await this.UnitOfWork.GetOSAndProductDetails(irsComponent).ConfigureAwait(false);
            return Json(osProductDetails);
        }
        #endregion

        #region IRSComponentProductUpdateList
        [HttpPost]
        [ProducesResponseType(typeof(IRSComponentUpdateViewModel[]), 200)]
        [ProducesResponseType(typeof(IRSComponentUpdateViewModel[]), 404)]
        public async Task<JsonResult> GetComponentsToPutInIRSProductDrop([FromBody]HPi.Pulsar.Product.Contracts.IrsComponentModel irsComponent)
        {
            var irsComponentProductDrop = await this.UnitOfWork.GetComponentsToPutInIRSProductDrop(irsComponent).ConfigureAwait(false);
            return Json(irsComponentProductDrop);
        }
        #endregion
    }
}
﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.UnitOfWork.Component.Contracts;
using HPi.Pulsar.UnitOfWork.Component.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HPi.Pulsar.Mvc.Areas.Component.Controllers
{


    [Area("Component")]
    public class ComponentController : BaseMvcController<IComponentUnitOfWork>
    {
        public ComponentController(IApplicationServices applicationServices, IComponentUnitOfWork componentUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration)
            : base(applicationServices, componentUnitOfWork, configuration, currentProfile)
        {
            this.currentUserProfile = currentProfile;
        }

        #region Service Properties
        private ICurrentUserProfile currentUserProfile { get; }
        #endregion

        #region Public Properties
        public int UserIdentity { get; set; }
        #endregion



        #region GetSupplierCodes

        [HttpGet]
        [ProducesResponseType(typeof(SupplierCodeViewModel), 200)]
        [ProducesResponseType(typeof(SupplierCodeViewModel), 404)]
        [Route("/component/Component/GetSupplierCodes/{categoryID}/{vendorID}")]
        public async Task<IActionResult> GetSupplierCodes(int categoryId, int vendorId)
        {
            var supplierCodes = await this.UnitOfWork.GetSupplierCodesAsync(categoryId, vendorId).ConfigureAwait(false);
            return this.Json(supplierCodes);
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/Component/Component/AddSupplierCode")]
        public async Task<IActionResult> AddSupplierCode([FromBody]AddSupplierCodeViewModel supplierCodeViewModel)
        {
            var status = await this.UnitOfWork.TryAddSupplierCodeAsync(supplierCodeViewModel).ConfigureAwait(false);
            return this.Json(status);
        }

        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("/Component/Component/UpdateVersionPartNumber")]
        public async Task<IActionResult> UpdateVersionPartNumber([FromBody]UpdateVersionPartNumberViewModel partNumberViewModel)
        {
            var status = await this.UnitOfWork.TryUpdateVersionPartNumberAsync(partNumberViewModel).ConfigureAwait(false);
            return this.Json(status);
        }


        #endregion

        #region GetVersionPartNumber
        [HttpGet]
        [ProducesResponseType(typeof(PartNumberViewModel), 200)]
        [ProducesResponseType(typeof(PartNumberViewModel), 404)]
        [Route("/Component/Component/GetVersionPartNumber/{Id}")]
        public async Task<IActionResult> GetVersionPartNumber(int Id)
        {
            var partNumber = await this.UnitOfWork.GetVersionPartNumberAsync(Id).ConfigureAwait(false);
            return this.Json(partNumber);
        }
        #endregion

        #region GetFT
        [HttpGet]
        [ProducesResponseType(typeof(FTViewModel), 200)]
        [ProducesResponseType(typeof(FTViewModel), 404)]
        [Route("/Component/Component/GetFT/{id}/{rootID}")]
        public async Task<IActionResult> GetFT(int id, int rootID)
        {
            var ft = await this.UnitOfWork.GetFTAsync(id, rootID, currentUserProfile.PartnerId, currentUserProfile.UserId).ConfigureAwait(false);
            return this.Json(ft);
        }
        #endregion
    }
}

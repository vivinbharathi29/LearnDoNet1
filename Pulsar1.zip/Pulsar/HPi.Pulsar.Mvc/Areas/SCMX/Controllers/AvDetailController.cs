﻿using System;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.UnitOfWork.SCMX.Contracts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace HPi.Pulsar.Mvc.Areas.SCMX.Controllers
{

    [Area("Scmx")]
    public class AvDetailController : BaseMvcController<IAvDetailUnitOfWork>
    {
        public AvDetailController(IApplicationServices applicationServices, IAvDetailUnitOfWork iAvDetailUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration)
            : base(applicationServices, iAvDetailUnitOfWork, configuration, currentProfile)
        {
            this.CurrentUserProfile = currentProfile;
        }

        #region Service Properties
        public ICurrentUserProfile CurrentUserProfile { get; }
        #endregion

        #region Public Properties
        public int UserIdentity { get; set; }
        #endregion

        #region UpdateAvDetails
        [HttpGet]
        [Route("/scmx/AvDetail/UpdateAvDetail/{avCreateId}/{deliverableRootId}/{productBrandId}/{avNo}/{chkUpdateDescription}")]
        public async Task UpdateAvDetail(int avCreateId, int deliverableRootId, int productBrandId, string avNo, bool chkUpdateDescription)
        {
            if (this.ApplicationMode == "XUnitTesting")
            {
                this.UserIdentity = 2245;
            }
            else if (this.ApplicationMode == "LocalTesting")
            {
                this.UserIdentity = 2245;//GetCurrentUserIdOrCmPcPhWebMktImpersonateID()
            }
            else
            {
                this.UserIdentity = GetCurrentUserIdOrCmPcPhWebMktImpersonateId(); //2245;
            }
            await this.UnitOfWork.UpdateAvDetailAsync(avCreateId, deliverableRootId, productBrandId, avNo, chkUpdateDescription, (int)this.UserIdentity).ConfigureAwait(false);
        }
        #endregion

        #region UpdateMissingAVMarketingDetails
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 400)]
        [Route("/scmx/AvDetail/UpdateMissingAVMarketingDetail/")]
        public async Task<IActionResult> UpdateMissingAVMarketingDetail(int avDetailID, DateTime discontinueDate, DateTime rTPDate, int bID)
        {
            var status = await this.UnitOfWork.TryUpdateMissingAVMarketingDetailAsync(avDetailID, this.CurrentUserProfile.UserName, discontinueDate, rTPDate, bID).ConfigureAwait(false);
            return this.Json(status);
        }
        #endregion UpdateMissingAVMarketingDetails
    }
}

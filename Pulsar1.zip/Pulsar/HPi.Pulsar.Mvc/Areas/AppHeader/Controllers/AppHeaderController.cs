﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.UnitOfWork.AppHeader.Contracts;
using HPi.Pulsar.UnitOfWork.AppHeader.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860
namespace HPi.Pulsar.Mvc.Areas.AppHeader.Controllers
{

    [Area("AppHeader")]
    public class AppHeaderController : BaseMvcController<IAppHeaderUnitOfWork>
    {
        public AppHeaderController(IApplicationServices applicationServices, IAppHeaderUnitOfWork iAppHeaderUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration)
            : base(applicationServices, iAppHeaderUnitOfWork, configuration, currentProfile)
        {
            this.currentUserProfile = currentProfile;
        }

        protected ICurrentUserProfile currentUserProfile { get; }

        #region AppHeaderMethods

        [ProducesResponseType(typeof(AppHeaderViewModel), 200)]
        [ProducesResponseType(typeof(AppHeaderViewModel), 400)]
        public async Task<IActionResult> GetUserByName()
        {
            var appHeaderDetails = await this.UnitOfWork.GetUserByNameAsync(this.currentUserProfile.LoginAuthName).ConfigureAwait(false);
            return this.Json(new { appHeaderDetails });
        }
        [ProducesResponseType(typeof(AppHeaderViewModel), 200)]
        [ProducesResponseType(typeof(AppHeaderViewModel), 400)]
        public async Task<IActionResult> GetUserById()
        {
            var appHeaderDetails = await this.UnitOfWork.GetUserByIdAsync(this.currentUserProfile.UserId).ConfigureAwait(false);
            return this.Json(new { appHeaderDetails });
        }

        [ProducesResponseType(typeof(AppHeaderViewModel), 200)]
        [ProducesResponseType(typeof(AppHeaderViewModel), 400)]
        public async Task<IActionResult> GetUserByEmail()
        {
            var appHeaderDetails = await this.UnitOfWork.GetUserByEmailAsync(this.currentUserProfile.Email).ConfigureAwait(false);
            return this.Json(new { appHeaderDetails });
        }

        [ProducesResponseType(typeof(AppHeaderViewModel), 200)]
        [ProducesResponseType(typeof(AppHeaderViewModel), 400)]
        public async Task<IActionResult> GetUserInfoByUserName()
        {              
            var appHeaderDetails = await this.UnitOfWork.GetUserInfoByUserNameAsync(this.currentUserProfile.LoginAuthName, this.currentUserProfile.LoginDomain, this.currentUserProfile.ImpersonateId, HttpContext.Request.IsHttps).ConfigureAwait(false);
            return this.Json(new { appHeaderDetails });
        }

        [ProducesResponseType(typeof(AppHeaderViewModel), 200)]
        [ProducesResponseType(typeof(AppHeaderViewModel), 400)]
        public async Task<IActionResult> GetEmployeeImpersonateID()
        {
            var appHeaderDetails = await this.UnitOfWork.GetEmployeeImpersonateIdAsync(this.currentUserProfile.LoginAuthName, this.currentUserProfile.LoginDomain).ConfigureAwait(false);
            return this.Json(new { appHeaderDetails });
        }

        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 400)]
        public async Task<IActionResult> GetUserInfoFromContext()
        {
            var userInfo = new UserInfoModel();
            userInfo.UserId = this.currentUserProfile.UserId;
            userInfo.CMImpersonate = this.currentUserProfile.CMImpersonate;
            userInfo.PCImpersonate = this.currentUserProfile.PCImpersonate;
            userInfo.PhWebImpersonate = this.currentUserProfile.PhWebImpersonate;
            userInfo.CurrentName = this.currentUserProfile.CurrentName;
            userInfo.originalName = this.currentUserProfile.originalName;
            userInfo.PulsarSystemAdmin = this.currentUserProfile.PulsarSystemAdmin;
            AppHeaderViewModel appHeaderVM = await this.UnitOfWork.GetEmployeeImpersonateIdAsync(this.currentUserProfile.LoginAuthName, this.currentUserProfile.LoginDomain).ConfigureAwait(false);
            userInfo.EmployeeId = appHeaderVM.UserId;
            //this.currentuserprofile.em
            if (userInfo.CurrentName == userInfo.originalName)
            {
                userInfo.LoginUserName = userInfo.originalName;
            }
            else
            {
                userInfo.LoginUserName = userInfo.originalName + "(" + userInfo.CurrentName + ")";
            }
            return this.Json(new { userInfo });
        }

        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 400)]
        [HttpGet]
        public async Task<IActionResult> GetEnvironmentName()
        {
            var environmentName = await this.UnitOfWork.GetEnvironmentNameAsync().ConfigureAwait(false);
            return this.Json(new { environmentName });
        }

        #endregion

        #region PageHeader
        [HttpGet]
        public async Task<IActionResult> GetPageHeader()
        {
            AppHeaderViewModel appHeaderDetail = new AppHeaderViewModel();
            AppHeaderViewModel appHeader = await this.UnitOfWork.GetEmployeeImpersonateIdAsync(this.currentUserProfile.LoginAuthName, this.currentUserProfile.LoginDomain);
            appHeaderDetail.EnvironmentName = "[" + await this.UnitOfWork.GetEnvironmentNameAsync() + "]";
            appHeaderDetail.ProfileURL = "/IPulsar/Admin/System Admin/AddUserToTeam_Edit.aspx?UserId=" + this.currentUserProfile.UserId + "&TeamID=0&FromTodayPage=1&app=PulsarPlus";
            appHeaderDetail.EnableImpersonate = this.currentUserProfile.PulsarSystemAdmin == 1 || this.currentUserProfile.UserId != appHeader.UserId ? true : false;
            if (this.currentUserProfile.CurrentName == this.currentUserProfile.originalName)
            {
                appHeaderDetail.CurrentUserName = this.currentUserProfile.originalName;
            }
            else
            {
                appHeaderDetail.CurrentUserName = this.currentUserProfile.originalName + "(" + this.currentUserProfile.CurrentName + ")";
            }
            return PartialView("_PageHeader", appHeaderDetail);
        }

        [HttpGet]
        public async Task<IActionResult> GetExcaliburPageHeader(bool isIpulsar = false)
        {
            AppHeaderViewModel appHeaderDetail = new AppHeaderViewModel();
            AppHeaderViewModel appHeader = await this.UnitOfWork.GetEmployeeImpersonateIdAsync(this.currentUserProfile.LoginAuthName, this.currentUserProfile.LoginDomain).ConfigureAwait(false);
            appHeaderDetail.EnvironmentName = "[" + await this.UnitOfWork.GetEnvironmentNameAsync() + "]";
            appHeaderDetail.ProfileURL = "/IPulsar/Admin/System Admin/AddUserToTeam_Edit.aspx?UserId=" + this.currentUserProfile.UserId + "&TeamID=0&FromTodayPage=1&app=PulsarPlus";
            appHeaderDetail.EnableImpersonate = this.currentUserProfile.PulsarSystemAdmin == 1 || this.currentUserProfile.UserId != appHeader.UserId ? true : false;
            if (this.currentUserProfile.CurrentName == this.currentUserProfile.originalName)
            {
                appHeaderDetail.CurrentUserName = this.currentUserProfile.originalName;
            }
            else
            {
                appHeaderDetail.CurrentUserName = this.currentUserProfile.originalName + "(" + this.currentUserProfile.CurrentName + ")";
            }
            appHeaderDetail.ImpersonateName = this.currentUserProfile.originalName == this.currentUserProfile.CurrentName ? string.Empty : this.currentUserProfile.CurrentName;
            appHeaderDetail.OriginalName = this.currentUserProfile.originalName;
            appHeaderDetail.IsIpulsar = isIpulsar;
            appHeaderDetail.IsIpulsarPlus = false;
            return PartialView("_ExcaliburPageHeader", appHeaderDetail);
        }


        [HttpGet]
        public IActionResult GetFavouriteMenu()
        {
            return ViewComponent("FavouriteMenu");
        }
        #endregion PageHeader
    }
}

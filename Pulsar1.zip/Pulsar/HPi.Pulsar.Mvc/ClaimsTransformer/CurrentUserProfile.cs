﻿using System;
using System.Linq;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using Microsoft.AspNetCore.Http;

namespace HPi.Pulsar.Mvc.ClaimsTransformer
{


    public class CurrentUserProfile : ICurrentUserProfile
    {
        public CurrentUserProfile(IHttpContextAccessor context)
        {
            this.context = context.HttpContext;
        }

        protected HttpContext context;

        public string Name
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "Name").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string UserName
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "UserName").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string UserGuid
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "UserGuid").Select(c => c.Value).SingleOrDefault();
            }
        }

        public int UserId
        {
            get
            {
                return Convert.ToInt32(this.context.User.Claims.Where(c => c.Type == "UserId").Select(c => c.Value).SingleOrDefault());
            }
        }

        public string IsHp
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "IsHp").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string NtDomain
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "NtDomain").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string NtName
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "NtName").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string ActualUserId
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "ActualUserID").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string ActualGivenName
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "ActualGivenName").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string IsReverseProxyConnection
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "IsReverseProxyConnection").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string AuthName
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "AuthName").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string Email
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "Email").Select(c => c.Value).SingleOrDefault();
            }
        }

        public string DisplayName
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "DisplayName").Select(c => c.Value).SingleOrDefault();
            }
        }

        public int? ImpersonateId
        {
            get
            {
                string impersonateId = this.context.User.Claims.Where(c => c.Type == "ImpersonateId").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(impersonateId))
                    return Convert.ToInt32(impersonateId);
                else
                    return null;
            }
        }


        public int? PMImpersonate
        {
            get
            {
                string pmIpersonate = this.context.User.Claims.Where(c => c.Type == "PMImpersonate").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(pmIpersonate))
                    return Convert.ToInt32(pmIpersonate);
                else
                    return null;
            }
        }
        public int? CMImpersonate
        {
            get
            {
                string cmImpersonate = this.context.User.Claims.Where(c => c.Type == "CMImpersonate").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(cmImpersonate))
                    return Convert.ToInt32(cmImpersonate);
                else
                    return null;
            }
        }

        public int? PCImpersonate
        {
            get
            {
                string pcImpersonate = this.context.User.Claims.Where(c => c.Type == "PCImpersonate").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(pcImpersonate))
                    return Convert.ToInt32(pcImpersonate);
                else
                    return null;
            }
        }

        public int? PhWebImpersonate
        {
            get
            {
                string phwebImpersonate = this.context.User.Claims.Where(c => c.Type == "PhWebImpersonate").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(phwebImpersonate))
                    return Convert.ToInt32(phwebImpersonate);
                else
                    return null;
            }
        }

        public string CurrentName
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "CurrentName")
                   .Select(c => c.Value).SingleOrDefault();
            }
        }

        public string originalName
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "originalName")
                   .Select(c => c.Value).SingleOrDefault();
            }
        }

        public string LoginAuthName
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "LoginAuthName")
                   .Select(c => c.Value).SingleOrDefault();
            }
        }

        public string LoginDomain
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "LoginDomain")
                   .Select(c => c.Value).SingleOrDefault();
            }
        }

        public string Favourites
        {
            get
            {
                return this.context.User.Claims.Where(c => c.Type == "Favourites")
                   .Select(c => c.Value).SingleOrDefault();
            }
        }

        public int? MarketingImpersonate
        {
            get
            {
                string marketingImpersonate = this.context.User.Claims.Where(c => c.Type == "MarketingImpersonate").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(marketingImpersonate))
                    return Convert.ToInt32(marketingImpersonate);
                else
                    return null;
            }
        }

        public bool ServicePM
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "ServicePM")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public bool WWANEngineer
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "WWANEngineer")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public bool ProcurementEngineer
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "ProcurementEngineer")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public bool ServiceCommodityManager
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "ServiceCommodityManager")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public int SepmCount
        {
            get
            {
                return Convert.ToInt32(this.context.User.Claims.Where(c => c.Type == "SepmCount")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public bool PreInstall
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "PreInstall")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public int? PartnerId
        {
            get
            {
                string partnerId = this.context.User.Claims.Where(c => c.Type == "PartnerId").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(partnerId))
                    return Convert.ToInt32(partnerId);
                else
                    return null;
            }
        }

        public int? PartnerTypeId
        {
            get
            {
                string partnerTypeId = this.context.User.Claims.Where(c => c.Type == "PartnerTypeId").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(partnerTypeId))
                    return Convert.ToInt32(partnerTypeId);
                else
                    return null;
            }
        }

        public int? PulsarSystemAdmin
        {
            get
            {
                string pulsarSystemAdmin = this.context.User.Claims.Where(c => c.Type == "PulsarSystemAdmin").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(pulsarSystemAdmin))
                    return Convert.ToInt32(pulsarSystemAdmin);
                else
                    return null;
            }
        }

        public int? WorkGroupId
        {
            get
            {
                string workGroupId = this.context.User.Claims.Where(c => c.Type == "WorkGroupId").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(workGroupId))
                    return Convert.ToInt32(workGroupId);
                else
                    return null;
            }
        }

        public string UserBrowser
        {
            get
            {
                //return ((Microsoft.AspNetCore.Server.Kestrel.Internal.Http.FrameRequestHeaders)context.Request.Headers).HeaderUserAgent;
                return ((Microsoft.AspNetCore.Server.Kestrel.Core.Internal.Http.HttpRequestHeaders)context.Request.Headers).HeaderUserAgent;
            }
        }

        public int OriginalUserId
        {
            get
            {
                return Convert.ToInt32(this.context.User.Claims.Where(c => c.Type == "OriginalUserId")
                   .Select(c => c.Value).SingleOrDefault());
            }
        }

        public int? DefaultWorkingListProduct
        {
            get
            {
                string defaultWorkingListProduct = this.context.User.Claims.Where(c => c.Type == "DefaultWorkingListProduct").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(defaultWorkingListProduct))
                    return Convert.ToInt32(defaultWorkingListProduct);
                else
                    return null;
            }
        }

        public bool? CommodityPM
        {
            get
            {
                string commodityPM = this.context.User.Claims.Where(c => c.Type == "CommodityPM").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(commodityPM))
                    return Convert.ToBoolean(commodityPM);
                else
                    return null;
            }
        }

        public bool? SCFactoryEngineer
        {
            get
            {
                string scFactoryEngineer = this.context.User.Claims.Where(c => c.Type == "SCFactoryEngineer").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(scFactoryEngineer))
                    return Convert.ToBoolean(scFactoryEngineer);
                else
                    return null;
            }
        }

        public bool? AccessoryPM
        {
            get
            {
                string accessoryPM = this.context.User.Claims.Where(c => c.Type == "AccessoryPM").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(accessoryPM))
                    return Convert.ToBoolean(accessoryPM);
                else
                    return null;
            }
        }

        public int? EngCoordinator
        {
            get
            {
                string engCoordinator = this.context.User.Claims.Where(c => c.Type == "EngCoordinator").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(engCoordinator))
                    return Convert.ToInt32(engCoordinator);
                else
                    return null;
            }
        }

        public int? SAAdmin
        {
            get
            {
                string saAdmin = this.context.User.Claims.Where(c => c.Type == "SAAdmin").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(saAdmin))
                    return Convert.ToInt32(saAdmin);
                else
                    return null;
            }
        }

        public bool ServiceCoordinator
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "ServiceCoordinator")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public byte? Division
        {
            get
            {
                string division = this.context.User.Claims.Where(c => c.Type == "Division")
                    .Select(c => c.Value).SingleOrDefault();

                if (!string.IsNullOrEmpty(division))
                    return Convert.ToByte(division);
                else
                    return null;
            }
        }

        public bool IsSystemAdmin
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "IsSystemAdmin")
                   .Select(c => c.Value).SingleOrDefault());
            }
        }

        public bool IsWHQLTestTeam
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "IsWHQLTestTeam")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public bool IsMITTestLead
        {
            get
            {
                return Convert.ToBoolean(this.context.User.Claims.Where(c => c.Type == "IsMITTestLead")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }

        public int? CMProductCount
        {
            get
            {
                string cmProductCount = this.context.User.Claims.Where(c => c.Type == "CMProductCount").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(cmProductCount))
                    return Convert.ToInt32(cmProductCount);
                else
                    return null;
            }
        }

        public int? MarketingProductCount
        {
            get
            {
                string marketingProductCount = this.context.User.Claims.Where(c => c.Type == "MarketingProductCount").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(marketingProductCount))
                    return Convert.ToInt32(marketingProductCount);
                else
                    return null;
            }
        }

        public int? PCProductCount
        {
            get
            {
                string pcProductCount = this.context.User.Claims.Where(c => c.Type == "PCProductCount").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(pcProductCount))
                    return Convert.ToInt32(pcProductCount);
                else
                    return null;
            }
        }

        public int? AgencyDataMaintainer
        {
            get
            {
                string agencyDataMaintainer = this.context.User.Claims.Where(c => c.Type == "AgencyDataMaintainer").Select(c => c.Value).SingleOrDefault();
                if (!string.IsNullOrEmpty(agencyDataMaintainer))
                    return Convert.ToInt32(agencyDataMaintainer);
                else
                    return null;
            }
        }

        public int ProductImageEdit
        {
            get
            {
                return Convert.ToInt32(this.context.User.Claims.Where(c => c.Type == "ProductImageEdit")
                    .Select(c => c.Value).SingleOrDefault());
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.Utilities;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;

namespace HPi.Pulsar.Mvc.ClaimsTransformer
{


    public class AppClaimsTransformer : IClaimsTransformation
    {
        public AppClaimsTransformer(IConfiguration configuration, IUserInfoService userService, IHttpContextAccessor httpAccessor)
        {
            serviceName = configuration["ServiceBaseURLs:1:ServiceName"].ToString();
            serviceURL = configuration["ServiceBaseURLs:1:ServiceUrl"].ToString();
            UserService = userService;
            environmentMode = configuration["Environment:Mode"].ToString();
            this.context = httpAccessor;
        }

        protected IUserInfoService UserService { get; set; }

        #region Private Variables
        private string serviceName { get; set; }

        private IHttpContextAccessor context;

        private string serviceURL { get; set; }

        private string environmentMode { get; set; }

        private const string appCookieName = "PulsarSession";

        private string loginUserName = AppSettings.Get<string>("LoginUser:User") != "" ? AppSettings.Get<string>("LoginUser:User") : string.Empty;

        private string loginUserDomain = AppSettings.Get<string>("LoginUser:Auth") != "" ? AppSettings.Get<string>("LoginUser:Auth") : string.Empty;
        #endregion

        public async Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal claimsPrincipal)
        {
            Validator.ValidateObjectNotNull(context, nameof(context));

            var sessionCookie = context.HttpContext.Request.Cookies[appCookieName];
            if (sessionCookie == null)
            {
                var sessionGuid = Guid.NewGuid().ToString().Replace("-", string.Empty);
                context.HttpContext.Response.Cookies.Append(appCookieName, sessionGuid);
            }

            var isReverseProxy = false;
            // use ApplicationUser instead
            UserInfoModel userInfo = null;

            

            //if (context.HttpContext.User.Identity?.IsAuthenticated == false)
            if(claimsPrincipal.Identity.IsAuthenticated)
            {
                int id = 0;
                //if (context.HttpContext.User.Identity.Name != null)
                if(claimsPrincipal.Identity.Name != null)
                {
                    if (environmentMode != "Development")
                    {
                        //if (context.HttpContext.User.Identity.Name.Contains("\\"))
                         if(claimsPrincipal.Identity.Name.Contains("\\"))
                        {
                            /*loginUserDomain = context.HttpContext.User.Identity.Name.Split('\\')[0];
                            loginUserName = context.HttpContext.User.Identity.Name.Split('\\')[1];*/
                            loginUserDomain = claimsPrincipal.Identity.Name.Split('\\')[0];
                            loginUserName = claimsPrincipal.Identity.Name.Split('\\')[1];
                        }
                    }
                    userInfo = await this.UserService.GetUserInfoByUserNameAsync(loginUserName, loginUserDomain).ConfigureAwait(false);
                }
                else
                {
                    id = int.Parse(ClaimsPrincipal.Current.FindFirst("ActualUserID").Value);
                    userInfo = await UserService.GetUserByIdAsync(id).ConfigureAwait(false);
                }

            }
            else
            {
                // check for prp connection
                string httpHost = context.HttpContext.Request.Headers["HOST"];

                if (!string.IsNullOrWhiteSpace(httpHost))
                {
                    if (httpHost.IndexOf("prp", StringComparison.Ordinal) != -1)
                    {
                        isReverseProxy = true;
                    }
                }

                // get auth user *** FOR NON-PROD SUPPORT ***
                string authUser = context.HttpContext.Request.Headers["AUTH_USER"];
                if (!string.IsNullOrWhiteSpace(authUser))
                {
                    userInfo = await UserService.GetUserByNameAsync(authUser).ConfigureAwait(false);
                }

                // if auth user lookup failed, try nt user
                string userDomainId = context.HttpContext.Request.Headers["HPPF_AUTH_NTUSERDOMAINID"];

                if (userInfo == null && !string.IsNullOrWhiteSpace(userDomainId))
                {
                    var splitter = new[] { ':', '\\', ' ' };
                    var userDomainIdParts = userDomainId.Split(splitter);
                    if (userDomainIdParts.Length == 2)
                    {
                        var userName = $"{userDomainIdParts[0]}\\{userDomainIdParts[1]}";
                        userInfo = await UserService.GetUserByNameAsync(userName).ConfigureAwait(false);
                        if (userInfo != null)
                        {
                            loginUserName = userInfo.NtName;
                            loginUserDomain = userInfo.NtDomain;
                            userInfo = await this.UserService.GetUserInfoByUserNameAsync(loginUserName, loginUserDomain).ConfigureAwait(false);
                        }
                    }
                }

                // if nt user lookup failed, try email address
                string email = context.HttpContext.Request.Headers["HPPF_AUTH_UID"];

                if (userInfo == null && !string.IsNullOrWhiteSpace(email))
                {
                    userInfo = await UserService.GetUserByEmailAsync(email).ConfigureAwait(false);
                    if (userInfo != null)
                    {
                        loginUserName = userInfo.NtName;
                        loginUserDomain = userInfo.NtDomain;
                        userInfo = await this.UserService.GetUserInfoByUserNameAsync(loginUserName, loginUserDomain).ConfigureAwait(false);
                    }
                }
            }

            ClaimsIdentity userIdentity = null;
            if (userInfo == null)
            {
                // create default claims principal
                userIdentity = UserInfoModel.Empty().CreateClaimsIdentity(isReverseProxy);
            }
            else
            {
                // create claims principal for user & impersonation
                var actualUserId = userInfo.UserId;
                var actualUserName = userInfo.FullNameAuthendication;
                //if (userInfo.ImpersonateId > 0)
                //{
                //    userInfo = await UserService.GetUserById(userInfo.UserId);
                //}

                userIdentity = userInfo.CreateClaimsIdentity(isReverseProxy, loginUserName, loginUserDomain);
            }

            // update last activity
            //context.HttpContext.User.AddIdentity(userIdentity);
            claimsPrincipal.AddIdentity(userIdentity);
            context.HttpContext.User = claimsPrincipal;

            if (userInfo == null || (userInfo != null && userInfo.UserId <= 0))
            {
                throw new Exception("Userid is 0");

                //string loginpage = context.Context.Request.Headers["HOST"].ToString()  + "/Pulsar/user/loginfailed";
                //context.Context.Response.Redirect(loginpage);
            }

            return await Task.FromResult(context.HttpContext.User);
        }

    }
}

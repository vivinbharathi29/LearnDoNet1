﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;


namespace HPi.Pulsar.Mvc.ClaimsTransformer
{

    public static class ClaimsMethods
    {
        public static ClaimsIdentity CreateClaimsIdentity(this UserInfoModel userInfo, bool isReverseProxy)
        {
            return userInfo.CreateClaimsIdentity(isReverseProxy, userInfo.LoginUserName, userInfo.FullName);
        }

        public static ClaimsIdentity CreateClaimsIdentity(this UserInfoModel userInfo, bool isReverseProxy, string loginUserName, string loginUserDomain)
        {
            var claims = new List<Claim>();
            if (userInfo != null && userInfo.UserId > 0 && !userInfo.Disabled.HasValue)
            {
                //add UserModel properties to claims list
                claims.Add(new Claim(ClaimTypes.Name, Convert.ToString(userInfo.AuthName)));
                claims.Add(new Claim(ClaimTypes.Email, Convert.ToString(userInfo.Email)));
                claims.Add(new Claim(ClaimTypes.GivenName, Convert.ToString(userInfo.DisplayName)));
                claims.Add(new Claim("Name", Convert.ToString(userInfo.AuthName)));
                claims.Add(new Claim("Email", Convert.ToString(userInfo.Email)));
                claims.Add(new Claim("UserName", Convert.ToString(userInfo.FullName)));
                claims.Add(new Claim("UserId", Convert.ToString(userInfo.UserId)));
                claims.Add(new Claim("PMImpersonate", Convert.ToString(userInfo.PMImpersonate)));
                claims.Add(new Claim("CMImpersonate", Convert.ToString(userInfo.CMImpersonate)));
                claims.Add(new Claim("PCImpersonate", Convert.ToString(userInfo.PCImpersonate)));
                claims.Add(new Claim("PhWebImpersonate", Convert.ToString(userInfo.PhWebImpersonate)));
                claims.Add(new Claim("CurrentName", Convert.ToString(userInfo.CurrentName)));
                claims.Add(new Claim("originalName", Convert.ToString(userInfo.originalName)));
                claims.Add(new Claim("LoginAuthName", Convert.ToString(loginUserName)));
                claims.Add(new Claim("LoginDomain", Convert.ToString(loginUserDomain)));
                claims.Add(new Claim("Favourites", userInfo.Favorites == null ? string.Empty : Convert.ToString(userInfo.Favorites)));
                claims.Add(new Claim("MarketingImpersonate", Convert.ToString(userInfo.MarketingImpersonate)));
                claims.Add(new Claim("ServicePM", userInfo.ServicePM.HasValue ? userInfo.ServicePM.Value.ToString() : "false"));
                claims.Add(new Claim("WWANEngineer", userInfo.WWANEngineer.HasValue ? userInfo.WWANEngineer.Value.ToString() : "false"));
                claims.Add(new Claim("ProcurementEngineer", userInfo.ProcurementEngineer.HasValue ? userInfo.ProcurementEngineer.Value.ToString() : "false"));
                claims.Add(new Claim("ServiceCommodityManager", userInfo.ServiceCommodityManager.HasValue ? userInfo.ServiceCommodityManager.Value.ToString() : "false"));
                claims.Add(new Claim("SepmCount", userInfo.SEPMProducts.HasValue ? userInfo.SEPMProducts.Value.ToString() : "0"));
                claims.Add(new Claim("PreInstall", userInfo.PreinstallPM.HasValue ? userInfo.PreinstallPM.Value.ToString() : "false"));
                claims.Add(new Claim("PartnerId", Convert.ToString(userInfo.PartnerId)));
                if (userInfo.Partner != null)
                {
                    claims.Add(new Claim("PartnerTypeId", Convert.ToString(userInfo.Partner.PartnerTypeID)));
                }
                claims.Add(new Claim("PulsarSystemAdmin", userInfo.PulsarSystemAdmin.HasValue ? Convert.ToString(userInfo.PulsarSystemAdmin) : "0"));
                claims.Add(new Claim("WorkGroupId", userInfo.WorkgroupID.HasValue ? userInfo.WorkgroupID.Value.ToString() : "0"));
                claims.Add(new Claim("OriginalUserId", Convert.ToString(userInfo.OriginalUserId)));
                claims.Add(new Claim("ImpersonateId", Convert.ToString(userInfo.ImpersonateId)));
                claims.Add(new Claim("DefaultWorkingListProduct", Convert.ToString(userInfo.DefaultWorkingListProduct)));
                claims.Add(new Claim("CommodityPM", userInfo.CommodityPM.HasValue ? userInfo.CommodityPM.Value.ToString() : "false"));
                claims.Add(new Claim("SCFactoryEngineer", userInfo.SCFactoryEngineer.HasValue ? userInfo.SCFactoryEngineer.Value.ToString() : "false"));
                claims.Add(new Claim("AccessoryPM", userInfo.AccessoryPM.HasValue ? userInfo.AccessoryPM.Value.ToString() : "false"));
                claims.Add(new Claim("EngCoordinator", Convert.ToString(userInfo.EngCoordinatorForConfiguration)));
                claims.Add(new Claim("SAAdmin", Convert.ToString(userInfo.SAAdmin)));
                claims.Add(new Claim("ServiceCoordinator", userInfo.ServiceCoordinator.HasValue ? userInfo.ServiceCoordinator.Value.ToString() : "false"));
                claims.Add(new Claim("Division", userInfo.Division.HasValue ? userInfo.Division.Value.ToString() : ""));
                claims.Add(new Claim("IsSystemAdmin", userInfo.SystemAdmin.HasValue ? Convert.ToString(userInfo.SystemAdmin) : "false"));
                claims.Add(new Claim("IsWHQLTestTeam", userInfo.WHQLTestTeam.HasValue ? userInfo.WHQLTestTeam.Value.ToString() : "false"));
                claims.Add(new Claim("IsMITTestLead", userInfo.MITTestLead.HasValue ? userInfo.MITTestLead.Value.ToString() : "false"));
                claims.Add(new Claim("CMProductCount", userInfo.CMProductCount.HasValue ? userInfo.CMProductCount.Value.ToString() : "0"));
                claims.Add(new Claim("MarketingProductCount", userInfo.MarketingProductCount.HasValue ? userInfo.MarketingProductCount.Value.ToString() : "0"));
                claims.Add(new Claim("PCProductCount", userInfo.PCProductCount.HasValue ? userInfo.PCProductCount.Value.ToString() : "0"));
                claims.Add(new Claim("AgencyDataMaintainer", userInfo.AgencyDataMaintainer.HasValue ? userInfo.AgencyDataMaintainer.Value.ToString() : "0"));
                claims.Add(new Claim("ProductImageEdit", Convert.ToString(userInfo.ProductImageEdit)));
            }
            else
            {
                //add UserModel properties to claims list
                claims.Add(new Claim(ClaimTypes.Name, Convert.ToString(userInfo.AuthName)));
                claims.Add(new Claim(ClaimTypes.Email, Convert.ToString(userInfo.Email)));
                claims.Add(new Claim(ClaimTypes.GivenName, Convert.ToString(userInfo.DisplayName)));
                claims.Add(new Claim("Name", Convert.ToString(userInfo.AuthName)));
                claims.Add(new Claim("Email", string.Empty));
                claims.Add(new Claim("UserName", string.Empty));
                claims.Add(new Claim("UserId", string.Empty));
                claims.Add(new Claim("CMImpersonate", string.Empty));
                claims.Add(new Claim("PCImpersonate", string.Empty));
                claims.Add(new Claim("PhWebImpersonate", string.Empty));
                claims.Add(new Claim("CurrentName", string.Empty));
                claims.Add(new Claim("originalName", string.Empty));
                claims.Add(new Claim("LoginAuthName", string.Empty));
                claims.Add(new Claim("LoginDomain", string.Empty));
                claims.Add(new Claim("Favourites", string.Empty));
                claims.Add(new Claim("MarketingImpersonate", Convert.ToString(userInfo.MarketingImpersonate)));
                claims.Add(new Claim("ServicePM", "false"));
                claims.Add(new Claim("WWANEngineer", "false"));
                claims.Add(new Claim("ProcurementEngineer", "false"));
                claims.Add(new Claim("ServiceCommodityManager", "false"));
                claims.Add(new Claim("SepmCount", "0"));
                claims.Add(new Claim("PreInstall", "false"));
                claims.Add(new Claim("PartnerId", Convert.ToString(userInfo.PartnerId)));
                claims.Add(new Claim("PartnerTypeId", "0"));
                claims.Add(new Claim("PulsarSystemAdmin", "0"));
                claims.Add(new Claim("WorkGroupId", "0"));
                claims.Add(new Claim("OriginalUserId", string.Empty));
                claims.Add(new Claim("ImpersonateId", string.Empty));
                claims.Add(new Claim("DefaultWorkingListProduct", string.Empty));
                claims.Add(new Claim("CommodityPM", "0"));
                claims.Add(new Claim("SCFactoryEngineer", "0"));
                claims.Add(new Claim("AccessoryPM", "0"));
                claims.Add(new Claim("EngCoordinator", "0"));
                claims.Add(new Claim("SAAdmin", "0"));
                claims.Add(new Claim("ServiceCoordinator", "false"));
                claims.Add(new Claim("Division", string.Empty));
                claims.Add(new Claim("IsSystemAdmin", "false"));
                claims.Add(new Claim("IsWHQLTestTeam", "false"));
                claims.Add(new Claim("IsMITTestLead", "false"));
                claims.Add(new Claim("CMProductCount", "0"));
                claims.Add(new Claim("MarketingProductCount", "0"));
                claims.Add(new Claim("PCProductCount", "0"));
                claims.Add(new Claim("AgencyDataMaintainer", "0"));
                claims.Add(new Claim("ProductImageEdit", "0"));
            }
            return new ClaimsIdentity(claims, "PulsarIdentity");
        }
    }
}
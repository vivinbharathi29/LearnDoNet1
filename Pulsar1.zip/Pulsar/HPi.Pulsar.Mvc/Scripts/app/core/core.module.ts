﻿import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute, Routes } from '@angular/router';

import { throwIfAlreadyLoaded } from './module-import-guard';
import { TopMenuComponent } from './top-menu/top-menu.component';
import { PageHeaderComponent } from './header_footer/page-header.component';
import { PageFooterComponent } from './header_footer/page-footer.component';
import { ExternalModalPopupComponent } from './external-modal-popup/external-modal-popup.component';


@NgModule({
    imports: [
        CommonModule, // we use ngFor
        FormsModule,
        RouterModule
    ],
    exports: [TopMenuComponent, PageHeaderComponent, PageFooterComponent, ExternalModalPopupComponent],
    declarations: [TopMenuComponent, PageHeaderComponent, PageFooterComponent, ExternalModalPopupComponent]

})
export class CoreModule {
    constructor( @Optional() @SkipSelf() parentModule: CoreModule) {
        throwIfAlreadyLoaded(parentModule, 'CoreModule');
    }
}

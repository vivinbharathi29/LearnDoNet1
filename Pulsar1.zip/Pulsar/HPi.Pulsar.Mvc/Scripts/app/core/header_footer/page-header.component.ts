﻿/// <reference path="../../Shared/function_definition/functiondefinition.ts" />
import { Component, OnInit } from '@angular/core';
import { TopMenuComponent } from '../top-menu/top-menu.component'
import { PageHeaderService } from './page-header.service'
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';

@Component({
    selector: 'page-header-content',
    templateUrl: './page-header.component.html',
    providers: [PageHeaderService]
})

export class PageHeaderComponent implements OnInit {

    //public configureUrl: string = "/Excalibur/MobileSE/Today/Configure.asp?app=PulsarPlus";
    public configureUrl: string = "/pulsarplus/today/TodayPage/GetTodayPageSubsectionConfig/";
    public impersonateUrl: string = "/pulsarplus/core/User/ChooseEmployee?dialogType=1";
    //public impersonateUrl: string = "/Excalibur/MobileSE/Today/ChangeUser.asp?app=PulsarPlus";
    public profileUrl: string;
    public enableImpersonate: boolean = false;
    public supportUrl: string = "/pulsarplus/today/TodayPage/GetSupportDetails?flag=false";
    public userId: number;
    public configureTitle: string = "Configure Today Page";
    public impersonateTitle: string = "Change User"
    public profileTitle: string = "User's Properties";
    public supportTitle: string = "Pulsar Support";
    public currentUserName: string = '';
    public currentName: string = '';
    public originalName: string = '';
    public environmentName: string = "";

    constructor(private http: Http, private service: PageHeaderService) {

    }

    ngOnInit() {
        this.service.getUserInfofromcontext().subscribe(result => {
            var userdata = result.json().userInfo;
            this.currentUserName = userdata.loginUserName;
            this.currentName = userdata.currentName == userdata.originalName ? '' : userdata.currentName;
            this.originalName = userdata.originalName;
            this.userId = userdata.userId;
            this.enableImpersonate = userdata.pulsarSystemAdmin == 1 || userdata.userId != userdata.employeeId ? true : false;
            this.profileUrl = "/IPulsar/Admin/System Admin/AddUserToTeam_Edit.aspx?UserId=" + this.userId + " &TeamID=0&FromTodayPage=1&app=PulsarPlus";
        });

        this.service.getEnvironmentName().subscribe(
            result => {
                this.environmentName = "[" + result.json().environmentName + "]";
                if (this.environmentName.toLowerCase().indexOf("sandbox") > -1) {
                    $(".megamenu_fixed").addClass('megamenu_sandboxtheme');
                    $("#environmentname").addClass('blinking');
                    return false;
                }
                else if (this.environmentName.toLowerCase().indexOf("test") > -1) {
                    $(".megamenu_fixed").addClass('megamenu_testtheme');
                    $("#environmentname").addClass('blinking');
                    return false;
                }
                $(".blinking").delay(1000).css({ "animation": "display 4s infinite" });
            }
        );
    }

    ViewPopup(url: string, title: string, page: string) {
        //var windowHeight = window.document.body.clientHeight - 200;
        //var windowWidth = (window.document.body.clientWidth * 60) / 100;
        var windowHeight = "650px";
        var windowWidth = 800;
        if (page == "support") {
            windowWidth = 920;
        }
        if (title == "Change User") {
            showPopupFirstlevel(url, title, "480px", "90%");
        }
        else if (title == "Configure Today Page") {
            showPopupFirstlevel(url, title, "600px", "90%");
        }
        else if (title == "Pulsar Support") {
            //adjustableShowPopup(url, title, "635px", "80%", "600px");
            showPopupFirstlevelWithHeightInPercentage(url, title, "80%", "95%");
        }
        else {
            showPopup(url, title, windowHeight, windowWidth);
        }
    }
}
﻿import { Component, ViewChild, AfterViewInit } from '@angular/core';

@Component({
    selector: 'page-footer-content',
    templateUrl: './page-footer.component.html',
})
export class PageFooterComponent {
    CopyrightYear: any;
    constructor()
    {
        let date: any = new Date();
        this.CopyrightYear = date.getFullYear();
    }
}
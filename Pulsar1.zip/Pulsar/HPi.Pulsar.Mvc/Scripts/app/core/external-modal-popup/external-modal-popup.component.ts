﻿import { Component } from '@angular/core';

@Component({
    selector: 'external-modal-popup',
    templateUrl: './external-modal-popup.component.html'
})
export class ExternalModalPopupComponent  {
    constructor() {
    }
}
/// <reference path="favorite-view-model.model.ts" />
/// <reference path="mega-menu-model.model.ts" />
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 04/11/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="mega-menu-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { FavoriteViewModel } from './favorite-view-model.model';
import { MegaMenuModel } from './mega-menu-model.model';

export class MegaMenuViewModel {
    megaMenus: MegaMenuModel[];
    favouriteMenus: FavoriteViewModel[];
    isSystemAdmin: boolean;
    userId: number;
    irsURL: string;
    partnerTypeId: number;
    isSupportAdmin: boolean;
}
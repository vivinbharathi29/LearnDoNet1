// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 04/11/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="mega-menu-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class MegaMenuModel
{
	menuID : number;
	name : string;
	displayName : string;
	link : string;
	parentName : string;
	rowNumber : any;
	columnNumber : any;
	fullWidth : boolean;
	totalColumns : any;
	hPOnly? : boolean;
	adminOnly? : boolean;
	openRoles : string;
	userRoles : string;
}
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 04/11/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="favorite-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class FavoriteViewModel
{
	favoriteId : number;
	employeeId : number;
	name : string;
	link : string;
	imageUrl : string;
	pulsarImageUrl : string;
	fusionRequirements : boolean;
	type : string;
}
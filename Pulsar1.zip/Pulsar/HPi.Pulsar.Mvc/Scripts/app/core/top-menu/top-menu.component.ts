﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay
// Created          : 04/08/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 07/13/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="top-menu.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { TopMenuService } from "./top-menu.service";
import { MegaMenuViewModel } from './mega-menu-view-model.model';
import { FavouriteMenuViewModel } from './favourite-menu-view-model.model';
import { ModalPopupComponent } from '../../shared/modal_popup/modal-popup.component'

@Component({
    selector: 'top-menu',
    templateUrl:'./top-menu.component.html',    
    providers: [TopMenuService]
})

export class TopMenuComponent implements OnInit {
    public megaMenuViewModel: MegaMenuViewModel;
    favouriteMenuViewModel: FavouriteMenuViewModel;
    constructor(private topMenuService: TopMenuService) {
        this.megaMenuViewModel = new MegaMenuViewModel();
        this.favouriteMenuViewModel = new FavouriteMenuViewModel();
    }

    ngOnInit() {
        this.getMegaMenu();
        this.getFavouriteMenu();
    }

    getMegaMenu() {
        this.topMenuService.getMegaMenu().subscribe(data => {
            this.megaMenuViewModel = data.json().megaMenuViewModel;
            setTimeout(function () {                
                setMegaMenu();
            },1500);
        });
    }

    getFavouriteMenu() {
        this.topMenuService.getFavouriteMenu().subscribe(data => {
            //console.log(data.json());
            this.favouriteMenuViewModel = data.json();
        });
    }

    ViewPopup(url: string, title: string) {        
        var windowHeight = "600px";
        var windowWidth = "90%"; 

        if (title == "Add New") {
            windowHeight = "640px";
            windowWidth = "970px";
        }
      //showPopup(url, title, windowHeight, windowWidth);
        showPopupFirstlevel(url, title, windowHeight, windowWidth);
        if (title == "Add New") {
            $("#externalpopup").css("cssText", "width: 970px !important;");
        }   
    }

    ViewPopupWithDimension(url: string, title: string, width: string, height: string) {
        var windowHeight = height;
        var windowWidth = width;
        //showPopup(url, title, windowHeight, windowWidth);
        showPopupFirstlevel(url, title, windowHeight, windowWidth);
    }

    openHoustonTime(): void {
        var url = "";
        var title = "";
        var height = "300px";
        var iframeHeight = "270px";
        var width = "320px";
        url = "/Pulsar/Common/Time";
        title = "Houston Time";
        adjustableShowPopup(url, title, height, width, iframeHeight);        
    }

    launchIMSPopUp()
    {
        launchIMS();
    }

    launchInitialOffering()
    {
        //console.log("this.megaMenuViewModel.userId", this.megaMenuViewModel.userId);
        initialOffering(this.megaMenuViewModel.userId);
    }

    topmenuhover(menuItem: string, event:any)
    {   
        if (event.type == "mouseover") {
            switch (menuItem.toLowerCase()) {
                case "marketing":
                    $(event.target).css('background-color', '#800080');
                    break;
                case "supply chain":
                    $(event.target).css('background-color', '#FFA500');
                    break;
                case "r&d":
                    $(event.target).css('background-color', '#008000');
                    break;
                case "service":
                    $(event.target).css('background-color', '#FFFF00');
                    break;
                case "others":
                    $(event.target).css('background-color', '#808080');
                    break;
                default:
                    break;
            }
        }
        else if (event.type == "mouseout") {
            $(event.target).css('background-color', '');
        }
    }
}
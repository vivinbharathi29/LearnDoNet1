// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 07/13/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="favourite-menu-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { FavoriteViewModel } from './favorite-view-model.model';

export class FavouriteMenuViewModel
{
    legacyProduct: FavoriteViewModel[];
    pulsarProduct: FavoriteViewModel[];
    components: FavoriteViewModel[];
	userId : number;
}
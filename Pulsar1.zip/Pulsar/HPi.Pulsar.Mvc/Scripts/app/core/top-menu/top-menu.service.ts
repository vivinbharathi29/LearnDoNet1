﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\rajamanr
// Created          : 04/04/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="top-menu.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams, ResponseContentType } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class TopMenuService {
    constructor(private http: Http, private location: Location) {
    }
    getMegaMenu() {
        return this.http.get(this.location.prepareExternalUrl('/MegaMenu/Index'));
    }

    getFavouriteMenu() {
        return this.http.get(this.location.prepareExternalUrl('/MegaMenu/GetFavouriteMenuItems'));
    }
}

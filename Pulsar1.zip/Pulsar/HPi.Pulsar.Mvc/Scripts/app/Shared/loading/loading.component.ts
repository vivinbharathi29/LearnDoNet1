﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay
// Created          : 06/27/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 07/03/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="test.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, Input } from '@angular/core';


@Component({
    selector: 'loading-gif',
    templateUrl: './loading.component.html',
})
export class LoadingComponent {
    @Input() showLoading: boolean = false;
    constructor() {

    }
}
﻿import { Component, Directive, ElementRef, Input, Output, EventEmitter,Injectable } from '@angular/core';
@Injectable()
export class CustomValidationService {
    static emailValidator(control): boolean {
        var emailIds = control.value.split(";");
        for (let i = 0; i < emailIds.length; i++) {
            if (emailIds[i] != "" && emailIds[i] != null) {
                if (emailIds[i].match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {

                } else {
                    return false;
                }
            }
        }
        return true;
    }
    static dropdownValidator(control): boolean {
        var value = control.value;
        if (value == null || value == 0) {
            return false;
                } else {
                    return true;
                }
    }
    static getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        let config = {
            'required': 'Required',
            'invalidCreditCard': 'Is invalid credit card number',
            'invalidEmailAddress': 'Invalid email address',
            'invalidPassword': 'Invalid password. Password must be at least 6 characters long, and contain a number.',
        };

        return config[validatorName];
    }
    static isHex(systemBoardId): boolean {
        if (systemBoardId.match(/[0-9A-Fa-f]{4}/g)) {
            return true;
        } else {
            return false;
        }
    }
}
﻿import { Component,Injectable } from '@angular/core';
import { Http } from '@angular/http';
import * as CryptoJS from "crypto-js";
import { Location } from '@angular/common';
import { RouterModule, ActivatedRoute } from '@angular/router';

@Component({
    selector: 'Encryption',
    template: '<h1>test</h1>'

})
@Injectable()
export class AESEncryption {

    public encryptedString;
    public decryptedString:any;
    public http: Http;
    public location: Location;
    constructor(http: Http, location: Location) {
        this.http = http;
        this.location = location;
    }
    public Encrypt(plaintext: any) {
        var key = CryptoJS.enc.Utf8.parse('7061737323313233');
        var iv = CryptoJS.enc.Utf8.parse('7061737323313233');
        var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(plaintext), key,
            {
                keySize: 128 / 8,
                iv: iv,
                mode: CryptoJS.mode.CBC,
                padding: CryptoJS.pad.Pkcs7
            });
        return encrypted;
    }
    public Decrypt(encryptedstring: any) {
        var key = CryptoJS.enc.Utf8.parse('7061737323313233');
        var iv = CryptoJS.enc.Utf8.parse('7061737323313233');
        this.decryptedString = CryptoJS.AES.decrypt(encryptedstring, key, {
            keySize: 128 / 8,
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        }).toString(CryptoJS.enc.Utf8);
        return this.decryptedString;
        //var querystring = this.decryptedString.split('&');
        //var parameter = querystring.split('=');
    }

}


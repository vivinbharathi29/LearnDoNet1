/// <reference path="listsortdirection.ts" />
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 04-04-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="pagination-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { ListSortDirection } from './listsortdirection';

export class pagination
{
	private _pageNo : number;
	private _pageSize : number;
	private  _sortBy : string;
    private _sortDirection: ListSortDirection;

    constructor() {

    }

    get PageNo(): number {
        return this._pageNo;
    }
    set PageNo(val: number) {
        this._pageNo = val;
    }
    get PageSize(): number {
        return this._pageSize;
    }
    set PageSize(val: number) {
        this._pageSize = val;
    }
    get SortBy(): string {
        return this._sortBy;
    }
    set SortBy(val: string) {
        this._sortBy = val;
    }
    get SortDirection(): ListSortDirection {
        return this._sortDirection;
    }

    set SortDirection(val: ListSortDirection) {
        this._sortDirection = val;
        switch (this._sortDirection) {
            case ListSortDirection.Ascending:
                break;
            case ListSortDirection.Descending:
                break;
            
        }
    }
  
}
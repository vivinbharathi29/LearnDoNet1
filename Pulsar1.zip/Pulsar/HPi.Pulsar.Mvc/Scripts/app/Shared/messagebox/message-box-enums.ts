﻿export enum MessageBoxIcon {
    Information,
    Warning,
    Error,
    Question
}

export enum MessageBoxType {
    YesNo,
    Ok,
    OKCancel
}

export enum MessageBoxButton {
    Yes,
    No,
    Ok,
    Cancel
}
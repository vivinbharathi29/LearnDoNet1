
import { MessageBoxButton, MessageBoxIcon, MessageBoxType } from "./message-box-enums"

export class MessageBoxConfig {

	private _title:string;
	private _message:string;
    private _type: MessageBoxIcon;
	private _icon:string;
	private _width:number;
	private _height:number;
	private _confirmBtn:string;
    private _cancelBtn: string;
    private _close: (mbr: MessageBoxButton) => any;
	constructor() {
		this._title = 'Default title';
        this._message = 'Default message';
        this.type = MessageBoxIcon.Information;
		this._width = 250;
		this._height = 150;
		this._confirmBtn = null;
		this._cancelBtn = 'OK';
    }

    get close(): ((mbr: MessageBoxButton) => any) {
        return this._close;
    }

    set close(val: ((n: MessageBoxButton) => any)) {
        this._close = val;
    }
	
	get title() : string {
		return this._title;
	}

	set title(val:string) {
		this._title = val;
	}

	get message() : string {
		return this._message;
	}

	set message(val:string) {
		this._message = val;
	}

	get icon() : string {
		return this._icon;
	}

	set icon(val:string) {
		this._icon = val;
	}

    get type(): MessageBoxIcon {
		return this._type;
	}

    set type(val: MessageBoxIcon)  {
		this._type = val;

		switch (this._type) {
            case MessageBoxIcon.Information:
                //this._icon = '/info-circle.svg';
                this._icon = '';
				break;
            case MessageBoxIcon.Warning:
               // this._icon = '/warning.svg';
                this._icon = '';
                break;
            case MessageBoxIcon.Error:
                //this._icon = '/exclamation-circle.svg';
                this._icon = '';
				break;
			default:
				this._icon = undefined;
				break;
		}
	}

	get width() : number {
		return this._width;
	}

	set width(val:number) {
		this._width = val;
	}

	get height() : number {
		return this._height;
	}

	set height(val:number) {
		this._height = val;
	}

	get confirmBtn() : string {
		return this._confirmBtn;
	}

	set confirmBtn(val:string) {
		this._confirmBtn = val;
	}

	get cancelBtn() : string {
		return this._cancelBtn;
	}

	set cancelBtn(val:string) {
		this._cancelBtn = val;
	}

}

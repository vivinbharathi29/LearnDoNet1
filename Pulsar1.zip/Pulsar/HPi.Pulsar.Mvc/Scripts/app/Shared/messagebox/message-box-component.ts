import {
    ApplicationRef, ComponentFactoryResolver, ComponentRef, Injectable, ReflectiveInjector,
    Injector, ViewContainerRef, EmbeddedViewRef, Type
} from '@angular/core';
import { BaseModal } from './base-modal.component';
import { MessageBoxBootstrap } from './message-box-bootstrap';
import { MessageBoxConfig } from './message-box-config';
import {  MessageBoxIcon, MessageBoxButton, MessageBoxType } from './message-box-enums';


@Injectable()
export class MessageBox {
    private _container: ComponentRef<any>;
    private messageboxconfig: MessageBoxConfig = new MessageBoxConfig();
    private bootstrap: boolean = true;
    private messageboxicon: MessageBoxIcon;
    private messageboxtype: MessageBoxType;

    constructor(
        private applicationRef: ApplicationRef,
        private componentFactoryResolver: ComponentFactoryResolver,
        private injector: Injector) {
    }

    private modalType(index: any) {
        this.messageboxicon = index;
        switch (this.messageboxicon) {
            case MessageBoxIcon.Information:
                //this.messageboxconfig.title = 'Information';
                this.messageboxconfig.type = MessageBoxIcon.Information;
                break;
            case MessageBoxIcon.Warning:
               // this.messageboxconfig.title = 'Warning';
                this.messageboxconfig.type = MessageBoxIcon.Warning;
                break;
            case MessageBoxIcon.Error:
               // this.messageboxconfig.title = 'Critical';
                this.messageboxconfig.type = MessageBoxIcon.Error;
                break;
            default:
               // this.messageboxconfig.title = 'Default title';
                this.messageboxconfig.type = MessageBoxIcon.Information;
                break;
        }
    }

    private buttontype(index: any) {
        this.messageboxtype = index;
        switch (this.messageboxtype) {
            case MessageBoxType.Ok:
                this.messageboxconfig.confirmBtn ="Ok";
                this.messageboxconfig.cancelBtn = null;
                break;
            case MessageBoxType.OKCancel:
                this.messageboxconfig.confirmBtn ="Ok";
                this.messageboxconfig.cancelBtn = "Cancel";
                break;
            case MessageBoxType.YesNo:
                this.messageboxconfig.confirmBtn = "Yes";
                this.messageboxconfig.cancelBtn = "No";
                 break;
           
        }
    }

    Show(title: any, message: any, messageBoxButton: any, messageBoxIcon: any, width: any, callback: (mbb: MessageBoxButton) => any): ComponentRef<MessageBoxBootstrap> {
        this.messageboxconfig.title = title;
        this.modalType(messageBoxIcon);
        this.buttontype(messageBoxButton);
        this.messageboxconfig.message = message;
        this.messageboxconfig.width = width;
        this.messageboxconfig.close = callback;
        return this.appendComponent(this.messageboxconfig, (MessageBoxBootstrap))

    }

    private getRootViewContainer(): ComponentRef<any> {
        if (this._container) return this._container;

        const rootComponents = this.applicationRef['_rootComponents'];
        if (rootComponents.length) return rootComponents[0];

        throw new Error('View Container not found! ngUpgrade needs to manually set this via setRootViewContainer.');
    }

    private setRootViewContainer(container): void {
        this._container = container;
    }

    private  getComponentRootNode(componentRef: ComponentRef<any>): HTMLElement {
        return (componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;
    }

    private  getRootViewContainerNode(): HTMLElement {
        return this.getComponentRootNode(this.getRootViewContainer());
    }

    private projectComponentInputs(component: ComponentRef<any>, options: any): ComponentRef<any> {
        if (options) {
            const props = Object.getOwnPropertyNames(options);
            for (const prop of props) {
                component.instance[prop] = options[prop];
            }
        }

        return component;
    }

    private appendComponent(
        modalconfig: any,
        componentClass: Type<MessageBoxBootstrap>,
        location: Element = this.getRootViewContainerNode()): ComponentRef<any> {
        

        let componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentClass);
        		let inj:ReflectiveInjector;
                if (modalconfig.constructor.name === 'MessageBoxConfig') {
                    inj = ReflectiveInjector.resolveAndCreate([
                        { provide: MessageBoxConfig, useValue: modalconfig }], this.injector);
		} else {
                    inj = ReflectiveInjector.resolveAndCreate([
                        { provide: modalconfig.constructor, useValue: modalconfig }, { provide: MessageBoxConfig, useValue: modalconfig }], this.injector);
                }
                let componentRef = componentFactory.create(inj);
        let appRef: any = this.applicationRef;
        let componentRootNode = this.getComponentRootNode(componentRef);

        this.projectComponentInputs(componentRef, modalconfig);

        if (appRef['attachView']) {
            appRef.attachView(componentRef.hostView);

       } else {
            let changeDetectorRef = componentRef.changeDetectorRef;
            appRef.registerChangeDetector(changeDetectorRef);

            componentRef.onDestroy(() => {
                appRef.unregisterChangeDetector(changeDetectorRef);
                if (componentRootNode.parentNode) {
                    componentRootNode.parentNode.removeChild(componentRootNode);
                }
            });
        }

        location.appendChild(componentRootNode);

        return componentRef;
    }
}


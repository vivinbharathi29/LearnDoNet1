import { Component, ComponentRef, Type, ReflectiveInjector,ElementRef , Injector, Injectable,  } from '@angular/core';

import { MessageBoxConfig } from './message-box-config';
declare var Jquery: any;
@Component({
	selector: 'base-message-box',
    //styleUrls: [require('../css/modal.css')],
    styles: [`
.modal {
	position: fixed;
	border: 2px solid #eee;
	border-radius: 4px;
	background-color: #fff;
	padding:15px;   
	left:50%; 
	top:35%;
	-webkit-transform: translate(-50%, -50%);
	-moz-transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	-o-transform: translate(-50%, -50%);
	transform: translate(-50%, -50%);
}
.angularHeader button
{
opacity:0.9 !important;
padding-top: 9px;
}

.modal-background {
	position:fixed; 
	background-color: rgba(0,0,0,0.5);
	left:0; 
	top:0;
	width:100%; 
	height:100%;
}

.modal-title {
	display:inline-block;
}

.modal-icon {
	height:25px;
	width:25px;
	margin-right:1px;
	position:relative;
	top:5px;
}

.modal-message {
	overflow:hidden;
	height:calc(100% - 95px);
}

.modal-buttonbar {
	margin-top:15px;
	position:absolute;
	right:20px;
	bottom:24px;
}

.modal-buttonbar button {
	margin-left:6px;
}

`],
	template: `
<div class="modal-background" (click)="dismiss('Dismiss')">
	<div class="modal" (click)="$event.stopPropagation()" [ngStyle]="{'width': width + 'px', 'height':  height + 'px'}">
		<img *ngIf="icon" class="modal-icon" [src]="icon" alt="" title=""/>
		<h2 class="modal-title" [innerHTML]="title"></h2>   
		<div class="modal-message" [innerHTML]="message"></div>
		<div class="modal-buttonbar">
			<button *ngIf="confirmBtn" (click)="confirm()">{{confirmBtn}}</button>
			<button *ngIf="cancelBtn" (click)="cancel()" >{{cancelBtn}}</button>
		</div>
	</div>
</div>`

})

export class BaseModal {

    title: string;
    message: string;
    icon: string;
    width: number;
    height: number;
    confirmBtn: string;
    cancelBtn: string;

    dismiss(value: string) {
        
    }
}

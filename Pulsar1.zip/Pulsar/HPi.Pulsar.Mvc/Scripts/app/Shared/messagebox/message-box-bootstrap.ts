/// <reference path="message-box-enums.ts" />
import { Component } from '@angular/core';

import { MessageBoxConfig, BaseModal, MessageBoxButton } from './index';

@Component({
	selector: 'message-box',
	template: `
<div class="modal" id="important-msg"  tabindex="-1" role="dialog" style="display:block;z-index:10114 !important;" (click)="dismiss('Dismiss')">
	<div class="modal-dialog" [ngClass]= "{'modal-sm':width<301, 'modal-lg':width>599}" (click)="$event.stopPropagation()">
		<div class="modal-content">
			<div class="modal-header angularHeader">
				<button style="opacity:1.1;margin-top:5px;" type="button" class="close"  data-dismiss="modal" (click)="cancel('Cancel')">
					<span class="popupClose">X</span><span class="sr-only">Close</span>
				</button>
				<img *ngIf="icon" class="modal-icon" style="width:24px;position:relative;top:-2px;" [src]="icon" alt="" title=""/>
				<h4 class="modal-title angularTitle " style="display:inline-block; padding-left:10px !important;" id="modal-title" [innerHTML]="title"></h4>
			</div>
			<div class="modal-body" [innerHTML]="message"></div>
			<div class="modal-footer">
				<button *ngIf="confirmBtn" type="button" class="btn btn-primary" (click)="confirm()">{{confirmBtn}}</button>
				<button *ngIf="cancelBtn" type="button" class="btn btn-primary" (click)="cancel()">{{cancelBtn}}</button>
			</div>
		</div>
	</div>
</div>
<div id="back-drop" class="modal-backdrop fade in"></div>`

})

export class MessageBoxBootstrap extends BaseModal {

    title: string;
    message: string;
    icon: string;
    width: number;
    height: number;
    confirmBtn: string;
    cancelBtn: string;
    close: (mbb: MessageBoxButton) => any;

    constructor(mbc: MessageBoxConfig) {
        super();
        this.title = mbc.title;
        this.message = mbc.message;
        this.icon = mbc.icon;
        this.width = mbc.width;
        this.height = mbc.height;
        this.confirmBtn = mbc.confirmBtn;
        this.cancelBtn = mbc.cancelBtn;
        this.close = mbc.close;
    }

    dismiss(value: string) {
        this.cancel(value);
    }
    removeElement(element) {
        element && element.parentNode && element.parentNode.removeChild(element);
    }

// Usage:

    confirm(value: string) {
        this.removeElement(document.getElementById('important-msg'));
        this.removeElement(document.getElementById('back-drop'));
        if (this.close != null) {
            if (this.confirmBtn == "Yes") {
                this.close(MessageBoxButton.Yes);
            }
            else if (this.confirmBtn == "Ok") {
                this.close(MessageBoxButton.Ok);
            }
        }
       
    }

    cancel(value: string) {
        this.removeElement(document.getElementById('important-msg'));
        this.removeElement(document.getElementById('back-drop'));
        if (this.close != null) {
            if (this.cancelBtn == "Cancel") {
                this.close(MessageBoxButton.Cancel);
            }
            else if (this.cancelBtn == "No") {
                this.close(MessageBoxButton.No);
            }
        }
    }

}

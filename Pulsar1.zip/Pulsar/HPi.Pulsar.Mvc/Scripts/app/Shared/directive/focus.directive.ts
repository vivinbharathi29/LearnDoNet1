﻿import { Directive, ElementRef, AfterViewInit } from '@angular/core';

@Directive({
    selector: '[focus]'
})
export class FocusDirective implements AfterViewInit {
    constructor(private el: ElementRef) {
    }
    ngAfterViewInit() {
        console.log("focus", this.el.nativeElement);
        this.el.nativeElement.focus();
    }
}
﻿import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { FilterModel } from './pagination/filter.model';
import { PaginationModel } from './pagination/pagination.model';
import { SortDirectionEnum } from './pagination/sort-direction-enum';
import { FilterOperatorEnum } from './pagination/filter-operator-enum';
import { FilterColumnTypeEnum } from './pagination/filter-column-type-enum';

import { LoadingComponent } from './loading/loading.component';
import { ModalPopupComponent } from "./modal_popup/modal-popup.component";
import { SafeHtmlPipe } from './pipes/safe-html.pipe';
import { FocusDirective } from './directive/focus.directive';
import { jqxGridComponent } from '../jqwidgets-ts/angular_jqxgrid';
import { jqxDateTimeInputComponent } from '../jqwidgets-ts/angular_jqxdatetimeinput';

@NgModule({
    imports: [CommonModule, FormsModule],
    exports: [jqxDateTimeInputComponent, jqxGridComponent, LoadingComponent, ModalPopupComponent, FormsModule, SafeHtmlPipe, FocusDirective],
    declarations: [jqxDateTimeInputComponent, jqxGridComponent, LoadingComponent, ModalPopupComponent, SafeHtmlPipe, FocusDirective]
})

export class SharedModule {
}

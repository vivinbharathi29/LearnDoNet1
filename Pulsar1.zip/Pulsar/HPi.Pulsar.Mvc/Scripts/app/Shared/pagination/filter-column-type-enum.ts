﻿// ***********************************************************************************************************
// Assembly         : Shared Module
// Author           : Muthukumar S
// Created          : 04-23-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="filter-column-type-enum.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
export enum FilterColumnTypeEnum {
    Number  = 1,
    String  = 2,
    Date    = 3,
    Boolean = 4
}
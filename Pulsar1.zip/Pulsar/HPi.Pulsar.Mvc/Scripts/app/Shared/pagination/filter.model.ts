﻿/// <reference path="filter-column-type-enum.ts" />
/// <reference path="filter-operator-enum.ts" />
// ***********************************************************************************************************
// Assembly         : Shared Module
// Author           : Muthukumar S (auth\sankaral)
// Created          : 04-23-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="filter.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { FilterColumnTypeEnum } from './filter-column-type-enum';
import { FilterOperatorEnum } from './filter-operator-enum';

export class FilterModel
{
    ColumnName  : string;
    Value       : string;
    ColumnType  : FilterColumnTypeEnum;
    Operator    : FilterOperatorEnum;
}
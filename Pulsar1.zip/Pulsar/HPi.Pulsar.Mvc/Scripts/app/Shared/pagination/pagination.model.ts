/// <reference path="sort-direction-enum.ts" />
/// <reference path="filter.model.ts" />
// ***********************************************************************************************************
// Assembly         : Shared Module
// Author           : Vinoth P
// Created          : 04-04-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="pagination-model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { SortDirectionEnum } from './sort-direction-enum';
import { FilterModel } from './filter.model';

export class PaginationModel
{
	PageNo      : number;
	PageSize    : number;
	SortBy      : string;
    SortDirection: SortDirectionEnum;
    Filters     : FilterModel[];
}
﻿// ***********************************************************************************************************
// Assembly         : Shared Module
// Author           : Muthukumar S
// Created          : 04-23-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="filter-operator-enum.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
export enum FilterOperatorEnum {
    EqualTo = 1,
    NotEqualTo = 2,
    GreaterThan = 3,
    LessThan = 4,
    GreaterThanOrEqualTo = 5,
    LesserThanOrEqualTo = 6,
    StartsWith = 7,
    EndsWith = 8,
    Contains = 9,
    NotContains = 10,
    Empty = 11,
    NotEmpty = 12,
    ContainsCaseSensitive = 13,
    NotContainsCaseSensitive = 14,
    StartsWithCaseSensitive = 15,
    EndsWithCaseSensitive = 16,
    EqualToCaseSensitive = 17,
    Null = 18,
    NotNull = 19
}
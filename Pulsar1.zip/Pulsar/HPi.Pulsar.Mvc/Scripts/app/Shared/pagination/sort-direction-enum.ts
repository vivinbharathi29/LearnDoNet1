﻿// ***********************************************************************************************************
// Assembly         : Shared Module
// Author           : Vinoth P
// Created          : 04-23-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="sort-direction-enum.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
export enum SortDirectionEnum {
    Ascending = 1,
    Descending = 2
}
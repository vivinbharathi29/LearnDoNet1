﻿export enum ListSortDirection {
    Ascending,
    Descending
}
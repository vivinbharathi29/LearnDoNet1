﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Muthukumar Sankaralingam
// Created          : 04/03/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 08/10/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="jqxgrid-configuration.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { PaginationModel } from '../pagination/pagination.model';
import { SortDirectionEnum } from '../pagination/sort-direction-enum';
import { FilterColumnTypeEnum } from '../pagination/filter-column-type-enum';
import { FilterOperatorEnum } from '../pagination/filter-operator-enum';
import { FilterModel } from '../pagination/filter.model';

export class jqxGridConfiguration {
    private _localdata: any;
    private _pagesize: number = 10;
    private _datafields: any;
    private _columns: any;
    private _columngroups: any;
    private _width: any = "100%";
    private _height: any = "80%";
    private _virtualmode: boolean = false;
    private _selectionmode: string = 'singlerow';
    private _columnsheight: any;
    private _filterdelay: number = 99999;
    public screenHeight = window.innerHeight/100;
    public gridHeightNoLinks: any = (this.screenHeight * 75 ) + "px";
    public gridHeightOneLineLinks: any = (this.screenHeight * 70) + "px";
    public gridHeightTwoLineLinks: any = (this.screenHeight * 60) + "px";
    public gridHeightWithContent: any = (this.screenHeight * 40) + "px";
    public columnTypes: { [key: string]: FilterColumnTypeEnum; } = {};
    public operators: { [key: string]: FilterOperatorEnum; } =
    {
        'EQUAL': FilterOperatorEnum.EqualTo,
        'NOT_EQUAL': FilterOperatorEnum.NotEqualTo,
        'GREATER_THAN': FilterOperatorEnum.GreaterThan,
        'LESS_THAN': FilterOperatorEnum.LessThan,
        'GREATER_THAN_OR_EQUAL': FilterOperatorEnum.GreaterThanOrEqualTo,
        'LESS_THAN_OR_EQUAL': FilterOperatorEnum.LesserThanOrEqualTo,
        'STARTS_WITH': FilterOperatorEnum.StartsWith,
        'ENDS_WITH': FilterOperatorEnum.EndsWith,
        'CONTAINS': FilterOperatorEnum.Contains,
        'DOES_NOT_CONTAIN': FilterOperatorEnum.NotContains,
        'EMPTY': FilterOperatorEnum.Empty,
        'NOT_EMPTY': FilterOperatorEnum.NotEmpty,
        'CONTAINS_CASE_SENSITIVE': FilterOperatorEnum.ContainsCaseSensitive,
        'DOES_NOT_CONTAIN_CASE_SENSITIVE': FilterOperatorEnum.NotContainsCaseSensitive,
        'STARTS_WITH_CASE_SENSITIVE': FilterOperatorEnum.StartsWithCaseSensitive,
        'ENDS_WITH_CASE_SENSITIVE': FilterOperatorEnum.EndsWithCaseSensitive,
        'EQUAL_CASE_SENSITIVE': FilterOperatorEnum.EqualToCaseSensitive,
        'NULL': FilterOperatorEnum.Null,
        'NOT_NULL': FilterOperatorEnum.NotNull
    };



    public get localdata(): any {
        return this._localdata;
    }
    public set localdata(localdata: any) {
        this._localdata = localdata;
        this.source.localdata = localdata;
    }



    public get pagesize(): number {
        return this._pagesize;
    }
    public set pagesize(pagesize: number) {
        this._pagesize = pagesize;
        this.settings.pagesize = pagesize;
    }



    public get datafields(): any {
        return this._datafields;
    }
    public set datafields(datafields: any) {
        this._datafields = datafields;
        this.source.datafields = datafields;
    }



    public get columns(): any {
        return this._columns;
    }
    public set columns(columns: any) {
        for (let index in columns) {
            columns[index].filterdelay = 99999;
        }
        this._columns = columns;
        this.settings.columns = columns;
    }


    public get columngroups(): any {
        return this._columngroups;
    }
    public set columngroups(columngroups: any) {
        this._columngroups = columngroups;
        this.settings.columngroups = columngroups;
    }

    public get columnsheight(): any {
        return this._columnsheight;
    }
    public set columnsheight(columnsheight: any) {
        this._columnsheight = columnsheight;
        this.settings.columnsheight = columnsheight;
    }


    public get width(): any {
        return this._width;
    }
    public set width(width: any) {
        this._width = width;
        this.settings.width = width;
    }

    public get height(): any {
        return this._height;
    }
    public set height(height: any) {
        this._height = height;
        this.settings.height = height;
    }

    public get autorowheight(): any {
        return this._autorowheight;
    }
    public set autorowheight(autorowheight: any) {
        this._autorowheight = autorowheight;
        this.settings.autorowheight = autorowheight;
    }
    private _autorowheight: any = false;

    public get virtualmode(): boolean {
        return this._virtualmode;
    }
    public set virtualmode(virtualmode: boolean) {
        this._virtualmode = virtualmode;
        this.settings.virtualmode = virtualmode;
    }

    public get selectionmode(): string {
        return this._selectionmode;
    }
    public set selectionmode(selectionmode: string) {
        this._selectionmode = selectionmode;
        this.settings.selectionmode = selectionmode;
    }
    public get filterdelay(): number {
        return this._filterdelay;
    } 
    source =
    {
        localdata: this._localdata,
        datatype: "json",
        datafields: this._datafields,
        root: 'Rows',
        beforeprocessing: function (data: any) {
            if (data.length == 0) {
                this.totalrecords = 0;
            }
            else {
                this.totalrecords = data[0].totalNoOfRows;
            }
        }

    };
    dataAdapter: any = new $.jqx.dataAdapter(this.source);

    public databind(): any {
        return this.dataAdapter.dataBind();
    }

    localization: jqwidgets.GridLocalizationObject = {
        thousandsseparator: ''
    }

    settings: jqwidgets.GridOptions = {
        width: this.width,
        height: this.height,
        source: this.dataAdapter,
        pageable: true,
        pagesize: 50,
        //pagesizeoptions: ['10', '50', '100', '250'],
        pagesizeoptions: ['10', '50', '100', '250', '500', '1000'],
        autoheight: false,
        sortable: true,
        altrows: false,
        filterable: true,
        showfilterrow: true,
        enabletooltips: true,
        virtualmode: this.virtualmode,
        editable: false,
        columngroups: this.columngroups,
        autorowheight: false, //this.autorowheight,
        sorttogglestates: "2",
        showsortmenuitems: false,
        showstatusbar: false,
        showtoolbar: false,
        //columnsheight: this.columnsheight,
        selectionmode: this.selectionmode,
        columnsresize: true,
        rendergridrows: function (obj) {
            return obj.data;
        },
        columns: this.columns,
        theme: "energyblue"


    };

    private toJSONFromLocal(date: Date): string {
        var local = new Date(date);
        local.setMinutes(date.getMinutes() - date.getTimezoneOffset());
        return local.toJSON().slice(0, 10);
    }
    public getPaginationModel(grid: jqxGridComponent): PaginationModel {
        var filters: FilterModel[] = [];
        var paginationInfo: PaginationModel = new PaginationModel();
        var filterinfo = grid.getfilterinformation();
        var pageInfo = grid.getpaginginformation();
        var sortingInfo = grid.getsortinformation();


        paginationInfo.PageNo = Number(pageInfo.pagenum);
        paginationInfo.PageSize = pageInfo.pagesize;
        paginationInfo.SortBy = sortingInfo.sortcolumn;



        if (typeof sortingInfo.sortdirection != 'undefined') {
            if (sortingInfo.sortdirection.ascending) {
                paginationInfo.SortDirection = SortDirectionEnum.Ascending;
            }
            else {
                if (sortingInfo.sortdirection.descending) {
                    paginationInfo.SortDirection = SortDirectionEnum.Descending;
                }
            }
        }

        for (let filterColumnEntry of filterinfo) {
            var filterItem = filterColumnEntry.filter.getfilters()[0];
            var filter: FilterModel = new FilterModel();
            filter.ColumnName = filterColumnEntry.filtercolumn;
            filter.ColumnType = this.columnTypes[filter.ColumnName];
            filter.Operator = this.operators[filterItem.condition];

            if (filter.ColumnType == FilterColumnTypeEnum.Date) {
                filter.Value = this.toJSONFromLocal(filterItem.value);
            }
            else {
                filter.Value = filterItem.value;
            }

            filters.push(filter);

        }
        paginationInfo.Filters = filters;

        return paginationInfo;
    }

}
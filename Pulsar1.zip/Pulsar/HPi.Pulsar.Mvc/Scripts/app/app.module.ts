﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, ActivatedRoute, Routes, Router } from '@angular/router';
import { CommonModule, Location, LocationStrategy, PathLocationStrategy, APP_BASE_HREF } from '@angular/common';
import { Http, Headers, RequestOptions, Response, HttpModule } from '@angular/http';

import { CoreModule } from './core/core.module';
import { ModalModule } from './shared/messagebox/modal.module';
import { SharedModule } from './shared/shared.module';
import { TodayModule } from './today/today.module';
import { ProductModule } from './product/product.module';
import { ComponentModule } from './component/component.module';
import { SCMXModule } from './scmx/scmx.module';
import { MessageBoxBootstrap } from './shared/messagebox/message-box-bootstrap';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { CustomRequestOptions } from './shared/utilities/custom-request-option.utility';
import { appComponents, appProviders } from './app-module.constant';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownTilesComponent } from './today/today_page/dropdown_tiles/dropdown-tiles.component';
import { DropdownTilesService } from './today/today_page/dropdown_tiles/dropdown-tiles.service';

@NgModule({
    imports: [BrowserModule, HttpModule, CommonModule, CoreModule, SharedModule, ModalModule.forRoot(), TodayModule, ProductModule, ComponentModule, SCMXModule, AppRoutingModule, ReactiveFormsModule],
    entryComponents: [MessageBoxBootstrap],
    declarations: [AppComponent, DropdownTilesComponent, MessageBoxBootstrap, ...appComponents],
    bootstrap: [AppComponent],
    providers: [...appProviders, DropdownTilesService,
    { provide: RequestOptions, useClass: CustomRequestOptions },
    [Location, { provide: LocationStrategy, useClass: PathLocationStrategy }],
        { provide: APP_BASE_HREF, useValue: '/pulsarplus' }
    ]
})

export class AppModule {
}

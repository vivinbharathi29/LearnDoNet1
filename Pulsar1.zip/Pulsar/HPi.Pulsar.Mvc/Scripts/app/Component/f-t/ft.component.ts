﻿import { Component, OnInit, Input } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { FTService } from './ft.service';
import { FTViewModel } from './ft-view-model.model';
import { CustomValidationService } from '../../shared/custom-validation.service';

@Component({
    selector: 'f-t',
    templateUrl: './ft.component.html',
    providers: [FTService],
    styles: [`
.modal-footer {
	 /* margin-bottom: 0; */
    /* padding-bottom: 0; */
    /* position: fixed; */
    /* padding-bottom: 0px; */
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 60px;
    /* line-height: 60px; */
    /* background-color: #f5f5f5; */
}
`]
})
export class FTComponent implements OnInit {

    partNumberForm: FormGroup;
    ftViewModel: FTViewModel;
    errorMessage: string = "";
    productName: string = "";
    categoryName: string = "";
    vendorName: string = "";
    ftPartNumberViewModel: any;
    changes: any;
    title: any;
    stepsToReproduce: any;
    otsArray: any;
    shortDescription: any;
    currentUserID: any;
    OTSNumber: any;
    constructor(private formBuilder: FormBuilder, private partNumberService: FTService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = "";
        this.buildForm();
        this.ftViewModel = new FTViewModel();
        this.ftViewModel.id = route.snapshot.params['versionId'];
        this.ftViewModel.rootID = route.snapshot.params['rootID'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.partNumberService.getFT(this.ftViewModel.id, this.ftViewModel.rootID).subscribe(
            data => {
                console.log(data.json());
                this.ftPartNumberViewModel = data.json();
                this.changes = this.ftPartNumberViewModel.strChanges;
                this.productName = this.ftPartNumberViewModel.strproductName;
                this.title = this.ftPartNumberViewModel.title;
                this.stepsToReproduce = this.ftPartNumberViewModel.stepsToReproduce;
                this.otsArray = this.ftPartNumberViewModel.ots;
                this.shortDescription = this.ftPartNumberViewModel.shortDescription;
                this.currentUserID = this.ftPartNumberViewModel.currentUserID;
                this.OTSNumber = this.ftPartNumberViewModel.oTSNumber;
                //this.partNumberForm.controls["version"].setValue(this.ftViewModel.version);
                //this.partNumberForm.controls["revision"].setValue(this.ftViewModel.revision);
                this.partNumberForm.controls["strproductName"].setValue(this.ftPartNumberViewModel.strproductName);
                this.partNumberForm.controls["strChanges"].setValue(this.ftPartNumberViewModel.strChanges);
                this.partNumberForm.controls["strVersion"].setValue(this.ftPartNumberViewModel.strVersion);
                this.partNumberForm.controls["oTSNumber"].setValue(this.ftPartNumberViewModel.oTSNumber);
                this.partNumberForm.controls["title"].setValue(this.ftPartNumberViewModel.title);
                this.partNumberForm.controls["stepsToReproduce"].setValue(this.ftPartNumberViewModel.stepsToReproduce);
                this.partNumberForm.controls["shortDescription"].setValue(this.ftPartNumberViewModel.shortDescription);
                this.partNumberForm.controls["currentUserID"].setValue(this.ftPartNumberViewModel.currentUserID);
                this.partNumberForm.updateValueAndValidity();
            }
        );
        $('f-t').parent().removeAttr('class');
        //$('f-t').parent().parent().find('.modal-header').attr("style", "padding: 0px;")
    }

    buildForm(): void {
        this.partNumberForm = this.formBuilder.group({
            //deliverableName: "",
            //version: "",
            //revision: "",
            //vendor: "",
            //versionID: "",
            //partNumber: "",
            strproductName: "",
            strChanges: "",
            strVersion: "",
            oTSNumber: "",
            stepsToReproduce: "",
            title: "",
            shortDescription: "",
            currentUserID: ""

        });
    }
    public isError: boolean = false;
    public ErrorMessage: string[]

    updateVersionPartNumber(ticketInfo: FormGroup) {
        this.ErrorMessage = [];
        this.isError = false;
        for (const control in this.partNumberForm.controls) {
            for (const propertyName in this.partNumberForm.controls[control].errors) {
                this.ErrorMessage.push(control + ' is ' + CustomValidationService.getValidatorErrorMessage(propertyName, this.partNumberForm.controls[control]));
                this.isError = true;
            }
        }
        if (this.isError) {
            window.scrollTo(10, 10);
        } else {
            this.ftViewModel = new FTViewModel();

        }
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }

    PrintScreen(): void {
        window.focus();


        //window.print();
              var divToPrint = document.getElementById('deliverableChanges');
            var newWin = window.open('', 'Print-Window');
            newWin.document.open();
            newWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</body></html>');
            newWin.document.close();
            setTimeout(function () { newWin.close(); }, 10);
    }
}

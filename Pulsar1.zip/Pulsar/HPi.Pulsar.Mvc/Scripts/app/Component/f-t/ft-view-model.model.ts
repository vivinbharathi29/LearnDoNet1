// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 09/14/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="ft-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class FTViewModel
{
	changes : string;
	version : string;
	revision : string;
	pass : string;
	name : string;
	id : number;
	platform : string;
	stepsToReproduce : string;
	oTSNumber : string;
    shortDescription: string;
    rootID: number;
    strproductName: string;
    strChanges: string;
    strVersion: string;
    title: string;
    currentUserID: number;
}
﻿/// <reference path="part-number/part-number.component.ts" />
import { Routes } from '@angular/router';

import { SupplierCodeComponent } from './supplier-code/supplier-code.component';
import { FTComponent } from './f-t/ft.component';
import { PartNumberComponent } from './part-number/part-number.component';
export const componentRoutes: Routes = [
    { path: 'supplierCodes/:categoryID/:vendorID', component: SupplierCodeComponent, outlet: 'externalpopupWindow' },
    { path: 'ft/:versionId/:rootID', component: FTComponent, outlet: 'externalpopupWindow' },
    { path: 'partnumber/:hwid', component: PartNumberComponent, outlet: 'externalpopupWindow' },
    { path: 'supplierCodespulsar2/:categoryID/:vendorID', component: SupplierCodeComponent },
    { path: 'ftpulsar2/:versionId/:rootID', component: FTComponent },
    { path: 'partnumberpulsar2/:hwid', component: PartNumberComponent }
];

//Declare all the components created for product module
export const componentComponents = [
    SupplierCodeComponent,
    FTComponent,
    PartNumberComponent
];

//Providers that needs to be shared across multiple components/modules can be declared here. Otherwise declare providers inside respective components
export const componentProviders = [
];
﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Routes } from '@angular/router';
import { Http, Headers, RequestOptions, Response, HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';
import { componentComponents, componentProviders } from './component-module.constant';
import { ComponentRoutingModule } from './component-routing.module';

@NgModule({
    imports: [CommonModule, HttpModule, FormsModule, ReactiveFormsModule, SharedModule, ComponentRoutingModule],
    declarations: [
        ...componentComponents
    ],
    providers: [
        ...componentProviders
    ]
})
export class ComponentModule { }

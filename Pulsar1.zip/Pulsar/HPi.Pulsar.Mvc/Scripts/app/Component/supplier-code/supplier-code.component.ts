﻿import { Component, OnInit, Input } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { SupplierCodeService } from './supplier-code.service';
import { SupplierCodeViewModel } from './supplier-code-view-model.model';
import { CustomValidationService } from '../../shared/custom-validation.service';

@Component({
    selector: 'edit-exception',
    templateUrl: './supplier-code.component.html',
    providers: [SupplierCodeService]
})
export class SupplierCodeComponent implements OnInit {

    supplierCodeForm: FormGroup;
    supplierCodeViewModel: SupplierCodeViewModel;
    errorMessage: string = "";
    productName: string = "";
    categoryName: string = "";
    vendorName: string = "";

    constructor(private formBuilder: FormBuilder, private supplierCodeService: SupplierCodeService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = "";
        this.buildForm();
        this.supplierCodeViewModel = new SupplierCodeViewModel();
        this.supplierCodeViewModel.categoryID = route.snapshot.params['categoryID'];
        this.supplierCodeViewModel.vendorID = route.snapshot.params['vendorID'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.supplierCodeService.getSupplierCodes(this.supplierCodeViewModel.categoryID, this.supplierCodeViewModel.vendorID).subscribe(
            data => {
                this.supplierCodeViewModel = data.json();
                this.categoryName = this.supplierCodeViewModel.category;
                this.vendorName = this.supplierCodeViewModel.vendor;
                this.supplierCodeForm.controls["category"].setValue(this.supplierCodeViewModel.category);
                this.supplierCodeForm.controls["vendor"].setValue(this.supplierCodeViewModel.vendor);
                this.supplierCodeForm.controls["categoryID"].setValue(this.supplierCodeViewModel.categoryID);
                this.supplierCodeForm.controls["vendorID"].setValue(this.supplierCodeViewModel.vendorID);
                //this.supplierCodeForm.controls["supplierCode"].setValue(String(this.supplierCodeViewModel.supplierCode));
                this.supplierCodeForm.updateValueAndValidity();
                document.getElementById("txtSupplierCode").focus();
            }
        );
        $('edit-exception').parent().removeAttr('style');
        $('edit-exception').parent().parent().find('.modal-header').attr("style", "padding: 0px;")

    }

    buildForm(): void {
        this.supplierCodeForm = this.formBuilder.group({
            category: "",
            vendor: "",
            supplierCode: ["", Validators.compose([Validators.required])],
            categoryID: "",
            vendorID: "",
        });
    }
    public isError: boolean = false;
    public ErrorMessage: string[]
    addSupplierCode(ticketInfo: FormGroup) {
        this.ErrorMessage = [];
        this.isError = false;
        for (const control in this.supplierCodeForm.controls) {
            for (const propertyName in this.supplierCodeForm.controls[control].errors) {
                if (control == "supplierCode") {
                    // this.ErrorMessage.push("Supplier Code" + ' is ' + CustomValidationService.getValidatorErrorMessage(propertyName, this.supplierCodeForm.controls[control]));
                    this.ErrorMessage.push("You must enter the supplier code or click the cancel button");
                    this.isError = true;

                } else {
                    this.ErrorMessage.push(control + ' is ' + CustomValidationService.getValidatorErrorMessage(propertyName, this.supplierCodeForm.controls[control]));
                    this.isError = true;
                }
            }
        }
        if (this.isError) {
            window.scrollTo(10, 10);
        } else {
            this.supplierCodeViewModel = new SupplierCodeViewModel();
            this.supplierCodeViewModel.categoryID = this.supplierCodeForm.value.categoryID;
            this.supplierCodeViewModel.vendorID = this.supplierCodeForm.value.vendorID;
            this.supplierCodeViewModel.supplierCode = this.supplierCodeForm.value.supplierCode;
            this.supplierCodeService.addSupplierCode(this.supplierCodeViewModel).subscribe(
                (data) => {
                    var success = data.json();
                    if (success) {
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                        popupCallBack(1);
                        closePopup('externalpagepopup');
                    }
                    else {
                        this.ErrorMessage.push("Unable to update Supplier Code.  An unexpected error occurred.");
                        this.isError = true;
                    }
                },
                Error => {
                    console.log('Failed', Error);
                }
            );;
        }
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
   
}

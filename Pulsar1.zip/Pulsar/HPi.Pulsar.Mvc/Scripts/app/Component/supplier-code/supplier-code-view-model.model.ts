// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 08/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="supplier-code-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class SupplierCodeViewModel
{
    categoryID: number;
    vendorID: number;
    supplierCode: string;
    category: string;
    vendor: string;
}
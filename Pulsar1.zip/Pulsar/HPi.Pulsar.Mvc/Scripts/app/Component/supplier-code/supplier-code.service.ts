﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\viperiya
// Created          : 08/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="supplier-code.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { SupplierCodeViewModel } from './supplier-code-view-model.model';

@Injectable()
export class SupplierCodeService {

    constructor(private http: Http, private location: Location) {
    }

    getSupplierCodes(categoryID: number, vendorID: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/Component/Component/GetSupplierCodes/' + categoryID + '/' + vendorID));
    }

    addSupplierCode(supplierCodeViewModel: SupplierCodeViewModel) {
        var headers = new Headers();

        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/Component/Component/AddSupplierCode/'), supplierCodeViewModel, {
            headers: headers
        });
    }
}
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 08/28/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="part-number-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class PartNumberViewModel
{
    deliverableName: string;
	partNumber : string;
    deliverable: string;
    version: string;
    revision: string;
    versionID: number;
    vendor: string;
    
}
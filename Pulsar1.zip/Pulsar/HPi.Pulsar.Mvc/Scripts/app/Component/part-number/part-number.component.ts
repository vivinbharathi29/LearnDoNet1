﻿import { Component, OnInit, Input } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { PartNumberService } from './part-number.service';
import { PartNumberViewModel } from './part-number-view-model.model';
import { CustomValidationService } from '../../shared/custom-validation.service';

@Component({
    selector: 'part-number',
    templateUrl: './part-number.component.html',
    providers: [PartNumberService]
})
export class PartNumberComponent implements OnInit {

    partNumberForm: FormGroup;
    partNumberViewModel: PartNumberViewModel;
    errorMessage: string = "";
    productName: string = "";
    categoryName: string = "";
    vendorName: string = "";
    deliverableName: any;
    versionID: any;
    version: any;
    revision: any;
    vendor: any;

    constructor(private formBuilder: FormBuilder, private partNumberService:  PartNumberService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = "";
        this.buildForm();
        this.partNumberViewModel = new PartNumberViewModel();
        this.partNumberViewModel.versionID = route.snapshot.params['hwid'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.partNumberService.getVersionPartNumber(this.partNumberViewModel.versionID).subscribe(
            data => {
                this.partNumberViewModel = data.json();
                this.versionID = this.partNumberViewModel.versionID;
                console.log(this.partNumberViewModel);
                this.deliverableName = this.partNumberViewModel.deliverableName;
                this.version = this.partNumberViewModel.version;
                this.revision = this.partNumberViewModel.revision;
                this.vendor = this.partNumberViewModel.vendor;
                this.partNumberForm.controls["deliverableName"].setValue(this.partNumberViewModel.deliverableName);
                this.partNumberForm.controls["version"].setValue(this.partNumberViewModel.version);
                this.partNumberForm.controls["revision"].setValue(this.partNumberViewModel.revision);
                this.partNumberForm.controls["vendor"].setValue(this.partNumberViewModel.vendor);
                this.partNumberForm.controls["versionID"].setValue(this.partNumberViewModel.versionID);
                this.partNumberForm.controls["partNumber"].setValue(this.partNumberViewModel.partNumber);
                this.partNumberForm.updateValueAndValidity();
            }
        );
    }

    buildForm(): void {
        this.partNumberForm = this.formBuilder.group({
            deliverableName: "",
            version: "",
            revision: "",
            vendor: "",
            versionID: "",
            partNumber : ""
        });
    }
    public isError: boolean = false;
    public ErrorMessage: string[]

    updateVersionPartNumber(ticketInfo: FormGroup) {
        this.ErrorMessage = [];
        this.isError = false;
        for (const control in this.partNumberForm.controls) {
            for (const propertyName in this.partNumberForm.controls[control].errors) {
                this.ErrorMessage.push(control + ' is ' + CustomValidationService.getValidatorErrorMessage(propertyName, this.partNumberForm.controls[control]));
                this.isError = true;
            }
        }
        if (this.isError) {
            window.scrollTo(10, 10);
        } else {
            this.partNumberViewModel = new PartNumberViewModel();
            this.partNumberViewModel.versionID = this.partNumberForm.value.versionID;
            this.partNumberViewModel.partNumber = this.partNumberForm.value.partNumber;
            this.partNumberService.updateVersionPartNumber(this.partNumberViewModel).subscribe(
                (data) => {
                    var success = data.json();
                    if (success) {
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                        popupCallBack(1);
                        closePopup('externalpagepopup');
                    }
                    else {
                        this.errorMessage = "Unable to update Supplier Code.  An unexpected error occurred.";
                    }
                },
                Error => {
                    console.log('Failed', Error);
                }
            );;
        }
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
}

﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\viperiya
// Created          : 08/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="supplier-code.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { PartNumberViewModel } from './part-number-view-model.model';

@Injectable()
export class PartNumberService {

    constructor(private http: Http, private location: Location) {
    }

    getVersionPartNumber(VersionID: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/component/Component/GetVersionPartNumber/' + VersionID));
    }

    updateVersionPartNumber(partNumberViewModel: PartNumberViewModel) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/component/Component/UpdateVersionPartNumber/'), JSON.stringify(partNumberViewModel), options);

        //var headers = new Headers();

        //headers.append('Content-Type', 'application/json');
        //return this.http.post('/component/Component/UpdateVersionPartNumber/', partNumberViewModel, {
        //    headers: headers
        //});
    }
}
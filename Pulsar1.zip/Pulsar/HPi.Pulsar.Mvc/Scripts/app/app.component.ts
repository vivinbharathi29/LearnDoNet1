﻿import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
    selector: 'app',
    templateUrl: './app.component.html',   
})
export class AppComponent {

    headerFooter: any;
    constructor(private router: Router, ) { }

    ngOnInit() {
        this.router.events
            .subscribe((event) => {
                if (event instanceof NavigationEnd) {
                    this.headerFooter = (event.url.indexOf("pulsar2") == -1)
                }
            });
    };

    //ngAfterViewInit(): void {
    //    debugger;
    //    this.addListeners();
    //}
    //addListeners() {
    //    debugger;
    //    document.getElementById('popup').addEventListener('mousedown', this.mouseDown, false);
    //    window.addEventListener('mouseup', this.mouseUp, false);

    //}

    //mouseUp() {
    //    debugger;
    //    window.removeEventListener('mousemove', this.divMove, true);
    //}

    //mouseDown(e) {
    //    debugger;
    //    window.addEventListener('mousemove', this.divMove(e:any), true);
    //}

    //divMove(e) {
    //    debugger;
    //    var div = document.getElementById('popup');
    //    div.style.position = 'absolute';
    //    div.style.top = e.clientY + 'px';
    //    return div.style.top = e.clientY + 'px';
    //}
}

﻿import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { UpdateDeliverableStatusService } from './update-deliverable-status.service'
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { CustomValidationService } from '../../shared/custom-validation.service'

@Component({
    selector: 'update-deliverable-status',
    templateUrl: './update-deliverable-status.component.html',
    providers: [UpdateDeliverableStatusService]
})
export class UpdateDeliverableStatusComponent {  
    errorMessage: string;
    public deliverableStatusVM: any;
    public scheduledataId: any;
    public id: any = 0;
    public statusID: any = 0;
    public typeID: any = 0;
    deliverableStatusform: FormGroup;

    constructor(http: Http, private service: UpdateDeliverableStatusService, private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router, private customValidationService: CustomValidationService) {
        this.id = activatedRoute.snapshot.params['id'];
        this.statusID = activatedRoute.snapshot.params['statusID'];
        this.typeID = activatedRoute.snapshot.params['typeID'];
        this.deliverableStatusform = fb.group({
            'Comments': [null, Validators.compose([Validators.required])],
            "StatusId": [null]
        })
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.scheduledataId = params['scheduledataid'];
        });
    }

    ngOnInit() {
        //this.getDeliverableStatus();
    }

    ngAfterViewInit(): void {
        this.getDeliverableStatus();
    }

    getDeliverableStatus() {
        this.service.geDeliverableStatus(this.id, this.statusID, this.typeID).subscribe(result => {
            
            this.deliverableStatusVM = result.json(); 
            this.deliverableStatusform = this.fb.group({
                'Comments': ['', Validators.compose([Validators.required])],
                "StatusId": [this.statusID]

            })
        });
    }

    isError: boolean = false;
    ErrorMessage: string[]
    SaveDeliverableStatus(deliverableStatusProperties: FormGroup) {
        this.deliverableStatusform.controls["StatusId"].setValue(this.statusID);
        if (this.statusID == 2)
        {
            this.ErrorMessage = [];
            this.isError = false;
            for (const control in this.deliverableStatusform.controls) {
                for (const propertyName in this.deliverableStatusform.controls[control].errors) {
                    this.ErrorMessage.push("You must explain in the comments field why you set the status to rejected");
                    this.isError = true;
                }
                if (control == "Comments") {
                    if (this.deliverableStatusform.controls[control].value == 0) {
                        //this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                        this.isError = true;
                    }
                }
            }
        }        

        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            this.service.updateDeliverableStatus(deliverableStatusProperties, this.id, this.typeID);
            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);            
            popupCallBack(1);
            closePopup('externalpagepopup');            
        } 
    }
    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

}  
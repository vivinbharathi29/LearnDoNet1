﻿import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ViewLeadProductExclusionService } from './view-lead-product-exclusions.service'
import { ActivatedRoute, NavigationExtras, Params,Router } from '@angular/router';

@Component({
    selector: 'view-lead-product-exclusions',
    templateUrl: './view-lead-product-exclusions.component.html',
})

export class ViewLeadProductExclusionComponent implements OnInit {
    id: number;
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    constructor(http: Http, private service: ViewLeadProductExclusionService,private ngZone: NgZone,private activatedRoute:ActivatedRoute,private router:Router) {
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            //ShowArtileListCallBackFn: (value) => this.showArticleListCallBack(value),
            component: this
        };   
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.settings.pageable = false;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.height = '310px';
        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product', type: 'string' },
            { name: 'deliverable', map: 'deliverable', type: 'string' },
            { name: 'versionName', map: 'versionName', type: 'string' },
            { name: 'id', map: 'id', type: 'string' },
            { name: 'comments', map: 'comments', type: 'string' },
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'Product', columngroup: 'viewleadproductexclusion',
                datafield: 'product', width: '15%', filtertype: 'input'
            },
            {
                text: 'Deliverable', columngroup: 'viewleadproductexclusion',
                datafield: 'deliverable', width: '20%', filtertype: 'input'
            },
            {
                text: 'Versions', columngroup: 'viewleadproductexclusion',
                datafield: 'versionName', width: '27%', filtertype: 'input'
            },
            {
                text: 'Comments', columngroup: 'viewleadproductexclusion',
                datafield: 'comments', width: '34%', filtertype: 'input'
            },
            {
                text: 'Id', columngroup: 'viewleadproductexclusion',
                datafield: 'id', filtertype: 'input',hidden:true
            },
        ];
    }
    getAllLeadProductExclusions() {
        this.id = this.activatedRoute.snapshot.params['PMID'];        
        this.myGrid.showdefaultloadelement(true);
        this.service.getAllLeadProductExclusions(this.id).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
        this.service.getAllLeadProductExclusions(this.id);
    }
    ErrorMessage: string[];
    isError: boolean = false;
    removeLeadProductExclusion() {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var index: number;
        var removeLeadProductIds: any='';
        for (index = 0; index < selectedIndices.length; index++) {
            removeLeadProductIds+= this.myGrid.getrowdata(selectedIndices[index]).id + ",";
        }
        if (removeLeadProductIds != '') {
            removeLeadProductIds = removeLeadProductIds.substring(0, removeLeadProductIds.length - 1);
            this.service.removeLeadProductExclusion(removeLeadProductIds).subscribe(result => {
                if (result.json() == true) {
                    this.cancelPopup();
                    LeadProductSynchronizationCallback(1);
                }
                console.log(result);
            });
        }
        else {
            this.ErrorMessage = [];
            this.ErrorMessage.push("Please select atleast one support version");
            window.scrollTo(10, 10);
            this.isError = true;
        }
    }
    
    ngOnInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getAllLeadProductExclusions();
    }


    cancelPopup()
    {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
}
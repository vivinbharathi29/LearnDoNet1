﻿import { Component, ViewChild, AfterViewInit, NgZone,Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';



@Injectable()
export class ViewLeadProductExclusionService{
    constructor(private http: Http, private location: Location) {

    }

    getAllLeadProductExclusions(pmId:any)
    {
        return this.http.get(this.location.prepareExternalUrl('product/Product/GetAllLeadProductExclusions?pmId=' + pmId));
    }
   
    removeLeadProductExclusion(removeLeadProductIds:any) {
       // var supportTicketViewModel = { supportTicketViewModel};
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(this.location.prepareExternalUrl('/product/Product/RemoveLeadProductExclusion?removeLeadProductIds=' + removeLeadProductIds));
               
    }

}
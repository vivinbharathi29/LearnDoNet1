﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-04-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="version-properties-update-eol-date.viewmodel.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class VersionPropertiesUpdateEOLDateViewModel {
    labelHeader: string;
    deliverableName: string;
    version: string;
    revision: string;
    pass: string;
    vendor: string;
    modelNumber: string;
    partNumber: string;
    eolDate: string;
    serviceEOADate: string;
    serviceActive: boolean;
    typeId: string;
    activeVersion: boolean;
    versionVendor: string;
    checked: string;
    calendarColumnLabel: string;
    checkBoxColumnLabel: string;
}
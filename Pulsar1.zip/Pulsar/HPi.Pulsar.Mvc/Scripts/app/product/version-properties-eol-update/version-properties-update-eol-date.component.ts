﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09/04/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="version-properties-update-eol-date.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../shared/messagebox/index';
declare let $: any;
declare var modalPopup: any;
import { VersionPropertiesUpdateEOLDateService } from './version-properties-update-eol-date.service';
import { VersionPropertiesUpdateEOLDateViewModel } from './version-properties-update-eol-date.viewmodel';

@Component({
    selector: 'version-properties-update-eol',
    templateUrl: './version-properties-update-eol-date.component.html',
    providers: [VersionPropertiesUpdateEOLDateService]
})
export class VersionPropertiesUpdateEOLDateComponent implements OnInit {
    @ViewChild('dateInput') inputDate: jqxDateTimeInputComponent;
    mbp: MessageBoxButton;
    versionPropertiesUpdateEOLDateViewModel: VersionPropertiesUpdateEOLDateViewModel;
    typeId: number;
    id: number;
    versionPropertiesUpdateEOLDate: any;
    errorMessage: string;
    labelHeader: string;
    constructor(private versionPropertiesUpdateEOLDateService: VersionPropertiesUpdateEOLDateService, private messageBox: MessageBox, private route: ActivatedRoute, private router: Router) {
        this.versionPropertiesUpdateEOLDateViewModel = new VersionPropertiesUpdateEOLDateViewModel();
        this.typeId = route.snapshot.params['TypeID'];
        this.id = route.snapshot.params['strIDs'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.getVersionPropertiesForWeb();
    }

    getVersionPropertiesForWeb() {
        this.versionPropertiesUpdateEOLDateService.getVersionPropertiesForWeb(this.id, this.typeId).subscribe(result => {
            this.versionPropertiesUpdateEOLDate = result.json();
            if (result.json().length > 0) {
                this.typeId = this.typeId;
                this.labelHeader = result.json()[0]['labelHeader']
            }
        });
    }

    cmdComplete_onclick(): void {
        var eolDate;
        var isChecked = false;
        var isValid = true;
        if (this.inputDate.getText() != "") {
            eolDate = this.inputDate.getText();
            eolDate = eolDate.split('/').join('-');
        }
        isChecked = (<HTMLInputElement>document.getElementById("chkEOL")).checked;
        if (isChecked == false) {
            this.errorMessage = "Remove It - Active Not Checked";
            isValid = false;
        }
        else if (this.isDate(eolDate)) {
            if (this.dateDifference(eolDate) > 0 && this.typeId != 2 || this.dateDifference(eolDate) > -90 && this.typeId == 2) {
                this.errorMessage = "Leave It - EOL Date is Expired";
                isValid = false;
            }
            else {
                this.errorMessage = "Remove It - EOL Date has not expired yet.";
                isValid = false;
            }
        }
        else {
            this.errorMessage = "Remove It - No EOL Date Specified and Not EOL.";
            isValid = false;
        }
        //if (isValid) {
        this.versionPropertiesUpdateEOLDateService.updateEOLDate(this.id, eolDate, this.typeId, isChecked).subscribe(result => {
            if (isChecked == false) {
                $('#divEolDate').empty();
                this.errorMessage = "Remove It - Active Not Checked";
                $('#deactivateWarning').css('display', 'block');
                $('#btnCancel').addClass("btn disabled");
                $('#btnComplete').addClass("btn disabled");
                this.messageBox.Show("EOL Date Update", "Successfully updated. Please reload the report to see the changes", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.confirmationMessage);
            }
            else
            {
                ComponentEndOfLifeDateExpiredReloadCallback(1);
                closePopup('externalpagepopup');
                this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            }
        });
        //}
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

    isDate(value) {
        return Object.prototype.toString.call(value) === '[object Date]';
    }

    dateDifference(eolDate) {
        var currentDate = new Date();
        var inputDate = new Date(eolDate);
        var timeDiff = Math.abs(currentDate.getTime() - inputDate.getTime());
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
        return diffDays;
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
            ComponentEndOfLifeDateExpiredReloadCallback(1);
        }
        else if (this.mbp == MessageBoxButton.Cancel) {
        }
    }
}
﻿import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit,ElementRef } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location,DatePipe } from '@angular/common';
import { FormsModule, FormBuilder, Validators, ReactiveFormsModule, Form, NgForm, NgControl, FormArray, NgModel, FormGroup, FormControl } from '@angular/forms';
import { PilotStatusService } from './pilot-status.service'

import { CustomValidationService } from '../../shared/custom-validation.service'
import { ActivatedRoute, NavigationExtras, Params, Router, Route } from '@angular/router';
import { jqxDateTimeInputComponent   } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
@Component({
    selector: 'pilot-status',
    templateUrl: './pilot-status.component.html',
})

export class PilotStatusComponent implements AfterViewInit {
    id: number;
    pilotStatusInfoForm: FormGroup;
    errorMessage: string;
    productDeliverableViewModel: any;
    productID: any;
    versionID: any;
    @ViewChild('pilotStatusInfoForm') elementFormRef: ElementRef;
    @ViewChild('dateInput') myDateInput: jqxDateTimeInputComponent;
    //showArticleListCallBack
    constructor(http: Http, private service: PilotStatusService, private fb: FormBuilder, private customValidationService: CustomValidationService, private ngZone: NgZone, private route: ActivatedRoute, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            //ShowArtileListCallBackFn: (value) => this.showArticleListCallBack(value),
            component: this
        };
        this.pilotStatusInfoForm = this.fb.group({
            "Id": [''],
            "PMEmailIDs": [''],
            "DevEmail": [''],
            "DevCenter": [''],
            "Vendor": [''],
            "DeliverableName": [''],
            "Version": [''],
            "Revision": [''],
            "StatusName": [''],
            "Name": [''],
            "PartnerID": [''],
            "ModelNumber": [''],
            "PartNumber": [''],
            "Comments": [''],
            "ExistingPilotStatusID": [''],
            "PilotStatusID": [''],
            "PilotDate": [''],
            "QualStatus": [''],
            //"VersionId": [''],
            "IsDateFieldReq": [''],
            "IsCommentFieldReq": ['']
        });
    }
    existingPilotStatusID: any;
    getPilotStatus() {
        this.productID = this.route.snapshot.params['productID'];
        this.versionID = this.route.snapshot.params['versionID'];
        this.service.getPilotStatus(this.productID, this.versionID).subscribe(result => {
            this.productDeliverableViewModel = result.json();
            this.pilotStatusInfoForm = this.fb.group({
                "Id": [this.productDeliverableViewModel.id],
                "PMEmailIDs": [this.productDeliverableViewModel.pmEmailIDs],
                "DevEmail": [this.productDeliverableViewModel.devEmail],
                "DevCenter": [this.productDeliverableViewModel.devCenter],
                "Vendor": [this.productDeliverableViewModel.vendor],
                "DeliverableName": [this.productDeliverableViewModel.deliverableName],
                "Version": [this.productDeliverableViewModel.version],
                "Revision": [this.productDeliverableViewModel.revision],
                "StatusName": [this.productDeliverableViewModel.statusName],
                "Name": [this.productDeliverableViewModel.name],
                "PartnerID": [this.productDeliverableViewModel.partnerID],
                "ModelNumber": [this.productDeliverableViewModel.modelNumber],
                "PartNumber": [this.productDeliverableViewModel.partNumber],
                "Pass": [this.productDeliverableViewModel.pass],
                "Comments": [this.productDeliverableViewModel.pilotNotes],
                "ExistingPilotStatusID": [this.productDeliverableViewModel.existingPilotStatusID],
                "PilotStatusID": [this.productDeliverableViewModel.pilotStatusID],
                "PilotDate": [this.productDeliverableViewModel.pilotDate],
                "QualStatus": [this.productDeliverableViewModel.qualStatus],
                //"VersionId": [this.productDeliverableViewModel.versionId],
                "IsDateFieldReq": [this.productDeliverableViewModel.isDateFieldReq],
                "IsCommentFieldReq": [this.productDeliverableViewModel.isCommentFieldReq]
            });
            
        });
    }

    isError: boolean = false;
    ErrorMessage: string[];
    SavePilotStatus(productDeliverableViewModel: FormGroup) {
        this.ErrorMessage = [];
        this.isError = false;
        for (const control in this.pilotStatusInfoForm.controls) {
            for (const propertyName in this.pilotStatusInfoForm.controls[control].errors) {
                this.ErrorMessage.push(control + ' is ' + CustomValidationService.getValidatorErrorMessage(propertyName, this.pilotStatusInfoForm.controls[control]));
                this.isError = true;
            }
            switch (control) {
                case "PilotStatusID":
                    if (this.pilotStatusInfoForm.controls[control].value == -1) {
                        this.ErrorMessage.push("Pilot Status is Required");
                        this.isError = true;
                    }
                    break;
                case "Comments":
                    if (this.pilotStatusInfoForm.controls["IsCommentFieldReq"].value == true && (this.pilotStatusInfoForm.controls[control].value == "" || this.pilotStatusInfoForm.controls[control].value == null)) {
                        this.ErrorMessage.push(control + ' is Required');
                        this.isError = true;
                    }
                    break;
                case "PilotDate":
                    if (this.pilotStatusInfoForm.controls["IsDateFieldReq"].value == true && this.myDateInput.getText().trim() == "") {
                        this.ErrorMessage.push('You must supply a valid date.');
                        this.isError = true;
                    }
                    break;
            }
        }
        var pilotDate = this.myDateInput.getText();
        productDeliverableViewModel["PilotDate"] = pilotDate;
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            this.service.updatePilotStatus(productDeliverableViewModel, this.versionID).subscribe(result => {
                ExpiredPilotStatusPopupCallBack(1);
                this.cancelPopup();
            });
        }

    }
    pilotStatusChange() {
        let pilotStatusName: any;
        var pilotStatus = <HTMLSelectElement>document.getElementById('PilotStatusID');
        var pilotStatusVM = this.productDeliverableViewModel.pilotStatusViewModel;
        var exist = false;
        if (pilotStatusVM != null) {
            {
                for (let pilot of pilotStatusVM) {
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id && pilot.commentsRequired == true) {
                        (<HTMLSpanElement>document.getElementById('commentReq')).style.display = '';
                        this.pilotStatusInfoForm.controls["IsCommentFieldReq"].setValue(true);
                    }
                    else {
                        (<HTMLSpanElement>document.getElementById('commentReq')).style.display = 'none';
                        this.pilotStatusInfoForm.controls["IsCommentFieldReq"].setValue(false);
                    }
                    if (exist == true)
                        break;
                }
                exist = false;
                for (let pilot of pilotStatusVM) {
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id && (pilot.dateField == 2 || pilot.dateField == 1)) {
                        (<HTMLLabelElement>document.getElementById('pilotDateField')).style.display = '';
                        $('#PilotDate').attr({ 'style': 'display:' });
                    }
                    else {
                        (<HTMLLabelElement>document.getElementById('pilotDateField')).style.display = 'none';
                        $('#PilotDate').attr({ 'style': 'display:none' });
                    }
                    if (exist == true)
                        break;
                }
                exist = false;
                for (let pilot of pilotStatusVM) {
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id && pilot.dateField == 1) {
                        (<HTMLSpanElement>document.getElementById('dateReq')).style.display = '';
                        this.pilotStatusInfoForm.controls["IsDateFieldReq"].setValue(true);
                    }
                    else {
                        (<HTMLSpanElement>document.getElementById('dateReq')).style.display = 'none';
                        this.pilotStatusInfoForm.controls["IsDateFieldReq"].setValue(false);
                    }
                    if (exist == true)
                        break;
                }
            }
        }
    }
    //dateTimeInputSettings: jqwidgets.DateTimeInputOptions = {
    //    formatString: "F", showTimeButton: false
    //} 
    ngAfterViewInit(): void {
        //this.myDateInput.createComponent(this.dateTimeInputSettings);
        this.getPilotStatus();
        
    } 
    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
}
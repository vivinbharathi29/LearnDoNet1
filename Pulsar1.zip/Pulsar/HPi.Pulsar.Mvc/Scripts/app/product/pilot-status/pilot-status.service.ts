﻿import { Component, ViewChild, AfterViewInit, NgZone,Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { ProductDeliverableViewModel } from './pilot-status.viewmodel'
import {Observable } from 'rxjs/Observable'
@Injectable()
export class PilotStatusService{
    constructor(private http: Http, private location: Location) {

    }

    getPilotStatus(productId: any = null, verionId: any = null)
    {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetPilotStatus/' + productId.toString() + '/' + verionId.toString()));
    }
   

    updatePilotStatus(productDeliverableViewModel:any, versionId: any) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/UpdatePilotStatus?versionId=' + versionId), productDeliverableViewModel, {
            headers: headers
        });       
        
    }

}
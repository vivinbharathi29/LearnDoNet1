﻿
import { Component, OnInit, Input } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { ReleaseService } from './release.service';
import { ReleaseViewModel } from './release-view-model.model';
import { CustomValidationService } from '../../shared/custom-validation.service';

@Component({
    selector: 'release',
    templateUrl: './release.component.html',
    providers: [ReleaseService]
})
export class ReleaseComponent implements OnInit {

    releaseForm: FormGroup;
    errorMessage: string = "";
    productName: string = "";
    vendorName: string = "";
    deliverableName: any;
    versionId: any;
    versionName: any;
    stringrelease: any;
    modelNumber: any;
    partNumber: any;
    headerRow: any;
    stringProductsLoaded: any;
    rootId: any;
    blnError: boolean;
    selectedArray = [];
    release: any;
    Function: any;
    releaseViewModelArray: any = [];
    constructor(private formBuilder: FormBuilder, private releaseService: ReleaseService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = "";
        this.versionId = route.snapshot.params['idList'];
        this.Function = route.snapshot.params['strFunction'];
    }

    ngOnInit(): void {
        this.releaseService.releaseCommodities(this.versionId, this.Function).subscribe(
            data => {
                this.release = data.json();
                console.log(this.release);
                if (data.json()[0]['message'] != "") {
                    (<HTMLInputElement>document.getElementById("btnSave")).disabled = true;
                    (<HTMLInputElement>document.getElementById("btnSave")).className += " btn disabled";
                }
                this.versionId = this.versionId;
                this.Function = this.Function;
            }
        );
    }

    buildForm(): void {
        this.releaseForm = this.formBuilder.group({
            rootId: "",
            fromMilestone: "",
            comments: "",
            imagePath: "",
            toMilestoneID: "",
            fromMilestoneID: "",
            executionEngineerID: "",
            executionEngineerName: "",
            notify : ""
        });
    }
    public isError: boolean = false;
    public ErrorMessage: string[]

    addrelease() {
        this.ErrorMessage = [];
        this.isError = false;

        var chk_arr = <HTMLCollection>document.getElementsByClassName("chkID");
        this.selectedArray = [];
        for (var i = 0; i < chk_arr.length; i++) {
            if ((<HTMLInputElement>chk_arr[i]).checked === true) {
                this.selectedArray.push((<HTMLInputElement>chk_arr[i]).value);
            }
        }
        let releaseViewModel = new ReleaseViewModel();
        var array = [];
        for (var i = 0; i < this.selectedArray.length; i++) {
            var Notify = (<HTMLInputElement>document.getElementById("txtEmail" + this.selectedArray[i])).value; //<HTMLCollection>document.getElementsByClassName("txtEmail") + this.selectedArray[i];
            var ImagePath = (<HTMLInputElement>document.getElementById("txtLocation"  + this.selectedArray[i])).value; //<HTMLCollection>document.getElementsByClassName("txtLocation") + this.selectedArray[i];
            var ExecutionEngineerId = parseInt((<HTMLInputElement>document.getElementById("txtExecutionEngineer" + this.selectedArray[i])).value);
            var ExecutionEngineerName = (<HTMLInputElement>document.getElementById("txtExecutionEngineerName" + this.selectedArray[i])).value;
            var FromMilestone = (<HTMLInputElement>document.getElementById("SelectedMilestoneName" + this.selectedArray[i])).value;
            var FromMilestoneId = parseInt((<HTMLInputElement>document.getElementById("SelectedMilestoneID" + this.selectedArray[i])).value);
            var ToMilestoneId = parseInt((<HTMLInputElement>document.getElementById("NextMilestoneID" + this.selectedArray[i])).value);
            var Id = parseInt(this.selectedArray[i]);
            releaseViewModel[i] = new ReleaseViewModel();
            releaseViewModel[i].Notify = Notify;
           
            releaseViewModel[i] = [
                {
                    "Notify": "test"
                }
            ]
            array.push(
                {
                    "Notify": Notify, "ImagePath": ImagePath, "Id": Id, "ExecutionEngineerId": ExecutionEngineerId, "ExecutionEngineerName": ExecutionEngineerName,
                    "FromMilestone": FromMilestone, "FromMilestoneId": FromMilestoneId, "ToMilestoneId": ToMilestoneId, "Function": this.Function
                }
            );
            
        }
        
       
          this.releaseService.saveReleaseCommodities(array).subscribe(
            (data) => {
                var success = data.json();
                if (success) {
                    this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                    popupCallBack(1);
                    closePopup('externalpagepopup');
                }
                else {
                    //this.errorMessage = "Unable to update supported products.";
                    this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                   
                    closePopup('externalpagepopup');
                }
            },
            Error => {
                console.log('Failed', Error);
                this.blnError = true;
                this.errorMessage = "Unable to update release products.";
            }
        );;
        //}
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
}

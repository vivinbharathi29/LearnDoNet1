// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 11/07/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="release-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class ReleaseViewModel
{
	id : number;
	vendor : string;
	version : string;
	partNumber : string;
	modelNumber : string;
	notify : string;
	imagePath : string;
	executionEngineerId : number;
	executionEngineerName : string;
	fromMilestone : string;
	fromMilestoneId : number;
	toMilestoneId : number;
	Function : string;
	checkedIdArray : string[];
    comments: string;
    versionId: number;
}
﻿/// <reference path="release-view-model.model.ts" />

// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 10/09/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="product.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { ReleaseViewModel } from './release-view-model.model';

@Injectable()
export class ReleaseService {
    constructor(private http: Http, private location: Location) {

    }

    releaseCommodities(versionID: any, functionNo: any): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/ReleaseCommodities/' + versionID + '/' + functionNo));
    }

    saveReleaseCommodities(releaseViewModel: any) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('product/Product/SaveReleaseCommodities'), JSON.stringify(releaseViewModel), options);
    }

}
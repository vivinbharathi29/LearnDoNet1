﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : Vignesh
// Created          : 03/24/2017
// Last Modified By : 
// Last Modified On : 01/05/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="jobs-did-not-run-as-scheduled.service" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class TodayActionService {
    constructor(private http: Http, private location: Location) {

    }
    getActionProductType(actionId: any) {

        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetTodayAction/' + actionId))
    }
}

﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh
// Created          : 11/27/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="todayaction.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router'
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Component({
    selector: 'today-action',
    template: '',
})

export class TodayActionComponent {

    public issueId: any;
    public typeId: any;
    public categoryId: any;
    public prodId: any;

    constructor(http: Http, private route: ActivatedRoute, private router: Router) {
        this.issueId = route.snapshot.params['id'];
        this.typeId = route.snapshot.params['pvId'];
        this.categoryId = route.snapshot.params['scheduleId'];
        this.prodId = route.snapshot.params['prodVId'];
        this.redirect();
    }
    
    redirect() {
        if (this.typeId != 0 && this.typeId==7)
        {
            var url = "";
            var title = "";
            var height = 250;
            var width = 475;
            url = "/Excalibur/Service/Action.asp";
            title = "";
            showPopup(url, title, height, width);
        }
    }
}
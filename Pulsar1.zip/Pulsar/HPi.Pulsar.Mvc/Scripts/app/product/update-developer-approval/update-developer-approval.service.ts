﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Vignesh.T
// Created          : 09-04-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="update-developer-approval.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class UpdateDeveloperApprovalService {

    constructor(private http: Http, private location: Location) {
    }

    getDeveloperApproval(productDeliverableIds: string, partnerId: number): Observable<Response> {
        
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetDeveloperApproval?productDeliverableIds=' + productDeliverableIds + '&partnerId=' + partnerId));
    }

    UpdateDeveloperApproval(deliverableStatusVM: any, idList: any, newValue: any) {        
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/UpdateDeveloperApproval?idList=' + idList + '&newValue=' + newValue), deliverableStatusVM, {
            headers: headers
        }).subscribe(
            (r: Response) => { }
            );
    }
}
﻿import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { UpdateDeveloperApprovalService } from './update-developer-approval.service'
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';

@Component({
    selector: 'update-developer-approval',
    templateUrl: './update-developer-approval.component.html',
    providers: [UpdateDeveloperApprovalService]
})
export class UpdateDeveloperApprovalComponent {
    @ViewChild('gridReference') myGrid: jqxGridComponent;    
    jqxGridConfig: jqxGridConfiguration;
    errorMessage: string;
    public developerapprovalVM: any;
    public scheduledataId: any;
    public newValue: any ;
    public idList: any = 0;
    public idListUpdate: any = 0;
    public statusId: any = 0;
    developerapprovalform: FormGroup;

    constructor(http: Http, private service: UpdateDeveloperApprovalService, private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router) {
        this.newValue = activatedRoute.snapshot.params['strValue'];        
        this.idList = activatedRoute.snapshot.params['idList'];
        this.idListUpdate = activatedRoute.snapshot.params['idListForUpdate'];
        this.statusId = activatedRoute.snapshot.params['strValue'];        
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = 400;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product' },
            { name: 'vendor', map: 'vendor' },
            { name: 'name', map: 'name' },
            { name: 'modelNumber', map: 'modelNumber' },
            { name: 'partNumber', map: 'partNumber' },
            { name: 'developerTestNotes', map: 'developerTestNotes' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'Product', datafield: 'product', filtertype: 'input'
            },
            {
                text: 'Vendor', columngroup: 'HelpAndSupport', datafield: 'vendor', filtertype: 'input'
            },
            {
                text: 'Deliverable', columngroup: 'HelpAndSupport', datafield: 'name', filtertype: 'input'
            },
            {
                text: 'Model', columngroup: 'HelpAndSupport', datafield: 'modelNumber', filtertype: 'input'
            },
            {
                text: 'Part', columngroup: 'HelpAndSupport', datafield: 'partNumber', filtertype: 'input'
            },
            {
                text: 'Comments', columngroup: 'HelpAndSupport', datafield: 'developerTestNotes', filtertype: 'input'
            }
        ];
        this.developerapprovalform = fb.group({
            'DeveloperTestNotes': [null, Validators.compose([Validators.required])],
            "StatusId": [null]
        })
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.scheduledataId = params['scheduledataid'];
        });
    }

    ngOnInit() {
        //this.myGrid.createComponent(this.jqxGridConfig.settings);
        //this.getDeveloperApproval();
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);   
        this.getDeveloperApproval();
    }

    getDeveloperApproval() {
        
        this.service.getDeveloperApproval(this.idListUpdate, this.newValue).subscribe(result => {
            
            this.developerapprovalVM = result.json();
            this.jqxGridConfig.localdata = this.developerapprovalVM.deliverableListVM;
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
            this.developerapprovalform = this.fb.group({
                'DeveloperTestNotes': ['', Validators.compose([Validators.required])],
                "StatusId": [this.statusId]
            })
        });
    }

    isError: boolean = false;
    ErrorMessage: string[]
    SaveDeveloperApproval(deliverableStatusProperties: FormGroup) {
        
        if (this.newValue == 2) {
            this.ErrorMessage = [];
            this.isError = false;
            for (const control in this.developerapprovalform.controls) {
                for (const propertyName in this.developerapprovalform.controls[control].errors) {
                    this.ErrorMessage.push("You must enter comments when rejecting a release.");
                    this.isError = true;
                }
                if (control == "Comments") {
                    if (this.developerapprovalform.controls[control].value == 0) {
                        //this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                        this.isError = true;
                    }
                }
            }
        }
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {            
            this.service.UpdateDeveloperApproval(deliverableStatusProperties, this.idListUpdate, this.newValue);
            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            closePopup('externalpagepopup');
            popupCallBack(1);
        }
    }
    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

}  
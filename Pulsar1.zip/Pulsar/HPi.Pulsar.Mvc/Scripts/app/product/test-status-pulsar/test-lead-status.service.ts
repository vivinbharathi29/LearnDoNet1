﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 10-27-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="test-lead-status.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { TestLeadStatusPulsarViewModel } from './test-lead-status.viewmodel';

@Injectable()
export class TestLeadStatusPulsarService {

    constructor(private http: Http, private location: Location) {
    }

    getTestLeadStatusPulsar(productId: any, releaseId: any, versionId: any, fieldId: any, todayPageSection: any, rowId: any): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetPulsarTestLeadStatus/' + productId + '/' + releaseId + '/' + versionId + '/' + fieldId + '/' + todayPageSection + '/' + rowId));
    }

    updateTestLeadStatusPulsar(productId: any, versionId: any, fieldId: any, cboStatus: any, notes: any, received: any, productDeliverableReleaseId: any): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/UpdatePulsarTestLeadStatus/' + productId + '/' + versionId + '/' + fieldId + '/' + cboStatus + '/' + productDeliverableReleaseId + '/' + received + '/' + notes));
    }
}
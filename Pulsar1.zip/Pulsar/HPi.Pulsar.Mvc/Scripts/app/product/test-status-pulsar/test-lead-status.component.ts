﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 10/27/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="test-lead-status.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';

import { TestLeadStatusPulsarService } from './test-lead-status.service';
import { TestLeadStatusPulsarViewModel } from './test-lead-status.viewmodel';

@Component({
    selector: 'test-lead-status-pulsar',
    templateUrl: './test-lead-status.component.html',
    providers: [TestLeadStatusPulsarService]
})
export class TestLeadStatusPulsarComponent implements OnInit {
    fieldId: any;
    versionId: any;
    productId: any;
    releaseId: any;
    rowId: any;
    todayPageSection: string;
    errorMessage: string;
    cboStatus: any;
    header: any;
    releaseLink: any;
    productDeliverableReleaseId: any;
    testLeadStatusPulsar: any;

    constructor(private testLeadStatusPulsarService: TestLeadStatusPulsarService, private route: ActivatedRoute, private router: Router) {
        this.fieldId = route.snapshot.params['FieldID'];
        this.versionId = route.snapshot.params['VersionID'];
        this.productId = route.snapshot.params['ProductID'];
        this.releaseId = route.snapshot.params['ReleaseID'];
        this.rowId = route.snapshot.params['RowID'];
        this.todayPageSection = route.snapshot.params['TodayPageSection'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.getTestLeadStatusPulsar();
    }

    getTestLeadStatusPulsar() {
        this.testLeadStatusPulsarService.getTestLeadStatusPulsar(this.productId, this.releaseId, this.versionId, this.fieldId, this.todayPageSection, this.rowId).subscribe(result => {
            this.testLeadStatusPulsar = result.json();
            if (this.testLeadStatusPulsar != null) {
                this.productDeliverableReleaseId = result.json()['productDeliverableReleaseId'];
                this.header = result.json()['header'];
                this.releaseLink = result.json()['releaseLink'];
                this.cboStatus = this.testLeadStatusPulsar.status;
            }
        });
    }

    saveTestLeadStatusPulsar(buttonname: any): void {
        var notes = (<HTMLInputElement>document.getElementById("txtNotes")).value;
        var received = (<HTMLInputElement>document.getElementById("txtReceived")).value;
        if (this.cboStatus == 2 || this.cboStatus == 3) {
            if (notes == "") {
                (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "block";
                this.errorMessage = "Test notes are required for the selected status.";
            }
            else {
                (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "none";
                this.errorMessage = null;
                this.testLeadStatusPulsarService.updateTestLeadStatusPulsar(this.productId, this.versionId, this.fieldId, this.cboStatus, notes, received, this.releaseId).subscribe(result => {
                    if (buttonname == "Save & Close") {
                        closePopup('externalpagepopup');
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                    }
                    else if (buttonname == "Save")
                    {
                        this.getTestLeadStatusPulsar();
                    }
                    MultiTestStatusCallback(1);
                });
            }
        }
        else {
            this.testLeadStatusPulsarService.updateTestLeadStatusPulsar(this.productId, this.versionId, this.fieldId, this.cboStatus, notes, received, this.releaseId).subscribe(result => {
                
                if (buttonname == "Save & Close") {
                    closePopup('externalpagepopup');
                    this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                }
                else if (buttonname == "Save") {
                    this.getTestLeadStatusPulsar();
                }
                MultiTestStatusCallback(1);
            });
        }
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

    CheckTextSize(value: any, maxLength: any) {
        if (value.length > maxLength) {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "block";
            this.errorMessage = "The maximum size of this field in 200 characters. You input has been truncated.";
        }
        else {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "none";
            this.errorMessage = null;
        }
    }

    cboDateChange_onclick(value: any) {
        this.cboStatus = value;
        if (value == 2 || value == 3) {
            (<HTMLInputElement>document.getElementById("RequireNotes")).style.display = "";
        }
        else {
            (<HTMLInputElement>document.getElementById("RequireNotes")).style.display = "none";
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "none";
        }
    }

    SwitchRelease(link: any): void {
        
    }
}
﻿import { Component, ViewChild, AfterViewInit, NgZone, Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';

@Injectable()
export class ImageTabChangeSCMService {
    constructor(private http: Http, private location: Location) {

    }

    getImageTabChangeSCM(productId: number, imageDefinitionId:number) {        
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetImageTabChangeSCM/' + productId + "/" + imageDefinitionId));
    }

    postImageTabChangeSCM(parameters: URLSearchParams) {
        var imageActionItemId = parameters.get("ImageActionItemID");
        var actionType = parameters.get("ActionType");
        var updatedBy = parameters.get("CurrentUserName");
        var productVersionId = parameters.get("ProductVersionID");
        var productBrandId = parameters.get("ProductBrandID");
        return this.http.get(this.location.prepareExternalUrl('/product/Product/UpdateImageAddObsoleteLocalizedAV/' + imageActionItemId + "/" + productVersionId + "/" + productBrandId + "/" + actionType + "/" + updatedBy));
    }
}
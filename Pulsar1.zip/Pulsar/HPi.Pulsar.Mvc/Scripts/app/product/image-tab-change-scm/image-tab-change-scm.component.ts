﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh.T
// Created          : 05/08/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="image-tab-change-scm.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../shared/messagebox/index';
////import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router'
import { ImageTabChangeSCMService } from './image-tab-change-scm.service';
////import { ImageTabChangetoLocalizationViewModel } from './image-tab-change-to-localization.viewmodel';

@Component({
    selector: 'image-tab-change-scm',
    templateUrl: './image-tab-change-scm.component.html'
})

export class ImageTabChangeSCMComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    //@ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    ////public imageTabChangetoLocalization: ImageTabChangetoLocalizationViewModel[];
    public title: string;
    public imageActionItemID: any = 0;
    public actionType: any = 0;
    public userId: any = 0;
    public productVersionId: any = 0;
    public productBrandID: any = 0;

    constructor(http: Http, private service: ImageTabChangeSCMService, private activatedRoute: ActivatedRoute, private _ngZone: NgZone, private router: Router) {

        this.imageActionItemID = activatedRoute.snapshot.params['imageActionItemID'];
        this.actionType = activatedRoute.snapshot.params['actionType'];
        this.userId = activatedRoute.snapshot.params['userId'];
        this.productVersionId = activatedRoute.snapshot.params['productVersionID'];
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = 380;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'combinedProductBrandId', map: 'combinedProductBrandId' },
            { name: 'brand', map: 'brand' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'combinedProductBrandId', datafield: 'combinedProductBrandId', filtertype: 'input', hidden: true
            },
            {
                text: 'SCM', columngroup: 'HelpAndSupport',
                datafield: 'brand', width: '468px', filtertype: 'input'
            }
        ];
    }

    getImageTabChangeSCM() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getImageTabChangeSCM(this.productVersionId, 0).subscribe(result => {

            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getImageTabChangeSCM();
    }

    onClickOk(): void {
        var index: number;
        var selectedIndices = this.myGrid.selectedrowindexes();

        for (index = 0; index < selectedIndices.length; index++) {
            this.productBrandID += this.myGrid.getrowdata(selectedIndices[index]).combinedProductBrandId;
            //var parameter = "function=UpdateAv&UpdateID=" + deliverableNameChangeAvLinkedIds + "&NotActionable=" + NotActionable + "&UserID=" + currentUserId;
            let parameters = new URLSearchParams();
            parameters.set("Function", "UpdateAV");
            parameters.set("ImageActionItemID", this.imageActionItemID);
            parameters.set("ActionType", this.actionType);
            parameters.set("CurrentUserName", this.userId);
            parameters.set("ProductVersionID", this.productVersionId);
            parameters.set("ProductBrandID", this.productBrandID);
            this.service.postImageTabChangeSCM(parameters)
                .subscribe(result => {
                    console.log(result);                    
                });
        }

        let parameters = new URLSearchParams();
        parameters.set("Function", "UpdateAV");
        parameters.set("ImageActionItemID", this.imageActionItemID);
        parameters.set("ActionType", "3");
        parameters.set("CurrentUserName", this.userId);
        parameters.set("ProductVersionID", "0");
        parameters.set("ProductBrandID", "0");
        this.service.postImageTabChangeSCM(parameters)
            .subscribe(result => {                
                console.log(result);
                this.closeExternalPopup();
                window['angularComponentRef_Localize'].zone.run(
                    function () {
                        window['angularComponentRef_Localize'].popUpCallBackFn(1);
                    });
            });       
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
};

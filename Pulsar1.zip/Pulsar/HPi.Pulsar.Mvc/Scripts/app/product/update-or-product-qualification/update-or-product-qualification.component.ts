﻿import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { UpdateOrProductQualificationservice } from './update-or-product-qualification.service'
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';

@Component({
    selector: 'update-qualification',
    templateUrl: './update-or-product-qualification.component.html',
    providers: [UpdateOrProductQualificationservice]
})
export class UpdateOrProductQualificationComponent {
    //@ViewChild('dateTimeInputReference') myDateTimeInput: jqxDateTimeInputComponent;
    errorMessage: string;
    public multiTestStatusViewModel: any;
    public scheduledataId: any;  
    ChangeRequestPropertiesform: FormGroup;

    constructor(http: Http, private service: UpdateOrProductQualificationservice, private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router) {
        this.ChangeRequestPropertiesform = fb.group({
            'languageID': [null],  // will use the property in html page  
            'ScheduleDataId': [null],
            'SchedulePhaseId': [null],
            'ScheduleDefinitionDataId': [null],
            'ProjectedStartdt': [null],
            'ProjectedEnddt': [null],
            'ActualStartdt': [null],
            'ActualEnddt': [null],
            'ItemNotes': [null],
            'ChangeNote': [null],
            'ScheduleDataHistory': [null]
        })
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.scheduledataId = params['scheduledataid'];
        });

    }

    ngOnInit() {

        // call the method on initial load of page to bind dropdown   

        this.getlanguages();


    }
    ngAfterViewInit(): void {
        this.getlanguages();
    }

    //Get the list of languages  

    getlanguages() {       
        //this._ShortuesService.getlanguages().subscribe(res => this.languages = res, error => this.errorMessage = <any>error);
        this.service.getProductQualification().subscribe(result => {
            this.multiTestStatusViewModel = result.json();
            //this.myDateTimeInput.setDate(new Date(this.updateScheduleViewModel.scheduleMilestoneData.projectedStartdt));

            this.ChangeRequestPropertiesform = this.fb.group({
                'languageID': [null],  // will use the property in html page  
                'ScheduleDataId': [this.multiTestStatusViewModel.scheduleDataId],
                'SchedulePhaseId': [this.multiTestStatusViewModel.schedulePhaseId],
                'ScheduleDefinitionDataId': [this.multiTestStatusViewModel.scheduleDefinitionDataId],
                'ProjectedStartdt': [this.multiTestStatusViewModel.projectedStartdt],
                'ProjectedEnddt': [this.multiTestStatusViewModel.projectedEnddt],
                'ActualStartdt': [this.multiTestStatusViewModel.actualStartdt],
                'ActualEnddt': [this.multiTestStatusViewModel.actualEnddt],
                'ItemNotes': [this.multiTestStatusViewModel.itemNotes],
                'ChangeNote': [null],
                'ScheduleDataHistory': [this.multiTestStatusViewModel.scheduleDataHistory]
                //'date': [this.updateScheduleViewModel.projectedStartdt]

            })
        });
    }

    SaveChangeRequestProperties(updatescheduel: FormGroup) {
        //this.ErrorMessage = [];
        //this.isError = false;
        //for (const control in this.ticketInfoForm.controls) {
        //    for (const propertyName in this.ticketInfoForm.controls[control].errors) {
        //        this.ErrorMessage.push(control + ' is ' + CustomValidationService.getValidatorErrorMessage(propertyName, this.ticketInfoForm.controls[control]));
        //        this.isError = true;
        //    }
        //}
        //if (this.isError) {
        //    window.scrollTo(10, 10);
        //}
        //else {
        //    this.service.UpdateTicketInfo(ticketInfo);
        //}
        this.service.updateProductQualification(updatescheduel);
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

}  
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh
// Created          : 08/17/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="update-or-product-qualification.service" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';



@Injectable()
export class UpdateOrProductQualificationservice {

    constructor(private http: Http, private location: Location) {
    }

    getProductQualification(): Observable<Response> {
        let productID: any;// Need to pass parameter from component
        let versionID: any;// Need to pass parameter from component
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetProductQualificationForMultiTestStatus/' + productID + '/' + versionID));
    }

    updateProductQualification(multiTestStatusViewModel) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        //this.http.post('/today/TodayPage/UpdateScheduleMilestoneData?scheduleDataId=' + updateScheduleMilestoneViewModel, {
        this.http.post('/product/Product/UpdateScheduleMilestoneData', multiTestStatusViewModel, {
            headers: headers
        }).subscribe(
            (r: Response) => { }
            );
    }
}
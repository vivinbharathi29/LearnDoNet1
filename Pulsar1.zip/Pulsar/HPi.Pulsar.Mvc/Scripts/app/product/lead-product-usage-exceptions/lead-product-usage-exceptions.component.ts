﻿import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { LeadProductUsageExceptionsService } from './lead-product-usage-exceptions.service'
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';

@Component({
    selector: 'lead-product-usage-exception',
    templateUrl: './lead-product-usage-exceptions.component.html',
    providers: [LeadProductUsageExceptionsService]
})
export class LeadProductUsageExceptionsComponent {
    errorMessage: string;
    public leadproductexceptionsVM: any;
    public leadproductId: any;
    deliverableStatusform: FormGroup;

    constructor(http: Http, private service: LeadProductUsageExceptionsService, private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router) {
        this.deliverableStatusform = fb.group({

        })
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.leadproductId = params['scheduledataid'];
        });
    }

    ngOnInit() {
        this.getLeadProductUsageExceptions();
    }

    ngAfterViewInit(): void {
        this.getLeadProductUsageExceptions();
    }

    getLeadProductUsageExceptions() {
        this.service.getLeadProductUsageExceptions(this.leadproductId).subscribe(result => {
            this.leadproductexceptionsVM = result.json();
            this.deliverableStatusform = this.fb.group({

            })
        });
    }

    SaveLeadProductUsageExceptions(deliverableStatusProperties: FormGroup) {

        this.service.UpdateLeadProductUsageExceptions(deliverableStatusProperties);
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

}  
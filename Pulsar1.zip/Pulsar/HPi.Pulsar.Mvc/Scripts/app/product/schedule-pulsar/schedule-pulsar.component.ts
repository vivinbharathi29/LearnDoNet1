﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Sundar R
// Created          : 11/13/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="schedule-pulsar.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { Location } from '@angular/common';

@Component({
    selector: 'schedule-pulsar',
    template: '',
})

export class SchedulePulsarComponent {

    public id: any;
    public pvId: any;
    public scheduleId: any;
    public prodVId: any;

    constructor(http: Http, private route: ActivatedRoute, private router: Router, private location: Location) {
        this.id = route.snapshot.params['id'];
        this.pvId = route.snapshot.params['pvId'];
        this.scheduleId = route.snapshot.params['scheduleId'];
        this.prodVId = route.snapshot.params['prodVId'];
        this.redirect();
    }

    redirect() {
        if (this.id != 0) {
            var url = "";
            var title = "";
            var height = 600;
            var width = 800;
            url = this.location.prepareExternalUrl('/product/Product/GetMilestonePulsar/' + this.id);
            title = "Update Schedule Item";
            adjustableShowPopup(url, title, height, width, "800px");;

            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            closePopup('externalpagepopup');
        }
        else if (this.pvId != 0) {

            var url = "";
            var title = "";
            var height = 600;
            var width = 800;
            url = this.location.prepareExternalUrl('/product/product/ListScheduleMilestoneData/' + this.pvId + '/' + this.scheduleId);
            title = "Select Schedule Items";
            showPopup(url, title, height, width);

            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            closePopup('externalpagepopup');
        }
        else if (this.scheduleId != 0) {
            var url = "";
            var title = "";
            var height = 600;
            var width = 800;
            url = this.location.prepareExternalUrl('/product/product/LoadMilestonePulsar?productVersionId=' + this.prodVId + '&scheduleId=' + this.scheduleId);
            title = "Add Custom Item";
            showPopup(url, title, height, width);

            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            closePopup('externalpagepopup');
        }
        
    }
}
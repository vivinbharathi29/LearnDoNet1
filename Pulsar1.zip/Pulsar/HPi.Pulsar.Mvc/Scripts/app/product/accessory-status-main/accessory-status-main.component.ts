﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-06-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="accessory-status-main.component.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { FormsModule, FormBuilder, Validators, ReactiveFormsModule, Form, NgForm, NgControl, FormArray, NgModel, FormGroup, FormControl } from '@angular/forms';
import { AccessoryStatusService } from './accessory-status-main.service'

import { CustomValidationService } from '../../shared/custom-validation.service'
import { ActivatedRoute, NavigationExtras, Params, Router, Route } from '@angular/router';

@Component({
    selector: 'accessory-status',
    templateUrl: './accessory-status-main.component.html',
})

export class AccessoryStatusComponent implements OnInit {
    id: number;
    accessoryStatusInfoForm: FormGroup;
    errorMessage: string;
    accessoryStatusViewModel: any;
    productId: any;
    versionId: any;
    constructor(http: Http, private service: AccessoryStatusService, private formBuilder: FormBuilder, private customValidationService: CustomValidationService, private ngZone: NgZone, private route: ActivatedRoute, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            component: this
        };
        this.accessoryStatusInfoForm = this.formBuilder.group({
            "Id": [''],
            "QualStatus": [''],
            "Version": [''],
            "Revision": [''],
            "PilotStatus": [''],
            "ModelNumber": [''],
            "PartNumber": [''],
            "Pass": [''],
            "AccessoryDate": [''],
            "KitNumber": [''],
            "KitDescription": [''],
            "AccessoryStatusId": [''],
            "Comments": [''],
            "Date": [''],
            "Vendor": [''],
            "Product": [''],
            "DeliverableName": [''],
            "IsDateFieldReq": [''],
            "IsCommentFieldReq": [''],
            "IsShowDate": [''],
            "AccessoryNotes": [''],
            "StatusName": ['']
        });
    }
    existingPilotStatusID: any;
    getAccessoryStatus() {
        this.productId = this.route.snapshot.params['productId'];
        this.versionId = this.route.snapshot.params['versionId'];
        this.service.getAccessoryStatus(this.productId, this.versionId).subscribe(result => {
            this.accessoryStatusViewModel = result.json();
            console.log(this.accessoryStatusViewModel);
            this.accessoryStatusInfoForm = this.formBuilder.group({
                "Id": [this.accessoryStatusViewModel.id],
                "QualStatus": [this.accessoryStatusViewModel.testStatus],
                "Version": [this.accessoryStatusViewModel.version],
                "Revision": [this.accessoryStatusViewModel.revision],
                "PilotStatus": [this.accessoryStatusViewModel.pilotStatus],
                "ModelNumber": [this.accessoryStatusViewModel.modelNumber],
                "PartNumber": [this.accessoryStatusViewModel.partNumber],
                "Pass": [this.accessoryStatusViewModel.pass],
                "AccessoryDate": [this.accessoryStatusViewModel.accessoryDate],
                "KitNumber": [this.accessoryStatusViewModel.kitNumber, Validators.compose([Validators.required])],
                "KitDescription": [this.accessoryStatusViewModel.kitDescription],
                "AccessoryStatusId": [this.accessoryStatusViewModel.accessoryStatusId],
                "Comments": [this.accessoryStatusViewModel.accessoryNotes, Validators.compose([Validators.required])],
                "Date": [this.accessoryStatusViewModel.accessoryDate, Validators.compose([Validators.required])],
                "Vendor": [this.accessoryStatusViewModel.vendor],
                "Product": [this.accessoryStatusViewModel.product],
                "DeliverableName": [this.accessoryStatusViewModel.deliverableName],
                "IsDateFieldReq": [this.accessoryStatusViewModel.isDateRequired],
                "IsCommentFieldReq": [this.accessoryStatusViewModel.isCommentRequired],
                "IsShowDate": [this.accessoryStatusViewModel.isShowDate],
                "AccessoryNotes": [this.accessoryStatusViewModel.accessoryNotes],
                "StatusName": [this.accessoryStatusViewModel.accessoryStatusId]
            });
        });
    }

    isError: boolean = false;
    ErrorMessage: string[];
    saveAccessoryStatus(accessoryStatusViewModel: any) {
        this.ErrorMessage = [];
        this.isError = false;
        for (const control in this.accessoryStatusInfoForm.controls) {
            switch (control) {
                case "StatusID":
                    if (this.accessoryStatusInfoForm.controls[control].value == 0) {
                        this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                        this.isError = true;
                    }
                    break;
                case "AccessoryNotes":
                    if (this.accessoryStatusInfoForm.controls["IsCommentFieldReq"].value == true && (this.accessoryStatusInfoForm.controls[control].value == "" || this.accessoryStatusInfoForm.controls[control].value == null)) {
                        this.ErrorMessage.push("Comments" + ' is Required  when entering this Accessory status');
                        this.isError = true;
                    }
                    break;
                case "KitNumber":
                    if (this.accessoryStatusInfoForm.controls["AccessoryStatusId"].value > 1 && (this.accessoryStatusInfoForm.controls[control].value == "" || this.accessoryStatusInfoForm.controls[control].value == null)) {
                        this.ErrorMessage.push(control + ' is Required when selecting this status');
                        this.isError = true;
                    }
                    break;
                case "AccessoryDate":
                    if (this.accessoryStatusInfoForm.controls["IsDateFieldReq"].value == true && (this.accessoryStatusInfoForm.controls[control].value == "" || this.accessoryStatusInfoForm.controls[control].value == null)) {
                        this.ErrorMessage.push(control + ' is Required');
                        this.isError = true;
                    }
                    break;
            }
        }

        this.accessoryStatusViewModel.accessoryStatusId = this.accessoryStatusInfoForm.controls["AccessoryStatusId"].value;
        this.accessoryStatusViewModel.accessoryNotes = this.accessoryStatusInfoForm.controls["AccessoryNotes"].value;
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            var chkStatus = <HTMLInputElement>document.getElementById('chkDelete');
            var isDelete = chkStatus != null ? (chkStatus.checked == true ? true : false) : false;
            this.service.updateAccessoryStatus(this.accessoryStatusViewModel, this.productId, this.versionId, chkStatus).subscribe(res => {
                console.log(res.json());
                EditAccessoryStatus2ReloadCallback(true);
                this.cancelPopup();
            });
        }

    }
    accessoryStatusChange() {
        let accessoryStatusName: any;
        var accessoryStatus = <HTMLSelectElement>document.getElementById('StatusID');
        if (accessoryStatus.selectedIndex != 0) {
            (<HTMLInputElement>document.getElementById('StatusName')).value = accessoryStatus.options[accessoryStatus.selectedIndex].id;
            if (<HTMLInputElement>document.getElementById('chkDelete')) {
                (<HTMLInputElement>document.getElementById('chkDelete')).style.display = '';
            }
        }
        else {
            (<HTMLInputElement>document.getElementById('chkDelete')).style.display = 'none';
        }
        var accessoryStatusVM = this.accessoryStatusViewModel.accessoryStatusListModel;
        var exist = false;
        if (accessoryStatusVM != null) {
            {
                if (parseInt((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value) > 1) {
                    if (<HTMLInputElement>document.getElementById('kitNumberReq')) {
                        (<HTMLFontElement>document.getElementById('kitNumberReq')).style.display = '';
                    }
                }
                else {
                    (<HTMLFontElement>document.getElementById('kitNumberReq')).style.display = 'none';
                }
                for (let accessory of accessoryStatusVM) {
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id && accessory.commentsRequired == true) {
                        if (<HTMLInputElement>document.getElementById('kitNumberReq')) {
                            (<HTMLFontElement>document.getElementById('kitNumberReq')).style.display = '';
                        }
                        if (<HTMLInputElement>document.getElementById('commentReq')) {
                            (<HTMLFontElement>document.getElementById('commentReq')).style.display = '';
                        }
                        this.accessoryStatusInfoForm.controls["IsCommentFieldReq"].setValue(true);
                    }
                    else {
                        (<HTMLFontElement>document.getElementById('commentReq')).style.display = 'none';
                        this.accessoryStatusInfoForm.controls["IsCommentFieldReq"].setValue(false);
                    }
                    if (exist == true)
                        break;
                }
                exist = false;
                for (let accessory of accessoryStatusVM) {
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id && (accessory.dateField == 2 || accessory.dateField == 1)) {
                        if (<HTMLInputElement>document.getElementById('isDateFieldRequired')) {
                            (<HTMLDivElement>document.getElementById('isDateFieldRequired')).style.display = '';
                        }

                        $('#AccessoryDate').attr({ 'style': 'display:' });
                        this.accessoryStatusInfoForm.controls["IsDateFieldReq"].setValue(true);
                    }
                    else {
                        (<HTMLDivElement>document.getElementById('isDateFieldRequired')).style.display = 'none';
                        $('#AccessoryDate').attr({ 'style': 'display:none' });
                        this.accessoryStatusInfoForm.controls["IsDateFieldReq"].setValue(false);
                    }
                    if (exist == true)
                        break;
                }
                exist = false;
                for (let accessory of accessoryStatusVM) {
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id && accessory.dateField == 1) {
                        if (<HTMLInputElement>document.getElementById('dateReq')) {
                            (<HTMLFontElement>document.getElementById('dateReq')).style.display = '';
                        }
                    }
                    else {
                        (<HTMLFontElement>document.getElementById('dateReq')).style.display = 'none';
                    }


                    if (exist == true)
                        break;
                }
            }
        }
    }
    ngOnInit(): void {
        this.getAccessoryStatus();
    }

    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
}
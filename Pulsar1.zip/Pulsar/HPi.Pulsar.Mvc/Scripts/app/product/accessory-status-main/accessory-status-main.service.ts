﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-06-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="accessory-status-main.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class AccessoryStatusService {

    constructor(private http: Http, private location: Location) {
    }

    getAccessoryStatus(prodId: number, versionId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetAccessoryStatus?prodId=' + prodId + "&versionId=" + versionId))
    }

    updateAccessoryStatus(accessoryStatusViewModel: any, prodId: any, versionId: any,chkStatus: any) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/UpdateAccessoryStatus?prodId=' + prodId + '&versionId=' + versionId + '&chkStatus=' + chkStatus + '&todayPageSection=EditAccessoryStatus2'), accessoryStatusViewModel);
    }

}
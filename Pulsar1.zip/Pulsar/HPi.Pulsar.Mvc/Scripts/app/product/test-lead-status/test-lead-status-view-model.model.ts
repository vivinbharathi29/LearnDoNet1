// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 09/29/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="test-lead-status-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class TestLeadStatusViewModel
{
    id: number;
	name : string;
	deliverableId : string;
	version : string;
	rootId : number;
	revision : string;
	pass : string;
	typeId : number;
	modelNumber : string;
	partNumber : string;
	vendor : string;
	productName : string;
	status : number;
	unitsReceived : number;
	testNotes : string;
	productId : number;
	versionId : number;
	fieldId : number;
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay(Nishok S E A)
// Created          : 09/27/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="test-lead-status.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { TestLeadStatusViewModel } from './test-lead-status-view-model.model';

@Injectable()
export class TestLeadStatusService {

    constructor(private http: Http, private location: Location) {
    }

    getTestLeadStatus(versionId: number, productId: number, fieldId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetTestStatus/' + versionId + '/' + productId + '/' + fieldId));
    }

    updateTestLeadStatus(testLeadStatusViewModel: TestLeadStatusViewModel) {
        var headers = new Headers();

        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/UpdateTestLeadStatus/'), testLeadStatusViewModel, {
            headers: headers
        });
    }
}
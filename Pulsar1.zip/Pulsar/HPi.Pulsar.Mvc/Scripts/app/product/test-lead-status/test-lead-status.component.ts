﻿import { Component, OnInit, Input } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { isNumeric } from 'rxjs/util/isNumeric';

import { TestLeadStatusService } from './test-lead-status.service';
import { TestLeadStatusViewModel } from './test-lead-status-view-model.model';

@Component({
    selector: 'test-lead-status',
    templateUrl: './test-lead-status.component.html',
    providers: [TestLeadStatusService]
})
export class TestLeadStatusComponent implements OnInit {

    testLeadStatusForm: FormGroup;
    testLeadStatusViewModel: TestLeadStatusViewModel;
    productName: string = "";
    displayNotesRequired: boolean = false;
    isError: boolean = false;
    errorMessage: string[];

    constructor(private formBuilder: FormBuilder, private testLeadStatusService: TestLeadStatusService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = [];
        this.buildForm();
        this.testLeadStatusViewModel = new TestLeadStatusViewModel();
        this.testLeadStatusViewModel.productId = route.snapshot.params['productID'];
        this.testLeadStatusViewModel.versionId = route.snapshot.params['versionID'];
        this.testLeadStatusViewModel.fieldId = route.snapshot.params['fieldID'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.testLeadStatusService.getTestLeadStatus(this.testLeadStatusViewModel.versionId, this.testLeadStatusViewModel.productId, this.testLeadStatusViewModel.fieldId).subscribe(
            data => {
                this.testLeadStatusViewModel = data.json();
                if (this.testLeadStatusViewModel.status == 2 || this.testLeadStatusViewModel.status == 3) {
                    this.displayNotesRequired = true;
                }
                else {
                    this.displayNotesRequired = false;
                }

                this.testLeadStatusForm.controls["testNotes"].setValue(this.testLeadStatusViewModel.testNotes);
                if (this.testLeadStatusViewModel.unitsReceived != 0) {
                    this.testLeadStatusForm.controls["unitsReceived"].setValue(String(this.testLeadStatusViewModel.unitsReceived));
                }
                this.testLeadStatusForm.controls["status"].setValue(String(this.testLeadStatusViewModel.status));
                this.testLeadStatusForm.controls["productId"].setValue(this.testLeadStatusViewModel.productId);
                this.testLeadStatusForm.controls["versionId"].setValue(this.testLeadStatusViewModel.versionId);
                this.testLeadStatusForm.controls["fieldId"].setValue(this.testLeadStatusViewModel.fieldId);
                this.testLeadStatusForm.updateValueAndValidity();
            }
        );
    }

    buildForm(): void {
        this.testLeadStatusForm = this.formBuilder.group({
            testNotes: "",
            unitsReceived: "",
            status: '0',
            productId: 0,
            versionId: 0,
            fieldId: 0,
        });
    }

    updateTestLeadStatus(): void {
        this.errorMessage = [];
        this.isError = false;
        let testLeadStatusViewModel: TestLeadStatusViewModel = new TestLeadStatusViewModel();
        testLeadStatusViewModel.productId = this.testLeadStatusForm.value.productId;
        testLeadStatusViewModel.versionId = this.testLeadStatusForm.value.versionId;
        testLeadStatusViewModel.fieldId = this.testLeadStatusForm.value.fieldId;
        testLeadStatusViewModel.status = this.testLeadStatusForm.value.status;
        testLeadStatusViewModel.testNotes = this.testLeadStatusForm.value.testNotes;
        testLeadStatusViewModel.unitsReceived = Number(this.testLeadStatusForm.value.unitsReceived);
        console.log("save", testLeadStatusViewModel);
        console.log("Notes", testLeadStatusViewModel.testNotes);
        if ((testLeadStatusViewModel.status == 2 || testLeadStatusViewModel.status == 3) && testLeadStatusViewModel.testNotes == null) {
            this.isError = true;
            this.errorMessage.push("Test Notes are required for the selected status.");
        }
        else if (testLeadStatusViewModel.status == 4 && testLeadStatusViewModel.testNotes.trim().toLowerCase().indexOf("waive") > -1) {
            this.isError = true;
            this.errorMessage.push("You can not use the word 'waive' in Watch notes.");
        }
        else if (!(this.testLeadStatusForm.value.unitsReceived == "" || isNumeric(this.testLeadStatusForm.value.unitsReceived))) {
            this.isError = true;
            this.errorMessage.push("The Total Received field must be a number if it is supplied.");
        }
        console.log("Error: ", this.isError, this.errorMessage);

        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            this.testLeadStatusService.updateTestLeadStatus(testLeadStatusViewModel).subscribe(
                (data) => {
                    var success = data.json();
                    if (success) {
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                        popupCallBack(1);
                        closePopup('externalpagepopup');
                    }
                    else {
                        // this.errorMessage = "Unable to update Exceptions.  An unexpected error occurred.";
                    }
                },
                Error => {
                    console.log('Failed', Error);
                }
            );
        }
    }

    onTestStatusChange(event: any) {
        var status = (event.srcElement || event.target).value;
        if (status == 2 || status == 3) {
            this.displayNotesRequired = true;
        }
        else {
            this.displayNotesRequired = false;
        }
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
}

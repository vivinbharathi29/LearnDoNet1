﻿import { Component, OnInit, Input, ViewChild, AfterViewInit } from '@angular/core';
import { DatePipe,Location } from '@angular/common';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { QualStatusService } from './qual-status.service';
import { QualificationStatusViewModel } from './qualification-status-view-model.model';
import { SubassemblyListViewModel } from './subassembly-list-view-model.model';
import { TestStatusViewModel } from './test-status-view-model.model';
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';

@Component({
    selector: 'qual-status',
    templateUrl: './qual-status.component.html',
    providers: [QualStatusService]
})
export class QualStatusComponent implements OnInit, AfterViewInit {
    @ViewChild('dateInput') testDateInput: jqxDateTimeInputComponent;
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;

    qualStatusForm: FormGroup;
    qualificationStatusViewModel: QualificationStatusViewModel;
    errorMessage: string = "";
    productName: string = "";
    dcrSelectedId: number = 0;
    bridgeURL: string = "";
    selectedStatusval: number = 0;
    defaultSelectedStatus: number = 0;
    subAssembly: string = "";
    isPulserProduct: boolean;
    todayPageSection: string;
    isCommentStarDisplay: boolean = false;
    devCenter: number = 0;
    product: string;
    vendor: string;
    deliverable: string;
    version: string;
    partNo: string;
    developerTestStatusName: string;
    integrationTestStatusName: string;
    odmTestStatusName: string;
    wwanTestStatusName: string;
    ttsTestStatusName: string;
    supplyChainRestriction: boolean;
    configurationRestriction: boolean;
    riskRelease: boolean;
    category: string;

    constructor(private formBuilder: FormBuilder, private qualStatusService: QualStatusService, private route: ActivatedRoute, private router: Router,private location:Location ) {
        this.errorMessage = "";
        this.buildForm();
        this.qualificationStatusViewModel = new QualificationStatusViewModel();
        this.qualificationStatusViewModel.productId = route.snapshot.params['productID'];
        this.qualificationStatusViewModel.versionId = route.snapshot.params['versionID'];
        this.qualificationStatusViewModel.relaseId = route.snapshot.params['relaseId'];
        this.isPulserProduct = route.snapshot.params['ispulsarproduct'] == "false" ? false : true;
        this.todayPageSection = route.snapshot.params['todayPageSection'];
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.height = 200;
        this.jqxGridConfig.width = "100%";
        //this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'isRealRoot', map: 'isRealRoot' },
            { name: 'active', map: 'active' },
            { name: 'selected', map: 'selected' },
            { name: 'subAssembly', map: 'subAssembly' },
            { name: 'name', map: 'name' },
            { name: 'checkboxStatus', map: 'checkboxStatus' },
            { name: 'bGColor', map: 'bGColor' },
            { name: 'showMissingSubAssembly', map: 'showMissingSubAssembly' },
            { name: 'subassemblyCount', map: 'subassemblyCount' },

        ];
        this.jqxGridConfig.columns = [
            {
                text: 'Number',
                datafield: 'subAssembly', width: '20%', filtertype: 'input'
            },
            {
                text: 'Name',
                datafield: 'name', width: '75%', filtertype: 'input'
            }
        ];
    }

    //call services to get value from db.
    ngOnInit(): void {
        console.log(this.isPulserProduct);
        if (this.isPulserProduct == false) {
            this.qualStatusService.getQualStatus(this.qualificationStatusViewModel.productId, this.qualificationStatusViewModel.versionId).subscribe(
                data => {
                    this.qualificationStatusViewModel = data.json();

                    //console.log("dCRID", this.qualificationStatusViewModel);
                    this.qualStatusForm.controls["modelNumber"].setValue(this.qualificationStatusViewModel.modelNumber);
                    this.qualStatusForm.controls["chkDelete"].setValue(this.qualificationStatusViewModel.chkDelete);
                    this.qualStatusForm.controls["testConfidence"].setValue(String(this.qualificationStatusViewModel.testConfidence));
                    this.qualStatusForm.controls["productID"].setValue(this.qualificationStatusViewModel.productId);
                    this.qualStatusForm.controls["versionID"].setValue(this.qualificationStatusViewModel.versionId);
                    this.qualStatusForm.controls["qualificationDcrId"].setValue(String(this.qualificationStatusViewModel.qualificationDcrId));
                    this.qualStatusForm.controls["selectedDCRNumber"].setValue(this.qualificationStatusViewModel.selectedDCRNumber);
                    this.qualStatusForm.controls["supplyChainRestriction"].setValue(this.qualificationStatusViewModel.supplyChainRestriction);
                    this.qualStatusForm.controls["configurationRestriction"].setValue(this.qualificationStatusViewModel.configurationRestriction);
                    this.qualStatusForm.controls["comments"].setValue(this.qualificationStatusViewModel.comments);
                    this.qualStatusForm.controls["partnerID"].setValue(this.qualificationStatusViewModel.partnerId);
                    this.qualStatusForm.controls["selectedTestStatus"].setValue(String(this.qualificationStatusViewModel.selectedTestStatus));
                    this.qualStatusForm.controls["id"].setValue(this.qualificationStatusViewModel.id);
                    this.qualStatusForm.controls["riskRelease"].setValue(this.qualificationStatusViewModel.riskRelease);
                    //this.qualStatusForm.controls["date"].value(this.qualificationStatusViewModel.testDate);
                    this.selectedStatusval = this.qualificationStatusViewModel.selectedTestStatus;
                    this.defaultSelectedStatus = this.qualificationStatusViewModel.selectedTestStatus;
                    this.dcrSelectedId = this.qualificationStatusViewModel.qualificationDcrId;
                    this.devCenter = this.qualificationStatusViewModel.devCenter;
                    this.product = this.qualificationStatusViewModel.product;
                    this.vendor = this.qualificationStatusViewModel.vendor;
                    this.deliverable = this.qualificationStatusViewModel.deliverable;
                    this.version = this.qualificationStatusViewModel.version;
                    this.partNo = this.qualificationStatusViewModel.partNumber;
                    this.developerTestStatusName = this.qualificationStatusViewModel.developerTestStatusName;
                    this.integrationTestStatusName = this.qualificationStatusViewModel.integrationTestStatusName;
                    this.odmTestStatusName = this.qualificationStatusViewModel.oDMtestStatusName;
                    this.wwanTestStatusName = this.qualificationStatusViewModel.wWANtestStatusName;
                    this.ttsTestStatusName = this.qualificationStatusViewModel.tTStestStatusName;
                    this.supplyChainRestriction = this.qualificationStatusViewModel.supplyChainRestriction;
                    this.configurationRestriction = this.qualificationStatusViewModel.configurationRestriction;
                    this.category = this.qualificationStatusViewModel.category;
                    this.riskRelease = this.qualificationStatusViewModel.riskRelease;
                    //if (this.qualificationStatusViewModel.testDate != "") {
                    //   // this.testDateInput.setDate(new Date(this.qualificationStatusViewModel.testDate));
                    //    this.testDateInput.setDate(new Date(this.qualificationStatusViewModel.testDate));

                    //}
                   
                    this.qualStatusForm.updateValueAndValidity();
                    //this.bridgeURL = this.location.prepareExternalUrl("/product/product/GetProductHardwareMatrix?ReportFormat=2&lstProducts=" + this.qualificationStatusViewModel.productId + "&lstRoot=" + this.qualificationStatusViewModel.bridgedIDs + "&lstVendor=" + this.qualificationStatusViewModel.versionId);
                    this.bridgeURL = "/Excalibur/Deliverable/HardwareMatrix.asp?ReportFormat=2&lstProducts=" + this.qualificationStatusViewModel.productId + "&lstRoot=" + this.qualificationStatusViewModel.bridgedIDs + "&lstVendor=" + this.qualificationStatusViewModel.versionId;
                }
            );
        }
        else {
            this.qualStatusService.getQualStatusRelease(this.qualificationStatusViewModel.productId, this.qualificationStatusViewModel.versionId, this.qualificationStatusViewModel.relaseId, 0, this.todayPageSection).subscribe(
                data => {
                    this.qualificationStatusViewModel = data.json();
                    this.getSubassemblyListRelease(this.qualificationStatusViewModel.productDeliverableReleaseId);
                    //console.log("dCRID", this.qualificationStatusViewModel);
                    this.qualStatusForm.controls["modelNumber"].setValue(this.qualificationStatusViewModel.modelNumber);
                    this.qualStatusForm.controls["chkDelete"].setValue(this.qualificationStatusViewModel.chkDelete);
                    this.qualStatusForm.controls["testConfidence"].setValue(String(this.qualificationStatusViewModel.testConfidence));
                    this.qualStatusForm.controls["productID"].setValue(this.qualificationStatusViewModel.productId);
                    this.qualStatusForm.controls["versionID"].setValue(this.qualificationStatusViewModel.versionId);
                    this.qualStatusForm.controls["qualificationDcrId"].setValue(String(this.qualificationStatusViewModel.qualificationDcrId));
                    this.qualStatusForm.controls["selectedDCRNumber"].setValue(this.qualificationStatusViewModel.selectedDCRNumber);
                    this.qualStatusForm.controls["supplyChainRestriction"].setValue(this.qualificationStatusViewModel.supplyChainRestriction);
                    this.qualStatusForm.controls["configurationRestriction"].setValue(this.qualificationStatusViewModel.configurationRestriction);
                    this.qualStatusForm.controls["comments"].setValue(this.qualificationStatusViewModel.comments);
                    this.qualStatusForm.controls["partnerID"].setValue(this.qualificationStatusViewModel.partnerId);
                    this.qualStatusForm.controls["selectedTestStatus"].setValue(String(this.qualificationStatusViewModel.selectedTestStatus));
                    this.qualStatusForm.controls["id"].setValue(this.qualificationStatusViewModel.id);
                    this.qualStatusForm.controls["riskRelease"].setValue(this.qualificationStatusViewModel.riskRelease);
                    //this.qualStatusForm.controls["date"].value(this.qualificationStatusViewModel.testDate);
                    this.selectedStatusval = this.qualificationStatusViewModel.selectedTestStatus;
                    this.defaultSelectedStatus = this.qualificationStatusViewModel.selectedTestStatus;
                    this.dcrSelectedId = this.qualificationStatusViewModel.qualificationDcrId;
                    this.devCenter = this.qualificationStatusViewModel.devCenter;
                    this.product = this.qualificationStatusViewModel.product;
                    this.vendor = this.qualificationStatusViewModel.vendor;
                    this.deliverable = this.qualificationStatusViewModel.deliverable;
                    this.version = this.qualificationStatusViewModel.version;
                    this.partNo = this.qualificationStatusViewModel.partNumber;
                    this.developerTestStatusName = this.qualificationStatusViewModel.developerTestStatusName;
                    this.integrationTestStatusName = this.qualificationStatusViewModel.integrationTestStatusName;
                    this.odmTestStatusName = this.qualificationStatusViewModel.oDMtestStatusName;
                    this.wwanTestStatusName = this.qualificationStatusViewModel.wWANtestStatusName;
                    this.ttsTestStatusName = this.qualificationStatusViewModel.tTStestStatusName;
                    this.supplyChainRestriction = this.qualificationStatusViewModel.supplyChainRestriction;
                    this.configurationRestriction = this.qualificationStatusViewModel.configurationRestriction;
                    this.category = this.qualificationStatusViewModel.category;
                    //if (this.qualificationStatusViewModel.testDate != "") {
                    //    this.testDateInput.setDate(new Date(this.qualificationStatusViewModel.testDate));
                    //}
                    this.qualStatusForm.updateValueAndValidity();
                    //this.bridgeURL = this.location.prepareExternalUrl("/product/product/GetProductHardwareMatrix?ReportFormat=2&lstProducts=" + this.qualificationStatusViewModel.productId + "&lstRoot=" + this.qualificationStatusViewModel.bridgedIDs + "&lstVendor=" + this.qualificationStatusViewModel.versionId);
                    this.bridgeURL = "/Excalibur/Deliverable/HardwareMatrix.asp?ReportFormat=2&lstProducts=" + this.qualificationStatusViewModel.productId + "&lstRoot=" + this.qualificationStatusViewModel.bridgedIDs + "&lstVendor=" + this.qualificationStatusViewModel.versionId;

                }
            );
        }
    }

    getSubassemblyListRelease(productDeliverableReleaseId: number) {
        this.myGrid.showdefaultloadelement(true);
        this.qualStatusService.getSubassemblyListRelease(this.qualificationStatusViewModel.productId, this.qualificationStatusViewModel.versionId, productDeliverableReleaseId).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            console.log(result.json());
            this.myGrid.updatebounddata(null);
            this.selectSubassemblies();
            this.myGrid.hideloadelement();

        });
    }

    getSubassemblyList() {
        this.myGrid.showdefaultloadelement(true);
        this.qualStatusService.getSubassemblyList(this.qualificationStatusViewModel.productId, this.qualificationStatusViewModel.versionId).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            console.log(result.json());
            this.myGrid.updatebounddata(null);
            this.selectSubassemblies();
            this.myGrid.hideloadelement();

        });
    }

    selectSubassemblies() {        
        let subassemblyList: SubassemblyListViewModel[] = [];
        subassemblyList = this.jqxGridConfig.settings.source.records;
        let rowid: number = 0;
        for (let index: number = 0; index < subassemblyList.length; index++) {
            var rowdata = this.myGrid.getrowdata(rowid);
            if (rowdata.id == subassemblyList[index].id) {
                if (subassemblyList[index].selected == 1 || (subassemblyList[index].subassemblyCount == 0 && subassemblyList[index].isRealRoot)) {
                    this.myGrid.selectrow(rowid);
                }
            }
            if (subassemblyList[index].showMissingSubAssembly == true) {
                this.subAssembly = "Note: TBD subassemblies will not appear on the matrix until the number is entered.";
            }

            rowid++;
        }
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        if (this.isPulserProduct == false) {
            this.getSubassemblyList();
        }
    }

    buildForm(): void {
        this.qualStatusForm = this.formBuilder.group({
            productID: 0,
            versionID: 0,
            modelNumber: "",
            chkDelete: false,
            testConfidence: "0",
            qualificationDcrId: "0",
            selectedDCRNumber: "0",
            supplyChainRestriction: false,
            configurationRestriction: false,
            comments: "",
            partnerID: 0,
            selectedTestStatus: "0",
            id: 0,
            riskRelease: false,
            date:""
        });
    }

    onCellvaluechanged(event: any): boolean {
        //if (event.args.rowselect) {
            console.log("Row click", event.args.rowindex);
            var data = this.myGrid.getrowdata(event.args.rowindex);
            console.log(data);
            if (data != null) {
                
                switch (data.checkboxStatus) {
                    case "selected":
                        this.myGrid.setcellvalue(event.args.rowindex, "checkboxStatus", "removed");
                        break;
                    case "new":
                        this.myGrid.setcellvalue(event.args.rowindex, "checkboxStatus", "none");
                        break;
                    case "removed":
                        this.myGrid.setcellvalue(event.args.rowindex, "checkboxStatus", "selected");
                        break;
                    case "none":
                        this.myGrid.setcellvalue(event.args.rowindex, "checkboxStatus", "new");
                        break;
                    default:
                        this.myGrid.setcellvalue(event.args.rowindex, "checkboxStatus", "none");
                        break;
                }
         //   }
            //this.myMenu.open(100, 100);
            return false;
        }
        //}
    }

    updateQualStatus(): void {
        if (this.qualificationStatusViewModel.status != this.qualStatusForm.value.selectedTestStatus && this.qualStatusForm.value.selectedTestStatus == 5)
        {
            //var testStatus = this.qualificationStatusViewModel.testStatusList.filter(x => x.id == this.qualStatusForm.value.selectedTestStatus);
            if (this.qualificationStatusViewModel.testingComplete==0)
            {
                if (!window.confirm("This deliverable has not completed all required testing. Are you sure you want to set it to " + $("#ddlTestStatus option:selected").text().trim() + "?"))
                    return;
            }
            else if (this.qualificationStatusViewModel.testingComplete == 2)
            {
                if (!window.confirm("This deliverable TTS status is still Pending. Are you sure you want to set it to " + $("#ddlTestStatus option:selected").text().trim() + "?"))
                    return;
            }
            else if (this.qualificationStatusViewModel.testingComplete == 3)
            {
                if (!window.confirm("This deliverable has not completed all required testing and the TTS status is still Pending. Are you sure you want to set it to " + $("#ddlTestStatus option:selected").text().trim() + "?"))
                    return;
            }
        }
        if (this.qualStatusForm.value.date != "") {
            this.testDateInput.setDate(new Date(this.qualStatusForm.value.date));
        }
        var selectedIndices = this.myGrid.selectedrowindexes();
        if (selectedIndices.length==0)
        {
            this.errorMessage = "You must select atleast one subassembly";
            return;
        }
        if (this.qualStatusForm.value.selectedTestStatus == 3) {
            if (this.testDateInput.getDate() == null) {
                this.errorMessage = "You must supply a valid date";
                return;
            }
        }

        if (this.qualStatusForm.value.selectedTestStatus == 6 || this.qualStatusForm.value.selectedTestStatus == 10 || this.qualStatusForm.value.selectedTestStatus == 7) {
            if (this.qualStatusForm.value.comments == "" || this.qualStatusForm.value.comments == null) {
                this.errorMessage = "You must supply comments when entering this Qualification status.";
                return;
            }
        }

        if (this.qualStatusForm.value.qualificationDcrId > 2 && this.qualStatusForm.value.selectedDCRNumber == 0) {
            this.errorMessage = "You must select an approved DCR number.";
            return;
        }

        var datePipe = new DatePipe('en-US');
        let qualificationStatusViewModel: QualificationStatusViewModel = new QualificationStatusViewModel();
        qualificationStatusViewModel.productId = this.qualStatusForm.value.productID;
        qualificationStatusViewModel.versionId = this.qualStatusForm.value.versionID;
        qualificationStatusViewModel.modelNumber = this.qualStatusForm.value.modelNumber;
        qualificationStatusViewModel.chkDelete = this.qualStatusForm.value.chkDelete;
        qualificationStatusViewModel.testConfidence = this.qualStatusForm.value.testConfidence;
        qualificationStatusViewModel.qualificationDcrId = this.qualStatusForm.value.qualificationDcrId;
        qualificationStatusViewModel.selectedDCRNumber = this.qualStatusForm.value.selectedDCRNumber;
        qualificationStatusViewModel.supplyChainRestriction = this.qualStatusForm.value.supplyChainRestriction;
        qualificationStatusViewModel.oldSupplyChainRestriction = this.supplyChainRestriction;
        qualificationStatusViewModel.configurationRestriction = this.qualStatusForm.value.configurationRestriction;
        qualificationStatusViewModel.oldConfigurationRestriction = this.configurationRestriction;
        qualificationStatusViewModel.comments = this.qualStatusForm.value.comments;
        qualificationStatusViewModel.partnerId = this.qualStatusForm.value.partnerID;
        qualificationStatusViewModel.selectedTestStatus = this.qualStatusForm.value.selectedTestStatus;
        qualificationStatusViewModel.id = this.qualStatusForm.value.id;
        qualificationStatusViewModel.oldRiskRelease = this.riskRelease;
        qualificationStatusViewModel.riskRelease = this.qualStatusForm.value.riskRelease;
        qualificationStatusViewModel.defaultSelectedTestStatus = this.defaultSelectedStatus;
        qualificationStatusViewModel.devCenter = this.devCenter;
        qualificationStatusViewModel.product = this.product;
        qualificationStatusViewModel.vendor = this.vendor;
        qualificationStatusViewModel.deliverable = this.deliverable;
        qualificationStatusViewModel.version = this.version;
        qualificationStatusViewModel.partNumber = this.partNo;
        qualificationStatusViewModel.developerTestStatusName = this.developerTestStatusName;
        qualificationStatusViewModel.integrationTestStatusName = this.integrationTestStatusName;
        qualificationStatusViewModel.oDMtestStatusName = this.odmTestStatusName;
        qualificationStatusViewModel.wWANtestStatusName = this.wwanTestStatusName;
        qualificationStatusViewModel.tTStestStatusName = this.ttsTestStatusName;
        qualificationStatusViewModel.testStatus = $("#ddlTestStatus option:selected").text().trim();
        qualificationStatusViewModel.category = this.category;
        if (this.testDateInput != null) {
            qualificationStatusViewModel.testDate = datePipe.transform(this.testDateInput.getDate(), 'MM/dd/yyyy');
        }
        qualificationStatusViewModel.subassemblyList = this.jqxGridConfig.settings.source.records;        
        for (var i = 0; i < qualificationStatusViewModel.subassemblyList.length; i++) {
            for (var index = 0; index < selectedIndices.length; index++) {
                if (i == selectedIndices[index]) {
                    if ((qualificationStatusViewModel.subassemblyList[i].checkboxStatus == "none" || qualificationStatusViewModel.subassemblyList[i].checkboxStatus == "selected") && qualificationStatusViewModel.subassemblyList[i].subassemblyCount == 0 && qualificationStatusViewModel.subassemblyList[i].isRealRoot) {
                        qualificationStatusViewModel.subassemblyList[i].subassemblyCount = 1;
                    }
                    if (qualificationStatusViewModel.subassemblyList[i].checkboxStatus == "selected" || (qualificationStatusViewModel.subassemblyList[i].subassemblyCount == 0 && qualificationStatusViewModel.subassemblyList[i].isRealRoot)) {
                        qualificationStatusViewModel.subassemblyList[i].checkboxStatus = "newItem";
                    }
                    else {
                        qualificationStatusViewModel.subassemblyList[i].checkboxStatus = "new";
                    }
                }
                else {
                    if (qualificationStatusViewModel.subassemblyList[i].checkboxStatus != "new") {
                        if (qualificationStatusViewModel.subassemblyList[i].checkboxStatus == "selected" || (qualificationStatusViewModel.subassemblyList[i].subassemblyCount == 0 && qualificationStatusViewModel.subassemblyList[i].isRealRoot)) {
                            qualificationStatusViewModel.subassemblyList[i].checkboxStatus = "removedItem";
                        }
                        else if (qualificationStatusViewModel.subassemblyList[i].checkboxStatus == "newItem" && qualificationStatusViewModel.subassemblyList[i].subassemblyCount == 1 && qualificationStatusViewModel.subassemblyList[i].isRealRoot) {
                            qualificationStatusViewModel.subassemblyList[i].checkboxStatus = "new";
                        }                        
                    }

                }
            }
        }
        if (this.isPulserProduct == false) {
           
            this.qualStatusService.updateQualStatus(qualificationStatusViewModel).subscribe(
                (data) => {
                    var success = data.json();
                    if (success) {
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                        popupCallBack(1);
                        closePopup('externalpagepopup');
                    }
                    else {
                        this.errorMessage = "Unable to update Exceptions.  An unexpected error occurred.";
                    }
                },
                Error => {
                    console.log('Failed', Error);
                }
            );;
        }
        else {
            this.qualStatusService.updateQualStatusRelease(qualificationStatusViewModel).subscribe(
                (data) => {
                    var success = data.json();
                    if (success) {
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                        popupCallBack(1);
                        closePopup('externalpagepopup');
                    }
                    else {
                        this.errorMessage = "Unable to update Exceptions.  An unexpected error occurred.";
                    }
                },
                Error => {
                    console.log('Failed', Error);
                }
            );;
        }
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }

    ddlWhyChange() {
        this.dcrSelectedId = this.qualStatusForm.value.qualificationDcrId
    }

    ddlTestStatusChange(event: any) {
        this.selectedStatusval = this.qualStatusForm.value.selectedTestStatus;
        if (this.selectedStatusval == 6 || this.selectedStatusval == 10 || this.selectedStatusval == 7) {
            this.isCommentStarDisplay = true;
        }
        else {
            this.isCommentStarDisplay = false;
        }

        if (this.qualStatusForm.value.selectedTestStatus == 0) {
            this.qualStatusForm.controls["qualificationDcrId"].setValue("0");
            this.qualStatusForm.controls["selectedDCRNumber"].setValue("0");
            this.dcrSelectedId = 0;
        }
        else {
            this.qualStatusForm.controls["chkDelete"].setValue(false);
        }
    }
}

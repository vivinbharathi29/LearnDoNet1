// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 09/12/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="qualification-status-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { TestStatusViewModel } from './test-status-view-model.model';
import { SubassemblyListViewModel } from './subassembly-list-view-model.model';

export class QualificationStatusViewModel {
    isServicePM: boolean;
    isAdmin: boolean;
    id: number;
    supplyChainRestriction: boolean;
    oldSupplyChainRestriction: boolean;
    configurationRestriction: boolean;
    oldConfigurationRestriction: boolean;
    oldRiskRelease: boolean;
    riskRelease: boolean;
    product: string;
    devCenter: number;
    productId: number;
    versionId: number;
    relaseId: number;
    productDeliverableReleaseId: number;
    deliverable: string;
    status: number;
    partNumber: string;
    modelNumber: string;
    testDate: string;
    vendor: string;
    category: string;
    categoryId: number;
    comments: string;
    dCRID: number;
    qualificationDcrId: number;
    version: string;
    revision: string;
    pass: string;
    vendorId: number;
    deliverableRootId: number;
    developerNotificationStatus: number;
    partnerId: number;
    testConfidence: number;
    developerTestStatus: number;
    developerTestNotes: string;
    integrationTestStatus: number;
    integrationTestNotes: string;
    oDMTestStatus: number;
    oDMTestNotes: string;
    wWANTestStatus: number;
    wWANTestNotes: string;
    tTS: string;
    requiresWWANSignOff: boolean;
    requiresODMSignoff: boolean;
    requiresMITSignoff: boolean;
    requiresDeveloperSignoff: boolean;
    testingComplete: number;
    devStatus: string;
    developerTestStatusName: string;
    integrationTestStatusName: string;
    oDMtestStatusName: string;
    wWANtestStatusName: string;
    tTStestStatusName: string;
    commentsRequired: string;
    testStatusList: TestStatusViewModel[];
    approvedDCRList: TestStatusViewModel[];
    selectedDCRNumber: number;
    selectedTestStatus: number;
    defaultSelectedTestStatus: number;
    found: boolean;
    chkDelete: boolean;
    bridgeCount: number;
    bridgedIDs: string;
    subassemblyList: SubassemblyListViewModel[];
    releaseLink: string;
    testStatus: string;
}
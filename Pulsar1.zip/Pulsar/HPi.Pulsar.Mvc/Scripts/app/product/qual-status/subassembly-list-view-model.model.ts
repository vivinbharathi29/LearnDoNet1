// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 09/14/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="subassembly-list-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class SubassemblyListViewModel
{
	id : number;
	active : number;
	subAssembly : string;
	name : string;
	isRealRoot : boolean;
	selected : number;
	subassemblyCount : number;
	bGColor : string;
    showMissingSubAssembly: boolean;
    checkboxStatus: string;
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay(Nishok S E A)
// Created          : 08/17/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="qual-status.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { QualificationStatusViewModel } from './qualification-status-view-model.model';

@Injectable()
export class QualStatusService {

    constructor(private http: Http, private location: Location) {
    }

    getQualStatus(productId: number, versionId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetQualStatus/' + productId + '/' + versionId));
    }

    updateQualStatus(qualificationStatusViewModel: any) {

        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/UpdateQualStatus'), qualificationStatusViewModel);
    }

    getSubassemblyList(productId: number, versionId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetSubassembly/' + productId + '/' + versionId));
    }

    getQualStatusRelease(productId: number, versionId: number, releaseId: number, productDeliverableReleaseId: number, todayPageSection: string): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetQualStatusRelease/' + productId + '/' + versionId + '/' + releaseId + '/' + productDeliverableReleaseId + '/' + todayPageSection));
    }

    updateQualStatusRelease(qualificationStatusViewModel: any) {

        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/UpdateQualStatusRelease'), qualificationStatusViewModel);
    }

    getSubassemblyListRelease(productId: number, versionId: number, productDeliverableReleaseId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetSubassemblyListRelease/' + productId + '/' + versionId + '/' + productDeliverableReleaseId));
    }
}
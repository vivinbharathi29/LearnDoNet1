﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : 
// Created          : 10/27/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="target-advanced.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response, } from '@angular/http';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { TargetAdvancedService } from './target-advanced.service';
import { TargetAdvancedViewModel } from './target-advanced.viewmodel';
import { ActivatedRoute, Router, Params } from '@angular/router';

@Component({
    selector: 'target-advanced',
    templateUrl:'./target-advanced.component.html'
})

export class TargetAdvancedComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public targetAdvanced: TargetAdvancedViewModel[];
    public selectedRowIndex: string;
    productId: number = 0;
    rootId: number = 0;
    versionId: number = 0;

    constructor(http: Http, private service: TargetAdvancedService,private route:ActivatedRoute) {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.settings.rowsheight = 50;
        
        this.productId = route.snapshot.params['productId'];
        this.rootId = route.snapshot.params['rootId'];
        this.versionId = route.snapshot.params['versionId'];
        this.jqxGridConfig.datafields = [
            { name: 'partNumber', map: 'partNumber' },
            { name: 'productID', map: 'productID' },
            { name: 'versionID', map: 'versionID' },
            { name: 'ProdDelID', map: 'prodDelID' },
            { name: 'pMAlert', map: 'pMAlert' },
            { name: 'targeted', map: 'targeted' },
            { name: 'release', map: 'release' },
            { name: 'releaseID', map: 'releaseID' },
            { name: 'targetedReleases', map: 'targetedReleases' },
            { name: 'version', map: 'version' },
            { name: 'noOfReleases', map: 'noOfReleases' },
            { name: 'targetNotes', map: 'targetNotes' },
            { name: 'modelNumber', map: 'modelNumber' },
            { name: 'language', map: 'language' },
            { name: 'target', map: 'target' },
            { name: 'targetNotes', map: 'targetNotes' },
            { name: 'devStatus', map: 'devStatus' },
            { name: 'dist', map: 'dist' },
            { name: 'images', map: 'images' },
            { name: 'whqlStatus', map: 'whqlStatus' },
            { name: 'workflowStatus', map: 'workflowStatus' },
            { name: 'delName', map: 'delName', type: 'string'  }
        ];

        this.jqxGridConfig.columns = [

            {
                text: 'Part Number', columngroup: 'TargetAdvanced',
                datafield: 'partNumber'
            },
            {
                text: 'ID', columngroup: 'TargetAdvanced',
                datafield: 'versionID'
            },
            {
                text: 'Version', columngroup: 'TargetAdvanced',
                datafield: 'version'
            },
            {
                text: 'Language', columngroup: 'TargetAdvanced',
                datafield: 'language'
            },
            {
                text: 'Target', columngroup: 'TargetAdvanced',
                datafield: 'target', cellsrenderer: this.cellsrendererDropdown
            },
            {
                text: 'Target Notes', columngroup: 'TargetAdvanced',
                datafield: 'targetNotes', cellsrenderer: this.cellsrendererText
            },
            {
                text: 'Model', columngroup: 'TargetAdvanced',
                datafield: 'modelNumber'
            },
            {
                text: 'Dev Status', columngroup: 'TargetAdvanced',
                datafield: 'devStatus'
            },
            {
                text: 'Dist', columngroup: 'TargetAdvanced',
                datafield: 'dist'
            },
            {
                text: 'Images', columngroup: 'TargetAdvanced',
                datafield: 'images'
            },
            {
                text: 'WHQL', columngroup: 'TargetAdvanced',
                datafield: 'whqlStatus'
            },
            {
                text: 'Work Flow', columngroup: 'TargetAdvanced',
                datafield: 'workflowStatus'
            }
        ];

        this.jqxGridConfig.columnTypes = {
            'partNumber': FilterColumnTypeEnum.String,
            'versionID': FilterColumnTypeEnum.Number,
            'version': FilterColumnTypeEnum.String,
            'language': FilterColumnTypeEnum.String,
            'target': FilterColumnTypeEnum.String,
            'targetNotes': FilterColumnTypeEnum.String,
            'modelNumber': FilterColumnTypeEnum.Number,
            'devStatus': FilterColumnTypeEnum.String,
            'dist': FilterColumnTypeEnum.String,
            'images': FilterColumnTypeEnum.String,
            'whqlStatus': FilterColumnTypeEnum.String,
            'workflowStatus': FilterColumnTypeEnum.String,
        }
    }


    getTargetAdvanced() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getTargetAdvanced(this.productId, this.rootId, this.versionId).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    ngAfterViewInit(): void {
       
        this.myGrid.createComponent(this.jqxGridConfig.settings);     
        this.getTargetAdvanced();
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var productId = data.productId;
            var versionId = data.versionId;
            var rootId = data.rootId;
            //AdvancedTarget(productId, versionId, rootId);
        }
        return false;
    }
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getTargetAdvanced();
        //this.getProducts(paginationInfo);

    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getTargetAdvanced();

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getTargetAdvanced();
    }


    cellsrendererText = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        //element[0].innerHTML = "<a class='jqx-anchor-hover jqxgrid-cellrender-font' onclick='javascript:AdvancedTarget(" + rowdata.productId + "," + rowdata.versionId + "," + rowdata.rootId + ");' /> " + value + " </a>";
        element[0].innerHTML = "<input type=text class='jqxgrid-cellrender-font' value='" + value + "'>";
        return element[0].outerHTML;
    };

    cellsrendererDropdown = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        //element[0].innerHTML = "<a class='jqx-anchor-hover jqxgrid-cellrender-font' onclick='javascript:AdvancedTarget(" + rowdata.productId + "," + rowdata.versionId + "," + rowdata.rootId + ");' /> " + value + " </a>";
        var strDropDown = "<select type=text class='jqxgrid-cellrender-font'><OPTION selected>Available</OPTION>";
        if (rowdata.pMAlert)
        {
            strDropDown = strDropDown + "<OPTION selected>New</OPTION>"
        }
        if (rowdata.targeted) {
            strDropDown = strDropDown + "<OPTION selected>Targeted</OPTION>"
        }
        else {
            strDropDown = strDropDown + "<OPTION>Targeted</OPTION>"
        }

        strDropDown = strDropDown + "</select>";

        element[0].innerHTML = strDropDown;
        return element[0].outerHTML;
    };
}

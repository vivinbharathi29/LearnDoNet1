﻿export class TargetAdvancedViewModel {

ProductID: number; 
 
ProdDelID :number; 

RootID : number; 

VersionID :number; 

RowCount : number; 

ColSpan :number; 

Count :number; 
 
Version: string; 

JSON:string; 
 
RootLanguageage: string; 

Language: string;

Global: boolean;

DelName: string; 

Prodname :string; 

LoadFailed: boolean;

Changes: string; 

OTS :string; 

Status : string; 

Images : string; 

Type : string; 

IsFusion: boolean;

IsPulsar: boolean;

EnableCboStatus: string;

Active: boolean;

Dist: string;

WhqlStatus : string; 

WhqlColor :string; 

OemReadyStatus : string; 

OemReadyColor :string; 

DevStatus :string; 

DevBGColor : string; 

WorkflowStatus : string; 

WorkflowColor :string; 

VersionStatus :string; 

Release :string; 

ModelNumber :string; 

Target : string; 

TargetNotes :string; 

NoOfReleases: number;

PartNumber: string;
}
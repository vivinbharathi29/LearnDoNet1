﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : 
// Created          : 10/27/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="pulsar-simple-av.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Location } from '@angular/common';
//import { pagination } from '../../../../shared/pagination-model.model';
//import { ListSortDirection } from '../../../../shared/listsortdirection';
//import { PaginationModel } from '../../../../shared/pagination/pagination.model';


@Injectable()
export class TargetAdvancedService {
    constructor(private http: Http, private location: Location) {
    }

    getTargetAdvanced(productId, rootId, versionId) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.get(this.location.prepareExternalUrl('/product/product/GetTargetDeliverableRootDetails' + '/' + productId + '/' + rootId + '/' + versionId), options);
    }

    getImpersonateName() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
    }

    postTargetAdvanced(parameters: URLSearchParams) {
       // var url = "/product/product/GetTargetDeliverableRootDetails";
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        //return this.http.post(url, parameters);
    }
}

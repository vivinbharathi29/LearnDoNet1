// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 08/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="processor-pm-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class ProcessorPMViewModel
{
	id : number;
	name : string;
	email : string;
	phone : string;
	partnerid : number;
	role : string;
}
﻿/// <reference path="programs-property.service.ts" />
/// <reference path="product-properties-view-model.model.ts" />
import { Component, OnInit, Input, NgZone  } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { ProgramPropertyService } from './programs-property.service';
import { ProductPropertiesViewModel } from './product-properties-view-model.model';

@Component({
    selector: 'programs-property',
    templateUrl: './programs-property.component.html',
    providers: [ProgramPropertyService]
})
export class ProgramsPropertyComponent implements OnInit {

    programPropertyForm: FormGroup;
    productPropertiesViewModel: ProductPropertiesViewModel;
    errorMessage: string = "";
    productName: string = "";
    public chooseEmployeeTitle: string = "Choose Person"
    public chipsetProcesserUrl: string = "/pulsarplus/core/User/ChooseEmployee?dialogType=8";
    public graphicsControllerUrl: string = "/pulsarplus/core/User/ChooseEmployee?dialogType=9";
    public videoMemoryUrl: string = "/pulsarplus/core/User/ChooseEmployee?dialogType=10";
    public commHWPMUrl: string = "/pulsarplus/core/User/ChooseEmployee?dialogType=11";
    public enablechooseEmployee: boolean = false;
    public ChipsetProcesserUserId: number = 0;
    public ChipsetProcesserUserName: string = "";
    public GraphicsControllerUserId: number = 0;
    public GraphicsControllerUserName: string = "";
    public VideoMemoryUserId: number = 0;
    public VideoMemoryUserName: string = "";
    public CommHWPMUserId: number = 0;
    public CommHWPMUserName: string = "";
    public switchType: string = "";
    ShowCommodityPropertiesCallFromOutside(impersonateId, impersonateName, switchType) {

        if (typeof (impersonateId) != "undefined") {           
            if (switchType =="ChipsetProcesser")
            {
                this.ChipsetProcesserUserId = impersonateId;
                this.ChipsetProcesserUserName = impersonateName;
            }
            if (switchType == "GraphicsController") {
                this.GraphicsControllerUserId = impersonateId;
                this.GraphicsControllerUserName = impersonateName;
            }
            if (switchType == "VideoMemory") {
                this.VideoMemoryUserId = impersonateId;
                this.VideoMemoryUserName = impersonateName;
            }
            if (switchType == "CommHWPM") {
                this.CommHWPMUserId = impersonateId;
                this.CommHWPMUserName = impersonateName;
            }
            
            this.switchType = switchType;
        }

    }
    constructor(private formBuilder: FormBuilder, private programPropertyService: ProgramPropertyService, private route: ActivatedRoute, private router: Router, private _ngZone: NgZone) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            ShowCommodityPropertiesCallbackFn: (impersonateId, impersonateName, switchType) => this.ShowCommodityPropertiesCallFromOutside(impersonateId, impersonateName, switchType),
            component: this
        };
        this.errorMessage = "";
        this.buildForm();
        this.productPropertiesViewModel = new ProductPropertiesViewModel();
        this.productPropertiesViewModel.id = route.snapshot.params['id'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.programPropertyService.getProductProperties(this.productPropertiesViewModel.id).subscribe(
            data => {
                this.productPropertiesViewModel = data.json();
                
                this.programPropertyForm.controls["productID"].setValue(this.productPropertiesViewModel.id);
                this.programPropertyForm.controls["productName"].setValue(this.productPropertiesViewModel.dotsName);
                this.programPropertyForm.controls["currentUserEmail"].setValue(this.productPropertiesViewModel.userEmail);
                this.programPropertyForm.controls["processorPMID"].setValue(String(this.productPropertiesViewModel.processorPMID));
                this.programPropertyForm.controls["commHWPMID"].setValue(String(this.productPropertiesViewModel.commHWPMID));
                this.programPropertyForm.controls["graphicsControllerPMID"].setValue(String(this.productPropertiesViewModel.graphicsControllerPMID));
                this.programPropertyForm.controls["videoMemoryPMID"].setValue(String(this.productPropertiesViewModel.videoMemoryPMID));
                this.programPropertyForm.updateValueAndValidity();
            }
        );
    }

    buildForm(): void {
        this.programPropertyForm = this.formBuilder.group({            
            processorPMID: "0",
            commHWPMID: "0",
            graphicsControllerPMID: "0",
            videoMemoryPMID: "0",
            productID: 0,
            productName: "",
            currentUserEmail:"",

        });
    }

    updateProductProperties(): void {
        let productProperties: ProductPropertiesViewModel = new ProductPropertiesViewModel();
        
        productProperties.id = this.programPropertyForm.value.productID;
        productProperties.dotsName = this.programPropertyForm.value.productName;
        productProperties.userEmail = this.programPropertyForm.value.currentUserEmail;        
        productProperties.commHWPMID = this.CommHWPMUserId == 0 ? this.programPropertyForm.value.commHWPMID : this.CommHWPMUserId;
        productProperties.processorPMID = this.ChipsetProcesserUserId == 0 ? this.programPropertyForm.value.processorPMID : this.ChipsetProcesserUserId;
        productProperties.graphicsControllerPMID = this.GraphicsControllerUserId == 0 ? this.programPropertyForm.value.graphicsControllerPMID : this.GraphicsControllerUserId;
        productProperties.videoMemoryPMID = this.VideoMemoryUserId == 0 ? this.programPropertyForm.value.videoMemoryPMID : this.VideoMemoryUserId;
        
        this.programPropertyService.updateProductProperties(productProperties).subscribe(
            (data) => {
                var success = data.json();
                if (success) {
                    ProductWithMissingHWPMCallBack(1);
                    this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                    closePopup('externalpagepopup');
                }
                else {
                    this.errorMessage = "Unable to update this product.";
                }
            },
            Error => {
                console.log('Failed', Error);
            }
        );;
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }

    updateOwners(productId: number): void
    {
        window.open("/excalibur/mobilese/today/OTSHWComponents.asp?ID=" + productId, "_blank", "width=700,height=350,location=1,menubar=1,resizable=1,scrollbars=1,status=1, titlebar=1,toolbar=1");
    }

    viewPopup(url: string, title: string, page: string) {
       
        var windowHeight = "650px";
        var windowWidth = 800;       
        //showPopup(url, title, "250px", "60%");
        showPopupThirdLevel(url, title,"50%","372px");
     
    }
}

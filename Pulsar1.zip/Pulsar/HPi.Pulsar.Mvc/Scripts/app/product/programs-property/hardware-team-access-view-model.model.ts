// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 08/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="hardware-team-access-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class HardwareTeamAccessViewModel
{
	productCount : number;
	hwTeam : string;
	isProcessorPM : boolean;
	isVideoMemoryPM : boolean;
	isGraphicsControllerPM : boolean;
	isCommodityPM : boolean;
	isPM : boolean;
}
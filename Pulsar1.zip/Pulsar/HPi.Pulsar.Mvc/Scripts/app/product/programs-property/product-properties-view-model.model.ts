﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 08/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="product-properties-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { GraphicsControllerPMViewModel } from './graphics-controller-pm-view-model.model';
import { HardwareTeamAccessViewModel } from './hardware-team-access-view-model.model';
import { ProcessorPMViewModel } from './processor-pm-view-model.model';
import { VideoMemoryPMViewModel } from './video-memory-pm-view-model.model';

export class ProductPropertiesViewModel {
    id: number;
    dotsName: string;
    commHWPMID: number;
    processorPMID: number;
    videoMemoryPMID: number;
    graphicsControllerPMID: number;
    userEmail: string;
    processorPMViewModel: ProcessorPMViewModel[];
    videoMemoryPMViewModel: VideoMemoryPMViewModel[];
    graphicsControllerPMViewModel: GraphicsControllerPMViewModel[];
    commHWPMListViewModel: GraphicsControllerPMViewModel[];
    hardwareTeamAccessViewModel: HardwareTeamAccessViewModel;
}
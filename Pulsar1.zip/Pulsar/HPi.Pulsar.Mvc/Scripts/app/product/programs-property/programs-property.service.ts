/// <reference path="product-properties-view-model.model.ts" />
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : subburay
// Created          : 08/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="programs-property.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { ProductPropertiesViewModel } from './product-properties-view-model.model';

@Injectable()
export class ProgramPropertyService {
    constructor(private http: Http, private location: Location) {

    }

    getProductProperties(productID: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetProductProperties/' + productID));
    }

    updateProductProperties(productPropertiesViewModel: ProductPropertiesViewModel) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/UpdateProductVersionHWPM/'), productPropertiesViewModel, {
            headers: headers
        });
    }
}
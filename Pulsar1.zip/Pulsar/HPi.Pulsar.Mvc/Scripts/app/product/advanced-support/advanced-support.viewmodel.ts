﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : RajivGandhi.R(auth\rajamanr)
// Created          : 09-08-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="advanced-support.viewmodel.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class AdvanceSupportViewModel {
    SelectedVersionIds: any;
    LoadedVersionIds: any;
    ProductId: any;
    RootId: any;
    ReleaseId: any;
    ProductDeliverableReleaseId: any;
    ProdRootId: any;
    RowId: any;
    ProductDeliverableDetails: ProductDeliverableModel[];
}
export class ProductDeliverableModel {
    VersionId: number;
    ProductDeliverableReleaseId: number;

    constructor(versionId: number, productDeliverableReleaseId: number) {
        this.VersionId = versionId;
        this.ProductDeliverableReleaseId = productDeliverableReleaseId;
    }
}
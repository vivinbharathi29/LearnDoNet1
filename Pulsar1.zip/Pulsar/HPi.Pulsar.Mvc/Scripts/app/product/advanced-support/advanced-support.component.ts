﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Rajivgandhi.R(auth\rajamanr)
// Created          : 08/31/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="advanced-support.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild, AfterViewInit } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';

import { AdvancedSupportService } from './advanced-support.service';
import { AdvanceSupportViewModel, ProductDeliverableModel } from './advanced-support.viewmodel';

@Component({
    selector: 'advanced-support',
    templateUrl: './advanced-support.component.html',
    //styles: ['.supportComplete{background-color:LightSteelBlue} .jqx-widget-content-energyblue{max-height:400px !important;overflow:auto !important} '],
    providers: [AdvancedSupportService]
})
export class AdvancedSupportComponent implements AfterViewInit {
    @ViewChild('gridReference') advancedSupportGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    advanceSupportViewModel: AdvanceSupportViewModel;
    advancedSupportProduct: any;
    toggle = false;
    typeId: any;
    categoryId: any;
    rootId: any;
    format: any;
    public screenHeight = window.innerHeight / 100;
    constructor(private advancedSupportService: AdvancedSupportService, private route: ActivatedRoute, private router: Router) {
        //this.irsComponentUpdateProductViewModel = new IRSComponentUpdateProductViewModel();

        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.settings.autorowheight = true;
        //this.jqxGridConfig.settings.pageable = true;
        this.jqxGridConfig.settings.autoheight = true;
        //this.jqxGridConfig.settings.altrows = true;
        //this.jqxGridConfig.settings.height = 250;
        this.jqxGridConfig.height = (this.screenHeight * 36) + "px";

        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number' },
            { name: 'location', map: 'location', type: 'string' },
            { name: 'supported', map: 'supported', type: 'string' },
            { name: 'versionId', map: 'versionId', type: 'string' },
            { name: 'newVersion', map: 'version', type: 'string' },
            { name: 'vendor', map: 'vendor', type: 'string' },
            { name: 'modelNumber', map: 'modelNumber', type: 'string' },
            { name: 'version', map: 'version', type: 'string' },
            { name: 'partNumber', map: 'partNumber', type: 'string' },
            { name: 'eolDate', map: 'eolDate', type: 'string' },
            { name: 'products', map: 'products', type: 'string', filterable: false },
            { name: 'productUsed', map: 'productUsed', type: 'string' },
            { name: 'productDeliverableReleaseId', map: 'productDeliverableReleaseId', type: 'number' },
            { name: 'releaseId', map: 'releaseId', type: 'number' },
        ];

        this.getAdvancedSupport();
    }

    ngAfterViewInit() {
        //$('advanced-support').parent().attr({ 'style': 'overflow-y:auto;max-height:500px;height: !important' });
        //$('advanced-support').find('#excelGrid div:first').attr({ 'style': 'max-height:500px;overflow:auto' });
        console.log('afterViewInit');

        //$('advanced-support').find('#excelGrid').find('div[role=row] .jqx-grid-cell').attr({ 'style': 'height:10% !important;' });

    }

    enableColumn(typeId: any, forWhich: any) {
        let isHidden: boolean = true;
        if (typeId == 1 && forWhich == 1) {
            isHidden = false;
        }
        else if (typeId != 1 && forWhich == 2) {
            isHidden = false;
        }
        else if (forWhich == 3 && (this.format == "" || this.format == undefined)) {
            isHidden = false;
        }
        return isHidden;
    }

    setWidth(typeId: any, forWhich: any,name:any) {
        let isHidden: boolean = true;
        if (typeId == 1 && forWhich == 1) {
            isHidden = false;
        }
        else if (typeId != 1 && forWhich == 2) {
            isHidden = false;
        }
        else if (forWhich == 3 && (this.format == "" || this.format == undefined)) {
            isHidden = false;
        }
        if (isHidden == true) {
            if (name == "version") {
                return "22%";
            }
            else if (name == "part") {
                return "19%";
            }
            else {
                return "18%";
            }
        }
        else {
            if (name == "version") {
                return "11%";
            }
            else if (name == "part") {
                return "9%";
            }
            else {
                return "8%";
            }
        }
    }
    getColumnText(format: any, typeId: any, categoryId: any, rootId: any) {
        if (typeId == 1)
            return "<div class='row'><div class='col-sm-6'><span>Where Used-</span>" + "<label><a target='_blank' href='#' onclick='viewMatrix(" + categoryId + "," + rootId + ")'>View Matrix</a></label></div></div>";
        else
            return "Where Used";

    }

    displaycellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        if (columnfield == "location") {
            if (rowdata.id != 0 && rowdata.location.indexOf('Workflow Complete') > -1) {
                $(defaulthtml).css('background-color', 'LightSteelBlue');
                var element = $(defaulthtml);
                element[0].innerHTML = "<div style='background-color:LightSteelBlue' title='Can only be removed by the Product Team'>" + rowdata.location + "</div>";
                // element[0].outerHTML = "<div style='background-color:LightSteelBlue'></div>";
                return element[0].outerHTML;
            }
            else if (rowdata.id != undefined && rowdata.id != 0) {
                var element = $(defaulthtml);
                element[0].innerHTML = "<input checked type='checkbox' id='chkSupport' value=" + rowdata.versionId + " isalreadyselected='true' productDeliverableReleaseId=" + rowdata.productDeliverableReleaseId + " releaseId = " + rowdata.releaseId +" />";
                return element[0].outerHTML;
            }
            else {
                var element = $(defaulthtml);
                element[0].innerHTML = "<input type='checkbox' id='chkSupport' value=" + rowdata.versionId + " isalreadyselected='false' productDeliverableReleaseId=" + rowdata.productDeliverableReleaseId + " releaseId = " + rowdata.releaseId +" />";
                return element[0].outerHTML;
            }
        }
        else if (columnfield == "products") {
            if (rowdata.products != null && rowdata.products != undefined) {
                var result = "";
                if (rowdata.products.length > 0) {
                    var productinfo = JSON.stringify(rowdata.products);
                    result = "Product Supported: " + "<a class='showProducts' title='' onclick='ShowProducts(this," + productinfo + ")'>" + rowdata.products.length + "</a>";
                }
                return result;
            }
            else {
                return "";
            }
        }
    };
    //call services to get value from db.
    ngOnInit(): void {

    }
    productId: any;
    releaseId: any;

    getAdvancedSupport() {
        //advanceSupportViewModel.SelectedVersionIds = idList;
        this.advanceSupportViewModel = new AdvanceSupportViewModel();
        let prodRootId = this.route.snapshot.params['prodRootId'];
        let rootId = this.route.snapshot.params['rootId'];
        let rowId = this.route.snapshot.params['rowId'];
        let productDeliverableReleaseId = this.route.snapshot.params['productDeliverableReleaseId'];
        let versionId = this.route.snapshot.params['versionId'];

        this.advancedSupportService.getDeliverableRootType(rootId, versionId)
            .subscribe(res => {
                this.typeId = res.json();
                this.advancedSupportService.getDeliverableRootCategory(rootId)
                    .subscribe(data => {
                        this.categoryId = data.json();
                        this.jqxGridConfig.columns = [
                            {
                                text: 'Supported', columngroup: 'AdvancedSupport',
                                datafield: 'location', width: '15%', hidden: this.enableColumn(this.typeId, 3), cellsrenderer: this.displaycellsrenderer, sortable: false,
                            },
                            {
                                text: 'Supported', columngroup: 'AdvancedSupport',
                                datafield: 'supported', width: '15%', hidden: true,
                            },
                            {
                                text: 'ID', columngroup: 'AdvancedSupport',
                                datafield: 'versionId', width: '7%', filtertype: 'input'
                            },
                            {
                                text: 'HW,FW,Rev', columngroup: 'AdvancedSupport',
                                datafield: 'version', width: '16%', filtertype: 'input', hidden: this.enableColumn(this.typeId, 1)
                            },
                            {
                                text: 'Vendor', columngroup: 'AdvancedSupport',
                                datafield: 'vendor', width: '12%', filtertype: 'input', hidden: this.enableColumn(this.typeId, 1)
                            },
                            {
                                text: 'Model', columngroup: 'AdvancedSupport',
                                datafield: 'modelNumber', width: '15%', filtertype: 'input', hidden: this.enableColumn(this.typeId, 1)
                            },
                            {
                                text: 'Version', columngroup: 'AdvancedSupport',
                                datafield: 'newVersion', width: this.setWidth(this.typeId, 1,"version"), filtertype: 'input', hidden: this.enableColumn(this.typeId, 2)
                            },
                            {
                                text: 'Part', columngroup: 'AdvancedSupport',
                                datafield: 'partNumber', width: this.setWidth(this.typeId, 1, "part"), filtertype: 'input'
                            },
                            {
                                text: 'EOA', columngroup: 'AdvancedSupport',
                                datafield: 'eolDate', width: this.setWidth(this.typeId, 1, "eoa"), filtertype: 'input'
                            },
                            {
                                text: this.getColumnText(this.format, this.typeId, this.categoryId, rootId), columngroup: 'AdvancedSupport',
                                datafield: 'products', width: '16%', filtertype: 'input', cellsrenderer: this.displaycellsrenderer, sortable: false, filterable: false
                            },
                            {
                                text: 'SupportProducts', columngroup: 'AdvancedSupport',
                                datafield: 'productUsed', width: '12%', filtertype: 'input', cellsrenderer: this.displaycellsrenderer, sortable: false, filterable: false
                            },
                            {
                                text: 'Id', columngroup: 'AdvancedSupport',
                                datafield: 'id', hidden: true
                            },
                            {
                                text: 'ProductDeliverableReleaseId', columngroup: 'AdvancedSupport',
                                datafield: 'productDeliverableReleaseId', hidden: true
                            },
                            {
                                text: 'releaseId', columngroup: 'AdvancedSupport',
                                datafield: 'releaseId', hidden: true
                            },
                        ];
                        this.format = this.route.snapshot.params['format'];
                        console.log('constructor');
                        this.advancedSupportGrid.createComponent(this.jqxGridConfig.settings);
                        this.advancedSupportGrid.hidecolumn('productUsed');
                        this.advancedSupportGrid.showdefaultloadelement(true);

                        $('#excelGrid').find('div[role=row]').attr({ 'style': 'display:none' });

                        this.advancedSupportService.getAdvancedSupport(prodRootId, rootId, productDeliverableReleaseId, rowId)
                            .subscribe(result => {
                                this.advancedSupportProduct = result.json();
                                this.productId = this.advancedSupportProduct.productId;
                                this.releaseId = this.advancedSupportProduct.releaseId;
                                let rootId = this.route.snapshot.params['rootId'];
                                this.jqxGridConfig.localdata = result.json().productDeliverableViewModel;
                                this.advancedSupportGrid.updatebounddata(null);
                                this.advancedSupportGrid.hideloadelement();
                                if (this.advancedSupportProduct.isLoadFailed == true) {
                                    // $('#contentPage').attr('style', 'display:none');
                                    $('#result').attr('style', 'display:none');
                                    $('#emptyPage').removeAttr('style');

                                }
                            });
                    });
            });
    }

    ErrorMessage: string[];
    isError: boolean = false;
    updateAdvancedSupport(): void {
        var comments = "";
        var productIds = "";
        var osIds = "";

        //var selectedIndices = this.advancedSupportGrid.selectedrowindexes();
        var idList = '';
        var idLoaded = '';
        var index: number;
        var releaseId = '';
        var productDeliverableDetails = new Array<ProductDeliverableModel>();
        $('#excelGrid').find('div[role=row]').each(function () {
            if ($(this).find('input[id=chkSupport]') != undefined && $(this).find('input[id=chkSupport]') != null) {
                if (releaseId == '') {
                    releaseId = $(this).find('input[id=chkSupport]').attr('releaseId');
                }
                if ($(this).find('input[id=chkSupport]').prop('checked') == true && $(this).find('input[id=chkSupport]').attr('isalreadyselected') != 'true') {
                    //idList += $(this).find('input[id=chkSupport]').val() + ",";
                }
                else if ($(this).find('input[id=chkSupport]').attr('isalreadyselected') == 'true') {
                    idLoaded += $(this).find('input[id=chkSupport]').val() + ",";
                }
                if ($(this).find('input[id=chkSupport]').prop('checked') == true) {
                    idList += $(this).find('input[id=chkSupport]').val() + ",";
                }
                if ($(this).find('input[id=chkSupport]').prop('checked') == false && $(this).find('input[id=chkSupport]').attr('isalreadyselected') == 'true') {
                    productDeliverableDetails.push(new ProductDeliverableModel($(this).find('input[id=chkSupport]').val(), $(this).find('input[id=chkSupport]').attr('productdeliverablereleaseId')));
                }
            }
        });
        if (idList == '' && idLoaded=='') {
            this.closeExternalPopup();
            return;
        } else {
            if (idList != '') {
                idList = idList.slice(0, - 1);
            }
            if (idLoaded != '') {
                idLoaded = idLoaded.slice(0, - 1);
            }
            let advanceSupportViewModel = new AdvanceSupportViewModel();
            advanceSupportViewModel.SelectedVersionIds = idList;
            advanceSupportViewModel.LoadedVersionIds = idLoaded;
            advanceSupportViewModel.ProductId = this.productId; //this.route.snapshot.params['productId'];
            advanceSupportViewModel.RootId = this.route.snapshot.params['rootId'];
            advanceSupportViewModel.ReleaseId = this.releaseId; //this.route.snapshot.params['releaseId'];
            advanceSupportViewModel.ProductDeliverableReleaseId = this.route.snapshot.params['productDeliverableReleaseId'];
            advanceSupportViewModel.ProdRootId = this.route.snapshot.params['prodRootId'];
            advanceSupportViewModel.ProductDeliverableDetails = productDeliverableDetails;
            this.advancedSupportGrid.showdefaultloadelement(true);
            this.advancedSupportService.updateAdvancedSupport(advanceSupportViewModel).subscribe(result => {
                if (result.json() == true) {
                    this.advancedSupportGrid.hideloadelement();
                    this.closeExternalPopup();
                    popupCallBack(1);
                }
                else {
                    alert("Unable to update supported products.");
                    this.advancedSupportGrid.hideloadelement();
                }
            });
        }

    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
    ExportExcel() {
        //$("#excelGrid").jqxGrid('exportdata', 'xls', 'jqxGrid'); 
        this.advancedSupportGrid.hidecolumn('products');
        this.advancedSupportGrid.showcolumn('productUsed');

        this.advancedSupportGrid.exportdata('xls', 'AdvancedSupport', true, null, false, '', '');
        this.advancedSupportGrid.showcolumn('products');
        this.advancedSupportGrid.hidecolumn('productUsed');
    }
}

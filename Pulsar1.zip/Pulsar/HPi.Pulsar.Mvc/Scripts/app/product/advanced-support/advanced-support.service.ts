﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08-31-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="irs-component-product-update.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { AdvanceSupportViewModel } from '../advanced-support/advanced-support.viewmodel'

@Injectable()
export class AdvancedSupportService {

    constructor(private http: Http, private location: Location) {
    }

    getAdvancedSupport(prodRootId, rootId, productDeliverableReleaseId, rowId) {
        // return this.http.get(this.location.prepareExternalUrl('/product/Product/GetAdvancedSupport'));
        //var headers = new Headers();
        //headers.append('Content-Type', 'application/json');
        //let advanceSupportVM: any;
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetAdvancedSupport?prodRootId=' + prodRootId + '&rootId=' + rootId + '&productDeliverableReleaseId=' + productDeliverableReleaseId + '&rowId=' + rowId));
    }

    updateAdvancedSupport(advanceSupportViewModel: AdvanceSupportViewModel) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/UpdateAdvancedSupport'), advanceSupportViewModel, {
            headers: headers
        });
    }
    getDeliverableRootType(rootId,versionId) {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetDeliverableRootType?rootId=' + rootId + '&versionId='+ versionId));
    }
    getDeliverableRootCategory(rootId) {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetDeliverableRootCategory?rootId=' + rootId));
    }
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08-31-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="irs-component-product-update.viewmodel.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class IRSComponentUpdateProductViewModel {
    partNumber: string;
    versionId: string;
    deliverableName: string;
    version: string;
    revision: string;
    pass: string;
    transferdescription: string;
    transferStatus: string;
    previousVersionPartNumbers: string;
    product: string;
    targetNotes: string;
    imageSummary: string;
    previousVersionCount: string;
    action: string;
    osList: string;
}
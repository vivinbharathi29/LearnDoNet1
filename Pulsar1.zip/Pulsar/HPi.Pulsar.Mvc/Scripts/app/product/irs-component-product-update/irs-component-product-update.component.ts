﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08/31/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="irs-component-product-update.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';

import { IRSComponentUpdateProductService } from './irs-component-product-update.service';
import { IRSComponentUpdateProductViewModel } from './irs-component-product-update.viewmodel';

@Component({
    selector: 'irs-component-product-update',
    templateUrl: './irs-component-product-update.component.html',
    providers: [IRSComponentUpdateProductService]
})
export class IRSComponentUpdateProductComponent implements OnInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    irsComponentUpdateProductViewModel: IRSComponentUpdateProductViewModel;
    public irsComponentUpdateProduct: any;
    toggle = false;
    productIds: any = '';
    osIds: any = '';
    count: any = '';
    constructor(private irsComponentUpdateProductService: IRSComponentUpdateProductService, private route: ActivatedRoute, private router: Router) {
        this.irsComponentUpdateProductViewModel = new IRSComponentUpdateProductViewModel();
        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.datafields = [
        //    { name: 'partNumber', map: 'partNumber', type: 'string' },
        //    { name: 'versionId', map: 'versionId', type: 'string' },
        //    { name: 'deliverableName', map: 'deliverableName', type: 'string' },
        //    { name: 'version', map: 'version', type: 'string' },
        //    { name: 'revision', map: 'revision', type: 'string' },
        //    { name: 'pass', map: 'pass', type: 'string' },
        //    { name: 'transferdescription', map: 'transferdescription', type: 'string' },
        //    { name: 'transferStatus', map: 'transferStatus', type: 'string' },
        //    { name: 'product', map: 'product', type: 'string' },
        //    { name: 'imageSummary', map: 'imageSummary', type: 'string' },
        //    { name: 'targetNotes', map: 'targetNotes', type: 'string' },
        //    { name: 'previousVersionPartNumbers', map: 'previousVersionPartNumbers', type: 'string' },
        //    { name: 'previousVersionCount', map: 'previousVersionCount', type: 'string' },
        //    { name: 'action', map: 'action', type: 'string' },
        //];

        //this.jqxGridConfig.columns = [
        //    {
        //        text: 'IRS Part Number', columngroup: 'IRSComponentUpdate',
        //        datafield: 'partNumber', width: '10%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Excalibur ID', columngroup: 'IRSComponentUpdate',
        //        datafield: 'versionId', width: '7%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Name', columngroup: 'IRSComponentUpdate',
        //        datafield: 'deliverableName', width: '15%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Version', columngroup: 'IRSComponentUpdate',
        //        datafield: 'version', width: '8%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Revision', columngroup: 'IRSComponentUpdate',
        //        datafield: 'revision', width: '7%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Pass', columngroup: 'IRSComponentUpdate',
        //        datafield: 'pass', width: '5%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Issues', columngroup: 'IRSComponentUpdate',
        //        datafield: 'transferStatus', width: '5%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Product', columngroup: 'IRSComponentUpdate',
        //        datafield: 'product', width: '8%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Action', columngroup: 'IRSComponentUpdate',
        //        datafield: 'action', width: '7%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Replace', columngroup: 'IRSComponentUpdate',
        //        datafield: 'previousVersionPartNumbers', width: '7%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Target Notes', columngroup: 'IRSComponentUpdate',
        //        datafield: 'targetNotes', width: '12%', filtertype: 'input'
        //    },
        //    {
        //        text: 'Image Summary', columngroup: 'IRSComponentUpdate',
        //        datafield: 'imageSummary', width: '12%', filtertype: 'input'
        //    },
        //];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.getOsAndProductDetails();
        (<HTMLInputElement>document.getElementById("externalpopup")).style.display = "none";
    }

    getOsAndProductDetails() {
        let irsComponent = {
            "OSIds": this.osIds,
            "ProductIds": this.productIds
        }
        this.irsComponentUpdateProductService.getOSAndProductDetails(irsComponent).subscribe(result => {
            this.irsComponentUpdateProduct = result.json();
            (<HTMLInputElement>document.getElementById("loading")).style.display = "none";
            (<HTMLInputElement>document.getElementById("externalpopup")).style.display = "none";
        });
    }

    selectAll() {
        var items = <HTMLCollection>document.getElementsByClassName('lstProduct');
        for (var i = 0; i < items.length; i++) {
            if ((<HTMLInputElement>items[i]).type == 'checkbox')
                (<HTMLInputElement>items[i]).checked = true;
        }
    }

    unSelectAll() {
        var items = <HTMLCollection>document.getElementsByClassName('lstProduct');
        for (var i = 0; i < items.length; i++) {
            if ((<HTMLInputElement>items[i]).type == 'checkbox')
                (<HTMLInputElement>items[i]).checked = false;
        }
    }    

    cmdApplyChanges_onclick(): void {
        (<HTMLInputElement>document.getElementById("loading")).style.display = "block";
        (<HTMLInputElement>document.getElementById("divirscomponent")).style.pointerEvents = "none";
        var comments = "";
        this.productIds = '';
        this.osIds = '';
        var product = <HTMLCollection>document.getElementsByClassName('lstProduct');
        var os = <HTMLCollection>document.getElementsByClassName('lstOs');
        if (product != null)
        {
            for (var i = 0; i < product.length; i++) {
                if ((<HTMLInputElement>product[i]).type == 'checkbox')
                    if ((<HTMLInputElement>product[i]).checked == true) {
                        this.productIds += (<HTMLInputElement>product[i]).id + ",";
                    }
            }
        }
        if (os != null) {
            for (var i = 0; i < os.length; i++) {
                if ((<HTMLInputElement>os[i]).type == 'checkbox')
                    if ((<HTMLInputElement>os[i]).checked == true) {
                        this.osIds += (<HTMLInputElement>os[i]).value + ",";
                    }
            }
        }
        this.ngOnInit();
        let irsComponent = {
            "OSIds": this.osIds,
            "ProductIds": this.productIds
        }
        this.irsComponentUpdateProductService.getComponentsToPutInIRSProductDrop(irsComponent).subscribe(result => {
            var obj = result.json().irsComponentUpdateProduct;
            var datafields = new Array();
            var columns = new Array();
            for (var i in obj[0]) {
                datafields.push({ name: i, map: i, type: 'string' });
                columns.push({ text: this.columnName(i), datafield: i, width: this.columnWidth(i), filtertype: 'input' });
            }
            this.jqxGridConfig.datafields = datafields;
            this.jqxGridConfig.columns = columns;
            this.myGrid.createComponent(this.jqxGridConfig.settings);
            this.jqxGridConfig.settings.rowsheight = 50;
            this.jqxGridConfig.settings.pageable = true;
            this.myGrid.showdefaultloadelement(true);
            this.jqxGridConfig.localdata = result.json().irsComponentUpdateProduct;
            if (result.json().irsComponentUpdateProduct != undefined) {
                this.count = result.json().irsComponentUpdateProduct.length;
                (<HTMLInputElement>document.getElementById("irsGrid")).style.display = "block";
                (<HTMLInputElement>document.getElementById("lblDisplay")).style.display = "block";
                (<HTMLInputElement>document.getElementById("lblGrid")).style.display = "none";
                (<HTMLInputElement>document.getElementById("loading")).style.display = "none";
                (<HTMLInputElement>document.getElementById("divirscomponent")).style.pointerEvents = "all";
                (<HTMLInputElement>document.getElementById("externalpopup")).style.display = "none";
            }
            else {
                this.count = '';
                (<HTMLInputElement>document.getElementById("irsGrid")).style.display = "none";
                (<HTMLInputElement>document.getElementById("lblDisplay")).style.display = "none";
                (<HTMLInputElement>document.getElementById("lblGrid")).style.display = "block";
                (<HTMLInputElement>document.getElementById("divirscomponent")).style.pointerEvents = "all";
                (<HTMLInputElement>document.getElementById("externalpopup")).style.display = "none";
            }
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    columnName(x) {
        switch (x) {
            case "partNumber": return "IRS Part Number";
            case "versionId": return "Excalibur ID";
            case "deliverableName": return "Name";
            case "version": return "Version";
            case "revision": return "Revision";
            case "pass": return "Pass";
            case "transferStatus": return "Issues";
            case "product": return "Product";
            case "action": return "Action";
            case "previousVersionPartNumbers": return "Replace";
            case "win7": return "Win7";
            case "win8": return "Win8";
            case "win81": return "Win8.1";
            case "win10": return "Win10";
            case "targetNotes": return "Target Notes";
            case "imageSummary": return "Image Summary";
            default: return " ";
        }
    };

    columnWidth(x) {
         switch (x) {
            case "partNumber": return "10%";
            case "versionId": return "7%";
            case "deliverableName": return "15%";
            case "version": return "8%";
            case "revision": return "7%";
            case "pass": return "5%";
            case "transferStatus": return "5%";
            case "product": return "8%";
            case "action": return "7%";
            case "previousVersionPartNumbers": return "7%";
            case "win7": return "5%";
            case "win8": return "5%";
            case "win81": return "5%";
            case "win10": return "5%";
            case "targetNotes": return "12%";
            case "imageSummary": return "12%";
            default: return " ";
        }
    };

    resetWindow(): void {
        (<HTMLInputElement>document.getElementById("loading")).style.display = "block";
        (<HTMLInputElement>document.getElementById("divirscomponent")).style.pointerEvents = "none";
        this.productIds = '';
        this.osIds = '';
        this.ngOnInit();
        this.myGrid.clear();
        (<HTMLInputElement>document.getElementById("irsGrid")).style.display = "none";
        (<HTMLInputElement>document.getElementById("lblDisplay")).style.display = "none";
        (<HTMLInputElement>document.getElementById("lblGrid")).style.display = "block";
        (<HTMLInputElement>document.getElementById("loading")).style.display = "none";
        (<HTMLInputElement>document.getElementById("divirscomponent")).style.pointerEvents = "all";
    }
}
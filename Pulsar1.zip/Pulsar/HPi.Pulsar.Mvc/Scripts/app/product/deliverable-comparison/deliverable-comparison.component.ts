﻿import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { DeliverableComparisonService } from './deliverable-comparison.service'
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';

@Component({
    selector: 'deliverable-comparison',
    templateUrl: './deliverable-comparison.component.html',
    providers: [DeliverableComparisonService]
})
export class DeliverableComparisonComponent {
    errorMessage: string;
    public deliverableComparisonVM: any;
    public scheduledataId: any;
    public rootId: any = 0;
    public prodId: any = 0;
    //public releaseId: any = 0;
    deliverableComparisonform: FormGroup;

    constructor(http: Http, private service: DeliverableComparisonService, private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router) {
        this.rootId = activatedRoute.snapshot.params['rootID'];
        this.prodId = activatedRoute.snapshot.params['prodID'];
        //this.releaseId = activatedRoute.snapshot.params['releaseId'];
        this.deliverableComparisonform = fb.group({

        })
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.scheduledataId = params['scheduledataid'];
        });
    }

    ngOnInit() {
        //this.getDeliverableComparison();
    }

    ngAfterViewInit(): void {
        this.getDeliverableComparison();
    }

    getDeliverableComparison() {

        this.service.geDeliverableComparison(this.rootId, this.prodId).subscribe(result => {

            this.deliverableComparisonVM = result.json();
            this.deliverableComparisonform = this.fb.group({

            })
        });
    }

    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

}  
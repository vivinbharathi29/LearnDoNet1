﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Vignesh.T
// Created          : 09-04-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="deliverable-comparison.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class DeliverableComparisonService {

    constructor(private http: Http, private location: Location) {
    }

    geDeliverableComparison(rootId: number, prodId: number): Observable<Response> {

        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetDeliverableComparison/' + rootId + '/' + prodId));
    }
}
﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09/15/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 05-31-2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="compare-root-on-lead-product.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { RootOnLeadProductService } from './compare-root-on-lead-product.service';

@Component({
    selector: 'root-lead-product',
    templateUrl: './compare-root-on-lead-product.component.html',
    providers: [RootOnLeadProductService]
})
export class RootOnLeadProductComponent implements OnInit {
    rootId: number;
    productId: number;
    fusionRequirement: any;
    errorMessage: string;
    deliverableName: string;
    public rootLeadProductViewModel: any;

    constructor(private rootOnLeadProductService: RootOnLeadProductService, private route: ActivatedRoute, private router: Router) {
        this.rootId = route.snapshot.params['rootId'];
        this.productId = route.snapshot.params['id'];
        this.fusionRequirement = route.snapshot.params['fusionRequirement'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.getRequestedDeliverables();
    }

    getRequestedDeliverables() {
        this.rootOnLeadProductService.getRequestedDeliverables(this.rootId, this.productId, this.fusionRequirement).subscribe(result => {
            this.rootLeadProductViewModel = result.json();
            if (result.json().length > 0) {
                this.errorMessage = result.json()[0]['errorMessage'];
                this.deliverableName = result.json()[0]['deliverableName'];
            }
        });
    }
}
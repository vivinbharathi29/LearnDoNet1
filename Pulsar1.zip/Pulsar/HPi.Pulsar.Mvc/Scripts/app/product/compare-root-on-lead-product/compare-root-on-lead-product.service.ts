﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-15-2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01-10-2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="compare-root-on-lead-product.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class RootOnLeadProductService {

    constructor(private http: Http, private location: Location) {
    }

    getRequestedDeliverables(rootId: number, productId: number, fusionRequirement: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetRequestedDeliverables/' + rootId + '/' + productId + '/' + fusionRequirement));
    }
}
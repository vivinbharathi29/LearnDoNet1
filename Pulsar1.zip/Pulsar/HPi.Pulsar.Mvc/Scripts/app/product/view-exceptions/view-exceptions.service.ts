﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/10/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-workflow-definitions.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class ViewExceptionsService {
    constructor(private http: Http, private location: Location) {
    }

    getLeadProductUsageExceptions(pmId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetLeadProductUsageExceptions?pmId=' + pmId));
    }

    updateLeadProductUsageExceptions(leadProductIds: any, types: any): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/UpdateLeadProductUsageExceptions/' + leadProductIds + '/' + types));
    }
}

﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { ViewExceptionsService } from './view-exceptions.service';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../shared//pagination/filter-column-type-enum';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../shared/messagebox/index';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router'

import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';

@Component({
    selector: 'view-exceptions',
    templateUrl: './view-exceptions.component.html',
})

export class ViewExceptionsComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;
    public leadproductId: any;
    deliverableStatusform: FormGroup;
    public message: string = "";
    constructor(http: Http, private service: ViewExceptionsService, private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router) {
        this.buildForm();
        this.leadproductId = activatedRoute.snapshot.params['id'];
       
        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.width = 1078;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';


        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product', type: 'string' },
            { name: 'deliverable', map: 'deliverable' },
            { name: 'versions', map: 'versions' },
            { name: 'distribution', map: 'distribution' },
            { name: 'notes', map: 'notes' },
            { name: 'images', map: 'images' },
            { name: 'comments', map: 'comments' },
            { name: 'typeIdPrefix', map: 'typeIdPrefix' },
            { name: 'id', map: 'id' }
            
        ];

        this.jqxGridConfig.columns = [
            { text: 'Product', filtertype: 'input', datafield: 'product', width: "20%", cellsrenderer: this.cellsrenderer },
            { text: 'Deliverable', filtertype: 'input', datafield: 'deliverable',  width: "20%" },
            { text: 'Versions', filtertype: 'input', datafield: 'versions',  width: "20%" },
            { name: 'Distribution', filtertype: 'input', datafield: 'distribution',   width: "20%" },
            { name: 'Notes', filtertype: 'input', datafield: 'notes',  width: "10%"  },
            { text: 'Images', filtertype: 'input', datafield: 'images', cellsalign: 'left', align: 'left', width: "10%", cellsrenderer: this.cellsrenderer },
            { text: 'Comments', filtertype: 'input', datafield: 'comments', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer },
            { text: 'typeIdPrefix', filtertype: 'input', datafield: 'typeIdPrefix', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'id', filtertype: 'input', datafield: 'id', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            

        ];

        this.jqxGridConfig.columnTypes = {
            'product': FilterColumnTypeEnum.String,
            'deliverable': FilterColumnTypeEnum.String,
            'versions': FilterColumnTypeEnum.String,
            'distribution': FilterColumnTypeEnum.String,
            'notes': FilterColumnTypeEnum.String,
            'images': FilterColumnTypeEnum.String,
            'comments': FilterColumnTypeEnum.String,
            'typeIdPrefix': FilterColumnTypeEnum.String,
            'id': FilterColumnTypeEnum.Number
        }
    }

    buildForm(): void {
        this.deliverableStatusform = this.fb.group({
            product: "",
            deliverable: "",
            versions: "",
            distribution: "",
            notes: "",
            images: "",
            comments: "",
            typeIdPrefix : ""
        });
    }

    getComponentsAwaitingFinalApproval(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getLeadProductUsageExceptions(this.leadproductId).subscribe(result => {

            this.jqxGridConfig.localdata = result.json();
            if (this.jqxGridConfig.localdata != null) {
                this.message = "No Exclusions are currently defined on active products";
            } else {
                this.message = "";
            }
            console.log(result.json());
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    saveLeadProductUsageExceptions() {
        var index: number;
        var strProductID = "";
        var typeIdPrefix = "";
        var id = "";
        var selectedIndices = this.myGrid.selectedrowindexes();
        if (typeof (selectedIndices.length) != "undefined") {
            for (index = 0; index < selectedIndices.length; index++) {
                typeIdPrefix = this.myGrid.getrowdata(selectedIndices[index]).typeIdPrefix;
                id = this.myGrid.getrowdata(selectedIndices[index]).id;
                this.service.updateLeadProductUsageExceptions(id, typeIdPrefix).subscribe(
                    (data) => {
                        var success = data.json();
                        console.log(success);
                        if (success) {
                          
                            //this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                           // popupCallBack(1);
                            //closePopup('externalpagepopup');
                        }
                        else {
                            //this.errorMessage = "Unable to update Supplier Code.  An unexpected error occurred.";
                        }
                    },
                    Error => {
                        console.log('Failed', Error);
                       // this.blnError = true;
                    }
                );;

            }
           
        }
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
        //this.getProducts(paginationInfo);

    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
    }

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
    }

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {

    };

    cancel(): void {
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }

   
}

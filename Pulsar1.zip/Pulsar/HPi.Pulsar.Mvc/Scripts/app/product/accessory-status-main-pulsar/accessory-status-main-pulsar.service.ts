﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-06-2017
// Last Modified By : Rajivgandhi.R(auth\rajamanr)
// Last Modified On : 01-11-2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="accessory-status-main-pulsar.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';


@Injectable()
export class AccessoryStatusPulsarService {

    constructor(private http: Http, private location: Location) {
    }

    getAccessoryStatusPulsar(productId: number, versionId: number, releaseId, productDeliverableReleaseId: any, todayPageSection:any): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetAccessoryStatusPulsar?prodId=' + productId + '&versionId=' + versionId + '&productDeliverableReleaseId=' + productDeliverableReleaseId + '&todayPageSection=EditAccessoryStatus2&releaseId=' + releaseId +'&todayPageSection='+todayPageSection));
    }

    updateAccessoryStatusPulsar(accessoryStatusViewModel: any, productId: any, versionId: any,productDeliverableReleaseId:any, chkStatus: any) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/UpdateAccessoryStatusPulsar?productDeliverableReleaseId=' + productDeliverableReleaseId + '&prodId=' + productId + '&versionId=' + versionId + '&chkStatus=' + chkStatus + '&todayPageSection=EditAccessoryStatus2'), accessoryStatusViewModel); 
    }
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R(auth\rajamanr)
// Created          : 09-06-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="accessory-status-main-pulsar.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { FormsModule, FormBuilder, Validators, ReactiveFormsModule, Form, NgForm, NgControl, FormArray, NgModel, FormGroup, FormControl } from '@angular/forms';
import { AccessoryStatusPulsarService } from './accessory-status-main-pulsar.service'

import { CustomValidationService } from '../../shared/custom-validation.service'
import { ActivatedRoute, NavigationExtras, Params, Router, Route } from '@angular/router';
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
declare let $: any;
@Component({
    selector: 'accessory-status-main-pulsar',
    templateUrl: './accessory-status-main-pulsar.component.html',
})

export class AccessoryStatusPulsarComponent implements AfterViewInit {
    id: number;
    accessoryStatusInfoForm: FormGroup;
    errorMessage: string;
    accessoryStatusViewModel: any;
    productID: any;
    versionID: any;
    productDeliverableReleaseID: any;
    releaseId: any;
    todayPageSection: any;
    buttonClick: any;
    accessoryStatusId: any;
    @ViewChild('dateInput') myDateInput: jqxDateTimeInputComponent;
    //showArticleListCallBack
    constructor(http: Http, private service: AccessoryStatusPulsarService, private fb: FormBuilder, private customValidationService: CustomValidationService, private ngZone: NgZone, private route: ActivatedRoute, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            //ShowArtileListCallBackFn: (value) => this.showArticleListCallBack(value),
            component: this
        };
        this.accessoryStatusInfoForm = this.fb.group({
            "Id": [''],
            "QualStatus": [''],
            "Version": [''],
            "Revision": [''],
            "PilotStatus": [''],
            "ModelNumber": [''],
            "PartNumber": [''],
            "Pass": [''],
            "AccessoryDate": [''],
            "KitNumber": [''],
            "KitDescription": [''],
            "AccessoryNotes": [''],
            "Date": [''],
            "Vendor": [''],
            "Product": [''],
            "DeliverableName": [''],
            "IsDateFieldReq": [''],
            "IsCommentFieldReq": [''],
            "IsShowDate": [''],
            "AccessoryStatusId":['']
        });
    }
    existingPilotStatusID: any;
    getAccessoryStatus() {
        this.productID = this.route.snapshot.params['productId'];
        this.versionID = this.route.snapshot.params['deliverableId'];
        this.productDeliverableReleaseID = this.route.snapshot.params['productDeliverableReleaseId'];
        this.releaseId = this.route.snapshot.params['releaseId'];
        this.id = this.route.snapshot.params['id'];
        this.todayPageSection = this.route.snapshot.params['todayPageSection'];
        this.service.getAccessoryStatusPulsar(this.productID, this.versionID,this.releaseId, this.productDeliverableReleaseID,this.todayPageSection).subscribe(result => {
            this.accessoryStatusViewModel = result.json();
            this.accessoryStatusId = this.accessoryStatusViewModel.accessoryStatusId;
           
            this.accessoryStatusInfoForm = this.fb.group({
                "Id": [this.accessoryStatusViewModel.id],
                "QualStatus": [this.accessoryStatusViewModel.qualStatus],
                "Version": [this.accessoryStatusViewModel.version],
                "Revision": [this.accessoryStatusViewModel.revision],
                "PilotStatus": [this.accessoryStatusViewModel.pilotStatus],
                "ModelNumber": [this.accessoryStatusViewModel.modelNumber],
                "PartNumber": [this.accessoryStatusViewModel.partNumber],
                "Pass": [this.accessoryStatusViewModel.pass],
                "AccessoryDate": [this.accessoryStatusViewModel.accessoryDate],
                "KitNumber": [this.accessoryStatusViewModel.kitNumber,  Validators.compose([Validators.required])],
                "KitDescription": [this.accessoryStatusViewModel.kitDescription],
                "AccessoryStatusId": [this.accessoryStatusViewModel.accessoryStatusId],
                "AccessoryNotes": [this.accessoryStatusViewModel.accessoryNotes, Validators.compose([Validators.required])],
                "Date": [this.accessoryStatusViewModel.accessoryDate,  Validators.compose([Validators.required])],
                "Vendor": [this.accessoryStatusViewModel.vendor],
                "name": [this.accessoryStatusViewModel.name],
                "DeliverableName": [this.accessoryStatusViewModel.deliverableName],
                "IsDateFieldReq": [this.accessoryStatusViewModel.isDateRequired],
                "IsCommentFieldReq": [this.accessoryStatusViewModel.isCommentRequired],
                "IsShowDate": [this.accessoryStatusViewModel.isShowDate]
            });

            for (let accessory of this.accessoryStatusViewModel.accessoryStatusListModel) {
                //  index = index + 1;
                if (accessory.selected != "") {
                    this.accessoryStatusInfoForm.controls["AccessoryStatusId"].setValue(accessory.id);
                    this.accessoryStatusInfoForm.updateValueAndValidity();
                    $('select[id=StatusID]').append('<option selected value=' + accessory.id +'>' + accessory.name + '</option>');
                }
                else {
                    $('select[id=StatusID]').append('<option value=' + accessory.id + '>' + accessory.name + '</option>');
                }
            }
            
        });
       
    }
    ngOnInit(): void {
        this.getAccessoryStatus();

    }

    isError: boolean = false;
    ErrorMessage: string[];
    saveAccessoryStatus(accessoryStatusViewModel: any) {
        this.ErrorMessage = [];
        this.isError = false;
     
        for (const control in this.accessoryStatusInfoForm.controls) {
            switch (control) {
                case "AccessoryStatusId":
                    if (this.accessoryStatusInfoForm.controls[control].value == 0) {
                        this.ErrorMessage.push('Accessory Status is Required');
                        this.isError = true;
                    }
                    break;
                case "AccessoryNotes":
                    if (this.accessoryStatusInfoForm.controls["IsCommentFieldReq"].value == true && (this.accessoryStatusInfoForm.controls[control].value == "" || this.accessoryStatusInfoForm.controls[control].value == null)) {
                        this.ErrorMessage.push('You must supply comments when entering this Accessory status.');
                        this.isError = true;
                    }
                    break;
                case "KitNumber":
                    if (this.accessoryStatusInfoForm.controls["AccessoryStatusId"].value > 1 && (this.accessoryStatusInfoForm.controls[control].value == "" || this.accessoryStatusInfoForm.controls[control].value == null)) {
                        this.ErrorMessage.push('You must supply a Kit Number when selecting this status.');
                        this.isError = true;
                    }
                    break;
                case "AccessoryDate":
                    if (this.accessoryStatusInfoForm.controls["IsDateFieldReq"].value == true && this.myDateInput.getText().trim()=='') {
                        this.ErrorMessage.push('You must supply a valid date.');
                        this.isError = true;
                    }
                    break;
            }
        }
        this.accessoryStatusViewModel.accessoryStatusId = this.accessoryStatusInfoForm.controls["AccessoryStatusId"].value;
        this.accessoryStatusViewModel.accessoryNotes = this.accessoryStatusInfoForm.controls["AccessoryNotes"].value;
        this.accessoryStatusViewModel.kitNumber = this.accessoryStatusInfoForm.controls["KitNumber"].value;
        this.accessoryStatusViewModel.kitDescription = this.accessoryStatusInfoForm.controls["KitDescription"].value;
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            var chkStatus = <HTMLInputElement>document.getElementById('chkDelete');
            var isDelete = chkStatus!=null?( chkStatus.checked == true ? true : false):false;
            this.service.updateAccessoryStatusPulsar(this.accessoryStatusViewModel, this.productID, this.versionID, this.productDeliverableReleaseID, isDelete).subscribe(res => {
                if (res.json() == true) {
                    if (this.buttonClick == "SaveandClose") {
                        EditAccessoryStatus2ReloadCallback(true);
                        this.cancelPopup();
                    }
                    else if (this.buttonClick == "Save") {
                        this.getAccessoryStatus();
                    }
                }
            });
        }

    }
   
    accessoryStatusChange() {
        let accessoryStatusName: any;
        var accessoryStatus = <HTMLSelectElement>document.getElementById('StatusID');
        this.accessoryStatusId = accessoryStatus.value;
        //if (accessoryStatus.selectedIndex == 1) {
        //    (<HTMLInputElement>document.getElementById('StatusName')).value = accessoryStatus.options[accessoryStatus.selectedIndex].id;
        //    if (<HTMLInputElement>document.getElementById('chkDelete')) {
        //        (<HTMLInputElement>document.getElementById('chkDelete')).style.display = '';
        //    }
        //}
        //else {
        //    if (<HTMLInputElement>document.getElementById('chkDelete')) {
        //        (<HTMLInputElement>document.getElementById('chkDelete')).style.display = 'none';
        //    }
        //}
        var accessoryStatusVM = this.accessoryStatusViewModel.accessoryStatusListModel;
        var exist = false;
        if (accessoryStatusVM != null) {
            {
                if (parseInt((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value) > 1) {
                    (<HTMLSpanElement>document.getElementById('kitNumberReq')).style.display = '';
                }
                else {
                    (<HTMLSpanElement>document.getElementById('kitNumberReq')).style.display = 'none';
                }
                for (let accessory of accessoryStatusVM) {
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id && accessory.commentsRequired == true) {
                        (<HTMLSpanElement>document.getElementById('commentReq')).style.display = '';
                        this.accessoryStatusInfoForm.controls["IsCommentFieldReq"].setValue(true);
                    }
                    else {
                        (<HTMLSpanElement>document.getElementById('commentReq')).style.display = 'none';
                        this.accessoryStatusInfoForm.controls["IsCommentFieldReq"].setValue(false);
                    }
                    if (exist == true)
                        break;
                }
                exist = false;
                for (let accessory of accessoryStatusVM) {
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id && (accessory.dateField == 2 || accessory.dateField == 1)) {
                        (<HTMLDivElement>document.getElementById('isDateFieldRequired')).style.display = '';
                        $('#AccessoryDate').attr({ 'style': 'display:' });
                        this.accessoryStatusInfoForm.controls["IsDateFieldReq"].setValue(true);
                    }
                    else {
                        (<HTMLDivElement>document.getElementById('isDateFieldRequired')).style.display = 'none';
                        $('#AccessoryDate').attr({ 'style': 'display:none' });
                        this.accessoryStatusInfoForm.controls["IsDateFieldReq"].setValue(false);
                    }
                    if (exist == true)
                        break;
                }
                exist = false;
                for (let accessory of accessoryStatusVM) {
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>accessoryStatus.options[accessoryStatus.selectedIndex]).value == accessory.id && accessory.dateField == 1) {
                        (<HTMLSpanElement>document.getElementById('dateReq')).style.display = '';
                    }
                    else {
                        (<HTMLSpanElement>document.getElementById('dateReq')).style.display = 'none';
                    }
                    
                    
                    if (exist == true)
                        break;
                }
            }
        }
    }
    ngAfterViewInit(): void {
        this.getAccessoryStatus();
      
    }



    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

    buttonClickEvent(button): void {
        this.buttonClick = button;
    }
}
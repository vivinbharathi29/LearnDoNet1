﻿import { Routes } from '@angular/router';

import { EditExceptionComponent } from './edit-exception/edit-exception.component';
import { ProgramsPropertyComponent } from './programs-property/programs-property.component';
import { DCRWorkflowChangeRequestComponent } from './dcr-workflow-change/dcr-change-request-workflow.component';
import { WorkingListReorderComponent } from './working-list-reorder/working-list-reorder.component';
import { IRSComponentUpdateProductComponent } from './irs-component-product-update/irs-component-product-update.component';
import { ViewLeadProductExclusionComponent } from './view-lead-product-exclusions/view-lead-product-exclusions.component';
import { ActionComponent } from './action/action.component';
import { PilotStatusComponent } from '../product/pilot-status/pilot-status.component';
import { PilotStatusService } from '../product/pilot-status/pilot-status.service';
import { PilotStatusPulsarComponent } from '../product/pilot-status-pulsar/pilot-status-pulsar.component';
import { PilotStatusPulsarService } from '../product/pilot-status-pulsar/pilot-status-pulsar.service';
import { AvNoToFeatureComponent } from './av-no-to-feature/av-no-to-feature.component';
import { RootOnLeadProductComponent } from './compare-root-on-lead-product/compare-root-on-lead-product.component';
import { MultiUpdateTestStatusComponent } from '../product/multi-update-test-status/multi-update-test-status.component';
import { MultiUpdateTestStatusService } from '../product/multi-update-test-status/multi-update-test-status.service';
import { ImageTabChangeSCMComponent } from '../product/image-tab-change-scm/image-tab-change-scm.component';
import { ImageTabChangeSCMService } from '../product/image-tab-change-scm/image-tab-change-scm.service';
import { TestLeadStatusComponent } from './test-lead-status/test-lead-status.component';
import { UpdateWWANTTSStatusComponent } from '../product/update-wwan-tts-status/update-wwan-tts-status.component';
import { UpdateWWANTTSStatusService } from '../product/update-wwan-tts-status/update-wwan-tts-status.service';
import { VersionPropertiesUpdateEOLDateComponent } from '../product/version-properties-eol-update/version-properties-update-eol-date.component';
import { QualStatusComponent } from './qual-status/qual-status.component';
import { ViewLeadProductExclusionService } from './view-lead-product-exclusions/view-lead-product-exclusions.service';
import { LeadProductExclusionComponent } from './lead-product-exclusion-main/lead-product-exclusion-main.component';
import { LeadProductExclusionService } from './lead-product-exclusion-main/lead-product-exclusion-main.service';
import { AdvancedSupportComponent } from './advanced-support/advanced-support.component'
import { AdvancedSupportService } from './advanced-support/advanced-support.service'
import { ProductSupportedComponent } from './update-supported-products/product-supported.component';
import { ProductSupportedService } from './update-supported-products/product-supported.service';
import { MultiEOLDateComponent } from './multi-eol-date/multi-eol-date.component';
import { ScheduleComponent } from './schedule/milestone-plan-schedule-update.component';
import { DevRejectProductRequestComponent } from './dev_product_reject_request/dev-reject-product-request.component';

import { UpdateDeliverableStatusComponent } from '../product/update-deliverable-status/update-deliverable-status.component';
import { UpdateDeliverableStatusService } from '../product/update-deliverable-status/update-deliverable-status.service';
import { AccessoryStatusPulsarComponent } from './accessory-status-main-pulsar/accessory-status-main-pulsar.component'
import { AccessoryStatusPulsarService } from './accessory-status-main-pulsar/accessory-status-main-pulsar.service'
import { ActionService } from './action/action.service';
import { UpdateDeveloperApprovalComponent } from '../product/update-developer-approval/update-developer-approval.component';
import { UpdateDeveloperApprovalService } from '../product/update-developer-approval/update-developer-approval.service';
import { DeliverableComparisonComponent } from '../product/deliverable-comparison/deliverable-comparison.component';
import { DeliverableComparisonService } from '../product/deliverable-comparison/deliverable-comparison.service';


import { ViewExceptionsComponent } from './view-exceptions/view-exceptions.component';
import { ViewExceptionsService } from './view-exceptions/view-exceptions.service';
import { AccessoryStatusComponent } from './accessory-status-main/accessory-status-main.component';
import { AccessoryStatusService } from './accessory-status-main/accessory-status-main.service';
import { UpdateOrProductQualificationComponent } from '../product/update-or-product-qualification/update-or-product-qualification.component';
import { UpdateOrProductQualificationservice } from '../product/update-or-product-qualification/update-or-product-qualification.service';
import { TestLeadStatusPulsarComponent } from './test-status-pulsar/test-lead-status.component';
import { UpdateOrProductQualificationPulsarComponent } from '../product/update-or-product-qualification-pulsar/update-or-product-qualification-pulsar.component';
import { UpdateOrProductQualificationPulsarservice } from '../product/update-or-product-qualification-pulsar/update-or-product-qualification-pulsar.service';

import { TargetAdvancedComponent } from './target-advanced/target-advanced.component'
import { TargetAdvancedService } from './target-advanced/target-advanced.service'

import { ReleaseComponent } from './release/release.component';
import { ReleaseService } from './release/release.service';

import { ProgramsComponent } from './programs/programs.component';

import { SchedulePulsarComponent } from './schedule-pulsar/schedule-pulsar.component';

import { RejectFeatureRequestComponent } from './reject-feature-request/reject-feature-request.component';
import { RejectFeatureRequestService } from './reject-feature-request/reject-feature-request.service';

import { pdmfeedbackupdatecomponent } from './pdm-feedback-update/pdm-feedback-update.component';
import { ScheduleMainComponent } from './schedule-main/schedule.component';

export const productRoutes: Routes = [
    { path: 'editexceptions/:productID/:versionID', component: EditExceptionComponent, outlet: 'externalpopupWindow' },
    { path: 'programproperties/:id', component: ProgramsPropertyComponent, outlet: 'externalpopupWindow' },
    { path: 'dcrworkflowupdate/:historyId/:dcrId/:pvId/:milestoneComplete', component: DCRWorkflowChangeRequestComponent, outlet: 'externalpopupWindow' },
    { path: 'workinglistreorder/:id/:projectId/:reportOption', component: WorkingListReorderComponent, outlet: 'externalpopupWindow' },
    { path: 'irscomponentupdate', component: IRSComponentUpdateProductComponent },
    { path: 'leadproductexclusion/:id', component: ViewLeadProductExclusionComponent, outlet: 'externalpopupWindow' },
    // { path: 'action', component: ActionComponent, outlet: 'externalpopupWindow' },
    { path: 'pilotstatus/:productID/:versionID', component: PilotStatusComponent, outlet: 'externalpopupWindow' },
    { path: 'pilotstatuspulsar/:productID/:versionID/:productDeliverableReleaseID/:productDeliverableID', component: PilotStatusPulsarComponent, outlet: 'externalpopupWindow' },
    { path: 'avnotofeature/:avCreateID/:featureId/:featureName/:productBrandId/:scmCategoryId/:productVersionID', component: AvNoToFeatureComponent, outlet: 'externalpopupWindow' },
    { path: 'rootleadproduct/:rootId/:id/:fusionRequirement', component: RootOnLeadProductComponent, outlet: 'externalpopupWindow' },
    { path: 'multiupdatetest/:idList/:index/:Type', component: MultiUpdateTestStatusComponent, outlet: 'externalpopupWindow' },
    { path: 'imagetabchangescm/:imageActionItemID/:actionType/:userId/:productVersionID', component: ImageTabChangeSCMComponent, outlet: 'externalpopupWindow' },
    { path: 'testleadstatus/:versionID/:productID/:fieldID', component: TestLeadStatusComponent, outlet: 'externalpopupWindow' },
    { path: 'updatewwanttsstatus/:id', component: UpdateWWANTTSStatusComponent, outlet: 'externalpopupWindow' },
    { path: 'updateoldate/:TypeID/:strIDs', component: VersionPropertiesUpdateEOLDateComponent, outlet: 'externalpopupWindow' },
    { path: 'qualstatus/:productID/:versionID/:relaseId/:ispulsarproduct/:todayPageSection', component: QualStatusComponent, outlet: 'externalpopupWindow' },
    { path: 'leadproductexclusionmain/:productId/:rootId/:versionIdList/:isFusionRequirements', component: LeadProductExclusionComponent, outlet: 'externalpopupWindow' },
    { path: 'advancedsupport/:prodRootId/:rootId/:productDeliverableReleaseId/:rowId/:productId', component: AdvancedSupportComponent, outlet: 'externalpopupWindow' },
    { path: 'updateproductsupported/:versionId', component: ProductSupportedComponent, outlet: 'externalpopupWindow' },
    { path: 'updatedeliverablestatus/:id/:statusID/:typeID', component: UpdateDeliverableStatusComponent, outlet: 'externalpopupWindow' },
    { path: 'multieoldate/:TypeID/:strIDs', component: MultiEOLDateComponent, outlet: 'externalpopupWindow' },
    { path: 'schedule/:versionId', component: ScheduleComponent, outlet: 'externalpopupWindow' },
    { path: 'devrejectproduct/:NewValue/:ID', component: DevRejectProductRequestComponent, outlet: 'externalpopupWindow' },
    { path: 'accessorystatuspulsar/:id/:productId/:deliverableId/:releaseId/:todayPageSection', component: AccessoryStatusPulsarComponent, outlet: 'externalpopupWindow' },
    { path: 'action/:appErrorId/:id/:working/:prodId/:type/:roadMapId/:ticketNumber/:component', component: ActionComponent, outlet: 'externalpopupWindow' },
    { path: 'updatedeveloperapproval/:strValue/:idList/:idListForUpdate', component: UpdateDeveloperApprovalComponent, outlet: 'externalpopupWindow' },
    { path: 'deliverablecomparison/:rootID/:prodID', component: DeliverableComparisonComponent, outlet: 'externalpopupWindow' },
    { path: 'viewExceptions/:id', component: ViewExceptionsComponent, outlet: 'externalpopupWindow' },
    { path: 'accessoryStatus/:productId/:versionId', component: AccessoryStatusComponent, outlet: 'externalpopupWindow' },
    { path: 'updateorproductqualification/:productId/:versionId', component: UpdateOrProductQualificationComponent, outlet: 'externalpopupWindow' },
    { path: 'testleadstatuspulsar/:FieldID/:VersionID/:ProductID/:ReleaseID/:RowID/:TodayPageSection', component: TestLeadStatusPulsarComponent, outlet: 'externalpopupWindow' },
    { path: 'targetadvanced/:productId/:rootId/:versionId', component: TargetAdvancedComponent, outlet: 'externalpopupWindow' },
    { path: 'release/:idList/:strFunction', component: ReleaseComponent, outlet: 'externalpopupWindow' },
    { path: 'updateorproductqualification/:productId/:versionId', component: UpdateOrProductQualificationComponent, outlet: 'externalpopupWindow' },
    { path: 'updateorproductqualificationpulsar/:chkIDs/:productId/:rootId/:versionId/:bsId/:showOnlyTargetedRelease', component: UpdateOrProductQualificationPulsarComponent, outlet: 'externalpopupWindow' },
    { path: 'programs/:id/:commodity/:HWPM/:factoryEngineer/:accessory/:clone/:tab/:pulsar', component: ProgramsComponent, outlet: 'externalpopupWindow' },
    { path: 'schedulepulsar/:id/:pvId/:scheduleId/:prodVId', component: SchedulePulsarComponent, outlet: 'externalpopupWindow' },
    { path: 'rejectfeature/:featureId', component: RejectFeatureRequestComponent, outlet: 'externalpopupWindow' },
    { path: 'pdmfeedbackupdatecomponent/:AvActionItemID/:updateItemsNumber/:alertMessage/:txtPDMFeedback', component: pdmfeedbackupdatecomponent, outlet: 'externalpopupWindow' },
    { path: 'schedulemain/:id/:pvId/:scheduleId/:prodVId', component: ScheduleMainComponent, outlet: 'externalpopupWindow'},
    { path: 'editexceptionspulsar2/:productID/:versionID', component: EditExceptionComponent},
    { path: 'programpropertiespulsar2/:id', component: ProgramsPropertyComponent},
    { path: 'dcrworkflowupdatepulsar2/:historyId/:dcrId/:pvId/:milestoneComplete', component: DCRWorkflowChangeRequestComponent},
    { path: 'workinglistreorderpulsar2/:id/:projectId/:reportOption', component: WorkingListReorderComponent},
    { path: 'leadproductexclusionpulsar2/:id', component: ViewLeadProductExclusionComponent},
    // { path: 'action', component: ActionComponent, outlet: 'externalpopupWindow' },
    { path: 'pilotstatuspulsar2/:productID/:versionID', component: PilotStatusComponent},
    { path: 'pilotstatuspulsarpulsar2/:productID/:versionID/:productDeliverableReleaseID/:productDeliverableID', component: PilotStatusPulsarComponent},
    { path: 'avnotofeaturepulsar2/:avCreateID/:featureId/:featureName/:productBrandId/:scmCategoryId/:productVersionID', component: AvNoToFeatureComponent},
    { path: 'rootleadproductpulsar2/:rootId/:id/:fusionRequirement', component: RootOnLeadProductComponent},
    { path: 'multiupdatetestpulsar2/:idList/:index/:Type', component: MultiUpdateTestStatusComponent},
    { path: 'imagetabchangescmpulsar2/:imageActionItemID/:actionType/:userId/:productVersionID', component: ImageTabChangeSCMComponent},
    { path: 'testleadstatuspulsar2/:versionID/:productID/:fieldID', component: TestLeadStatusComponent},
    { path: 'updatewwanttsstatuspulsar2/:id', component: UpdateWWANTTSStatusComponent},
    { path: 'updateoldatepulsar2/:TypeID/:strIDs', component: VersionPropertiesUpdateEOLDateComponent},
    { path: 'qualstatuspulsar2/:productID/:versionID/:relaseId/:ispulsarproduct/:todayPageSection', component: QualStatusComponent},
    { path: 'leadproductexclusionmainpulsar2/:productId/:rootId/:versionIdList/:isFusionRequirements', component: LeadProductExclusionComponent},
    { path: 'advancedsupportpulsar2/:prodRootId/:rootId/:productDeliverableReleaseId/:rowId/:productId', component: AdvancedSupportComponent},
    { path: 'updateproductsupportedpulsar2/:versionId', component: ProductSupportedComponent},
    { path: 'updatedeliverablestatuspulsar2/:id/:statusID/:typeID', component: UpdateDeliverableStatusComponent},
    { path: 'multieoldatepulsar2/:TypeID/:strIDs', component: MultiEOLDateComponent},
    { path: 'schedulepulsar2/:versionId', component: ScheduleComponent},
    { path: 'devrejectproductpulsar2/:NewValue/:ID', component: DevRejectProductRequestComponent},
    { path: 'accessorystatuspulsarpulsar2/:id/:productId/:deliverableId/:releaseId/:todayPageSection', component: AccessoryStatusPulsarComponent},
    { path: 'actionpulsar2/:appErrorId/:id/:working/:prodId/:type/:roadMapId/:ticketNumber/:component', component: ActionComponent},
    { path: 'updatedeveloperapprovalpulsar2/:strValue/:idList/:idListForUpdate', component: UpdateDeveloperApprovalComponent},
    { path: 'deliverablecomparisonpulsar2/:rootID/:prodID', component: DeliverableComparisonComponent},
    { path: 'viewExceptionspulsar2/:id', component: ViewExceptionsComponent},
    { path: 'accessoryStatuspulsar2/:productId/:versionId', component: AccessoryStatusComponent},
    { path: 'updateorproductqualificationpulsar2/:productId/:versionId', component: UpdateOrProductQualificationComponent},
    { path: 'testleadstatuspulsarpulsar2/:FieldID/:VersionID/:ProductID/:ReleaseID/:RowID/:TodayPageSection', component: TestLeadStatusPulsarComponent},
    { path: 'targetadvancedpulsar2/:productId/:rootId/:versionId', component: TargetAdvancedComponent},
    { path: 'releasepulsar2/:idList/:strFunction', component: ReleaseComponent},
    { path: 'updateorproductqualificationpulsar2/:productId/:versionId', component: UpdateOrProductQualificationComponent},
    { path: 'updateorproductqualificationpulsarpulsar2/:chkIDs/:productId/:rootId/:versionId/:bsId/:showOnlyTargetedRelease', component: UpdateOrProductQualificationPulsarComponent},
    { path: 'programspulsar2/:id/:commodity/:HWPM/:factoryEngineer/:accessory/:clone/:tab/:pulsar', component: ProgramsComponent},
    { path: 'schedulepulsarpulsar2/:id/:pvId/:scheduleId/:prodVId', component: SchedulePulsarComponent},
    { path: 'rejectfeaturepulsar2/:featureId', component: RejectFeatureRequestComponent},
    { path: 'pdmfeedbackupdatecomponentpulsar2/:AvActionItemID/:updateItemsNumber/:alertMessage/:txtPDMFeedback', component: pdmfeedbackupdatecomponent},
    { path: 'schedulemainpulsar2/:id/:pvId/:scheduleId/:prodVId', component: ScheduleMainComponent},
];

//Declare all the components created for product module
export const productComponents = [
    EditExceptionComponent, ProgramsPropertyComponent, DCRWorkflowChangeRequestComponent, WorkingListReorderComponent, IRSComponentUpdateProductComponent,
    ViewLeadProductExclusionComponent, ActionComponent, PilotStatusComponent, PilotStatusPulsarComponent, AvNoToFeatureComponent, RootOnLeadProductComponent, MultiUpdateTestStatusComponent,
    ImageTabChangeSCMComponent, TestLeadStatusComponent, UpdateWWANTTSStatusComponent, VersionPropertiesUpdateEOLDateComponent, QualStatusComponent, LeadProductExclusionComponent, AdvancedSupportComponent, ProductSupportedComponent, UpdateDeliverableStatusComponent,
    MultiEOLDateComponent, ScheduleComponent, DevRejectProductRequestComponent, AccessoryStatusPulsarComponent, UpdateDeveloperApprovalComponent, DeliverableComparisonComponent, ViewExceptionsComponent, AccessoryStatusComponent, UpdateOrProductQualificationComponent,
    TestLeadStatusPulsarComponent, TargetAdvancedComponent, ReleaseComponent, UpdateOrProductQualificationPulsarComponent, ProgramsComponent, SchedulePulsarComponent, RejectFeatureRequestComponent, pdmfeedbackupdatecomponent, ScheduleMainComponent
];

//Providers that needs to be shared across multiple components/modules can be declared here. Otherwise declare providers inside respective components
export const productProviders = [
    PilotStatusService, PilotStatusPulsarService, MultiUpdateTestStatusService, ImageTabChangeSCMService, UpdateWWANTTSStatusService, ViewLeadProductExclusionService, LeadProductExclusionService, AdvancedSupportService, ProductSupportedService,
    UpdateDeliverableStatusService, AccessoryStatusPulsarService, ActionService, UpdateDeveloperApprovalService, DeliverableComparisonService, ViewExceptionsService, AccessoryStatusService, UpdateOrProductQualificationservice, TargetAdvancedService, ReleaseService, UpdateOrProductQualificationPulsarservice
];
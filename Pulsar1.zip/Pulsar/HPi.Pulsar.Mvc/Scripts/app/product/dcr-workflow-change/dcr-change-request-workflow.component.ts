﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08/28/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-change-request-workflow.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';

import { DCRWorkflowChangeRequestService } from './dcr-change-request-workflow.service';
import { DCRWorkflowChangeRequestViewModel } from './dcr-change-request-workflow.viewmodel';

@Component({
    selector: 'dcr-workflow-change-request',
    templateUrl: './dcr-change-request-workflow.component.html',
    providers: [DCRWorkflowChangeRequestService]
})
export class DCRWorkflowChangeRequestComponent implements OnInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    dcrWorkflowChangeRequestViewModel: DCRWorkflowChangeRequestViewModel;
    dcrId: number;
    pvId: number;
    historyId: number;
    milestoneComplete: any;
    createdBy: any;
    dateCreated: any;
    workflowType: any;
    labelHeader: any;

    constructor(private dcrWorkflowChangeRequestService: DCRWorkflowChangeRequestService, private route: ActivatedRoute, private router: Router) {
        this.dcrWorkflowChangeRequestViewModel = new DCRWorkflowChangeRequestViewModel();
        this.historyId = route.snapshot.params['historyId'];
        this.dcrId = route.snapshot.params['dcrId'];
        this.pvId = route.snapshot.params['pvId'];
        this.milestoneComplete = route.snapshot.params['milestoneComplete'];

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.settings.pageable = false;
        this.jqxGridConfig.datafields = [
            { name: 'milestone', map: 'milestone', type: 'string' },
            { name: 'status', map: 'status', type: 'string' },
            { name: 'assignedTo', map: 'assignedTo', type: 'string' },
            { name: 'comments', map: 'comments', type: 'string' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'Milestone', columngroup: 'DCRWorkflowStatus',
                datafield: 'milestone', width: '20%', filtertype: 'input'
            },
            {
                text: 'Status', columngroup: 'DCRWorkflowStatus',
                datafield: 'status', width: '20%', filtertype: 'input'
            },
            {
                text: 'Assigned To', columngroup: 'DCRWorkflowStatus',
                datafield: 'assignedTo', width: '20%', filtertype: 'input'
            },
            {
                text: 'Comments', columngroup: 'DCRWorkflowStatus',
                datafield: 'comments', width: '40%', filtertype: 'input'
            }
        ];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getDcrWorkflowStatus();
    }

    getDcrWorkflowStatus() {
        this.myGrid.showdefaultloadelement(true);
        this.dcrWorkflowChangeRequestService.getDcrWorkflowStatus(this.dcrId, this.milestoneComplete, this.pvId).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            if (result.json().length > 0) {
                this.createdBy = result.json()[0]['createdBy'];
                this.dateCreated = result.json()[0]['dateCreated'];
                this.workflowType = result.json()[0]['workflowType'];
                this.labelHeader = result.json()[0]['labelHeader'];
            }
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    cmdComplete_onclick(): void {
        var comments = "";
        if ((<HTMLInputElement>document.getElementById("txtComments")).value != "") {
            comments = (<HTMLInputElement>document.getElementById("txtComments")).value;
        }
        this.dcrWorkflowChangeRequestService.updateDcrWorkflowChangeRequest(this.historyId, comments, this.dcrId, this.pvId).subscribe(result => {
            popupCallBack(1); 
            closePopup('externalpagepopup');
            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        });
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08-28-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-change-request-workflow.viewmodel.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class DCRWorkflowChangeRequestViewModel {
    labelHeader: string;
    workflowType: string;
    dateCreated: Date;
    createdBy: string;
    milestone: string;
    status: string;
    assignedTo: string;
    comments: string;
    emailList: string;
    product: boolean;
    summary: string;
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08-28-2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 11-27-2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-change-request-workflow.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { DCRWorkflowChangeRequestViewModel } from './dcr-change-request-workflow.viewmodel';

@Injectable()
export class DCRWorkflowChangeRequestService {

    constructor(private http: Http, private location: Location) {
    }

    getDcrWorkflowStatus(dcrId: any, milestoneComplete: any, pvId: any): Observable<Response>  {
        return this.http.get(this.location.prepareExternalUrl('/product/DCRWorkflowDefinitions/GetDCRWorkflowStatus/' + dcrId + '/' + pvId + '/' + milestoneComplete));
    }

    updateDcrWorkflowChangeRequest(historyId: number, comments: string, dcrId: number, pvId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/DCRWorkflowDefinitions/UpdateDCRWorkflowComments/' + historyId + '/' + comments + '/' + dcrId + '/' + pvId));
    }
}
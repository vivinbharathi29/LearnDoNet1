﻿import { Component, OnInit, Input } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { ProductSupportedService } from './product-supported.service';
import { ProductSupportedViewModel } from './product-supported-view-model.model';
import { CustomValidationService } from '../../shared/custom-validation.service';

@Component({
    selector: 'product-supported',
    templateUrl: './product-supported.component.html',
    providers: [ProductSupportedService]
})
export class ProductSupportedComponent implements OnInit {

    productSupportedForm: FormGroup;
    productSupportedViewModel: ProductSupportedViewModel;
    errorMessage: string = "";
    productName: string = "";
    vendorName: string = "";
    deliverableName: any;
    versionId: any;
    versionName: any;
    stringProductSupported: any;
    modelNumber: any;
    partNumber: any;
    headerRow: any;
    stringProductsLoaded: any;
    rootId: any;
    blnError: boolean;
    selectedValues = [];
    constructor(private formBuilder: FormBuilder, private productSupportedService: ProductSupportedService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = "";
       // this.buildForm();
        this.productSupportedViewModel = new ProductSupportedViewModel();
        this.productSupportedViewModel.versionId = route.snapshot.params['versionId'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.productSupportedService.updateSupportedProducts(this.productSupportedViewModel.versionId).subscribe(
            data => {
                this.productSupportedViewModel = data.json();
                console.log(this.productSupportedViewModel);
                this.deliverableName = this.productSupportedViewModel.deliverableName;
                this.stringProductSupported = this.productSupportedViewModel.stringProductSupported;
                this.headerRow = this.productSupportedViewModel.headerRow;
                this.modelNumber = this.productSupportedViewModel.modelNumber;
                this.partNumber = this.productSupportedViewModel.partNumber;
                this.versionId = this.productSupportedViewModel.versionId;
                this.vendorName = this.productSupportedViewModel.vendorName;
                this.versionName = this.productSupportedViewModel.versionName;
                this.rootId = this.productSupportedViewModel.rootId;
                this.stringProductsLoaded = this.productSupportedViewModel.stringProductsLoaded
              
            }
        );
    }

    buildForm(): void {
        this.productSupportedForm = this.formBuilder.group({
            versionId: "",
            rootId: "",
            stringProductsLoaded:""
        });
    }
    public isError: boolean = false;
    public ErrorMessage: string[]

    addProductSupported() {
        this.ErrorMessage = [];
        this.isError = false;

        var chk_arr = <HTMLCollection>document.getElementsByClassName("chkSupport");
        
        for (var i = 0; i < chk_arr.length; i++) {
            if ((<HTMLInputElement>chk_arr[i]).checked === true) {
                this.selectedValues.push((<HTMLInputElement>chk_arr[i]).value);
            }
        }

        
            this.productSupportedViewModel = new ProductSupportedViewModel();
            this.productSupportedViewModel.versionId = this.versionId;
            this.productSupportedViewModel.stringProductsLoaded = this.stringProductsLoaded;
            this.productSupportedViewModel.selectedValues = this.selectedValues;
            this.productSupportedService.saveSupportedProducts(this.productSupportedViewModel).subscribe(
                (data) => {
                    var success = data.json();
                    if (success) {
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                        popupCallBack(1);
                        closePopup('externalpagepopup');
                    }
                    else {
                        //this.errorMessage = "Unable to update supported products.";
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                        closePopup('externalpagepopup');
                    }
                },
                Error => {
                    console.log('Failed', Error);
                    this.blnError = true;
                    this.ErrorMessage.push("Unable to update supported products.");
                }
            );;
        //}
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
}

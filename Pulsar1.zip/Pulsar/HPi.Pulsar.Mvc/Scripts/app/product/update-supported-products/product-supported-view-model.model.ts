// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 10/09/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="product-supported-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class ProductSupportedViewModel
{
	deliverableName : string;
	vendorName : string;
	versionName : string;
	modelNumber : string;
	partNumber : string;
	productId : number;
	rootId : number;
    vendorId: number;
    versionId: number;
	versionCount : number;
    stringProductSupported: string;
    headerRow: string;
    stringProductsLoaded: string;
    selectedValues: any;
}
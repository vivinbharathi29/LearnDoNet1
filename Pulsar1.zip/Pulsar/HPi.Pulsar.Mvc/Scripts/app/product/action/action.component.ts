﻿import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { FormsModule, FormBuilder, Validators, ReactiveFormsModule, Form, NgForm, NgControl, FormArray, NgModel, FormGroup, FormControl } from '@angular/forms';
import { ActionService } from './action.service'
import { SupportTicketViewModel } from './action.viewmodel'
import { CustomValidationService } from '../../shared/custom-validation.service'
import { ActivatedRoute, NavigationExtras, Params, Router } from '@angular/router';
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
@Component({
    selector: 'action',
    templateUrl: './action.component.html',
})

export class ActionComponent implements OnInit {
    public fullImagePath = 'images/demo_wait.gif';
    id: number;
    //public supportTicketViewModel: SupportTicketViewModel;
    actionInfoForm: FormGroup;
    errorMessage: string;
    actionViewModel: any;
    notifyEmailIds: string;
    TestClear: string = ''
    ownerId: any;
    submitterId: any;
    totalNoOfOwner: any;
    totalNoOfSubmitter: any;
    public ownerTitle: string = "Select Owner";
    public ownerUrl: string = "/core/User/ChooseEmployee?dialogType=20";
    public submitterTitle: string = "Select Submitter";
    public submitterUrl: string = "/core/User/ChooseEmployee?dialogType=21";
    constructor(http: Http, private service: ActionService, private fb: FormBuilder, private customValidationService: CustomValidationService, private ngZone: NgZone, private activatedRoute: ActivatedRoute, private router: Router, private location: Location) {

        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            ShowArtileListCallBackFn: (value) => this.showArticleListCallBack(value),
            updateEmailsPopUpCallBackFn: (value) => this.updateEmailsPopUpCallBackFn(value),
            ActionPageCallBackFn: (id, name, pageName) => this.actionCallBack(id, name, pageName),
            component: this
        };
        console.log(2);

        this.actionInfoForm = this.fb.group({
            "ID": [],
            "Summary": [''],
            "Resolution": [''],
            "Details": [''],
            "OwnerID": [''],
            "ProjectID": [''],
            "StatusID": [''],
            "SubmitterID": [''],
            "RoadMapID": [''],
            "IsCopyMe": [''],
            "IsCopySubmitter": [''],
            "Priority": [''],
            "DisplayOrder": [0],
            "Duration": [0],
            "TargetDate": [''],
            "StatusNotes": [''],
            "SponsorID": [''],
            "IsReviewInput": [''],
            "IsWorking": [''],
            "EmailNote": [''],
            "Notify": [''],
            "DefaultNotify": [''],
            "Type": [''],
            "TicketID": [''],
            "AppErrorID":['']
        });
    }
    productVersionId: any;
    actionCallBack(id, name, pageName) {
        if (pageName == "Select Owner") {
            $('input[type=hidden][id=OwnerID]').val(id);//Assign text
            $('input[type=text][id=OwnerName]').val(name);
        }
        else {
            $('input[type=hidden][id=SubmitterID]').val(id);
            $('input[type=text][id=SubmitterName]').val(name);
        }
    }
    ticketNumber: any;
    appErrorId: any;
    getWorkingListAction() {
        this.appErrorId = this.activatedRoute.snapshot.params['appErrorId'];
        var id = this.activatedRoute.snapshot.params['id'];
        var working = this.activatedRoute.snapshot.params['working'];
        var typeId = this.activatedRoute.snapshot.params['type'];
        var productId = this.activatedRoute.snapshot.params['prodId'];
        var roadMapId = this.activatedRoute.snapshot.params['roadMapId'];
        this.ticketNumber = this.activatedRoute.snapshot.params['ticketNumber'];
        console.log(1);
        $("#waitLoad").css("display", "block");
        $('body').css('pointer-events', 'none');
        this.service.getWorkingListAction(productId, id, typeId, this.appErrorId, working, roadMapId, this.ticketNumber).subscribe(result => {
            this.actionViewModel = result.json();
            this.actionViewModel.statusID = this.actionViewModel.statusID == null ? 0 : this.actionViewModel.statusID;//Null Checked
            this.actionViewModel.priority = this.actionViewModel.priority == null ? 0 : this.actionViewModel.priority;//Null Checked
            this.ownerId = result.json().ownerID;
            this.submitterId = result.json().submitterID;
            this.actionSponsorId = result.json().sponsorID;
            this.ownerUrl = this.location.prepareExternalUrl("/core/User/ChooseEmployee?dialogType=20&ownerId=" + this.ownerId + "&id=" + this.id);
            this.submitterUrl = this.location.prepareExternalUrl("/core/User/ChooseEmployee?dialogType=21&ownerId=" + this.ownerId + "&id=" + this.id);
            //this.totalNoOfOwner = result.json().ownerViewModel != undefined && result.json().ownerViewModel != null ? result.json().ownerViewModel[0].totalNoOfRows:0;
            //this.totalNoOfSubmitter = result.json().submitterViewModel != undefined && result.json().submitterViewModel != null ? result.json().submitterViewModel[0].totalNoOfRows:0;
            this.productVersionId = result.json().productVersionID;
            this.actionRoadMapViewModel = this.actionViewModel.actionRoadMapViewModel;
            if (result.json().ownerID == null || result.json().ownerID == 0) {
                this.actionViewModel.ownerName = result.json().currentUserName;
                this.actionViewModel.ownerID = result.json().currentUserId;
            }
            if (result.json().submmitterID == null || result.json().submmitterID == 0) {
                this.actionViewModel.submitter = result.json().currentUserName;
                this.actionViewModel.submitterID = result.json().currentUserId;
            }
            var sponsorId  = this.actionViewModel.sponsorID == null ? 0 : this.actionViewModel.sponsorID;
            this.actionInfoForm = this.fb.group({
                "ID": [this.actionViewModel.id],
                "Summary": [this.actionViewModel.summary],
                "Resolution": [this.actionViewModel.resolution],
                "Details": [this.actionViewModel.details],
                "OwnerID": [this.actionViewModel.ownerID],
                "ProjectID": [this.actionViewModel.productVersionID],
                "StatusID": [this.actionViewModel.statusID],
                "RoadMapID": [this.actionViewModel.roadMapID],
                "IsCopyMe": [this.actionViewModel.isCopyMe],
                "IsCopySubmitter": [this.actionViewModel.isCopySubmitter],
                "SubmitterID": [this.actionViewModel.submitterID],
                "Priority": [this.actionViewModel.priority],
                "DisplayOrder": [this.actionViewModel.displayOrder],
                "Duration": [this.actionViewModel.duration],
                "TargetDate": [this.actionViewModel.targetDate],
                //"StatusNotesUpdatedDt": [this.actionViewModel.statusNotesUpdatedDt],
                //"OriginalTargetDt": [this.actionViewModel.originalTargetDt],
                "StatusNotes": [this.actionViewModel.statusNotes],
                "SponsorID": [sponsorId],
                "IsReviewInput": [this.actionViewModel.isReviewInput],
                "IsWorking": [this.actionViewModel.isWorking],
                "EmailNote": [''],
                "Notify": [this.actionViewModel.notify],
                "DefaultNotify": [this.actionViewModel.defaultNotify],
                "Type": [this.actionViewModel.type],
                "TicketID": [this.ticketNumber],
                "AppErrorID":[this.appErrorId]

            });
            this.actionInfoForm.updateValueAndValidity();
            this.service.getAllProductGroups(this.productVersionId).subscribe(result => {
                var productGroups = result.json();
                for (let productGroup of productGroups) {
                    var selectedGroup = productGroup.selected != null ? productGroup.selected : '';
                    $('select[id=ProjectID]').append('<option ' + selectedGroup + ' value=' + productGroup.productVersionID + '>' + productGroup.name + '</option>');
                }
                for (let item of this.actionViewModel.actionStatusesViewModel) {
                    if ((this.actionViewModel.statusID == item.id || (this.actionViewModel.statusID == null || item.id == 1))) {
                        $('select[id=StatusID]').append('<option value=' + item.id + ' selected>' + item.name + '</option>');
                    }
                    else {
                        $('select[id=StatusID]').append('<option value=' + item.id + '>' + item.name + '</option>');
                    }
                } 
                $("#waitLoad").css("display", "none");
                $('body').css('pointer-events', 'All');
            });

        });
    }

    actionSponsorId: any=null;
    ngAfterViewInit(): void{

    }
    public isError: boolean = false;
    public ErrorMessage: string[]
    SaveAction(actionInfo: FormGroup) {
        this.ErrorMessage = [];
        this.isError = false;
        for (const control in this.actionInfoForm.controls) {
            if (control == "ProjectID" || control == "Priority") {
                if (control == "ProjectID") {
                    if ((<HTMLSelectElement>document.getElementById(control)).selectedIndex == 0 || (<HTMLSelectElement>document.getElementById(control)).selectedIndex == -1) {
                        this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                        this.isError = true;
                    }
                    else if ((<HTMLSelectElement>document.getElementById(control)).value=="0") {
                        this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                        this.isError = true;
                    }
                }
                else if ((<HTMLSelectElement>document.getElementById(control)).selectedIndex == 0 || (<HTMLSelectElement>document.getElementById(control)).selectedIndex == -1) {
                    this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                    this.isError = true;
                }
            }
            else if (control == "OwnerID" || control == "SubmitterID")
            {
                if ((<HTMLInputElement>document.getElementById(control)).value == null || (<HTMLInputElement>document.getElementById(control)).value == "0" || (<HTMLInputElement>document.getElementById(control)).value == undefined) {
                    this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                    this.isError = true;
                }
            }
            else if (control == "Summary") {
                if (this.actionInfoForm.controls[control].value == "") {
                    this.ErrorMessage.push('Summary is Required');
                    this.isError = true;
                }
            }
        }
        var chkCopyMe = <HTMLInputElement>document.getElementById("chkCopyMe");
        var chkCopySubmitter = <HTMLInputElement>document.getElementById("chkCopySubmitter");
        var chkWorking = <HTMLInputElement>document.getElementById("chkWorking");
        var chkReviewInput = <HTMLInputElement>document.getElementById("chkReviewInput");
        var copyMe = chkCopyMe != null && chkCopyMe != undefined ? chkCopyMe.checked : null;
        var copySubmitter = chkCopySubmitter != null && chkCopySubmitter != undefined ? chkCopySubmitter.checked : null;
        var reviewInput = chkReviewInput != null && chkReviewInput != undefined ? chkReviewInput.checked : null;
        var working = chkWorking != null && chkWorking != undefined ? chkWorking.checked : null;
        (<FormGroup>actionInfo)["Type"] = (<HTMLInputElement>document.getElementById("type")).value;
        (<FormGroup>actionInfo)["IsCopyMe"] = copyMe;
        (<FormGroup>actionInfo)["IsCopySubmitter"] = copySubmitter;
        (<FormGroup>actionInfo)["IsReviewInput"] = reviewInput;
        (<FormGroup>actionInfo)["IsWorking"] = working;
        (<FormGroup>actionInfo)["StatusID"] = (<HTMLSelectElement>document.getElementById("StatusID")).value;
        (<FormGroup>actionInfo)["OwnerID"] = (<HTMLInputElement>document.getElementById("OwnerID")).value;
        (<FormGroup>actionInfo)["SubmitterID"] = (<HTMLInputElement>document.getElementById("SubmitterID")).value;
        var component = this.activatedRoute.snapshot.params['component'];
        if (this.isError) {
            popupScrollTop();
        }
        else {
            this.service.UpdateActionInfo(actionInfo).subscribe(result => {
                closePopup('externalpagepopup');
                this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                if (component == 'quicksearch') {
                }
                else if (component == 'ticket') {
                    //popupCallBack(1);
                    MyOpenTicketsCallBack();

                }
                else if (component == 'apperror') {
                    //popupCallBack(1);
                    if (window['angularComponentRef_AppError'] != undefined && window['angularComponentRef_AppError'] != null) {
                        window['angularComponentRef_AppError'].zone.run(
                            function () {
                                window['angularComponentRef_AppError'].popUpCallBackFn(1);
                            });
                    }
                }
                else if (component == 'openiown')
                {
                    if (window['angularComponentRef_IOwn'] != undefined && window['angularComponentRef_IOwn'] != null) {
                        window['angularComponentRef_IOwn'].zone.run(
                            function () {
                                window['angularComponentRef_IOwn'].popUpCallBackFn(1);
                            });
                    }
                }
                else if (component == 'isubmitted') {
                    if (window['angularComponentRef_ISubmitted'] != undefined && window['angularComponentRef_ISubmitted'] != null) {
                        window['angularComponentRef_ISubmitted'].zone.run(
                            function () {
                                window['angularComponentRef_ISubmitted'].popUpCallBackFn(1);
                            });
                    }
                }
                else if (component == 'myworkinglist')
                {
                    if (window['angularComponentRef_Working'] != undefined && window['angularComponentRef_Working'] != null) {
                        window['angularComponentRef_Working'].zone.run(
                            function () {
                                window['angularComponentRef_Working'].popUpCallBackFn(1);
                            });
                    }
                    
                }
                else if (component == 'pastdue') {
                    if (window['angularComponentRef_PastDue'] != undefined && window['angularComponentRef_PastDue'] != null) {
                        window['angularComponentRef_PastDue'].zone.run(
                            function () {
                                window['angularComponentRef_PastDue'].popUpCallBackFn(1);
                            });
                    }

                }
                else {
                    popupCallBack(1);
                }
            });
        }
    }
    ngOnInit(): void {
        this.getWorkingListAction();

    }


    showArticleListCallBack(ArticleIDList) {
        var IDArray;
        var i;
        var strURL;
        var hostName;
        var SubmitterPartnerID = <HTMLInputElement>document.getElementById('SubmitterPartnerID');
        var txtResolution = <HTMLInputElement>document.getElementById('txtResolution');
        if (SubmitterPartnerID.value != "1")
        {
            hostName = window.location.host;
            if (hostName.indexOf("twn") == "-1")
                strURL = "https://prp-pulsar.houston.hp.com/excalibur/";
            else
                strURL = "https://pulsarwebtwn.prp.ext.hp.com/excalibur/";
        }
        else
            //$window.location.host;
           //strURL = "http://pulsarweb.usa.hp.com/Excalibur/";
            //strURL = this.location.path;
            strURL = "http://" + window.location.host + "/Excalibur/";
        if (typeof (ArticleIDList) != "undefined") {
            if (ArticleIDList != "0") {
                IDArray = ArticleIDList.split(",");
                txtResolution.value = txtResolution.value + "\r\r<u>Related Articles</u>\r"
                for (i = 0; i < IDArray.length; i++)
                    txtResolution.value = txtResolution.value + "<a href=\"" + strURL + "Support/Preview.asp?ID=" + IDArray[i] + "\">Article " + IDArray[i] + "</a>\r"

            }
        }
    }
    actionRoadMapViewModel: any;
    LoadRoadMap() {
        var cboProject = <HTMLSelectElement>document.getElementById('ProjectID');
        if (cboProject.selectedIndex != 0) {
            this.service.getRoadMapList(cboProject.options[cboProject.selectedIndex].id).subscribe(result => {
                this.actionRoadMapViewModel = result.json();
            });
        }
        else {

        }
    }
    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
    AddEmail() {
        //var url = "/Excalibur/Email/AddressBook.asp?AddressList=" + $('#txtNotify').value;
        var selectedEmailIds = <HTMLInputElement>document.getElementById('txtNotify');
        var url = this.location.prepareExternalUrl("/core/User/AddressBook?AddressList=" + selectedEmailIds.value + "&pageName=Ticket");
        //adjustableShowPopup(url, 'Add Email Address', "450px", "75%", "365px");
        var windowHeight = "50%";
        var windowWidth = "";
        showPopupThirdLevel(url, 'Add Email Address', windowHeight, windowWidth);
    }
    updateEmailsPopUpCallBackFn(value) {
        this.notifyEmailIds = value;
        //var currentEmailIds = <HTMLInputElement>document.getElementById('txtNotify');
        //var notifyEmailsIds;
        //notifyEmailsIds = this.notifyEmailIds + ';' + currentEmailIds.value;
        //}
        (<HTMLInputElement>document.getElementById('txtNotify')).value = this.notifyEmailIds;
    }
    ViewPopup(url: string, title: string, page: string) {
        var windowHeight = "50%";
        var windowWidth = "";
        showPopupThirdLevel(url, title, windowHeight, windowWidth);
        $('#externalpopup').css("width", '60%');
    }

    //EmployeeScroll(employeeType: any, ctrl: any) {
    //    let itemCount = $(ctrl).find('option') != undefined?$(ctrl).find('option').length - 1:0;
    //    if (employeeType == 'Owner') {
    //        if (itemCount < this.totalNoOfOwner) {
    //            if ($(ctrl).scrollTop() + $(ctrl).innerHeight() >= $(ctrl)[0].scrollHeight) {
    //                this.service.getAllEmployee(employeeType, this.ownerId, this.id, (itemCount / 50)+1, 50).subscribe(result => {
    //                    var employees = result.json();
    //                    for (let emp of employees) {
    //                        $(ctrl).append('<option value=' + emp.Id + '>' + emp.Name + '</option>');
    //                        itemCount = itemCount + 1;
    //                    }
    //                });
    //            }
    //        }
    //    }
    //    else {
    //        if (itemCount < this.totalNoOfSubmitter) {
    //            if ($(ctrl).scrollTop() + $(ctrl).innerHeight() >= $(ctrl)[0].scrollHeight) {
    //                this.service.getAllEmployee(employeeType, this.ownerId, this.id, (itemCount / 50)+1, 50).subscribe(result => {
    //                    var employees = result.json();
    //                    for (let emp of employees) {
    //                        $(ctrl).append('<option value=' + emp.Id + '>' + emp.Name + '</option>');
    //                        itemCount = itemCount + 1;
    //                    }
    //                });
    //            }
    //        }
    //    }
    //}
}
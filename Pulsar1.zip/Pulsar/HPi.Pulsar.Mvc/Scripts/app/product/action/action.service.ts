﻿import { Component, ViewChild, AfterViewInit, NgZone,Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import {SupportTicketViewModel } from './action.viewmodel'
@Injectable()
export class ActionService{
    constructor(private http: Http, private location: Location) {

    }

    getWorkingListAction(productID: any = null, ID: any = null, typeid: any = null, appErrorID: any = null, working: any=0, roadmapID: any = null, ticketID:any=null)
    {
        return this.http.get(this.location.prepareExternalUrl('product/Product/GetWorkingListAction?productId=' + productID + '&Id=' + ID + '&type=' + typeid + '&appErrorId=' + appErrorID + '&working=' + working + '&roadmapId=' + roadmapID + '&ticketId='+ticketID));
    }
    getRoadMapList(ID: any) {
        return this.http.get(this.location.prepareExternalUrl('product/Product/GetActionRoadMapByProductId?productId=' + ID));
    }
    getAllEmployee(employeeType: any,ownerId:number,id:number,pageNo:number,pageSize:number) {
        return this.http.get(this.location.prepareExternalUrl('product/Product/GetAllEmployees?employeeType=' + employeeType + '&ownerId=' + ownerId + '&id=' + id +'&pageNo='+ pageNo + '&pageSize=' + pageSize));
    }

    getAllProductGroups(productVersionId:any) {
        return this.http.get(this.location.prepareExternalUrl('product/Product/GetAllProductGroups?productVersionId=' + productVersionId));
    }

    UpdateActionInfo(actionViewModel) {
       // var supportTicketViewModel = { supportTicketViewModel};
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/UpsertDeliverableActionWeb'), actionViewModel, {
            headers: headers
        });
               
    }

}
﻿export class SupportTicketViewModel
{
    id: number;
    summary: string;
    submitterName: string;
    submitterEmail: string;
    resolution: string;
    details: string;
    attachment1: string;
    attachment2: string;
    attachment3: string;
    fileName1: string;
    fileName2: string;
    fileName3: string;
    ownerID: number;
    ownerName: string;
    projectID: number;
    categoryID: number;
    typeID: number;
    StatusID: number;
    actionItemID: number;
    dateCreated: any;
    dateClosed: any;
    copyMe: boolean;
    copyTeam: boolean;
    supportAdmin: any;
    supportCategory: any;
    supportProjects: any;
    supportIssueType: any;
    supportIssueStatus: any;
}
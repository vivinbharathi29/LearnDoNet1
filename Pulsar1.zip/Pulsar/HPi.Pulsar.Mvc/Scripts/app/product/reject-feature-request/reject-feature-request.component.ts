﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 11/14/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="reject-feature-request.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';

import { RejectFeatureRequestService } from './reject-feature-request.service';

@Component({
    selector: 'reject-feature-request',
    templateUrl: './reject-feature-request.component.html',
    providers: [RejectFeatureRequestService]
})
export class RejectFeatureRequestComponent implements OnInit {
    public featureRoot: any;
    id: any;
    feature: any;
    constructor(private rejectFeatureRequestService: RejectFeatureRequestService, private route: ActivatedRoute, private router: Router) {
        this.id = route.snapshot.params['featureId'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.getFeatureName();
    }

    getFeatureName() {
        this.rejectFeatureRequestService.getFeatureName(this.id).subscribe(result => {
            this.feature = result.json();
        });
    }

    cmdRejectRequest_onclick(): void {
        var comments = (<HTMLInputElement>document.getElementById("txtReason")).value;
        if (comments != "") {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "none";
            let featureRoot = {
                "FeatureId": this.id,
                "WhyRejected": comments
            }
            this.rejectFeatureRequestService.rejectFeatureRequest(featureRoot).subscribe(result => {
                popupCallBack(1);
                closePopup('externalpagepopup');
                this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            });
        }
        else {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "block";
        }
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
}
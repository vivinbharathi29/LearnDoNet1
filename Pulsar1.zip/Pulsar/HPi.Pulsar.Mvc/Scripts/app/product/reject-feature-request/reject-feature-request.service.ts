﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 11-14-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="reject-feature-request.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class RejectFeatureRequestService {

    constructor(private http: Http, private location: Location) {
    }

    getFeatureName(id: any): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetFeatureName/' + id));
    }

    rejectFeatureRequest(featureRoot: any): Observable<Response> {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('product/Product/RejectFeatureRequest'), JSON.stringify(featureRoot), options);
    }
}
﻿import { Component, OnInit, Input } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { EditExceptionService } from './edit-exception.service';
import { EditExceptionViewModel } from './edit-exception-view-model.model';

@Component({
    selector: 'edit-exception',
    templateUrl: './edit-exception.component.html',
    providers: [EditExceptionService]
})
export class EditExceptionComponent implements OnInit {

    editExceptionForm: FormGroup;
    editExceptionViewModel: EditExceptionViewModel;
    errorMessage: string = "";
    productName: string = "";

    constructor(private formBuilder: FormBuilder, private editExceptionService: EditExceptionService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = "";
        this.buildForm();
        this.editExceptionViewModel = new EditExceptionViewModel();
        this.editExceptionViewModel.productId = route.snapshot.params['productID'];
        this.editExceptionViewModel.versionId = route.snapshot.params['versionID'];
    }

    //call services to get value from db.
    ngOnInit(): void {        
        this.editExceptionService.getExceptions(this.editExceptionViewModel.productId, this.editExceptionViewModel.versionId).subscribe(
            data => {
                this.editExceptionViewModel = data.json();
                if (this.editExceptionViewModel.deliverable != "") {
                    this.productName = this.editExceptionViewModel.deliverable;
                }
                if (this.editExceptionViewModel.productName != "") {
                    this.productName = this.productName + " " + "(" + this.editExceptionViewModel.productName + ")";
                }
                this.editExceptionForm.controls["exceptions"].setValue(this.editExceptionViewModel.exceptions);
                this.editExceptionForm.controls["release"].setValue(this.editExceptionViewModel.release);
                this.editExceptionForm.controls["scope"].setValue(String(this.editExceptionViewModel.scope));
                this.editExceptionForm.controls["productId"].setValue(this.editExceptionViewModel.productId);
                this.editExceptionForm.controls["versionId"].setValue(this.editExceptionViewModel.versionId);
                this.editExceptionForm.updateValueAndValidity();
            }
        );
    }

    buildForm(): void {
        this.editExceptionForm = this.formBuilder.group({
            exceptions: "",
            release: false,
            scope: '2',
            productId: 0,
            versionId: 0
        });
    }

    editException(): void {
        this.editExceptionViewModel = new EditExceptionViewModel();
        this.editExceptionViewModel.productId = this.editExceptionForm.value.productId;
        this.editExceptionViewModel.versionId = this.editExceptionForm.value.versionId;
        this.editExceptionViewModel.exceptions = this.editExceptionForm.value.exceptions;
        this.editExceptionViewModel.release = this.editExceptionForm.value.release;
        this.editExceptionViewModel.scope = this.editExceptionForm.value.scope;
        this.editExceptionService.editException(this.editExceptionViewModel).subscribe(
            (data) => {
                var success = data.json();
                if (success) {
                    this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                    closePopup('externalpagepopup');
                    popupCallBack(1);               
                }
                else {
                    this.errorMessage = "Unable to update Exceptions.  An unexpected error occurred.";
                }
            },
            Error => {
                console.log('Failed', Error);
            }
        );
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
}

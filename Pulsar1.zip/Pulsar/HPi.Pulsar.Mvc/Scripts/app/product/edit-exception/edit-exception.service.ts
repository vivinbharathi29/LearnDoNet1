﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay(Nishok S E A)
// Created          : 08/17/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="edit-exception.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { EditExceptionViewModel } from './edit-exception-view-model.model';

@Injectable()
export class EditExceptionService {

    constructor(private http: Http, private location: Location) {
    }

    getExceptions(productId: number, versionId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetException/' + productId + '/' + versionId));
    }

    editException(editExceptionViewModel: EditExceptionViewModel) {
        var headers = new Headers();

        headers.append('Content-Type', 'application/json');
       return this.http.post(this.location.prepareExternalUrl('/product/Product/UpdateException/'), editExceptionViewModel, {
            headers: headers
        });
    }
}
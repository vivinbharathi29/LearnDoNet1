// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 08/21/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="edit-exception-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class EditExceptionViewModel
{
	productId : number;
	versionId : number;
	exceptions : string;
	release : boolean;
	scope : number;
	productName : string;
	deliverable : string;
}
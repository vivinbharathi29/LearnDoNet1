﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay(Nishok S E A)
// Created          : 09/17/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="av-no-to-feature.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { AvNoToFeatureViewModel } from './av-no-to-feature-view-model.model';

@Injectable()
export class AVNoToFeatureService {

    constructor(private http: Http, private location: Location) {
    }

    getAVNoDescription(productVersionId: number, productBrandId: number, scmCategoryId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetAVNoDescription/' + productVersionId + '/' + productBrandId + '/' + scmCategoryId));
    }

    updateAvDetailFeatureID(avNoToFeatureViewModel: AvNoToFeatureViewModel) {
        var headers = new Headers();

        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/UpdateAvDetailFeatureID/'), avNoToFeatureViewModel, {
            headers: headers
        });
    }
}
﻿import { Component, OnInit, Input } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { AVNoToFeatureService } from './av-no-to-feature.service';
import { AvNoToFeatureViewModel } from './av-no-to-feature-view-model.model';
import { AVNoDescriptionViewModel } from './av-no-description-view-model.model';

@Component({
    selector: 'av-no-to-feature',
    templateUrl: './av-no-to-feature.component.html',
    providers: [AVNoToFeatureService]
})
export class AvNoToFeatureComponent implements OnInit {

    avNoToFeatureForm: FormGroup;
    avNoToFeatureViewModel: AvNoToFeatureViewModel;
    avNoDescriptionViewModel: AVNoDescriptionViewModel[];
    errorMessage: string = "";
    featureName: string = "";
    disableSubmit: boolean = false;
    isError: boolean = false;
    errorMessages: string[];

    constructor(private formBuilder: FormBuilder, private avNoToFeatureService: AVNoToFeatureService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = "";
        this.errorMessages = [];
        this.buildForm();
        this.avNoToFeatureViewModel = new AvNoToFeatureViewModel();
        this.avNoToFeatureViewModel.avCreateId = route.snapshot.params['avCreateID'];
        this.avNoToFeatureViewModel.featureId = route.snapshot.params['featureId'];
        this.avNoToFeatureViewModel.featureName = route.snapshot.params['featureName'];
        this.avNoToFeatureViewModel.productBrandId = route.snapshot.params['productBrandId'];
        this.avNoToFeatureViewModel.sCMCategoryId = route.snapshot.params['scmCategoryId'] == "" || route.snapshot.params['scmCategoryId'] == null ? 0 : route.snapshot.params['scmCategoryId'];
        this.avNoToFeatureViewModel.productVersionId = route.snapshot.params['productVersionID'];
        this.featureName = route.snapshot.params['featureName'];
        this.avNoToFeatureForm.controls["avCreateID"].setValue(this.avNoToFeatureViewModel.avCreateId);
        this.avNoToFeatureForm.controls["featureId"].setValue(this.avNoToFeatureViewModel.featureId);
        this.avNoToFeatureForm.controls["featureName"].setValue(String(this.avNoToFeatureViewModel.featureName));
        this.avNoToFeatureForm.controls["productBrandId"].setValue(this.avNoToFeatureViewModel.productBrandId);
        this.avNoToFeatureForm.controls["scmCategoryId"].setValue(this.avNoToFeatureViewModel.sCMCategoryId);
        this.avNoToFeatureForm.controls["productVersionID"].setValue(this.avNoToFeatureViewModel.productVersionId);
        this.avNoToFeatureForm.updateValueAndValidity();
    }

    //call services to get value from db.pulsarsimpleavs
    ngOnInit(): void {

        this.avNoToFeatureService.getAVNoDescription(this.avNoToFeatureViewModel.productVersionId, this.avNoToFeatureViewModel.productBrandId, this.avNoToFeatureViewModel.sCMCategoryId).subscribe(
            data => {
                this.avNoToFeatureViewModel = data.json();
                this.avNoDescriptionViewModel = this.avNoToFeatureViewModel.avNoDescription;
                if (this.avNoToFeatureViewModel.avNoDescription.length <= 0) {
                    this.errorMessage = "The selected Feature's Product, Brand and SCM Category (if applicable) does not have any existing AV No.'s available.";
                    this.disableSubmit = true;
                }
                if (this.avNoToFeatureViewModel.selectedDescription!=null)
                {
                    this.avNoToFeatureForm.controls["selectedDescription"].setValue(this.avNoToFeatureViewModel.selectedDescription);
                }
                this.avNoToFeatureForm.updateValueAndValidity();
            }
        );
    }

    buildForm(): void {
        this.avNoToFeatureForm = this.formBuilder.group({
            avCreateID: 0,
            featureId: 0,
            featureName: '',
            productBrandId: 0,
            scmCategoryId: 0,
            productVersionID: 0,
            selectedDescription: '0',
            userId: 0
        });
    }

    updateAvDetailFeatureID(): void {
        this.errorMessages = [];
        this.isError = false;
        let avNoToFeatureViewModel: AvNoToFeatureViewModel = new AvNoToFeatureViewModel();
        this.avNoToFeatureViewModel.avCreateId = this.avNoToFeatureForm.value.avCreateID;
        this.avNoToFeatureViewModel.featureId = this.avNoToFeatureForm.value.featureId;
        this.avNoToFeatureViewModel.selectedDescription = this.avNoToFeatureForm.value.selectedDescription;
        console.log("selected", this.avNoToFeatureViewModel.selectedDescription);
        //if (this.avNoToFeatureViewModel.selectedDescription == "0" || this.avNoToFeatureViewModel.selectedDescription == null ) {
        //    this.isError = true;
        //    this.errorMessages.push("Av no is required.");
        //}
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            this.avNoToFeatureService.updateAvDetailFeatureID(this.avNoToFeatureViewModel).subscribe(
                (data) => {
                    var success = data.json();
                    if (success) {
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                        popupCallBack(1);
                        closePopup('externalpagepopup');
                    }
                    else {
                        this.errorMessage = "Unable to update Exceptions.  An unexpected error occurred.";
                    }
                },
                Error => {
                    console.log('Failed', Error);
                }
            );
        }
    }

    cancel(): void {
        this.buildForm();
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
}

// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 09/25/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="av-no-description-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class AVNoDescriptionViewModel
{
	avNoGPGDescription : string;
	avNo : string;
}
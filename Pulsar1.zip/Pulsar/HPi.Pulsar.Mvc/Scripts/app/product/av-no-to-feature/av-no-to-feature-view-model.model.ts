
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 09/20/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="av-no-to-feature-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { AVNoDescriptionViewModel } from './av-no-description-view-model.model';

export class AvNoToFeatureViewModel {
    avCreateId: number;
    userId: number;
    featureName: string;
    featureId: number;
    productBrandId: number;
    sCMCategoryId: number;
    productVersionId: number;
    avNoDescription: AVNoDescriptionViewModel[];
    selectedDescription: string;
}
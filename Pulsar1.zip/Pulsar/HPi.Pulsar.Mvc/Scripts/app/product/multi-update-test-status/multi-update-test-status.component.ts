﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R(auth\rajamanr)
// Created          : 09/14/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="irs-component-product-update.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild, AfterViewInit } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';

import { MultiUpdateTestStatusService } from './multi-update-test-status.service';
import { MultiUpdateTestStatusViewModel } from './multi-update-test-status.viewmodel';

@Component({
    selector: 'multi-update-test-status',
    templateUrl: './multi-update-test-status.component.html',
    providers: [MultiUpdateTestStatusService]
})
export class MultiUpdateTestStatusComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    multiUpdateTestStatusViewModel: MultiUpdateTestStatusViewModel;
    multiUpdateTestStatus: any;
    toggle = false;
    typeId: any;
    categoryId: any;
    rootId: any;
    format: any;
    componentTestLead: any;
    constructor(private multiUpdateTestStatusService: MultiUpdateTestStatusService, private route: ActivatedRoute, private router: Router) {
        //this.irsComponentUpdateProductViewModel = new IRSComponentUpdateProductViewModel();

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.settings.pageable = false;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.height = "200px";
        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product', type: 'string' },
            { name: 'deliverableName', map: 'deliverableName', type: 'string' },
            { name: 'version', map: 'version', type: 'string' },
            { name: 'vendor', map: 'vendor', type: 'string' },
            { name: 'modelNumber', map: 'modelNumber', type: 'string' },
            { name: 'partNumber', map: 'partNumber', type: 'string' },
            { name: 'eolDate', map: 'eolDate', type: 'string' },
            { name: 'odmTestStatus', map: 'odmTestStatus', type: 'string' },
            { name: 'integrationTestStatus', map: 'integrationTestStatus', type: 'string' },
            { name: 'wwanTestStatus', map: 'wwanTestStatus', type: 'string' },
            { name: 'productId', map: 'productId', type: 'string' },
            { name: 'versionId', map: 'versionId', type: 'string' },
            { name: 'id', map: 'id', type: 'string' },
            { name: 'productDeliverableReleaseId', map: 'productDeliverableReleaseId', type: 'string' },
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'productId', columngroup: 'multiupdate',
                datafield: 'productId', width: '20%', filtertype: 'input', hidden: true
            },
            {
                text: 'versionId', columngroup: 'multiupdate',
                datafield: 'versionId', width: '20%', filtertype: 'input', hidden: true
            },
            {
                text: 'productDeliverableId', columngroup: 'multiupdate',
                datafield: 'id', width: '20%', filtertype: 'input', hidden: true
            },
            {
                text: 'productDeliverableReleaseId', columngroup: 'multiupdate',
                datafield: 'productDeliverableReleaseId', width: '20%', filtertype: 'input', hidden: true
            },
            {
                text: 'Product', columngroup: 'multiupdate',
                datafield: 'product', width: '20%', filtertype: 'input'
            },
            {
                text: 'Deliverable', columngroup: 'multiupdate',
                datafield: 'deliverableName', width: '20%', filtertype: 'input'
            },
            {
                text: 'Available&nbsp;Until', columngroup: 'multiupdate',
                datafield: 'eolDate', width: '20%', filtertype: 'input'
            },
            {
                text: 'Version', columngroup: 'multiupdate',
                datafield: 'version', width: '20%', filtertype: 'input'
            },
            {
                text: 'Vendor', columngroup: 'multiupdate',
                datafield: 'vendor', width: '20%', filtertype: 'input'
            },

            {
                text: 'Model', columngroup: 'multiupdate',
                datafield: 'modelNumber', width: '20%', filtertype: 'input'
            },
            {
                text: 'Part&nbsp;Number', columngroup: 'multiupdate',
                datafield: 'partNumber', width: '20%', filtertype: 'input'
            },
            ,
            {
                text: 'SE&nbsp;Status', columngroup: 'multiupdate',
                datafield: 'integrationTestStatus', width: '20%', filtertype: 'input', hidden: this.isSETest==true ? false : true
            },
            ,
            {
                text: 'ODM&nbsp;Status', columngroup: 'multiupdate',
                datafield: 'odmTestStatus', width: '20%', filtertype: 'input', hidden: this.isODMTest==true ? false : true
            },
            ,
            {
                text: 'WWAN&nbsp;Status', columngroup: 'multiupdate',
                datafield: 'wwanTestStatus', width: '20%', filtertype: 'input', hidden: this.isWWANTest==true ? false : true
            },
            //{
            //    text: 'EOL', columngroup: 'multiupdate',
            //    datafield: 'eolDate', width: '20%', filtertype: 'input'
            //},
        ];
        this.idList = this.route.snapshot.params['idList'];
    }
    idList: any;
    productId: any;
    versionIds: any;
    ProductDeliverableIds: any;
    ProductReleaseIds: any;
    isSETest: boolean;
    isODMTest: boolean;
    isWWANTest: boolean;
    enableColumn(typeId: any, forWhich: any) {
        let isHidden: boolean = true;
        if (typeId == 1 && forWhich == 1) {
            isHidden = false;
        }
        else if (typeId != 1 && forWhich == 2) {
            isHidden = false;
        }
        else if (forWhich == 3 && this.format == "") {
            isHidden = false;
        }
        return isHidden;
    }

    //call services to get value from db.
    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getMultiUpdateTestStatus();
        $('multi-update-test-status').parent().attr({ 'style': 'overflow-y:auto;max-height:600px;height: !important' });
    }

    getMultiUpdateTestStatus() {
        this.myGrid.showdefaultloadelement(true);
        var componentTestLeadViewModel = new MultiUpdateTestStatusViewModel();
        componentTestLeadViewModel.IdList = this.idList;
        //this.multiUpdateTestStatusService.getUserLeadType().subscribe(result => {
        //    this.isSETest = result.json().isSETestLead;
        //    this.isODMTest = result.json().isODMTestLead;
        //    this.isWWANTest = result.json().isWWANTestLead;
        //});
        this.multiUpdateTestStatusService.getProductDeliverableInfoForComponentTestLead(componentTestLeadViewModel).subscribe(result => {
            this.componentTestLead = result.json();
            this.isSETest = result.json().isSETestLead;
            this.isODMTest = result.json().isODMTestLead;
            this.isWWANTest = result.json().isWWANTestLead;
            this.jqxGridConfig.columns[12].hidden = this.isSETest == true ? false : true;
            this.jqxGridConfig.columns[14].hidden = this.isODMTest == true ? false : true;
            this.jqxGridConfig.columns[16].hidden = this.isWWANTest == true ? false : true;
            
            if (result.json().integrationTestStatusId <= 4) {
                if ((<HTMLSelectElement>document.getElementById('IntegrationTestStatusId')) != null) {
                    (<HTMLSelectElement>document.getElementById('IntegrationTestStatusId')).selectedIndex = result.json().integrationTestStatusId - 1;
                }
            }
            if (result.json().odmTestStatusId <= 4) {
                if ((<HTMLSelectElement>document.getElementById('ODMTestStatusId')) != null) {
                    (<HTMLSelectElement>document.getElementById('ODMTestStatusId')).selectedIndex = result.json().odmTestStatusId - 1;
                }
            }
            if (result.json().wwanTestStatusId <= 4) {
                if ((<HTMLSelectElement>document.getElementById('WWANTestStatusId')) != null) {
                    (<HTMLSelectElement>document.getElementById('WWANTestStatusId')).selectedIndex = result.json().wwanTestStatusId - 1;
                }
            }
            this.jqxGridConfig.localdata = result.json().productDeliverableViewModel;
           //this.jqxGridConfig.columns[0].se
            this.myGrid.updatebounddata(null);
            //this.myGrid.selectallrows();
            this.myGrid.selectallrows();
           
            this.myGrid.hideloadelement();
        });
    }

    //toggleAll() {
    //    this.advancedSupportProduct.productDetails.forEach(item => item.checked = true);
    //}    
    isError: boolean = false;
    ErrorMessage: string[]
    UpdateMultiUpdateTestStatus(): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var idList = "";
        var index: number;
        this.ErrorMessage = [];
        this.isError = false;

        for (index = 0; index < selectedIndices.length; index++) {
            idList += this.myGrid.getrowdata(selectedIndices[index]).versionId + "_" + this.myGrid.getrowdata(selectedIndices[index]).productId + "_"
                + this.myGrid.getrowdata(selectedIndices[index]).id + "_" + this.myGrid.getrowdata(selectedIndices[index]).productDeliverableReleaseId + ",";

        }
        let multiUpdateTestStatusViewModel = new MultiUpdateTestStatusViewModel();
        var IntegrationTestStatusId = <HTMLSelectElement>document.getElementById('IntegrationTestStatusId');
        var ODMTestStatusId = <HTMLSelectElement>document.getElementById('ODMTestStatusId');
        var WWANTestStatusId = <HTMLSelectElement>document.getElementById('WWANTestStatusId');
        var IntegrationTestNotes = <HTMLTextAreaElement>document.getElementById('IntegrationTestStatusNotes');
        var ODMTestNotes = <HTMLTextAreaElement>document.getElementById('ODMTestNotes');
        var WWANTestNotes = <HTMLTextAreaElement>document.getElementById('WWANTestNotes');
        if (selectedIndices.length == 0) {
            this.ErrorMessage.push('You must select at least one deliverable to continue.');
            this.isError = true;
        }
        if (IntegrationTestStatusId != null) {
            if (IntegrationTestStatusId.selectedIndex == 0) {
                this.ErrorMessage.push('SE Test Status is required');
                this.isError = true;
            }
            else if (IntegrationTestStatusId.selectedIndex == 2 || IntegrationTestStatusId.selectedIndex == 3) {
                if (IntegrationTestNotes.value.trim() == '') {
                    this.ErrorMessage.push('SE Test Notes are required for the selected status');
                    this.isError = true;
                }
            }
            multiUpdateTestStatusViewModel.IntegrationTestStatusNotes = IntegrationTestNotes.value.trim();
            multiUpdateTestStatusViewModel.IntegrationTestStatusId = IntegrationTestStatusId.selectedIndex;
        }
        if (ODMTestStatusId != null) {
            if (ODMTestStatusId.selectedIndex == 0) {
                this.ErrorMessage.push('ODM Test Status is required');
                this.isError = true;
            }
            else if (ODMTestStatusId.selectedIndex == 2 || ODMTestStatusId.selectedIndex == 3) {
                if (ODMTestNotes.value.trim() == '') {
                    this.ErrorMessage.push('ODM Test Notes are required for the selected status');
                    this.isError = true;
                }
            }
            multiUpdateTestStatusViewModel.ODMTestNotes = ODMTestNotes.value.trim();
            multiUpdateTestStatusViewModel.ODMTestStatusId = ODMTestStatusId.selectedIndex;
        }
        if (WWANTestStatusId) {
            if (WWANTestStatusId.selectedIndex == 0) {
                this.ErrorMessage.push('COMM Test Status is required');
                this.isError = true;
            }
            else if (WWANTestStatusId.selectedIndex == 2 || WWANTestStatusId.selectedIndex == 3) {
                if (WWANTestNotes.value.trim() == '') {
                    this.ErrorMessage.push('COMM Test Notes are required for the selected status');
                    this.isError = true;
                }
            }
            multiUpdateTestStatusViewModel.WWANTestNotes = WWANTestNotes.value.trim();
            multiUpdateTestStatusViewModel.WWANTestStatusId = WWANTestStatusId.selectedIndex;
        }
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            multiUpdateTestStatusViewModel.IdList = idList;
            this.multiUpdateTestStatusService.updateMultiUpdateTestStatus(multiUpdateTestStatusViewModel).subscribe(result => {
                MultiTestStatusCallback(1);
                this.closeExternalPopup();
            });
        }
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
    statusChange(statusType:any): void
    {
        if (statusType == "setest") {
            var IntegrationTestStatus = <HTMLSelectElement>document.getElementById('IntegrationTestStatusId');
            if (IntegrationTestStatus.selectedIndex == 2 || IntegrationTestStatus.selectedIndex == 3)
                (<HTMLFontElement>document.getElementById('requireIntegrationNotes')).style.display = "";
            else {
                this.isError = false;
                this.ErrorMessage = [];
                //if (IntegrationTestStatus != null) {
                //    if (IntegrationTestStatus.selectedIndex == 0) {
                //        this.ErrorMessage.push('SE Test Status is required');
                //        this.isError = true;
                //    } 
                //}
               
                (<HTMLFontElement>document.getElementById('requireIntegrationNotes')).style.display = "none";
            }
        }
        else if (statusType == "odmtest") {
            var ODMTestStatus = <HTMLSelectElement>document.getElementById('ODMTestStatusId');
            if (ODMTestStatus.selectedIndex == 2 || ODMTestStatus.selectedIndex == 3)
                (<HTMLFontElement>document.getElementById('requireODMNotes')).style.display = "";
            else {
                (<HTMLFontElement>document.getElementById('requireODMNotes')).style.display = "none";
                this.isError = false;
                this.ErrorMessage = [];
                //if (ODMTestStatus != null) {
                //    if (ODMTestStatus.selectedIndex == 0) {
                //        this.ErrorMessage.push('ODM Test Status is required');
                //        this.isError = true;
                //    }
                //}
            }
        }
        else {
            var WWANTestStatus = <HTMLSelectElement>document.getElementById('WWANTestStatusId');
            if (WWANTestStatus.selectedIndex == 2 || WWANTestStatus.selectedIndex == 3)
                (<HTMLFontElement>document.getElementById('requireWWANNotes')).style.display = "";
            else {
                this.isError = false;
                this.ErrorMessage = [];
                (<HTMLFontElement>document.getElementById('requireWWANNotes')).style.display = "none";
            }
        }
    }
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08-31-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="multi-update-test-status.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import {MultiUpdateTestStatusViewModel } from '../multi-update-test-status/multi-update-test-status.viewmodel'

@Injectable()
export class MultiUpdateTestStatusService {

    constructor(private http: Http, private location: Location) {
    }

    getProductDeliverableInfoForComponentTestLead(componentTestLeadViewModel): Observable<Response> {
        return this.http.post(this.location.prepareExternalUrl('/product/Product/GetProductDeliverableInfoForComponentTestLead'),componentTestLeadViewModel);
    }

    getUserLeadType(){
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetUserLeadType'));
    }
    updateMultiUpdateTestStatus(componentTestLeadViewModel: MultiUpdateTestStatusViewModel) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/UpdateProductDeliverableComponentTest'), componentTestLeadViewModel, {
            headers: headers
        });
    }
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : RajivGandhi.R(auth\rajamanr)
// Created          : 09-14-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="multi-update-test-status.viewmodel.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class MultiUpdateTestStatusViewModel {
    SelectedVersionIds: any;
    LoadedVersionIds: any;
    ProductId: any;
    RootId: any;
    ReleaseId: any;
    ProductDeliverableReleaseId: any;
    IdList: any;
    WWANTestStatusId: any;
    ODMTestStatusId: any;
    IntegrationTestStatusId: any;
    WWANTestNotes: any;
    ODMTestNotes: any;
    IntegrationTestStatusNotes: any;
    VersionIds: any;
    ProductDeliverableIds: any;
    ProductReleaseIds: any;
}
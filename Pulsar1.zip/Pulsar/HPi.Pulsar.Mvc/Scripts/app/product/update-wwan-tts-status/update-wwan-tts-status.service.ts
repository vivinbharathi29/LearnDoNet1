﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Vignesh.T
// Created          : 09-04-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="update-wwan-tts-status.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class UpdateWWANTTSStatusService {

    constructor(private http: Http, private location: Location) {
    }

    geWWANTTSStatus(id: number): Observable<Response> {
        
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetWWANTTSStatus?id=' + id));
    }
   

    updateWWANTTSStatus(versionPropertiesVM: any, id: number) {
        
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/UpdateWWANTTSStatus?id=' + id), versionPropertiesVM, {
            headers: headers
        }).subscribe(
            (r: Response) => { }
            );
    }
}
﻿import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { UpdateWWANTTSStatusService } from './update-wwan-tts-status.service'
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { CustomValidationService } from '../../shared/custom-validation.service'

@Component({
    selector: 'update-wwan-tts-status',
    templateUrl: './update-wwan-tts-status.component.html',
    providers: [UpdateWWANTTSStatusService]
})
export class UpdateWWANTTSStatusComponent {
    //@ViewChild('dateTimeInputReference') myDateTimeInput: jqxDateTimeInputComponent;
    errorMessage: string;
    public versionProperties: any;
    public scheduledataId: any;
    WWANTTSStatusform: FormGroup;
    public typeId: any = 0;
    constructor(http: Http, private service: UpdateWWANTTSStatusService, private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router, private customValidationService: CustomValidationService) {
        this.WWANTTSStatusform = fb.group({
            'TTS': [0, Validators.compose([Validators.required])]
        })
        this.typeId = activatedRoute.snapshot.params['id'];
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.scheduledataId = params['scheduledataid'];
        });
    }

    ngOnInit() {
        //this.geWWANTTSStatus();
    }

    ngAfterViewInit(): void {
        this.geWWANTTSStatus();
    }

    geWWANTTSStatus() {

        this.service.geWWANTTSStatus(this.typeId).subscribe(result => {

            this.versionProperties = result.json();
            //this.myDateTimeInput.setDate(new Date(this.updateScheduleViewModel.scheduleMilestoneData.projectedStartdt));

            this.WWANTTSStatusform = this.fb.group({
                'TTS': ['', Validators.compose([Validators.required])]
            })
        });
    }

    isError: boolean = false;
    ErrorMessage: string[]
    SaveWWANTTSStatus(versionProperties: FormGroup) {

        this.ErrorMessage = [];
        this.isError = false;
        for (const control in this.WWANTTSStatusform.controls) {
            for (const propertyName in this.WWANTTSStatusform.controls[control].errors) {
                this.ErrorMessage.push('You must select the WWAN TTS to continue');
                this.isError = true;
            }
            if (control == "TTS") {
                if (this.WWANTTSStatusform.controls[control].value == 0) {
                    this.isError = true;
                }
            }
        }
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            this.service.updateWWANTTSStatus(versionProperties, this.typeId);
            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            UpdatePanelStatusCallbackReloadCallback(1);
            closePopup('externalpagepopup');
        }

    }
    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
    isValid: boolean = false;
    onChange(event) {
        if (event == "Waived" || event == "Failed") {
            this.isValid = true;
        }
    }

}  
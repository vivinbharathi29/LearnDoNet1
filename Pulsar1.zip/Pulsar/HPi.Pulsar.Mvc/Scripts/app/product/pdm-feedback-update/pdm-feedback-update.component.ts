﻿import { Component } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
//import { PDMFeedbackUpdateService } from './pdm-feedback-update.service';

@Component({
    selector: 'pdm-feedback-update.component',
    templateUrl: './pdm-feedback-update.component.html',
    styles: [`
.hideSection
{
  display:none;
}
`]
   // providers: [PDMFeedbackUpdateService]
})
export class pdmfeedbackupdatecomponent {

    feedback: string;
    avActionItemID: number;
    avItemsNumber: string;
    //userName: string = "";
    alertMessage: string;
    pdmFeedbackParentWindow: string;
    public enableUpdateForMultipleAV: boolean = false;
    public enableUpdateForSingleAV: boolean = false;

    constructor(private route: ActivatedRoute, private router: Router) {
        //this.feedback = "";
        this.avActionItemID = route.snapshot.params['AvActionItemID'];
        this.avItemsNumber = route.snapshot.params['updateItemsNumber'];
        this.alertMessage = route.snapshot.params['alertMessage'];      
        this.pdmFeedbackParentWindow = route.snapshot.params['txtPDMFeedback'];
        this.feedback = this.pdmFeedbackParentWindow;
        this.enableUpdateForMultipleAV = false;
        this.enableUpdateForSingleAV = false;
        if (this.avItemsNumber == "single") {
            this.enableUpdateForSingleAV = false;
            this.enableUpdateForMultipleAV = true;
        }
        if (this.avItemsNumber == "multiple") {
            this.enableUpdateForSingleAV = true;
            this.enableUpdateForMultipleAV = false;
        }
      //  (<HTMLInputElement>document.getElementById("txtFeedBack")).value = this.pdmFeedbackParentWindow;
    }

    save(): void {
        if (this.feedback.trim().length == 0)
        {
            alert(this.alertMessage);
        }

            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);

            if (this.avItemsNumber == "single") {
                PDMFeedbackMainSingle(this.avActionItemID, this.feedback);
            }

            if (this.avItemsNumber == "multiple") {
                PDMFeedbackMainMultiples2Callback(this.feedback);
               }
            closePopup('externalpagepopup');
            // popupCallBack(this.feedback);

            //this.PdmFeedbackUpdateService.updatePDMFeedBackSingleAV(this.avActionItemID, this.userName, this.feedback).subscribe(result => {
            //});
  
      //  }
      //  else {
      //      alert(this.alertMessage);
      //  }
    }

    cancel(): void {
        // this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
}

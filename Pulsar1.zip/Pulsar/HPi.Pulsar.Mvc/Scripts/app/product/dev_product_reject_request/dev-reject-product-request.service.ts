﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-19-2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01-10-2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dev-reject-product-request.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class DevRejectProductRequestService {

    constructor(private http: Http, private location: Location) {
    }

    getProductDeliverableSummary(id: any, newValue: any): Observable<Response> {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/GetProductDeliverableSummary?newValue=' + newValue), id, {
            headers: headers
        });
    }

    saveDevNotification(multiId: any, comments: any, newValue: any): Observable<Response> {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/SaveDevNotification?newValue=' + newValue + '&comments=' + comments), multiId, {
            headers: headers
        });
    }
}
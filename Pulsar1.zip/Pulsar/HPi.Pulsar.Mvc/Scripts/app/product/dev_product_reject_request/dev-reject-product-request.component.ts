﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09/19/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01-10-2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dev-reject-product-request.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DevRejectProductRequestService } from './dev-reject-product-request.service';

@Component({
    selector: 'dev-reject-product-request',
    templateUrl: './dev-reject-product-request.component.html',
    providers: [DevRejectProductRequestService]
})
export class DevRejectProductRequestComponent implements OnInit {
    id: any;
    newValue: any;
    multiId: any;
    message: string;
    errorMessage: string;
    devRejectProductRequestViewModel: any;

    constructor(private devRejectProductRequestService: DevRejectProductRequestService, private route: ActivatedRoute, private router: Router) {
        this.newValue = route.snapshot.params['NewValue'];
        this.id = route.snapshot.params['ID'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.getProductDeliverableSummary();
    }

    getProductDeliverableSummary() {
        this.devRejectProductRequestService.getProductDeliverableSummary(this.id.split(","), this.newValue).subscribe(result => {
            this.devRejectProductRequestViewModel = result.json();
            if (result.json().length > 0) {
                this.message = result.json()[0]['message'];
            }
        });
    }

    saveNotification(): void {
        var comments = (<HTMLInputElement>document.getElementById("txtComments")).value;
        if (comments != "") {
            this.multiId = this.id;
            this.devRejectProductRequestService.saveDevNotification(this.multiId.split(","), comments, this.newValue).subscribe(result => {
                popupCallBack(1);
                closePopup('externalpagepopup');
                this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            });
        }
        else {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "block";
            this.errorMessage = "Comments are required when rejecting deliverable requests.";
        }
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

    CheckTextSize(value: any, maxLength: any) {
        if (value.length > maxLength) {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "block";
            this.errorMessage = "The maximum size of this field in 200 characters. Your input has been truncated.";
        }
        else {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "none";
            this.errorMessage = null;
        }
    }
}
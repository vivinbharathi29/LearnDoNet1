﻿import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { UpdateOrProductQualificationPulsarservice } from './update-or-product-qualification-pulsar.service'
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { CustomValidationService } from '../../shared/custom-validation.service'
@Component({
    selector: 'update-qualification',
    templateUrl: './update-or-product-qualification-pulsar.component.html',
    providers: [UpdateOrProductQualificationPulsarservice]
})
export class UpdateOrProductQualificationPulsarComponent {
    //@ViewChild('dateTimeInputReference') myDateTimeInput: jqxDateTimeInputComponent;
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    //@ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    errorMessage: string;
    public multiTestStatusViewModel: any;
    public scheduledataId: any;
    public checkedIds: any = 0;
    public productId: any = 0;
    public rootId: any = 0;
    public versionId: any = 0;
    public bsId: any = 0;
    public showOnlyTargetedRelease: any = 0;
    public qualificationDate: any = true;
    public qualificationConfidence: any = true;
    public qualificationRiskRelease: any;
    updatequalificationpulsarform: FormGroup;
    public refreshInterval: any;
    constructor(http: Http, private service: UpdateOrProductQualificationPulsarservice, private fb: FormBuilder, private activatedRoute: ActivatedRoute, private router: Router, private customValidationService: CustomValidationService) {
        this.checkedIds = activatedRoute.snapshot.params['chkIDs'];
        this.productId = activatedRoute.snapshot.params['productId'];
        this.rootId = activatedRoute.snapshot.params['rootId'];
        this.versionId = activatedRoute.snapshot.params['versionId'];
        this.bsId = activatedRoute.snapshot.params['bsId'];
        this.showOnlyTargetedRelease = activatedRoute.snapshot.params['showOnlyTargetedRelease'];
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'versionId', map: 'versionId' },
            { name: 'product', map: 'product' },
            { name: 'release', map: 'release' },
            { name: 'qualification', map: 'qualification' },
            { name: 'pilot', map: 'pilot' },
            { name: 'accessory', map: 'accessory' },
            { name: 'availableUntil', map: 'availableUntil' },
            { name: 'vendor', map: 'vendor' },
            { name: 'hwfwRev', map: 'hwfwRev' },
            { name: 'modelNumber', map: 'modelNumber' },
            { name: 'partNumber', map: 'partNumber' },
            { name: 'comments', map: 'comments' },
            { name: 'id', map: 'id' },
            { name: 'productDeliverableReleaseId', map: 'productDeliverableReleaseId' }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'Version Id', datafield: 'versionId', filtertype: 'input',width: '10%'
            },
            {
                text: 'Product', datafield: 'product', filtertype: 'input', width: '10%'
            },
            {
                text: 'Release', datafield: 'release', filtertype: 'input', width: '10%'
            },
            {
                text: 'Qualification', datafield: 'qualification', filtertype: 'input', width: '10%'
            },
            {
                text: 'Pilot', datafield: 'pilot', filtertype: 'input', width: '10%'
            },
            {
                text: 'Accessory', datafield: 'accessory', filtertype: 'input', width: '10%'
            },
            {
                text: 'Available Until', datafield: 'availableUntil', filtertype: 'input', width: '10%', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Vendor', datafield: 'vendor', filtertype: 'input', width: '10%'
            },
            {
                text: 'HWFWRev', datafield: 'hwfwRev', filtertype: 'input', width: '10%'
            },
            {
                text: 'Model', datafield: 'modelNumber', filtertype: 'input', width: '10%'
            },
            {
                text: 'Part', datafield: 'partNumber', filtertype: 'input', width: '10%'
            },
            {
                text: 'Comments', datafield: 'comments', filtertype: 'input', width: '25%'
            },
            {
                text: 'id', datafield: 'id', filtertype: 'input', width: '25%', hidden: true 
            },
            {
                text: 'productDeliverableReleaseId', datafield: 'productDeliverableReleaseId', filtertype: 'input', width: '25%', hidden: true 
            }
        ];
        this.updatequalificationpulsarform = fb.group({
            'SelectedIds': [null],
            'StatusId': [null],
            'IsRiskRelease': [null],
            'QualComments': [null],
            'QualDate': [null],
            'QualConfidence': [null]            
        })
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.scheduledataId = params['scheduledataid'];
        });

    }

    pageReload(): void {
        this.myGrid.clearselection();        
        this.GetProductQualificationForMultiTestStatusPulsar();
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);    
        this.GetProductQualificationForMultiTestStatusPulsar();
    }

    //Get the list of languages  

    GetProductQualificationForMultiTestStatusPulsar() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getProductQualificationPulsar(this.checkedIds, this.productId, this.rootId, this.versionId, this.bsId, this.showOnlyTargetedRelease).subscribe(result => {            
            this.multiTestStatusViewModel = result.json();              
            if (result.json().notSpecificProduct == 0) {                
                this.jqxGridConfig.columns[1].hidden = true
            }
            this.jqxGridConfig.localdata = result.json().deliverableListPulsarViewModel;
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
            this.updatequalificationpulsarform = this.fb.group({
                'SelectedIds': [this.multiTestStatusViewModel.selectedIds],  // will use the property in html page  
                'StatusId': [this.multiTestStatusViewModel.testStatusId],
                'IsRiskRelease': [null],
                'QualComments': [''],
                'QualDate': [null],
                'QualConfidence': [this.multiTestStatusViewModel.qualConfidence]                

            })

            if (result.json().statusId == 3) {
                this.qualificationDate = true;
                this.qualificationConfidence = true;
            }
            else
            {
                this.qualificationDate = false;
                this.qualificationConfidence = false;
            }
        });
    }

    isError: boolean = false;
    ErrorMessage: string[];
    SaveProductQualificationPulsar(updatescheduel: FormGroup) {        
        this.ErrorMessage = [];
        this.isError = false;
        for (const control in this.updatequalificationpulsarform.controls) {
            if (control == "QualDate") {
                if (this.updatequalificationpulsarform.controls[control].value == null) {                    
                    this.ErrorMessage.push('Qualification Date is Required.');
                    this.isError = true;
                }
            }
        }
        if (this.isError) {
            window.scrollTo(20, 20);
        }
        else {
            var index: number;
            var productDeliverableIds: string;
            var productDeliverableReleaseIDs: string;
            var checkedIds = "";
            var selectedCount: string;
            var ajaxurl: string;
            var selectedIndices = this.myGrid.selectedrowindexes();
            selectedCount = this.myGrid.getdatainformation().rowscount;
            for (index = 0; index < selectedIndices.length; index++) {
                //selectedCount = selectedCount - 1;

                if (this.myGrid.getrowdata(selectedIndices[index]).productDeliverableReleaseId > 0) {
                    productDeliverableReleaseIDs += this.myGrid.getrowdata(selectedIndices[index]).productDeliverableReleaseId + ",";
                }
                else {
                    productDeliverableIds += this.myGrid.getrowdata(selectedIndices[index]).productDeliverableId + ",";
                }

                checkedIds += this.myGrid.getrowdata(selectedIndices[index]).id + "_" + this.myGrid.getrowdata(selectedIndices[index]).productDeliverableReleaseId + ",";
            }
            if (checkedIds != undefined) {
                checkedIds = checkedIds.slice(0, checkedIds.length - 1); // Remove last two characters: comma and space            
            }

            this.service.updateProductQualification(updatescheduel, checkedIds);
            this.myGrid.showdefaultloadelement(true);
            this.refreshInterval = setInterval(() => this.cancelPopup(), 7000);
            this.myGrid.showdefaultloadelement(false);
        }
    }
    cancelPopup() {
        clearInterval(this.refreshInterval);
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        MultiDeveloperSignoffCallback(1);
    }

    onChange(selectedIndex: any) {
        if (selectedIndex == 3) {
            this.qualificationDate = true;
            this.qualificationConfidence = true;
        }
        else {
            this.qualificationDate = false;
            this.qualificationConfidence = false;
        }     
        if (selectedIndex == 16 || selectedIndex == 11 || selectedIndex == 3) {            
            this.qualificationConfidence = true;
        }
        else {            
            this.qualificationConfidence = false;
        }  
        if (selectedIndex == 5) {
            this.qualificationRiskRelease = true;
        }
        else {
            this.qualificationRiskRelease = false;
        }      
    }
    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {        
        if (value == "Unavailable") {
            var element = $(defaulthtml);
            element.css({ 'background-color': 'red' });
            return element[0].outerHTML;
        }
        var availableDate = new Date(value);        
        if (Object.prototype.toString.call(availableDate) == '[object Date]' && value != " ") {        
            var element = $(defaulthtml);
            element.css({ 'background-color': 'yellow' });
            return element[0].outerHTML;
        }
        return defaulthtml;
    }

}  
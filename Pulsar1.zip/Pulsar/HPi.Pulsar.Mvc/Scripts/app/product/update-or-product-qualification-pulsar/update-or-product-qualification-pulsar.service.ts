﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh
// Created          : 08/17/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="update-or-product-qualification.service" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class UpdateOrProductQualificationPulsarservice {

    constructor(private http: Http, private location: Location) {
    }

    getProductQualificationPulsar(versionList, productId, rootId, versionId, bsId, showOnlyTargetedRelease): Observable<Response> {
        
        let parameters = new URLSearchParams();
        parameters.set("VersionList", versionList);
        parameters.set("ProductId", productId);
        parameters.set("RootId", rootId);
        parameters.set("VersionId", versionId);
        parameters.set("BsId", bsId);
        parameters.set("ShowOnlyTargetedRelease", showOnlyTargetedRelease);   
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });        
        return this.http.post(this.location.prepareExternalUrl('/product/Product/GetProductQualificationForMultiTestStatusPulsar'), parameters);
    }

    updateProductQualification(multiTestStatusPulsar, checkedIds: string) {        
        //var headers = new Headers();
        //headers.append('Content-Type', 'application/json');
        //this.http.post('/product/Product/UpdateProductQualificationForMultiTestStatusPulsar?selectedIds+checkedIds', multiTestStatusPulsar, {
        //    headers: headers
        //}).subscribe(
        //    (r: Response) => { }
        //    );
        
        if (multiTestStatusPulsar.IsRiskRelease == true) {
            multiTestStatusPulsar.IsRiskRelease = 1;
        }
        else {
            multiTestStatusPulsar.IsRiskRelease = 0;
        }
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/UpdateProductQualificationForMultiTestStatusPulsar?selectedIds=' + checkedIds), multiTestStatusPulsar, {
            headers: headers
        }).subscribe(
            (r: Response) => { }
            );
    }
}
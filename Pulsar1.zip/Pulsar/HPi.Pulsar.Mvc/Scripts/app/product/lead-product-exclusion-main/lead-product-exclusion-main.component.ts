﻿import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';

import { LeadProductExclusionService } from './lead-product-exclusion-main.service'
import { ExclusionMainViewModel } from './lead-product-exclusion-main.viewmodel'
import { ActivatedRoute, NavigationExtras, Params,Router } from '@angular/router';

@Component({
    selector: 'lead-product-exclusions',
    templateUrl: './lead-product-exclusion-main.component.html',
})

export class LeadProductExclusionComponent implements OnInit {
    id: number;   
    constructor(http: Http, private service: LeadProductExclusionService,private ngZone: NgZone,private activatedRoute:ActivatedRoute,private router:Router) {
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            //ShowArtileListCallBackFn: (value) => this.showArticleListCallBack(value),
            component: this
        };   
        this.rootId = this.activatedRoute.snapshot.params['rootId'];
        this.productId = this.activatedRoute.snapshot.params['productId'];
    }
    exclusionMainViewModel: any;
    getAllLeadProductExclusions() {
        let exclusionMainVM = new ExclusionMainViewModel();
        exclusionMainVM.RootId = this.rootId;
        exclusionMainVM.ProductId = this.productId;
        exclusionMainVM.VersionIds = this.activatedRoute.snapshot.params['versionIdList'];
        exclusionMainVM.IsFusionRequirements = this.activatedRoute.snapshot.params['isFusionRequirements'];
        this.service.getDeliverableVersionExclusions(exclusionMainVM).subscribe(result => {
            this.exclusionMainViewModel = result.json();
            this.releaseId = this.exclusionMainViewModel.releaseId;
            this.productVersionId = this.exclusionMainViewModel.productVersionId;
            console.log('Test');
        });
    }
    productId: any;
    releaseId: any;
    rootId: any;
    productVersionId: any;
    ErrorMessage: string[];
    isError: boolean = false;
    addLeadProductExclusion() {
        //var selectedIndices = this.myGrid.selectedrowindexes();
        var index: number;
        var addLeadProductVersionIds: any='';
        var comments: any = (<HTMLTextAreaElement>document.getElementById('Comments')).value;
        var versionList: any = <HTMLUListElement>document.getElementById('VersionList');
        var selectAll: any = <HTMLInputElement>document.getElementById('rdnAll');
        var selectType: any = <HTMLInputElement>document.getElementById('rdnType');
        var leadCheckBoxCount: any = 0;
        var count: any = 0;
        this.isError = false;
        if (selectType.checked == true) {
            $("ul#VersionList").find('input[type=checkbox]').each(function () {
                leadCheckBoxCount = leadCheckBoxCount + 1;
                if (this.checked == false) {
                    count = count + 1;
                }
            });
            if (leadCheckBoxCount == count) {
                this.ErrorMessage = [];
                this.ErrorMessage.push("Please select atleast one deliverable version");
                window.scrollTo(10, 10);
                this.isError = true;
                return;
            }
        }
        let leadIndex: number = 0;
        if (selectAll.checked == true) {
           
            $("ul#VersionList").find('input[type=checkbox]').each(function () {
                    addLeadProductVersionIds += this.value + ",";
                  

                });
           
        }
        else {
            $("ul#VersionList").find('input[type=checkbox]').each(function () {
                if (this.checked == true) {
                    addLeadProductVersionIds += this.value + ",";
                }
            });
        }
        let exclusionMainVM = new ExclusionMainViewModel();
        exclusionMainVM.RootId = this.rootId;
        exclusionMainVM.VersionIds = addLeadProductVersionIds;
        exclusionMainVM.Comments = comments;
        exclusionMainVM.ProductId = this.productVersionId;
        exclusionMainVM.ReleaseId = this.releaseId;
        this.service.addLeadProductExclusion(exclusionMainVM).subscribe(result => {
            if (result.json() == true) {
                this.cancelPopup();
                LeadProductSynchronizationCallback(1);
                console.log(result.json());
            }
        });
    }
    
    ngOnInit(): void {
        this.getAllLeadProductExclusions();
    }


    cancelPopup()
    {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
    selectVersion(Type:any) {
        var rdnType: any = (<HTMLInputElement>document.getElementById('rdnType'));
        var index: any = 0;
        if (Type == 'radio')
            rdnType.selected = true;
        if ($('#VersionList').find('input[type=checkbox]').length == 1) {
            $('#VersionList').find('input[type=checkbox]').attr('Checked', true)
        }
    }
}
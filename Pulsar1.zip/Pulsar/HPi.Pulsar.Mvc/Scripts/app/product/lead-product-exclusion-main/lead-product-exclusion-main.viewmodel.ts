﻿export class ExclusionMainViewModel
{
    RootName: any;
    ProductName: any;
    ProductId: any;
    Comments: any;
    RootId: any;
    DeliverableVersionId: any;
    VersionIds: any; 
    ReleaseId: any;
    IsFusionRequirements: any; 
}
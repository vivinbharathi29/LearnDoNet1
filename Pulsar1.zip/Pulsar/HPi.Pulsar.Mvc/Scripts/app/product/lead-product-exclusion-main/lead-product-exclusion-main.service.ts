﻿import { Component, ViewChild, AfterViewInit, NgZone,Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';



@Injectable()
export class LeadProductExclusionService{
    constructor(private http: Http, private location: Location) {

    }

    getDeliverableVersionExclusions(exclusionMain:any)
    {
        return this.http.post(this.location.prepareExternalUrl('product/Product/GetDeliverableVersionExclusions'), exclusionMain);
    }
   
    addLeadProductExclusion(exclusionMainVM: any) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/product/Product/AddLeadProductExclusions'), exclusionMainVM);
    }
}
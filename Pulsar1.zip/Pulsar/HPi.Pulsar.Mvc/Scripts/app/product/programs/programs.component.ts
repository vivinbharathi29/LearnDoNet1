﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Sundar R
// Created          : 11/13/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="programs.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute, Params } from '@angular/router'

@Component({
    selector: 'programs',
    template: '',
})

export class ProgramsComponent {

    public id: any;
    public commodity: any;
    public factoryEngineer: any;
    public accessory: any;
    public clone: any;
    public tab: any;
    public hwpm: any;
    public pulsar: any;

    constructor(http: Http, private route: ActivatedRoute, private router: Router) {
        this.id = route.snapshot.params['id'];
        this.commodity = route.snapshot.params['commodity'];
        this.hwpm = route.snapshot.params['HWPM'];
        this.factoryEngineer = route.snapshot.params['factoryEngineer'];
        this.accessory = route.snapshot.params['accessory'];
        this.clone = route.snapshot.params['clone'];
        this.tab = route.snapshot.params['tab'];
        this.pulsar = route.snapshot.params['pulsar'];
        this.redirect();
    }

    redirect() {
        if (this.commodity == 1) {
            var url = "";
            var title = "";
            var height = 300;
            var width = 600;
            url = "/product/product/GetProgramsCommodityPM/" + this.id;
            title = "Product Properties";
            showPopup(url, title, height, width);

            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            closePopup('externalpagepopup');
        }
        else if (this.hwpm == 1) {

            this.router.navigate([{ outlets: { 'externalpopupWindow': ['programproperties', this.id] } }]);
            modalPopup.show('#externalpopupMessage', "70%", "390px", "Product Properties");
        }
        else if (this.factoryEngineer == 1) {
            var url = "";
            var title = "";
            url = "/Core/User/ChooseEmployee?dialogType=15&HistoryID=0&productVersionId=" + this.id;
            title = "Product Properties";
            adjustableShowPopup(url, title, "400px", "50%", "365px");
            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            closePopup('externalpagepopup');
        }
        else if (this.accessory == 1) {
            var url = "";
            var title = "";
            url = "/Core/User/ChooseEmployee?dialogType=13&HistoryID=0&productVersionId=" + this.id;
            title = "Product Properties";
            adjustableShowPopup(url, title, "400px", "50%", "365px");

            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            closePopup('externalpagepopup');
        }
        else if (this.pulsar == 1) {
            var url = "";
            var title = "";
            var height = 250;
            var width = 475;
            url = "/Excalibur/MobileSE/Today/programs.asp?clone=" + this.clone + "&ID=" + this.id + "&Tab=" + this.tab;
            title = "Product Properties";
            showPopup(url, title, height, width);
        }
    }
}
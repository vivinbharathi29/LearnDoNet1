﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-12-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="multi-eol-date.viewmodel.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class MultiEOLDateViewModel {
    labelHeader: string;
    deliverableName: string;
    version: string;
    revision: string;
    pass: string;
    vendor: string;
    modelNumber: string;
    partNumber: string;
    eolDate: string;
    serviceEOADate: string;
    typeId: string;
}
﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09/12/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 10/14/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="multi-eol-date.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { jqxMenuComponent } from '../../jqwidgets-ts/angular_jqxmenu';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../shared/messagebox/index';
import { MultiEOLDateService } from './multi-eol-date.service';
import { MultiEOLDateViewModel } from './multi-eol-date.viewmodel';

@Component({
    selector: 'multi-eol-date',
    templateUrl: './multi-eol-date.component.html',
    providers: [MultiEOLDateService]
})
export class MultiEOLDateComponent implements OnInit {
    @ViewChild('dateInput') inputDate: jqxDateTimeInputComponent;
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    private mbp: MessageBoxButton;
    multiEOLDateViewModel: MultiEOLDateViewModel;
    selectedRowIndex: string;
    typeId: number;
    idList: any;
    labelHeader: any;
    dateChange: any;

    constructor(private multiEOLDateService: MultiEOLDateService, private route: ActivatedRoute, private router: Router, private messageBox: MessageBox) {
        this.multiEOLDateViewModel = new MultiEOLDateViewModel();
        this.idList = route.snapshot.params['strIDs'];
        this.typeId = route.snapshot.params['TypeID'];
        console.log(this.typeId);
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightTwoLineLinks;
        this.jqxGridConfig.settings.pageable = false;
        this.jqxGridConfig.selectionmode = 'checkbox';

        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number' },
            { name: 'deliverableName', map: 'deliverableName', type: 'string' },
            { name: 'version', map: 'version', type: 'string' },
            { name: 'partNumber', map: 'partNumber', type: 'string' },
            { name: 'modelNumber', map: 'modelNumber', type: 'string' },
            { name: 'eolDate', map: 'eolDate', type: 'date' },
            { name: 'eoaDate', map: 'eoaDate', type: 'date' },
            { name: 'vendor', map: 'vendor', type: 'string' }, 
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'MultiEOLDate',
                datafield: 'id', width: '7.5%', filtertype: 'number'
            },
            {
                text: 'Deliverable', columngroup: 'MultiEOLDate',
                datafield: 'deliverableName', width: '18%', filtertype: 'input'
            },
            {
                text: 'Available Until', columngroup: 'MultiEOLDate',
                datafield: 'eolDate', width: '10%', cellsformat: 'MM/dd/yyyy', filtertype: 'date'
            },
            {
                text: 'Factory EOA', columngroup: 'MultiEOLDate',
                datafield: 'eoaDate', width: '10%', cellsformat: 'MM/dd/yyyy', filtertype: 'date'
            },
            {
                text: 'Version', columngroup: 'MultiEOLDate',
                datafield: 'version', width: '12%', filtertype: 'input'
            },
            {
                text: 'Vendor', columngroup: 'MultiEOLDate',
                datafield: 'vendor', width: '10%', filtertype: 'input'
            },
            {
                text: 'Model', columngroup: 'MultiEOLDate',
                datafield: 'modelNumber', width: '15%', filtertype: 'input'
            },
            {
                text: 'Part Number', columngroup: 'MultiEOLDate',
                datafield: 'partNumber', width: '15%', filtertype: 'input'
            },
        ];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getDcrWorkflowStatus();
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
        else {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            return false;
        }
    }

    getDcrWorkflowStatus() {
        this.myGrid.showdefaultloadelement(true);
        this.multiEOLDateService.getDeliverablesToUpdate(this.idList, this.typeId).subscribe(result => {
            if (result.json().length > 0) {
                this.labelHeader = result.json()[0]['labelHeader'];
            }

            if (result.json()[0]['eoaDate'] == "") {
                this.jqxGridConfig.columns[3].hidden = true;
            }
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.selectallrows();
            this.myGrid.hideloadelement();
        });
    }

    cmdComplete_onclick(): void {
        var idArray = "";
        var eolDate = "";
        eolDate = this.inputDate.getText();
        if (eolDate != null || eolDate != undefined || eolDate != "") {
            eolDate = eolDate.split('/').join('-');
        }
        var selectedIndices = this.myGrid.selectedrowindexes();
        for (var index = 0; index < selectedIndices.length; index++) {
            idArray = idArray + this.myGrid.getrowdata(selectedIndices[index]).id + ",";
        }
        idArray = idArray.substring(0, idArray.length - 1);
        if (idArray.length == 0) {
            this.messageBox.Show("MultiEOL Update", "You must select at least one deliverable to continue.", MessageBoxType.Ok, MessageBoxIcon.Warning, "400", this.confirmationMessage);
        }
        else if ($('#cboDateChange').val() == "0") {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "block";
            (<HTMLInputElement>document.getElementById("errorDate")).style.display = "none";
            (<HTMLInputElement>document.getElementById("errorNoChange")).style.display = "block";
        }
        else {
            this.multiEOLDateService.updateMultiEOLDate(idArray, eolDate, this.typeId, this.dateChange).subscribe(result => {
                ComponentEndOfLifeDateExpiredReloadCallback(1);
                closePopup('externalpagepopup');
                this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            });
        }
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

    cboDateChange_onclick(value: any) {
        this.dateChange = value;
        if (value == 1) {
            (<HTMLInputElement>document.getElementById("dateField")).style.display = "block";
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "none";
            (<HTMLInputElement>document.getElementById("dateField")).focus();
            this.inputDate.setDate('');
        }
        else if (value == 2) {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "block";
            (<HTMLInputElement>document.getElementById("dateField")).style.display = "none";
        }
        else {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "none";
            (<HTMLInputElement>document.getElementById("dateField")).style.display = "none";
        }
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
        }
        else if (this.mbp == MessageBoxButton.Cancel) {
        }
    }
}
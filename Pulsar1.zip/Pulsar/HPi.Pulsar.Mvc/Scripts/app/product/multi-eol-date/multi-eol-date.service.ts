﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-12-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="multi-eol-date.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { MultiEOLDateViewModel } from './multi-eol-date.viewmodel';

@Injectable()
export class MultiEOLDateService {

    constructor(private http: Http, private location: Location) {
    }

    getDeliverablesToUpdate(idList: any, typeId: number): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/GetDeliverablesToUpdate/' + idList + '/' + typeId));
    }

    updateMultiEOLDate(idArray: string, eolDate: string, typeId: number, dateChange: string): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/product/Product/UpdateMultiEOLDate/' + idArray + '/' + eolDate + '/' + typeId + '/' + dateChange));
    }
}
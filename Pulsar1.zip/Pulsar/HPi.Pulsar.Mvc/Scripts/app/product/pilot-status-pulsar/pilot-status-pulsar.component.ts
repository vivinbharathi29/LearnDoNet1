﻿import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location, DatePipe } from '@angular/common';
import { FormsModule, FormBuilder, Validators, ReactiveFormsModule, Form, NgForm, NgControl, FormArray, NgModel, FormGroup, FormControl } from '@angular/forms';
import { PilotStatusPulsarService } from './pilot-status-pulsar.service'
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../shared/messagebox/index';
import { CustomValidationService } from '../../shared/custom-validation.service'
import { ActivatedRoute, NavigationExtras, Params, Router, Route } from '@angular/router';
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'pilot-status',
    templateUrl: './pilot-status-pulsar.component.html'
})

export class PilotStatusPulsarComponent implements OnInit {
    id: number;
    pilotStatusInfoForm: FormGroup;
    errorMessage: string;
    productDeliverableViewModel: any;
    productID: any;
    versionID: any;
    productDeliverableReleaseID: any;
    showOnlyTargetedRelease: any;
    todayPageSection: any;
    mbp: MessageBoxButton;
    @ViewChild('dateInput') myDateInput: jqxDateTimeInputComponent;
    //showArticleListCallBack
    constructor(http: Http, private service: PilotStatusPulsarService, private fb: FormBuilder, private messageBox: MessageBox, private customValidationService: CustomValidationService, private ngZone: NgZone, private route: ActivatedRoute, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            popUpCallBackFn: (id, versionid, productReleaseId) => this.switchrelease(id, versionid, productReleaseId),
            component: this
        };

        this.pilotStatusInfoForm = this.fb.group({
            "Id": [''],
            "PMEmailIDs": [''],
            "DevEmail": [''],
            "DevCenter": [''],
            "Vendor": [''],
            "DeliverableName": [''],
            "Version": [''],
            "Revision": [''],
            "StatusName": [''],
            "Name": [''],
            "PartnerID": [''],
            "ModelNumber": [''],
            "PartNumber": [''],
            "Comments": [''],
            "ExistingPilotStatusID": [''],
            "PilotStatusID": [''],
            "TargetDate": [''],
            "PilotDate": [''],
            "QualStatus": [''],
            //"VersionID": [''],
            "IsDateFieldReq": [''],
            "IsCommentFieldReq": ['']
        });
        this.productID = this.route.snapshot.params['productID'];
        this.versionID = this.route.snapshot.params['versionID'];
        this.productDeliverableReleaseID = this.route.snapshot.params['productDeliverableReleaseID'];
    }
    existingPilotStatusID: any;
    getPilotStatus() {
        this.service.getPilotStatus(this.productID, this.versionID, this.productDeliverableReleaseID).subscribe(result => {
            this.productDeliverableViewModel = result.json();
            let date: any = new Date();//remove
            var datePipe = new DatePipe('en-US');
            date = datePipe.transform(this.productDeliverableViewModel.pilotDate, 'MM/dd/yyyy');
            (<HTMLInputElement>document.getElementById('PilotDate')).value = date;

            this.pilotStatusInfoForm = this.fb.group({
                "Id": [this.productDeliverableViewModel.id],
                "PMEmailIDs": [this.productDeliverableViewModel.pmEmailIDs],
                "DevEmail": [this.productDeliverableViewModel.devEmail],
                "DevCenter": [this.productDeliverableViewModel.devCenter],
                "Vendor": [this.productDeliverableViewModel.vendor],
                "DeliverableName": [this.productDeliverableViewModel.deliverableName],
                "Version": [this.productDeliverableViewModel.version],
                "Revision": [this.productDeliverableViewModel.revision],
                "StatusName": [this.productDeliverableViewModel.statusName],
                "Name": [this.productDeliverableViewModel.name],
                "PartnerID": [this.productDeliverableViewModel.partnerID],
                "ModelNumber": [this.productDeliverableViewModel.modelNumber],
                "PartNumber": [this.productDeliverableViewModel.partNumber],
                "Pass": [this.productDeliverableViewModel.pass],
                "Comments": [this.productDeliverableViewModel.pilotNotes],
                "ExistingPilotStatusID": [this.productDeliverableViewModel.existingPilotStatusID],
                "PilotStatusID": [this.productDeliverableViewModel.PilotStatusID],
                "TargetDate": [this.productDeliverableViewModel.targetDate],
                "PilotDate": [this.productDeliverableViewModel.pilotDate],
                "QualStatus": [this.productDeliverableViewModel.qualStatus],
                //  "VersionID": [this.productDeliverableViewModel.versionID],
                "IsDateFieldReq": [this.productDeliverableViewModel.isDateFieldReq],
                "IsCommentFieldReq": [this.productDeliverableViewModel.isCommentFieldReq]
            });
        });
    }

    isError: boolean = false;
    ErrorMessage: string[]
    SavePilotStatus(productDeliverableViewModel: FormGroup) {
        //this.ErrorMessage = [];
        //this.isError = false;
        this.versionID = this.route.snapshot.params['versionID'];
        this.ErrorMessage = [];
        this.isError = false;

        for (const control in this.pilotStatusInfoForm.controls) {
            for (const propertyName in this.pilotStatusInfoForm.controls[control].errors) {
                this.ErrorMessage.push(control + ' is ' + CustomValidationService.getValidatorErrorMessage(propertyName, this.pilotStatusInfoForm.controls[control]));
                this.isError = true;
            }
            switch (control) {
                case "PilotStatusID":
                    if (this.pilotStatusInfoForm.controls[control].value == -1) {
                        this.ErrorMessage.push("Pilot Status is Required");
                        this.isError = true;
                    }
                    break;
                case "Comments":
                    if (this.pilotStatusInfoForm.controls["IsCommentFieldReq"].value == true && (this.pilotStatusInfoForm.controls[control].value == "" || this.pilotStatusInfoForm.controls[control].value == null)) {
                        this.ErrorMessage.push(control + ' is Required');
                        this.isError = true;
                    }
                    break;
                case "PilotDate":
                    if (this.pilotStatusInfoForm.controls["IsDateFieldReq"].value == true && this.myDateInput.getText().trim() == "") {
                        this.ErrorMessage.push('You must supply a valid date.');
                        this.isError = true;
                    }
                    break;
            }
        }

        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            if ($('#hdnKeepItOpen').val() == 'false') {
                this.service.updatePilotStatus(productDeliverableViewModel, this.versionID).subscribe(result => {
                    ExpiredPilotStatusPopupCallBack(1);
                    this.cancelPopup();
                });

                //this.service.updatePilotStatus(this.pilotStatusInfoForm);
                //this.cancelPopup();
            }
            else {
                //this.service.updatePilotStatus(this.pilotStatusInfoForm);
                this.service.updatePilotStatus(productDeliverableViewModel, this.versionID).subscribe(result => {
                    ExpiredPilotStatusPopupCallBack(1);
                    //this.cancelPopup();
                });
            }
        }
    }
    pilotStatusChange() {
        let pilotStatusName: any;
        var pilotStatus = <HTMLSelectElement>document.getElementById('PilotStatusID');
        if (pilotStatus.selectedIndex != 0) {
            (<HTMLInputElement>document.getElementById('StatusName')).innerText = pilotStatus.options[pilotStatus.selectedIndex].textContent;
        }
        var pilotStatusVM = this.productDeliverableViewModel.pilotStatusViewModel;
        var exist = false;
        if (pilotStatusVM != null) {
            {
                for (let pilot of pilotStatusVM) {
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id && pilot.commentsRequired == true) {
                        (<HTMLSpanElement>document.getElementById('commentReq')).style.display = '';
                        this.pilotStatusInfoForm.controls["IsCommentFieldReq"].setValue(true);
                        break;
                    }
                    else {
                        (<HTMLSpanElement>document.getElementById('commentReq')).style.display = 'none';
                        this.pilotStatusInfoForm.controls["IsCommentFieldReq"].setValue(false);
                    }
                    if (exist == true)
                        break;
                }
                exist = false;
                for (let pilot of pilotStatusVM) {
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id && (pilot.dateField == 2 || pilot.dateField == 1)) {
                        (<HTMLLabelElement>document.getElementById('pilotDateField')).style.display = '';
                        $('#PilotDate').attr({ 'style': 'display:' });
                    }
                    else {
                        (<HTMLLabelElement>document.getElementById('pilotDateField')).style.display = 'none';
                        $('#PilotDate').attr({ 'style': 'display:none' });
                    }
                    if (exist == true)
                        break;
                }
                exist = false;
                for (let pilot of pilotStatusVM) {
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id) {
                        exist = true;
                    }
                    if ((<HTMLOptionElement>pilotStatus.options[pilotStatus.selectedIndex]).value == pilot.id && pilot.dateField == 1) {
                        (<HTMLSpanElement>document.getElementById('dateReq')).style.display = '';
                        this.pilotStatusInfoForm.controls["IsDateFieldReq"].setValue(true);
                    }
                    else {
                        (<HTMLSpanElement>document.getElementById('dateReq')).style.display = 'none';
                        this.pilotStatusInfoForm.controls["IsDateFieldReq"].setValue(false);
                    }
                    if (exist == true)
                        break;
                }
            }
        }
    }
    ngOnInit(): void {
        this.getPilotStatus();
    }

    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
    switchrelease(ProdID, VersionID, ProductDeliverableReleaseID) {
        var isModified = false;
        $("#hdnKeepItOpen").val(true);
        var pilotStatus = <HTMLSelectElement>document.getElementById('PilotStatusID');
        var existingPilotStatusID = this.productDeliverableViewModel.existingPilotStatusID;
        var existingComments = this.productDeliverableViewModel.existingComments;
        var existingPilotDate = this.productDeliverableViewModel.pilotDate;
        if (pilotStatus.options[pilotStatus.selectedIndex].nodeValue != existingPilotStatusID) {
            isModified = true;
        }
        else if (existingComments != $("#Comments").val()) {
            isModified = true;
        }
        else if (existingPilotDate != $("#PilotDate").val()) {
            isModified = true;
        }

        if (isModified) {
            this.messageBox.Show("Pilot Status", "Do you want to save your changes for this Release?", MessageBoxType.OKCancel, MessageBoxIcon.Information, "400", this.confirmationMessage);

        }
        else {
            //this.cancelPopup();
            //this.router.navigate([{ outlets: { 'externalpopupWindow': ['pilotstatuspulsar', ProdID, VersionID, ProductDeliverableReleaseID, this.todayPageSection, this.showOnlyTargetedRelease] } }]);
            //modalPopup.show('#externalpagepopup', "70%", "350px", "Pilot Status Pulsar");
            this.cancelPopup();
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['pilotstatuspulsar', ProdID, VersionID, ProductDeliverableReleaseID, this.todayPageSection, this.showOnlyTargetedRelease] } }]);
            modalPopup.show('#externalpagepopup', "70%", "450px", "Pilot Status Pulsar");
        }
    }
    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
            this.SavePilotStatus(this.productDeliverableViewModel);
        }
        else if (this.mbp == MessageBoxButton.Cancel) {

        }
    }

}
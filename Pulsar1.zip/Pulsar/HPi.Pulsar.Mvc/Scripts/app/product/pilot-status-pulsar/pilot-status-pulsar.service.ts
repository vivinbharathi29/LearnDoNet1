﻿import { Component, ViewChild, AfterViewInit, NgZone,Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';

@Injectable()
export class PilotStatusPulsarService{
    constructor(private http: Http, private location: Location) {

    }

    getPilotStatus(productID: any = null, versionID: any = null, productDeliverableReleaseID:any=null)
    {
        return this.http.get(this.location.prepareExternalUrl('product/Product/GetPilotStatusPulsar?productId=' + productID + '&versionId=' + versionID + '&productDeliverableReleaseId=' + productDeliverableReleaseID));
    }
   

    updatePilotStatus(productDeliverableViewModel: any,versionId:any) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('product/Product/UpdatePilotStatusPulsar?versionId=' + versionId), productDeliverableViewModel, {
            headers: headers
        }); 
    }

}
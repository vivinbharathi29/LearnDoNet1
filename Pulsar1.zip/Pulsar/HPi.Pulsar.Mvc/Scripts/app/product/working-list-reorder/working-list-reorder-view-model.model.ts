/// <reference path="reorder-view-model.model.ts" />
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 08/30/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="working-list-reorder-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { ReorderViewModel } from './reorder-view-model.model';

export class WorkingListReorderViewModel {
    id: number;
    projectId: number;
    reportOption: number;
    productName: string;
    employeeName: string;
    positions: number[];
    reorderList: ReorderViewModel[];
}
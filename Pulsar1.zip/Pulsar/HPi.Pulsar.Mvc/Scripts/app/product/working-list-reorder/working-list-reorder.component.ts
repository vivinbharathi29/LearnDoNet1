﻿import { Component, OnInit, Input, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { WorkingListReorderService } from './working-list-reorder-service';
import { WorkingListReorderViewModel } from './working-list-reorder-view-model.model';
import { ReorderViewModel } from './reorder-view-model.model';

@Component({
    selector: 'working-list-reorder',
    templateUrl: './working-list-reorder.component.html',
    providers: [WorkingListReorderService]
})
export class WorkingListReorderComponent implements OnInit, AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;

    workingListReorderViewModel: WorkingListReorderViewModel;
    reorderList: ReorderViewModel[];
    errorMessage: string = "";
    heading: string = "";
    selectedPosition: any = 1;

    constructor(private workingListReorderService: WorkingListReorderService, private route: ActivatedRoute, private router: Router) {
        this.errorMessage = "";
        this.workingListReorderViewModel = new WorkingListReorderViewModel();
        this.workingListReorderViewModel.id = route.snapshot.params['id'];
        this.workingListReorderViewModel.projectId = route.snapshot.params['projectId'];
        this.workingListReorderViewModel.reportOption = route.snapshot.params['reportOption'];

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightWithContent;
        this.jqxGridConfig.settings.pageable = false;
        this.jqxGridConfig.datafields = [
            { name: 'oldOrder', map: 'oldOrder' },
            { name: 'newOrder', map: 'newOrder', type: 'number' },
            { name: 'id', map: 'id' },
            { name: 'priority', map: 'priority' },
            { name: 'product', map: 'product', type: 'string' },
            { name: 'summary', map: 'summary', type: 'string' },
            { name: 'owner', map: 'owner', type: 'string' }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'Old',
                datafield: 'oldOrder', width: '5%', filtertype: 'number'
            },
            {
                text: 'New',
                datafield: 'newOrder', width: '5%', filtertype: 'number', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ID',
                datafield: 'id', width: '8%', filtertype: 'number',
            },
            {
                text: 'Priority',
                datafield: 'priority', width: '5%', filtertype: 'number'
            },
            {
                text: 'Product',
                datafield: 'product', width: '20%', filtertype: 'input'
            },
            {
                text: 'Summary',
                datafield: 'summary', width: '57%', filtertype: 'input'
            }
        ];
    }

    //call services to get value from db.
    ngOnInit(): void {

    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getWorkingListOrder();
    }

    getWorkingListOrder(): void {
        this.myGrid.showdefaultloadelement(true);
        this.workingListReorderService.getWorkingListOrder(this.workingListReorderViewModel.id, this.workingListReorderViewModel.projectId, this.workingListReorderViewModel.reportOption)
            .subscribe(
            data => {
                this.workingListReorderViewModel = data.json();
                this.heading = "Reorder " + this.workingListReorderViewModel.productName + " Working List for " + this.workingListReorderViewModel.employeeName;
                this.jqxGridConfig.localdata = this.workingListReorderViewModel.reorderList;
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            }
            );
    }

    updateWorkingListOrder(): void {
        this.reorderList = this.jqxGridConfig.settings.source.records;
        console.log(this.reorderList);
        this.workingListReorderService.updateWorkingListOrder(this.reorderList).subscribe(
            (data) => {
                var success = data.json();
                if (success) {
                    this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                    popupCallBack(1);
                    closePopup('externalpagepopup');
                }
                else {
                    this.errorMessage = "Unable to update action item order";
                }
            },
            Error => {
                console.log('Failed', Error);
                this.errorMessage = "Unable to update action item order";
            }
        );
    }

    cancel(): void {
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        let val: any;
        if (value != 0) {
            val = Number(value);
        }
        else {
            val = "Set";
        }
        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='aLink'/>" + val + "</a>";
        return element[0].outerHTML;
    };

    onCellClick(event: any) {        
        var column = event.args.datafield;
        var rowindex = event.args.rowindex;
        if (column == "newOrder") {
            let index: number = this.workingListReorderViewModel.positions.indexOf(Number(this.selectedPosition));
            if (index != -1) {
                this.workingListReorderViewModel.positions.splice(index, 1);
            }
            this.myGrid.setcellvalue(rowindex, "newOrder", Number(this.selectedPosition));            
            if (typeof (this.workingListReorderViewModel.positions[index]) != "undefined") {
                this.selectedPosition = this.workingListReorderViewModel.positions[index];
            }
            else {
                this.selectedPosition = this.workingListReorderViewModel.positions[0];
            }            
        }
    }
}

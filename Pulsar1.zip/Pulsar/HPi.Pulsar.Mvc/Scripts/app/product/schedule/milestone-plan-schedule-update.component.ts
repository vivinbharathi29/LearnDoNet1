﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09/08/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="milestone-plan-schedule-update.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { jqxDateTimeInputComponent } from '../../jqwidgets-ts/angular_jqxdatetimeinput';
import { ScheduleService } from './milestone-plan-schedule-update.service';

@Component({
    selector: 'milestone-schedule-update',
    templateUrl: './milestone-plan-schedule-update.component.html',
    providers: [ScheduleService]
})
export class ScheduleComponent implements OnInit {
    @ViewChild('dateInput') inputDate: jqxDateTimeInputComponent;
    versionId: number;
    errorMessage: string;
    deliverableName: string;
    scheduleUpdateViewModel: any;

    constructor(private scheduleService: ScheduleService, private route: ActivatedRoute, private router: Router) {
        this.versionId = route.snapshot.params['versionId'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.getDeliverableMilestoneList();
    }

    getDeliverableMilestoneList() {
        this.scheduleService.getDeliverableMilestoneList(this.versionId).subscribe(result => {
            this.scheduleUpdateViewModel = result.json();
            if (result.json().length > 0) {
                this.errorMessage = result.json()[0]['errorMessage'];
                this.deliverableName = result.json()[0]['deliverableName'];
            }
        });
    }

    cmdComplete_onclick(): void {
        var tagDateList = '';
        var txtDateList = '';
        var txtDateId = '';
        var strMilestones = ((<HTMLInputElement>document.getElementById("txtIdList")).value);
        var tagDate = <HTMLCollection>document.getElementsByClassName('tagDate');
        var txtDate = <HTMLCollection>document.getElementsByClassName('txtDate');
        if (tagDate.length > 0) {
            for (var i = 0; i < tagDate.length; i++) {
                tagDateList += (<HTMLInputElement>tagDate[i]).value.split('/').join('-') + " ";
            }
        }
        if (txtDate.length > 0) {
            for (var i = 0; i < txtDate.length; i++) {
                txtDateList += (<HTMLInputElement>txtDate[i].children[0]).value.split('/').join('-') + " ";
                txtDateId += (<HTMLInputElement>txtDate[i]).id + " ";
            }
        }
        var idArray = strMilestones;
        var dateArray = txtDateList;
        var tagArray = tagDateList;
        var dateIdArray = txtDateId;

        this.scheduleService.updateScheduleMilestonePlan(idArray, dateArray, tagArray, dateIdArray, this.versionId).subscribe(result => {
            popupCallBack(1);
            closePopup('externalpagepopup');
            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        });
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
}
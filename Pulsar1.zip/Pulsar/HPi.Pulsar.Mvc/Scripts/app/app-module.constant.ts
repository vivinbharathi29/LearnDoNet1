﻿import { RouterModule, Routes, ActivatedRoute } from '@angular/router';

import { jqxTabsComponent } from './jqwidgets-ts/angular_jqxtabs';

import { TodayTabsComponent } from './today/today_page/today-tabs/today-tabs.component';
import { AdminAlertsTabComponent } from './today/today_page/today-tabs/tab-content/admin-alerts.component';
import { AlertsTabComponent } from './today/today_page/today-tabs/tab-content/alerts.component';
import { DCRSTabComponent } from './today/today_page/today-tabs/tab-content/dcrs.component';
import { MyItemsTabComponent } from './today/today_page/today-tabs/tab-content/my-items.component';
import { ProductAlertsTabComponent } from './today/today_page/today-tabs/tab-content/product-alerts.component';
import { PulsarNewsTabComponent } from './today/today_page/today-tabs/tab-content/pulsar-news.component';
import { TestTabComponent } from './today/today_page/today-tabs/tab-content/test.component';
import { FavoritesTabComponent } from './today/today_page/today-tabs/tab-content/favorites.component';
import { TodayPageTilesComponent } from './today/today_page/dashboard/today-tiles.component';
import { BreadCrumbComponent } from './today/today_page/dashboard/breadcrumb.component';
import { QuickSearchComponent } from './today/today_page/quick_search/quick-search.component';

import { UserInfoService } from './today/today_page/dashboard/user-info.service';
import { TodayTabsService } from './today/today_page/today-tabs/today-tabs.service';
import { QuickPageService } from "./today/today_page/quick_search/quick-search.service";

export const appRoutes: Routes = [
    { path: '', redirectTo: '/today', pathMatch: 'full' },
    { path: 'today', component: TodayTabsComponent },
    { path: '**', component: TodayTabsComponent }
];

export const appComponents = [
    TodayTabsComponent, AdminAlertsTabComponent, AlertsTabComponent, DCRSTabComponent, MyItemsTabComponent, ProductAlertsTabComponent, PulsarNewsTabComponent,
    TestTabComponent, TodayPageTilesComponent, QuickSearchComponent, BreadCrumbComponent, jqxTabsComponent, FavoritesTabComponent
];

export const appProviders = [
    UserInfoService, TodayTabsService, QuickPageService
];
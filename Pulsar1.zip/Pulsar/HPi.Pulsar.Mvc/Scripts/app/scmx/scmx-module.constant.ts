﻿import { Routes } from '@angular/router';

import { AvNumberToDeliverableComponent } from './add-av-no-to-deliverable/add-av-no-to-deliverable.component';

export const scmxRoutes: Routes = [
    { path: 'avnotodeliverable/:avCreateId/:deliverableRootId/:productBrandId/:deliverableName', component: AvNumberToDeliverableComponent, outlet: 'externalpopupWindow' },
    { path: 'avnotodeliverablepulsar2/:avCreateId/:deliverableRootId/:productBrandId/:deliverableName', component: AvNumberToDeliverableComponent}
];

//Declare all the components created for product module
export const scmxComponents = [
    AvNumberToDeliverableComponent
];

//Providers that needs to be shared across multiple components/modules can be declared here. Otherwise declare providers inside respective components
export const scmxProviders = [
];
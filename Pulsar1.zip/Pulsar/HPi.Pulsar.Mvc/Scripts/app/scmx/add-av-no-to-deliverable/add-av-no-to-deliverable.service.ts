﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09-20-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="add-av-no-to-deliverable.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

import { AvNumberToDeliverableViewModel } from './add-av-no-to-deliverable.viewmodel';

@Injectable()
export class AvNumberToDeliverableService {

    constructor(private http: Http, private location: Location) {
    }

    updateAvNoToDeliverables(avCreateId: number, deliverableRootId: number, productBrandId: number, avNo: string, chkUpdateDescription: boolean): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/scmx/AvDetail/UpdateAvDetail/' + avCreateId + '/' + deliverableRootId + '/' + productBrandId + '/' + avNo + '/' + chkUpdateDescription));
    }
}
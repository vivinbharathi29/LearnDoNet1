﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 09/20/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 09/21/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="add-av-no-to-deliverable.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ActivatedRoute, Router, Params } from '@angular/router';

import { AvNumberToDeliverableService } from './add-av-no-to-deliverable.service';
import { AvNumberToDeliverableViewModel } from './add-av-no-to-deliverable.viewmodel';

@Component({
    selector: 'add-av-no-to-deliverable',
    templateUrl: './add-av-no-to-deliverable.component.html',
    providers: [AvNumberToDeliverableService]
})
export class AvNumberToDeliverableComponent implements OnInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    avCreateId: number;
    deliverableRootId: number;
    productBrandId: any;
    avNo: any;
    deliverableName: any;
    deliverable: string;

    constructor(private avNumberToDeliverableService: AvNumberToDeliverableService, private route: ActivatedRoute, private router: Router) {
        this.avCreateId = route.snapshot.params['avCreateId'];
        this.deliverableRootId = route.snapshot.params['deliverableRootId'];
        this.productBrandId = route.snapshot.params['productBrandId'];
        this.deliverableName = route.snapshot.params['deliverableName'];
    }

    //call services to get value from db.
    ngOnInit(): void {
        this.getDeliverableName();
    }

    getDeliverableName() {
        this.deliverable = this.deliverableName;
    }

    cmdComplete_onclick(): void {
        var comments = "";
        var chkUpdateDescription = false;
        if ((<HTMLInputElement>document.getElementById("txtAV")).value != "") {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "none";
            comments = (<HTMLInputElement>document.getElementById("txtAV")).value;
            chkUpdateDescription = (<HTMLInputElement>document.getElementById("cbUpdateDesc")).checked;
            this.avNumberToDeliverableService.updateAvNoToDeliverables(this.avCreateId, this.deliverableRootId, this.productBrandId, comments, chkUpdateDescription).subscribe(result => {
                popupCallBack(1);
                closePopup('externalpagepopup');
                this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            });
        }
        else {
            (<HTMLInputElement>document.getElementById("deactivateWarning")).style.display = "block";
        }
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
}
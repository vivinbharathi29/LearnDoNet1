﻿import { NgModule } from '@angular/core';
import { RouterModule, Routes, ActivatedRoute } from '@angular/router';
import { scmxRoutes } from './scmx-module.constant';

@NgModule({
    imports: [RouterModule.forChild(scmxRoutes)],
    exports: [RouterModule]
})
export class SCMXRoutingModule { }

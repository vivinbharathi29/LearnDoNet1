﻿import { Component, ViewChild, AfterViewInit, NgZone,Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import {SupportTicketViewModel } from './ticket.viewmodel'
@Injectable()
export class TicketService{
    constructor(private http: Http, private location: Location) {

    }

    getTicketInfo(id:number)
    {
        return this.http.get(this.location.prepareExternalUrl('today/TodayPage/Ticket/' + id));
    }
    GetAllSupportCategories(id: number) {
        return this.http.get(this.location.prepareExternalUrl('today/TodayPage/GetAllSupportCategories?projectID=' + id));
    }
    UpdateTicketInfo(supportTicketViewModel,copyMe,copyTeam) {
       // var supportTicketViewModel = { supportTicketViewModel};
        var headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/UpdateTicket?copyMe=' + copyMe + '&copyTeam=' + copyTeam), supportTicketViewModel, {
            headers: headers
        });
               
    }

}
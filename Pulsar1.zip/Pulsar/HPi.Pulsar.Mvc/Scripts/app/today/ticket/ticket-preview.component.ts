﻿import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { FormsModule, FormBuilder, Validators, ReactiveFormsModule, Form, NgForm, NgControl, FormArray, NgModel, FormGroup, FormControl } from '@angular/forms';
import { TicketPreviewService } from './ticket-preview.service'
import { SupportTicketViewModel } from './ticket.viewmodel'
import { CustomValidationService } from '../../shared/custom-validation.service'
import { ActivatedRoute, NavigationExtras, Params, Router } from '@angular/router';

@Component({
    selector: 'ticketpreview',
    templateUrl: './ticket-preview.component.html',
    styles: [`
.hideSection
{
    display:none;
}
.table {
    display: table;
    width: 100%;
}
.row {
    display: table-row;
}
.cell {
    display: table-cell;
    width: 33%;
    border-bottom: 1px solid black;
    border-top: 1px solid black;
    border-left: 1px solid black;
    border-right: 1px solid black;
}
`]
})

export class TicketPreviewComponent implements OnInit {
    public id: number;
    //public supportTicketViewModel: SupportTicketViewModel;
    ticketInfoForm: FormGroup;
    errorMessage: string;
    supportTicketPreviewViewModel: any;
    public attachement1: boolean = false;
    public attachement2: boolean = false;
    public attachement3: boolean = false;
    //showArticleListCallBack
    constructor(http: Http, private service: TicketPreviewService, private fb: FormBuilder, private customValidationService: CustomValidationService, private ngZone: NgZone, private activatedRoute: ActivatedRoute, private router: Router) {
        //window['angularComponentRef'] = { component: this, zone: ngZone };
        //window['angularComponentRef'] = {
        //    zone: this.ngZone,
        //    ShowArtileListCallBackFn: (value) => this.showArticleListCallBack(value),
        //    component: this
        //};

        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.id = params['TicketNumber'];
        });
        this.ticketInfoForm = this.fb.group({
            //"accessorypath": ['', Validators.compose([Validators.required])],
            "ID": ['', Validators.compose([Validators.required])],
            "Summary": ['', Validators.compose([Validators.required])],
            "SubmitterName": [''],
            "SubmitterEmail": [''],
            "Resolution": [''],
            "Details": [''],
            "Attachment1": [''],
            "Attachment2": [''],
            "Attachment3": [''],
            "FileName1": [''],
            "FileName2": [''],
            "FileName3": [''],
            "OwnerID": [0, Validators.compose([Validators.required])],
            "OldOwnerID": [''],
            "OwnerName": [''],
            "ProjectID": [0, Validators.compose([Validators.required])],
            "CategoryID": [0, Validators.compose([Validators.required])],
            "TypeID": [0, Validators.compose([Validators.required])],
            "StatusID": [0, Validators.compose([Validators.required])],
            "ActionItemID": [''],
            "DateCreated": [''],
            "DateClosed": [''],
            "CopyMe": [''],
            "CopyTeam": [''],
            "ConvertActionItem": [''],
            "SubmitterPartnerID": ['']
        });

        //   this.GetTicketInfo();
    }
    GetTicketPreviewInfo() {
        
        this.service.getTicketPreviewInfo(this.id).subscribe(result => {
            this.supportTicketPreviewViewModel = result.json();
            
            if (this.supportTicketPreviewViewModel.attachment1 != "")
            {
                this.attachement1 = true;
            }
            if (this.supportTicketPreviewViewModel.attachment2 != "") {
                this.attachement2 = true;
            }
            if (this.supportTicketPreviewViewModel.attachment3 != "") {
                this.attachement3 = true;
            }
            //this.ticketInfoForm = this.fb.group({

            //    "ID": [this.supportTicketViewModel.id, Validators.compose([Validators.required])],
            //    "Summary": [this.supportTicketViewModel.summary, Validators.compose([Validators.required])],
            //    "SubmitterName": [this.supportTicketViewModel.submitterName],
            //    "SubmitterEmail": [this.supportTicketViewModel.submitterEmail],
            //    "Resolution": [this.supportTicketViewModel.resolution],
            //    "Details": [this.supportTicketViewModel.details],
            //    "Attachment1": [this.supportTicketViewModel.attachment1],
            //    "Attachment2": [this.supportTicketViewModel.attachment2],
            //    "Attachment3": [this.supportTicketViewModel.attachment3],
            //    "FileName1": [this.supportTicketViewModel.fileName1],
            //    "FileName2": [this.supportTicketViewModel.fileName2],
            //    "FileName3": [this.supportTicketViewModel.fileName3],
            //    "OwnerID": [this.supportTicketViewModel.ownerID, Validators.compose([Validators.required])],
            //    "OwnerName": [this.supportTicketViewModel.ownerName],
            //    "ProjectID": [this.supportTicketViewModel.projectID, Validators.compose([Validators.required])],
            //    "CategoryID": [this.supportTicketViewModel.categoryID, Validators.compose([Validators.required])],
            //    "TypeID": [this.supportTicketViewModel.typeID, Validators.compose([Validators.required])],
            //    "StatusID": [this.supportTicketViewModel.statusID, Validators.compose([Validators.required])],
            //    "ActionItemID": [this.supportTicketViewModel.actionItemID],
            //    "DateCreated": [this.supportTicketViewModel.dateCreated],
            //    "DateClosed": [this.supportTicketViewModel.dateClosed],
            //    "CopyMe": [this.supportTicketViewModel.copyMe],
            //    "CopyTeam": [this.supportTicketViewModel.copyTeam],
            //    "ConvertActionItem": [''],
            //    "OldOwnerID": [this.supportTicketViewModel.oldOwnerID],
            //    "SubmitterPartnerID": [this.supportTicketViewModel.submitterPartnerID]
            //});
            //var requireResolution = <HTMLDivElement>document.getElementById('requireResolution');

            //if (this.supportTicketViewModel.statusID != 2) {
            //    requireResolution.style.display = "none"
            //}
            //else {
            //    requireResolution.style.display = "";
            //    // ActionItemRow.style.display = "none";
            //}
        });
    }

    public isError: boolean = false;
    public ErrorMessage: string[]
    
    ngOnInit(): void {
        this.GetTicketPreviewInfo();
    }

    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }
}
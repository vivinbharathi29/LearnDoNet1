﻿import { Component, ViewChild, AfterViewInit, NgZone, NgModule, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { FormsModule, FormBuilder, Validators, ReactiveFormsModule, Form, NgForm, NgControl, FormArray, NgModel, FormGroup, FormControl } from '@angular/forms';
import { TicketService } from './ticket.service'
import { SupportTicketViewModel } from './ticket.viewmodel'
import { CustomValidationService } from '../../shared/custom-validation.service'
import { ActivatedRoute, NavigationExtras, Params, Router } from '@angular/router';
declare let $: any;
@Component({
    selector: 'ticket',
    templateUrl: './ticket.component.html',

})

export class TicketComponent implements OnInit {
    id: number;
    //public supportTicketViewModel: SupportTicketViewModel;
    ticketInfoForm: FormGroup;
    errorMessage: string;
    supportTicketViewModel: any;
    //showArticleListCallBack
    notifyEmailIds: string;



    constructor(http: Http, private service: TicketService, private fb: FormBuilder, private customValidationService: CustomValidationService, private ngZone: NgZone, private activatedRoute: ActivatedRoute, private router: Router, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            ShowArtileListCallBackFn: (value) => this.showArticleListCallBack(value),
            updateEmailsPopUpCallBackFn: (value) => this.updateEmailsPopUpCallBackFn(value),
            component: this
        };

        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.id = params['TicketNumber'];
        });
        this.ticketInfoForm = this.fb.group({
            //"accessorypath": ['', Validators.compose([Validators.required])],
            "ID": ['', Validators.compose([Validators.required])],
            "Summary": ['', Validators.compose([Validators.required])],
            "SubmitterName": [''],
            "SubmitterEmail": [''],
            "Resolution": [''],
            "Details": [''],
            "Attachment1": [''],
            "Attachment2": [''],
            "Attachment3": [''],
            "FileName1": [''],
            "FileName2": [''],
            "FileName3": [''],
            "OwnerID": [Validators.compose([Validators.required])],
            "OldOwnerID": [''],
            "OwnerName": [''],
            "ProjectID": [Validators.compose([Validators.required])],
            "CategoryID": [Validators.compose([Validators.required])],
            "TypeID": [Validators.compose([Validators.required])],
            "StatusID": [Validators.compose([Validators.required])],
            "ActionItemID": [''],
            "DateCreated": [''],
            "DateClosed": [''],
            //"CopyMe": [''],
            //"CopyTeam": [''],
            //"ConvertActionItem": [''],
            "SubmitterPartnerID": ['']
        });

        //   this.GetTicketInfo();
    }
    GetTicketInfo() {
        this.service.getTicketInfo(this.id).subscribe(result => {
            this.supportTicketViewModel = result.json();
            this.ticketInfoForm = this.fb.group({

                "ID": [this.supportTicketViewModel.id, Validators.compose([Validators.required])],
                "Summary": [this.supportTicketViewModel.summary, Validators.compose([Validators.required])],
                "SubmitterName": [this.supportTicketViewModel.submitterName],
                "SubmitterEmail": [this.supportTicketViewModel.submitterEmail],
                "Resolution": [this.supportTicketViewModel.resolution],
                "Details": [this.supportTicketViewModel.details],
                "Attachment1": [this.supportTicketViewModel.attachment1],
                "Attachment2": [this.supportTicketViewModel.attachment2],
                "Attachment3": [this.supportTicketViewModel.attachment3],
                "FileName1": [this.supportTicketViewModel.fileName1],
                "FileName2": [this.supportTicketViewModel.fileName2],
                "FileName3": [this.supportTicketViewModel.fileName3],
                "OwnerID": [this.supportTicketViewModel.ownerID, Validators.compose([Validators.required])],
                "OwnerName": [this.supportTicketViewModel.ownerName],
                "ProjectID": [this.supportTicketViewModel.projectID, Validators.compose([Validators.required])],
                "CategoryID": [this.supportTicketViewModel.categoryID, Validators.compose([Validators.required])],
                "TypeID": [this.supportTicketViewModel.typeID, Validators.compose([Validators.required])],
                "StatusID": [this.supportTicketViewModel.statusID, Validators.compose([Validators.required])],
                "ActionItemID": [this.supportTicketViewModel.actionItemID],
                "DateCreated": [this.supportTicketViewModel.dateCreated],
                "DateClosed": [this.supportTicketViewModel.dateClosed],
                //"CopyMe": [this.supportTicketViewModel.copyMe],
                //"CopyTeam": [this.supportTicketViewModel.copyTeam],
                //"ConvertActionItem": [''],
                "OldOwnerID": [this.supportTicketViewModel.oldOwnerID],
                "SubmitterPartnerID": [this.supportTicketViewModel.submitterPartnerID]
            });
            //var requireResolution = <HTMLDivElement>document.getElementById('requireResolution');

            //if (this.supportTicketViewModel.statusID !=2) {
            //    requireResolution.style.display = "none"
            //}
            //else {
            //    requireResolution.style.display = "";
            //    // ActionItemRow.style.display = "none";
            //}
        });
    }

    convertAction(Id: any) {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['action', Id, 0, 0, 0, null, 0, 0] } }]);
        modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");
    }
    isError: boolean = false;
    ErrorMessage: string[]

    SaveTicket(ticketInfo: FormGroup) {
        this.ErrorMessage = [];
        this.isError = false;
        var chkCopyMe = <HTMLInputElement>document.getElementById("chkCopyMe");
        var chkCopyTeam = <HTMLInputElement>document.getElementById("chkCopyTeam");

        for (const control in this.ticketInfoForm.controls) {
            //for (const propertyName in this.ticketInfoForm.controls[control].errors) {
            //    this.ErrorMessage.push(control + ' is ' + CustomValidationService.getValidatorErrorMessage(propertyName, this.ticketInfoForm.controls[control]));
            //    this.isError = true;
            //}
            if (control == "CategoryID" || control == "OwnerID" || control == "ProjectID" || control == "StatusID") {
                if (this.ticketInfoForm.controls[control].value == 0) {
                    this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                    this.isError = true;
                }

            }
            else if (control == "Resolution") {
                if ((this.ticketInfoForm.controls["StatusID"].value == 2) && (this.ticketInfoForm.controls[control].value == null || this.ticketInfoForm.controls[control].value == "")) {

                    this.ErrorMessage.push('Response is Required');
                    this.isError = true;
                }
            }
            else if (control == "Summary") {
                if (this.ticketInfoForm.controls[control].value == "") {
                    this.ErrorMessage.push('Question/Request is Required');
                    this.isError = true;
                }
            }
            else if (control == "TypeID") {
                if (this.ticketInfoForm.controls[control].value == -1) {
                    this.ErrorMessage.push(control.replace("ID", "") + ' is Required');
                    this.isError = true;
                }
            }
        }
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            var copyMe = chkCopyMe != null && chkCopyMe != undefined ? chkCopyMe.value : null;
            var copyTeam = chkCopyTeam != null && chkCopyTeam != undefined ? chkCopyTeam.value : null;
            this.service.UpdateTicketInfo(ticketInfo, copyMe, copyTeam).subscribe(result => {


                var chkActionItem = <HTMLInputElement>document.getElementById("chkActionItem");
                if (chkActionItem != null && chkActionItem != undefined) {
                    if (chkActionItem.checked && chkActionItem.value == "1") {
                        MyOpenTicketsCallBack();
                        closePopup('externalpagepopup');
                        this.router.navigate([{ outlets: { 'externalpopupWindow': ['action', 0, 0, 0, 0, 2, 0, this.id, 'ticket'] } }]);
                        modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");

                    }
                    else {
                        MyOpenTicketsCallBack();
                        closePopup('externalpagepopup');
                        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                    }
                }
                else {
                    MyOpenTicketsCallBack();
                    closePopup('externalpagepopup');
                    this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
                }
            });

        }
    }
    ngOnInit(): void {
        this.GetTicketInfo();
        $('ticket').parent().removeClass();
    }

    showArticleListCallBack(ArticleIDList) {
        var IDArray;
        var i;
        var strURL;
        var hostName;
        var SubmitterPartnerID = <HTMLInputElement>document.getElementById('SubmitterPartnerID');
        var txtResolution = <HTMLInputElement>document.getElementById('txtResolution');
        if (SubmitterPartnerID.value != "1")
        {
            hostName = window.location.host;
            if (hostName.indexOf("twn") == "-1")
                strURL = "https://prp-pulsar.houston.hp.com/excalibur/";
            else
                strURL = "https://pulsarwebtwn.prp.ext.hp.com/excalibur/";
        }
        else
          //  strURL = "http://pulsarweb.usa.hp.com/Excalibur/";
        strURL = "http://" + window.location.host + "/Excalibur/";
        if (typeof (ArticleIDList) != "undefined") {
            if (ArticleIDList != "0") {
                IDArray = ArticleIDList.split(",");
                txtResolution.value = txtResolution.value + "\r\r<u>Related Articles</u>\r"
                for (i = 0; i < IDArray.length; i++)
                    txtResolution.value = txtResolution.value + "<a href=\"" + strURL + "Support/Preview.asp?ID=" + IDArray[i] + "\">Article " + IDArray[i] + "</a>\r"

            }
        }
    }

    cboStatus_onchange() {
        var cboStatus = <HTMLSelectElement>document.getElementById('StatusID');
        var requireResolution = <HTMLSpanElement>document.getElementById('requireResolution');
        var notifyRow = <HTMLDivElement>document.getElementById('notifyRow');
        var notifyRowWithButton = <HTMLDivElement>document.getElementById('notifyRowWithButton');
        if (cboStatus.options[cboStatus.selectedIndex].textContent.trim() == "Closed") {
            requireResolution.style.display = "";
            notifyRow.style.display = "";
            notifyRowWithButton.style.display = "";
            // ActionItemRow.style.display = "";
        }
        else {
            requireResolution.style.display = "none";
            notifyRow.style.display = "none";
            notifyRowWithButton.style.display = "none";
            // ActionItemRow.style.display = "none";
        }
    }
    onProjectChange(projectId) {
        this.service.GetAllSupportCategories(projectId).subscribe(supportCategories => {
            var categories = supportCategories.json();
            var sel = document.getElementById('CategoryID');
            $('#CategoryID').empty();
            let index: number = 0;
            for (let category of categories) {
                if (index == 0) {
                    var opt = document.createElement('option');
                    opt.innerHTML = "Select Category";
                    opt.value = "0";
                    opt.selected = true;
                    this.ticketInfoForm.controls["CategoryID"].setValue(0);
                    sel.appendChild(opt);
                }
                var opt = document.createElement('option');
                opt.innerHTML = category.name;
                opt.value = category.id;
                sel.appendChild(opt);
                index = index + 1;
            }
        });
    }
    cancelPopup() {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

    updateEmailsPopUpCallBackFn(value) {
        this.notifyEmailIds = value;
        var currentEmailIds = <HTMLInputElement>document.getElementById('txtNotify');
        var notifyEmailsIds;

        notifyEmailsIds = this.notifyEmailIds;

        (<HTMLInputElement>document.getElementById('txtNotify')).value = notifyEmailsIds;
    }
    AddEmail() {
        //var url = "/Excalibur/Email/AddressBook.asp?AddressList=" + $('#txtNotify').value;
        var selectedEmailIds = <HTMLInputElement>document.getElementById('txtNotify');
        var url = this.location.prepareExternalUrl("/core/User/AddressBook?AddressList=" + selectedEmailIds.value +"&PageName=Ticket");
        adjustableShowPopup(url, 'Add Email Address', "450px", "75%", "365px");
    }
}

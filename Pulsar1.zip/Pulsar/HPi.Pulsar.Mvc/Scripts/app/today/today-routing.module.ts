﻿import { NgModule } from '@angular/core';
import { RouterModule, Routes, ActivatedRoute } from '@angular/router';
import { todayRoutes } from './today-module.constant';

@NgModule({
    imports: [RouterModule.forChild(todayRoutes)],
    exports: [RouterModule]
})
export class TodayRoutingModule {

}

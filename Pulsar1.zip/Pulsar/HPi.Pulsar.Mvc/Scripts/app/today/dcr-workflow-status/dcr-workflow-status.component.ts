﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08/21/2017
// Last Modified By :
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-workflow-status.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridComponent } from '../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../shared/jqxgrid_helper/jqxgrid-configuration';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../shared/messagebox/index';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { DCRWorkflowStatusService } from './dcr-workflow-status.service';
import { DCRWorkflowStatusViewModel } from './dcr-workflow-status.viewmodel';

@Component({
    selector: 'dcr-workflow-status',
    templateUrl: './dcr-workflow-status.component.html'
})

export class DCRWorkflowStatusComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    mbp: MessageBoxButton;
    public enablemenu: boolean = true;
    public dcrId: any;
    public pvId: any;
    public milestoneComplete: any;
    public createdBy: any;
    public dateCreated: any;
    public workflowType: any;
    public isTerminate: any;
    public labelHeader: any;
    public dcrWorkflowStatus: DCRWorkflowStatusViewModel[];

    constructor(http: Http, private service: DCRWorkflowStatusService, private messageBox: MessageBox, private activatedRoute: ActivatedRoute, private _ngZone: NgZone, private router: Router) {
        this.dcrId = activatedRoute.snapshot.params['dcrId'];
        this.pvId = activatedRoute.snapshot.params['pvId'];
        this.milestoneComplete = activatedRoute.snapshot.params['milestoneComplete'];

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.settings.pageable = false;
        this.jqxGridConfig.datafields = [
            { name: 'milestone', map: 'milestone', type: 'string' },
            { name: 'status', map: 'status', type: 'string' },
            { name: 'assignedTo', map: 'assignedTo', type: 'string' },
            { name: 'comments', map: 'comments', type: 'string' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'Milestone', columngroup: 'DCRWorkflowStatus',
                datafield: 'milestone', width: '20%', filtertype: 'input'
            },
            {
                text: 'Status', columngroup: 'DCRWorkflowStatus',
                datafield: 'status', width: '20%', filtertype: 'input'
            },
            {
                text: 'Assigned To', columngroup: 'DCRWorkflowStatus',
                datafield: 'assignedTo', width: '20%', filtertype: 'input'
            },
            {
                text: 'Comments', columngroup: 'DCRWorkflowStatus',
                datafield: 'comments', width: '40%', filtertype: 'input'
            }
        ];
    }

    getDcrWorkflowStatus() {
        this.myGrid.showdefaultloadelement(true);
        this.milestoneComplete = "name";
        this.service.getDcrWorkflowStatus(this.dcrId, this.pvId, this.milestoneComplete).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            if (result.json().length > 0) {
                this.createdBy = result.json()[0]['createdBy'];
                this.dateCreated = result.json()[0]['dateCreated'];
                this.workflowType = result.json()[0]['workflowType'];
                this.isTerminate = result.json()[0]['isTerminate'];
                this.pvId = result.json()[0]['pvId'];
                this.labelHeader = result.json()[0]['labelHeader'];
            }
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getDcrWorkflowStatus();
    }

    cmdTerminateDcr_onclick(): void {
        this.messageBox.Show("DCR Workflow Status", "Are you sure you want to terminate this workflow?", MessageBoxType.OKCancel, MessageBoxIcon.Information, "400", this.confirmationMessage);
    }

    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
            this.service.terminateDcrWorkflowStatus(this.pvId).subscribe(result => {
                popupCallBack(1);
                closePopup('externalpagepopup');
                this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            });
        }
        else if (this.mbp == MessageBoxButton.Cancel) {
            closePopup('externalpagepopup');
            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        }
    }
}
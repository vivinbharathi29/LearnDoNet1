﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 08/21/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 08/22/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-workflow-status.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class DCRWorkflowStatusService {
    constructor(private http: Http, private location: Location) {
    }

    getDcrWorkflowStatus(dcrId: any, pvId: any, milestoneComplete: any) {
        return this.http.get(this.location.prepareExternalUrl('/product/DCRWorkflowDefinitions/GetDCRWorkflowStatus/' + dcrId + '/' + pvId + '/' + milestoneComplete));
    }

    terminateDcrWorkflowStatus(pvId: any) {
        return this.http.get(this.location.prepareExternalUrl('/product/DCRWorkflowDefinitions/TerminateDCRWorkflow/' + pvId));
    }
}

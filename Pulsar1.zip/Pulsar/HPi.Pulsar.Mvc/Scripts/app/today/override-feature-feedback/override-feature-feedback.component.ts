﻿import { Component } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'override-feature-feedback',
    templateUrl: './override-feature-feedback.component.html'
})
export class OverrideFeatureFeedbackComponent {

    feedback: string = "";

    constructor(private router: Router) {
        this.feedback = "";
    }

    save(): void {
        if (this.feedback.trim().length != 0) {
            this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
            popupCallBack(this.feedback);
            closePopup('externalpagepopup');
        }
        else {
            alert("Comment is required for Not Actionable action items");
        }
    }

    cancel(): void {
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
        closePopup('externalpagepopup');
    }
}

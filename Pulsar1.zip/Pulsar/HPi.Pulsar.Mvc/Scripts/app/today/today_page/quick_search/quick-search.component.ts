﻿//our root app component
import { FormsModule } from '@angular/forms';
import { Location } from '@angular/common';
import { Component, OnInit, ViewChild,AfterViewInit } from '@angular/core';
import { QuickPageService } from './quick-search.service';
import { UserInfoService } from '../dashboard/user-info.service';
import { ActivatedRoute, NavigationExtras, Params, Router } from '@angular/router';
import { ModalPopupComponent } from '../../../Shared/modal_popup/modal-popup.component';
declare let $: any;
declare var modalPopup: any;
@Component({
    selector: 'quick-search',
    templateUrl: './quick-search.component.html'
})

export class QuickSearchComponent implements OnInit {
    
    public StringMyReportLinks: string;
    public CurrentUserPartnerType: number;
    public CurrentUserPartner: number;
    public CurrentUserDivision: number;
    public DeliverableUrl: string;
    public UserId: string;
    public changeRequestUrl: string = "/product/product/GetTodayAction/0/3/0/0";
    public changeRequestTitle: string = "Change Request"
    public HostName: string;
    host: any;
    name: string;
    html: string;
    isDefaultPulsarPlus: boolean;
    isSetPulsarPlusDefault: boolean = false;
    constructor(private service: QuickPageService, private userService: UserInfoService, private router: Router, private location: Location) {
        this.DeliverableUrl=this.location.prepareExternalUrl('/product/product/GetDeliverablesReport').toString();
    }
    ngAfterViewInit() {
        this.getUserPreference();
    }
    ngOnInit() {
        this.userService.getUserInfo().subscribe(result => {
            
            this.CurrentUserPartnerType = result.json().appHeaderDetails.currentUserPartnerType;
            this.CurrentUserPartner = result.json().appHeaderDetails.currentUserPartner;
            this.CurrentUserDivision = result.json().appHeaderDetails.currentUserDivision;
            this.UserId = result.json().appHeaderDetails.userId;
            var deliverableLink = document.getElementById('adeliverables') as HTMLAnchorElement;
            this.HostName = result.json().appHeaderDetails.hostName;
            this.host = result.json().appHeaderDetails.hostName;
        });
        this.service.index().subscribe(result => {
            this.html = result.json().strMyReportLinks;
            this.StringMyReportLinks = result.json().strMyReportLinks;
        });
    }
    convertAction() {
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['action', 0, 0, 0, 0, 2, 0, 0,'quicksearch'] } }]);
        modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");
    }   

    ViewChangeRequest(url: string, title: string, page: string) {
        //adjustableShowPopup(this.location.prepareExternalUrl(url), title, "660px", "75%", "620px");
        showPopupFirstlevelWithHeightInPercentage(this.location.prepareExternalUrl(url), title, "80%", "95%");                
    }

    setPulsarPlusDefault(value: any) {
        this.isSetPulsarPlusDefault = value.target.checked;
    }

    getUserPreference() {
        this.service.getUserPreference().subscribe(result => {
            var userPreference = result.json();
            if (userPreference.isDefaultPulsarPlus == true) {
                this.isDefaultPulsarPlus = true;
            }
            else {
                this.isDefaultPulsarPlus = false;
            }

        });
    }

    btnDefaultClick(){
        if (this.isSetPulsarPlusDefault == true)
        {
            this.service.UpdateUserPreferenceDefaultPulsarPlus(this.isSetPulsarPlusDefault).subscribe(result => {
                this.isDefaultPulsarPlus = true;
            });
        }
    }

    suddenimpactRedirect(hostname: any) {        
        btnOTSClick(hostname);
    }
    
}

// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : Vinothkumar Periyasamy(auth/viperiya)
// Created          : 04-13-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="today-page.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response,URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class QuickPageService {
    constructor(private http: Http, private location: Location) { 
	
    }
	index()
    {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/Index'));
    }
    UpdateUserPreferenceDefaultPulsarPlus(isDefaultPulsarPlus: boolean): Observable<Response> {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/UpdateUserPreferenceDefaultPulsarPlus/' + isDefaultPulsarPlus));
    }

    getUserPreference() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetUserPreference'));
    }
}
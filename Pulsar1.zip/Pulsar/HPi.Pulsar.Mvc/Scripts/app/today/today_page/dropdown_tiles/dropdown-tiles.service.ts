﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay(Nishok S E A)
// Created          : 02/06/2018
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dropdown-tiles.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class DropdownTilesService {
    getTiles$ = new Observable<any>();
    private notify = new Subject<any>();
    constructor(private http: Http, private location: Location) {
        this.getTiles$ = this.notify.asObservable();
    }

    getTiles(data)
    {
        this.notify.next(data);
    }

    getImpersonateName() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
    }
        
}

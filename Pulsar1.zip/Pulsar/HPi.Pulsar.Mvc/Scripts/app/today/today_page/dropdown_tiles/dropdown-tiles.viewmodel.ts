﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Anand Singh(auth\kumaanan)
// Created          : 02-08-2018
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dropdown-tiles.viewmodel.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class DropdownTilesViewModel {
    tile: string;
    tileId: string;
    tileCount: number;
    tileUrl: string;
    section: string;
    tileName: string;
    tileNumber: number;
    popupWidth: string;
    currentUserSysAdmin: boolean;
    sepmProductCount: boolean;
}
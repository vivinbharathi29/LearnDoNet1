﻿// ***********************************************************************************************************
// Assembly         : App Module
// Author           : Anand Singh(auth\kumaanan)
// Created          : 02-15-2018
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dropdown-tile.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, Inject, OnInit, AfterViewInit } from '@angular/core';
import { DropdownTilesService } from '../dropdown_tiles/dropdown-tiles.service';
import { NavigationExtras, Params, Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { TodayTabsComponent } from '../today-tabs/today-tabs.component';
import { DropdownTilesViewModel } from './dropdown-tiles.viewmodel';
import { DropdownSectionEnum } from './dropdown-tiles.enum';
import { default as data } from './dropdown-tiles.data';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'dropdown-tiles',
    templateUrl: './dropdown-tiles.component.html'
})
export class DropdownTilesComponent implements OnInit {
    tabs = {};
    dropdownData: DropdownTilesViewModel;
    todayTiles: DropdownTilesViewModel[] = [];
    tileId: string;
    tileUrl: string;
    section: string;
    tileName: any;
    tileNumber: number;
    tileCount: number;
    popupWidth: any = "90%";
    popupHeight: any = "600px";
    impersonatedName: string = "";
    isCurrentUserSysAdmin: boolean;
    isSepmProductCount: boolean;

    constructor(private service: DropdownTilesService, private router: Router, private todayTabs: TodayTabsComponent) {
    }
    ngAfterViewInit() {
        this.service.getImpersonateName().subscribe(result => {
            this.impersonatedName = result.json().title;
        });
    }
    ngOnInit() {
        this.getTodayTiles();
    }

    getTodayTiles() {
        this.service.getTiles$.subscribe((result) => {
            this.tabs = result;
            for (let item in this.tabs)
            {
                if (Number.isInteger(this.tabs[item])) {
                    if (this.tabs[item] > 0) {    
                        for (let i = 0; i < data.tilesDetail.length; i++) {
                            if (item === data.tilesDetail[i].tileId) {
                                if (item == "openObservationsAssignedToMe" && this.todayTabs.appHeaderViewModel.otsOwnerSection == false) {
                                    break;
                                }
                                if (item == "openObservationsOnMyComponent" && this.todayTabs.appHeaderViewModel.otsDeliverableSection == false) {
                                    break;
                                }
                                if (item == "openObservationsSubmitted" && this.todayTabs.appHeaderViewModel.otsSubmittedSection == false) {
                                    break;
                                }
                                this.dropdownData = { tile: data.tilesDetail[i].tileTitle + ' : ' + data.tilesDetail[i].section, tileId: data.tilesDetail[i].tileId, tileCount: this.tabs[item], tileUrl: data.tilesDetail[i].tileUrl, section: data.tilesDetail[i].section, tileName: data.tilesDetail[i].tileTitle, tileNumber: data.tilesDetail[i].tileNumber, popupWidth: data.tilesDetail[i].popupWidth, currentUserSysAdmin: data.tilesDetail[i].currentUserSysAdmin, sepmProductCount: data.tilesDetail[i].sepmProductCount }
                                this.todayTiles.push(this.dropdownData);
                                break;
                            }
                        }
                    }
                }
            }
            this.todayTiles.sort((a: any, b: any) => {
                if (a.tile < b.tile) {
                    return -1;
                } else if (a.tile > b.tile) {
                    return 1;
                } else {
                    return 0;
                }
            });
        })
    }

    subSectionChange(value: string) {
        this.tileId = value;
    }

    showTileData(): void {
        if (this.tileId == undefined) {
            this.tileId = (<HTMLInputElement>document.getElementById("tileOptionUrl")).value;
        }

        for (let i = 0; i < this.todayTiles.length; i++) {
            if (this.tileId === this.todayTiles[i].tileId)
            {
                this.tileUrl = this.todayTiles[i].tileUrl;
                this.section = this.todayTiles[i].section;
                this.tileName = this.todayTiles[i].tileName;
                this.tileCount = this.todayTiles[i].tileCount;
                this.tileNumber = this.todayTiles[i].tileNumber;
                this.popupWidth = this.todayTiles[i].popupWidth;
                this.isCurrentUserSysAdmin = this.todayTiles[i].currentUserSysAdmin;
                this.isSepmProductCount = this.todayTiles[i].sepmProductCount;
                break;
            }
        }
        let tabName = "";
        switch (this.section) {
            case DropdownSectionEnum.adminAlerts:
                tabName = "tabAdminAlerts";
                break;
            case DropdownSectionEnum.productAlerts:
                tabName = "tabProductAlerts";
                break;
            case DropdownSectionEnum.alerts:
                tabName = "tabAlerts";
                break;
            case DropdownSectionEnum.myItems:
                tabName = "tabMyItems";
                break;
            case DropdownSectionEnum.test:
                tabName = "tabTest";
                break;
            case DropdownSectionEnum.dcrs:
                tabName = "tabDCRS";
                break;
            default:
                tabName = "tabPulsarNews";
                break;
        }
        let tabIndex: number = -1;
        let index: number = 0;
        for (index = 0; index < this.todayTabs.myTabs.length(); index++) {
            if (this.todayTabs.myTabs.getTitleAt(index).trim().toLowerCase() == this.section.trim().toLowerCase()) {
                tabIndex = index;
                break;
            }
        }
        this.todayTabs.myTabs.select(tabIndex);
        this.todayTabs.changeColor(tabName);
        this.loadSubsection();
    }
    
    loadSubsection(): void {
        let popupurl: string = "";
        let popupTitle: string = "";
        let currentUserSysAdmin;
        let sepmProducts;
        let userId;
        popupurl = this.tileUrl.replace('/', '');
        popupTitle = this.impersonatedName != "" ? this.tileName + this.impersonatedName : this.tileName;

        if (this.isCurrentUserSysAdmin == true) {
            currentUserSysAdmin = this.todayTabs.appHeaderViewModel.systemAdmin;
        }
        if (this.isSepmProductCount == true) {
            sepmProducts = this.todayTabs.appHeaderViewModel.sepmProducts;
        }
        //console.log(popupTitle);
        let navigationExtras: NavigationExtras = {
            queryParams: { 'CurrentUserSysAdmin': currentUserSysAdmin, 'SEPMProductCount': sepmProducts, 'NewComponentTwoCount': this.tileCount},
            preserveQueryParams: false

        };
        console.log(popupurl);
        this.router.navigate([{ outlets: { 'popupWindow': [popupurl] } }], navigationExtras);

        modalPopup.show('#popup', this.popupWidth, this.popupHeight, popupTitle, this.tileNumber);
    }
}

﻿// ***********************************************************************************************************
// Assembly         : App Module
// Author           : Anand Singh(auth\kumaanan)
// Created          : 02-15-2018
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dropdown-tile.enum.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
export enum DropdownSectionEnum {
    adminAlerts = "Admin Alerts",
    productAlerts = "Product Alerts",
    alerts = "Alerts",
    myItems = "My Items",
    test = "Test",
    dcrs = "DCRs",
    pulsarNews = "Pulsar News"
}
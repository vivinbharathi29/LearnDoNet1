﻿// ***********************************************************************************************************
// Assembly         : App Module
// Author           : Anand Singh(auth\kumaanan)
// Created          : 02-15-2018
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dropdown-tile.data.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { DropdownSectionEnum } from './dropdown-tiles.enum';
export default {
    "tilesDetail": [
        {
            "tileId": "ihubJobsDidNotRunAsScheduled",
            "tileTitle": "IHUB Jobs Did Not Run As Scheduled",
            "tileUrl": "/ihubdidnotrunasscheduled",
            "tileNumber": 81,
            "section": DropdownSectionEnum.adminAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "scmFeedErrors",
            "tileTitle": "SCM Feed Errors",
            "tileUrl": "/scmfeederror",
            "tileNumber": 3,
            "section": DropdownSectionEnum.adminAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "jobsDidnotRunAsScheduled",
            "tileTitle": "Jobs Did Not Run As Scheduled",
            "tileUrl": "/jobsdidnotrunasscheduled",
            "tileNumber": 96,
            "section": DropdownSectionEnum.adminAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "applicationErrorsOutstanding",
            "tileTitle": "Application Errors To Investigate",
            "tileUrl": "/applicationerrorsoutstanding",
            "tileNumber": 29,
            "section": DropdownSectionEnum.adminAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "spareKitsNotMappedToAVs",
            "tileTitle": "SpareKits Not Mapped to AVs",
            "tileUrl": "/spareKitsnotmappedtoavs",
            "tileNumber": 61,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "aVsNotMappedtoSparekit",
            "tileTitle": "AVs Not Mapped to SpareKits",
            "tileUrl": "/avsnotmappedtosparekit",
            "tileNumber": 63,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "aVsDeletedButMappedToSpareKits",
            "tileTitle": "AVs deleted but Mapped to SpareKits",
            "tileUrl": "/avsdeletedbutmappedtosparekits",
            "tileNumber": 65,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "spareKitsNotStructuredToFamily",
            "tileTitle": "SpareKits Not Structured to Family",
            "tileUrl": "/sparekitsnotstructuredtofamily",
            "tileNumber": 66,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "aVsNotRequested",
            "tileTitle": "AVs Not Requested",
            "tileUrl": "/avsnotrequested",
            "tileNumber": 82,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "upcomingReleases",
            "tileTitle": "Release Team Action Items - Upcoming Releases",
            "tileUrl": "/upcomingreleases",
            "tileNumber": 86,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "helpAndSupportUpcomingRelease",
            "tileTitle": "Help And Support - Upcoming Releases",
            "tileUrl": "/helpandsupportupcomingreleases",
            "tileNumber": 16,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "recentVersionReleased",
            "tileTitle": "Recent Versions Released",
            "tileUrl": "/recentversionsreleased",
            "tileNumber": 17,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "functionalTestUpcomingRelease",
            "tileTitle": "Functional Test - Upcoming Releases",
            "tileUrl": "/functionaltestupcomingreleases",
            "tileNumber": 70,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentsAwaitingDeveloperReview",
            "tileTitle": "Components Awaiting Developer Review",
            "tileUrl": "/componentsawaitingdeveloperreview",
            "tileNumber": 101,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "failedTtsComponentsToReview",
            "tileTitle": "Failed TTS Components to Review",
            "tileUrl": "/failedttscomponentstoreview",
            "tileNumber": 18,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "observationUnassigneds",
            "tileTitle": "Observations - Unassigned",
            "tileUrl": "/hardwareobservationunassigned",
            "tileNumber": 47,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%", 
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "observationTransferRequested",
            "tileTitle": "Observations - Transfer Requested",
            "tileUrl": "/hardwareobservationtransferrequested",
            "tileNumber": 48,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "featuresRequestingRootComponents",
            "tileTitle": "Features Requesting Root Components",
            "tileUrl": "/featuresrequestingrootcomponents",
            "tileNumber": 67,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "featureRootRequestsRejected",
            "tileTitle": "Feature Root Requests Rejected",
            "tileUrl": "/featurerootrequestsrejected",
            "tileNumber": 68,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "engineeringDevelopmentWorkingList",
            "tileTitle": "Engineering Development Working List",
            "tileUrl": "/engineeringdevelopmentworkinglist",
            "tileNumber": 122,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "newSmrRequest",
            "tileTitle": "New SMR Requests",
            "tileUrl": "/newsmrrequests",
            "tileNumber": 120,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "hwDeliverableEolCount",
            "tileTitle": "Component End of Factory Availability Date Expired",
            "tileUrl": "/componentendoflifedateexpired",
            "tileNumber": 124,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%", 
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "deliverableEolCount",
            "tileTitle": "Component End of Life Date Expired",
            "tileUrl": "/componentendoflifedateexpired",
            "tileNumber": 124,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "newComponentsRequest",
            "tileTitle": "New Components Request",
            "tileUrl": "/newcomponentrequest",
            "tileNumber": 90,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "inActiveComponentStillTargeted",
            "tileTitle": "Inactive Components Still Targeted",
            "tileUrl": "/inactivecomponentstilltargeted",
            "tileNumber": 83,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "approvalRequestedReleaseToProduction",
            "tileTitle": "Approval Requested - Release to Production",
            "tileUrl": "/approvalrequestedreleasetoproduction",
            "tileNumber": 56,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "productsWithExpiredServiceLifeDate",
            "tileTitle": "Products With Expired Service Life Date",
            "tileUrl": "/productswithexpiredservicelifedate",
            "tileNumber": 43,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "productsMissingPMOrServiceLifeDate",
            "tileTitle": "Product Missing PM or End of Service Life Date",
            "tileUrl": "/productmissingpmorservicelifedate",
            "tileNumber": 27,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "componentsAwaitingFinalApproval",
            "tileTitle": "Components Awaiting Final Approval",
            "tileUrl": "/componentsawaitingfinalapproval",
            "tileNumber": 41,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "newComponentsReleasedForMyProductOne",
            "tileTitle": "New Hardware Components Released for My Products",
            "tileUrl": "/newcomponentsreleasedformyproductsone",
            "tileNumber": 85,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "newComponentsReleasedForMyProductTwo",
            "tileTitle": "New Accessory Components Released For My Products",
            "tileUrl": "/newcomponentreleasedformyproducttwo",
            "tileNumber": 84,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "missingBaseUnitSubassemblyNumbers",
            "tileTitle": "Missing Base Unit Subassembly Numbers(Pulsar Product)",
            "tileUrl": "/missingbaseunitsubassemblynumber",
            "tileNumber": 88,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "70%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "missingSupplierCodes",
            "tileTitle": "Missing Supplier Codes",
            "tileUrl": "/missingsuppliercodes",
            "tileNumber": 102,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "missingSubassemblyNumberLegacy",
            "tileTitle": "Missing Subassembly Numbers",
            "tileUrl": "/missingsubassemblynumberslegacy",
            "tileNumber": 91,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "hardwareComponentsWithNoPartNumber",
            "tileTitle": "Hardware Components With No Part Number",
            "tileUrl": "/hardwarecomponentswithnopartnumber",
            "tileNumber": 95,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentInTestOdmLead",
            "tileTitle": "Components in Test - ODM Hardware Test Lead (plural Components)",
            "tileUrl": "/componentintestodm",
            "tileNumber": 31,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "componentInTestSELead",
            "tileTitle": "Component In Test - SE Test Lead",
            "tileUrl": "/componentintestse",
            "tileNumber": 32,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "componentInTestWwanLead",
            "tileTitle": "Component In Test - WWAN Hardware Test Lead",
            "tileUrl": "/componentintestwwan",
            "tileNumber": 33,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "missingServiceSubassemblyNumber",
            "tileTitle": "Missing Service Subassembly Numbers",
            "tileUrl": "/missingservicesubassemblynumbers",
            "tileNumber": 93,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "linkedComponentsNotUsed",
            "tileTitle": "Linked Components No Longer Used By the Commodity Team",
            "tileUrl": "/linkedcomponentnotusedbycommodityteam",
            "tileNumber": 7,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "errorTransmittingFilestoPreinstallServer",
            "tileTitle": "Error Transmitting Files to Preinstall Server",
            "tileUrl": "/errortransmittingfilestopreinstallserver",
            "tileNumber": 104,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "expiredPilotScheduleDates",
            "tileTitle": "Expired Pilot Schedule Dates",
            "tileUrl": "/expiredpilotscheduledates",
            "tileNumber": 103,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentPassedPlannedReleaseDate",
            "tileTitle": "Components Passed Planned Release Date",
            "tileUrl": "/componentspassedplannedreleasedate",
            "tileNumber": 74,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "coreTeamWorkingList",
            "tileTitle": "Core Team Working List",
            "tileUrl": "/coreteamworkinglist",
            "tileNumber": 75,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "pmDeveloperRequestedRemoval",
            "tileTitle": "Accessory PM Alerts/ Factory Engineer Alerts/ Hardware PM Alerts - Developer Requests Removal From Product",
            "tileUrl": "/pmalertsdeveloperrequestedremoval",
            "tileNumber": 125,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentMissingSubAssemblyOrKitNumber",
            "tileTitle": "Components with Missing Subassembly or Kit Numbers",
            "tileUrl": "/componentmissingsubassemblyorkitnumber",
            "tileNumber": 121,
            "section": DropdownSectionEnum.alerts,
            "popupWidth": "65%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentInFunctionalTest",
            "tileTitle": "Components In Functional Test",
            "tileUrl": "/componentsinfunctionaltest",
            "tileNumber": 105,
            "section": DropdownSectionEnum.test,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentsAwaitingTestReview",
            "tileTitle": "Components Awaiting Test Review",
            "tileUrl": "/componentsawaitingtestreview",
            "tileNumber": 69,
            "section": DropdownSectionEnum.test,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentProductSupportInTest",
            "tileTitle": "Sustaining Product Support - In Test",
            "tileUrl": "/sustainingproductsupportintest",
            "tileNumber": 21,
            "section": DropdownSectionEnum.test,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "componentProductSupportInTest",
            "tileTitle": "Sustaining Product Support - Test Complete",
            "tileUrl": "/sustainingproductsupportincomplete",
            "tileNumber": 22,
            "section": DropdownSectionEnum.test,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "componentProductSupportInTestPending",
            "tileTitle": "Sustaining Product Support - Test Pending",
            "tileUrl": "/sustainingproductsupportintestpending",
            "tileNumber": 23,
            "section": DropdownSectionEnum.test,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "observationUnassigneds",
            "tileTitle": "Observations - Unassigned",
            "tileUrl": "/observationunassigned",
            "tileNumber": 5,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "productsWithMissingHWPM",
            "tileTitle": "Products with missing HW PM",
            "tileUrl": "/productmissinghwpm",
            "tileNumber": 28,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "900px",
            "currentUserSysAdmin": true,
            "sepmProductCount": true
        },
        {
            "tileId": "observationTransferRequested",
            "tileTitle": "Observations - Transfer Requested",
            "tileUrl": "/observationstransferrequested",
            "tileNumber": 8,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "developerRequestedRemoval",
            "tileTitle": "Developer Requests Removal From Product",
            "tileUrl": "/developerrequestremovalfromproduct",
            "tileNumber": 13,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "productsMissingPdmTeamMember",
            "tileTitle": "Products Missing PDM Team Member",
            "tileUrl": "/productmissingpdmteammember",
            "tileNumber": 62,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "70%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "missingSystemBoardIds",
            "tileTitle": "Missing System Board ID",
            "tileUrl": "/missingsystemboard",
            "tileNumber": 1,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "35%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "leadProductSync",
            "tileTitle": "Lead Product - Synchronization Issues",
            "tileUrl": "/leadproductsynchronization",
            "tileNumber": 34,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "missingRequiredMilestones",
            "tileTitle": "Missing Required Milestones",
            "tileUrl": "/missingrequiredmilestones",
            "tileNumber": 10,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "smrAwaitingApproval",
            "tileTitle": "SMR - Awaiting Approval",
            "tileUrl": "/smrawaitingdeveloper",
            "tileNumber": 11,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "pastDueScheduleItems",
            "tileTitle": "Past Due Schedule Items",
            "tileUrl": "/pastdue",
            "tileNumber": 2,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "newComponentsReleased",
            "tileTitle": "New Components Released",
            "tileUrl": "/newcomponentsreleased",
            "tileNumber": 57,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentProductSupportInTest",
            "tileTitle": "SMR - Waiting On Developer",
            "tileUrl": "/smrwaitingondeveloper",
            "tileNumber": 12,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "missingSETestLeads",
            "tileTitle": "Unassigned SE Test Lead",
            "tileUrl": "/missingsetestlead",
            "tileNumber": 4,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "30%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "productsWithMissingHWPM",
            "tileTitle": "Products with missing HW PM",
            "tileUrl": "/productmissinghwpm",
            "tileNumber": 28,
            "section": DropdownSectionEnum.productAlerts,
            "popupWidth": "90%",
            "currentUserSysAdmin": true,
            "sepmProductCount": true

        },
        {
            "tileId": "componentsinReleaseWorkflowStep",
            "tileTitle": "Release Team Action Items - Components in Release Workflow Step",
            "tileUrl": "/componentsinreleaseworkflowstep",
            "tileNumber": 87,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "dcrWorkflowMilestone",
            "tileTitle": "DCR Workflow Milestones",
            "tileUrl": "/dcrworkflowdefinition",
            "tileNumber": 19,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "openSupportTicketsISubmitted",
            "tileTitle": "Open Support Tickets I Submitted",
            "tileUrl": "/opensupportticketsisubmitted",
            "tileNumber": 44,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "itemsAwaitingMyApproval",
            "tileTitle": "Items Awaiting My Approval",
            "tileUrl": "/itemsawaitingmyapproval",
            "tileNumber": 49,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "allOpenitemsIOwn",
            "tileTitle": "All Open Items I Own",
            "tileUrl": "/allopenitemsiown",
            "tileNumber": 50,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "myOpenTickets",
            "tileTitle": "My Open Tickets",
            "tileUrl": "/myopentickets",
            "tileNumber": 51,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "sharedAVActions",
            "tileTitle": "Shared AV Actions",
            "tileUrl": "/sharedavactions",
            "tileNumber": 54,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "pendingZsrpReadyDate",
            "tileTitle": "Pending ZSRP Ready Dates",
            "tileUrl": "/pendingzsrpreadydate",
            "tileNumber": 9,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "pHwebAVActionItemsLegacyProduct",
            "tileTitle": "PHweb AV Action Items (Legacy Product)",
            "tileUrl": "/phwebavactionitemslegacyproduct",
            "tileNumber": 45,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "myWorkingList",
            "tileTitle": "My Working List",
            "tileUrl": "/myworkinglist",
            "tileNumber": 42,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "imageTabChangetoLocalization",
            "tileTitle": "Image Tab Change to Localization (Pulsar Product)",
            "tileUrl": "/imagetabchangetolocalization",
            "tileNumber": 94,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "60%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "missingAVMarketingData",
            "tileTitle": "Missing AV Marketing Data",
            "tileUrl": "/missingavmarketingdata",
            "tileNumber": 55,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "rejectedAVs",
            "tileTitle": "Rejected Avs (Pulsar Product)",
            "tileUrl": "/rejectedavs",
            "tileNumber": 52,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "pHwebAVActionItemsPulsarProduct",
            "tileTitle": "PHweb AV Action Items (Pulsar Product)",
            "tileUrl": "/phwebavactionitemspulsarproduct",
            "tileNumber": 46,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "50%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "userAndRolesRequest",
            "tileTitle": "Users and Roles Requests",
            "tileUrl": "/usersandrolesrequests",
            "tileNumber": 64,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "65%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "pastDuesAlert",
            "tileTitle": "Past Due",
            "tileUrl": "/pastduesalert",
            "tileNumber": 24,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "pastDueScheduleAlertItems",
            "tileTitle": "Schedule Alert",
            "tileUrl": "/pastdueschedule",
            "tileNumber": 30,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "dueThisWeek",
            "tileTitle": "Due this Week",
            "tileUrl": "/duethisweek",
            "tileNumber": 25,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "openItemsISubmitted",
            "tileTitle": "All Open Items I Submitted",
            "tileUrl": "/openitemsisubmitted",
            "tileNumber": 26,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "initialOfferingDeactivateSimpleAVs",
            "tileTitle": "Initial Offering - Deactivate Simple AVs",
            "tileUrl": "/initialofferingdeactivatesimpleavs",
            "tileNumber": 89,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "70%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "legacySimpleAVsCreated",
            "tileTitle": "Create Simple AVs (Legacy Product)",
            "tileUrl": "/legacysimpleavs",
            "tileNumber": 14,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "pulsarSimpleAVsCreated",
            "tileTitle": "Create Simple AVs (Pulsar Product)",
            "tileUrl": "/pulsarsimpleavs",
            "tileNumber": 15,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "featureNamingOverrideRequested",
            "tileTitle": "Feature Naming Override Request",
            "tileUrl": "/featurenamingoverriderequested",
            "tileNumber": 53,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "componentNameChangeLinkedToAV",
            "tileTitle": "Component Name Change Linked To AV",
            "tileUrl": "/componentnamechangelinkedtoav",
            "tileNumber": 92,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "featureRemovedFromPrl",
            "tileTitle": "Feature removed from POST PRL Lock",
            "tileUrl": "/featureremovedfromprl",
            "tileNumber": 76,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "80%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "openObservationsAssignedToMe",
            "tileTitle": "Open Observations Assigned To Me",
            "tileUrl": "/openobservationsassignedtome",
            "tileNumber": 71,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "openObservationsOnMyComponent",
            "tileTitle": "Open Observations On My Components",
            "tileUrl": "/openobservationsonmycomponent",
            "tileNumber": 72,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "openObservationsSubmitted",
            "tileTitle": "Open Observations I Submitted",
            "tileUrl": "/openobservationssubmitted",
            "tileNumber": 73,
            "section": DropdownSectionEnum.myItems,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "closedInLastSevenDays",
            "tileTitle": "Change Requests - Closed in 7 days",
            "tileUrl": "/crclosedinlastsevendays",
            "tileNumber": 20,
            "section": DropdownSectionEnum.dcrs,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        },
        {
            "tileId": "crProposed",
            "tileTitle": "Change Requests - Proposed",
            "tileUrl": "/crproposed",
            "tileNumber": 6,
            "section": DropdownSectionEnum.dcrs,
            "popupWidth": "90%",
            "currentUserSysAdmin": false,
            "sepmProductCount": false

        }
    ]
}
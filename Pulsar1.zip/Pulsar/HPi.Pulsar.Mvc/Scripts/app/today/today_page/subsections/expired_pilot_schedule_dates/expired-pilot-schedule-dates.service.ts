﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 03/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="expired-pilot-schedule-dates.service" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class ExpiredPilotScheduleDatesService {
    constructor(private http: Http, private location: Location) {

    }
    getExpiredPilotScheduleDates() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetExpiredPilotScheduleDates'));
    }
}

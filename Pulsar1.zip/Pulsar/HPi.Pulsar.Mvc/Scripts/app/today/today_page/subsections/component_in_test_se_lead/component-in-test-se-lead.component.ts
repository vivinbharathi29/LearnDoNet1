﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R(auth\rajamanr)
// Created          : 06/03/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="component-in-test-se-lead.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, ViewChild, AfterViewInit,NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ComponentInTestSELeadService } from './component-in-test-se-lead.service';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { Router } from '@angular/router';
@Component({
    selector: 'component-in-test-se-lead',
    templateUrl:'./component-in-test-se-lead.component.html'
})

export class ComponentInTestSELeadComponent implements AfterViewInit {
    @ViewChild('gridReference') componentSELeadGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    private mbp: MessageBoxButton;
    constructor(http: Http, private service: ComponentInTestSELeadService, private ngZone: NgZone,private messageBox:MessageBox,private router:Router) {
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            TestStatusComponentFn: (value) => this.TestStatusComponentCallBackFn(value),
            popUpCallBackFn: (value) => this.TestStatusComponentCallBackFn(value),
            MultiTestStatusComponentFn: (value) => this.MultiTestStatusComponentFn(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.selectionmode = "checkbox";
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product',type:'string' },
            { name: 'testDate', map: 'testDate', type: 'string' },
            { name: 'deliverable', map: 'deliverable', type: 'string'},
            { name: 'version', map: 'version', type: 'string' },
            { name: 'modelNumber', map: 'modelNumber', type: 'string' },
            { name: 'partNumber', map: 'partNumber', type: 'string'},
            { name: 'productID', map: 'productID' },
            { name: 'versionID', map: 'versionID' },
            { name: 'rootID', map: 'rootID' },
            { name: 'id', map: 'id' },
            { name: 'productDeliverableReleaseID', map:'productDeliverableReleaseID'}
        ];
        
        this.jqxGridConfig.columns = [
            {
                text: 'Product', columngroup: 'selead',
                datafield: 'product', width: "11%", filtertype: 'input', editable: true
            },
            {
                text: 'Target', columngroup: 'selead',
                datafield: 'testDate', filtertype: 'input', width: "10%", 
            },

            {
                text: 'Component', columngroup: 'selead',
                datafield: 'deliverable', filtertype: 'input', width: "31%", 
            },
            {
                text: 'Version', columngroup: 'selead',
                datafield: 'version', width: "15%", filtertype: 'input', 
            },
            {
                text: 'Model', columngroup: 'selead',
                datafield: 'modelNumber', width: "15%", filtertype: 'input', 
            },
            {
                text: 'PartNumber', columngroup: 'selead',
                datafield: 'partNumber', width: "15%", filtertype: 'input', 
            },
            {
                text: 'Id', columngroup: 'selead',
                datafield: 'id', hidden: true, 
            },
            {
                text: 'ProductId', columngroup: 'selead',
                datafield: 'productID', hidden: true, 
            },
            {
                text: 'RootId', columngroup: 'selead',
                datafield: 'rootID', hidden: true, 
            },
            {
                text: 'VersionId', columngroup: 'selead',
                datafield: 'versionID', hidden: true, 
            },
            {
                text: 'ProductDeliverableReleaseID', columngroup: 'selead',
                datafield: 'productDeliverableReleaseID', hidden: true
            }
        ];

        this.jqxGridConfig.columnTypes = {
            'product': FilterColumnTypeEnum.String,
            'partNumber': FilterColumnTypeEnum.String,
            'testDate': FilterColumnTypeEnum.String,
            'modelNumber': FilterColumnTypeEnum.String,
            'version': FilterColumnTypeEnum.String,
            'deliverable': FilterColumnTypeEnum.String,
        }

    }

    EditTestStatus(ID: any, ProductID: any, VersionID: any, RootID: any, FieldID: any, ProductDeliverableReleaseID:any):void {
        var url = "";
        var rowId = ID.toString() + "_" + ProductDeliverableReleaseID;
        if (ProductDeliverableReleaseID != undefined && ProductDeliverableReleaseID != 0) {
            //url = '/Excalibur/Deliverable/TestTeam/TestStatusPulsar.asp?FieldID=' + FieldID + "&VersionID=" + VersionID + "&ProductID=" + ProductID + "&ReleaseID=" + ProductDeliverableReleaseID + "&RowID=" + rowId + "&TodayPageSection=EditTestStatus&app=PulsarPlus";
            //showPopup(url, "Components In Test - SE Test Lead", 900, 600);
            var TodayPageSection = "EditTestStatus";
            var ReleaseID = ProductDeliverableReleaseID;
            var RowID = rowId;
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['testleadstatuspulsar', FieldID, VersionID, ProductID, ReleaseID, RowID, TodayPageSection] } }]);
            modalPopup.show('#externalpagepopup', "900", "600", "Components In Test - SE Test Lead");
        }
        else {
            //url = '/Excalibur/Deliverable/TestTeam/TestStatus.asp?FieldID=' + FieldID + "&VersionID=" + VersionID + "&ProductID=" + ProductID + "&RowID=" + rowId + "&TodayPageSection=EditTestStatus&app=PulsarPlus";
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['testleadstatus', VersionID, ProductID, FieldID] } }]);
            modalPopup.show('#externalpagepopup', "900", "600", "Components In Test - SE Test Lead");
        }
        
        
    }
    TestStatusComponentCallBackFn(status) {      
                this.pageReload();
    }
    MultiTestStatusComponentFn(status: any): void {
        if (typeof (status) != "undefined") {
            console.log(status);
            this.pageReload();
        }
    }
    pageReload() {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.componentSELeadGrid);
        this.getComponentInTestSELead(paginationInfo);
        this.componentSELeadGrid.clearselection();
    }
    selectedCount: number;
    multiEditTestStatus():void
    {
        var strIDs = "";
        var url;
        var selectedIndices = this.componentSELeadGrid.selectedrowindexes();
        this.selectedCount = selectedIndices.length;
        //if (selectedIndices.length <= 1) {
        //    this.messageBox.Show("Update Status", "Please check more than one alert and try again", MessageBoxType.Ok, MessageBoxIcon.Information, "500", this.numCallback);
        //    return;
        //}
        for (var index = 0; index < selectedIndices.length; index++) {
            strIDs = strIDs + this.componentSELeadGrid.getrowdata(selectedIndices[index]).id + "_" + this.componentSELeadGrid.getrowdata(selectedIndices[index]).productDeliverableReleaseID +  ",";
        }
        this.selectedIds = strIDs;
        
        if (strIDs != "") {
            strIDs = strIDs.substring(0, strIDs.length - 1);
            //url = "/Excalibur/Deliverable/TestTeam/MultiUpdateTestStatus.asp?IDList=" + strIDs +"&Index=1&TodayPageSection=MultiEditTestStatus&app=PulsarPlus";
            //showPopup(url, "Batch Update Test Status", 650, 720);
            this.router.navigate([{outlets: {
                    'externalpopupWindow': ['multiupdatetest', strIDs, 1,'MultiEditTestStatus'] } }]);
            modalPopup.show('#externalpopupMessage', "80%", "650px", "Batch Update Test Status");
        }
        else 
        {
            this.messageBox.Show("Update Status", "Please check at least one alert and try again", MessageBoxType.Ok, MessageBoxIcon.Information, "500", this.numCallback);
        }
    }
    public selectedIds: string = "";
    numCallback = (response: MessageBoxButton): void => {
        
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
            if (this.selectedIds == '' || this.selectedIds == undefined) {
                return;
            }
            if (this.selectedCount <= 1) {
                return;
            }
        }
    }
    getComponentInTestSELead(paginationInfo: PaginationModel) {
        this.componentSELeadGrid.showdefaultloadelement(true);
        this.service.getComponentInTestSELead(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.componentSELeadGrid.updatebounddata(null);
            this.componentSELeadGrid.hideloadelement();
            });
    }
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.componentSELeadGrid);
        this.getComponentInTestSELead(paginationInfo);
        //this.getProducts(paginationInfo);

    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.componentSELeadGrid);
        this.getComponentInTestSELead(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.componentSELeadGrid);
        this.getComponentInTestSELead(paginationInfo);
    }
    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.componentSELeadGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.componentSELeadGrid);
        this.getComponentInTestSELead(paginationInfo);
    }
    public selectedRowIndex: string;
    onRowClick(event: any): boolean {
        console.log("Row click", event.args.rowindex);
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.componentSELeadGrid.getrowdata(event.args.rowindex);
        if (event.args.rightclick) {
            return false;
        }
        else {
            this.EditTestStatus(data.id, data.productID, data.versionID, data.rootID, 1, data.productDeliverableReleaseID);
        }
    }
    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='jqx-anchor-hover jqxgrid-cellrender-font' id=SETestInProgressRow" + rowdata.id + " onclick='return EditTestStatus(" + rowdata.id + "," + rowdata.productID + "," + rowdata.versionID + "," + rowdata.rootID + ",1," + rowdata.productDeliverableReleaseID +")'>" + value + " </a>";
//        element.addClass('components-in-test-ivory');
        return element[0].outerHTML; 
    };

}

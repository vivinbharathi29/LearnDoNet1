﻿import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { JobsDidNotRunAsScheduledService } from './jobs-did-not-run-as-scheduled.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';

@Component({
    selector: 'JobsDidNotRunAsScheduled',
    templateUrl: './jobs-did-not-run-as-scheduled.component.html',
    providers: [JobsDidNotRunAsScheduledService]
})

export class JobsDidnotRunAsScheduledComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public iHUBDidNotRunScheduled;
    constructor(http: Http, private service: JobsDidNotRunAsScheduledService)//,location:Location)
    {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'jobID', map: 'jobID' },
            { name: 'jobName', map: 'jobName' },
            { name: 'lastRun', map: 'lastRun', type: 'date' },
            { name: 'runEvery', map: 'runEvery' }
        ];

        this.jqxGridConfig.columns = [

            {
                text: 'Job ID',
                datafield: 'jobID', filtertype: 'number', width: '10%'
            },
            {
                text: 'Job Name',
                datafield: 'jobName', filtertype: 'input'
            },
            {
                text: 'Last Run',
                datafield: 'lastRun', filtertype: 'date', cellsFormat: 'MM/dd/yyyy HH:mm:ss tt', width: '23%'
            },
            {
                text: 'Run Every',
                datafield: 'runEvery', filtertype: 'input', width: '15%'
            }
        ];
    }

    getJobsDidNotRunAsScheduled() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getJobsDidNotRunAsScheduled(-1, false).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getJobsDidNotRunAsScheduled();
    }
}

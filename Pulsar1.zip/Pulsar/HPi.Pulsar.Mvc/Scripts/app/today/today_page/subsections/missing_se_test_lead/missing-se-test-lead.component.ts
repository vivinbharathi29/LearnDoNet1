﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\rajamanr
// Created          : 04/04/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="missing-se-test-lead.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, ViewChild, AfterViewInit, Injectable,ElementRef,NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
//import { Location } from '@angular/common';
import { MissingSETestLeadService } from './missing-se-test-lead.service';
import { MissingSETestLeadViewModel } from './missing-se-test-lead.view-model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
declare let $: any;
@Component({
    selector: 'missing-se-test-lead',
    templateUrl:'./missing-se-test-lead.component.html'
})
@Injectable()
export class MissingSETestLeadComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    public missingSETestLeads: MissingSETestLeadViewModel[];
    jqxGridConfig: jqxGridConfiguration;
    constructor(http: Http, private service: MissingSETestLeadService,private elementRef:ElementRef,private ngZone: NgZone) {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            MissingSETestCallBackFn: (value) => this.MissingSETestCallBack(value),
            component: this
        };
        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product', type: "string" },
            { name: 'id', map: 'id' },
            { name: 'fusionRequirements', map: 'fusionRequirements' }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'Product', columngroup: 'MissingSETestLead',
                datafield: 'product', width: "95%", filtertype: 'input', cellsrenderer: this.cellsrenderer
            }
            ,
            {
                text: 'Id', columngroup: 'MissingSETestLead',
                datafield: 'id',hidden:true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'FusionRequirements', columngroup: 'MissingSETestLead',
                datafield: 'fusionRequirements', hidden: true, cellsrenderer: this.cellsrenderer
            }
        ];
    }
    MissingSETestCallBack(status: any): void {
    this.getMissingSETestLeads();
    }
    getMissingSETestLeads() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMissingSETestLeads().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }
    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getMissingSETestLeads();
    }
   
    //Menu Code - Grid Row click event to display the menu
    public selectedRowIndex: string;
    onRowClick(event: any): boolean {
        console.log("Row click", event.args.rowindex);
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (event.args.rightclick) {
            return false;
        }
        else {
            missingsetest_onclick(data.id, data.fusionRequirements);
        }
    }
    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='jqx-anchor-hover jqxgrid-cellrender-font' href='javascript:missingsetest_onclick(" + rowdata.id + "," + rowdata.fusionRequirements +");' /> " + value + "</a>";
//        element.addClass('missing-se-test-ivory');
        return element[0].outerHTML; 
    };
}

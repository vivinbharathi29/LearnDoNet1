﻿import { Component, ViewChild, AfterViewInit, NgZone} from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { MissingSupplierCodesService } from './missing-supplier-codes.service';
import { ActivatedRoute, Router } from '@angular/router';
declare let $: any;
declare var modalPopup: any;
@Component({
    selector: 'missing-supplier-codes',
    templateUrl:'./missing-supplier-codes.component.html',
    providers: [MissingSupplierCodesService]
})

export class MissingSupplierCodesComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;
    //public title: string;
    missingSupplierCodesCallback(strID: any) {
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.getMissingSupplierCodes();
            //}
        }
    }

    constructor(private http: Http, private service: MissingSupplierCodesService, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.missingSupplierCodesCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = false;
        this.jqxGridConfig.datafields = [
            { name: 'categoryId', map: 'categoryId', type:'number' },
            { name: 'category', map: 'category', type: 'string'},
            { name: 'supplierId', map: 'supplierId', type: 'number'},
            { name: 'supplier', map: 'supplier', type: 'string' },
        ];

        this.jqxGridConfig.columns = [
            { text: 'Category ID', filtertype: 'number', hidden: true, datafield: 'categoryId', width: '20%' },
            { text: 'Category', filtertype: 'input', datafield: 'category', width: '50%' },
            { text: 'Supplier ID', filtertype: 'number', hidden: true, datafield: 'supplierId', width: '20%'},
            { text: 'Supplier', filtertype: 'input', datafield: 'supplier', width: '50%' },
        ];
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);        
        this.getMissingSupplierCodes();
        //this.service.getImpersonateName().subscribe(result => {
        //    this.title = result.json().title;
        //});
    }

    getMissingSupplierCodes() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMissingSupplierCodes().subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            }); }
        
    onRowClick(event: any): boolean {
        console.log("Row click", event.args.rowindex);
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        console.log(data);
        if (data != null) {
            var url = "";
            var title = "Supplier Code";
            var height = "650px";
            var width = "90%";
            
            url = "/excalibur/Deliverable/SupplierCode.asp?CategoryID=" + data.categoryId + "&VendorID=" + data.supplierId + "&app=PulsarPlus";
            

           // showPopup(url, title, height, width);
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['supplierCodes', data.categoryId, data.supplierId] } }]);
            modalPopup.show('#externalpopupMessage', "60%", "300px", "Edit Missing Supplier Code");
        }

        return false;
    }
}

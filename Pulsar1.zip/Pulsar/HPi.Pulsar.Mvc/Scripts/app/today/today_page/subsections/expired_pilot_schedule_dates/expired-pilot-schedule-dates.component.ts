﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ExpiredPilotScheduleDatesService } from './expired-pilot-schedule-dates.service';
import { Router } from '@angular/router';
import { ModalPopupComponent } from '../../../../Shared/modal_popup/modal-popup.component'
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'expired-pilot-schedule-dates',
    templateUrl:'./expired-pilot-schedule-dates.component.html',
    providers: [ExpiredPilotScheduleDatesService]
})

export class ExpiredPilotScheduleDatesComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;

    expiredPilotScheduleDatesCallback(strID: any) {
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.getExpiredPilotScheduleDates();
            //}
        }
    }

    constructor(private http: Http, private service: ExpiredPilotScheduleDatesService, private _ngZone: NgZone,private router:Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.expiredPilotScheduleDatesCallback(value),
            component: this
        };
        window['angularComponentRef_expiredPilot'] = { component: this, zone: _ngZone };
        window['angularComponentRef_expiredPilot'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.expiredPilotScheduleDatesCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = false;
        //this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number' },
            { name: 'productId', map: 'productId', type: 'number' },
            { name: 'productDeliverableReleaseId', map: 'productDeliverableReleaseId', type: 'number' },
            { name: 'deliverableId', map: 'deliverableId', type: 'number' },
            { name: 'isPulsarProduct', map: 'isPulsarProduct', type: 'bool' },
            { name: 'daysLate', map: 'daysLate', type: 'number' },
            { name: 'dotsname', map: 'dotsname', type: 'string' },
            { name: 'release', map: 'release', type: 'string' },
            { name: 'component', map: 'component', type: 'string' },
            { name: 'version', map: 'version', type: 'string' },
            { name: 'modelNumber', map: 'modelNumber', type: 'string' },
            { name: 'partNumber', map: 'partNumber', type: 'string' },

        ];

        this.jqxGridConfig.columns = [
            { text: 'Days Late', filtertype: 'number', datafield: 'daysLate', width: '10%' },
            { text: 'Product', filtertype: 'input', datafield: 'dotsname', width: '15%' },
            { text: 'Release', filtertype: 'input', datafield: 'release', width: '15%' },
            { text: 'Component', filtertype: 'input', datafield: 'component', width: '20%' },
            { text: 'Version', filtertype: 'input', datafield: 'version', width: '15%' },
            { text: 'Model', filtertype: 'input', datafield: 'modelNumber', width: '15%' },
            { text: 'Part Number', filtertype: 'input', datafield: 'partNumber', width: '10%' },
        ];
    }
    onClickUpdateStatus(strvalue): void {
        var index: number;
        var ids: string;
        var selectedCount: number;
        var rowcount: any;
        ids = "";
        var selectedIndices = this.myGrid.selectedrowindexes();
        selectedCount = this.myGrid.getrowdata(1).totalNoOfRows;

        var dataInfo = this.myGrid.getdatainformation();
        var paginationInfo = dataInfo.paginginformation;
        rowcount = dataInfo.rowscount;
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
        var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
        var endIndex = startIndex + displayRowsLength - 1;
        if (displayRowsLength < paginationInfo.pagesize) {
            endIndex = startIndex + displayRowsLength - 1;
        } 

        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                selectedCount = selectedCount - 1;
                ids += displayRows[index].id + ", ";
            }
        }
        ids = ids.slice(0, ids.length - 2); // Remove last two characters: comma and space
        alert(ids);
        if (ids == "") {
            alert("You must select the components you want to edit first.");
        }
        else {
            var strID;
            var url = "/excalibur/Deliverable/Commodity/MultiTestStatus.asp?VersionList=0," + ids;
            var title = "Multi Test Status";
            var height = 600;
            var width = 900;
            showPopup(url, title, height, width)
        }
        // Call Javascript function here. Pass productDeliverableIds as the parameter
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getExpiredPilotScheduleDates();

    }

    getExpiredPilotScheduleDates() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getExpiredPilotScheduleDates().subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }

    onPageChanged(event: any): void {
        this.myGrid.clearselection();
    }

    onRowClick(event: any): boolean {
        if (!event.args.rightclick) {
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            console.log(data);
            if (data != null) {
                var url = "";
                var title = "Pilot Status";
                var height = "650px";
                var width = "90%";
                if (data.isPulsarProduct) {//
                    //url = "/excalibur/deliverable/commodity/PilotStatusPulsar.asp?ProdID=" + data.ProductId + "&VersionID=" + data.DeliverableId +
                    //    "&ReleaseID=" + data.ProductDeliverableReleaseId + "&TodayPageSection=EditPilotStatus&ProductDeliverableId=" + data.id + "&app=PulsarPlus";
                    //showPopup(url, title, height, width);
                    this.router.navigate([{ outlets: { 'externalpopupWindow': ['pilotstatuspulsar', data.productId, data.deliverableId, data.productDeliverableReleaseId,data.id] } }]);
                    modalPopup.show('#externalpagepopup', "65%", "550px", "Pilot Status Pulsar");
                }
                else {
                   // url = "/excalibur/deliverable/commodity/PilotStatus.asp?ProdID=" + data.ProductId + "&VersionID=" + data.DeliverableId + "&TodayPageSection=EditPilotStatus&ProductDeliverableId=" + data.id + "&app=PulsarPlus";
                    //this.showPilotStatus(data.ProductId, data.DeliverableId);
                    this.router.navigate([{ outlets: { 'externalpopupWindow': ['pilotstatus', data.productId, data.deliverableId] } }]);
                    modalPopup.show('#externalpagepopup', "65%", "550px", "Pilot Status");
                }

                //showPopup(url, title, height, width);
            }

            return false;
        }
    }

    showPilotStatus(ProductId:any,versionID:any)
    {
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['pilotstatus', ProductId, versionID] } }]);
        modalPopup.show('#externalpagepopup', "85%", "650px", "Pilot Status");

    }
}

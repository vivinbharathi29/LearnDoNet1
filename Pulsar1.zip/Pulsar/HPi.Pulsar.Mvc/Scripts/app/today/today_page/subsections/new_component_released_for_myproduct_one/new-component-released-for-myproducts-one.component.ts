﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { NewComponentsReleasedForMyProductsOneService } from './new-component-released-for-myproducts-one.service';
import { NewComponentsReleasedForMyProductsOne } from './new-component-released-for-myproducts-one.viewmodel';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { jqxDateTimeInputComponent } from '../../../../jqwidgets-ts/angular_jqxdatetimeinput';

@Component({
    selector: 'sparekit-not-mapped-to-avs',
    templateUrl: './new-component-released-for-myproducts-one.component.html',
    providers: [NewComponentsReleasedForMyProductsOneService]
})


export class NewComponentsReleasedForMyProductsOneComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;    
    jqxGridConfig: jqxGridConfiguration;
    public newComponentsReleasedForMyProductsOneComponent: NewComponentsReleasedForMyProductsOne;
    public selectedRowIndex: string;
    mbp: MessageBoxButton;
    MultiDeveloperSignoffCallback(strID) {
        if (typeof (strID) != "undefined") {
            if (strID > 0) {
                console.log(strID);
                this.reloadGrid();
            }
        }
    }
    constructor(private http: Http, private service: NewComponentsReleasedForMyProductsOneService, private router: Router, private _ngZone: NgZone, private messageBox: MessageBox) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.MultiDeveloperSignoffCallback(value),
            component: this
        };
        window['angularMoveToDate'] = { component: this, zone: _ngZone };
        window['angularMoveToDate'] = {
            zone: this._ngZone,            
            popUpCallBackFn: (value, testdate, confidenceStatus, qualComments) => this.updateQualStatus(value, testdate, confidenceStatus, qualComments),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'string' },
            { name: 'product', map: 'product' },
            { name: 'hfcn', map: 'hfcn' },
            { name: 'vendor', map: 'vendor' },
            { name: 'component', map: 'component' },
            { name: 'hw', map: 'hw' },
            { name: 'fw', map: 'fw' },
            { name: 'rev', map: 'rev' },
            { name: 'model', map: 'model' },
            { name: 'part', map: 'part' },
            { name: 'totalNoOfRows', map: 'totalNoOfRows' },
            { name: 'productDeliverableId', map: 'productDeliverableId' },
            { name: 'productId', map: 'productId' },
            { name: 'totalNoOfRows', map: 'totalNoOfRows' },
            { name: 'productDeliverableReleaseID', map: 'productDeliverableReleaseID' },
            { name: 'isPulsarProduct', map: 'isPulsarProduct' },
            { name: 'release', map: 'release' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'input', datafield: 'id', width: '8%' },
            { text: 'Product', filtertype: 'input', datafield: 'product', width: '10%' },
            { text: 'Release', filtertype: 'input', datafield: 'release', width: '7%' },
            { text: 'HFCN', filtertype: 'input', datafield: 'hfcn', width: '7%' },
            { text: 'Vendor', filtertype: 'input', datafield: 'vendor', width: '9%' },
            { text: 'Component', filtertype: 'input', datafield: 'component', width: '30%' },
            { text: 'HW', filtertype: 'input', datafield: 'hw', width: '8%' },
            { text: 'FW', filtertype: 'input', datafield: 'fw', width: '13%' },
            { text: 'Rev', filtertype: 'input', datafield: 'rev', width: '10%' },
            { text: 'Model', filtertype: 'input', datafield: 'model', width: '14%' },
            { text: 'Part', filtertype: 'input', datafield: 'part', width: '9%' },
            { text: 'productDeliverableId', filtertype: 'input', datafield: 'productDeliverableId', hidden: true },
            { text: 'productId', filtertype: 'input', datafield: 'productId', hidden: true },
            { text: 'totalNoOfRows', filtertype: 'input', datafield: 'totalNoOfRows', hidden: true },
            { text: 'productDeliverableReleaseID', filtertype: 'input', datafield: 'productDeliverableReleaseID', hidden: true },
            { text: 'isPulsarProduct', filtertype: 'input', datafield: 'isPulsarProduct', hidden: true },
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'product': FilterColumnTypeEnum.String,
            'release': FilterColumnTypeEnum.String,
            'hfcn': FilterColumnTypeEnum.String,
            'vendor': FilterColumnTypeEnum.String,
            'component': FilterColumnTypeEnum.String,
            'hw': FilterColumnTypeEnum.String,
            'fw': FilterColumnTypeEnum.String,
            'rev': FilterColumnTypeEnum.String,
            'model': FilterColumnTypeEnum.String,
            'part': FilterColumnTypeEnum.String
        }
    }

    numCallback = (response: MessageBoxButton): void => {
        this.mbp = response;
    }

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleasedForMyProductsOne(paginationInfo);
    }
    updateQualStatus(strvalue, testDate, confidenceStatus, qualComments): void {        
        var index: number;
        var productDeliverableIds: string;
        var productDeliverableReleaseIDs: string;
        var checkedIds = '';
        var selectedCount: string;
        var ajaxurl: string;        
        productDeliverableIds = "";
        var selectedIndices = this.myGrid.selectedrowindexes();
        selectedCount = this.myGrid.getdatainformation().rowscount;
        //for (index = 0; index < selectedIndices.length; index++) {           
        //    productDeliverableReleaseIDs = this.myGrid.getrowdata(selectedIndices[index]).productDeliverableReleaseID + ",";
        //    productDeliverableIds = this.myGrid.getrowdata(selectedIndices[index]).productDeliverableId + ",";
        //    checkedIds += this.myGrid.getrowdata(selectedIndices[index]).productDeliverableId + "_" + this.myGrid.getrowdata(selectedIndices[index]).productDeliverableReleaseID + ",";
        //}

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = this.myGrid.getrows().length;
        var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
        var endIndex = startIndex + paginationInfo.PageSize - 1;
        if (displayRowsLength < paginationInfo.PageSize) {
            endIndex = startIndex + displayRowsLength - 1;
        }
        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                productDeliverableReleaseIDs = displayRows[index].productDeliverableReleaseID + ",";
                productDeliverableIds = displayRows[index].productDeliverableId + ",";
                checkedIds += displayRows[index].productDeliverableId + "_" + displayRows[index].productDeliverableReleaseID + ",";
            }
        }

        if (productDeliverableIds != undefined) {
            productDeliverableIds = productDeliverableIds.slice(0, productDeliverableIds.length - 1); // Remove last two characters: comma and space            
        }
        if (productDeliverableReleaseIDs != undefined) {
            productDeliverableReleaseIDs = productDeliverableReleaseIDs.slice(0, productDeliverableReleaseIDs.length - 1);
        }
        if (checkedIds != undefined) {
            checkedIds = checkedIds.slice(0, checkedIds.length - 1);
        }
       
        if (productDeliverableIds == "") {
            this.messageBox.Show("New Hardware Components Released for My Product", "You must select the components you want to remove first.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
        }
        else {
            this.newComponentsReleasedForMyProductsOneComponent = new NewComponentsReleasedForMyProductsOne();
            this.newComponentsReleasedForMyProductsOneComponent.selectedIds = checkedIds; //productDeliverableIds;
            this.newComponentsReleasedForMyProductsOneComponent.statusId = strvalue;
            this.newComponentsReleasedForMyProductsOneComponent.qualDate = testDate;
            this.newComponentsReleasedForMyProductsOneComponent.qualConfidence = strvalue == 3 ? confidenceStatus : 0;
            this.newComponentsReleasedForMyProductsOneComponent.qualComments = qualComments;
            this.service.saveOverrideFeatureFeedback(this.newComponentsReleasedForMyProductsOneComponent).subscribe(data => {
                if (data != null) {
                    var paginationInfo: PaginationModel;
                    paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                    this.getNewComponentsReleasedForMyProductsOne(paginationInfo);
                    this.myGrid.clearselection();
                }
            });
            var paginationInfo: PaginationModel;
            paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
            this.getNewComponentsReleasedForMyProductsOne(paginationInfo);
        }
    }


    getNewComponentsReleasedForMyProductsOne(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getNewComponentsReleasedForMyProductsOneComponents(paginationInfo).subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata("Data");
                this.myGrid.hideloadelement();
            });
    }
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleasedForMyProductsOne(paginationInfo);
        this.myGrid.clearselection();

    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleasedForMyProductsOne(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleasedForMyProductsOne(paginationInfo);
    }


    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleasedForMyProductsOne(paginationInfo);
    }

    editQualStatus(productid: number, versionid: number, ispulsarproduct: boolean, prodDeliverableRelaseId: number) {
        var url = "/Excalibur/deliverable/commodity/QualStatus.asp?ProdID=" + productid + "&VersionID=" + versionid + "&TodayPageSection=" + "EditCommodityStatus" + "&app=" + "PulsarPlus";
        var title = "Qualification Status";
        var height = 550;
        var width = 750;
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['qualstatus', productid, versionid, prodDeliverableRelaseId, ispulsarproduct, 'EditCommodityStatus'] } }]);
        modalPopup.show('#externalpagepopup', "60%", "550px", "Qualification Status");
    }

    movetoDate() {
        var selectedIndices = this.myGrid.selectedrowindexes();
        if (selectedIndices.length > 0) {
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['movetodateformyproductone'] } }]);
            modalPopupSecondlevel.show('#externalpagepopup', "90%", "42%", "Move To Date");
        }
        else {
            this.messageBox.Show("New Hardware Components Released for My Product", "You must select the components you want to remove first.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
        }

    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var productId = data.productId;
            var rootId = data.id;
            var isPulsarProduct = data.isPulsarProduct;
            var productDeliverableReleaseID = data.productDeliverableReleaseID;
            this.editQualStatus(productId, rootId, isPulsarProduct, productDeliverableReleaseID);
        }
        return false;
    }

    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:newcomponentreleasedOne_onclick(" + rowdata.productId + " ," + rowdata.id + "," + rowdata.isPulsarProduct + "," + rowdata.productDeliverableReleaseID + ");' /> " + value + "</a>";
        return element[0].outerHTML;
    };
}


﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay
// Created          : 04/25/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="feature-removed-from-post-prl-lock.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, ViewChild, AfterViewInit, Injectable, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { FeatureRemovedFromPRLService } from './feature-removed-from-post-prl-lock.service';
import { FeatureRemovedFromPRLViewModel } from './feature-removed-from-prl-view-model.model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';

@Component({
    selector: 'feature-removed-from-post-prl-lock',
    templateUrl:'./feature-removed-from-post-prl-lock.component.html'
})
export class FeatureRemovedFromPRLComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;

    public featureRemovedFromPRLViewModel: FeatureRemovedFromPRLViewModel[];
    public featuresRemovedFromPRLViewModel: FeatureRemovedFromPRLViewModel;
    jqxGridConfig: jqxGridConfiguration;
    public currentUserName: string;
    public selectedRowIndex: string;

    featureRemovedFromPRLCallback(strID: any) {
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.getFeatureRemovedFromPRL();
            //}
        }
    }

    constructor(http: Http, private service: FeatureRemovedFromPRLService, private _ngZone: NgZone) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.featureRemovedFromPRLCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        //this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'featureActionItemId', map: 'featureActionItemId' },
            { name: 'productVersionId', map: 'productVersionId' },
            { name: 'actionType', map: 'actionType' },
            { name: 'currentUserName', map: 'currentUserName' },
            { name: 'productName', map: 'productName' },
            { name: 'scmName', map: 'scmName' },
            { name: 'featureId', map: 'featureId' },
            { name: 'featureName', map: 'featureName' }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'Product Name',
                datafield: 'productName', width: '30%', filtertype: 'input'
            },
            {
                text: 'SCM Name',
                datafield: 'scmName', width: '20%', filtertype: 'input'
            },
            {
                text: 'Feature ID',
                datafield: 'featureId', width: '20%', filtertype: 'number'
            },
            {
                text: 'Feature Full Name',
                datafield: 'featureName', width: '30%', filtertype: 'input'
            }
        ];

    }

    getFeatureRemovedFromPRL() {
        console.log("reload");
        this.myGrid.showdefaultloadelement(true);
        this.service.getFeatureRemovedFromPRL("load").subscribe(result => {
            console.log("result");
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        }, Error => { console.log("reaload error", Error); });
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '130px', height: '70px', mode: 'popup', autoOpenPopup: false,

    };

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        this.service.getImpersonateName().subscribe(result => {
            this.currentUserName = result.json().title;
        });
        this.getFeatureRemovedFromPRL();
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("menu itemclick", this.selectedRowIndex);
        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        //rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        //console.log(rowIndex);
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        console.log(gridData);
        console.log(menuItem); // Get the Menu Item name
        switch (menuItem) {
            case "Obsolete AV":
                this.FeatureChange_oncontextmenu(gridData.featureActionItemId, 1, gridData.currentUserName, rowIndex);
                break;
            case "Not Actionable":
                this.FeatureChange_oncontextmenu(gridData.featureActionItemId, 2, gridData.currentUserName, rowIndex);
                break;
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
    }

    FeatureChange_oncontextmenu(featureActionItemId: number, actionType: number, currentUser: string, gridRowId: number): void {
        this.featuresRemovedFromPRLViewModel = new FeatureRemovedFromPRLViewModel();
        this.featuresRemovedFromPRLViewModel.featureActionItemId = featureActionItemId;
        this.featuresRemovedFromPRLViewModel.actionType = actionType;
        this.featuresRemovedFromPRLViewModel.currentUserName = currentUser;
        this.service.updateFeatureActionStatus(this.featuresRemovedFromPRLViewModel).subscribe(x => {
            if (x.json() == true) {
                this.getFeatureRemovedFromPRL();
            }
        });
    }
}

﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay
// Created          : 04/25/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 10/03/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="core-team-working-list.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, ViewChild, AfterViewInit, Injectable, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { CoreTeamWorkingListService } from './core-team-working-list.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'core-team-working-list',
    templateUrl:'./core-team-working-list.component.html'
})
export class CoreTeamWorkingListComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    public selectedRowIndex: string;
    jqxGridConfig: jqxGridConfiguration;    
    
    coreTeamWorkingListCallback(result: any) {
        if (typeof (result) != undefined) {
            this.myGrid.clearselection();
            this.getCoreTeamWorkingDetails();
        }
    }

    constructor(http: Http, private service: CoreTeamWorkingListService, private _ngZone: NgZone, private router: Router, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.coreTeamWorkingListCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'rootId', map: 'rootId' },
            { name: 'categoryId', map: 'categoryId' },
            { name: 'component', map: 'component' },
            { name: 'version', map: 'version' },
            { name: 'vendor', map: 'vendor' },
            { name: 'model', map: 'model' },
            { name: 'part', map: 'part' },
            { name: 'developer', map: 'developer' },
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'ID',
                datafield: 'id', width: '10%', filtertype: 'number'
            },
            {
                text: 'Component',
                datafield: 'component', width: '30%', filtertype: 'input'
            },
            {
                text: 'Version',
                datafield: 'version', width: '10%', filtertype: 'input'
            },
            {
                text: 'Vendor',
                datafield: 'vendor', width: '11.8%', filtertype: 'input'
            },
            {
                text: 'Model',
                datafield: 'model', width: '10%', filtertype: 'input'
            },
            {
                text: 'Part',
                datafield: 'part', width: '12%', filtertype: 'input'
            },
            {
                text: 'Developer',
                datafield: 'developer', width: '14%', filtertype: 'input'
            }
        ];

    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    showContextmenu(): boolean {
        return false;
    }

    getCoreTeamWorkingDetails() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getCoreTeamWorkingDetails().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    onPageChanged(event: any): void {
        this.myGrid.clearselection();
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '150px', height: '160px', mode: 'popup', autoOpenPopup: false,

    };

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        this.getCoreTeamWorkingDetails();
    }

    coreTeamMultiUpdate(functionType: number): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var idList = "";
        var index: number;
        var rowcount: any;
        //for (index = 0; index < selectedIndices.length; index++) {
        //    idList += this.myGrid.getrowdata(selectedIndices[index]).id + ",";
        //}

        var dataInfo = this.myGrid.getdatainformation();
        var paginationInfo = dataInfo.paginginformation;
        rowcount = dataInfo.rowscount;
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
        var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
        var endIndex = startIndex + displayRowsLength - 1;
        if (displayRowsLength < paginationInfo.pagesize) {
            endIndex = startIndex + displayRowsLength - 1;
        } 

        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                idList += displayRows[index].id + ",";
            }
        }

        idList = idList.slice(0, idList.length - 1);
        if (idList == "") {
            alert("You must select the components first.");
        }
        else {
            //idList = idList.slice(0, idList.length - 1); // Remove last two characters: comma and space
            var url = "";
            var title = "";
            var height = "600px";
            var width = "90%";
            url = "/excalibur/Deliverable/Commodity/Release.asp?VersionID=" + idList + "&txtFunction=" + functionType + "&app=PulsarPlus";
            title = "Release Versions";
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['release', idList, functionType] } }]);
            modalPopup.show('#externalpagepopup', "1000px", "500px", "Release Versions");
        }
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        if (gridData != undefined) {
            switch (menuItem) {
                case "Release...":
                    this.releaseHW(1, gridData.id, 1);
                    break;
                case "Cancel...":
                    this.releaseHW(2, gridData.id, 1);
                    break;
                case "Where Used":
                    this.whereUsed(gridData.id, gridData.categoryId, gridData.rootId);
                    break;
                case "Choose Products...":
                    this.chooseProducts(gridData.id);
                    break;
                case "Test Results...":
                    this.testResultsSummary(gridData.id);
                    break;
                case "Properties":
                    this.deliverableProperties(gridData.id);
                    break;
            }
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
    }

    releaseHW(action: number, id: number, source: number): void {
        var url = "";
        var title = "";
        var height = "550px";
        var width = "90%";
        url = "/excalibur/Release.asp?Action=" + action + "&ID=" + id + "&app=PulsarPlus";
        title = "Component Workflow";
        if (source == 1) {
            adjustableShowPopupSecondlevel(url, title, height, width, "790px");
            //showPopup(url, title, height, width);
        } else {
            alert("Are you sure you want to release the selected versions?");
        }
    }

    whereUsed(id: number, categoryId: number, rootId: number): void {
        var url = "";
        var title = "";
        var height = "600px";
        var width = "90%";
        if (id == 0) {
            //url = this.location.prepareExternalUrl("/product/Product/GetProductHardwareMatrix?lstCategory=" + categoryId + "&lstRoot=" + rootId);
            url = "/excalibur/Deliverable/HardwareMatrix.asp?lstCategory=" + categoryId + "&lstRoot=" + rootId + "&app=PulsarPlus";
        }
        else {
            //url = this.location.prepareExternalUrl("/product/Product/GetProductHardwareMatrix?lstCategory=" + categoryId + "&lstRoot=" + rootId + "&HighlightRow=" + id);
            url = "/excalibur/Deliverable/HardwareMatrix.asp?lstCategory=" + categoryId + "&lstRoot=" + rootId + "&HighlightRow=" + id + "&app=PulsarPlus";
        }
        window.open(url);
    }

    chooseProducts(versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/Deliverable/ProductsSupported.asp?VersionID=" + versionId + "&app=PulsarPlus";
        title = "Update Supported Products";
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['updateproductsupported', versionId] } }]);
        modalPopup.show('#externalpagepopup', "90%", "650px", "Update Supported Products");

    }

    testResultsSummary(id: number): void {
        alert("Under Development.");
    }

    deliverableProperties(versionId: number): void {
        var url = "";
        var title = "";
        var height = "600px";
        var width = "90%";
        url = "/excalibur/WizardFrames.asp?Type=1&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
    }
}

﻿import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum'
import { AvsNotMappedtoSpareKitsService } from './avs-not-mapped-to-sparekits.service';

@Component({
    selector: 'avs-not-mapped-to-sparekit',
    templateUrl:'./avs-not-mapped-to-sparekits.component.html',
    providers: [AvsNotMappedtoSpareKitsService]
})


export class AvsNotMappedtoSpareKitsComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;    
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;    
    public selectedRowIndex: string;

    constructor(private http: Http, private service: AvsNotMappedtoSpareKitsService) {

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'productName', map: 'productName' },
            { name: 'brandName', map: 'brandName' },
            { name: 'avNo', map: 'avNo' },
            { name: 'gpgDescription', map: 'gpgDescription', type:'string' },
            { name: 'avFeatureCategory', map: 'avFeatureCategory' },
            { name: 'kmat', map: 'kmat' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'Program', filtertype: 'input', datafield: 'productName', width: '20%' },
            { text: 'Brand', filtertype: 'input', datafield: 'brandName', width: '20%' },
            { text: 'Feature Category', filtertype: 'input', datafield: 'avFeatureCategory', width: '20%' },
            { text: 'GPG Description', filtertype: 'input', datafield: 'gpgDescription', width: '20%' },
            { text: 'AV', filtertype: 'input', datafield: 'avNo', width: '20%' },
            { text: 'kmat', filtertype: 'input', hidden: true, datafield: 'kmat', width: 170 },
        ];

        this.jqxGridConfig.columnTypes = {
            'productName': FilterColumnTypeEnum.String,
            'brandName': FilterColumnTypeEnum.String,
            'avFeatureCategory': FilterColumnTypeEnum.String,
            'gpgDescription': FilterColumnTypeEnum.String,
            'avNo': FilterColumnTypeEnum.String,
            'kmat': FilterColumnTypeEnum.String
        }

    }


    getAvsNotMappedtoASpareKits(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getAvsNotMappedtoSpareKits(paginationInfo).subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();                
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAvsNotMappedtoASpareKits(paginationInfo);
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAvsNotMappedtoASpareKits(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAvsNotMappedtoASpareKits(paginationInfo);
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '180px', height: '50px', mode: 'popup', autoOpenPopup: false
    };

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAvsNotMappedtoASpareKits(paginationInfo);

    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        switch (menuItem) {
            case "Ignore AV On Product...":
                this.getIgnoreAv(gridData.kmat, gridData.avNo);
                break;            
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
    }

    getIgnoreAv(kmat: number, avNo: number): void {
        var parameters = "function=IgnoreAv&KMAT=" + kmat + "&AV=" + avNo;
        this.service.getIgnoreAv(parameters).subscribe(
            (res: Response) => {
                this.myGrid.clearselection();
                var paginationInfo: PaginationModel;
                paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                this.getAvsNotMappedtoASpareKits(paginationInfo);
            },
            error =>
            {
            });
    }

}

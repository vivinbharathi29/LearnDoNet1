﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/23/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 02/15/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="linked-component-not-used-by-commodity-team.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Router, ActivatedRoute, Params,NavigationExtras } from '@angular/router'
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { LinkedComponentsNotUsedByCommodityTeamService } from './linked-component-not-used-by-commodity-team.service';
import { LinkedComponentsNotUsedByCommodityTeamViewModel } from './linked-component-not-used-by-commodity-team.viewmodel';

@Component({
    selector: 'linked-component-not-used-by-commodity-team',
    templateUrl:'./linked-component-not-used-by-commodity-team.component.html'
})

export class LinkedComponentsNotUsedByCommodityTeamComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public userId: number = 0;
    private mbp: MessageBoxButton;
    public linkedComponentNotUsed: LinkedComponentsNotUsedByCommodityTeamViewModel[];
    public selectedRowIndex: string;
    EOLMultiUpdateCallback(result) {
        if (typeof (result) != "undefined") {
            this.reloadGrid();
        }
    }
    EditAccessoryStatus2Callback(result) {
        if (typeof (result) != "undefined") {
                this.reloadGrid();
        }
    }
    constructor(http: Http, private service: LinkedComponentsNotUsedByCommodityTeamService, private activatedRoute: ActivatedRoute, private messageBox: MessageBox, private _ngZone: NgZone,private route:Router) {
        window['angularComponentRef_LinkedNoLonger'] = { component: this, zone: _ngZone };
        window['angularComponentRef_LinkedNoLonger'] = {
            zone: this._ngZone,
            EOLMultiUpdateCallbackFn: (value) => this.EOLMultiUpdateCallback(value),
            EditAccessoryStatus2CallbackFn: (value) => this.EditAccessoryStatus2Callback(value),
            component: this
        };

        //this.activatedRoute.queryParams.subscribe((params: Params) => {
        //    this.userId = params['UserId'];
        //});
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number' },
            { name: 'deliverableId', map: 'deliverableId' },
            { name: 'productId', map: 'productId' },
            { name: 'dotsName', map: 'dotsName', type: 'string'  },
            { name: 'deliverableName', map: 'deliverableName', type: 'string'  },
            { name: 'modelNumber', map: 'modelNumber', type: 'string'  },
            { name: 'partNumber', map: 'partNumber', type: 'string'  },
            { name: 'version', map: 'version', type: 'string'  },
            { name: 'userId', map: 'userId' },
            { name: 'release', map: 'release', type: 'string' },
            { name: 'productDeliverableReleaseId', map: 'productDeliverableReleaseId'},
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'LinkedComponentNotUsed',
                datafield: 'id', width: '10%', filtertype: 'number', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'UserId', columngroup: 'LinkedComponentNotUsed',
                datafield: 'userId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ProductDeliverableReleaseId', columngroup: 'LinkedComponentNotUsed',
                datafield: 'productDeliverableReleaseId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'DeliverableId', columngroup: 'LinkedComponentNotUsed',
                datafield: 'deliverableId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ProductId', columngroup: 'LinkedComponentNotUsed',
                datafield: 'productId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Release', columngroup: 'LinkedComponentNotUsed',
                datafield: 'release', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Product', columngroup: 'LinkedComponentNotUsed',
                datafield: 'dotsName', width: '15%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Component', columngroup: 'LinkedComponentNotUsed',
                datafield: 'deliverableName', width: '23%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Version', columngroup: 'LinkedComponentNotUsed',
                datafield: 'version', width: '15%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Model', columngroup: 'LinkedComponentNotUsed',
                datafield: 'modelNumber', cellsalign: 'left', align: 'left', width: '15%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Part Number', columngroup: 'LinkedComponentNotUsed',
                datafield: 'partNumber', cellsalign: 'left', align: 'left', width: '12%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            }
        ];
    }

    EOLMultiUpdate(userId: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        this.messageBox.Show("Confirm Deactivation", "Are you sure you want to deactivate all of these components?", MessageBoxType.OKCancel, MessageBoxIcon.Information, "400", this.confirmationMessage);
    }

    getLinkedComponentsNotUsedByCommodityTeam() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getLinkedComponentsNotUsedByCommodityTeam().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            if (result.json().length > 0) {
                this.userId = result.json()[0]['userId'];
            }
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getLinkedComponentsNotUsedByCommodityTeam();
    }

    reloadGrid(): void {
        this.getLinkedComponentsNotUsedByCommodityTeam();
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
            EOLMultiUpdate(this.userId);
        }
        else if (this.mbp == MessageBoxButton.Cancel) {

        }
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var id = data.id;
            var productId = data.productId;
            var deliverableId = data.deliverableId;
            var versionId = data.deliverableId;
            var productDeliverableReleaseId = data.productDeliverableReleaseId;
            //EditAccessoryStatus2(id, productId, deliverableId, productDeliverableReleaseId);
            if (productDeliverableReleaseId == "0") {
                this.route.navigate([{ outlets: { 'externalpopupWindow': ['accessorystatus', productId, versionId] } }]);
                modalPopup.show('#externalpagepopup', "85%", "650px", "Update Accessory Status");
            }
            else {
                this.route.navigate([{ outlets: { 'externalpopupWindow': ['accessorystatuspulsar', id, productId, deliverableId, productDeliverableReleaseId,'EditAccessoryStatus2'] } }]);
                modalPopup.show('#externalpagepopup', "60%", "550px", "Update Accessory Status - Pulsar");
            }
        }
        return false;
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a ID='AccessoryLeverageBrokenRow&" + rowdata.id + "' class='jqx-anchor-hover jqxgrid-cellrender-font' onclick='javascript:EditAccessoryStatus2(" + rowdata.id + "," + rowdata.productId + "," + rowdata.deliverableId + "," + rowdata.productDeliverableReleaseId + ");' /> " + value + " </a>";
        return element[0].outerHTML;
    };
}

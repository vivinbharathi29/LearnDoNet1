﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/25/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/08/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="component-missing-subassembly-or-kitnumber.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { ComponentMissingSubAssemblyOrKitNumberService } from './component-missing-subassembly-or-kitnumber.service';

@Component({
    selector: 'component-missing-subassembly-or-kitnumber',
    templateUrl:'./component-missing-subassembly-or-kitnumber.component.html'
})

export class ComponentMissingSubAssemblyOrKitNumberComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public userId: number = 0;
    private mbp: MessageBoxButton;
    EOLMultiUpdateCallback(result) {
        if (typeof (result) != undefined) {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: ComponentMissingSubAssemblyOrKitNumberService, private activatedRoute: ActivatedRoute, private messageBox: MessageBox, private _ngZone: NgZone) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            EOLMultiUpdateCallbackFn: (value) => this.EOLMultiUpdateCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number'  },
            { name: 'deliverableName', map: 'deliverableName', type: 'string'  },
            { name: 'subAssembly', map: 'subAssembly', type: 'string'  },
            { name: 'kitNumber', map: 'kitNumber', type: 'string'  },
            { name: 'userId', map: 'userId' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'MissingSubAssemblyOrKitNumber',
                datafield: 'id', width: '15%', filtertype: 'number'
            },
            {
                text: 'Component', columngroup: 'MissingSubAssemblyOrKitNumber',
                datafield: 'deliverableName', width: '40%', filtertype: 'input'
            },
            {
                text: 'Subassembly', columngroup: 'MissingSubAssemblyOrKitNumber',
                datafield: 'subAssembly', width: '25%', filtertype: 'input'
            },
            {
                text: 'Kit Number', columngroup: 'MissingSubAssemblyOrKitNumber',
                datafield: 'kitNumber', cellsalign: 'left', align: 'left', width: '20%', filtertype: 'input'
            },
            {
                text: 'UserId', columngroup: 'MissingSubAssemblyOrKitNumber',
                datafield: 'userId', hidden: true
            }
        ];
    }

    EOLMultiUpdate(userId: any): void {
        this.messageBox.Show("Confirm Deactivation", "Are you sure you want to deactivate all of these components?", MessageBoxType.OKCancel, MessageBoxIcon.Information, "400", this.confirmationMessage)
    }

    getComponentsMissingSubAssemblyOrKitNumber() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getComponentsMissingSubAssemblyOrKitNumber().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            if (result.json().length > 0) {
                this.userId = result.json()[0]['userId'];
            }
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getComponentsMissingSubAssemblyOrKitNumber();
    }

    reloadGrid(): void {
        this.getComponentsMissingSubAssemblyOrKitNumber();
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
            EOLMultiUpdate(this.userId);
        }
        else if (this.mbp == MessageBoxButton.Cancel) {
        }
    }
}
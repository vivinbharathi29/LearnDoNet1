// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : subburay
// Created          : 05/29/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/08/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="today-page.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';

@Injectable()
export class ComponentsPassedPlannedReleaseDateService {
    constructor(private http: Http, private location: Location) {
    }

    getComponentsPassedPlannedReleaseDate() {
        return this.http.get(this.location.prepareExternalUrl('/Today/TodayPage/GetComponentsPassedPlannedReleaseDate'));
    }
}
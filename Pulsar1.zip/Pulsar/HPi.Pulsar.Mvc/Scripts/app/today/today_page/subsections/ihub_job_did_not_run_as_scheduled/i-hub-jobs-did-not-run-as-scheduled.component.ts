﻿import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { IHUBJobsDidNotRunAsScheduledService } from './i-hub-jobs-did-not-run-as-scheduled.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';

@Component({
    selector: 'iHUBJobsDidNotRunAsScheduled',
    templateUrl: './i-hub-jobs-did-not-run-as-scheduled.component.html',
    providers: [IHUBJobsDidNotRunAsScheduledService]
})

export class IHUBJobsDidnotRunAsScheduledComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public iHUBDidNotRunScheduled;
    constructor(http: Http, private service: IHUBJobsDidNotRunAsScheduledService)//,location:Location)
    {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'jobID', map: 'jobID' },
            { name: 'jobName', map: 'jobName' },
            { name: 'lastRun', map: 'lastRun' },
            { name: 'runEvery', map: 'runEvery' }
        ];

        this.jqxGridConfig.columns = [

            {
                text: 'Job ID',
                datafield: 'jobID', filtertype: 'number', width: '10%'
            },
            {
                text: 'Job Name',
                datafield: 'jobName', filtertype: 'input'
            },
            {
                text: 'Last Run',
                datafield: 'lastRun', filtertype: 'date', cellsformat: 'MM/dd/yyyy', width: '23%'
            },
            {
                text: 'Run Every',
                datafield: 'runEvery', filtertype: 'input', width: '15%'
            }
        ];


    }

    getIHUBJobsDidNotRunAsScheduled() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getIHUBJobsDidNotRunAsScheduled(-1, true).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getIHUBJobsDidNotRunAsScheduled();
    }
}

﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 03/24/2017
// Last Modified By : Shanmugaraj.M
// Last Modified On : 01/06/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="avs-deleted-but-mapped-to-sparekits" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class AvsDeletedButMappedtoSparekitsService {
    constructor(private http: Http, private location: Location) {

    }
    getAvsDeletedbutMappedtoSpareKits(paginationInfo: PaginationModel) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetDeletedAvsMappedToSpareKits'), JSON.stringify(paginationInfo), options);
    }

    updateDeletedAvMappedToSPS(params: string) {
        console.log("service call");
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        let options = new RequestOptions({ headers: headers });
        //'/Excalibur/mobilese/today/UpdateAv.asp'
        var url = this.location.prepareExternalUrl('/today/TodayPage/UpdateAV');
        return this.http.post(url, params, options);
    }
}

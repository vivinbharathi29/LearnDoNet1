﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05-13-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="cr-proposed.viewmodel.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class CRProposedViewModel {
    id: number;
    dotsName: string;
    status: string;
    owner: string;
    submitter: string;
    summary: string;
    type: string;
    totalNoOfRows: number;
}
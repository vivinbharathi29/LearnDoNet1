﻿export class FeaturesRequestingRootComponentsVM {
    id: number;
    feature: string;
    rootNamingSuggestion: string;
    featureCategory: string;
    category: string;
    updatedBy: string;
    updated: string;
}
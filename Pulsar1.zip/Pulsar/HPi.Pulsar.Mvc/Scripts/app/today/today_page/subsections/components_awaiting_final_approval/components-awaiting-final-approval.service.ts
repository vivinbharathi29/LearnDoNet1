// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 04-28-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="today-page.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response,URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Injectable()
export class ComponentsAwaitingFinalApprovalService {
    constructor(private http: Http, private location: Location) {
    }

    getComponentsAwaitingFinalApprovals(paginationInfo: PaginationModel) {
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetComponentsAwaitingFinalApproval'), JSON.stringify(paginationInfo), options);
    }		
}
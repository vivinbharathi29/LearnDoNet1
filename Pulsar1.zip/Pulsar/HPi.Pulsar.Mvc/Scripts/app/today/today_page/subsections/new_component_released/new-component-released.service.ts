/// <reference path="target-deliverable-version-web-view-model.model.ts" />
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 06/20/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="today-page.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { pagination } from '../../../../shared/pagination-model.model';
import { ListSortDirection } from '../../../../shared/listsortdirection';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { TargetDeliverableVersionWebViewModel } from './target-deliverable-version-web-view-model.model';

@Injectable()
export class NewComponentsReleasedService {
    public targetDeliverableVersionWebViewModel: TargetDeliverableVersionWebViewModel;
    constructor(private http: Http, private location: Location) {

    }

    getNewComponentsReleasedService(paginationInfo: PaginationModel, productId: string = '') {
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetNewComponentsReleased/' + productId), JSON.stringify(paginationInfo), options);
    }

    getNewComponentsReleasedSummaryService(productId: string) {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetNewComponentsReleasedSummary/' + productId));
    }
    SaveTargetQuick(pmAlerts: any, targetType: any, productVersionID: any, deliverableVersionID: any) {
        //SaveTargetQuick(pmAlerts: any, targetType: any, productVersionID: any, deliverableVersionID: any, releaseId: any, resetOtherTargets: any) {
        this.targetDeliverableVersionWebViewModel = new TargetDeliverableVersionWebViewModel();
        this.targetDeliverableVersionWebViewModel.pMAlerts = pmAlerts;
        this.targetDeliverableVersionWebViewModel.targetValue = targetType;
        this.targetDeliverableVersionWebViewModel.productVersionID = productVersionID;
        this.targetDeliverableVersionWebViewModel.deliverableVersionID = deliverableVersionID;
        //this.targetDeliverableVersionWebViewModel.releaseId = releaseId;
        //this.targetDeliverableVersionWebViewModel.resetOtherTargets = resetOtherTargets;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('product/Product/UpdateTargetDeliverableVersionWeb'), JSON.stringify(this.targetDeliverableVersionWebViewModel), options);
    }

}
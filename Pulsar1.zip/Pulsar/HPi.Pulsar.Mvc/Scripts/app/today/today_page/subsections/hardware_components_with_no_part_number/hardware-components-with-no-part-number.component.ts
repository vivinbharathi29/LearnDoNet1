﻿import { Component, ViewChild, AfterViewInit, NgZone  } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { HardwareComponentsWithNoPartNumberService } from './hardware-components-with-no-part-number.service';
import { HardwareComponentsWithNoPartNumberViewModel } from './hardware-components-with-no-part-number.viewmodel';
import { ActivatedRoute, Router } from '@angular/router';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'hardware-components-with-no-part-number',
    templateUrl:'./hardware-components-with-no-part-number.component.html'
})

export class HardwareComponentsWithNoPartNumberComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;
    public hardwareComponentsWithNoPartNumber: HardwareComponentsWithNoPartNumberViewModel[];
    ShowNewComponentRequestTwoCallback(strID) {
        
        if (typeof (strID) != "undefined") {
            //alert(strID);
            if (strID != 0) {
                console.log(strID);
                this.reloadGrid();
            }
        }

    }
    constructor(http: Http, private service: HardwareComponentsWithNoPartNumberService, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.ShowNewComponentRequestTwoCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;
        //this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'commodity', map: 'commodity' },
            { name: 'modelnumber', map: 'modelnumber' },
            { name: 'supplier', map: 'supplier' },
            { name: 'versionRevisionPass', map: 'versionRevisionPass' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'LegacyAV',
                datafield: 'id', width: '10%', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Commodity', columngroup: 'LegacyAV',
                datafield: 'commodity', cellsalign: 'left', align: 'left', width: '35%', filtertype: 'input'
            },
            {
                text: 'Model Number', columngroup: 'LegacyAV',
                datafield: 'modelnumber', cellsalign: 'left', align: 'left', width: '20%', filtertype: 'input'
            },
            {
                text: 'Supplier', columngroup: 'LegacyAV',
                datafield: 'supplier', cellsalign: 'left', align: 'left', filtertype: 'input', width: '15%'
            },
            {
                text: 'Version, Revision, Pass', columngroup: 'LegacyAV',
                datafield: 'versionRevisionPass', cellsalign: 'left', align: 'left', filtertype: 'input', width: '20%'
            }
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'commodity': FilterColumnTypeEnum.String,
            'modelnumber': FilterColumnTypeEnum.String,
            'supplier': FilterColumnTypeEnum.String,
            'versionRevisionPass': FilterColumnTypeEnum.String,
        }
    }


    getHardwareComponentsWithNoPartNumber(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getHardwareComponentsWithNoPartNumber(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getHardwareComponentsWithNoPartNumber(paginationInfo);
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getHardwareComponentsWithNoPartNumber(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getHardwareComponentsWithNoPartNumber(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getHardwareComponentsWithNoPartNumber(paginationInfo);
    } 
    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getHardwareComponentsWithNoPartNumber(paginationInfo);
    }  

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var hwid = data.id;
            var strID;
            var url = "/Excalibur/Deliverable/commodity/PartNumber.asp?VersionID=" + hwid + "&app=" + "PulsarPlus";
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['partnumber', hwid] } }]);
            modalPopup.show('#externalpopupMessage', "60%", "340px", "Update Deliverable Version Part Number");
        }
        return false;
    }

    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {        
        var element = $(defaulthtml);
        element[0].innerHTML = "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:HardwareComponentNoPartNumber_onclick(" + rowdata.id + ");' /> " + value + "</a>";
        return element[0].outerHTML;
    };
}

﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R
// Created          : 11/05/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="due-this-week.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Injectable()
export class DueThisWeekService {
    constructor(private http: Http, private location: Location) {

    }
    getDueThisWeek(paginationInfo: PaginationModel) {
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetDueThisWeek'), JSON.stringify(paginationInfo), options);
    }

    getImpersonateName() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
    }
}

﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M
// Created          : 05/09/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="help-support-upcoming-releases.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class HelpAndSupportUpcomingReleasesService {
    constructor(private http: Http, private location: Location) {
    }

    getUpcomingReleases() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetUpcomingReleasesHelpAndSupport'))
    }
}

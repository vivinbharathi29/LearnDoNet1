// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 06/01/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="my-working-list-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class MyWorkingListViewModel
{
	id : number;
	project : string;
	displayOrder? : number;
	type : number;
	duedate : Date;
	priority? : any;
	status : number;
	mileStone : string;
	target : string;
	summary : string;
	totalNoOfRows : number;
}
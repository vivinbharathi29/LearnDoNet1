﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh.T
// Created          : 05/04/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/06/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="missing-subassembly-numbers-legacy.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class MissingSubassemblyNumberLegacyService {
    constructor(private http: Http, private location: Location) {
    }

    getMissingSubassemblyNumberLegacy(paginationInfo: PaginationModel) {        
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetMissingSubAssemblyLegacyNumbers'), JSON.stringify(paginationInfo), options);
    }

    getMissingSubassemblyNumberLegacyExportToExcel(paginationInfo: PaginationModel) {
        //let headers = new Headers({ 'Content-Type': 'application/json' });
        //let options = new RequestOptions({ headers: headers });
        //paginationInfo.PageNo = paginationInfo.PageNo + 1;
        //return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetMissingSubAssemblyLegacyNumbers'), JSON.stringify(paginationInfo), options);
        //return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetMissingSubAssemblyLegacyExportToExcel'))
        ///return this.http.get(this.location.prepareExternalUrl('/today/todayPage/GetMissingSubAssemblyLegacyExportToExcel'))
        //return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetMissingSubAssemblyLegacyExportToExcel'), JSON.stringify(paginationInfo), options);
    }
}

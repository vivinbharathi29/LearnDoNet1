﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M
// Created          : 05/29/2017
// Last Modified By : Shanmugaraj.M
// Last Modified On : 01/06/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="engineering-development-working-list.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class EngineeringDevelopmentWorkingListService {
    constructor(private http: Http, private location: Location) {
    }

    getEngineeringDevelopmentWorkingList() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetEngineeringDevelopmentWorks'))
    }
}

﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 03/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="features-requesting-root-components.service" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class FeaturesRequestingRootComponentsService {
    constructor(private http: Http, private location: Location) {

    }
    getFeaturesRequestingRootComponents(paginationInfo: PaginationModel) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetFeaturesRequestingRootComponents'), JSON.stringify(paginationInfo), options);
    }
}

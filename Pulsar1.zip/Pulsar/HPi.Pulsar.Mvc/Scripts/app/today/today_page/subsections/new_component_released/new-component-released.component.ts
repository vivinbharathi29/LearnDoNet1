﻿
import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';

import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { NewComponentsReleasedService } from './new-component-released.service';
import { NewComponentsReleasedViewModel } from './new-components-released-view-model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
//import { UserInfoService } from '../../dashboard/user-info.service';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
//import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';

import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';

declare let $: any;
declare var modalPopup: any;
@Component({
    selector: 'new-components-released',
    templateUrl: './new-component-released.component.html'
})

export class NewComponentsReleasedComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;
    public newComponentsReleased: NewComponentsReleasedViewModel[];
    public title: string;

    //private mbp: MessageBoxButton;

    TargetQuickSaveCallBack(status: any): void {
        //console.log("callback");
        if (typeof (status) != "undefined") {
            //if (status > 0) {
            console.log(status);
            this.pageReload();
            //}
        }
    }

    pageReload() {
        this.myGrid.clearselection();
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleased(paginationInfo);
    }

    constructor(http: Http, private service: NewComponentsReleasedService, private _ngZone: NgZone, private router: Router, private location: Location) {
        window['angularComponentRef'] = {
            component: this,
            popUpCallBackFn: (value) => this.TargetQuickSaveCallBack(value),
            zone: _ngZone
        };
        window['angularComponentRef_LeadProduct'] = {
            zone: this._ngZone,
            ExpandCallbackFn: (strSection, strProdID) => this.ExpandSummaryCallback(strSection, strProdID),
            AllProductCallbackFn: (strProdID, strText) => this.AllProductCallback(strProdID, strText),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.width = 1000;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightTwoLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product', type: 'string' },
            { name: 'name', map: 'name', type: 'string' },
            { name: 'partNumber', map: 'partNumber', type: 'string' },
            { name: 'changeAlert', map: 'changeAlert', type: 'string' },
            { name: 'distribution', map: 'distribution', type: 'string' },
            { name: 'osSupportedList', map: 'osSupportedList', type: 'string' },
            { name: 'targetNotes', map: 'targetNotes', type: 'string' },
            { name: 'imageSummary', map: 'imageSummary', type: 'string' },
            { name: 'developer', map: 'developer', type: 'string' },
            { name: 'id', map: 'id' },
            { name: 'prodId', map: 'prodId' },
            { name: 'rootId', map: 'rootId' },
            { name: 'versionId', map: 'versionId' },
            { name: 'version', map: 'version' },
            { name: 'revision', map: 'revision' },
            { name: 'pass', map: 'pass' },
            { name: 'rowBkgColor', map: 'rowBkgColor' },
            { name: 'alertBkgColor', map: 'alertBkgColor' },
            { name: 'fusion', map: 'fusion', type: 'bool' },
            { name: 'pulsar', map: 'pulsar', type: 'bool' },
            { name: 'versionRevisionPass', map: 'versionRevisionPass', type: 'string' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'Product', filtertype: 'input', datafield: 'product', width: "10%", cellclassname: this.cellclass },
            { text: 'Component', filtertype: 'input', datafield: 'name', width: "25%", cellclassname: this.cellclass },
            { text: 'Version,Revision,Pass', filtertype: 'input', datafield: 'versionRevisionPass', width: "10%", cellclassname: this.cellclass },
            { text: 'Part number', filtertype: 'input', datafield: 'partNumber', width: "10%", cellclassname: this.cellclass },
            { text: 'Alert', filtertype: 'input', datafield: 'changeAlert', width: "10%", cellclassname: this.cellclass },
            {
                text: 'Distribution', filtertype: 'input', datafield: 'distribution', width: "10%", cellclassname: this.cellclass
            },
            { text: 'OS', filtertype: 'input', datafield: 'osSupportedList', width: "10%", cellclassname: this.cellclass },
            { text: 'Target notes', filtertype: 'input', datafield: 'targetNotes', width: "8%", cellclassname: this.cellclass },
            { text: 'Images', filtertype: 'input', datafield: 'imageSummary', width: "5%", cellclassname: this.cellclass },
            { text: 'Developer', filtertype: 'input', datafield: 'developer', width: "8%", cellclassname: this.cellclass }

            //{ text: 'id', filtertype: 'number', datafield: 'id', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'prodId', filtertype: 'number', datafield: 'prodId', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'rootId', filtertype: 'number', datafield: 'rootId', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'versionId', filtertype: 'number', datafield: 'versionId', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'version', filtertype: 'input', datafield: 'version', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'revision', filtertype: 'input', datafield: 'revision', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'pass', filtertype: 'input', datafield: 'pass', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'rowBkgColor', filtertype: 'input', datafield: 'rowBkgColor', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'fusion', filtertype: 'bool', datafield: 'fusion', cellsalign: 'right', width: 200, hidden: true },
            //{ text: 'pulsar', filtertype: 'bool', datafield: 'pulsar', cellsalign: 'right', width: 200, hidden: true }

        ];

        this.jqxGridConfig.columnTypes = {
            'product': FilterColumnTypeEnum.String,
            'name': FilterColumnTypeEnum.String,
            'partNumber': FilterColumnTypeEnum.String,
            'changeAlert': FilterColumnTypeEnum.String,
            'distribution': FilterColumnTypeEnum.String,
            'osSupportedList': FilterColumnTypeEnum.String,
            'targetNotes': FilterColumnTypeEnum.String,
            'imageSummary': FilterColumnTypeEnum.String,
            'developer': FilterColumnTypeEnum.String,
            'versionRevisionPass': FilterColumnTypeEnum.String
            //'prodId': FilterColumnTypeEnum.Number,
            //'rootId': FilterColumnTypeEnum.Number,
            //'versionId': FilterColumnTypeEnum.Number,
            //'version': FilterColumnTypeEnum.String,
            //'revision': FilterColumnTypeEnum.String,
            //'pass': FilterColumnTypeEnum.String,
            //'rowBkgColor': FilterColumnTypeEnum.String,
            //'fusion': FilterColumnTypeEnum.Boolean,
            //'pulsar': FilterColumnTypeEnum.Boolean
        }
    }

    cellclass = function (row, columnfield, value, rowdata) {

        if (rowdata.rowBkgColor) {
            if (rowdata.alertBkgColor) {
                if (columnfield == 'changeAlert') {
                    return 'new-component-released-alertBkgColor';
                }
            }
            return 'new-component-released-rowBkgColor';
        }

    }

    //cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
    //    var element = $(defaulthtml);
    //    element.css({ 'background-color': rowdata.rowBkgColor });
    //    element[0].outerHTML;
    //    if (rowdata.alertBkgColor) {
    //        if (columnfield == 'changeAlert') {
    //            element.css({ 'background-color': rowdata.alertBkgColor });
    //            return element[0].outerHTML;
    //        }
    //    }
    //    return element[0].outerHTML;
    //}


    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    private productId: string = ''

    ExpandSummaryCallback(strSection: any, strProdID: any) {
        //debugger;
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.productId = strProdID;
        this.getNewComponentsReleased(paginationInfo, strProdID);
        this.service.getNewComponentsReleasedSummaryService(strProdID).subscribe(result => {
            this.allNewProducts = result.json();
        });
    }

    AllProductCallback(strProdID: any, strText: any) {
        //debugger;
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.productId = strProdID;
        this.getNewComponentsReleased(paginationInfo, strProdID);
        //this.service.getNewComponentsReleasedSummaryService(strProdID).subscribe(result => {
        //    this.allNewProducts = result.json();
        //});
    }

    getNewComponentsReleased(paginationInfo: PaginationModel, productId: string = '') {
        this.myGrid.showdefaultloadelement(true);
        this.service.getNewComponentsReleasedService(paginationInfo, productId).subscribe(result => {
            console.log("Json", result.json());
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleased(paginationInfo);
        //this.getProducts(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleased(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleased(paginationInfo);
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
        {
            width: '200px', height: '230px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
        };

    allNewProducts: any;
    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getNewComponentsReleased(paginationInfo);
        this.service.getNewComponentsReleasedSummaryService(this.productId).subscribe(result => {
            this.allNewProducts = result.json();
            console.log(this.allNewProducts);
        });
        this.myMenu.createComponent(this.MenuSettings);
    }

    PMAlertsMultiAccept(functionType: number): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var idList = "";
        var index: number;
        var ResetOtherTargets = 0;
        var ProductId: number;
        //var ProdId = dataview[sThisVal - 1]["ProdId"];
        //var VersionId = dataview[sThisVal - 1]["VersionId"];
        //var ReleaseID = dataview[sThisVal - 1]["ReleaseID"];
        //var StableConsistent = dataview[sThisVal - 1]["StableConsistent"];
        for (index = 0; index < selectedIndices.length; index++) {
            idList += this.myGrid.getrowdata(selectedIndices[index]).prodId + "-" + ResetOtherTargets + ":" + this.myGrid.getrowdata(selectedIndices[index]).versionId + ":" + this.myGrid.getrowdata(selectedIndices[index]).releaseId + ",";
            if (this.myGrid.getrowdata(selectedIndices[index]).prodId != ProductId) {
                ProductId = this.myGrid.getrowdata(selectedIndices[index]).prodId;
                if (this.myGrid.getrowdata(selectedIndices[index]).stableConsistent == 1) {
                    if (window.confirm("This is a Stable and Consistent Pulsar Product,  Do you want to keep the previous version(s) Targeted or only Target this Version?  \r\r Click 'OK' to Keep ALL Versions Targeted or Click 'Cancel' ONLY Target this Version")) {
                        ResetOtherTargets = 1;
                    }
                }
            }
        }
        console.log("checked", idList);
        if (idList == "") {
            alert("Please select at least one Component!");
        }
        else {
            var messages;
            if (functionType == 0) {
                messages = "Are you sure you want to Reject selected Component(s)?\r\r Click OK to continue or Cancel to stop Reject";
            }
            else {
                messages = "Are you sure you want to Target selected Component(s)?\r\r Click OK to continue or Cancel to stop Target";
            }
            if (window.confirm(messages)) {
                idList = idList.slice(0, idList.length - 1); // Remove last two characters: comma and space
                var url = "";
                var title = "";
                var height = "150px";
                var width = "300px";

                this.service.SaveTargetQuick(idList, functionType, 0, 0).subscribe(data => {
                    var result = data.json();
                    if (result) {
                        var paginationInfo: PaginationModel;
                        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                        this.getNewComponentsReleased(paginationInfo);
                        this.myGrid.clearselection();
                    }
                });
            }

            //url = "/Excalibur/Target/TargetQuickSave.asp?PMAlerts=" + idList + "&TargetType=" + functionType + "&app=PulsarPlus";
            //title = "Item lookup";
            //showPopup(url, title, height, width);
        }
    }

    pMAlertsMultiAcceptMVC(functionType: number): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var idList = "";
        var index: number;

        for (index = 0; index < selectedIndices.length; index++) {
            idList += this.myGrid.getrowdata(selectedIndices[index]).prodId + ":" + this.myGrid.getrowdata(selectedIndices[index]).versionId + ",";
        }
        console.log("checked", idList);
        if (idList == "") {
            alert("Please check at least one component and try again");
        }
        else {
            idList = idList.slice(0, idList.length - 1); // Remove last two characters: comma and space
            var url = "";
            var title = "";
            var height = "150px";
            var width = "300px";

            this.service.SaveTargetQuick(idList, functionType, 0, 0).subscribe(data => {
                var result = data.json();
                if (result) {
                    var paginationInfo: PaginationModel;
                    paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                    this.getNewComponentsReleased(paginationInfo);
                    this.myGrid.clearselection();
                }
            });

            //url = "/Excalibur/Target/TargetQuickSave.asp?PMAlerts=" + idList + "&TargetType=" + functionType + "&app=PulsarPlus";
            //title = "Item lookup";
            //showPopup(url, title, height, width);
        }
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick", this.selectedRowIndex);

        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        //rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        //console.log(rowIndex);
        //rowIndex = rowIndex == -1 ? this.selectedRowIndex : rowIndex;
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        console.log(gridData);
        console.log(menuItem); // Get the Menu Item name

        if (gridData != undefined) {
            switch (menuItem) {
                case "Target version":
                    this.targetVersion(gridData.prodId, gridData.versionId, 1, gridData.product, gridData.name);
                    //this.targetVersionMVC(gridData.prodId, gridData.versionId, 1, gridData.product, gridData.name, gridData.stableConsistent, gridData.releaseId);
                    break;
                case "Cancel alert for version":
                    this.targetVersion(gridData.prodId, gridData.versionId, 0, gridData.product, gridData.name);
                    //this.targetVersionMVC(gridData.prodId, gridData.versionId, 0, gridData.product, gridData.name, gridData.stableConsistent, gridData.releaseId);
                    break;
                case "Edit distribution...":
                    this.changeDistribution(gridData.id, gridData.prodId, gridData.versionId, gridData.rootId);
                    //this.changeDistributionMVC(gridData.id, gridData.prodId, gridData.versionId, gridData.rootId, gridData.releaseId);
                    break;
                case "Edit target notes...":
                    this.editExceptions(gridData.id, gridData.prodId, gridData.versionId, gridData.rootId);
                    //this.editExceptionsMVC(gridData.id, gridData.prodId, gridData.versionId, gridData.rootId, gridData.releaseId);
                    break;
                case "Edit images...":
                    this.editImages(gridData.id, gridData.prodId, gridData.versionId, gridData.rootId, gridData.fusion, gridData.pulsar);
                    //this.editImagesMVC(gridData.id, gridData.prodId, gridData.versionId, gridData.rootId, gridData.fusion, gridData.pulsar, gridData.releaseId);
                    break;
                case "Show changes...":
                    this.showChanges(gridData.prodId, gridData.rootId);
                    //this.showChangesMVC(gridData.prodId, gridData.rootId, gridData.releaseId);
                    break;
                case "Advanced target...":
                    this.advancedTarget(gridData.prodId, gridData.rootId, gridData.versionId);
                    //this.advancedTargetMVC(gridData.prodId, gridData.rootId, gridData.versionId, gridData.releaseId);
                    break;
                case "Properties":
                    this.displayVersion(gridData.rootId, gridData.versionId);
                    break;
            }
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.selectedRowIndex = "";
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = event.args.rowindex;
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
        //}
    }

    targetVersionMVC(prodID: number, verID: number, type: number, prodDesc: string, componentDesc: string, stableConsistent: any, releaseId: any): void {
        var msg;
        var blnOK;
        if (type == 1) {
            if (stableConsistent == 1) {
                blnOK = window.confirm("Product '" + prodDesc + "' is a Stable and Consistent Pulsar Product,  Do you want to keep the previous version(s) Targeted or only Target this Version '" + componentDesc + "'?  \r\r Click 'OK' to Keep ALL Versions Targeted or Click 'Cancel' ONLY Target this Version");
                if (blnOK) {
                    // strResult = window.showModalDialog("../../Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type + "&ReleaseID=" + ReleaseID + "&ResetOtherTargets=0", "", "dialogWidth:300px;dialogHeight:150px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");
                    //this.service.SaveTargetQuick("", type, prodID, verID, releaseId,0).subscribe(data => {
                    //    var result = data.json();
                    //    if (result) {
                    //        var paginationInfo: PaginationModel;
                    //        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                    //        this.getNewComponentsReleased(paginationInfo);
                    //        this.myGrid.clearselection();
                    //    }
                    //});
                }
                else {
                    //strResult = window.showModalDialog("../../Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type + "&ReleaseID=" + ReleaseID + "&ResetOtherTargets=1", "", "dialogWidth:300px;dialogHeight:150px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");
                    //this.service.SaveTargetQuick("", type, prodID, verID, releaseId,1).subscribe(data => {
                    //    var result = data.json();
                    //    if (result) {
                    //        var paginationInfo: PaginationModel;
                    //        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                    //        this.getNewComponentsReleased(paginationInfo);
                    //        this.myGrid.clearselection();
                    //    }
                    //});
                }
            } else {
                //this.service.SaveTargetQuick("", type, prodID, verID, releaseId,1).subscribe(data => {
                //    var result = data.json();
                //    if (result) {
                //        var paginationInfo: PaginationModel;
                //        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                //        this.getNewComponentsReleased(paginationInfo);
                //        this.myGrid.clearselection();
                //    }
                //});
            }
            // msg = "Are you sure you want to Accept the release of " + componentDesc + " for " + prodDesc + "?\r\rThis version will supersede previously accepted versions on this product.";
        }
        else {
            //msg = "Are you sure you want to Reject the release of " + componentDesc + " for " + prodDesc + "?\r\rThis component will not be added to your current component list.";
            blnOK = window.confirm("Are you sure you want to Reject the release of the Component '" + componentDesc + "' for Product '" + prodDesc + "'?\r\rThis component will not be added to your current component list.\r\r Click OK to continue or Cancel to stop Reject selected component(s)");
            if (blnOK) {
                // strResult = window.showModalDialog("../../Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type + "&Rejected=1" + "&ReleaseID=" + ReleaseID + "&ResetOtherTargets=0", "", "dialogWidth:300px;dialogHeight:150px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");
                var url = "/Excalibur/Target/TargetQuickSave.asp?ProdID=" + prodID + "&VersionID=" + verID + "&Type=" + type + "&app=PulsarPlus";
                //this.service.SaveTargetQuick("", type, prodID, verID, releaseId,1).subscribe(data => {
                //    var result = data.json();
                //    if (result) {
                //        var paginationInfo: PaginationModel;
                //        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                //        this.getNewComponentsReleased(paginationInfo);
                //        this.myGrid.clearselection();
                //    }
                //});
            }
        }

        //if (window.confirm(msg)) {
        //    var url = "/Excalibur/Target/TargetQuickSave.asp?ProdID=" + prodID + "&VersionID=" + verID + "&Type=" + type + "&app=PulsarPlus";
        //    this.service.SaveTargetQuick("", type, prodID, verID).subscribe(data => {
        //        var result = data.json();
        //        if (result) {
        //            debugger;
        //            var paginationInfo: PaginationModel;
        //            paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        //            this.getNewComponentsReleased(paginationInfo);
        //            this.myGrid.clearselection();
        //        }
        //    });
        //var title = "";
        //if (type == 0)
        //    url = url + "&Rejected=1";
        //var height = "150px";
        //var width = "300px";
        //showPopup(url, title, height, width);
    }

    targetVersion(prodID: number, verID: number, type: number, prodDesc: string, componentDesc: string): void {
        var msg;
        if (type == 1)
            msg = "Are you sure you want to Accept the release of " + componentDesc + " for " + prodDesc + "?\r\rThis version will supersede previously accepted versions on this product.";
        else
            msg = "Are you sure you want to Reject the release of " + componentDesc + " for " + prodDesc + "?\r\rThis component will not be added to your current component list.";

        if (window.confirm(msg)) {
            var url = "/Excalibur/Target/TargetQuickSave.asp?ProdID=" + prodID + "&VersionID=" + verID + "&Type=" + type + "&app=PulsarPlus";
            this.service.SaveTargetQuick("", type, prodID, verID).subscribe(data => {
                var result = data.json();
                if (result) {
                    // debugger;
                    var paginationInfo: PaginationModel;
                    paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                    this.getNewComponentsReleased(paginationInfo);
                    this.myGrid.clearselection();
                }
            });
        }
    }

    changeDistributionMVC(id: number, productId: number, versionId: number, rootID: number, releaseId: number): void {
        var url = "";
        var title = "";
        var height = "550px";
        var width = "90%";
        //url = "/Excalibur/Target/ChangeDistribution.asp?ProductID=" + prodID + "&VersionID=" + verID + "&RootID=" + rootID + "&app=PulsarPlus";
        url = this.location.prepareExternalUrl("/product/product/ChangeDistribution/" + productId + "/" + versionId + "/" + rootID + "/" + releaseId);
        title = "Change distribution";
        showPopup(url, title, height, width);
        //adjustableShowPopup(url, title, "650px", "70%", "565px");
    }

    changeDistribution(id: number, productId: number, versionId: number, rootID: number): void {
        var url = "";
        var title = "";
        var height = "500px";
        var width = "90%";
        //url = "/Excalibur/Target/ChangeDistribution.asp?ProductID=" + prodID + "&VersionID=" + verID + "&RootID=" + rootID + "&app=PulsarPlus";
        url = this.location.prepareExternalUrl("/product/product/ChangeDistribution/" + productId + "/" + versionId + "/" + rootID);
        title = "Change distribution";
        showPopup(url, title, height, width);
        //adjustableShowPopup(url, title, "650px", "70%", "565px");
    }

    editExceptionsMVC(id: number, prodID: number, verID: number, rootID: number, releaseId: number): void {
        var url = "";
        var title = "";
        var height = "600px";
        var width = "90%";
        url = "/Excalibur/Target/EditExceptions.asp?ProductID=" + prodID + "&VersionID=" + verID + "&RootID=" + rootID + "&app=PulsarPlus";
        title = "Edit Exception";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['editexceptions', prodID, verID] } }]);
        modalPopup.show('#externalpopupMessage', "70%", "350px", "Edit Exception");
    }

    editExceptions(id: number, prodID: number, verID: number, rootID: number): void {
        var url = "";
        var title = "";
        var height = "600px";
        var width = "90%";
        url = "/Excalibur/Target/EditExceptions.asp?ProductID=" + prodID + "&VersionID=" + verID + "&RootID=" + rootID + "&app=PulsarPlus";
        title = "Edit Exception";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['editexceptions', prodID, verID] } }]);
        modalPopup.show('#externalpopupMessage', "70%", "350px", "Edit Exception");
    }

    editImagesMVC(id: number, prodID: number, verID: number, rootID: number, fusion: boolean, pulsar: boolean, releaseId: number): void {
        console.log("Edit Image", fusion, pulsar);
        var url = "";
        var title = "";
        var height = "600px";
        var width = "800px";
        if (pulsar) {
            url = '/Excalibur/target/Pulsar/ChangeImages.asp?ProductID=' + prodID + '&RootID=' + rootID + '&VersionID=' + verID + "&ReleaseID=" + releaseId;// + "&app=PulsarPlus";
        } else if (fusion) {
            //url = '/Excalibur/target/Fusion/ChangeImages.asp?ProductID=' + prodID + '&RootID=' + rootID + '&VersionID=' + verID;// + "&app=PulsarPlus";
            url = "/pulsarplus/product/product/GetAllChangeImagesForProductFusion?productId=" + prodID + "&versionId=" + verID + "&rootId=" + rootID + "&ReleaseID=" + releaseId;
        } else {
            url = '/Excalibur/target/ChangeImages.asp?ProductID=' + prodID + '&RootID=' + rootID + '&VersionID=' + verID + "&ReleaseID=" + releaseId;// + "&app=PulsarPlus";
        }
        title = "Change Images";
        //showPopup(url, title, height, width);
        editImagesNewComponentReleased(url);
    }

    editImages(id: number, prodID: number, verID: number, rootID: number, fusion: boolean, pulsar: boolean): void {
        console.log("Edit Image", fusion, pulsar);
        var url = "";
        var title = "";
        var height = "600px";
        var width = "800px";
        if (pulsar) {
            url = '/Excalibur/target/Pulsar/ChangeImages.asp?ProductID=' + prodID + '&RootID=' + rootID + '&VersionID=' + verID;// + "&app=PulsarPlus";
        } else if (fusion) {
            //url = '/Excalibur/target/Fusion/ChangeImages.asp?ProductID=' + prodID + '&RootID=' + rootID + '&VersionID=' + verID;// + "&app=PulsarPlus";
            url = "/pulsarplus/product/product/GetAllChangeImagesForProductFusion?productId=" + prodID + "&versionId=" + verID + "&rootId=" + rootID;
        } else {
            url = '/Excalibur/target/ChangeImages.asp?ProductID=' + prodID + '&RootID=' + rootID + '&VersionID=' + verID;// + "&app=PulsarPlus";
        }
        title = "Change Images";
        //showPopup(url, title, height, width);
        editImagesNewComponentReleased(url);
    }
    showChangesMVC(prodID: number, rootID: number, releaseId: number): void {
        var url = "";
        var title = "";
        var height = "600px";
        var width = "90%";
        //url = "/Excalibur/MobileSE/Today/CompareVersions.asp?ID=" + rootID + "&ProdID=" + prodID + "&app=PulsarPlus";
        //title = "Deliverable Comparison";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['deliverablecomparison', rootID, prodID, releaseId] } }]);
        modalPopup.show('#externalpagepopup', "70%", "480px", "Deliverable Comparison");
    }

    showChanges(prodID: number, rootID: number): void {
        var url = "";
        var title = "";
        var height = "600px";
        var width = "90%";
        //url = "/Excalibur/MobileSE/Today/CompareVersions.asp?ID=" + rootID + "&ProdID=" + prodID + "&app=PulsarPlus";
        //title = "Deliverable Comparison";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['deliverablecomparison', rootID, prodID] } }]);
        modalPopup.show('#externalpagepopup', "70%", "480px", "Deliverable Comparison");
    }

    advancedTargetMVC(prodID: number, rootID: number, verID: number): void {
        var url = "";
        var title = "";
        var height = "500px";
        var width = "90%";
        //url = "/Excalibur/Target/TargetAdvanced.asp?ProductID=" + prodID + "&VersionID=" + verID + "&RootID=" + rootID + "&app=PulsarPlus";
        title = "Target Version";
        url = this.location.prepareExternalUrl("/product/Product/GetTargetDeliverableRootDetails/" + prodID + "/" + rootID + "/" + verID + "/false");
        showPopup(url, title, height, width);
        //adjustableShowPopup(url, title, "600px", "80%", "565px");
    }

    advancedTarget(prodID: number, rootID: number, verID: number): void {
        var url = "";
        var title = "";
        var height = "500px";
        var width = "90%";
        //url = "/Excalibur/Target/TargetAdvanced.asp?ProductID=" + prodID + "&VersionID=" + verID + "&RootID=" + rootID + "&app=PulsarPlus";
        title = "Target Version";
        url = this.location.prepareExternalUrl("/product/Product/GetTargetDeliverableRootDetails/" + prodID + "/" + rootID + "/" + verID + "/false");
        showPopup(url, title, height, width);
        //adjustableShowPopup(url, title, "600px", "80%", "565px");
    }

    displayVersion(rootID: number, versionID: number): void {
        var url = "";
        var title = "";
        var height = "600px";
        var width = "90%";
        url = "/Excalibur/WizardFrames.asp?Type=1&RootID=" + rootID + "&ID=" + versionID + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
    }

    irsComponents(): void {
        var win = window.open('/pulsarplus/irscomponentupdate', '_blank');
        if (win) {
            win.focus();
        }
    }

    //irsComponents1(): void {
    //    this.router.navigate(['/irscomponentupdate']);
    //}

    //cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
    //    return "<a class='jqx-anchor-hover'  href='javascript:ActionPropertiesMvc(" + rowdata.id + "," + rowdata.type + " );' /> " + value + "</a>";
    //    //return "<a href='javascript:unassignedotsrows_onclick(" + rowdata.id + " );' /> " + value + "</a>";

    //    //return "<a class='jqx-anchor-hover'   href='javascript:alert(\"" + rowdata.UnitPrice + "\");' /> " + value + "</a>";

    //};

    //numCallback = (response: MessageBoxButton): void => {
    //    this.mbp = response;
    //}

    //oKCallback = (response: MessageBoxButton): any => {

    //    this.mbp = response;
    //    if (this.mbp == MessageBoxButton.Yes) {
    //        alert(this.mbp.toString());
    //    }
    //    else if (this.mbp == MessageBoxButton.No) {
    //        alert(this.mbp.toString());
    //    }
    //    else if (this.mbp == MessageBoxButton.Ok) {
    //        var selectedIndices = this.myGrid.selectedrowindexes();
    //        var id = "";
    //        var typeid = "";
    //        var url = "";
    //        var title = "";
    //        var height = 150;
    //        var width = 300;
    //        var ProdID = this.myGrid.getrowdata(selectedIndices).prodID;
    //        var VerID = this.myGrid.getrowdata(selectedIndices).versionId;
    //        if (Type == 0) {
    //            var Type = 0;
    //            url = "/Excalibur/Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type + "&Rejected=1" + '&app=' + 'PulsarPlus';
    //            title = "New Components Released";
    //            showPopup(url, title, height, width);
    //        } else {
    //            var Type = 1;
    //            url = "/Excalibur/Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type + '&app=' + 'PulsarPlus';
    //            title = "New Components Released";
    //            showPopup(url, title, height, width);
    //        }


    //        //     var strResult;
    //        //if (Type == 0)
    //        //    strResult = window.showModalDialog("/Excalibur/Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type + "&Rejected=1", "", "dialogWidth:300px;dialogHeight:150px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");
    //        //else
    //        //    strResult = window.showModalDialog("/Excalibur/Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type, "", "dialogWidth:300px;dialogHeight:150px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");
    //        //if (typeof (strResult) != "undefined")
    //        //    $("#gridNewComponentsReleased").igGrid("dataBind");
    //        // }
    //    }
    //    else if (this.mbp == MessageBoxButton.Cancel) {
    //        alert(this.mbp.toString());
    //    }
    //}

    //IRSComponentUpdateList() {
    //    window.open("/Excalibur/Image/Fusion/IRSComponentUpdateList.asp" + "" + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")
    //}

    //PMAlertsMultiAcceptMVC(strType) {
    //    var strIDs = "";
    //    var strProductID = "";
    //    var strVersionID = "";
    //    // var rows = $("#gridNewComponentsReleased").igGridSelection("selectedRows");
    //    var selectedIndices = this.myGrid.selectedrowindexes();
    //    var index: number;
    //    if (typeof (selectedIndices.length) != "undefined" && selectedIndices.length == 0) {
    //        for (index = 0; index < selectedIndices.length; index++) {
    //            //strProductID += this.myGrid.getrowdata(index).productId + ",";
    //            //strVersionID += this.myGrid.getrowdata(index).versionId + ",";
    //            strIDs = strIDs + this.myGrid.getrowdata(index).prodId + ":" + this.myGrid.getrowdata(index).versionId + ",";
    //        }
    //        strIDs = strIDs.substring(0, strIDs.length - 1);
    //        var strResult;
    //        var url = "/Excalibur/Target/TargetQuickSave.asp?PMAlerts=" + strIDs + "&TargetType=" + strType + '&app=' + 'PulsarPlus';
    //        var title = "New Component Released";
    //        var height = 200;
    //        var width = 400;
    //        showPopup(url, title, height, width)

    //    } else {
    //        this.messageBox.Show("New Components Released", "Please check at least one component and try again", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
    //    }
    //    //if (rows == null || rows.length == 0)
    //    //    alert("Please check at least one component and try again");
    //    //else {
    //    //    for (var i = 0; i < rows.length; i++) {
    //    //        var data = $("#gridNewComponentsReleased").igGrid('findRecordByKey', rows[i].id);
    //    //        strIDs = strIDs + data.ProdId + ":" + data.VersionId + ",";
    //    //    }


    //    //strResult = window.showModalDialog("/Excalibur/Target/TargetQuickSave.asp?PMAlerts=" + strIDs + "&TargetType=" + strType, "", "dialogWidth:300px;dialogHeight:150px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");

    //    //if (typeof (strResult) != "undefined")
    //    //    $("#gridNewComponentsReleased").igGrid("dataBind");
    //}

    //TargetVersionMVC(event: any, Type): void {
    //    var selectedIndices = this.myGrid.selectedrowindexes();
    //    var prodDesc = this.myGrid.getrowdata(selectedIndices).product;
    //    var componentDesc = this.myGrid.getrowdata(selectedIndices).name;

    //    //var blnOK;
    //    if (Type == 1)
    //        this.messageBox.Show("New Components Released", "Are you sure you want to Accept the release of " + componentDesc + " for " + prodDesc + "?\r\rThis version will supersede previously accepted versions on this product.", MessageBoxType.OKCancel, MessageBoxIcon.Information, "400", this.oKCallback);
    //    //= window.confirm("Are you sure you want to Accept the release of " + componentDesc + " for " + prodDesc + "?\r\rThis version will supersede previously accepted versions on this product.");
    //    else
    //        this.messageBox.Show("New Components Released", "Are you sure you want to Reject the release of " + componentDesc + " for " + prodDesc + "?\r\rThis component will not be added to your current component list.", MessageBoxType.OKCancel, MessageBoxIcon.Information, "400", this.oKCallback);
    //    //blnOK = window.confirm("Are you sure you want to Reject the release of " + componentDesc + " for " + prodDesc + "?\r\rThis component will not be added to your current component list.");

    //    //if (blnOK) {
    //    //    var strResult;
    //    //    if (Type == 0)
    //    //        strResult = window.showModalDialog("/Excalibur/Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type + "&Rejected=1", "", "dialogWidth:300px;dialogHeight:150px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");
    //    //    else
    //    //        strResult = window.showModalDialog("/Excalibur/Target/TargetQuickSave.asp?ProdID=" + ProdID + "&VersionID=" + VerID + "&Type=" + Type, "", "dialogWidth:300px;dialogHeight:150px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");
    //    //    if (typeof (strResult) != "undefined")
    //    //        $("#gridNewComponentsReleased").igGrid("dataBind");
    //    //}
    //}

    //ChangeDistributionMVC(event: any): void {

    //    var url = "";
    //    var title = "";
    //    var height = 650;
    //    var width = 700;
    //    var selectedIndices = this.myGrid.selectedrowindexes();
    //    var VerID = this.myGrid.getrowdata(selectedIndices).versionId;
    //    var ProdID = this.myGrid.getrowdata(selectedIndices).prodID;
    //    var RootID = this.myGrid.getrowdata(selectedIndices).rootID;
    //    url = "/Excalibur/Target/ChangeDistribution.asp?ProductID=" + ProdID + "&VersionID=" + VerID + "&RootID=" + RootID + '&app=' + 'PulsarPlus';
    //    title = "New Components Released";
    //    showPopup(url, title, height, width);

    //    //var strResult;
    //    //var resultArray;

    //    //strResult = window.showModalDialog("/Excalibur/Target/ChangeDistribution.asp?ProductID=" + ProdID + "&VersionID=" + VerID + "&RootID=" + RootID, "", "dialogWidth:700px;dialogHeight:500px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");

    //    //if (typeof (strResult) != "undefined") {
    //    //    resultArray = strResult.split("|");
    //    //    $("#gridNewComponentsReleased").igGridUpdating("setCellValue", Id, "Distribution", resultArray[0]);
    //    //    $("#gridNewComponentsReleased").igGridUpdating("setCellValue", Id, "ImageSummary", resultArray[1]);
    //    //}

    //}

    //EditExceptionsMVC(event: any): void {
    //    var url = "";
    //    var title = "";
    //    var height = 300;
    //    var width = 700;
    //    var selectedIndices = this.myGrid.selectedrowindexes();
    //    var ProdID = this.myGrid.getrowdata(selectedIndices).prodID;
    //    var VerID = this.myGrid.getrowdata(selectedIndices).versionId;
    //    var RootID = this.myGrid.getrowdata(selectedIndices).rootID;
    //    url = "/Excalibur/Target/EditExceptions.asp?ProductID=" + ProdID + "&VersionID=" + VerID + "&RootID=" + RootID + '&app=' + 'PulsarPlus';
    //    title = "New Components Released";
    //    showPopup(url, title, height, width);

    //    //var strResult;
    //    //strResult = window.showModalDialog("/Excalibur/Target/EditExceptions.asp?ProductID=" + ProdID + "&VersionID=" + VerID + "&RootID=" + RootID, "", "dialogWidth:700px;dialogHeight:300px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No");
    //    //if (typeof (strResult) != "undefined")
    //    //    $("#gridNewComponentsReleased").igGridUpdating("setCellValue", Id, "TargetNotes", strResult);

    //}

    //ShowChangesMVC(event: any): void {
    //    var NewTop;
    //    var NewLeft;

    //    NewLeft = (screen.width - 750) / 2
    //    NewTop = (screen.height - 650) / 2
    //    var selectedIndices = this.myGrid.selectedrowindexes();
    //    var ProdID = this.myGrid.getrowdata(selectedIndices).prodID;
    //    var VerID = this.myGrid.getrowdata(selectedIndices).versionId;
    //    var RootID = this.myGrid.getrowdata(selectedIndices).rootID;
    //    window.open("CompareVersions.asp?ID=" + RootID + "&ProdID=" + ProdID, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=750,Height=650,menubar=no,toolbar=no,scrollbars=Yes,resizable=Yes,status=No")
    //    window.focus();
    //}

    ////NOTE: if compared to the funcion in today.asp   position Of rootID and verID parameters are swapped
    //AdvancedTargetMVC(event: any): void {
    //    var strResult;
    //    var url = "";
    //    var title = "";
    //    var height = 650;
    //    var width = 700;
    //    var selectedIndices = this.myGrid.selectedrowindexes();
    //    var ProdID = this.myGrid.getrowdata(selectedIndices).prodID;
    //    var VerID = this.myGrid.getrowdata(selectedIndices).versionId;
    //    var RootID = this.myGrid.getrowdata(selectedIndices).rootID;
    //    url = "/Excalibur/Target/TargetAdvanced.asp?ProductID=" + ProdID + "&VersionID=" + VerID + "&RootID=" + RootID + '&app=' + 'PulsarPlus';
    //    title = "New Components Released";
    //    showPopup(url, title, height, width);

    //    //strResult = window.showModalDialog("/Excalibur/Target/TargetAdvanced.asp?ProductID=" + ProdID + "&VersionID=" + VerID + "&RootID=" + RootID, "", "dialogWidth:700px;dialogHeight:650px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No")
    //    //if (typeof (strResult) != "undefined")
    //    //    $("#gridNewComponentsReleased").igGrid("dataBind");

    //}

    //DisplayVersionMVC(event: any): void {

    //    var url = "";
    //    var title = "";
    //    var height = 650;
    //    var width = 700;
    //    var selectedIndices = this.myGrid.selectedrowindexes();
    //    var VersionID = this.myGrid.getrowdata(selectedIndices).versionID;
    //    var RootID = this.myGrid.getrowdata(selectedIndices).rootID;
    //    url = "/Excalibur/WizardFrames.asp?Type=1&RootID=" + RootID + "&ID=" + VersionID + '&app=' + 'PulsarPlus';
    //    title = "New Components Released";
    //    showPopup(url, title, height, width);

    //    //if (window.event != null)
    //    //    if (window.event.srcElement.className == "check")
    //    //        return;

    //    //var strResult;
    //    //strResult = window.showModalDialog("/Excalibur/WizardFrames.asp?Type=1&RootID=" + RootID + "&ID=" + VersionID, "", "dialogWidth:700px;dialogHeight:650px;edge: Sunken;center:Yes; help: No;maximize:Yes;resizable: Yes;status: No")

    //    //if (typeof (strResult) != "undefined")
    //    //    $(igGridID).igGrid("dataBind");

    //}
}


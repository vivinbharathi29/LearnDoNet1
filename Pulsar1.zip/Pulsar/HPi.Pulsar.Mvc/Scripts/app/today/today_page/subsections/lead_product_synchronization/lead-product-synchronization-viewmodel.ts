// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R(auth\rajamanr)
// Created          : 06-05-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="lead-product-synchronization.viewmodel.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class LeadProductSynchronizationViewModel
{
	id : number;
	product : string;
	type? : any;
	owner : string;
	summary : string;
	status? : any;
	typeName : string;
	statusName : string;
    createDate?: Date;
    isFusionRequirements: any;
}
﻿export class ImageTabChangetoLocalizationViewModel {
    productName: string;
    operatingSystem: string;
    localization: string;
    changeType: string;
    imageActionItemID: number;
    productVersionID: number;
}
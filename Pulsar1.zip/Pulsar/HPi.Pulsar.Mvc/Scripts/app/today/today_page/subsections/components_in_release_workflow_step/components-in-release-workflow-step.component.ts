﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh
// Created          : 04/05/2017
// Last Modified By : Vignesh
// Last Modified On : 04/25/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="components-in-release-workflow-step.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone} from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { ComponentsinReleaseWorkflowStepService } from './components-in-release-workflow-step.service';

@Component({
    selector: 'components-in-release-workflow-step',
    templateUrl:'./components-in-release-workflow-step.component.html',
    providers: [ComponentsinReleaseWorkflowStepService]
})

export class ComponentsinReleaseWorkflowStepComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;    
    public selectedRowIndex: string;
    componentsinReleaseWorkflowStepCallback(result: any) {
        if (typeof (result) != undefined) {
            this.gridReload();
        }
    }

    constructor(http: Http, private service: ComponentsinReleaseWorkflowStepService, private _ngZone: NgZone) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.componentsinReleaseWorkflowStepCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;        
        this.jqxGridConfig.settings.pagesize = 10;

        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'site', map: 'site' },
            { name: 'done', map: 'done' },
            { name: 'component', map: 'component' },
            { name: 'developer', map: 'developer' },
            { name: 'transferPath', map: 'transferPath' },
            { name: 'rootId', map: 'rootId' }                
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', 
                datafield: 'id', width: '8%', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Site', 
                datafield: 'site', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '6%'
            },
            {
                text: 'Done',
                datafield: 'done', cellsalign: 'left', align: 'left', width: '6%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Component', 
                datafield: 'component', cellsalign: 'left', align: 'left', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '43%'
            },
            {
                text: 'Developer',
                datafield: 'developer', cellsalign: 'left', align: 'left', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '15%'
            },
            {
                text: 'Transfer Path',
                datafield: 'transferPath', cellsalign: 'left', align: 'left', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '48%'
            },
            {
                text: 'rootId',
                datafield: 'rootId', cellsalign: 'left', align: 'left', hidden: true, filtertype: 'input', cellsrenderer: this.cellsrenderer
            }
            
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'site': FilterColumnTypeEnum.String,
            'done': FilterColumnTypeEnum.String,
            'component': FilterColumnTypeEnum.String,
            'developer': FilterColumnTypeEnum.String,
            'transferPath': FilterColumnTypeEnum.String,
        }
    }

    gridReload(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsInReleaseWorkflowStep(paginationInfo);
    }

    getComponentsInReleaseWorkflowStep(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getComponentsInReleaseWorkflowStep(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsInReleaseWorkflowStep(paginationInfo);
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsInReleaseWorkflowStep(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsInReleaseWorkflowStep(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsInReleaseWorkflowStep(paginationInfo);
    }

    onRowClick(event: any): boolean {
        if (!event.args.rightclick) {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                var productid = data.id;
                var rootid = data.rootId;
                var type = 1;
                componentinRelease_onclick(productid, rootid, type);
            }
            return false;
        }
    }

    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:componentinRelease_onclick(" + rowdata.id + " ," + rowdata.rootId + "," + 1 + ");' /> " + value + "</a>";
        return element[0].outerHTML;
    };
}

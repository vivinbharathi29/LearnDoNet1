﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { MoveToDateForMyProductsOneService } from './move-to-date-for-myproducts-one.service';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { jqxDateTimeInputComponent } from '../../../../jqwidgets-ts/angular_jqxdatetimeinput';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { CustomValidationService } from '../../../../shared/custom-validation.service'

@Component({
    selector: 'move-to-date',
    templateUrl: './move-to-date-for-myproducts-one.component.html',
    providers: [MoveToDateForMyProductsOneService]
})

export class MoveToDateForMyProductsOneComponent implements AfterViewInit {
    @ViewChild('ConfidenceStatus') confidenceStatus: HTMLSelectElement;
    @ViewChild('qualDate') qualDate: jqxDateTimeInputComponent;   
    @ViewChild('myDateTimeInput') myDateTimeInput: jqxDateTimeInputComponent;
    @ViewChild('QualComments') qualComments: HTMLTextAreaElement;
    public selectedRowIndex: string;
    mbp: MessageBoxButton;
    movetoDateform: FormGroup;
    QualDate: Date;
    constructor(private http: Http, private service: MoveToDateForMyProductsOneService, private router: Router, private _ngZone: NgZone, private messageBox: MessageBox, private fb: FormBuilder, private customValidationService: CustomValidationService) {        
        this.movetoDateform = fb.group({
            'qualDate': [null, Validators.compose([Validators.required])]            
        })
    }

    numCallback = (response: MessageBoxButton): void => {
        this.mbp = response;
    }
   
    ngAfterViewInit(): void {      
        
    }
    
    ngOnInit() {    
        this.QualDate = new Date("1900/01/01");    
    }
    
    isError: boolean = false;
    ErrorMessage: string[]
    UpdateDateStatus() {        
        var testDate;
        var confidence;
        var qualComments;
        if (this.qualDate.getText() != "") {
            testDate = this.qualDate.getText();
        }
        var selectConfidence = <HTMLSelectElement>document.getElementById('ConfidenceStatus');

        if (selectConfidence.selectedIndex + 1 != 0) {
            confidence = selectConfidence.selectedIndex + 1; 

        }

        this.ErrorMessage = [];
        this.isError = false;
        if (testDate == null) {
            this.ErrorMessage.push("You must supply a valid date");
            this.isError = true;
        }        
        var qualCommentCtrl = <HTMLTextAreaElement>document.getElementById('QualComments');
        qualComments = qualCommentCtrl.value;
        
        if (this.isError) {
            window.scrollTo(10, 10);
        }
        else {
            MoveToDate(3, testDate, confidence, qualComments);
            this.closeExternalPopup();
        }        
    } 
    closeExternalPopup(): void {
        closePopup('externalpagepopup');
        this.router.navigate([{ outlets: { externalpopupWindow: null } }]);
    }    
}


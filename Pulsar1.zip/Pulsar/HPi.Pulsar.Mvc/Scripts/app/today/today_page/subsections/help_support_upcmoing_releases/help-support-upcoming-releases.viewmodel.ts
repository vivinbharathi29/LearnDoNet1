﻿export class HelpAndSupportUpcomingReleasesViewModel
{
    id: number;
    component: string;
    planned: Date;
    language: string;
    currentWorkflowStep: string;
    rootId: string;
}
﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';

import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { FeatureNamingOverrideRequestedService } from './feature-naming-override-requested.service';
import { FeatureNamingOverrideRequestedViewModel } from './feature-naming-override-requested-view-model.model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { UserInfoService } from '../../dashboard/user-info.service';
import 'rxjs/add/operator/map';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { Router, ActivatedRoute, Params } from '@angular/router'

@Component({
    selector: 'feature-naming-override-requested',
    templateUrl: './feature-naming-override-requested.component.html'
})

export class FeatureNamingOverrideRequestedComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    featureNamingOverrideRequestedViewModel: FeatureNamingOverrideRequestedViewModel;
    public title: string;
    mbp: MessageBoxButton;
    public currentUserName: string = "";
    userName: string;
    email: string;
    featureId: any;
    public selectedRowIndex: string;
    constructor(http: Http, private service: FeatureNamingOverrideRequestedService, private userInfoService: UserInfoService, private messageBox: MessageBox, private activatedRoute: ActivatedRoute, private _ngZone: NgZone, private router: Router) {
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.currentUserName = params['CurrentUserName'];
        });
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.GetNotActionableCommentCallBack(value),
            featurePropertiesPopUpCallBackFn: (value) => this.SetNotActionableActionsCallBack(value),
            featurePropertiesCallBackFn: (value1, value2) => this.CompletetActionableActions(value1, value2),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.width = 1200;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.settings.rowsheight = 50;
        this.jqxGridConfig.datafields = [
            { name: 'featureID', map: 'featureID', type: 'string' },
            { name: 'overrideReason', map: 'overrideReason', type: 'string' },
            { name: 'requestedBy', map: 'requestedBy', type: 'string' },
            { name: 'requestedDate', map: 'requestedDate' },
            { name: 'userName', map: 'userName' },
            { name: 'email', map: 'email' },
        ];

        this.jqxGridConfig.columns = [
            { text: 'Feature ID', filtertype: 'input', datafield: 'featureID', width: "10%", cellsrenderer: this.cellsrenderer },
            { text: 'Reason for Override Request', filtertype: 'input', datafield: 'overrideReason', cellsalign: 'left', align: 'left', width: "60%", cellsrenderer: this.cellsrenderer },
            { text: 'Requested By', filtertype: 'input', datafield: 'requestedBy', align: 'left', cellsalign: 'left', width: "10%", cellsrenderer: this.cellsrenderer },
            { text: 'Date Requested', datafield: 'requestedDate', cellsalign: 'left', width: "13%", filtertype: 'date', cellsrenderer: this.cellsrenderer },
            { text: 'Feature ID', filtertype: 'input', datafield: 'userName', width: "10%", cellsrenderer: this.cellsrenderer, hidden: true }
        ];

        this.jqxGridConfig.columnTypes = {
            'featureID': FilterColumnTypeEnum.String,
            'overrideReason': FilterColumnTypeEnum.String,
            'requestedBy': FilterColumnTypeEnum.String,
            'requestedDate': FilterColumnTypeEnum.Date
        }
    }
    GetNotActionableComment() {
        var strComment;
        var title = "Show Properties";
        var height = "175px";
        var width = 621;
        //var url = "/Excalibur/mobilese/today/OverrideFeatureFeedback.asp?" + "&app=PulsarPlus";
        //strComment = adjustableShowPopup(url, title, height, width, "147px"); //showPopup(url, title, height, width);
        ////return strComment;
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['overridefeaturefeedback'] } }]);
        modalPopup.show('#externalpopupMessage', "75%", "300px", "Not Actionable");
    }

    GetNotActionableCommentCallBack(strComment) {

        if (strComment == "Cancel") {
            return;
        }
        else {
            this.SetNotActionableActions(strComment);
        }
    }

     SetNotActionableActions(strComment) {
         console.log(strComment);
         var index: number;
         var selectedIndices = this.myGrid.selectedrowindexes();
         let parameters = new URLSearchParams();
         this.myGrid.showdefaultloadelement(true);

         var paginationInfo: PaginationModel;
         paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
         var displayRows = this.myGrid.getdisplayrows();
         var displayRowsLength = this.myGrid.getrows().length;
         var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
         var endIndex = startIndex + paginationInfo.PageSize - 1;
         if (displayRowsLength < paginationInfo.PageSize) {
             endIndex = startIndex + displayRowsLength - 1;
         }
         
         for (index = startIndex; index <= endIndex; index++) {
             if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                 this.featureNamingOverrideRequestedViewModel = new FeatureNamingOverrideRequestedViewModel();
                 var request = null;
                 this.featureNamingOverrideRequestedViewModel.featureID = displayRows[index].featureID;
                 this.featureNamingOverrideRequestedViewModel.actionType = 1;
                 this.featureNamingOverrideRequestedViewModel.userName = this.userName;
                 this.featureNamingOverrideRequestedViewModel.overrideReason = strComment;
                 this.featureNamingOverrideRequestedViewModel.email = displayRows[index].email;
                 this.service.saveOverrideFeatureFeedback(this.featureNamingOverrideRequestedViewModel).subscribe(data => {
                     var result = data.json();
                     if (result) {
                         var paginationInfo: PaginationModel;
                         paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                         this.getFeatureNamingOverrideRequested(paginationInfo);
                         this.myGrid.clearselection();
                         this.myGrid.hideloadelement();
                     }
                 });
             }
         }

     }

    SetNotActionableActionsCallBack(strComment) {
        this.featureNamingOverrideRequestedViewModel = new FeatureNamingOverrideRequestedViewModel();
        this.featureNamingOverrideRequestedViewModel.featureID = this.featureId;
        this.featureNamingOverrideRequestedViewModel.actionType = 1;
        this.featureNamingOverrideRequestedViewModel.userName = this.userName;
        this.featureNamingOverrideRequestedViewModel.overrideReason = strComment;
        this.featureNamingOverrideRequestedViewModel.email = this.email;
        this.service.saveOverrideFeatureFeedback(this.featureNamingOverrideRequestedViewModel).subscribe(data => {
            var result = data.json();
            if (result) {
                var paginationInfo: PaginationModel;
                paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                this.getFeatureNamingOverrideRequested(paginationInfo);
                this.myGrid.clearselection();
                this.myGrid.hideloadelement();
            }
        });


    }


     CompletetActionableActions(FeatureID, FeatureName) {
         this.featureNamingOverrideRequestedViewModel = new FeatureNamingOverrideRequestedViewModel();
         this.featureNamingOverrideRequestedViewModel.featureID = FeatureID;
         this.featureNamingOverrideRequestedViewModel.actionType = 0;
         this.featureNamingOverrideRequestedViewModel.userName = this.userName;
         this.featureNamingOverrideRequestedViewModel.featureName = FeatureName;
         this.featureNamingOverrideRequestedViewModel.overrideReason = null;
         this.featureNamingOverrideRequestedViewModel.email = this.email;
         this.service.saveOverrideFeatureFeedback(this.featureNamingOverrideRequestedViewModel).subscribe(data => {
             var result = data.json();
             if (result) {
                 var paginationInfo: PaginationModel;
                 paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                 this.getFeatureNamingOverrideRequested(paginationInfo);

             }
         });

     }

    SetNotActionableAction(CurrentUser) {

        var i, strComment = "";
        var elemsIDChecked;
        elemsIDChecked = "";

        var selectedIndices = this.myGrid.selectedrowindexes();
        let parameters = new URLSearchParams();
        //this.myGrid.showdefaultloadelement(true);
        if (typeof (selectedIndices.length) != "undefined" && selectedIndices.length != 0) {

            this.GetNotActionableComment();
        }
        else {
            this.messageBox.Show("Feature Naming Override Requested", "Please select Features to set to 'Not Actionable'", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            // alert("Please select Features to set to 'Not Actionable'");
         }

     }
     numCallback = (response: MessageBoxButton): void => {
         
         this.mbp = response;
         //if (this.mbp == MessageBoxButton.Yes) {
         //    alert(this.mbp.toString());
         //}
         //else if (this.mbp == MessageBoxButton.No) {
         //    alert(this.mbp.toString());
         //}
         //else if (this.mbp == MessageBoxButton.Ok) {
         //    alert(this.mbp.toString());
         //}
         //else if (this.mbp == MessageBoxButton.Cancel) {
         //    alert(this.mbp.toString());
         //}
     }
    getFeatureNamingOverrideRequested(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getFeatureNamingOverrideRequestedService(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            console.log(result.json());
            if (result.json().length > 0) {
                this.userName = result.json()[0]['userName'];
            } 
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }
    /********* the below event is fired whenever page number is changed
             Call the service method here and refresh the grid.
     *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeatureNamingOverrideRequested(paginationInfo);
        //this.getProducts(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeatureNamingOverrideRequested(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeatureNamingOverrideRequested(paginationInfo);
    }

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeatureNamingOverrideRequested(paginationInfo);
        this.userInfoService.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
            if (result.json().impersonatename != "") {
                this.userName = result.json().impersonatename;
            } else {
                this.userName = this.userName; //result.json().userName; //this.currentUserName;
            }
            console.log(this.userName);
        });
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        //return "<a class='jqx-anchor-hover'  href='javascript:ShowOverrideFeatureDetail(" + rowdata.featureID + ","+ this.userName + " );' /> " + value + "</a>";
        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='jqx-anchor-hover'  href='javascript:ShowOverrideFeatureDetail(" + rowdata.featureID + "," + this.userName + " );' /> " + value + "</a>";
        return element[0].outerHTML;

    };
    onRowClick(event: any): boolean {
        if (!event.args.rightclick) {
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            console.log(data);
            if (data != null) {
                ShowOverrideFeatureDetail(data.featureID, data.userName);
                this.email = data.email;
                this.featureId = data.featureID;
            }

            return false;
        }
    }

}

﻿export class MissingServiceSubassemblyNumberViewModel {
    id: number;
    product: string;
    component: string;
}
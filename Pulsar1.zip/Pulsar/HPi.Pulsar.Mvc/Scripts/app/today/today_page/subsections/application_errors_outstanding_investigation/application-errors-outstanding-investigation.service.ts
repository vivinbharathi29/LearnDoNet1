﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R(auth\rajamanr)
// Created          : 05/24/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="application-errors-outstanding-investigation.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class ApplicationErrorsOutstandingService {
    constructor(private http: Http, private location: Location) {
    }

    getApplicationErrorsOutstanding() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetApplicationErrorsOutstanding'))
    }
}
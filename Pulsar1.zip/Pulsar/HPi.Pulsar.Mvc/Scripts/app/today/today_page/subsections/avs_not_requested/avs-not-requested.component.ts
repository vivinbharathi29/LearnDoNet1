﻿import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { AVsNotRequestedService } from './avs-not-requested.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';

@Component({
    selector: 'avs-not-requested',
    templateUrl: './avs-not-requested.component.html',
    providers: [AVsNotRequestedService]
})

export class AVsNotRequestedComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    constructor(http: Http, private service: AVsNotRequestedService)
    {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'program', map: 'program' },
            { name: 'brand', map: 'brand' },
            { name: 'featureCategory', map: 'featureCategory' },
            { name: 'gpgDescription', map: 'gpgDescription' }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'Program',
                datafield: 'program', filtertype: 'input'
            },
            {
                text: 'Brand',
                datafield: 'brand', filtertype: 'input', width: 150
            },
            {
                text: 'Feature Category',
                datafield: 'featureCategory', filtertype: 'input'
            },
            {
                text: 'GPG Description',
                datafield: 'gpgDescription', filtertype: 'input'
            }
        ];
    }

    getAvsNotRequested() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getAvsNotRequested().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getAvsNotRequested();
    }
}
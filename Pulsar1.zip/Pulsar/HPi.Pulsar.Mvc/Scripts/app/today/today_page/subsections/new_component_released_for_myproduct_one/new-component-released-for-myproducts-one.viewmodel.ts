﻿export class NewComponentsReleasedForMyProductsOne {
    selectedIds: string;
    statusId: number;
    isRiskRelease: boolean;
    qualComments: string;
    qualDate: Date;
    qualConfidence: string;    
    testDate: Date; 
}
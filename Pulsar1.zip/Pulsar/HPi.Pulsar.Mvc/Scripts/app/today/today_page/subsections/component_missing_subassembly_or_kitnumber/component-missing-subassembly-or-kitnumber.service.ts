﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/25/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/08/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="component-missing-subassembly-or-kitnumber.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Location } from '@angular/common';

@Injectable()
export class ComponentMissingSubAssemblyOrKitNumberService {
    constructor(private http: Http, private location: Location) {
    }

    getComponentsMissingSubAssemblyOrKitNumber() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetComponentsMissingSubAssemblyOrKitNumber'))
    }
}
﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/29/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 10/03/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="engineering-development-working-list.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { EngineeringDevelopmentWorkingListService } from './engineering-development-working-list.service';
import { EngineeringDevelopmentWorkingListViewModel } from './engineering-development-working-list.viewmodel';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
@Component({
    selector: 'engineering-development-working-list',
    templateUrl:'./engineering-development-working-list.component.html'
})

export class EngineeringDevelopmentWorkingListComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    private mbp: MessageBoxButton;
    public engineeringDevelopmentWorkingList: EngineeringDevelopmentWorkingListViewModel[];
    EngineeringDevelopmentListCallback(result) {
        if (typeof (result) != "undefined") {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: EngineeringDevelopmentWorkingListService, private messageBox: MessageBox, private _ngZone: NgZone, private activatedRoute: ActivatedRoute, private router: Router,private location:Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.EngineeringDevelopmentListCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.settings.autorowheight = true;
        this.jqxGridConfig.settings.pagesizeoptions = ['10', '50', '100', '250'];
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number'  },
            { name: 'version', map: 'version', type: 'string'  },
            { name: 'component', map: 'component', type: 'string'  },
            { name: 'vendor', map: 'vendor', type: 'string'  },
            { name: 'model', map: 'model', type: 'string'  },
            { name: 'part', map: 'part', type: 'string'  },
            { name: 'testProgress', map: 'testProgress', type: 'string'  },
            { name: 'rootId', map: 'rootId' },
            { name: 'categoryId', map: 'categoryId' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'RootId', columngroup: 'ComponentAlerts',
                datafield: 'rootId', hidden: true
            },
            {
                text: 'CategoryId', columngroup: 'ComponentAlerts',
                datafield: 'categoryId', hidden: true
            },
            {
                text: 'ID', columngroup: 'ComponentAlerts',
                datafield: 'id', width: '7.5%', filtertype: 'number'
            },
            {
                text: 'Component', columngroup: 'ComponentAlerts',
                datafield: 'component', cellsalign: 'left', align: 'left', width: '35%', filtertype: 'input'
            },
            {
                text: 'Version', columngroup: 'ComponentAlerts',
                datafield: 'version', cellsalign: 'left', align: 'left', width: '14%', filtertype: 'input'
            },
            {
                text: 'Vendor', columngroup: 'ComponentAlerts',
                datafield: 'vendor', cellsalign: 'left', align: 'left', width: '11%', filtertype: 'input'
            },
            {
                text: 'Model', columngroup: 'ComponentAlerts',
                datafield: 'model', cellsalign: 'left', align: 'left', width: '12%', filtertype: 'input'
            },
            {
                text: 'Part', columngroup: 'ComponentAlerts',
                datafield: 'part', cellsalign: 'left', align: 'left', width: '9%', filtertype: 'input'
            },
            {
                text: 'Test Progress', columngroup: 'ComponentAlerts',
                datafield: 'testProgress', cellsalign: 'left', align: 'left', width: '9%', filtertype: 'input'
            },
        ];
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //$("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '136px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
    };

    //Menu Code – menu item click to get the Grid row data.
    EngDevMultiUpdate(event: any): void {
        var idList = "";
        var strFunction = "";
        var height = "500px";
        var width = "900px";
        var url = "";
        var title = "";
        var strResult;
        var index: number;
        var rowcount: any;
        var selectedIndices = this.myGrid.selectedrowindexes();
        if (this.myGrid.getfilterinformation().length > 0) {
            for (var index = 0; index < selectedIndices.length; index++) {
                idList = idList + this.myGrid.getrowdata(selectedIndices[index]).id + ",";
            }
        }
        else {
            var dataInfo = this.myGrid.getdatainformation();
            var paginationInfo = dataInfo.paginginformation;
            rowcount = dataInfo.rowscount;
            var displayRows = this.myGrid.getdisplayrows();
            var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
            var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
            var endIndex = startIndex + displayRowsLength - 1;
            if (displayRowsLength < paginationInfo.pagesize) {
                endIndex = startIndex + displayRowsLength - 1;
            }
            for (index = startIndex; index <= endIndex; index++) {
                if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                    idList += displayRows[index].id + ",";
                }
            }
        }

        idList = idList.substring(0, idList.length - 1);
        strFunction = event;
        if (idList.length == 0) {
            this.messageBox.Show("Release", "You must select the components first.", MessageBoxType.Ok, MessageBoxIcon.Warning, "400", this.confirmationMessage)
        }
        else {
            //url = "/Excalibur/Deliverable/Commodity/Release.asp?VersionID=" + idList + "&txtFunction=" + strFunction + '&app=' + 'PulsarPlus';
            //title = "Release";
            //showPopup(url, title, height, width);
            //strResult = showPopup(url, title, height, width);
            //if (typeof (strResult) != "undefined") {
            //    window.location.reload(true);
            //}

            this.router.navigate([{ outlets: { 'externalpopupWindow': ['release', idList, strFunction] } }]);
            modalPopup.show('#externalpagepopup', "1000px", "500px", "Release Versions");
        }
    }

    ReleaseHW(action: any, event: any): void {
        var strResult;
        var Source = "1";
        var Action = action;
        var id = "";
        var url = "";
        var title = "";
        var height = "550px";
        var width = "90%";
        var selectedIndices = this.myGrid.selectedrowindexes();
        id = this.myGrid.getrowdata(selectedIndices).id;
        url = "/Excalibur/Release.asp?Action=" + Action + "&ID=" + id + '&app=' + 'PulsarPlus';
        if (action == 1) {
            title = "Release";
        }
        else {
            title = "Cancel";
        }
        if (Source == "1") {
            //showPopup(url, title, height, width);
            adjustableShowPopupSecondlevel(url, title, height, width, "790px");
            //strResult = showPopup(url, title, height, width);
            //if (typeof (strResult) != "undefined")
            //    window.location.reload(true);
        }
        else {
            this.messageBox.Show("Confirm", "Are you sure you want to release the selected versions?.", MessageBoxType.OKCancel, MessageBoxIcon.Warning, "400", this.confirmationMessage)
        }
    }

    WhereUsed(event: any): void {
        var id = 0;
        var rootId = "";
        var categoryId = "";
        var url = "";
        var title = "";
        var height = "650px";
        var width = "655px";
        var selectedIndices = this.myGrid.selectedrowindexes();
        id = this.myGrid.getrowdata(selectedIndices).id;
        rootId = this.myGrid.getrowdata(selectedIndices).rootId;
        categoryId = this.myGrid.getrowdata(selectedIndices).categoryId;
        if (id == 0) {
            url = "/Excalibur/Deliverable/HardwareMatrix.asp?lstCategory=" + categoryId + "&lstRoot=" + rootId;
            window.open(url);
           // window.open(this.location.prepareExternalUrl("/product/Product/GetProductHardwareMatrix?lstCategory=" + categoryId + "&lstRoot=" + rootId), "_blank").focus();
        }
        else {
            url = "/Excalibur/Deliverable/HardwareMatrix.asp?lstCategory=" + categoryId + "&lstRoot=" + rootId + "&HighlightRow=" + id;
            window.open(url);
            //window.open(this.location.prepareExternalUrl("/product/Product/GetProductHardwareMatrix?lstCategory=" + categoryId + "&lstRoot=" + rootId + "&HighlightRow=" + id), "_blank").focus();
        }
    }

    //TestResultsSummary(event: any): void {
    //    this.messageBox.Show("Under Development.", "Under Development.", MessageBoxType.Ok, MessageBoxIcon.Warning, "400", this.confirmationMessage)
    //}

    DeliverableProperties(event: any): void {
        var id = "";
        var url = "";
        var title = "";
        var height = "650px";
        var width = "750px";
        var selectedIndices = this.myGrid.selectedrowindexes();
        id = this.myGrid.getrowdata(selectedIndices).id;
        url = "/Excalibur/WizardFrames.asp?Type=1&ID=" + id + '&app=' + 'PulsarPlus';
        title = "Deliverable Properties";
        showPopup(url, title, height, width);
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
        }
        else if (this.mbp == MessageBoxButton.Cancel) {
        }
    }

    getEngineeringDevelopmentWorkingList() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getEngineeringDevelopmentWorkingList().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    onPageChanged(event: any): void {
        this.myGrid.clearselection();
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getEngineeringDevelopmentWorkingList();
        this.myMenu.createComponent(this.MenuSettings);
    }

    reloadGrid(): void {
        this.myGrid.clearselection();
        this.getEngineeringDevelopmentWorkingList();
    }
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\rajamanr
// Created          : 04/04/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="missing-system-board-id.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class MissingSystemBoardIDService {
    constructor(private http: Http, private location: Location) {
        
    }
    getMissingSystemBoardIds() {        
        //let headers = new Headers({ 'Access-Control-Allow-Origin': '*' }); // ... Set content type to JSON
        //let options = new RequestOptions({ headers: headers });
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetMissingSystemBoardIds'));
    }
}

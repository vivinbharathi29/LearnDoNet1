﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh.T
// Created          : 05/08/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="component-name-change-linked-to-av.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router'
import { ImageTabChangetoLocalizationService } from './image-tab-change-to-localization.service';
import { ImageTabChangetoLocalizationViewModel } from './image-tab-change-to-localization.viewmodel';

@Component({
    selector: 'image-tab-change-to-localization',
    templateUrl:'./image-tab-change-to-localization.component.html'
})

export class ImageTabChangetoLocalizationComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public imageTabChangetoLocalization: ImageTabChangetoLocalizationViewModel[];
    public title: string;
    public userId: number = 0;
    public enablemenu: boolean = true;
    public enableAddLocalizationmenu: boolean = true;
    ShowNewComponentRequestTwoCallback(strID) {
        
        if (typeof (strID) != "undefined") {
            //alert(strID);
            if (strID != 0) {
                console.log(strID);
                this.getImageTabChangetoLocalization();
            }
        }

    }
    constructor(http: Http, private service: ImageTabChangetoLocalizationService, private activatedRoute: ActivatedRoute, private _ngZone: NgZone, private router: Router) {
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.userId = params['UserId'];
        });
        window['angularComponentRef_Localize'] = { component: this, zone: _ngZone };
        window['angularComponentRef_Localize'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.ShowNewComponentRequestTwoCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        //this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'productName', map: 'productName' },
            { name: 'operatingSystem', map: 'operatingSystem' },
            { name: 'localization', map: 'localization' },
            { name: 'changeType', map: 'changeType' },
            { name: 'imageActionItemID', map: 'imageActionItemID' },
            { name: 'productVersionID', map: 'productVersionID' },
            { name: 'userName', map: 'userName' }                
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ProductName', datafield: 'productName', filtertype: 'input', width: '27.5%'
            },
            {
                text: 'Operating System', columngroup: 'HelpAndSupport',
                datafield: 'operatingSystem', width: '30%', filtertype: 'input'
            },
            {
                text: 'Localization', columngroup: 'HelpAndSupport',
                datafield: 'localization', cellsalign: 'left', align: 'left', width: '17%', filtertype: 'input'
            },
            {
                text: 'Change Type', columngroup: 'HelpAndSupport',
                datafield: 'changeType', cellsalign: 'left', align: 'left', width: '25%', filtertype: 'input'
            },
            {
                text: 'imageActionItemID', columngroup: 'HelpAndSupport',
                datafield: 'imageActionItemID', hidden: true
            },
            {
                text: 'productVersionID', columngroup: 'HelpAndSupport',
                datafield: 'productVersionID', hidden: true
            },
            {
                text: 'userName', columngroup: 'HelpAndSupport',
                datafield: 'userName', hidden: true
            }            
        ];

    }

    //onClickUpdateAv(currentUserId, NotActionable): void {
    //    var index: number;
    //    var deliverableNameChangeAvLinkedIds: string;
    
    //    currentUserId = this.userId;
    //    deliverableNameChangeAvLinkedIds = "";
    //    var selectedIndices = this.myGrid.selectedrowindexes();
    //    for (index = 0; index < selectedIndices.length; index++) {

    //        deliverableNameChangeAvLinkedIds += this.myGrid.getrowdata(index).deliverableNameChangeAvLinkedId;
    //        if (deliverableNameChangeAvLinkedIds == "") {
    //            alert("You must select the components you want to remove first.");
    //        }
    //        else {

    //            var parameter = "function=UpdateAv&UpdateID=" + deliverableNameChangeAvLinkedIds + "&NotActionable=" + NotActionable + "&UserID=" + currentUserId;
    //            this.service.postUpdateAVs("/Excalibur/MobileSE/Today/UpdateAv.asp", parameter)
    //            //this.makePageRequest("Excalibur\MobileSE\Today\UpdateAv.asp", "", "POST", parameter);
    //        }
    //    }
    //}

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                if (data.changeType == "Localization removed") {
                    this.enablemenu = true;
                }
                else {
                    this.enablemenu = false;
                }
                if (data.changeType == "Localization added") {
                    this.enableAddLocalizationmenu = true;
                }
                else {
                    this.enableAddLocalizationmenu = false;
                }
            }
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
    };

    //Menu Code – menu item click to get the Grid row data.
    ImageChange_oncontextmenu(event: any, actionType: any): void {
        
        var imageActionItemID = "";
        var productVersionID = "";
        var currentUserName = "";
        var pvId = "";
        var url = "";
        var title = "";
        var height = "535px";
        var width = "1057px";
        var selectedIndices = this.myGrid.selectedrowindexes();
        imageActionItemID = this.myGrid.getrowdata(selectedIndices).imageActionItemID;
        productVersionID = this.myGrid.getrowdata(selectedIndices).productVersionID;
        currentUserName = this.myGrid.getrowdata(selectedIndices).userName;
        if (actionType == 0)
        {
            this.ShowSCMDialog(imageActionItemID, productVersionID, currentUserName, actionType);
        }            
        else
        {            
            this.SetImageChangeToItem(imageActionItemID, productVersionID, currentUserName, actionType);
        }
            
        //url = "/Excalibur/MobileSE/Today/DCRWorkflowFrame.asp?DCRID=" + dcrId + "&PVID=" + pvId + "&HistoryID=" + historyId + "&AddNew=0&CompleteMilestone=Y";
        //title = "Milestone Complete";
        //showPopup(url, title, height, width);
    }

    ShowSCMDialog(imageActionItemID: any, productVersionID: any, userId: any, actionType: any): void {
        var strUpdated;
        var historyId = "";
        var url = "";
        var title = "";
        var height = "300";
        var width = "500";
        var selectedIndices = this.myGrid.selectedrowindexes();
        //historyId = this.myGrid.getrowdata(selectedIndices).historyId;
        ////url = "/Excalibur/MobileSE/Today/ImageTabChangeShowSCM.asp?ProductVersionID=" + productVersionID + "&ImageActionItemID=" + imageActionItemID + "&CurrentUser=" + userId + "&ActionType=" + actionType + "&app=PulsarPlus";
        ////title = "Image Tab Change to Localization - SCM";
        ////showPopup(url, title, height, width);
        //strUpdated = showPopup(url, title, height, width);
        //if (typeof (strUpdated) != "undefined")
        //    window.parent.location.reload(true);
        ////let navigationExtras: NavigationExtras = {
        ////    queryParams: { 'productVersionID': productVersionID },
        ////    queryParams: { 'actionType': actionType },
        ////    preserveQueryParams: false
        ////};
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['imagetabchangescm', imageActionItemID, actionType, userId, productVersionID] } }]);
        modalPopup.show('#externalpopupMessage', "38.5%", "486px", "Image Tab Change to Localization - SCM");
        ////this.selectedRowIndex = "";
        ////this.selectedRowIndex = event.args.rowindex;
        ////var data = this.myGrid.getrowdata(event.args.rowindex);
        ////if (event.args.rightclick) {
        ////    return false;
        ////}
        ////else {
        ////    //ShowCommodityProperties(data.id, 5);
            
        ////}
    }

    SetImageChangeToItem(imageActionItemID: any, productVersionID: any, userId: any, actionType: any): void {
        //var parameters = "Function=UpdateAV&ImageActionItemID=" + imageActionItemID + "&ActionType=" + actionType + "&CurrentUserName=" + userId + "&ProductVersionID=" + productVersionID + "&ProductBrandID=0";
       
        let parameters = new URLSearchParams();     
        parameters.set("Function", "UpdateAV");
        parameters.set("ImageActionItemID", imageActionItemID);
        parameters.set("ActionType", actionType);
        parameters.set("CurrentUserName", userId);
        parameters.set("ProductVersionID", productVersionID);
        parameters.set("ProductBrandID", "0");
        this.service.postUpdateAVs(parameters)
            .subscribe(result => {
                console.log(result);
                this.getImageTabChangetoLocalization();
                //
                //alert(result.json());
                //if (result.json() != "0") {
                //    //var paginationInfo: PaginationModel;
                //    //paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                //    this.getImageTabChangetoLocalization();
                //}
            });
        this.getImageTabChangetoLocalization();
    }   

    makePageRequest(url: string, files: string, methodtype: string, parameter: string) {
        
        var xhr = new XMLHttpRequest(),
            method = methodtype,
            url = url;

        xhr.open(method, url, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                console.log(xhr.responseText);
            }
        };
        xhr.send(parameter);
    }

    getImageTabChangetoLocalization() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getImageTabChangetoLocalization().subscribe(result => {
            
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getImageTabChangetoLocalization();
        this.service.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
        });
        this.myMenu.createComponent(this.MenuSettings);
    }

    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {        
        var element = $(defaulthtml);
        element[0].innerHTML = "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:imagetabchangelocalization_onclick(" + rowdata.imageActionItemID + " ," + rowdata.productVersionID + "," + rowdata.userName + "," + rowdata.changeType + ");' /> " + value + "</a>";
        return element[0].outerHTML;
    }; 
};

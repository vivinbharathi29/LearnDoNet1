﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M
// Created          : 04/05/2017
// Last Modified By : Shanmugaraj.M
// Last Modified On : 05/04/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="past-due-schedule-items.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, ViewChild, AfterViewInit,NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { DueThisWeekService } from './due-this-week.service';
import { DueThisWeekViewModel } from './due-this-week.viewmodel';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';


@Component({
    selector: 'due-this-week',
    templateUrl:'./due-this-week.component.html'
})

export class DueThisWeekComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public dueThisWeekVM: DueThisWeekViewModel[];
    public title: string;
    public subTitle: string;
    constructor(http: Http, private service: DueThisWeekService,private ngZone:NgZone) {

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            ActionsCallbackFn: (value) => this.ActionsCallback(value),
            popUpCallBackFn: (value) => this.PopupCallback(value),
            component: this
        };
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'type', map: 'type' },
            { name: 'statusName', map: 'statusName' },
            { name: 'targetDate', map: 'targetDate' },
            { name: 'typeName', map: 'typeName' },
            { name: 'owner', map: 'owner' },
            { name: 'project', map: 'project', type:"string"},
            { name: 'summary', map: 'summary', type: "string"}
        ];
        
        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'DueThisWeek',
                datafield: 'id', width: "10%", filtertype: 'number', cellsrenderer: this.cellsrenderer, editable: true
            },
            {
                text: 'Owner', columngroup: 'DueThisWeek',
                datafield: 'owner', width: "15%", filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Type', columngroup: 'DueThisWeek', filtertype: 'input',
                datafield: 'type', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Type', columngroup: 'DueThisWeek',
                datafield: 'typeName', width: "10%", filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Status', columngroup: 'DueThisWeek',
                datafield: 'statusName', width: "15%", filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Due Date', columngroup: 'DueThisWeek',
                datafield: 'targetDate', filtertype: 'date', width: "15%", cellsformat: 'MM/dd/yyyy', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Product', columngroup: 'DueThisWeek',
                datafield: 'project', width: "15%", filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Summary', columngroup: 'DueThisWeek',
                datafield: 'summary', width: "20%", filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            //{
            //    text: 'Id', columngroup: 'PastDueAlertItems',
            //    datafield: 'id', hidden: true, cellsrenderer: this.cellsrenderer
            //},           
        ];
        
        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'type': FilterColumnTypeEnum.String,
            'TargetDate': FilterColumnTypeEnum.Date,
            'statusName': FilterColumnTypeEnum.String,
            'typeName': FilterColumnTypeEnum.String,
            'owner': FilterColumnTypeEnum.String,
            'project': FilterColumnTypeEnum.String,
            'summary': FilterColumnTypeEnum.String
        }

    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    sendMail(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
       // var url = "";
        var title = "";
        var height = 750;
        var width = 650;
        var NewTop;
        var NewLeft;
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        //url = "Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid;
        title = "Send Email";
        //showPopup(url, title, height, width);
        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        var action = 1;
       
        // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

         window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")
        
        //window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")
    }

    properties(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = 800;
        var width = 950;
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        url = "/Excalibur/mobilese/today/action.asp?ID=" + id + "&Type=" + typeid + "&app=PulsarPlus";
        title = "Properties";
        showPopup(url, title, height, width);
    }
    //Menu Code – Sample menu item click to get the Grid row data.
    printPreview(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        //var url = "";
        var title = "";
        var height = 750;
        var width = 650;
        var NewTop;
        var NewLeft;
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        //url = "/Excalibur/mobilese/today/actionReport.asp?Action=0&ID=" + id + "&Type=" + typeid;
        title = "Print Report";
        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + 0 + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No");
        //window.open("/Excalibur/mobilese/today/actionReport.asp?Action=0&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No");
        //showPopup(url, title, height, width);
    }


    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }

    getDueThisWeek(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getDueThisWeek(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
            });
    }
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDueThisWeek(paginationInfo);
        //this.getProducts(paginationInfo);

    }
    public selectedRowIndex: string;
    onRowClick(event: any): boolean {
        console.log("Row click", event.args.rowindex);
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
        else 
        {
            showProperties(data.id, data.type);
        }
    }
    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDueThisWeek(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDueThisWeek(paginationInfo);
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row

    };
    ActionsCallback(status: any): void {
        if (typeof (status) != "undefined") {
            if (status > 0) {
                console.log(status);
                this.pageReload();
            }
        }
    }
    PopupCallback(status: any): void {
        if (typeof (status) != "undefined") {
            if (status > 0) {
                console.log(status);
                this.pageReload();
            }
        }
    }
    pageReload() {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDueThisWeek(paginationInfo);
        this.myGrid.clearselection();
    }
    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDueThisWeek(paginationInfo);
        this.service.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
            this.subTitle = result.json().subTitle;
        });
        this.myMenu.createComponent(this.MenuSettings);
    }
   
    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        if (columnfield == "id") {
            var element = $(defaulthtml);
            element[0].innerHTML = "<a class='jqx-anchor-hover jqxgrid-cellrender-font' onclick='javascript:showProperties(" + rowdata.id + "," + rowdata.type + ")'>" + value + " </a>";
 //           element.addClass('my-action-items-ivory');
            return element[0].outerHTML; 
            
        }
        else
        {
            var element = $(defaulthtml);
            element[0].innerHTML = "<span class='jqxgrid-cellrender-font' id='" + rowdata.id + "'>" + value + "</span>";
//            element.addClass('my-action-items-ivory');
            return element[0].outerHTML;
        }
    };

}

﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { ComponentsAwaitingTestReviewService } from './components-awaiting-test-review.service';
import { ActivatedRoute, Router } from '@angular/router';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'components-awaiting-test-review',
    templateUrl:'./components-awaiting-test-review.component.html',
    styles: [`
.hideSection
{
    display:none;
}
`],
    providers: [ComponentsAwaitingTestReviewService]
})


export class ComponentsAwaitingTestReviewComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public enablemenu: boolean = false;
    public selectedRowIndex: string;

    componentsAwaitingTestReviewCallback(result: any) {
        if (typeof (result) != undefined) {
            this.gridReload();
        }
    }

    constructor(private http: Http, private service: ComponentsAwaitingTestReviewService, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.componentsAwaitingTestReviewCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();        
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type:'number' },
            { name: 'version', map: 'version', type: 'string' },
            { name: 'buildLevel', map: 'buildLevel', type: 'string'},
            { name: 'developer', map: 'developer', type: 'string' },
            { name: 'planned', map: 'planned' },
            { name: 'functionalTestTeam', map: 'functionalTestTeam', type: 'string' },
            { name: 'transferPath', map: 'transferPath', type: 'string'},
            { name: 'rootId', map: 'rootId', type: 'number' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: '10%' },
            { text: 'Component', filtertype: 'input', datafield: 'version', width: '30%' },
            { text: 'Level', filtertype: 'input', datafield: 'buildLevel', width: '15%' },
            { text: 'Developer', filtertype: 'input', datafield: 'developer', width: '15%' },
            { text: 'Planned Completion', filtertype: 'date', cellsformat: 'MM/dd/yyyy', datafield: 'planned', width: '15%' },
            { text: 'Team', filtertype: 'input', datafield: 'functionalTestTeam', width: '15%' },
            { text: 'TransferPath', filtertype: 'input', hidden: true, datafield: 'transferPath', width: 140 },
            { text: 'RootId', filtertype: 'input', hidden: true, datafield: 'rootId', width: 140 },
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'version': FilterColumnTypeEnum.String,
            'buildLevel': FilterColumnTypeEnum.String,
            'developer': FilterColumnTypeEnum.String,
            'planned': FilterColumnTypeEnum.Date,
            'functionalTestTeam': FilterColumnTypeEnum.String,
            'transferPath': FilterColumnTypeEnum.String,
            'rootId': FilterColumnTypeEnum.Number
        }

    }
    getComponentsAwaitingTestReview(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getComponentsAwaitingTestReview(paginationInfo).subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingTestReview(paginationInfo);


    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingTestReview(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingTestReview(paginationInfo);
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '150px', height: '170px', mode: 'popup', autoOpenPopup: false,

    };

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingTestReview(paginationInfo);
    }

    gridReload(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingTestReview(paginationInfo);
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("menu itemclick", this.selectedRowIndex);
        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();        
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        console.log(gridData);
        console.log(menuItem, gridData.rootId); // Get the Menu Item name    

        switch (menuItem) {
            case "Release Version...":
                this.releaseVersion(gridData.rootId, gridData.id, 1);
                break;
            case "Fail Version...":
                this.releaseVersion(gridData.rootId, gridData.id, 2);
                break;
            case "Display Changes":
                //this.displayChanges(gridData.id);
                this.displayChanges(gridData.rootId, gridData.id);
                break;
            case "Download":
                this.getVersion(gridData.id);
                break;
            case "Update Schedule...":
                this.updateSchedule(gridData.id);
                break;
            case "Properties":
                this.displayVersion(1, gridData.rootId, gridData.id);
                break;
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            console.log(data);
            if (data != null) {
                if (data.transferPath != "") {
                    this.enablemenu = false;
                }
                else {
                    this.enablemenu = true;
                }
            }
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
    }

    releaseVersion(rootId: number, versionId: number, action: number): void {
        var url = "";
        var title = "";
        var height = "550px";        
        var width = "90%";
        url = "/excalibur/Release.asp?Action=" + action + "&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Workflow";
        adjustableShowPopupSecondlevel(url, title, height, width, "790px");
    }

    displayChanges(rootId: number,versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/Properties/FT.asp?ID=" + versionId + "&app=PulsarPlus";
        //title = "Deliverable Changes";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['ft', versionId, rootId] } }]);
        modalPopup.show('#externalpagepopup', "40%", "500px", "Deliverable Changes");
    }

    getVersion(versionId: number): void {
        window.open("/excalibur/FileBrowse.asp?ID=" + versionId);
    }

    updateSchedule(versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/deliverable/schedule.asp?ID=" + versionId + "&app=PulsarPlus";
        title = "Update Schedule";
        //showPopup(url, title, height, width);
        //UpdateScheduleExcalibur(versionId);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['schedule', versionId] } }]);
        modalPopup.show('#externalpagepopup', "600px", "", "Update Schedule");
    }

    displayVersion(action: number, rootId: number, versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/WizardFrames.asp?Type=1&RootID=" + rootId + "&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
        //call back reload.
    }
}


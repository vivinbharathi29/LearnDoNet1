﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 04/05/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 11/13/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="missing-required-milestone.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { MissingRequiredMilestonesService } from './missing-required-milestone.service';
import { MissingRequiredMilestoneViewModel } from './missing-required-milestone.viewmodel';

@Component({
    selector: 'missing-required-milestones',
    templateUrl:'./missing-required-milestone.component.html'
})

export class MissingRequiredMilestonesComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;
    public recentVersionsReleased: MissingRequiredMilestoneViewModel[];
    constructor(http: Http, private service: MissingRequiredMilestonesService) {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.settings.rowsheight = 50;
        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product', type:'string' },
            { name: 'schedule', map: 'schedule', type: 'string'  },
            { name: 'itemDescription', map: 'itemDescription', type: 'string'  },
            { name: 'itemDefinition', map: 'itemDefinition', type: 'string'  },
            { name: 'scheduleDataId', map: 'scheduleDataId', type: 'string'  },
            { name: 'productVersionId', map: 'productVersionId' }
        ];

        this.jqxGridConfig.columns = [

            {
                text: 'ScheduleDataId', columngroup: 'MissingRequiredMilestones',
                datafield: 'scheduleDataId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ProductVersionId', columngroup: 'MissingRequiredMilestones',
                datafield: 'productVersionId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Product', columngroup: 'MissingRequiredMilestones',
                datafield: 'product', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Schedule', columngroup: 'MissingRequiredMilestones',
                datafield: 'schedule', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Item Description', columngroup: 'MissingRequiredMilestones',
                datafield: 'itemDescription', width: '20%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Item Definition', columngroup: 'MissingRequiredMilestones',
                datafield: 'itemDefinition', width: '60%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            }
        ];

    }
    
    getMissingRequiredMilestones() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMissingRequiredMilestones().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getMissingRequiredMilestones();
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var productVersionId = data.productVersionId;
            GoToScheduleTabForTheSelectNullRequiredMilestonesStuff(productVersionId);       
        }
        return false;
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='jqx-anchor-hover jqxgrid-cellrender-font' ID=" + rowdata.scheduleDataId + " href='javascript:GoToScheduleTabForTheSelectNullRequiredMilestonesStuff(" + rowdata.productVersionId + ");' /> " + value + " </a>";
        return element[0].outerHTML;
    };
    
}

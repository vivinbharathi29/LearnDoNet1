﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { MyOpenTicketsService } from './my-open-tickets.service';
import { MyOpenTicketsViewModel } from './my-open-tickets-view-model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { UserInfoService } from '../../dashboard/user-info.service';
import { Router, NavigationExtras } from '@angular/router'
declare let $: any;
declare var modalPopup: any;

import 'rxjs/add/operator/map';
@Component({
    selector: 'my-open-tickets',
    templateUrl:'./my-open-tickets.component.html'
})

export class MyOpenTicketsComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;
    public myOpenTickets: MyOpenTicketsViewModel[];
    public title: string;
    private userName: string;
    public isEditAccess: boolean;
    myOpenTicketsCallback(strID: any) {
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.reloadGrid();
            //}
        }
    }

    constructor(http: Http, private service: MyOpenTicketsService, private userInfoService: UserInfoService, private _ngZone: NgZone, private router: Router) {//
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.myOpenTicketsCallback(value),
            component: this
        };
        window['angularComponentRef_MyOpenTickets'] = { component: this, zone: _ngZone };
        window['angularComponentRef_MyOpenTickets'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.myOpenTicketsCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
       // this.jqxGridConfig.width = 1000;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.settings.rowsheight = 50;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number' },
            { name: 'project', map: 'project', type: 'string' },
            { name: 'category', map: 'category', type: 'string' },
            { name: 'submitter', map: 'submitter', type: 'string' },
            { name: 'owner', map: 'owner', type: 'string' },
            { name: 'status', map: 'status', type: 'string'},
            { name: 'age', map: 'age' },
            { name: 'summary', map: 'summary', type: 'string' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: "8%" },
            { text: 'Project', filtertype: 'input', datafield: 'project', cellsalign: 'left', align: 'left', width: "8%" },
            { text: 'Category', filtertype: 'input', datafield: 'category', align: 'left', cellsalign: 'left', width: "12%" },
            { text: 'Submitter', filtertype: 'input', datafield: 'submitter', cellsalign: 'left', width: "12%" },
            { text: 'Owner', filtertype: 'input', datafield: 'owner', cellsalign: 'left', width: "10%" },
            { text: 'Status', filtertype: 'input', datafield: 'status', cellsalign: 'left', width: "9%"},
            { text: 'Age', filtertype: 'input', datafield: 'age', cellsalign: 'left', width: "8%" },
            { text: 'Summary', filtertype: 'input', datafield: 'summary', cellsalign: 'left', width: "35%" },
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'project': FilterColumnTypeEnum.String,
            'category': FilterColumnTypeEnum.String,
            'submitter': FilterColumnTypeEnum.String,
            'owner': FilterColumnTypeEnum.String,
            'status': FilterColumnTypeEnum.String,
            'age': FilterColumnTypeEnum.Number,
            'summary': FilterColumnTypeEnum.String
        }
    }

    getMyOpenTickets(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMyOpenTicketsService(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            
            if (result.json().length > 0) {
                this.userName = result.json()[0]['userName'];
                this.isEditAccess = result.json()[0]['isEditAccess'];
            } 
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }
    /********* the below event is fired whenever page number is changed
             Call the service method here and refresh the grid.
     *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyOpenTickets(paginationInfo);
        //this.getProducts(paginationInfo);

    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyOpenTickets(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyOpenTickets(paginationInfo);
    }

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyOpenTickets(paginationInfo);
        this.userInfoService.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
            if (result.json().impersonatename != "") {
                this.userName = result.json().impersonatename;
            } else {
                this.userName = this.userName; //result.json().userName; //this.currentUserName;
            }
            console.log(this.userName);
        });
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {

        //  return "<a class='jqx-anchor-hover'   href='javascript:alert(\"" + rowdata.UnitPrice + "\");' /> " + value + "</a>";
        // return "<a class='jqx-anchor-hover'  href='javascript:unassignedotsrows_onclick(" + rowdata.id + " );' /> " + value + "</a>";

    };

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyOpenTickets(paginationInfo);
    }

    private ticketNumber: any;
    onRowClick(event: any): boolean {
        console.log("Row click", event.args.rowindex);
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        console.log(data);
        if (data != null) {
            var url = "";
            var title = "Support Ticket";
            var height = "650px";
            var width = "90%";
            this.ticketNumber = data.id
            this.ShowPage(this.isEditAccess);
            //url = "/excalibur/support/ticket.asp?ID=" + data.id + "&app=PulsarPlus";
            //showPopup(url, title, height, width);
        }

        return false;
    }

    ShowPage(isEditAccess: boolean) {
        let navigationExtras: NavigationExtras = {
            queryParams: { 'TicketNumber': this.ticketNumber},
            preserveQueryParams: false
        };        
        if (isEditAccess)
        {
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['ticket'] } }], navigationExtras);
            modalPopup.show('#externalpagepopup', "85%", "650px", "Support Ticket");
        }
        else {
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['ticketpreview'] } }], navigationExtras);
            modalPopup.show('#externalpagepopup', "85%", "500px", "Mobile Tool Support");
        }
    }

}

﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\rajamanr
// Created          : 04/04/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="missing-se-test-lead.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class MissingSETestLeadService {
    constructor(private http: Http, private location: Location) {
        
    }
    getMissingSETestLeads() {
        
        //let headers = new Headers({ 'Access-Control-Allow-Origin': '*' }); // ... Set content type to JSON
        //let options = new RequestOptions({ headers: headers });
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetUnassignedTestLeads'));
    }
}

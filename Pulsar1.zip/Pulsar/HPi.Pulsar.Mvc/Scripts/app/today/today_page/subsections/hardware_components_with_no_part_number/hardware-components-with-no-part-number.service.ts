﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh.T
// Created          : 05/04/2017
// Last Modified By : 01/06/2017
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="hardware-components-with-no-part-number.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class HardwareComponentsWithNoPartNumberService {
    constructor(private http: Http, private location: Location) {
    }

    getHardwareComponentsWithNoPartNumber(paginationInfo: PaginationModel) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetHardwareComponentsWithNoPartNumber'), JSON.stringify(paginationInfo), options);
    }
}

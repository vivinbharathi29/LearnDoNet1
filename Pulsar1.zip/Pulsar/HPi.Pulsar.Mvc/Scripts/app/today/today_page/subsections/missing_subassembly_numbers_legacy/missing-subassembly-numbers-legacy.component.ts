﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { MissingSubassemblyNumberLegacyService } from './missing-subassembly-numbers-legacy.service';
import { MissingSubassemblyNumberViewModel } from './missing-subassembly-numbers-legacy.viewmodel';

@Component({
    selector: 'missing-subassembly-numbers-legacy',
    templateUrl:'./missing-subassembly-numbers-legacy.component.html'
})

export class MissingSubassemblyNumberLegacyComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public missingSubassemblyNumber: MissingSubassemblyNumberViewModel[];
    public userId: number = 0;
    public selectedRowIndex: string;
    ShowCommodityPropertiesCallFromOutside(strID) {       
        //if (typeof (strID) != "undefined") {
            //if (strID > 0) {          
            //console.log(strID);
            this.pageReload();

            //}
       // }

    }
    constructor(http: Http, private service: MissingSubassemblyNumberLegacyService, private _ngZone: NgZone, private activatedRoute: ActivatedRoute, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.ShowCommodityPropertiesCallFromOutside(value),
            component: this
        };
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.userId = params['UserId'];
        });
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;
        //this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'string' },           
            { name: 'product', map: 'product' },            
            { name: 'component', map: 'component' },
            { name: 'businessSegment', map: 'businessSegment' },
            { name: 'created', map: 'created', type: 'date' },
            { name: 'productId', map: 'productId' },
            { name: 'releaseID', map: 'releaseID' },
            { name: 'productDelRootId', map: 'productDelRootId' },
            { name: 'strSubID', map: 'strSubID' }       
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'LegacyAV',
                datafield: 'id', cellsrenderer: this.cellsrenderer, width: '10%', filtertype: 'input'
            },
            {
                text: 'Product', columngroup: 'LegacyAV',
                datafield: 'product', cellsalign: 'left', align: 'left', width: '18%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Component', columngroup: 'LegacyAV',
                datafield: 'component', cellsalign: 'left', align: 'left', width: '35%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Business Segment', columngroup: 'LegacyAV',
                datafield: 'businessSegment', cellsalign: 'left', align: 'left', width: '17%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Tagged Date',
                datafield: 'created', filtertype: 'date', cellsFormat: 'MM/dd/yyyy HH:mm:ss tt', width: '20%',
            },
            {
                text: 'productId', columngroup: 'LegacyAV',
                datafield: 'productId', cellsalign: 'left', align: 'left', filtertype: 'input', hidden: true
            },
            {
                text: 'ReleaseID', columngroup: 'LegacyAV',
                datafield: 'releaseID', cellsalign: 'left', align: 'left', filtertype: 'input', hidden: true
            },
            {
                text: 'productDelRootId', columngroup: 'LegacyAV',
                datafield: 'productDelRootId', cellsalign: 'left', align: 'left', filtertype: 'input', hidden: true
            },
            {
                text: 'StrSubID', columngroup: 'LegacyAV',
                datafield: 'strSubID', cellsalign: 'left', align: 'left', filtertype: 'input', hidden: true
            }            
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'product': FilterColumnTypeEnum.String,            
            'component': FilterColumnTypeEnum.String,  
            'businessSegment': FilterColumnTypeEnum.String,
            'created': FilterColumnTypeEnum.Date,             
        }
    }


    getMissingSubassemblyNumberLegacy(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMissingSubassemblyNumberLegacy(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();            
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingSubassemblyNumberLegacy(paginationInfo);
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingSubassemblyNumberLegacy(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingSubassemblyNumberLegacy(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingSubassemblyNumberLegacy(paginationInfo);
    }

    pageReload(): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingSubassemblyNumberLegacy(paginationInfo);
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var delrootId = data.productDelRootId;
            var rootId = data.id;
            var productid = data.productId;
            var userId = this.userId;
            var releaseId = data.releaseID;
            //missingSubassemblynumberslegacy_onclick(delrootId, rootId, productid, userId, releaseId);
            var paginationInfo: PaginationModel;
            paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
            this.getMissingSubassemblyNumberLegacy(paginationInfo);
            
            var strSubID;
            if (delrootId == 0) {
                strSubID = "Root" + rootId + "_" + releaseId;
            }
            else {
                strSubID = delrootId + "_" + releaseId;
            }

            if (releaseId == 0) {
                //modalDialog.open({ dialogTitle: 'Edit Subassembly', dialogURL: '../../deliverable/commodity/SubAssembly.asp?VersionID=0&ProductID=' + ProdID + '&RootID=' + RootID + "&CurrentUserID=" + CurrentUserID + "&RowId=" + RowID, dialogHeight: $(window).height() * (55 / 100), dialogWidth: $(window).width() * (50 / 100), dialogResizable: true, dialogDraggable: true });
                var strID;
                //var url = "/Excalibur/Deliverable/commodity/SubAssembly.asp?VersionID=0&ProductID=" + productid + "&RootID=" + rootid + "&CurrentUserID=" + userid + "&RowId=" + strSubID + "&app=" + "PulsarPlus";
                var url = this.location.prepareExternalUrl("/product/product/GetSubAssembly/" + 0 + "/" + productid + "/" + rootId + "/" + strSubID);
                var title = "Edit Subassembly";
                var height = 600;
                var width = 820;
                showPopup(url, title, height, width)
            }
            else {
                //modalDialog.open({ dialogTitle: 'Edit Subassembly', dialogURL: '../../deliverable/commodity/SubAssemblyPulsar.asp?VersionID=0&ProductID=' + ProdID + '&RootID=' + RootID + "&CurrentUserID=" + CurrentUserID + '&ReleaseID=' + ReleaseID + "&RowID=" + RowID, dialogHeight: $(window).height() * (55 / 100), dialogWidth: $(window).width() * (50 / 100), dialogResizable: true, dialogDraggable: true });
                var strID;
                // var url = "/Excalibur/Deliverable/commodity/SubAssemblyPulsar.asp?VersionID=0&ProductID=" + productid + "&RootID=" + rootid + "&CurrentUserID=" + userid + "&ReleaseID=" + releaseID + "&RowID=" + strSubID + "&app=" + "PulsarPlus";
                var url = this.location.prepareExternalUrl("/product/product/GetSubAssemblyPulsar/" + 0 + "/" + productid + "/" + rootId + "/" + releaseId + "/" + strSubID);
                var title = "Edit Subassembly";
                var height = 600;
                var width = 820;
                showPopup(url, title, height, width)
            }    
        }
        return true;
    }

    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {
        //var element = $(defaulthtml);
        //element[0].innerHTML = "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:missingSubassemblynumberslegacy_onclick(" + rowdata.productDelRootId + "," + rowdata.id + "," + rowdata.productId + "," + this.userId + "," + rowdata.releaseID + ");' /> " + value + "</a>";
        //return element[0].outerHTML;
    };

    //exportToExcel(paginationInfo: PaginationModel): void {
    //    //this.myGrid.exportdata('csv', 'Missing Subassembly', true, null, false, '', '');        
    //    this.service.getMissingSubassemblyNumberLegacyExportToExcel();
    //};

    exportToExcel() {        
        ExportToExcel();
        ////var paginationInfo: PaginationModel;
        ////paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        ////this.myGrid.showdefaultloadelement(true);
        ////this.service.getMissingSubassemblyNumberLegacyExportToExcel(paginationInfo);
        //this.service.getMissingSubassemblyNumberLegacyExportToExcel(paginationInfo).subscribe(result => {
        //    //this.jqxGridConfig.localdata = result.json();

        //    //this.myGrid.updatebounddata(null);
        //    this.myGrid.hideloadelement();
        //});
    }
}

// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 04-19-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="today-page.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response,URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { pagination } from '../../../../shared/pagination-model.model';
import { ListSortDirection } from '../../../../shared/listsortdirection';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Injectable()
export class MyOpenTicketsService {
    constructor(private http: Http, private location: Location) { 
	
    }
    getMyOpenTicketsService(paginationInfo: PaginationModel) {
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({
            'Content-Type': 'application/json', 
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
            'Expires': 'Sat, 01 Jan 2000 00:00:00 GMT'
        });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetMyOpenTickets'), JSON.stringify(paginationInfo), options);
    }
    getImpersonateName() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
    }

}
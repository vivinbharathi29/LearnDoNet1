﻿export class DeveloperRequestRemovalFromProductViewModel {
    productId: string;
    rootId: string;
    versionId: string;
    component: string;
    product: string;
    developer: string;
    email: string;
    developerTestNotes: string;
    totalNoOfRows: number;
}
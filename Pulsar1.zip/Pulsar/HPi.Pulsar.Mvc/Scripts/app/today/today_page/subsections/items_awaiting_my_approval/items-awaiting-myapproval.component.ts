﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { ItemsAwaitingMyApprovalService } from './items-awaiting-myapproval.service';
import { ItemsAwaitingMyApprovalViewModel } from './items-awaiting-my-approval-view-model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { UserInfoService } from '../../dashboard/user-info.service';

import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
declare let $: any;
@Component({
    selector: 'items-awaiting-my-approval',
    templateUrl:'./items-awaiting-myapproval.component.html'
})

export class ItemsAwaitingMyApprovalComponent implements AfterViewInit {
    public fullImagePath = 'images/demo_wait.gif';
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public itemsAwaitingMyApproval: ItemsAwaitingMyApprovalViewModel[];
    public title: string;
    mbp: MessageBoxButton;
    public currentUserName: string = "";
    userName: string;
    textTodayMAIA: string;
    public selectedRowIndex: string;
    PopupCallback(result) {
        if (typeof (result) != "undefined") {
            this.reloadGrid();
        }
    } 
    constructor(http: Http, private service: ItemsAwaitingMyApprovalService, private messageBox: MessageBox, private userInfoService: UserInfoService, private location: Location, private _ngZone: NgZone) {
        window['angularComponentRef_ItemsAwaiting'] = { component: this, zone: _ngZone };
        window['angularComponentRef_ItemsAwaiting'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.PopupCallback(value),
            component: this
        }; 
        this.jqxGridConfig = new jqxGridConfiguration();
       // this.jqxGridConfig.width = 1050;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightTwoLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.settings.rowsheight = 50;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number'  },
            { name: 'type', map: 'type' },
            { name: 'typeName', map: 'typeName', type: 'string' },
            { name: 'statusName', map: 'statusName', type: 'string' },
            { name: 'owner', map: 'owner', type: 'string' },
            { name: 'product', map: 'product', type: 'string' },
            { name: 'summary', map: 'summary', type: 'string'}
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: "15%" },
            { text: 'TypeId', filtertype: 'input', datafield: 'type', hidden: true, cellsalign: 'left', align: 'left', width: "15%" },
            { text: 'Type', filtertype: 'input', datafield: 'typeName', cellsalign: 'left', align: 'left', width: "15%" },
            { text: 'Status', filtertype: 'input', datafield: 'statusName', hidden: false, align: 'left', cellsalign: 'left', width: "15%"},
            { text: 'Owner', filtertype: 'input', datafield: 'owner', cellsalign: 'left', width: "15%" },
            { text: 'Product', filtertype: 'input', datafield: 'product', hidden: false, align: 'left', cellsalign: 'left', width: "17%" },
            { text: 'Summary', filtertype: 'input', datafield: 'summary', cellsalign: 'left', width: "20%" },
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'type': FilterColumnTypeEnum.Number,
            'typeName': FilterColumnTypeEnum.String,
            'statusName': FilterColumnTypeEnum.String,
            'owner': FilterColumnTypeEnum.String,
            'product': FilterColumnTypeEnum.String,
            'summary': FilterColumnTypeEnum.String
        }
    }

    numCallback = (response: MessageBoxButton): void => {
        
        this.mbp = response;
    }

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getItemsAwaitingMyApproval(paginationInfo);
        this.myGrid.clearselection();
    }

    MultiDcrMvc(strTodayMAIA: string, strValue: string) {
        //this.myGrid.showdefaultloadelement(true);        
        $("#waitLoad").css("display", "block");
        $('body').css('pointer-events', 'none');
        var blnMultiDcrActive = false;
        if (blnMultiDcrActive) {
            $("#waitLoad").css("display", "none");
            $('body').css('pointer-events', 'all');
            this.messageBox.Show("Confirmation", "Request has already been submitted", MessageBoxType.Ok, MessageBoxIcon.Warning, "400", this.numCallback)
        return;
    }
        $("#waitLoad").css("display", "block");
        $('body').css('pointer-events', 'none');
    blnMultiDcrActive = true;
    var strIDs = "";
    var i = 0;
    var index: number;
    var strIDs: string;
    strIDs = "";
    var selectedIndices = this.myGrid.selectedrowindexes();
    
    //for (index = 0; index < selectedIndices.length; index++) {
    //    strIDs += this.myGrid.getrowdata(selectedIndices[index]).id + ",";
        
    //    }        
        var paginationInfo: PaginationModel;        
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var displayRows = this.myGrid.getdisplayrows();
        //var displayRowsLength = displayRows.length;
        var displayRowsLength = this.myGrid.getrows().length;
        var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
        var endIndex = startIndex + paginationInfo.PageSize - 1;
        if (displayRowsLength < paginationInfo.PageSize) {
            endIndex = startIndex + displayRowsLength - 1;
        }
        for (index = startIndex; index <= endIndex; index++) {            
            if (selectedIndices.indexOf(displayRows[index].boundindex) !=-1  ) {
                //strIDs += this.myGrid.getrowdata(index).id + ",";
                strIDs += displayRows[index].id + ",";
            }
        }
    strIDs = strIDs.slice(0, strIDs.length - 1); 

    
    if ((strValue == '3') && (strTodayMAIA == "")) {
        $("#waitLoad").css("display", "none");
        $('body').css('pointer-events', 'all');
        this.messageBox.Show("Confirmation", "You must provide a comment to Disapprove a DCR", MessageBoxType.Ok, MessageBoxIcon.Warning, "400", this.numCallback)
        blnMultiDcrActive = false;
        return;
    }

    try {
        if (strIDs == "")
        {
            $("#waitLoad").css("display", "none");
            $('body').css('pointer-events', 'all');
            this.messageBox.Show("Confirmation", "You must select the actions you want to approve or disapprove first.", MessageBoxType.Ok, MessageBoxIcon.Warning, "400", this.numCallback)
        }
        else {
            var selectedIndices = this.myGrid.selectedrowindexes();
            let parameters = new URLSearchParams();
            $("#waitLoad").css("display", "none");
            $('body').css('pointer-events', 'all');
            this.myGrid.showdefaultloadelement(true);
            //parameters.set("txtMultiID", strIDs);
            //if (strTodayMAIA != "") {
            //    parameters.set("txtComments", strTodayMAIA);
            //}        
                
            //parameters.set("target", "");
            
            parameters.set("SelectedIds", strIDs);
            parameters.set("ApproverStatus", strValue);
            if (strTodayMAIA != "") {
                parameters.set("approverComments", strTodayMAIA);
            }   
            
                this.service.postMultiUpdateService(parameters)
                    .subscribe(result => {
                        if (result.text()) {
                            var paginationInfo: PaginationModel;
                            paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                            this.getItemsAwaitingMyApproval(paginationInfo);
                            this.myGrid.clearselection();
                            this.myGrid.hideloadelement();
                            this.textTodayMAIA = ''; 
                        }
                        
                    });

                
        }
    } catch (e) {
        blnMultiDcrActive = false;
    }
}

    getItemsAwaitingMyApproval(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getItemsAwaitingMyApprovalService(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            if (result.json().length > 0) {
                this.userName = result.json()[0]['userName'];
            } 
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {        
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getItemsAwaitingMyApproval(paginationInfo);
        //this.getProducts(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getItemsAwaitingMyApproval(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getItemsAwaitingMyApproval(paginationInfo);
    }

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getItemsAwaitingMyApproval(paginationInfo);
        this.myMenu.createComponent(this.MenuSettings);
        this.userInfoService.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
            if (result.json().impersonatename != "") {
                this.userName = result.json().impersonatename;
            } else {
                this.userName = this.userName; //result.json().userName; //this.currentUserName;
            }
            console.log(this.userName);
        });
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {

      //  return "<a class='jqx-anchor-hover'  href='javascript:ActionPropertiesMvc(" + rowdata.id + "," + rowdata.type+" );' /> " + value + "</a>";
        ////var element = $(defaulthtml);
        ////element[0].innerHTML = "<a class='jqx-anchor-hover'  href='javascript:ActionPropertiesMvc(" + rowdata.id + "," + rowdata.type + " );' /> " + value + "</a>";
        ////return element[0].outerHTML;

    };

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    sendMail(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = 750;
        var width = 650;
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var NewTop;
        var NewLeft;

        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        var action = 1;
       // url = "/pulsarplus/product/product/GetSubAssembly/" + 0 + "/" + productid + "/" + rootid + "/" + strSubID;
        url = "/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid;
        var title = "";
        var height = 520;
        var width = 850;
        //showPopup(url, title, height, width)
        window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=770,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")



        //url = "actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid;
        //title = "Send Email";
        //showPopup(url, title, height, width);
    }
    properties(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var deliverableIssueId = "";
        var crType = "";
        var url = "";
        var title = "";
        var height = "75%";
        var width = "94%";
        deliverableIssueId = this.myGrid.getrowdata(selectedIndices).id;
        crType = this.myGrid.getrowdata(selectedIndices).type;
        //url = "/Excalibur/mobilese/today/action.asp?ID=" + id + "&Type=" + typeid + '&app=' + 'PulsarPlus';
        title = "Properties";
        url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");        
        //showPopup(url, title, height, width);
        showPopupWithHeightInPercentage(url, title, height, width);
    }
    //Menu Code – Sample menu item click to get the Grid row data.
    printPreview(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = 750;
        var width = 650;
        var strResult;
        var NewTop;
        var NewLeft;

        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var action = 0;

        // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=800,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

       // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=0&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")
        //url = "actionReport.asp?Action=0&ID=" + id + "&Type=" + typeid;
        // title = "PrintReport";
        //showPopup(url, title, height, width);
    }
    ActionPrint(strID, strType) {
        var strResult;
        var NewTop;
        var NewLeft;

        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        var action = 0;

        // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        strResult = window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + strID + "/" + strType, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")


        //strResult = window.open("/Excalibur/mobilese/today/actionReport.asp?Action=0&ID=" + strID + "&Type=" + strType, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }
    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
         else {
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            console.log(data);
            if (data != null) {
                //ActionPropertiesMvc(data.id, data.type);
                var deliverableIssueId = "";
                var crType = "";
                var url = "";
                var title = "";
                var height = "75%";
                var width = "94%";
                deliverableIssueId = data.id;
                crType = data.type;
                title = "Properties";
                url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
               // showPopup(url, title, height, width);
                showPopupWithHeightInPercentage(url, title, height, width);
            }

            return false;
        }
    }
    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row

    }

    exportToExcel(): void {
        this.myGrid.exportdata('csv', 'Items Awaiting Approval', true, null, false, '', '');
    };

}


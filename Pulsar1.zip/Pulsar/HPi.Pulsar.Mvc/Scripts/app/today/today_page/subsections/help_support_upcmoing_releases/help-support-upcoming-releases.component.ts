﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M
// Created          : 05/08/2017
// Last Modified By : Shanmugaraj.M
// Last Modified On : 08/16/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="help-support-upcoming-releases.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { HelpAndSupportUpcomingReleasesService } from './help-support-upcoming-releases.service';
import { HelpAndSupportUpcomingReleasesViewModel } from './help-support-upcoming-releases.viewmodel';

@Component({
    selector: 'help-support-upcoming-releases',
    templateUrl:'./help-support-upcoming-releases.component.html'
})

export class HelpAndSupportUpcomingReleasesComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public upcomingReleases: HelpAndSupportUpcomingReleasesViewModel[];
    public selectedRowIndex: string;
    constructor(http: Http, private service: HelpAndSupportUpcomingReleasesService) {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.settings.autorowheight = true;
        this.jqxGridConfig.settings.pagesizeoptions = ['10', '50', '100', '250'];
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number' },
            { name: 'rootId', map: 'rootId' },
            { name: 'component', map: 'component', type: 'string' },
            { name: 'planned', map: 'planned' },
            { name: 'language', map: 'language', type: 'string' },
            { name: 'currentWorkflowStep', map: 'currentWorkflowStep', type: 'string' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'RootId', columngroup: 'HelpAndSupport',
                datafield: 'rootId', hidden: true
            },
            {
                text: 'ID', columngroup: 'HelpAndSupport',
                datafield: 'id', width: '8%', filtertype: 'number', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Component', columngroup: 'HelpAndSupport',
                datafield: 'component', cellsalign: 'left', align: 'left', width: '22%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Planned', columngroup: 'HelpAndSupport',
                datafield: 'planned', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'date', cellsformat: 'MM/dd/yyyy', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Languages', columngroup: 'HelpAndSupport',
                datafield: 'language', cellsalign: 'left', align: 'left', width: '42%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Current Workflow Step', columngroup: 'HelpAndSupport',
                datafield: 'currentWorkflowStep', cellsalign: 'left', align: 'left', width: '18%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            }
        ];

    }

    getUpcomingReleases() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getUpcomingReleases().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getUpcomingReleases();
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var id = data.id;
            var rootId = data.rootId;
            DisplayDeliverable_onclick(id, rootId);
        }
        return false;
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a style='font-family:verdana' id='releaseworkflow' class='jqx-anchor-hover ID=" + rowdata.id + "&" + "RootID=" + rowdata.rootId + "&" + "Type=1' onclick='javascript:DisplayDeliverable_onclick();' /> " + value + " </a>";
        return element[0].outerHTML;
    }
};

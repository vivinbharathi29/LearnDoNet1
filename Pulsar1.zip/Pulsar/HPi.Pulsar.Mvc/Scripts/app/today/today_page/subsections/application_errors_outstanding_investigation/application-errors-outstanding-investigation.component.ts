﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R(auth\rajamanr)
// Created          : 05/24/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 10/03/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="application-errors-outstanding-investigation.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { ModalPopupComponent } from '../../../../Shared/modal_popup/modal-popup.component'
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ApplicationErrorsOutstandingService } from './application-errors-outstanding-investigation.service';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'application-error-outstanding',
    templateUrl:'./application-errors-outstanding-investigation.component.html'
})

export class ApplicationErrorsOutstandingComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    constructor(http: Http, private service: ApplicationErrorsOutstandingService, private ngZone: NgZone,private router:Router) {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.settings.rowsheight = 150;
        window['angularComponentRef_AppError'] = { component: this, zone: ngZone };
        window['angularComponentRef_AppError'] = {
            zone: this.ngZone,
            popUpCallBackFn: (value) => this.popupCallBack(value),
            component: this
        };
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'errLine', map: 'errLine' },
            { name: 'errorDateTime', map: 'errorDateTime' },
            { name: 'errDescription', map: 'errDescription' },
            { name: 'name', map: 'name' },
            { name: 'email', map: 'email' },
            { name: 'page', map: 'page' },
            { name: 'rowStatusColour', map: 'rowStatusColour' }
            //{ name: 'action', map:'action'}
        ];

        this.jqxGridConfig.columns = [
            //{
            //    text: 'Action', columngroup: 'ApplicationErrorsOutstanding',
            //    datafield: 'action', width: 120, cellsrenderer: this.cellsrenderer
            //},
            {
                text: 'ID', columngroup: 'ApplicationErrorsOutstanding', columntype: 'input',filtertype:'number',
                datafield: 'id', width: "10%",  cellsrenderer: this.cellsrenderer
            },
            {
                text: 'User', columngroup: 'ApplicationErrorsOutstanding',
                datafield: 'name', width: "10%", cellsrenderer: this.cellsrenderer, filtertype: 'input',
            },
            {
                text: 'Email', columngroup: 'ApplicationErrorsOutstanding',
                datafield: 'email', hidden:true
            },
            {
                text: 'When', columngroup: 'ApplicationErrorsOutstanding',filtertype:'date',
                datafield: 'errorDateTime', width: "12%",  cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Page', columngroup: 'ApplicationErrorsOutstanding',
                datafield: 'page', width: "10%", cellsrenderer: this.cellsrenderer, filtertype: 'input',
            },
            {
                text: 'Line', columngroup: 'ApplicationErrorsOutstanding', columntype: 'input', filtertype: 'number',
                datafield: 'errLine', width: "10%",  cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Error Description', columngroup: 'ApplicationErrorsOutstanding',
                datafield: 'errDescription', width: "45.8%", cellsrenderer: this.cellsrenderer, filtertype: 'input',
            },
            {
                text: 'rowStatusColour', columngroup: 'ApplicationErrorsOutstanding',
                datafield: 'rowStatusColour', cellsrenderer: this.cellsrenderer,hidden:true
            }
            //{
            //    text: 'Email', columngroup: 'ApplicationErrorsOutstanding',
            //    datafield: 'email', hidden:true
            //},
        ];
    }

    popupCallBack(status: any): void {
        if (typeof (status) != "undefined") {
            if (status > 0) {
                console.log(status);
                this.pageReload();
            }
        }
    }
    pageReload(): void {
        this.getApplicationErrorsOutstanding();
        this.myGrid.clearselection();
    }
    sendMail(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var emailIDs = "";
        var description = "";
        var index: number;
        var rowcount: any;

        var dataInfo = this.myGrid.getdatainformation();
        var paginationInfo = dataInfo.paginginformation;
        rowcount = dataInfo.rowscount;
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
        var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
        var endIndex = startIndex + displayRowsLength - 1;
        if (displayRowsLength < paginationInfo.pagesize) {
            endIndex = startIndex + displayRowsLength - 1;
        }

        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                if (displayRows[index].email != undefined && displayRows[index].email != null && displayRows[index].email != '') {
                    emailIDs = emailIDs + displayRows[index].email + ";";
                }
            }
        }

        //for (var index = 0; index < selectedIndices.length; index++) {
        //    if (this.myGrid.getrowdata(selectedIndices[index]).email != undefined && this.myGrid.getrowdata(selectedIndices[index]).email != null && this.myGrid.getrowdata(selectedIndices[index]).email != '') {
        //        emailIDs = emailIDs + this.myGrid.getrowdata(selectedIndices[index]).email + ";";
        //    }
        //}

        var rowIndex;
        rowIndex = this.myGrid.getselectedrowindex(); // Get the Row index of grid
        description = this.myGrid.getrowdata(rowIndex).errDescription;
        var strFind = /\'/g;
        description = description != undefined ? description.replace(strFind, "") : '';
        location.href = "mailto:" + emailIDs + "?Subject=Pulsar Error&Body=" + description;
        
    }

    addToolAction(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var url = "";
        var title = "";
        var height = 750;
        var width = 650;

        id = this.myGrid.getrowdata(selectedIndices).id;
        var action = 1;
        var appErrorId = id;
        var working = 1;
        var prodId = 0;
        var typeId = 2;
        title = "Convert to Action Item";
       // showPopup(url,title,height,width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['action',appErrorId,0,working,prodId,typeId,0,0,'apperror'] } }]);
        //modalPopup.show('#popup', width, height, 'Convert To Action Item', 1);
        modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");
    }
    enterErrorCause(event: any): void {
        var url = "";
        var title = "Properties";
        var height = 650;
        var width = 650;
        var idList = "";
        var selectedIndices = this.myGrid.selectedrowindexes();
        var parameters = "";
        var rowIndex;
        var index: number;
        var rowcount: any;

        rowIndex = this.myGrid.getselectedrowindex(); // Get the Row index of grid
        var id = this.myGrid.getrowdata(rowIndex).id;
        //for (var index = 0; index < selectedIndices.length; index++) {
        //    var idsList = idsList + this.myGrid.getrowdata(selectedIndices[index]).id +",";
        // }
        
        var dataInfo = this.myGrid.getdatainformation();
        var paginationInfo = dataInfo.paginginformation;
        rowcount = dataInfo.rowscount;
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
        var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
        var endIndex = startIndex + displayRowsLength - 1;
        if (displayRowsLength < paginationInfo.pagesize) {
            endIndex = startIndex + displayRowsLength -1;
        }
        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                idList = idList + displayRows[index].id + ";";
            }
        }
        
        idList = idList.substring(0, idList.length - 1)
        url = "/Excalibur/MobileSE/today/AppError.asp?ID=" + id + "&CopyTo=" + idList + "&app=PulsarPlus";
        showPopup(url, title, height, width);

    }
    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }
    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
    }
    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row

    };
    getApplicationErrorsOutstanding() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getApplicationErrorsOutstanding().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }
    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getApplicationErrorsOutstanding();
        this.myMenu.createComponent(this.MenuSettings);
        
    }

    onPageChanged(event: any): void {
        this.myGrid.clearselection();
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {

        if (rowdata.rowStatusColour == 'Ivory') {
            var element = $(defaulthtml);
            if (columnfield == "errLine" && rowdata.errLine == 0) {
                element[0].innerHTML = "";
            }
            element.addClass('jqxgrid-cellrender-font'); 
//            element.addClass('application-error-row-ivory');
            return element[0].outerHTML;
        }
        else
        {
            var element = $(defaulthtml);
            if (columnfield == "errLine" && rowdata.errLine == 0) {
                element[0].innerHTML = "";
            }
            element.addClass('jqxgrid-cellrender-font');
//            element.addClass('application-error-row-gray');
            return element[0].outerHTML;
        }
    };
}

﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05-10-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-workflow-definitions.viewmodel.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class DCRWorkflowDefinitionsViewModel {
    milestone: string;
    workflowType: string;
    workflowCreateDt: Date;
    step: string;
    comments: string;
    pvId: string;
    dotsName: string;
    dcrId: string;
    historyId: string;
    reassign: boolean;
    userId: string;
}
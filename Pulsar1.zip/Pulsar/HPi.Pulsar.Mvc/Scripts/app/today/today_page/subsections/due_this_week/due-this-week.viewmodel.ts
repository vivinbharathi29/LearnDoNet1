﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R (auth\rajamanr)
// Created          : 05/12/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="due-this-week.viewmodels.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class DueThisWeekViewModel
{
    Type: string;
    StatusName: string;
    TargetDate: Date;
    TypeName: string;
    Owner: string;
    Project: string;
    Summary: string;
    Id: number;
}
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 06/02/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="missing-av-marketing-data-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class MissingAVMarketingDataViewModel
{
	productBrandID : number;
	productVersionID : number;
	dOTSName : string;
	avDetailID : number;
	avNo : string;
	aVFeatureCategory : string;
	marketingDescription : string;
	cPLBlindDate : Date;
	rASDiscontinueDate? : Date;
	rTPDate? : Date;
	gPGDescription : string;
	brandName : string;
	bID : number;
	pVID : number;
	daysUntil : number;
	totalNoOfRows : number;
}
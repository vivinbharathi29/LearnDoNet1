﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\subburay
// Created          : 04/25/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/08/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="components-passed-planned-release-date.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, Injectable, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { ComponentsPassedPlannedReleaseDateService } from './components-passed-planned-release-date.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'components-passed-planned-release-date',
    templateUrl:'./components-passed-planned-release-date.component.html',
    styles: [`
.hideSection
{
    display:none;
}
`],
})
export class ComponentsPassedPlannedReleaseDateComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;

    jqxGridConfig: jqxGridConfiguration;
    public enableChageScheduleMenu: boolean = false;
    public enableChooseVersionsMenu: boolean = false;
    public selectedRowIndex: string;

    componentsPassedPlannedReleaseDateCallback(result: any) {
        if (typeof (result) != undefined) {
            this.getComponentsPassedPlannedReleaseDate();
        }
    }

    constructor(http: Http, private service: ComponentsPassedPlannedReleaseDateService, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.componentsPassedPlannedReleaseDateCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'rootId', map: 'rootId' },
            { name: 'component', map: 'component', type: 'string' },
            { name: 'planned', map: 'planned' },
            { name: 'developer', map: 'developer', type: 'string' },
            { name: 'vendor', map: 'vendor', type: 'string' },
            { name: 'modelNumber', map: 'modelNumber', type: 'string' },
            { name: 'partNumber', map: 'partNumber', type: 'string' },
            { name: 'location', map: 'location', type: 'string' },
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID',
                datafield: 'id', width: '8%', filtertype: 'number'
            },
            {
                text: 'Component',
                datafield: 'component', width: '25%', filtertype: 'input'
            },
            {
                text: 'Planned',
                datafield: 'planned', width: '10%', filtertype: 'date', cellsformat: 'MM/dd/yyyy h:mm:ss tt'
            },
            {
                text: 'Developer',
                datafield: 'developer', width: '15%', filtertype: 'input'
            },
            {
                text: 'Vendor',
                datafield: 'vendor', width: '10%', filtertype: 'input'
            },
            {
                text: 'Model',
                datafield: 'modelNumber', width: '10%', filtertype: 'input'
            },
            {
                text: 'Part Number',
                datafield: 'partNumber', width: '8%', filtertype: 'input'
            },
            {
                text: 'Current Workflow',
                datafield: 'location', width: '17%', filtertype: 'input'
            }
        ];

    }

    getComponentsPassedPlannedReleaseDate() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getComponentsPassedPlannedReleaseDate().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    showContextmenu(): boolean {
        return false;
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '160px', height: '120px', mode: 'popup', autoOpenPopup: false,

    };

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        this.getComponentsPassedPlannedReleaseDate();
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        switch (menuItem) {
            case "Release...":
                this.releaseVersionPassedDue(0, gridData.rootId, gridData.id);
                break;
            case "Cancel...":
                this.releaseVersionPassedDue(2, gridData.rootId, gridData.id);
                break;
            case "Change Schedule...":
                this.updateSchedulePassedDue(gridData.id);
                break;
            case "Choose Versions...":
                this.displayAdvancedSupport(0, gridData.rootId);
                break;
            case "Properties":
                if (gridData.id != 0) {
                    this.displayVersion(1, gridData.rootId, gridData.id);
                }
                else {
                    this.displayRoot(gridData.rootId);
                }
                break;
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                if (data.id != 0) {
                    this.enableChageScheduleMenu = false;
                    this.enableChooseVersionsMenu = true;
                }
                else {
                    this.enableChageScheduleMenu = true;
                    this.enableChooseVersionsMenu = false;
                }
            }
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
        //}
    }

    releaseVersionPassedDue(action: number, rootId: number, versionId: number): void {
        var url = "";
        var title = "";
        var height = "550px";
        var width = "90%";
        url = "/excalibur/Release.asp?Action=" + action + "&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Workflow";
        adjustableShowPopupSecondlevel(url, title, height, width, "790px");
    }

    updateSchedulePassedDue(versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/deliverable/schedule.asp?ID=" + versionId + "&app=PulsarPlus";
        title = "Update Schedule";
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['schedule', versionId] } }]);
        modalPopup.show('#externalpagepopup', "450px", "", "Update Schedule");
    }

    displayVersion(action: number, rootId: number, versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/WizardFrames.asp?Type=1&RootID=" + rootId + "&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
    }

    displayAdvancedSupport(versionId: number, rootId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/Deliverable/AdvancedSupport.asp?ProdRootID=" + versionId + "&RootID=" + rootId + "&app=PulsarPlus";
        title = "Advanced Deliverable Support";
        showPopup(url, title, height, width);
    }

    displayRoot(rootId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/Root.asp?ID=" + rootId + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
    }
}

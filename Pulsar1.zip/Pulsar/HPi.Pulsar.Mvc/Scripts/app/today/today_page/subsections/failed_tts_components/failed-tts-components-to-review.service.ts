﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/10/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/06/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="failed-tts-components-to-review.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class FailedTTSComponentsToReviewService {
    constructor(private http: Http, private location: Location) {
    }

    getFailedTtsComponentsToReview() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetFailedTtsComponentsToReview'))
    }
}

﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { MissingBaseUnitSubassemblyNumberService } from './missing-base-unit-subassembly-numbers.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Component({
    selector: 'missing-base-unit',
    templateUrl: './missing-base-unit-subassembly-numbers.component.html',
    providers: [MissingBaseUnitSubassemblyNumberService]
})

export class MissingBaseUnitSubassemblyNumberComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public avsNotRequested;
    public selectedRowIndex: string;
    missingBaseUnitSubassemblyNumberCallback(strID: any) {
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.myGrid.clearselection();
            this.getMissingBaseUnitSubassemblyNumbers();
            //}
        }
    }

    constructor(http: Http, private service: MissingBaseUnitSubassemblyNumberService, private _ngZone: NgZone) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.missingBaseUnitSubassemblyNumberCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.width = '90%';
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'baseUnitFeatureID', map: 'baseUnitFeatureID' },
            { name: 'product', map: 'product' },
            { name: 'gpg', map: 'gpg' },
            { name: 'id', map: 'id' }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'Base Unit Feature ID', cellclassname: this.cellclass,
                datafield: 'baseUnitFeatureID', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '12%'
            },
            {
                text: 'Product', cellclassname: this.cellclass,
                datafield: 'product', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '39.5%'
            },
            {
                text: 'GPG (40c SA)', cellclassname: this.cellclass,
                datafield: 'gpg', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '45%'
            },
            {
                text: 'id',
                datafield: 'id', filtertype: 'input', hidden: true, cellsrenderer: this.cellsrenderer
            }
        ];
    }

    onClickExportRPN(): void {
        var index: number;
        var baseunitIds: string;
        var rowcount: any;
        baseunitIds = "";
        var selectedIndices = this.myGrid.selectedrowindexes();
        if (this.myGrid.getfilterinformation().length > 0) {
            for (index = 0; index < selectedIndices.length; index++) {
                baseunitIds += this.myGrid.getrowdata(selectedIndices[index]).id + ",";
            }
        }
        else {
            var dataInfo = this.myGrid.getdatainformation();
            var paginationInfo = dataInfo.paginginformation;
            rowcount = dataInfo.rowscount;
            var displayRows = this.myGrid.getdisplayrows();
            var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
            var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
            var endIndex = startIndex + displayRowsLength - 1;
            if (displayRowsLength < paginationInfo.pagesize) {
                endIndex = startIndex + displayRowsLength - 1;
            }
            for (index = startIndex; index <= endIndex; index++) {
                if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                    baseunitIds += displayRows[index].id + ",";
                }
            } 
        }

        baseunitIds = baseunitIds.slice(0, baseunitIds.length - 2); // Remove last two characters: comma and space       
        if (baseunitIds == "") {
            alert("Please select base unit features to export RPN");
        }
        else {
            // return "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:missingBaseUnitSubassemblyNumbersRedirect_onclick(" + baseunitIds + ");' /> " + baseunitIds + "</a>";
            var url = "/ipulsar/Product/BaseUnitMissingSA_ExportRPN.aspx?ActionItemIDs=" + baseunitIds + "&app=PulsarPlus";
            var title = "Exporting RPN";
            var height = $(window).height() * (30 / 100);
            var width = $(window).width() * (30 / 100);
            showPopup(url, title, height, width)

        }
        // Call Javascript function here. Pass productDeliverableIds as the parameter
    }

    getMissingBaseUnitSubassemblyNumbers() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMissingBaseUnitSubassemblyNumbers().subscribe(result => {

            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });

    }

    onPageChanged(event: any): void {
        this.myGrid.clearselection();
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getMissingBaseUnitSubassemblyNumbers();
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var id = data.id;
            missingBaseUnitSubassemblyNumbers_onclick(id);
        }
        return false;
    }

    onRowSelect(event: any): void {        
        var index: number;
        var baseunitIds: string;
        var rowcount: any;
        var rowindex = event.args.rowindex;
        if (rowindex.length > 1) {              

            var dataInfo = this.myGrid.getdatainformation();
            var paginationInfo = dataInfo.paginginformation;
            rowcount = dataInfo.rowscount;
            var displayRows = this.myGrid.getdisplayrows();
            var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
            var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
            var endIndex = startIndex + paginationInfo.pagesize - 1;
            if (displayRowsLength < paginationInfo.pagesize) {
                endIndex = startIndex + displayRowsLength - 1;                
            }
            for (index = startIndex; index <= endIndex; index++) {
               
                var rowBoundIndex = this.myGrid.getrowdata(index);                
                if (rowBoundIndex != null) {
                    if (rowBoundIndex.gpg.length > 40) {
                        this.myGrid.unselectrow(index);
                    }
                    //rowindex = event.args.rowindex;
                }
            }

            //while (rowindex.length >= 1) {
            //    var rowBoundIndex = this.myGrid.getrowdata(event.args.rowindex[0]);
            //    if (rowBoundIndex != null) {
            //        if (rowBoundIndex.gpg.length > 40) {
            //            this.myGrid.unselectrow(rowindex[0]);
            //        }
            //        rowindex = event.args.rowindex;
            //    }
            //}
        }
        else {
            var rowBoundIndex = this.myGrid.getrowdata(event.args.rowindex);
            if (rowBoundIndex != null) {
                if (rowBoundIndex.gpg.length > 40) {
                    this.myGrid.unselectrow(rowindex);
                }
            }
        }        
    }

    cellclass = function (row, columnfield, value, rowdata) {
        if (rowdata.gpg.length > 40) {
            return 'cellcolormissingbaseunit';
        }
    }

    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {

        if (rowdata.gpg.length > 40) {
            if (columnfield == "gpg") {
                var element = $(defaulthtml);
                element.css({ 'color': 'red' });
                return element[0].outerHTML;
            }
        }
        return defaulthtml;
        // return "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:missingBaseUnitSubassemblyNumbers_onclick(" + rowdata.id + ");' /> " + value + "</a>";
    };

}

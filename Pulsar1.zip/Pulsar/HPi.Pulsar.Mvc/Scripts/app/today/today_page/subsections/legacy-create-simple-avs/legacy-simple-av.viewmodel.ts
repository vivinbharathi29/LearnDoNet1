﻿export class LegacySimpleAVViewModel {
    deliverableRootId: number;
    avCreateId: string;
    product: string;
    brandName: string;
    component: string;
    avFeatureCategory: string;
    ioGenerated: boolean;
    overMaxLen: string;
    totalNoOfRows: number;
}
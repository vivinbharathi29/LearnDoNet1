﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { AllOpenItemsIOwnService } from './all-open-items-i-own.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { UserInfoService } from '../../dashboard/user-info.service';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { Location } from '@angular/common';
import { Router, NavigationExtras } from '@angular/router'
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';

@Component({
    selector: 'all-open-items-i-open',    
    templateUrl: './all-open-items-i-own.component.html',
})

export class AllOpenItemsIOwnComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;
    public title: string;
    allOpenItemsIOwnCallback(result: any) {
        if (typeof (result) != undefined) {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: AllOpenItemsIOwnService, private userInfoService: UserInfoService, private _ngZone: NgZone, private location: Location, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            ActionsCallbackFn: (value) => this.allOpenItemsIOwnCallback(value),
            popUpCallBackFn: (value) => this.allOpenItemsIOwnCallback(value),
            component: this
        };
        window['angularComponentRef_IOwn'] = { component: this, zone: _ngZone };
        window['angularComponentRef_IOwn'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.allOpenItemsIOwnCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number' },
            { name: 'type', map: 'type' },
            { name: 'typeName', map: 'typeName', type: 'string' },
            { name: 'targetDate', map: 'targetDate' },
            { name: 'owner', map: 'owner', type: 'string' },
            { name: 'project', map: 'project', type: 'string' },
            { name: 'summary', map: 'summary', type: 'string'},
            { name: 'statusName', map: 'statusName', type: 'string'}
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: "9%", cellsrenderer: this.cellsrenderer },
            { text: 'TypeId', filtertype: 'input', datafield: 'type', hidden: true, cellsalign: 'left', align: 'left', width: "8%", cellsrenderer: this.cellsrenderer },
            { text: 'Type', filtertype: 'input', datafield: 'typeName', cellsalign: 'left', align: 'left', width: "13%", cellsrenderer: this.cellsrenderer },
            { text: 'Status', filtertype: 'input', datafield: 'statusName', cellsalign: 'left', width: "10%", cellsrenderer: this.cellsrenderer },
            { text: 'Due Date', datafield: 'targetDate', filterable: false, hidden: false, align: 'left', cellsalign: 'left', width: "15%", cellsrenderer: this.cellsrenderer },
            { text: 'Owner', filtertype: 'input', datafield: 'owner', cellsalign: 'left', width: "10%", cellsrenderer: this.cellsrenderer },
            { text: 'Product', filtertype: 'input', datafield: 'project', hidden: false, align: 'left', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer },
            { text: 'Summary', filtertype: 'input', datafield: 'summary', cellsalign: 'left', width: "40%", cellsrenderer: this.cellsrenderer }
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'type': FilterColumnTypeEnum.Number,
            'typeName': FilterColumnTypeEnum.String,
            'owner': FilterColumnTypeEnum.String,
            'product': FilterColumnTypeEnum.String,
            'summary': FilterColumnTypeEnum.String,
            'statusName': FilterColumnTypeEnum.String
        }
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    sendMail(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = 750;
        var width = 650;
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var NewTop;
        var NewLeft;
        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        var action = 1;
        var title = "";
        var height = 520;
        var width = 850;

        // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=770,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

    } 

    properties(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = "450px";
        var width = "80%";
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var deliverableIssueId = this.myGrid.getrowdata(selectedIndices).id;
        var crType = this.myGrid.getrowdata(selectedIndices).type;
        //url = "/Excalibur/mobilese/today/action.asp?ID=" + id + "&Type=" + typeid + '&app=' + 'PulsarPlus';
        if (crType == 2) {
            //url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['action', 0, deliverableIssueId, 0, 0, 2, 0, 0, 'openiown'] } }]);
            modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");
        }
        else {
            url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
           // showPopup(url, title, height, width);
            showPopupWithHeightInPercentage(url, title, "75%", "94%");
        }
        title = "Properties";
        
    }

    //Menu Code – Sample menu item click to get the Grid row data.
    printPreview(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = 750;
        var width = 650;
        var NewTop;
        var NewLeft;
        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var action = 0;
        var title = "";
        var height = 520;
        var width = 850;
        window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=770,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")
    } 

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        if ($(args).find("a").text() == "Edit Row") {
            //Do something
        }
    }

    onRowClick(event: any): boolean {        
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
        else {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
               // ActionPropertiesMvc(data.id, data.type);
                var deliverableIssueId = data.id;
                var crType = data.type;
                var url = '';//this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
                var title = "Properties";
                var height = "450px";
                var width = "80%";
         //       showPopup(url, title, height, width);
                if (crType == 2) {
                    //url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
                    this.router.navigate([{ outlets: { 'externalpopupWindow': ['action', 0, deliverableIssueId, 0, 0, 2, 0, 0, 'openiown'] } }]);
                    modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");
                }
                else {
                    url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
                   // showPopup(url, title, height, width);
                    showPopupWithHeightInPercentage(url, title, "75%", "94%");
                }
            }

            return false;
        }
    }

    getAllOpenItemsIOwn(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getAllOpenItemsIOwnService(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAllOpenItemsIOwn(paginationInfo);
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAllOpenItemsIOwn(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAllOpenItemsIOwn(paginationInfo);
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
    };

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAllOpenItemsIOwn(paginationInfo);
        this.userInfoService.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
        });
        this.myMenu.createComponent(this.MenuSettings);
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        //var element = $(defaulthtml);
        //element[0].innerHTML = "<a class='jqx-anchor-hover'  href='javascript:ActionPropertiesMvc(" + rowdata.id + "," + rowdata.type + " );' /> " + value + "</a>";
        //return element[0].outerHTML;
    };

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getAllOpenItemsIOwn(paginationInfo);
    }
}
﻿export class MissingRequiredMilestoneViewModel {
    product: string;
    schedule: number;
    itemDescription: string;
    itemDefinition: string;
    productVersionId: string;
    scheduleDataId: string;
}
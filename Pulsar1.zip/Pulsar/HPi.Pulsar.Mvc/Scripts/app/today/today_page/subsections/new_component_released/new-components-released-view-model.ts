// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 06/20/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="new-components-released-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class NewComponentsReleasedViewModel
{
	developernotificationstatus : string;
	prodID : number;
	rootID : number;
	versionID : number;
	id : number;
	product : string;
	partNumber : string;
	developer : string;
	name : string;
	version : string;
	revision : string;
	pass : string;
	targetNotes : string;
	targetVersions : string;
	criticalChanges : string;
	hasIssues : string;
	oSSupportedList : string;
	imageSummary : string;
	fusion : string;
	pulsar : number;
	preinstall : boolean;
	preload : boolean;
	dropInBox : boolean;
	web : boolean;
	aRCD : boolean;
	selectiveRestore : boolean;
	dRDVD : boolean;
	rACD_Americas : boolean;
	rACD_EMEA : boolean;
	rACD_APD : boolean;
	patch : boolean;
	oSCD : boolean;
	docCD : boolean;
	sEPMID : number;
	oDMSEPMID : boolean;
	pINPM : boolean;
	oDMHWPMID : boolean;
	hWPCID : boolean;
	pMAlert : boolean;
	allowImageBuilds : boolean;
	targeted : boolean;
	categoryid : number;
	devcenter : number;
	totalNoOfRows : number;
}
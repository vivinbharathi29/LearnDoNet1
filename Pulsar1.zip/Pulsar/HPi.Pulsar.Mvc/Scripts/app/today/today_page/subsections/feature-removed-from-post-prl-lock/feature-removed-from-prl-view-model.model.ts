// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 06/04/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="feature-removed-from-prl-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class FeatureRemovedFromPRLViewModel
{
    featureActionItemId : number;
	productVersionId : number;
	actionType : number;
	currentUserName : string;
	productName : string;
	sCMName : string;
    featureId : number;
	featureName : string;
}
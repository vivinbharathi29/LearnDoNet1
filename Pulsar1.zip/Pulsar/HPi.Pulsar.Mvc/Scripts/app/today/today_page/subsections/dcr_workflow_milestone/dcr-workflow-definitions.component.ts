﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/10/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 10/03/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-workflow-definitions.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
declare let $: any;
declare var modalPopup: any;
import { DCRWorkflowDefinitionsService } from './dcr-workflow-definitions.service';
import { DCRWorkflowDefinitionsViewModel } from './dcr-workflow-definitions.viewmodel';

@Component({
    selector: 'dcr-workflow-definition',
    templateUrl: './dcr-workflow-definitions.component.html'
})

export class DCRWorkflowDefinitionsComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    mbp: MessageBoxButton;
    public title: string;
    //public userId: number = 0;
    textDCRWorkflowComments: string;
    public enablemenu: boolean = true;
    public dcrWorkflowDefinitions: DCRWorkflowDefinitionsViewModel[];
    PopupCallback(result) {
        if (typeof (result) != "undefined") {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: DCRWorkflowDefinitionsService, private messageBox: MessageBox, private activatedRoute: ActivatedRoute, private _ngZone: NgZone, private router: Router, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.PopupCallback(value),
            component: this
        };
        //this.activatedRoute.queryParams.subscribe((params: Params) => {
        //    this.userId = params['UserId'];
        //});
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'milestone', map: 'milestone', type: 'string' },
            { name: 'workflowType', map: 'workflowType', type: 'string' },
            { name: 'workflowCreateDt', map: 'workflowCreateDt', type: 'date' },
            { name: 'step', map: 'step', type: 'string' },
            { name: 'comments', map: 'comments', type: 'string' },
            { name: 'dotsName', map: 'dotsName', type: 'string' },
            { name: 'pvId', map: 'pvId' },
            { name: 'dcrId', map: 'dcrId', type: 'number' },
            { name: 'historyId', map: 'historyId' },
            { name: 'reassign', map: 'reassign' },
            { name: 'userId', map: 'userId' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'UserId', columngroup: 'DCRWorkflowDefinition',
                datafield: 'userId', hidden: true
            },
            {
                text: 'PVId', columngroup: 'DCRWorkflowDefinition',
                datafield: 'pvId', hidden: true
            },
            {
                text: 'HistoryId', columngroup: 'DCRWorkflowDefinition',
                datafield: 'historyId', hidden: true
            },
            {
                text: 'Product', columngroup: 'DCRWorkflowDefinition',
                datafield: 'dotsName', width: '10%', filtertype: 'input', cellclassname: this.cellclass
            },
            {
                text: 'DCR Number', columngroup: 'DCRWorkflowDefinition',
                datafield: 'dcrId', width: '8%', filtertype: 'number', cellclassname: this.cellclass
            },
            {
                text: 'Milestone', columngroup: 'DCRWorkflowDefinition',
                datafield: 'milestone', width: '12%', filtertype: 'input', cellclassname: this.cellclass
            },
            {
                text: 'Workflow Type', columngroup: 'DCRWorkflowDefinition',
                datafield: 'workflowType', width: '15%', filtertype: 'input', cellclassname: this.cellclass
            },
            {
                text: 'Workflow Create Dt.', columngroup: 'DCRWorkflowDefinition',
                datafield: 'workflowCreateDt', width: '15%', filtertype: 'date', cellsformat: 'MMMM dd yyyy HH:mm tt', cellclassname: this.cellclass
            },
            {
                text: 'Step', columngroup: 'DCRWorkflowDefinition',
                datafield: 'step', cellsalign: 'left', align: 'left', width: '7.5%', filtertype: 'input', cellclassname: this.cellclass
            },
            {
                text: 'Comments', columngroup: 'DCRWorkflowDefinition',
                datafield: 'comments', cellsalign: 'left', align: 'left', width: '29%', filtertype: 'input', cellclassname: this.cellclass
            },
            {
                text: 'Reassign', columngroup: 'DCRWorkflowDefinition',
                datafield: 'reassign', hidden: true
            }
        ];
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                if (data.reassign == true) {
                    this.enablemenu = true;
                }
                else {
                    this.enablemenu = false;
                }
            }
            //this.enablemenu = true;
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
        {
            width: '200px', height: '106px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
        };

    //Menu Code – menu item click to get the Grid row data.
    ContextMenuMilestoneComplete(event: any): void {
        var historyId = "";
        var dcrId = "";
        var pvId = "";
        var url = "";
        var title = "";
        var milestoneComplete = "";
        var height = "535px";
        var width = "1114px";
        var selectedIndices = this.myGrid.selectedrowindexes();
        historyId = this.myGrid.getrowdata(selectedIndices).historyId;
        dcrId = this.myGrid.getrowdata(selectedIndices).dcrId;
        pvId = this.myGrid.getrowdata(selectedIndices).pvId;
        milestoneComplete = "Y";
        url = "/Excalibur/MobileSE/Today/DCRWorkflowFrame.asp?DCRID=" + dcrId + "&PVID=" + pvId + "&HistoryID=" + historyId + "&AddNew=0&CompleteMilestone=Y" + "&app=" + "PulsarPlus";
        title = "Milestone Complete";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['dcrworkflowupdate', historyId, dcrId, pvId, milestoneComplete] } }]);
        modalPopup.show('#externalpagepopup', "1057px", "600px", "View Workflow Status");
    }

    DCRWorkflowReassign(event: any): void {
        var strUpdated;
        var historyId = "";
        var url = "";
        var title = "";
        var height = "400px";
        var width = "50%";
        var selectedIndices = this.myGrid.selectedrowindexes();
        historyId = this.myGrid.getrowdata(selectedIndices).historyId;
        // url = "/Excalibur/MobileSE/Today/DCRWorkflowReassignFrame.asp?HistoryID=" + historyId + "&app=" + "PulsarPlus";
        url = "/pulsarplus/core/User/ChooseEmployee?dialogType=12&HistoryID=" + historyId;
        title = "Reassign Milestone";
        strUpdated = showPopup(url, title, height, width);
        //if (typeof (strUpdated) != "undefined")
        //    window.parent.location.reload(true);
    }

    ViewDCRWorkflowProperties(event: any): void {
        var deliverableIssueId = "";
        var url = "";
        var title = "";
        var height = "75%";
        var width = "94%";
        var selectedIndices = this.myGrid.selectedrowindexes();
        var crType = 3;
        deliverableIssueId = this.myGrid.getrowdata(selectedIndices).dcrId;
        //url = "/Excalibur/MobileSE/Today/action.asp?ID=" + dcrId + "&Type=3" + "&app=" + "PulsarPlus";
        url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
        title = "View Properties";
        //showPopup(url, title, height, width);
        showPopupWithHeightInPercentage(url, title, height, width);
    }

    ViewDCRWorkflowStatus(event: any): void {
        //var userId = "";
        var dcrId = "";
        var pvId = "";
        //var url = "";
        //var title = "";
        //var height = "535px";
        //var width = "1057px";
        var selectedIndices = this.myGrid.selectedrowindexes();
        //userId = this.myGrid.getrowdata(selectedIndices).userId;
        dcrId = this.myGrid.getrowdata(selectedIndices).dcrId;
        pvId = this.myGrid.getrowdata(selectedIndices).pvId;
        //url = "/Excalibur/MobileSE/Today/DCRWorkflowFrame.asp?DCRID=" + dcrId + "&AddNew=0&UserID=" + userId + "&PVID=" + pvId + "&app=" + "PulsarPlus";
        //title = "View Workflow Status";
        //showPopup(url, title, height, width);
        this.ShowExternalPopup(dcrId, pvId);
    }

    ShowExternalPopup(dcrId: any, pvId: any) {
        var milestoneComplete = "";
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['dcrworkflowstatus', dcrId, pvId, milestoneComplete] } }]);
        modalPopup.show('#externalpagepopup', "1057px", "600px", "View Workflow Status");
    }

    getDcrWorkflowDefinitions() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getDcrWorkflowDefinitions().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getDcrWorkflowDefinitions();
        this.service.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
        });
        this.myMenu.createComponent(this.MenuSettings);
    }

    reloadGrid(): void {
        this.myGrid.clearselection();
        this.getDcrWorkflowDefinitions();
    }

    onPageChanged(event: any): void {
        this.myGrid.clearselection();
    }

    cmdMilestoneComplete_onclick(): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        if (selectedIndices.length == 0) {
            this.messageBox.Show("DCR Workflow Milestone", "Please select the milestone.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.confirmationMessage)
        }
        else {
            this.messageBox.Show("DCR Workflow Milestone", "Are you sure you want to complete the selected milestones?", MessageBoxType.OKCancel, MessageBoxIcon.Information, "400", this.confirmationMessage)
        }
    }

    cmdAddMilestoneComments_onclick(): void {
        var index: number;
        var rowcount: any;
        var selectedIndices = this.myGrid.selectedrowindexes();
        if (selectedIndices.length == 0) {
            this.messageBox.Show("DCR Workflow Milestone", "Please select the milestone.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.confirmationMessage)
        }
        else {
            var historyId = "";
            var commentsval = "";
            historyId = this.myGrid.getrowdata(selectedIndices).historyId;
            commentsval = (<HTMLInputElement>document.getElementById("txtDCRWorkflowComments")).value;
            if ((<HTMLInputElement>document.getElementById("txtDCRWorkflowComments")).value == "") {
                this.messageBox.Show("DCR Workflow Milestone", "Please Enter Comments Prior To Updating", MessageBoxType.Ok, MessageBoxIcon.Warning, "400", this.confirmationMessage)
            }
            else {
                let parameters = new URLSearchParams();
                this.myGrid.showdefaultloadelement(true);

                var dataInfo = this.myGrid.getdatainformation();
                var paginationInfo = dataInfo.paginginformation;
                rowcount = dataInfo.rowscount;
                var displayRows = this.myGrid.getdisplayrows();
                var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
                var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
                var endIndex = startIndex + displayRowsLength - 1;
                if (displayRowsLength < paginationInfo.pagesize) {
                    endIndex = startIndex + displayRowsLength - 1;
                }

                for (index = startIndex; index <= endIndex; index++) {
                    if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                        historyId = displayRows[index].historyId;
                        parameters.set("Function", "AddDCRWorkflowComments");
                        parameters.set("Comments", encodeURI(commentsval));
                        parameters.set("HistoryID", historyId);
                        this.service.postDCRWorkflowCompleteService(parameters).subscribe(result => {
                            this.reloadGrid();
                        });
                    }
                }
                (<HTMLInputElement>document.getElementById("txtDCRWorkflowComments")).value = "";
                this.myGrid.hideloadelement();
            }
        }
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
            let parameters = new URLSearchParams();
            var historyId = "";
            var dcrId = "";
            var pvId = "";
            var index: number;
            var rowcount: any;
            var selectedIndices = this.myGrid.selectedrowindexes();
            this.myGrid.showdefaultloadelement(true);

            var dataInfo = this.myGrid.getdatainformation();
            var paginationInfo = dataInfo.paginginformation;
            rowcount = dataInfo.rowscount;
            var displayRows = this.myGrid.getdisplayrows();
            var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
            var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
            var endIndex = startIndex + displayRowsLength - 1;
            if (displayRowsLength < paginationInfo.pagesize) {
                endIndex = startIndex + displayRowsLength - 1;
            }

            for (index = startIndex; index <= endIndex; index++) {
                if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                    historyId = displayRows[index].historyId;
                    dcrId = displayRows[index].dcrId;
                    pvId = displayRows[index].pvId;
                    parameters.set("Function", "UpdateDCRWorkflowComplete");
                    parameters.set("HistoryID", historyId);
                    parameters.set("DCRID", dcrId);
                    parameters.set("PVID", pvId);
                    this.service.postDCRWorkflowCompleteService(parameters).subscribe(result => {
                        this.reloadGrid();
                    });
                }
            }
            (<HTMLInputElement>document.getElementById("txtDCRWorkflowComments")).value = "";
            this.myGrid.hideloadelement();
        }
        else if (this.mbp == MessageBoxButton.Cancel) {

        }
    }

    cellclass = function (row, columnfield, value, rowdata) {
        if (rowdata.reassign == true) {
            return 'cellcolor';
        }
    }
}

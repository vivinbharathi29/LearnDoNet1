// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : subburay
// Created          : 09/14/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="feature-naming-override-requested-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class FeatureNamingOverrideRequestedViewModel {
    featureID: number;
    overrideReason: string;
    requestedBy: string;
    requestedDate: string;
    email: string;
    totalNoOfRows: number;
    userName: string;
    actionType: number;
    featureName: string;
}
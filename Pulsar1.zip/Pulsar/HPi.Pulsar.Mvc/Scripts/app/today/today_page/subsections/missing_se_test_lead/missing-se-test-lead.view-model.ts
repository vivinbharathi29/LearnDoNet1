﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\rajamanr
// Created          : 04/06/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="missing-se-test-lead.viewmodel.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class MissingSETestLeadViewModel {
    Id: number;
    Product: string;
    Description: string;
    TotalNoOfRows: number;
    FusionRequirement: boolean;
}
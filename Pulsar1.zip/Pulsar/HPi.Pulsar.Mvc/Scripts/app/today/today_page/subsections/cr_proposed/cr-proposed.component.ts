﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/11/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 08/10/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="cr-proposed.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

/// <reference path="../../../../jqwidgets-ts/angular_jqxgrid.ts" />
/// <reference path="../../../../shared/jqxgrid_helper/jqxgrid-configuration.ts" />
import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { CRProposedService } from './cr-proposed.service';
import { CRProposedViewModel } from './cr-proposed.viewmodel';

@Component({
    selector: 'cr-proposed',
    templateUrl:'./cr-proposed.component.html'
})

export class CRProposedComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public crProposed: CRProposedViewModel[];
    public selectedRowIndex: string;
    PopupCallback(result) {
        if (typeof (result) != "undefined") {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: CRProposedService, private _ngZone: NgZone, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.PopupCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;

        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number'  },
            { name: 'dotsName', map: 'dotsName', type: 'string'  },
            { name: 'status', map: 'status', type: 'string'  },
            { name: 'owner', map: 'owner', type: 'string'  },
            { name: 'submitter', map: 'submitter', type: 'string'  },
            { name: 'summary', map: 'summary', type: 'string'  },
            { name: 'type', map: 'type', type: 'string'  }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'Type', columngroup: 'CRProposed',
                datafield: 'type', hidden: true
            },
            {
                text: 'ID', columngroup: 'CRProposed',
                datafield: 'id', cellsalign: 'left', align: 'left', width: '10%', cellsformat: 'n', filtertype: 'number'
            },
            {
                text: 'Product', columngroup: 'CRProposed',
                datafield: 'dotsName', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input'
            },
            {
                text: 'Status', columngroup: 'CRProposed',
                datafield: 'status', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input'
            },
            {
                text: 'Owner', columngroup: 'CRProposed',
                datafield: 'owner', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input'
            },
            {
                text: 'Submitter', columngroup: 'CRProposed',
                datafield: 'submitter', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input'
            },
            {
                text: 'Summary', columngroup: 'CRProposed',
                datafield: 'summary', cellsalign: 'left', align: 'left', width: '50%', filtertype: 'input'
            }
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'dotsName': FilterColumnTypeEnum.String,
            'status': FilterColumnTypeEnum.String,
            'owner': FilterColumnTypeEnum.String,
            'submitter': FilterColumnTypeEnum.String,
            'summary': FilterColumnTypeEnum.String
        }
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
        else {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                var deliverableIssueId = data.id;
                var crType = data.type;
                var url = "";
                var title = "";
                var height = "75%";
                var width = "94%";               
                url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType+"/0/0");
                title = "Change Request Properties";
                showPopupWithHeightInPercentage(url, title, height, width);
                //changeproposedrows_onclick(deliverableIssueId, crType);
            }
            return false;
        }
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
    };

    //Menu Code – menu item click to get the Grid row data.
    ActionMail(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var strResult;
        var NewTop;
        var NewLeft;
        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var action = 1;
        var title = "";
        var height = 520;
        var width = 850;
        // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        strResult = window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=770,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        //strResult = window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid + "&app=" + "PulsarPlus", "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No") 
    }

    ActionProperties(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = "75%";
        var width = "94%";
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + id + "/" + typeid + "/0/0");
        title = "Properties";
        showPopupWithHeightInPercentage(url, title, height, width);
        //url = "/Excalibur/mobilese/today/action.asp?ID=" + id + "&Type=" + typeid + "&app=" + "PulsarPlus";
        //title = "Properties";
        //showPopup(url, title, height, width);
    }

    ActionPrint(event: any): void {
        var strResult;
        var NewTop;
        var NewLeft;
        var id = "";
        var typeid = "";
        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        var selectedIndices = this.myGrid.selectedrowindexes();
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
       // strResult = window.open("/Excalibur/MobileSE/Today/actionReport.asp?Action=0&ID=" + id + "&Type=" + typeid + "&app=" + "PulsarPlus", "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No"); 
        strResult = window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + 0 + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=770,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No");
    }

    getCRProposed(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getCRProposed(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRProposed(paginationInfo);
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRProposed(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRProposed(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myGrid.localizestrings(this.jqxGridConfig.localization);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRProposed(paginationInfo);
        this.myMenu.createComponent(this.MenuSettings);
    }

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRProposed(paginationInfo);
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        //var element = $(defaulthtml);
        //element[0].innerHTML = "<a style='font-family:verdana' class='jqx-anchor-hover ID=" + rowdata.id + "&" + "Type=" + rowdata.type + "' id='changeproposedrows' onclick='javascript:changeproposedrows_onclick();' /> " + value + " </a>";
        //return element[0].outerHTML;
    };

    exportToExcel(): void {
        CrProposedExportToExcel();
    }
}

// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R auth\rajamanr
// Created          : 04-18-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="lead-product-synchronization.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response,URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { pagination } from '../../../../shared/pagination-model.model';
import { ListSortDirection } from '../../../../shared/listsortdirection';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Injectable()
export class LeadProductSynchronizationService {
    constructor(private http: Http, private location: Location) { 
	
    }
    getLeadProductSynchronization(paginationInfo: PaginationModel,strProductId:string='') {
        
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetLeadProductDiscrepencies/' + strProductId), JSON.stringify(paginationInfo), options);
    }

    getLeadProductListSynchronization(productId:string) {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetLeadProductDiscrepenciesProducts/' + productId));
    }
    //postMultiUpdateService(strValue, parameters)
    //{
    //    var url = "/Excalibur/ActionMultiApprove.asp?ApproverStatus=" + strValue;
    //    let headers = new Headers({ 'Content-Type': 'application/json' });
    //    let options = new RequestOptions({ headers: headers, body: parameters });
    //    return this.http.post(url, options);
    //}	
}
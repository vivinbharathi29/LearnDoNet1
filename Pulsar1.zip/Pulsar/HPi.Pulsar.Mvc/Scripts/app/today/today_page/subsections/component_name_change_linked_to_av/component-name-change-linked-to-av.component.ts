﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh.T
// Created          : 05/08/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 10/05/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="component-name-change-linked-to-av.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { ComponentNameChangeLinkedToAVService } from './component-name-change-linked-to-av.service';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Component({
    selector: 'component-name-change-linked-av',
    templateUrl:'./component-name-change-linked-to-av.component.html'
})

export class ComponentNameChangeLinkedToAVComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public title: string;
    public userId: number = 0;
    constructor(http: Http, private service: ComponentNameChangeLinkedToAVService, private activatedRoute: ActivatedRoute) {
        this.activatedRoute.queryParams.subscribe((params: Params) => {
        });
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'product', map: 'product' },
            { name: 'avNo', map: 'avNo' },
            { name: 'currentGPGDescription', map: 'currentGPGDescription' },
            { name: 'newGPGDescription', map: 'newGPGDescription' },
            { name: 'deliverableNameChangeAvLinkedId', map: 'deliverableNameChangeAvLinkedId' },
            { name: 'overMaxLen', map: 'overMaxLen' }               
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', datafield: 'id', filtertype: 'number', width: '10%', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass
            },
            {
                text: 'Product', columngroup: 'HelpAndSupport',
                datafield: 'product', width: '17%', filtertype: 'input', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass
            },
            {
                text: 'AV No', columngroup: 'HelpAndSupport',
                datafield: 'avNo', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass
            },
            {
                text: 'Current GPG Description', columngroup: 'HelpAndSupport',
                datafield: 'currentGPGDescription', cellsalign: 'left', align: 'left', width: '25%', filtertype: 'input', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass
            },
            {
                text: 'New GPG Description', columngroup: 'HelpAndSupport',
                datafield: 'newGPGDescription', cellsalign: 'left', align: 'left', width: '35%', filtertype: 'input', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass
            },
            {
                text: 'deliverableNameChangeAvLinkedId', columngroup: 'HelpAndSupport',
                datafield: 'deliverableNameChangeAvLinkedId', cellsalign: 'left', align: 'left', hidden: true
            },
            {
                text: 'overMaxLen', columngroup: 'HelpAndSupport',
                datafield: 'overMaxLen', cellsalign: 'left', align: 'left', hidden: true
            }           
        ];

    }

    onClickUpdateAv(currentUserId, NotActionable): void {
        var index: number;
        var deliverableNameChangeAvLinkedIds: string;       
        var rowcount: any;
        currentUserId = this.userId;
        deliverableNameChangeAvLinkedIds = "";
        var selectedIndices = this.myGrid.selectedrowindexes();  
        let parameters = new URLSearchParams();

        var dataInfo = this.myGrid.getdatainformation();
        var paginationInfo = dataInfo.paginginformation;
        rowcount = dataInfo.rowscount;
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
        var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
        var endIndex = startIndex + displayRowsLength - 1;
        if (displayRowsLength < paginationInfo.pagesize) {
            endIndex = startIndex + displayRowsLength - 1;
        } 

        if (selectedIndices.length != 0) {

            for (index = startIndex; index <= endIndex; index++) {
                if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                    deliverableNameChangeAvLinkedIds += displayRows[index].deliverableNameChangeAvLinkedId;
                    if (deliverableNameChangeAvLinkedIds == "") {
                        alert("You must select the components you want to remove first.");
                    }
                    else {
                        parameters.set("Function", "UpdateAv");
                        parameters.set("UpdateID", deliverableNameChangeAvLinkedIds);
                        parameters.set("NotActionable", NotActionable);
                        parameters.set("UserID", currentUserId);
                        this.service.postUpdateAVs(parameters)
                            .subscribe(result => {
                                console.log(result);
                                this.reloadGrid();
                            });
                    }
                }
            }
        }
        else {
            alert("You must select the components you want to remove first.");
        }
    }

    makePageRequest(url: string, files: string, methodtype: string, parameter: string)
    {
        
        var xhr = new XMLHttpRequest(),
            method = methodtype,
            url = url;

        xhr.open(method, url, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                console.log(xhr.responseText);
            }
        };
        xhr.send(parameter);
    }   

    getComponentNameChangeLinkedToAV() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getComponentNameChangeLinkedToAV().subscribe(result => {            
            this.jqxGridConfig.localdata = result.json();
            this.userId = result.json()[0].userId;         
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getComponentNameChangeLinkedToAV();
        this.service.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
        });
    }

    onPageChanged(event: any): void {
        this.myGrid.clearselection();
    }

    cellclass = function (row, columnfield, value, rowdata) {
        if (rowdata.overMaxLen == "1") {
            return 'cellcolor';
        }
    }

    reloadGrid(): void {
        this.myGrid.clearselection();
        this.getComponentNameChangeLinkedToAV();
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        if (rowdata.overMaxLen == "1") {
            var element = $(defaulthtml);
            element.css({ 'background-color': '#ffe4e1' });
            return element[0].outerHTML;
        }
        return defaulthtml;
    }    
};
﻿export class HardwareComponentsWithNoPartNumberViewModel {
    id: number;
    commodity: string;
    modelnumber: string;
    supplier: string;
    versionRevisionPass: string;
}
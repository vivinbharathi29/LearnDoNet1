﻿export class EngineeringDevelopmentWorkingListViewModel
{
    id: string;
    rootId: string;
    categoryId: string;
    component: string;
    version: string;
    vendor: string;
    model: string;
    part: string;
}
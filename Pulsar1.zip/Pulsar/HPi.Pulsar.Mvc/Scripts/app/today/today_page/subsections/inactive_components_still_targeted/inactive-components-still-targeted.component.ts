﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { InActiveComponentStillTargetedService } from './inactive-components-still-targeted.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router'

@Component({
    selector: 'inactive-component-still-targeted',
    templateUrl: './inactive-components-still-targeted.component.html',
    providers: [InActiveComponentStillTargetedService]
})

export class InActiveComponentStillTargetedComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public avsNotRequested;
    public selectedRowIndex: string;
    ShowCommodityPropertiesCallFromOutside(strID) {

        if (typeof (strID) != "undefined") {
            if (strID > 0) {
                console.log(strID);
                this.pageReload();

            }
        }

    }
    constructor(http: Http, private service: InActiveComponentStillTargetedService, private _ngZone: NgZone, private router: Router)//,location:Location)
    {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            ShowCommodityPropertiesCallbackFn: (value) => this.ShowCommodityPropertiesCallFromOutside(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'product', map: 'product' },
            { name: 'release', map: 'release' },
            { name: 'availableUntil', map: 'availableUntil' },
            { name: 'component', map: 'component' },
            { name: 'version', map: 'version' },
            { name: 'model', map: 'model' },
            { name: 'partNumber', map: 'partNumber' },
            { name: 'rootId', map: 'rootId' },
            { name: 'productId', map: 'productId' }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'ID',
                datafield: 'id', filtertype: 'number', cellsrenderer: this.cellsrenderer, width: '8%'
            },
            {
                text: 'Product',
                datafield: 'product', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '10%'
            },
            {
                text: 'Release',
                datafield: 'release', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '9%'
            },
            {
                text: 'Available Until',
                datafield: 'availableUntil', cellsrenderer: this.cellsrenderer, width: '8%', filtertype: 'date', cellsFormat: 'MM/dd/yyyy'
            },
            {
                text: 'Component',
                datafield: 'component', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '35%'
            },
            {
                text: 'Version',
                datafield: 'version', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '15%'
            },
            {
                text: 'Model',
                datafield: 'model', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '12%'
            },
            {
                text: 'Part Number',
                datafield: 'partNumber', filtertype: 'input', cellsrenderer: this.cellsrenderer, width: '9%'
            },
            {
                text: 'Root ID',
                datafield: 'rootId', filtertype: 'input', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Product ID',
                datafield: 'productId', filtertype: 'input', hidden: true, cellsrenderer: this.cellsrenderer
            }
        ];
    }

    getInActiveComponentStillTargeted() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getInActiveComponentStillTargeted().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();

            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);

        this.getInActiveComponentStillTargeted();
    }
    pageReload(): void {

        //var paginationInfo: PaginationModel;
        //paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getInActiveComponentStillTargeted();
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var productId = data.productId;
            var rootId = data.rootId;
            var versionId = data.id;
            
            //inactivecomponent_onclick(productId, rootId, versionId);
            var TodayPageSection = "EditCommodityStatusSignoff";
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['updateorproductqualificationpulsar', '0', productId, rootId, versionId,'0','0'] } }]);
            modalPopup.show('#externalpagepopup', "80%", "480px", "Update Qualification Status");
        }
        return false;
    }

    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {
        //var element = $(defaulthtml);
        //element[0].innerHTML = "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:inactivecomponent_onclick(" + rowdata.productId + " ," + rowdata.rootId + "," + rowdata.id + ");' /> " + value + "</a>";
        //return element[0].outerHTML;
    };
}

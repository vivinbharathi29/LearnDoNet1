// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 04-18-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="items-awaiting-my-approval-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class ItemsAwaitingMyApprovalViewModel
{
	id : number;
	product : string;
	type? : any;
	owner : string;
	summary : string;
	status? : any;
	typeName : string;
	statusName : string;
	createDate? : Date;
}
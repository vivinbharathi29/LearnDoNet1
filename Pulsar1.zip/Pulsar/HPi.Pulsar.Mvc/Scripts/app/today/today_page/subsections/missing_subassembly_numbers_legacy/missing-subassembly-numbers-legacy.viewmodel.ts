﻿export class MissingSubassemblyNumberViewModel {
    id: number;
    product: string;
    component: string;    
}
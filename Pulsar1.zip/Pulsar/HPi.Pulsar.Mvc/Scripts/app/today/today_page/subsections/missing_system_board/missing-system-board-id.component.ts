﻿/// <reference path="../../../../jqwidgets-ts/angular_jqxgrid.ts" />
/// <reference path="missing-system-board-id.service.ts" />

// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : auth\rajamanr
// Created          : 04/04/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="missing-system-board-id.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
import { Component, ViewChild, AfterViewInit, Injectable,NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
//import { Location } from '@angular/common';
import { MissingSystemBoardIDService } from './missing-system-board-id.service';
import { MissingSystemBoardIDViewModel } from './missing-system-board-id.view-model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';

@Component({
    selector: 'missing-system-board-id',
    templateUrl:'./missing-system-board-id.component.html'
})
@Injectable()
export class MissingSystemBoardIDComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    public missingSystemBoardIds: MissingSystemBoardIDViewModel[];
    jqxGridConfig: jqxGridConfiguration;
    constructor(http: Http, private service: MissingSystemBoardIDService,private ngZone:NgZone) {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        window['angularComponentRef'] = { component: this, zone: ngZone };
        window['angularComponentRef'] = {
            zone: this.ngZone,
            MissingSystemBoardCallBackFn: (value) => this.MissingSystemBoardCallBack(value),
            component: this
        };

        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'product', map: 'product', type: "string" }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'MissingSystemBoardId',
                datafield: 'id', width: "35%", filtertype: 'number', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Product', columngroup: 'MissingSystemBoardId',// handlekeyboardnavigation:this.handlekeyboardnavigation,
                datafield: 'product', width: "60%", filtertype: 'input', cellsrenderer: this.cellsrenderer
            }
        ];
    }
    getMissingSystemBoard() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMissingSystemBoardIds().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }
    MissingSystemBoardCallBack(status: any): void {
            this.getMissingSystemBoard();
    }
    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getMissingSystemBoard();
    }
    //Menu Code - Grid Row click event to display the menu
    public selectedRowIndex: string;
    onRowClick(event: any): boolean {
        console.log("Row click", event.args.rowindex);
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (event.args.rightclick) {
            return false;
        }
        else {
            missingsystem_onclick(data.id);
        }
    }
    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='jqx-anchor-hover jqxgrid-cellrender-font' href='javascript:missingsystem_onclick(" + rowdata.id + " );' /> " + value + "</a>";
//        element.addClass('missing-system-board-ivory');
        return element[0].outerHTML; 
    };
    //handlekeyboardnavigation=(event)=> {
    //    var key = event.charCode ? event.charCode : event.keyCode ? event.keyCode : 0;
    //    if (key == 13) {
    //        alert('Pressed Enter Key.');
    //        return true;
    //    }
    //}
}

﻿export class FailedTTSComponentsToReviewViewModel
{
    id: number;
    category: string;
    vendor: string;
    component: string;
    version: string;
    revision: string;
    pass: string;
    partNumber: string;
    modelNumber: string;
    reportPath: string;
    rootId: string;
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : RajivGandhi.R
// Created          : 06/03/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/08/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="component-in-test-odm-hardware-lead.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Injectable()
export class ComponentInTestOdmHardwareLeadService {
    constructor(private http: Http, private location: Location) {

    }
    getComponentInTestOdmHardwareLead(paginationInfo: PaginationModel) {
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetComponentInTestOdmLeads'), JSON.stringify(paginationInfo), options);
    }

    getImpersonateName() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
    }
}
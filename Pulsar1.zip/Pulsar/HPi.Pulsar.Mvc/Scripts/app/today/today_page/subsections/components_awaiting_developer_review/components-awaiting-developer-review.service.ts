﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 03/24/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/08/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="components-awaiting-developer-review.service" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Injectable()
export class ComponentsAwaitingDeveloperReviewService {
    constructor(private http: Http, private location: Location) {

    }

    getComponentsAwaitingDeveloperReview(paginationInfo: PaginationModel) {
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetComponentsAwaitingDeveloperReview'), JSON.stringify(paginationInfo), options);
    }
}

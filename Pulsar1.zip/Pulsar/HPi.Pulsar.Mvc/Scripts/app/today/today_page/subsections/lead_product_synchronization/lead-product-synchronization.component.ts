﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { LeadProductSynchronizationService } from './lead-product-synchronization.service';
import { LeadProductSynchronizationViewModel } from './lead-product-synchronization-viewmodel';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
//import { DomSanitizer } from '@angular/platform-browser'
import { Router, ActivatedRoute, Params } from '@angular/router'
import { Location } from '@angular/common';

import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';

//@Pipe({ name: 'safeHtml' })
//export class SafeHtmlPipe implements PipeTransform {
//    constructor(private sanitized: DomSanitizer) { }
//    transform(value) {
//        console.log(this.sanitized.bypassSecurityTrustHtml(value))
//        return this.sanitized.bypassSecurityTrustHtml(value);
//    }
//}
@Component({
    selector: 'lead-product-synchronization',
    templateUrl: './lead-product-synchronization.component.html'
})

export class LeadProductSynchronizationComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    currentUserID: number = 0;
    private mbp: MessageBoxButton;
    allNewProducts: any;
    public LeadProductSynchronization: LeadProductSynchronizationViewModel[];
    public leadProductSynchronizationViewModel: LeadProductSynchronizationViewModel;

    constructor(private http: Http, private location: Location, private service: LeadProductSynchronizationService, private activatedRoute: ActivatedRoute, private messageBox: MessageBox, private ngZone: NgZone, private router: Router) {
        //this.activatedRoute.queryParams.subscribe((params: Params) => {
        //    this.currentUserID = params['UserId'];
        //});
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = "470px";
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.settings.rowsheight = 80;
        this.jqxGridConfig.settings.autorowheight = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
        window['angularComponentRef_LeadProduct'] = { component: this, zone: ngZone };
        window['angularComponentRef_LeadProduct'] = {
            zone: this.ngZone,
            LeadProductSynchronizationCallbackFn: (value) => this.LeadProductSynchronizationCallback(value),
            ExpandCallbackFn: (strSection, strProdID) => this.ExpandCallbackFn(strSection, strProdID),
            AllProductCallbackFn: (strProdID, strText) => this.AllProductCallback(strProdID, strText),
            component: this
        };
        this.jqxGridConfig.datafields = [
            { name: 'product', map: 'product', type: "string" },
            { name: 'leadProduct', map: 'leadProduct', type: "string" },
            { name: 'deliverableName', map: 'deliverableName', type: "string" },
            { name: 'leadProductSynchronizationsSummary', map: 'leadProductSynchronizationsSummary', type: "string" },
            // { name: 'leadID', map: 'leadID' },
            { name: 'followID', map: 'followID' },
            { name: 'rootID', map: 'rootID' },
            { name: 'leadProductSynchronizationId', map: 'leadProductSynchronizationId' },
            { name: 'isFusionRequirements', map: 'isFusionRequirements' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'LeadProductSynchronizationId', filtertype: 'input', datafield: 'leadProductSynchronizationId', hidden: true, cellsrenderer: this.cellsrenderer },
            //{ text: 'LeadID', filtertype: 'input', datafield: 'leadID', hidden: true, cellsrenderer: this.cellsrenderer },
            { text: 'FollowerID', filtertype: 'input', datafield: 'followID', hidden: true, cellsrenderer: this.cellsrenderer },
            { text: 'RootID', filtertype: 'input', datafield: 'rootID', hidden: true, cellsrenderer: this.cellsrenderer },
            { text: 'Product', filtertype: 'input', datafield: 'product', width: "15%", cellsalign: 'left', align: 'left', cellsrenderer: this.cellsrenderer },
            { text: 'Lead Product', filtertype: 'input', datafield: 'leadProduct', cellsalign: 'left', align: 'left', width: "15%", cellsrenderer: this.cellsrenderer },
            { text: 'Component', filtertype: 'input', datafield: 'deliverableName', align: 'left', cellsalign: 'left', width: "25%", cellsrenderer: this.cellsrenderer },
            { text: 'Actions', filtertype: 'input', datafield: 'leadProductSynchronizationsSummary', align: 'left', cellsalign: 'left', width: "42%", cellsrenderer: this.cellsrenderer },
            { text: 'isFusionRequirements', datafield: 'isFusionRequirements',hidden:true },
        ];

        this.jqxGridConfig.columnTypes = {
            'product': FilterColumnTypeEnum.String,
            'leadProduct': FilterColumnTypeEnum.String,
            'deliverableName': FilterColumnTypeEnum.String,
            'leadProductSynchronization': FilterColumnTypeEnum.String
        }
    }

    LeadProductSynchronizationCallback(status: any): void {
        if (typeof (status) != "undefined") {
            if (status > 0) {
                console.log(status);
                this.pageReload();
            }
        }
    }
    AllProductCallback(strProdID: any, strText: any) {
        //debugger;
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.leadProductId = strProdID;
        this.getLeadProductSynchronization(paginationInfo, strProdID);
        //this.service.getNewComponentsReleasedSummaryService(strProdID).subscribe(result => {
        //    this.allNewProducts = result.json();
        //});
    }
    pageReload(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var selectedProduct: any;
        selectedProduct = $('#dnProduct :selected').val();
        if (selectedProduct != 'ALL') {
            this.getLeadProductSynchronization(paginationInfo, selectedProduct);
        } else {
            this.getLeadProductSynchronization(paginationInfo);
        }
        this.myGrid.clearselection();
    }    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }
    numCallback = (response: MessageBoxButton): void => {

        this.leadProductSynchronizationViewModel = new LeadProductSynchronizationViewModel();
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {

            var url = "";
            var title = "";
            var height = 900;
            var width = 650;
            if (this.selectedIds == '' || this.selectedIds == undefined) {
                return;
            }
            else {
                if (this.syncType == "1") {
                    this.myGrid.showdefaultloadelement(true);
                    this.leadProductSynchronizationViewModel.product = this.selectedIds;
                    this.http.post(this.location.prepareExternalUrl("/product/Product/SyncSelectedProducts"), this.leadProductSynchronizationViewModel).subscribe(x => {
                        if (x.json() == true)
                            this.LeadProductSynchronizationCallback('1');
                    });
                    title = "View Excluded Components";
                }
                else if (this.syncType == "2") {
                    url = "/Excalibur/product/leadproduct/QuickExcludeSave.asp?ExceptionList=" + this.selectedIds + "&app=PulsarPlus";
                    title = "View Excluded Components";
                    showPopup(url, "", height, width);
                }   
            }
        }
        //else if (this.mbp == MessageBoxButton.No) {
        //    alert(this.mbp.toString());
        //}
        //else if (this.mbp == MessageBoxButton.Ok) {
        //    alert(this.mbp.toString());
        //}
        //else if (this.mbp == MessageBoxButton.Cancel) {
        //    alert(this.mbp.toString());
        //}

    }
    private selectedIds: string;
    private syncType: string;
    MultiLeadSync(syncType: any): void {
        var strIDs = "";
        var url;
        var index: number;
        var selectedIndices = this.myGrid.selectedrowindexes();
        var fusionRequirement = this.myGrid.getrowdata(selectedIndices[index]).isFusionRequirements == true ? "1" : "0";

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = this.myGrid.getrows().length;
        var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
        var endIndex = startIndex + paginationInfo.PageSize - 1;
        if (displayRowsLength < paginationInfo.PageSize) {
            endIndex = startIndex + displayRowsLength - 1;
        }
        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                strIDs += displayRows[index].followID + ":" + displayRows[index].rootID + ":" + (displayRows[index].isFusionRequirements == true ? "1" : "0") + ",";
            }
        }

        //for (var index = 0; index < selectedIndices.length; index++) {
        //    if (this.myGrid.getrowdata(selectedIndices[index]) != undefined)
        //        strIDs = strIDs + this.myGrid.getrowdata(selectedIndices[index]).followID + ":" + this.myGrid.getrowdata(selectedIndices[index]).rootID + ":" + fusionRequirement + ",";
        //}
        if (strIDs != "") {
            strIDs = strIDs.slice(0, strIDs.length - 1); 
            //strIDs = strIDs.substring(0, strIDs.length - 1);
            this.selectedIds = strIDs;
        }
        this.syncType = syncType;
        if (strIDs != "") {
            if (syncType == "1") {
                this.messageBox.Show("Lead Product Synchronization", "Are you sure you want to synchronize the selected components to the lead product component list?", MessageBoxType.OKCancel, MessageBoxIcon.Information, "500", this.numCallback);

            }
            else {
                this.messageBox.Show("Lead Product Synchronization", "Are you sure you want to stop synchronizing the selected components to the lead product component list?", MessageBoxType.OKCancel, MessageBoxIcon.Information, "500", this.numCallback);
            }
        }
        else {
            this.messageBox.Show("Lead Product Synchronization", "Please check at least one component and try again", MessageBoxType.Ok, MessageBoxIcon.Information, "500", this.numCallback);
        }

    }
    DisplaySyncDifferences(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var rootId = "";
        var versionList = "";
        var isFusionRequirements = false; 
        var fusionRequirement = 0;
        id = this.myGrid.getrowdata(selectedIndices).followID;
        rootId = this.myGrid.getrowdata(selectedIndices).rootID;
        versionList = this.myGrid.getrowdata(selectedIndices).rootID;
        isFusionRequirements = this.myGrid.getrowdata(selectedIndices).isFusionRequirements;
        fusionRequirement = isFusionRequirements == true ? 1 : 0;
        //window.open("/Excalibur/Product/LeadProduct/CompareRootOnLeadProduct.asp?ProductID=" + id + "&RootID=" + rootId);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['rootleadproduct', rootId, id, fusionRequirement] } }]);
        modalPopup.show('#externalpagepopup', "1057px", "500px", "Compare Root Lead Product");
        //this.router.navigate(['/rootleadproduct'], { queryParams: { 'rootId': rootId, 'id': id } });
        //window.open("rootleadproduct?rootId=" + rootId + "&id=" + id);
    }
    ViewLeadExclusions(id: any): void {
        var url = "";
        var title = "";
        var height = 900;
        var width = 650;
        //url = "/Excalibur/product/leadproduct/ViewExclusions.asp?PMID=" + id + "&app=PulsarPlus";
        //title = "View Excluded Components";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['leadproductexclusion',  id] } }]);
        modalPopup.show('#externalpagepopup', "900px", "550px", "View Excluded Components");
    }

    ViewLeadExceptions(id: any): void {
        var url = "";
        var title = "";
        var height = 900;
        var width = 650;
        //url = "/Excalibur/product/leadproduct/ViewExceptions.asp?PMID=" + id + "&app=PulsarPlus";
        //title = "View Usage Exceptions";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['viewExceptions', id] } }]);
        modalPopup.show('#externalpagepopup', "1000px", "500px", "View Usage Exceptions");
    }

    LeadProductAddExclusions(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var rootId = "";
        var versionList = "";
        var url = "";
        var title = "";
        var height = 900;
        var width = 650;
        var isFusionRequirements = false;
        id = this.myGrid.getrowdata(selectedIndices).followID;
        rootId = this.myGrid.getrowdata(selectedIndices).rootID;
        versionList = this.myGrid.getrowdata(selectedIndices).leadProductSynchronizationId;
        isFusionRequirements = this.myGrid.getrowdata(selectedIndices).isFusionRequirements;
        //url = "/Excalibur/product/leadproduct/Exclusions.asp?ProductID=" + id + "&RootID=" + rootId + "&VersionIDList=" + versionList + "&app=PulsarPlus";
        //title = "Lead Product Add Exclusions";
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['leadproductexclusionmain', id, rootId, versionList, isFusionRequirements] } }]);
        modalPopup.show('#externalpagepopup', "750px", "550px", "Lead Product Deliverable Exclusions");
    }

    LeadProductEditExceptions(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var rootId = "";
        var versionList = "";
        var url = "";
        var title = "";
        var height = 900;
        var width = 650;
        var isFusionRequirements = 0;
        id = this.myGrid.getrowdata(selectedIndices).followID;
        rootId = this.myGrid.getrowdata(selectedIndices).rootID;
        versionList = this.myGrid.getrowdata(selectedIndices).leadProductSynchronizationId //+ '_' + (this.myGrid.getrowdata(selectedIndices).isFusionRequirements==true?'1':'0');
        isFusionRequirements = this.myGrid.getrowdata(selectedIndices).isFusionRequirements == true ? 1 : 0;
        url = "/Excalibur/product/leadproduct/Exceptions.asp?ID=" + id + "&RootID=" + rootId + "&VersionIDList=" + versionList + "&FusionRequirements=" + isFusionRequirements + "&app=PulsarPlus";
        title = "Lead Product Edit Exceptions";
        showPopup(url, title, height, width);
    }

    SyncRoot(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var rootId = "";
        var url = "";
        var title = "";
        var height = 900;
        var width = 650;
        //url = "/Excalibur/Product/LeadProduct/Sync.asp?SyncList=" + id + ":" + rootId + "&app=PulsarPlus";
        //title = "Sync Root";
        //showPopup(url, title, height, width);
        var isFusionRequirements = "0";
        isFusionRequirements = this.myGrid.getrowdata(selectedIndices).isFusionRequirements == true ? "1" : "0";
        this.leadProductSynchronizationViewModel = new LeadProductSynchronizationViewModel();
        this.leadProductSynchronizationViewModel.product = this.myGrid.getrowdata(selectedIndices).followID + ":" + this.myGrid.getrowdata(selectedIndices).rootID + ":" + isFusionRequirements;
        //this.leadProductSynchronizationViewModel.isFusionRequirements = isFusionRequirements;
        this.http.post(this.location.prepareExternalUrl("/product/Product/SyncSelectedProducts"), this.leadProductSynchronizationViewModel).subscribe(x => {
            if (x.json() == true)
                this.LeadProductSynchronizationCallback('1');
        });
    }
    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }
    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
    }
    getLeadProductSynchronization(paginationInfo: PaginationModel, strProductId: string = '') {
        this.myGrid.showdefaultloadelement(true);
        this.service.getLeadProductSynchronization(paginationInfo, strProductId).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.currentUserID = result.json() != undefined && result.json().length > 0 ? result.json()[0].userId : this.currentUserID;
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLeadProductSynchronization(paginationInfo, this.leadProductId);
        this.myGrid.clearselection();
        //this.getProducts(paginationInfo);

    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLeadProductSynchronization(paginationInfo, this.leadProductId);

    }
    private leadProductId: string = ''
    ExpandCallbackFn(strSection: any, strProdID: any) {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.leadProductId = strProdID;
        this.getLeadProductSynchronization(paginationInfo, strProdID);
        this.service.getLeadProductListSynchronization(strProdID).subscribe(result => {
            this.allNewProducts = result.json();
        });
    }
    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLeadProductSynchronization(paginationInfo, this.leadProductId);
    }


    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLeadProductSynchronization(paginationInfo, this.leadProductId);
        this.service.getLeadProductListSynchronization(this.leadProductId).subscribe(result => {
            this.allNewProducts = result.json();
        });
        this.myMenu.createComponent(this.MenuSettings);
    }
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '110px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row

    };
    public lastRootId: any;
    public lastFollowerId: any;
    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='jqx-anchor-hover' > " + value + "</a>";
        //element.addClass('lead-product-sync-ivory');
        return element[0].outerHTML;
    };
}

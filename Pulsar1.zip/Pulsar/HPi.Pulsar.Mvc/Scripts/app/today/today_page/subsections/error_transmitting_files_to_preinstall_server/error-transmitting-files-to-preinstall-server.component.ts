﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ErrorTransmittingFilesToPreinstallService } from './error-transmitting-files-to-preinstall-server.service';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { Location } from '@angular/common';

@Component({
    selector: 'expired-pilot-schedule-dates',
    templateUrl:'./error-transmitting-files-to-preinstall-server.component.html',
    styles: [`
.hideSection
{
    display:none;
}
`],
    providers: [ErrorTransmittingFilesToPreinstallService]
})

export class ErrorTransmittingFilesToPreinstallServiceComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public enableCreateVersionMenu: boolean = false;
    public enableRestartFiletransferMenu: boolean = false;
    public selectedRowIndex: string;

    errorTransmittingFilesToPreinstallCallback(strID: any) {
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.getErrorTransmittingFilestoPreinstallServer();
            //}
        }
    }

    constructor(private http: Http, private service: ErrorTransmittingFilesToPreinstallService, private _ngZone: NgZone, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.errorTransmittingFilesToPreinstallCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = false;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'rootId', map: 'rootId' },
            { name: 'workflowStatus', map: 'workflowStatus' },
            { name: 'name', map: 'name' },
            { name: 'version', map: 'version' },
            { name: 'status', map: 'status' },
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: '20%' },
            { text: 'Component', filtertype: 'input', datafield: 'name', width: '30%' },
            { text: 'Version', filtertype: 'input', datafield: 'version', width: '20%' },
            { text: 'Issue', filtertype: 'input', datafield: 'status', width: '30%' },
            { text: 'RootId', hidden: true, filtertype: 'input', datafield: 'rootId', width: 212 },
            { text: 'WorkflowStatus', hidden: true, filtertype: 'number', datafield: 'workflowStatus', width: 212 },
        ];
    }

    getErrorTransmittingFilestoPreinstallServer() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getErrorTransmittingFilestoPreinstallServer().subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '180px', height: '130px', mode: 'popup', autoOpenPopup: false,

    };

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        this.getErrorTransmittingFilestoPreinstallServer();
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick", this.selectedRowIndex);
        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        //rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        //console.log(rowIndex);
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        console.log(gridData);
        console.log(menuItem, gridData.rootId); // Get the Menu Item name            
        switch (menuItem) {
            case "Contact Support":
                this.showSupportPage(1, 59, gridData.id, 0);
                break;
            case "Create New Version...":
                this.cloneVersion(gridData.rootId, gridData.id);
                break;
            case "Restart File Transfer...":
                this.releaseVersion(gridData.rootId, gridData.id, 1);
                break;
            case "Cancel File Transfer":
                this.transmissionRetry(6, gridData.id);
                break;
            case "Properties":                
                this.displayVersion(1, gridData.rootId, gridData.id);                
                break;
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            console.log(data);
            if (data != null) {
                console.log("workflowStatus", data.workflowStatus);
                if (data.workflowStatus == 3) {
                    this.enableCreateVersionMenu = false;
                    this.enableRestartFiletransferMenu = true;
                }
                else {
                    this.enableCreateVersionMenu = true;
                    this.enableRestartFiletransferMenu = false;
                }
            }
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
        //}
    }

    showSupportPage(appId: number, categoryId: number, versionId: number, admin: number): void {        
        var CategoryParam = "";
        var RequiredText = "";        
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
      
        if (categoryId != 0)
            CategoryParam = "&cboCategory=" + categoryId;

        if (versionId != 0)
            RequiredText = "&txtRequired=" + "Component Version ID: " + versionId;
            var required = "Component Version ID: " + versionId;

        if (admin == 1) {
            url = "/excalibur/support/default.asp?app=PulsarPlus";
        }
        else if (appId != 0) {
            url = this.location.prepareExternalUrl("/product/Product/GetSupportProjects/" + appId + "/" + categoryId + "/" + required);
            //url = "/excalibur/Support/Support.asp?cboProject=" + appId + CategoryParam + "&app=PulsarPlus" + RequiredText ;
        }
        else {
            url = "/excalibur/Support/Support.asp?app=PulsarPlus";
        }
        title = "Mobile Tools Support";
        showPopup(url, title, height, width);
    }

    cloneVersion(rootId: number, versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/WizardFrames.asp?rootID=" + rootId + "&CloneID=" + versionId + "&CloneType=2" + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
        // window reload
    }

    releaseVersion(rootId: number, versionId: number, action: number): void {
        var url = "";
        var title = "";
        var height = "550px";
        var width = "90%";
        url = "/excalibur/Release.asp?ID=" + versionId + "&Action=" + action + "&app=PulsarPlus";
        title = "Component Workflow";
        //showPopup(url, title, height, width);
        adjustableShowPopupSecondlevel(url, title, height, width, "790px");
    }

    transmissionRetry(status: number, id: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/MobileSE/Today/UpdateBitTransferStatus.asp?Status=" + status + "&ID=" + id + "&app=PulsarPlus";
        
        if (status == 6) {
            title = "Cancel File Transfer";
            if (confirm("This component can not be added to the Preinstall images unless this transfer completes.  Are you sure you want to cancel this transfer?")) {
                showPopup(url, title, height, width);                
            }
        }
        else {
            title = "Retry File Transfer";
            showPopup(url, title, height, width);
        }
        //window reload
       
    }

    displayVersion(action: number, rootId: number, versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/WizardFrames.asp?Type=1&RootID=" + rootId + "&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
        //window reload
    }
}

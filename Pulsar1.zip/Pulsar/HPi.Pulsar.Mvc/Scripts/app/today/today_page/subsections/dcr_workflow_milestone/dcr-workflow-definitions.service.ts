﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/10/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/05/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="dcr-workflow-definitions.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class DCRWorkflowDefinitionsService {
    constructor(private http: Http, private location: Location) {
    }

    getDcrWorkflowDefinitions() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetDcrWorkflowDefinitions'))
    }

    getImpersonateName() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
    }

    postDCRWorkflowCompleteService(parameters: URLSearchParams) {    
        //var url = "/Excalibur/MobileSE/Today/DCRUpdateWorkflowData.aspx";
        var url = this.location.prepareExternalUrl('/today/TodayPage/UpdateDCRWorkflow');
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        return this.http.post(url, parameters);    
    }
}

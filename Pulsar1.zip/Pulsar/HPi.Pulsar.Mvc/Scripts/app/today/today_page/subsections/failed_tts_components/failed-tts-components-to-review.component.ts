﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/10/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 08/16/2017
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="failed-tts-components-to-review.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router'
import { FailedTTSComponentsToReviewService } from './failed-tts-components-to-review.service';
import { FailedTTSComponentsToReviewViewModel } from './failed-tts-components-to-review.viewmodel';

@Component({
    selector: 'failed-tts-components-to-review',
    templateUrl:'./failed-tts-components-to-review.component.html'
})

export class FailedTTSComponentsToReviewComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public enablemenu: boolean = true;
    public failedTtsComponent: FailedTTSComponentsToReviewViewModel[];
    UpdatePanelStatusCallback(result) {
        if (typeof (result) != "undefined") {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: FailedTTSComponentsToReviewService, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            UpdatePanelStatusCallbackFn: (value) => this.UpdatePanelStatusCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'rootId', map: 'rootId' },
            { name: 'id', map: 'id', type: 'number'  },
            { name: 'category', map: 'category', type: 'string'  },
            { name: 'vendor', map: 'vendor', type: 'string'  },
            { name: 'component', map: 'component', type: 'string'  },
            { name: 'version', map: 'version', type: 'string'  },
            { name: 'revision', map: 'revision', type: 'string'  },
            { name: 'pass', map: 'pass', type: 'string'  },
            { name: 'partNumber', map: 'partNumber', type: 'string'  },
            { name: 'modelNumber', map: 'modelNumber', type: 'string'  },
            { name: 'reportPath', map: 'reportPath', type: 'string'  }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'RootId', columngroup: 'WWANEngineerAlerts',
                datafield: 'rootId', hidden: true
            },
            {
                text: 'ID', columngroup: 'WWANEngineerAlerts',
                datafield: 'id', width: '7%', filtertype: 'number', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Category', columngroup: 'WWANEngineerAlerts',
                datafield: 'category', width: '7%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Vendor', columngroup: 'WWANEngineerAlerts',
                datafield: 'vendor', width: '8%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Component', columngroup: 'WWANEngineerAlerts',
                datafield: 'component', cellsalign: 'left', align: 'left', width: '30.5%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'HW', columngroup: 'WWANEngineerAlerts',
                datafield: 'version', cellsalign: 'left', align: 'left', width: '7%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'FW', columngroup: 'WWANEngineerAlerts',
                datafield: 'revision', cellsalign: 'left', align: 'left', width: '7%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Rev', columngroup: 'WWANEngineerAlerts',
                datafield: 'pass', cellsalign: 'left', align: 'left', width: '12%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Part', columngroup: 'WWANEngineerAlerts',
                datafield: 'partNumber', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Model', columngroup: 'WWANEngineerAlerts',
                datafield: 'modelNumber', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ReportPath', columngroup: 'WWANEngineerAlerts',
                datafield: 'reportPath', hidden: true, cellsrenderer: this.cellsrenderer
            }
        ];
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
    };

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                if (data.reportPath != "") {
                    this.enablemenu = true;
                }
                else {
                    this.enablemenu = false;
                }
            }
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
    }

    getFailedTtsComponentsToReview() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getFailedTtsComponentsToReview().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getFailedTtsComponentsToReview();
        this.myMenu.createComponent(this.MenuSettings);
    }

    reloadGrid(): void {
        this.getFailedTtsComponentsToReview();
    }

    //Menu Code –  menu item click to get the Grid row data.
    UpdatePanelStatus(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";        
        id = this.myGrid.getrowdata(selectedIndices).id;        
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['updatewwanttsstatus', id] } }]);
        modalPopup.show('#externalpagepopup', "70%", "415px", "Update WWAN TTS Status");
    }

    DisplayPanelReport(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var url = "";
        id = this.myGrid.getrowdata(selectedIndices).id;
        url = this.myGrid.getrowdata(selectedIndices).reportPath;
        DisplayPanelTestReport(url);
    }

    DisplayVersionDetails(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var url = "";
        var title = "";
        var height = 650;
        var width = 750;
        id = this.myGrid.getrowdata(selectedIndices).id;
        url = "/Excalibur/query/DeliverableVersionDetails.asp?ID=" + id + "&app=" + "PulsarPlus";
        title = "Component Details";
        showPopup(url, title, height, width);
    }
   
    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<span id='PanelFailed" + rowdata.id + "' class='jqx-anchor-hover jqxgrid-cellrender-font'/> " + value + " </span>";
        return element[0].outerHTML;
    };
}

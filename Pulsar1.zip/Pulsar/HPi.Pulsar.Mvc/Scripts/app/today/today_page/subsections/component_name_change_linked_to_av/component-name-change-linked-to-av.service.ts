﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Vignesh.T
// Created          : 05/09/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="component-name-change-linked-to-av.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';

@Injectable()
export class ComponentNameChangeLinkedToAVService {
    constructor(private http: Http, private location: Location) {
    }

    getComponentNameChangeLinkedToAV() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetComponentNameChangeLinkedToAV'))
    }

    getImpersonateName() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
    }

    postUpdateAVs(parameters: URLSearchParams) {
        var url = this.location.prepareExternalUrl('/today/TodayPage/UpdateAV');
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        return this.http.post(url, parameters);
    }
}
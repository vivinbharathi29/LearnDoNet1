﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { FunctionalTestUpcomingReleaseService } from './functional-test-upcoming-releases.service';
import { ActivatedRoute, Router } from '@angular/router';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'functional-test-upcoming-release',
    templateUrl:'./functional-test-upcoming-releases.component.html',
    styles: [`
.hideSection
{
    display:none;
}
`],
    providers: [FunctionalTestUpcomingReleaseService]
})

export class FunctionalTestUpcomingReleaseComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public enablemenu: boolean = false;
    public selectedRowIndex: string;

    functionalTestUpcomingReleaseCallback(strID: any) {
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.getFunctionalTestUpcomingReleases();
            //}
        }
    }

    constructor(private http: Http, private service: FunctionalTestUpcomingReleaseService, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.functionalTestUpcomingReleaseCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = false;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'rootID', map: 'rootID' },
            { name: 'component', map: 'component' },
            { name: 'developer', map: 'developer' },
            { name: 'currentWorkflow', map: 'currentWorkflow' },
            { name: 'team', map: 'team' },
            { name: 'transferPath', map: 'transferPath' },
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: '6%' },
            { text: 'Component', filtertype: 'input', datafield: 'component', width: '36%' },
            { text: 'Developer', filtertype: 'input', datafield: 'developer', width: '20%' },
            { text: 'Current Workflow Step', filtertype: 'input', datafield: 'currentWorkflow', width: '20%' },
            { text: 'Team', filtertype: 'input', datafield: 'team', width: '18%' },
            { text: 'RootID', filtertype: 'input', hidden: true, datafield: 'rootID', width: 170 },
            { text: 'TransferPath', filtertype: 'input', hidden: true, datafield: 'transferPath', width: 170 }
        ];
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '150px', height: '160px', mode: 'popup', autoOpenPopup: false,

    };

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        this.myGrid.showdefaultloadelement(true);
        this.getFunctionalTestUpcomingReleases();
    }

    getFunctionalTestUpcomingReleases()
    {
        this.myGrid.showdefaultloadelement(true);
        this.service.getFunctionalTestUpcomingReleases().subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("menu itemclick", this.selectedRowIndex);
        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        console.log(gridData);
        console.log(menuItem, gridData.rootId); // Get the Menu Item name    

        switch (menuItem) {
            case "Release Version...":
                this.releaseVersion(gridData.rootId, gridData.id, 1);
                break;
            case "Fail Version...":
                this.releaseVersion(gridData.rootId, gridData.id, 2);
                break;
            case "Display Changes":
                //this.displayChanges(gridData.id);
                this.displayChanges(gridData.rootId, gridData.id);
                break;
            case "Download":
                this.getVersion(gridData.id);
                break;
            case "Update Schedule...":
                this.updateSchedule(gridData.id);
                break;
            case "Properties":
                this.displayVersion(1, gridData.rootId, gridData.id);
                break;
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            console.log(data);
            if (data != null) {
                if (data.transferPath != "") {
                    this.enablemenu = false;
                }
                else {
                    this.enablemenu = true;
                }
            }
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
    }

    releaseVersion(rootId: number, versionId: number, action: number): void {
        var url = "";
        var title = "";
        var height = "550px";
        var width = "90%";
        url = "/excalibur/Release.asp?Action=" + action + "&ID=" + versionId + "&app=PulsarPlus"
        title = "Component Workflow";
        //showPopup(url, title, height, width);
        adjustableShowPopupSecondlevel(url, title, height, width, "790px");
    }

    displayChanges(rootId: number, versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
       // url = "/excalibur/Properties/FT.asp?ID=" + versionId + "&app=PulsarPlus";
        //title = "Deliverable Changes";
       // showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['ft', rootId, versionId] } }]);
        modalPopup.show('#externalpagepopup', "40%", "500px", "Deliverable Changes");
    }

    getVersion(versionId: number): void {
        window.open("/excalibur/FileBrowse.asp?ID=" + versionId);
    }

    updateSchedule(versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/deliverable/schedule.asp?ID=" + versionId + "&app=PulsarPlus";
        title = "Update Schedule";
        //showPopup(url, title, height, width);
        UpdateScheduleExcalibur(versionId);
    }

    displayVersion(action: number, rootId: number, versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/WizardFrames.asp?Type=1&RootID=" + rootId + "&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
        //call back reload.
    }
}

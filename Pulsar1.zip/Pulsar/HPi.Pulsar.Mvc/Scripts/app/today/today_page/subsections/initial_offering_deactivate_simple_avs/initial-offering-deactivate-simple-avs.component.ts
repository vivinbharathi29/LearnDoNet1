﻿import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { InitialOfferingDeactivateSimpleAVsService } from './initial-offering-deactivate-simple-avs.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';

@Component({
    selector: 'initial-offering-deactivate-simple-avs',
    templateUrl:'./initial-offering-deactivate-simple-avs.component.html',
    providers: [InitialOfferingDeactivateSimpleAVsService]
})

export class InitialOfferingDeactivateSimpleAVsComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public avsNotRequested;
    public title: string;
    constructor(http: Http, private service: InitialOfferingDeactivateSimpleAVsService)//,location:Location)
    {
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.datafields = [
            { name: 'productVersion', map: 'productVersion' },
            { name: 'brand', map: 'brand' },
            { name: 'componentID', map: 'componentID' },
            { name: 'name', map: 'name' },
            { name: 'avNo', map: 'avNo' },
            { name: 'gpgDescription', map: 'gpgDescription' },
            { name: 'featureCategory', map: 'featureCategory' }
        ];
        this.jqxGridConfig.columns = [
            {
                text: 'Product Version',
                datafield: 'productVersion', filtertype: 'input',width:'12%'
            },
            {
                text: 'Brand',
                datafield: 'brand', filtertype: 'input', width: '15%'
            },
            {
                text: 'Component ID',
                datafield: 'componentID', filtertype: 'input', width: '10%'
            },
            {
                text: 'Name',
                datafield: 'name', filtertype: 'input', width: '23%'
            },
            {
                text: 'AV No',
                datafield: 'avNo', filtertype: 'input', width: '10%'
            },
            {
                text: 'GPG Description',
                datafield: 'gpgDescription', filtertype: 'input', width: '10%'
            },
            {
                text: 'Feature Category',
                datafield: 'featureCategory', filtertype: 'input', width: '20%'
            }
        ];
    }

    getInitialOfferingDeactivateSimpleAVs() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getInitialOfferingDeactivateSimpleAVs().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getInitialOfferingDeactivateSimpleAVs();
        this.service.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
        });
    }
}

﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router'
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { ComponentsAwaitingFinalApprovalService } from './components-awaiting-final-approval.service';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';


import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
declare function EditCommodityStatusSignoff(strProductDeliverableIDs: any, strProductID: any, strVersionID: any, strProductDeliverableReleaseIDs: any, IsPulsarProduct: any, strSource: any);
@Component({
    selector: 'components-awaiting-final-approval',
    templateUrl:'./components-awaiting-final-approval.component.html',
})

export class ComponentsAwaitingFinalApprovalComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    private mbp: MessageBoxButton;
    public selectedRowIndex: string;

    callFromOutside(ProductDeliverableID, ProductDeliverableReleaseID, Status) {
        if (typeof (Status) != "undefined") {
            if (Status == "Leverage" || Status.substr(5) == "Leverage" || Status == "QComplete" || Status.substr(5) == "QComplete" || Status == "Dropped" || Status.substr(5) == "Dropped" || Status == "QHold" || Status.substr(5) == "QHold" || Status == "Fail" || Status.substr(5) == "Fail" || Status == "Validated" || Status.substr(5) == "Validated") {
                this.reloadGrid();
            } else
            {
                this.reloadGrid();
            }
        }
    }

    MultiDeveloperSignoffCallback(strID) {
        if (typeof (strID) != "undefined") {
            if (strID > 0) {
                console.log(strID);
                this.reloadGrid();
            }
        }
    }

    clickHandler() {
    }
   
    constructor(http: Http, private service: ComponentsAwaitingFinalApprovalService, private messageBox: MessageBox, private _ngZone: NgZone, private router: Router) {

        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef']= {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.MultiDeveloperSignoffCallback(value),
            EditCommodityStatus2CallbackFn: (ProductDeliverableID, ProductDeliverableReleaseID, Status) => this.callFromOutside(ProductDeliverableID, ProductDeliverableReleaseID, Status),
            component: this
        };
       
        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.width = 1078;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
       

        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id',type:'number' },
            { name: 'productId', map: 'productId' },
            { name: 'productDeliverableReleaseId', map: 'productDeliverableReleaseId' },
            { name: 'versionId', map: 'versionId' },
            { name: 'product', map: 'product' },
            { name: 'status', map: 'status' },
            { name: 'vendor', map: 'vendor' },
            { name: 'name', map: 'name' },
            { name: 'version', map: 'version' },
            { name: 'revision', map: 'revision' },
            { name: 'pass', map: 'pass' },
            { name: 'modelNumber', map: 'modelNumber' },
            { name: 'partNumber', map: 'partNumber' },
            { name: 'isPulsarProduct', map: 'isPulsarProduct' },
            { name: 'release', map: 'release' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: "8%", cellsrenderer: this.cellsrenderer },
            { text: 'productId', filtertype: 'input', datafield: 'productId', hidden: true, width: "8%" },
            { text: 'productDeliverableReleaseId', filtertype: 'input', datafield: 'productDeliverableReleaseId', hidden: true, width: "8%" },
            { name: 'versionId', map: 'versionId', hidden: true },
            { name: 'isPulsarProduct', map: 'isPulsarProduct', hidden: true },
            { text: 'Product', filtertype: 'input', columngroup: 'ProductAlerts', datafield: 'product', cellsalign: 'left', align: 'left', width: "8%", cellsrenderer: this.cellsrenderer },
            { text: 'Release', filtertype: 'input', datafield: 'release', cellsalign: 'left', width: "8%", cellsrenderer: this.cellsrenderer },
            { text: 'Status', columntype: 'input', datafield: 'status', width: "7%" , cellsrenderer: this.cellsrenderer },
            { text: 'Vendor', filtertype: 'input', datafield: 'vendor', cellsalign: 'left', width: "5%", cellsrenderer: this.cellsrenderer },
            { text: 'Component', filtertype: 'input', datafield: 'name', cellsalign: 'left', width: "40%" , cellsrenderer: this.cellsrenderer },
            { text: 'HW', filtertype: 'input', datafield: 'version', cellsalign: 'left', width: "5%" , cellsrenderer: this.cellsrenderer },
            { text: 'FW', filtertype: 'input', datafield: 'revision', cellsalign: 'left', width: "5%", cellsrenderer: this.cellsrenderer},
            { text: 'Rev', filtertype: 'input', datafield: 'pass', cellsalign: 'left', width: "23%" , cellsrenderer: this.cellsrenderer },
            { text: 'Model', filtertype: 'input', datafield: 'modelNumber', cellsalign: 'left', width: "15%", cellsrenderer: this.cellsrenderer },
            { text: 'Part', filtertype: 'input', datafield: 'partNumber', cellsalign: 'left', width: "15%", cellsrenderer: this.cellsrenderer }
           
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'productDeliverableReleaseId': FilterColumnTypeEnum.Number,
            'productId': FilterColumnTypeEnum.Number,
            'versionId': FilterColumnTypeEnum.Number,
            'product': FilterColumnTypeEnum.String,
            'status': FilterColumnTypeEnum.String,
            'vendor': FilterColumnTypeEnum.String,
            'name': FilterColumnTypeEnum.String,
            'version': FilterColumnTypeEnum.String,
            'revision': FilterColumnTypeEnum.String,
            'pass': FilterColumnTypeEnum.String,
            'modelNumber': FilterColumnTypeEnum.String,
            'partNumber': FilterColumnTypeEnum.String,
            'isPulsarProduct': FilterColumnTypeEnum.Boolean,
            'release': FilterColumnTypeEnum.String
        }
    }

    callbackfunction() {
    window['angularComponent'].zone.run(() => {
        this.runThisFunctionFromOutside();
    });
    }
    runThisFunctionFromOutside() {
    }
    

    MultiHardwareSignoff(strValue)
    {   
        var strProductDeliverableIDs = "";
        var strProductDeliverableReleaseIDs = "";
        var i = 0;
        var blnMulti = false;
        var strProductID = "";
        var strVersionID = "";
        var IsPulsarProduct = "False";
        var count = 0;

        var index: number;
        var productDeliverableIds: string;
        var chkIDs ="";
        productDeliverableIds = "";
        var selectedIndices = this.myGrid.selectedrowindexes();

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = this.myGrid.getrows().length;
        var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
        var endIndex = startIndex + paginationInfo.PageSize - 1;
        if (displayRowsLength < paginationInfo.PageSize) {
            endIndex = startIndex + displayRowsLength - 1;
        }
        if (typeof (selectedIndices.length) != "undefined") {
            for (index = startIndex; index <= endIndex; index++) {
                if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                    strProductID += displayRows[index].productId + ",";
                    strVersionID += displayRows[index].versionId + ",";
                    strProductDeliverableIDs += displayRows[index].id + ",";
                    strProductDeliverableReleaseIDs += displayRows[index].productDeliverableReleaseId + ",";
                    chkIDs += displayRows[index].id + "_" + displayRows[index].productDeliverableReleaseId + ",";
                    count++;
                }
            }
            if (count > 1)
                blnMulti = true;
        }
        else
        {
        }
        strProductID = strProductID.slice(0, strProductID.length - 1); 
        strVersionID = strVersionID.slice(0, strVersionID.length - 1);
        strProductDeliverableIDs = strProductDeliverableIDs.slice(0, strProductDeliverableIDs.length - 1);
        chkIDs = chkIDs.slice(0, chkIDs.length - 1);
        strProductDeliverableReleaseIDs = strProductDeliverableReleaseIDs.slice(0, strProductDeliverableReleaseIDs.length - 1);// Remove last characters: comma 
        

        if (strProductDeliverableIDs == "" && strProductDeliverableReleaseIDs == "") {
            this.messageBox.Show("Components Awaiting Final Approval", "You must select the components you want to edit first.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
        } else {
            if (blnMulti) {
                var TodayPageSection = "EditCommodityStatusSignoff";
                this.router.navigate([{ outlets: { 'externalpopupWindow': ['updateorproductqualificationpulsar', chkIDs,0,0,0,0,0] } }]);
                modalPopup.show('#externalpagepopup', "80%", "480px", "Patch Update Qualification Status");
            }
            else {
               this.EditCommodityStatusSignoff(strProductDeliverableIDs, strProductID, strVersionID, strProductDeliverableReleaseIDs, IsPulsarProduct, 2);
            }
        }
    }

    EditCommodityStatusSignoff(ProductDeliverableID, ProdID, VersionID, ProductDeliverableReleaseID, IsPulsarProduct, strSource) {
    
    var strID;
    var url;
    var title;
    var height;
    var width;
    title = "Qualification Status";
    height = 750;// $(window).height() * (30 / 100);
    width = 800;// $(window).width() * (30 / 100);

    if (strSource == 1) {

        this.router.navigate([{ outlets: { 'externalpopupWindow': ['qualstatus', ProdID, VersionID, ProductDeliverableReleaseID, IsPulsarProduct, 'EditCommodityStatusSignoff'] } }]);
        modalPopup.show('#externalpagepopup', "60%", "550px", "Qualification Status");
    }
    else {

        this.router.navigate([{ outlets: { 'externalpopupWindow': ['qualstatus', ProdID, VersionID, ProductDeliverableReleaseID, IsPulsarProduct, 'EditCommodityStatusSignoff'] } }]);
        modalPopup.show('#externalpagepopup', "60%", "550px", "Qualification Status");
    }
}
   


    numCallback = (response: MessageBoxButton): void => {
        
        this.mbp = response;
    }

    

    getComponentsAwaitingFinalApproval(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getComponentsAwaitingFinalApprovals(paginationInfo).subscribe(result => {
            
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
        //this.getProducts(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
    }

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
    }

    reloadGrid(): void {
        this.myGrid.clearselection();
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingFinalApproval(paginationInfo);
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {

        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='jqx-anchor-hover'  href='javascript:EditCommodityStatusSignoff(" + rowdata.id + "," + rowdata.productId + "," + rowdata.versionId + "," + rowdata.productDeliverableReleaseId + "," + rowdata.isPulsarProduct + "," + 1 + ");' /> " + value + "</a>";
        return element[0].outerHTML;

    };

    onRowClick(event: any): boolean {
        if (!event.args.rightclick) {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                var strID;
                var url;
                var title;
                var height;
                var width;
                title = "Qualification Status";
                height = 750;// $(window).height() * (30 / 100);
                width = 800;// $(window).width() * (30 / 100);
                var strSource =1
                if (strSource == 1) {
                    this.router.navigate([{ outlets: { 'externalpopupWindow': ['qualstatus', data.productId, data.versionId, data.productDeliverableReleaseId, data.isPulsarProduct, 'EditCommodityStatusSignoff'] } }]);
                    modalPopup.show('#externalpagepopup', "60%", "550px", "Qualification Status");
                }
                else {
                    this.router.navigate([{ outlets: { 'externalpopupWindow': ['qualstatus', data.productId, data.versionId, data.productDeliverableReleaseId, data.isPulsarProduct, 'EditCommodityStatusSignoff'] } }]);
                    modalPopup.show('#externalpagepopup', "60%", "550px", "Qualification Status");
                }
            }

            return false;
        }
    }
}
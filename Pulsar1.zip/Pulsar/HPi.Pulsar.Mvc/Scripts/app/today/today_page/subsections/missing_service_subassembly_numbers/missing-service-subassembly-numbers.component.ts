﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { MissingServiceSubassemblyNumberService } from './missing-service-subassembly-numbers.service';
import { MissingServiceSubassemblyNumberViewModel } from './missing-service-subassembly-numbers.viewmodel';
import { Router, ActivatedRoute, Params } from '@angular/router'
@Component({
    selector: 'missing-subassembly-numbers-legacy',
    templateUrl:'./missing-service-subassembly-numbers.component.html'
})

export class MissingServiceSubassemblyNumberComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public missingServiceSubassemblyNumber: MissingServiceSubassemblyNumberViewModel[];    
    public userId: number = 0;
    public selectedRowIndex: string;
    ShowCommodityPropertiesCallFromOutside(strID) {
        
        //if (typeof (strID) != "undefined") {
            //if (strID > 0) {             
                //console.log(strID);
                this.pageReload();

            //}
        //}

    }
    constructor(http: Http, private service: MissingServiceSubassemblyNumberService, private _ngZone: NgZone, private activatedRoute: ActivatedRoute, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.ShowCommodityPropertiesCallFromOutside(value),
            component: this
        };
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            //this.userId = params['UserId'];
        });
        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.width = 800;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'rootId', map: 'rootId' },
            { name: 'product', map: 'product' },
            { name: 'component', map: 'component' },
            { name: 'productId', map: 'productId' },
            { name: 'id', map: 'id' },
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'LegacyAV', filtertype: 'number',
                datafield: 'rootId', cellsrenderer: this.cellsrenderer, width: '10%'
            },
            {
                text: 'Product', columngroup: 'LegacyAV',
                datafield: 'product', cellsalign: 'left', align: 'left', width: '20%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Component', columngroup: 'LegacyAV',
                datafield: 'component', cellsalign: 'left', align: 'left', width: '68%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'productId', columngroup: 'LegacyAV',
                datafield: 'productId', cellsalign: 'left', align: 'left', filtertype: 'input', hidden: true
            },
            {
                text: 'id', columngroup: 'LegacyAV',
                datafield: 'id', cellsrenderer: this.cellsrenderer, hidden: true
            },
        ];

        this.jqxGridConfig.columnTypes = {
            'rootId': FilterColumnTypeEnum.Number,
            'product': FilterColumnTypeEnum.String,
            'component': FilterColumnTypeEnum.String,
        }
    }


    getMissingServiceSubassemblyNumber(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMissingServiceSubassemblyNumber(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.userId = result.json()[0].userId;
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();           
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingServiceSubassemblyNumber(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingServiceSubassemblyNumber(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingServiceSubassemblyNumber(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingServiceSubassemblyNumber(paginationInfo);
    }

    pageReload(): void {
        this.myGrid.clearselection();
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingServiceSubassemblyNumber(paginationInfo);
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var id = data.productVersionId;
            var rootId = data.rootId;
            var productId = data.productId;
            var userId = this.userId;
            var index: number;
            var selectedIds: string;
            selectedIds = "";           
            var selectedIndices = this.myGrid.selectedrowindexes();
            //for (index = 0; index < selectedIndices.length; index++) {
            //    selectedIds += this.myGrid.getrowdata(index).id + ",";
            //}

            var paginationInfo: PaginationModel;
            paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
            var displayRows = this.myGrid.getdisplayrows();
            var displayRowsLength = this.myGrid.getrows().length;
            var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
            var endIndex = startIndex + paginationInfo.PageSize - 1;
            if (displayRowsLength < paginationInfo.PageSize) {
                endIndex = startIndex + displayRowsLength - 1;
            }
            for (index = startIndex; index <= endIndex; index++) {
                if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                    selectedIds += displayRows[index].id + ",";
                }
            }

            selectedIds = selectedIds.slice(0, selectedIds.length - 1);
            // var url = "/Excalibur/Deliverable/Commodity/SubAssembly.asp?ProductID=" + prodid + "&RootID=" + rootid + "&IDList=" + selectedid + "&CurrentUserID=" + userid + "&VersionID=0&TodayPageSection=1&app=" + "PulsarPlus";
            var url = this.location.prepareExternalUrl("/product/product/GetSubAssembly/" + 0 + "/" + productId + "/" + rootId + "/" + selectedIds);
            var title = "Missing Service Subassembly Numbers";
            var height = 600;
            var width = 820;
            showPopup(url, title, height, width);
            //missingServiceSubassemblynumbers_onclick(productId, rootId, selectedIds, userId);
            //this.pageReload();
        }
        return true;
    }

    cellsrenderer = (row, columnfield, value, defaulthtml, columnproperties, rowdata) => {
        
        //var index: number;
        //var selectedIds: string;
        //selectedIds = "";
        ////this.userId = 2245;
        //var selectedIndices = this.myGrid.selectedrowindexes();
        //for (index = 0; index < selectedIndices.length; index++) {           
        //    selectedIds += this.myGrid.getrowdata(index).id + ", ";
        //}
        //selectedIds = selectedIds.slice(0, selectedIds.length - 2);
        ////return "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:missingServiceSubassemblynumbers_onclick(" + rowdata.productId + " ," + rowdata.rootId + "," + '655316' + "," + this.userId + ");' /> " + value + "</a>";
        //var element = $(defaulthtml);
        //element[0].innerHTML = "<a style='height:16px;width:16px;' class='jqx-anchor-hover' href='javascript:missingServiceSubassemblynumbers_onclick(" + rowdata.productId + " ," + rowdata.rootId + "," + '655316' + "," + this.userId + ");' /> " + value + "</a>";
        //return element[0].outerHTML;
    };
}

// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 06/02/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="today-page.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response,URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { pagination } from '../../../../shared/pagination-model.model';
import { ListSortDirection } from '../../../../shared/listsortdirection';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
@Injectable()
export class MissingAVMarketingDataService {
    constructor(private http: Http, private location: Location) { 
	
	}
			
    getMissingAVMarketingDataService(paginationInfo:PaginationModel)
	{
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetMissingAVMarketingData'), JSON.stringify(paginationInfo), options);
    } 

    getMissingAVMarketingDataBIDService(paginationInfo: PaginationModel, bid: any) {
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetMissingAVMarketingDataBId/' +bid ), JSON.stringify(paginationInfo), options);
    }

    updateMissingAVMarketingDataService(parameters: URLSearchParams) {
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        return this.http.post(this.location.prepareExternalUrl('/scmx/AvDetail/UpdateMissingAVMarketingDetail/'), parameters);
    }
}
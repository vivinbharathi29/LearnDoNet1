// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 04-18-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="today-page.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response,URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { pagination } from '../../../../shared/pagination-model.model';
import { ListSortDirection } from '../../../../shared/listsortdirection';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Injectable()
export class ItemsAwaitingMyApprovalService {
    constructor(private http: Http, private location: Location) { 
	
    }
    getItemsAwaitingMyApprovalService(paginationInfo: PaginationModel) {
        
        paginationInfo.PageNo = paginationInfo.PageNo + 1;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/GetItemsAwaitingMyApproval'), JSON.stringify(paginationInfo), options);
    }

    postMultiUpdateService(parameters: URLSearchParams)
    {      
        
        //var selectedIds = parameters.get("txtMultiID");
        //var approverComments = parameters.get("txtComments");
        //var updatedBy = parameters.get("target");
        //var approverStatus = strValue;
        //var productBrandId = parameters.get("ProductBrandID");
        //return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/UpdateActionMultiApproval/' + selectedIds + "/" + approverStatus + "/" + approverComments));

        var url = this.location.prepareExternalUrl('/today/TodayPage/UpdateActionMultiApproval');
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        return this.http.post(url, parameters);
    }
}
// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : hpadmin
// Created          : 04-19-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="my-open-tickets-view-model.model.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class MyOpenTicketsViewModel
{
	id : number;
	project : string;
	category : string;
	submitter : string;
	owner : string;
	status : string;
	summary : string;
	age : number;
	ageSort : number;
}
﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : hpadmin
// Created          : 03/24/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/06/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="avs-not-requested.service" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class AVsNotRequestedService {
    constructor(private http: Http, private location: Location) {

    }
    getAvsNotRequested() {
        return this.http.get(this.location.prepareExternalUrl('/today/todayPage/GetAvsNotRequested'))
    }
}
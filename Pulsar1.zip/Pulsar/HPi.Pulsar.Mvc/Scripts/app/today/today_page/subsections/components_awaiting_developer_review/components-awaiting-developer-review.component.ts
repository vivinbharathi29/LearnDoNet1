﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { ComponentsAwaitingDeveloperReviewService } from './components-awaiting-developer-review.service';
import { ActivatedRoute, Router } from '@angular/router';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
declare let $: any;
declare var modalPopup: any;

@Component({
    selector: 'components-awaiting-developer-review',
    templateUrl:'./components-awaiting-developer-review.component.html',
    styles: [`
.hideSection
{
    display:none;
}
`],
    providers: [ComponentsAwaitingDeveloperReviewService]
})

export class ComponentsAwaitingDeveloperReviewComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public enablemenu: boolean = false;
    public selectedRowIndex: string;

    constructor(private http: Http, private service: ComponentsAwaitingDeveloperReviewService, private _ngZone: NgZone, private router: Router)
    {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.componentsAwaitingDeveloperReviewCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.virtualmode = true; 
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'rootID', map: 'rootID' },
            { name: 'component', map: 'component' },
            { name: 'level', map: 'level' },
            { name: 'developer', map: 'developer' },
            { name: 'plannedCompletion', map: 'plannedCompletion' },
            { name: 'team', map: 'team' },
            { name: 'transferPath', map: 'transferPath' },
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'input', datafield: 'id', width: '10%' },
            { text: 'Component', filtertype: 'input', datafield: 'component', width: '30%' },
            { text: 'Level', filtertype: 'input', datafield: 'level', width: '15%' },
            { text: 'Developer', filtertype: 'input', datafield: 'developer', width: '15%' },
            { text: 'Planned Completion', filtertype: 'input', datafield: 'plannedCompletion', width: '15%' },
            { text: 'Team', filtertype: 'input', datafield: 'team', width: '15%' },
            { text: 'RootID', filtertype: 'input', hidden: true, datafield: 'rootID', width: 170 },
            { text: 'TransferPath', filtertype: 'input', hidden: true, datafield: 'transferPath', width: 170 }
        ];
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingDeveloperReview(paginationInfo);
    }

    getComponentsAwaitingDeveloperReview(paginationInfo: PaginationModel)
    {
        this.myGrid.showdefaultloadelement(true);
        this.service.getComponentsAwaitingDeveloperReview(paginationInfo).subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }

    componentsAwaitingDeveloperReviewCallback(result: any) {
        if (typeof (result) != undefined) {
            var paginationInfo: PaginationModel;
            this.myGrid.createComponent(this.jqxGridConfig.settings);
            paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
            this.getComponentsAwaitingDeveloperReview(paginationInfo);
        }
    }

    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingDeveloperReview(paginationInfo);
        //this.getProducts(paginationInfo);

    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingDeveloperReview(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsAwaitingDeveloperReview(paginationInfo);
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '150px', height: '160px', mode: 'popup', autoOpenPopup: false
    };

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index

        switch (menuItem) {
            case "Release Version...":
                this.ShowReleaseVersions(gridData.rootId, gridData.id, 1);
                break;
            case "Fail Version...":
                this.ShowReleaseVersions(gridData.rootId, gridData.id, 2);
                break;
            case "Display Changes":
                this.ShowPropertiesChange(gridData.rootId, gridData.id);
                break;
            case "Download":
                this.ShowVersions(gridData.id);
                break;
            case "Update Schedule...":
                this.ShowUpdateSchedules(gridData.id);
                break;
            case "Properties":
                this.ShowComponentVersions(1, gridData.rootId, gridData.id);
                break;
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                if (data.transferPath != "") {
                    this.enablemenu = false;
                }
                else {
                    this.enablemenu = true;
                }
            }
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
    }


    ShowReleaseVersions(rootId: number, versionId: number, action: number): void {
        var url = "";
        var title = "";
        var height = "550px";
        var width = "90%";
        url = "/excalibur/Release.asp?Action=" + action + "&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Workflow";
        adjustableShowPopupSecondlevel(url, title, height, width, "790px");
    }

    ShowPropertiesChange(rootId: number,versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/Properties/FT.asp?ID=" + versionId + "&app=PulsarPlus";
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['ft', versionId, rootId] } }]);
        modalPopup.show('#externalpagepopup', "40%", "500px", "Deliverable Changes");
    }

    ShowVersions(versionId: number): void {
        window.open("/excalibur/FileBrowse.asp?ID=" + versionId);
    }

    ShowUpdateSchedules(versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/deliverable/schedule.asp?ID=" + versionId + "&app=PulsarPlus";
        title = "Update Schedule";
        UpdateScheduleExcalibur(versionId);
    }

    ShowComponentVersions(action: number, rootId: number, versionId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/WizardFrames.asp?Type=1&RootID=" + rootId + "&ID=" + versionId + "&app=PulsarPlus";
        title = "Component Version Properties";
        showPopup(url, title, height, width);
    }
}
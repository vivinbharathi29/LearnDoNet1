// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.Mvc
// Author           : subburay
// Created          : 06/04/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/07/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="today-page.service.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';
import { FeatureRemovedFromPRLViewModel } from './feature-removed-from-prl-view-model.model';

@Injectable()
export class FeatureRemovedFromPRLService {
    constructor(private http: Http, private location: Location) {

    }

    getFeatureRemovedFromPRL(content:string) {
        return this.http.get(this.location.prepareExternalUrl('/Today/TodayPage/GetFeaturesRemovedFromPrl'));
    }
    //updateFeatureActionStatus(featureRemovedFromPRLViewModel: FeatureRemovedFromPRLViewModel) {
    //    let headers = new Headers({ 'Content-Type': 'application/json' });
    //    let options = new RequestOptions({ headers: headers });
    //    return this.http.post(this.location.prepareExternalUrl('/Today/TodayPage/UpdateFeatureActionStatus'), JSON.stringify(featureRemovedFromPRLViewModel), options);        
    //}

    updateFeatureActionStatus(featureRemovedFromPRLViewModel: FeatureRemovedFromPRLViewModel) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(this.location.prepareExternalUrl('/today/TodayPage/UpdateFeatureActionStatus/'), featureRemovedFromPRLViewModel, options);
    }

    getImpersonateName() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetImpersonateName'));
    }
}
﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 06/02/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 09/26/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="component-end-of-life-date-expired.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { ComponentEndOfLifeDateExpiredService } from './component-end-of-life-date-expired.service';

@Component({
    selector: 'component-end-of-life-date-expired',
    templateUrl:'./component-end-of-life-date-expired.component.html'
})

export class ComponentEndOfLifeDateExpiredComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    private mbp: MessageBoxButton;
    public title: string;
    public selectedRowIndex: string;
    ComponentEndOfLifeDateExpiredCallback(result) {
        if (typeof (result) != undefined) {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: ComponentEndOfLifeDateExpiredService, private messageBox: MessageBox, private activatedRoute: ActivatedRoute, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            ComponentEndOfLifeDateExpiredCallbackFn: (value) => this.ComponentEndOfLifeDateExpiredCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';

        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number' },
            { name: 'deliverableName', map: 'deliverableName', type:'string' },
            { name: 'component', map: 'component', type: 'string'  },
            { name: 'eolDate', map: 'eolDate' },
            { name: 'vendor', map: 'vendor' },
            { name: 'modelNumber', map: 'modelNumber', type: 'string' },
            { name: 'partNumber', map: 'partNumber',type:'string' },
            { name: 'title', map: 'title' },
            { name: 'userType', map: 'userType' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'UserType', columngroup: 'LifeDateExpired',
                datafield: 'userType', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ID', columngroup: 'LifeDateExpired',
                datafield: 'id', width: '10%', filtertype: 'number', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Available Until', columngroup: 'LifeDateExpired',
                datafield: 'eolDate', width: '10%', filtertype: 'date', cellsformat: 'MM/dd/yyyy', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Component', columngroup: 'LifeDateExpired',
                datafield: 'deliverableName', cellsalign: 'left', align: 'left', width: '22.5%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Version', columngroup: 'LifeDateExpired',
                datafield: 'component', cellsalign: 'left', align: 'left', width: '15%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Vendor', columngroup: 'LifeDateExpired',
                datafield: 'vendor', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Model', columngroup: 'LifeDateExpired',
                datafield: 'modelNumber', cellsalign: 'left', align: 'left', width: '15%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Part Number', columngroup: 'LifeDateExpired',
                datafield: 'partNumber', cellsalign: 'left', align: 'left', width: '15%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            }
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'eolDate': FilterColumnTypeEnum.Date,
            'component': FilterColumnTypeEnum.String,
            'deliverableName': FilterColumnTypeEnum.String,
            'vendor': FilterColumnTypeEnum.String,
            'modelNumber': FilterColumnTypeEnum.String,
            'partNumber': FilterColumnTypeEnum.String,
        }
    }

    onRowClick(event: any): boolean {        
        if (event.args.rightclick) {
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
        else {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                if (data.userType == "ServiceCommodityManager") {
                    var id = data.id;
                    var TypeID = "2";
                    var strIDs = id;
                    this.router.navigate([{ outlets: { 'externalpopupWindow': ['updateoldate', TypeID, strIDs] } }]);
                    modalPopup.show('#externalpagepopup', "30%", "330px", "Update Deliverable EOA Information");
                    $("#externalpagepopup").css("cssText", "height: 330px !important; position: absolute;");
                }
                else {
                    var id = data.id;
                    var TypeID = "1";
                    var strIDs = id;
                    this.router.navigate([{ outlets: { 'externalpopupWindow': ['updateoldate', TypeID, strIDs] } }]);
                    modalPopup.show('#externalpagepopup', "30%", "330px", "Update Deliverable EOA Information");
                    $("#externalpagepopup").css("cssText", "height: 330px !important; position: absolute;");
                }
            }
            return false;
        }
    }

    MultiUpdateEolDate(TypeID: any): void {
        var strIDs = "";
        var userType = "";
        var strResult;
        var id = "";
        var url = "";
        var title = "";
        var height = "500px";
        var width = "760px";
        title = "Update Selected Components";
        var index: number;
        var selectedIndices = this.myGrid.selectedrowindexes();
        //for (var index = 0; index < selectedIndices.length; index++) {
        //    strIDs = strIDs + this.myGrid.getrowdata(selectedIndices[index]).id + ",";
        //    userType = this.myGrid.getrowdata(selectedIndices[index]).userType + ",";
        //}
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = this.myGrid.getrows().length == 0 ? displayRows.length : this.myGrid.getrows().length;
        var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
        var endIndex = startIndex + paginationInfo.PageSize - 1;
        if (displayRowsLength < paginationInfo.PageSize) {
            endIndex = startIndex + displayRowsLength - 1;
        }
        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                strIDs += displayRows[index].id + ",";
                userType = displayRows[index].userType + ",";
            }
        }

        strIDs = strIDs.substring(0, strIDs.length - 1);
        if (strIDs.length == 0) {
            this.messageBox.Show("Release", "Please check at least one component and try again.", MessageBoxType.Ok, MessageBoxIcon.Warning, "400", this.confirmationMessage)
        }
        else {
            userType = userType.split(',')[0];
            if (userType == "ServiceCommodityManager") {
                TypeID = "2";
            }
            else {
                TypeID = "1";
            }
            if (TypeID == "2") {
                title = "Update End of Service Availability Date";
            }
            else {
                title = "Update End of Availability Date";
            }
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['multieoldate', TypeID, strIDs] } }]);
            modalPopup.show('#externalpagepopup', "88%", "550px", "Update Deliverable EOA Information");
        }
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
        }
        else if (this.mbp == MessageBoxButton.Cancel) {
        }
    }

    getComponentsEndOfLifeDateExpired(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getComponentsEndOfLifeDateExpired(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            if (result.json().length > 0) { 
                this.title = result.json()[0]['title'];
            }
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsEndOfLifeDateExpired(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsEndOfLifeDateExpired(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsEndOfLifeDateExpired(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsEndOfLifeDateExpired(paginationInfo);
    }

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getComponentsEndOfLifeDateExpired(paginationInfo);
        this.myGrid.clearselection();
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        if (rowdata.userType == "ServiceCommodityManager") {
            element[0].innerHTML = "<a style='font-family:verdana' class='jqx-anchor-hover' id='DelEOLRow " + rowdata.id + "' onclick='javascript:UpdateEOLDate(" + rowdata.id + "," + "2" + ");' /> " + value + " </a>";
        }
        else {
            element[0].innerHTML = "<a style='font-family:verdana' class='jqx-anchor-hover' id='DelEOLRow " + rowdata.id + "' onclick='javascript:UpdateEOLDate(" + rowdata.id + "," + "1" + ");' /> " + value + " </a>";
        }
        return element[0].outerHTML;
    };
}
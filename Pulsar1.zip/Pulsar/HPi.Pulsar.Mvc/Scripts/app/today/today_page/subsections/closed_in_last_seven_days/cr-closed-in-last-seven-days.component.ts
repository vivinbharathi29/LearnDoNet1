﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/11/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 01/08/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="cr-closed-in-last-seven-days.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { CRClosedInLastSevenDaysService } from './cr-closed-in-last-seven-days.service';
import { Location } from '@angular/common';

@Component({
    selector: 'closed-in-last-seven-days',
    templateUrl: './cr-closed-in-last-seven-days.component.html'
})

export class CRClosedInLastSevenDaysComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public selectedRowIndex: string;
    PopupCallback(result) {
        if (typeof (result) != undefined) {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: CRClosedInLastSevenDaysService, private _ngZone: NgZone, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.PopupCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type: 'number'  },
            { name: 'dotsName', map: 'dotsName', type: 'string'  },
            { name: 'status', map: 'status', type: 'string'  },
            { name: 'closed', map: 'closed' },
            { name: 'owner', map: 'owner', type: 'string'  },
            { name: 'submitter', map: 'submitter', type: 'string'  },
            { name: 'summary', map: 'summary', type: 'string'  },
            { name: 'type', map: 'type', type: 'string' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'Type', columngroup: 'CRClosedInLast7Days',
                datafield: 'type', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ID', columngroup: 'CRClosedInLast7Days',
                datafield: 'id', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'number', cellsformat: 'n',  cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Product', columngroup: 'CRClosedInLast7Days',
                datafield: 'dotsName', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input',  cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Status', columngroup: 'CRClosedInLast7Days',
                datafield: 'status', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input',  cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Closed', columngroup: 'CRClosedInLast7Days',
                datafield: 'closed', width: '10%', filtertype: 'date', cellsformat: 'MM/dd/yyyy', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Owner', columngroup: 'CRClosedInLast7Days',
                datafield: 'owner', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Submitter', columngroup: 'CRClosedInLast7Days',
                datafield: 'submitter', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            },
            {
                text: 'Summary', columngroup: 'CRClosedInLast7Days',
                datafield: 'summary', cellsalign: 'left', align: 'left', width: '40%', filtertype: 'input', cellsrenderer: this.cellsrenderer
            }
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'dotsName': FilterColumnTypeEnum.String,
            'status': FilterColumnTypeEnum.String,
            'closed': FilterColumnTypeEnum.Date,
            'owner': FilterColumnTypeEnum.String,
            'submitter': FilterColumnTypeEnum.String,
            'summary': FilterColumnTypeEnum.String
        }
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        if ($(args).find("a").text() == "Edit Row") {
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
        else {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            if (data != null) {
                //var id = data.id;
                //var crtype = data.type;
                //changeclosedrows_onclick(id,crtype);
                var deliverableIssueId = data.id;
                var crType = data.type;
                var url = "";
                var title = "";
                var height = "75%";
                var width = "94%";
                url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
                title = "Properties";
               // showPopup(url, title, height, width);  
                showPopupWithHeightInPercentage(url, title, height, width);
            }
            return false;
        }
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
    };

    //Menu Code – menu item click to get the Grid row data.
    ShowActionReportMobileSE(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var NewTop;
        var NewLeft;
        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var action = 1;
        var title = "";
        var height = 520;
        var width = 850;
        window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No");
    }

    ShowActionProperties(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        //var id = "";
        //var typeid = "";
        //var url = "";
        //var title = "";
        //var height = 700;
        //var width = 705;
        //title = "Properties";
        //id = this.myGrid.getrowdata(selectedIndices).id;
        //typeid = this.myGrid.getrowdata(selectedIndices).type;
        //url = "/Excalibur/mobilese/today/action.asp?ID=" + id + "&Type=" + typeid + "&app=" + "PulsarPlus";
        //showPopup(url, title, height, width);
        
        var deliverableIssueId = this.myGrid.getrowdata(selectedIndices).id;
        var crType = this.myGrid.getrowdata(selectedIndices).type;
        var url = "";
        var title = "";
        var height = "75%";
        var width = "94%";
        url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
        title = "Properties";
        //showPopup(url, title, height, width); 
        showPopupWithHeightInPercentage(url, title, height, width);       
    }
    
    ShowActionReport(event: any): void {
        var NewTop;
        var NewLeft;
        var id = "";
        var typeid = "";
        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        var selectedIndices = this.myGrid.selectedrowindexes();
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        window.open("/Excalibur/MobileSE/Today/actionReport.asp?Action=0&ID=" + id + "&Type=" + typeid + "&app=" + "PulsarPlus", "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No");
    }

    getCRClosedInLastSevenDays(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getCRClosedInLastSevenDays(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRClosedInLastSevenDays(paginationInfo);
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRClosedInLastSevenDays(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRClosedInLastSevenDays(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myGrid.localizestrings(this.jqxGridConfig.localization);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRClosedInLastSevenDays(paginationInfo);
        this.myMenu.createComponent(this.MenuSettings);
    }

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getCRClosedInLastSevenDays(paginationInfo)
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var element = $(defaulthtml);
        element[0].innerHTML = "<a style='font-family:verdana' class='jqx-anchor-hover ID=" + rowdata.id + "&" + "Type=" + rowdata.type + "' id='changeclosedrows' onclick='javascript:changeclosedrows_onclick();' /> " + value + " </a>";
        return element[0].outerHTML;
    };
    
    exportToExcel() {
        CrClosedExportToExcel();
    }
}
﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/04/2017
// Last Modified By : Shanmugaraj.M(auth\maniseka)
// Last Modified On : 09/26/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="legacy-simple-av.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

/// <reference path="../../../../jqwidgets-ts/angular_jqxgrid.ts" />
/// <reference path="../../../../shared/jqxgrid_helper/jqxgrid-configuration.ts" />
import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router';
declare let $: any;
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { LegacySimpleAVService } from './legacy-simple-av.service';
import { LegacySimpleAVViewModel } from './legacy-simple-av.viewmodel';

@Component({
    selector: 'legacy-simple-av',
    templateUrl:'./legacy-simple-av.component.html'
})

export class LegacySimpleAVComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public userId: number = 0;
    public title: string;
    private mbp: MessageBoxButton;
    public legacySimpleAvs: LegacySimpleAVViewModel[];
    PopupCallback(result) {
        if (typeof (result) != "undefined") {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: LegacySimpleAVService, private messageBox: MessageBox, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.PopupCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'deliverableRootId', map: 'deliverableRootId',type:'number' },
            { name: 'avCreateId', map: 'avCreateId', type: 'number' },
            { name: 'product', map: 'product', type: 'string'},
            { name: 'brandName', map: 'brandName', type: 'string'},
            { name: 'component', map: 'component', type: 'string' },
            { name: 'avFeatureCategory', map: 'avFeatureCategory' },
            { name: 'productBrandId', map: 'productBrandId' },
            { name: 'ioGenerated', map: 'ioGenerated', type: 'bool' },
            { name: 'overMaxLen', map: 'overMaxLen' },
            { name: 'userId', map: 'userId' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'UserId', columngroup: 'LegacyAV',
                datafield: 'userId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ProductBrandId', columngroup: 'LegacyAV',
                datafield: 'productBrandId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'OverMaxLen', columngroup: 'LegacyAV',
                datafield: 'overMaxLen', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'AvCreateId', columngroup: 'LegacyAV',
                datafield: 'avCreateId', hidden: true, cellsrenderer: this.cellsrenderer
            },
            {
                text: 'ID', columngroup: 'LegacyAV',
                datafield: 'deliverableRootId', cellsalign: 'left', align: 'left', width: '6.5%', filtertype: 'number', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass 
            },
            {
                text: 'Product', columngroup: 'LegacyAV',
                datafield: 'product', cellsalign: 'left', align: 'left', width: '11%', filtertype: 'input', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass 
            },
            {
                text: 'Brand', columngroup: 'LegacyAV',
                datafield: 'brandName', cellsalign: 'left', align: 'left', width: '12%', filtertype: 'input', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass 
            },
            {
                text: 'Component', columngroup: 'LegacyAV',
                datafield: 'component', cellsalign: 'left', align: 'left', width: '46%', filtertype: 'input', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass 
            },
            {
                text: 'AV Feature Category', columngroup: 'LegacyAV',
                datafield: 'avFeatureCategory', cellsalign: 'left', align: 'left', width: '15%', filtertype: 'input', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass 
            },
            {
                text: 'IO Generated', columngroup: 'LegacyAV',
                datafield: 'ioGenerated', cellsalign: 'left', align: 'left', width: '8%', filtertype: 'bool', cellsrenderer: this.cellsrenderer, cellclassname: this.cellclass 
            }
        ];

        this.jqxGridConfig.columnTypes = {
            'deliverableRootId': FilterColumnTypeEnum.Number,
            'product': FilterColumnTypeEnum.String,
            'brandName': FilterColumnTypeEnum.String,
            'component': FilterColumnTypeEnum.String,
            'avFeatureCategory': FilterColumnTypeEnum.String,
            'ioGenerated': FilterColumnTypeEnum.Boolean,
        }
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '112px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row
    };

    //Menu Code – menu item click to get the Grid row data.
    CreateAVs_oncontextmenu(event: any, NotActionable: any): void {
        var avCreateId = "";
        var userId = "";
        var url = "";
        let parameters = new URLSearchParams();
        var selectedIndices = this.myGrid.selectedrowindexes();
        avCreateId = this.myGrid.getrowdata(selectedIndices).avCreateId;
        userId = this.myGrid.getrowdata(selectedIndices).userId;
        parameters.set("function", "CreateSimpleAv");
        parameters.set("AvCreateID", avCreateId);
        parameters.set("NotActionable", NotActionable);
        parameters.set("UserID", userId);
        this.service.postCreateSimpleAvsLegacy(parameters)
            .subscribe(result => {
                if (result.text() != "0") {
                    this.reloadGrid();
                }
            });
    }

    AddExistingAVNoToDeliverable(event: any): void {
        var strID = "";
        var userId = "";
        var avCreateId = "";
        var deliverableRootId = "";
        var productBrandId = "";
        var deliverableName = "";
        var url = "";
        var title = "";
        var height = "170px";
        var width = "400px";
        var selectedIndices = this.myGrid.selectedrowindexes();
        userId = this.myGrid.getrowdata(selectedIndices).userId;
        avCreateId = this.myGrid.getrowdata(selectedIndices).avCreateId;
        deliverableRootId = this.myGrid.getrowdata(selectedIndices).deliverableRootId;
        productBrandId = this.myGrid.getrowdata(selectedIndices).productBrandId;
        deliverableName = this.myGrid.getrowdata(selectedIndices).component;
        url = "/Excalibur/MobileSE/Today/AddAvNoToDeliverableFrame.asp?ID=" + avCreateId + "&CurrentUserId=" + userId + "&DeliverableRootId=" + deliverableRootId + "&DeliverableName=" + deliverableName + "&ProductBrandId=" + productBrandId + "&app=" + "PulsarPlus";
        title = "Add Existing AV No. To Component";
       // strID = adjustableShowPopup(url, title, height, width, "180px");
        //strID = showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['avnotodeliverable', avCreateId, deliverableRootId, productBrandId, deliverableName] } }]);
        modalPopup.show('#externalpopupMessage', "400px", "30%", "Add Existing AV No. To Component");
    }

    public avCreateId: string[];
    public categoryId: string;
    ChangeCategory_oncontextmenu(event: any): void {
        this.avCreateId = [];
        this.categoryId = "";
        var url = "";
        var title = "SCM Category";
        var height = ($(window).height() * 15) / 100;
        var width = ($(window).width() * 25) / 100;
        let parameters = new URLSearchParams();
        var selectedIndices = this.myGrid.selectedrowindexes();
        if (selectedIndices.length > 0) {
            this.categoryId = "";
            this.avCreateId.push(this.myGrid.getrowdata(selectedIndices[0]).avCreateId);
            url = "/Pulsar/scm/ListCategory?SelectedCategoryID=" + this.categoryId + "&app=PulsarPlus";
            showPopup(url, title, height, width);
        }
    }

    btnCreateAVs_onclick(userId: any, NotActionable: any): void {
        
        var idList = "";
        var index: number;
        var selectedIndices = this.myGrid.selectedrowindexes();
        //for (var index = 0; index < selectedIndices.length; index++) {
        //    idList = idList + this.myGrid.getrowdata(selectedIndices[index]).id + ",";
        //}
        
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = this.myGrid.getrows().length;
        var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
        var endIndex = startIndex + paginationInfo.PageSize - 1;
        if (displayRowsLength < paginationInfo.PageSize) {
            endIndex = startIndex + displayRowsLength - 1;
        }
        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                idList += displayRows[index].avCreateId + ",";
            }
        }

        idList = idList.substring(0, idList.length - 1);
        if (idList.length == 0) {
            this.messageBox.Show("Create Simple AV's", "Please Select Atleast Single AV.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.confirmationMessage)
        }
        else {
            var id = "";
            var dcrId = "";
            var pvId = "";
            let parameters = new URLSearchParams();
            var selectedIndices = this.myGrid.selectedrowindexes();
            this.myGrid.showdefaultloadelement(true);
            for (index = startIndex; index <= endIndex; index++) {
                if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                    parameters.set("function", "CreateSimpleAv");
                    parameters.set("AvCreateID", displayRows[index].avCreateId);
                    parameters.set("NotActionable", NotActionable);
                    parameters.set("UserID", displayRows[index].userId);
                    parameters.set("Pulsar", "0");
                    parameters.set("AvCreateIDs", "");
                    this.service.postCreateSimpleAvsLegacy(parameters).subscribe(result => {
                        this.reloadGrid();
                    });
                }
            }
            this.reloadGrid();
            this.myGrid.hideloadelement();
        }
    }

    getLegacySimpleAvs(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getLegacySimpleAvs(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            if (result.json().length > 0) {
                this.userId = result.json()[0]['userId'];
            }
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLegacySimpleAvs(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLegacySimpleAvs(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLegacySimpleAvs(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLegacySimpleAvs(paginationInfo);
        this.service.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
        });
        this.myMenu.createComponent(this.MenuSettings);
    }

    reloadGrid(): void {
        this.myGrid.clearselection();
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getLegacySimpleAvs(paginationInfo);
    }

    confirmationMessage = (response: MessageBoxButton): void => {
        this.mbp = response;
        if (this.mbp == MessageBoxButton.Ok) {
        }
        else if (this.mbp == MessageBoxButton.Cancel) {
        }
    }

    cellclass = function (row, columnfield, value, rowdata) {
        if (rowdata.overMaxLen == "1") {
            return 'cellcolor';
        }
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        //if (rowdata.overMaxLen == "1") {
        //    var element = $(defaulthtml);
        //    element.css({ 'background-color': '#ffe4e1' });
        //    return element[0].outerHTML;
        //}  
        //return defaulthtml;
    }
};


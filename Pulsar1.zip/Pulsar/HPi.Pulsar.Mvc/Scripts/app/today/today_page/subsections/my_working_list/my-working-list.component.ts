﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';

import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { MyWorkingListService } from './my-working-list.service';
import { MyWorkingListViewModel } from './my-working-list-view-model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { UserInfoService } from '../../dashboard/user-info.service';
import 'rxjs/add/operator/map';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
@Component({
    selector: 'my-working-list',
    templateUrl:'./my-working-list.component.html'
})

export class MyWorkingListComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    jqxGridConfig: jqxGridConfiguration;
    public myWorkingList: MyWorkingListViewModel[];
    public title: string;
    public userId: any;
    public selectedRowIndex: string;
    ActionsCallback(status: any): void {
        if (typeof (status) != "undefined") {
            if (status > 0) {
                console.log(status);
                this.pageReload();
            }
        }
    }
    pageReload() {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyWorkingList(paginationInfo);
    }
    constructor(http: Http, private service: MyWorkingListService, private userInfoService: UserInfoService, private ngZone: NgZone, private router: Router, private location: Location) {        
        window['angularComponentRef'] = {
            zone: this.ngZone,
            ActionsCallbackFn: (value) => this.ActionsCallback(value),
            popUpCallBackFn: (value) => this.ActionsCallback(value),
            component: this
        };
        window['angularComponentRef_Working'] = { component: this, zone: ngZone };
        window['angularComponentRef_Working'] = {
            zone: this.ngZone,
            popUpCallBackFn: (value) => this.ActionsCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
       // this.jqxGridConfig.width = 1000;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'type', map: 'type' },
            { name: 'id', map: 'id' },
            { name: 'priority', map: 'priority',type:'string' },
            { name: 'displayOrder', map: 'displayOrder',type: 'string' },
            { name: 'mileStone', map: 'mileStone', type: 'string'},
            { name: 'timeFrame', map: 'timeFrame' },
            { name: 'summary', map: 'summary' },
            { name: 'duedate', map: 'duedate' },
            { name: 'typeName', map: 'typeName' },
            { name: 'statusName', map: 'statusName' },
            { name: 'userId', map: 'userId' }
        ];


        //this.jqxGridConfig.columns = [
        //    { text: 'Type', filtertype: 'input', datafield: 'type', width: "10%", cellsrenderer: this.cellsrenderer, hidden: true  },
        //    { text: 'ID', filtertype: 'number', datafield: 'id', cellsalign: 'left', align: 'left', width: "10%", cellsrenderer: this.cellsrenderer },
        //    { text: 'PR', filtertype: 'input', datafield: 'priority', align: 'left', cellsalign: 'left', width: "5%", cellsrenderer: this.cellsrenderer },
        //    { text: 'Order', filtertype: 'input', datafield: 'displayOrder', cellsalign: 'left', width: "5%", cellsrenderer: this.cellsrenderer },
        //    { text: 'Type', filtertype: 'input', datafield: 'typeName', width: "10%", cellsrenderer: this.cellsrenderer },
        //    { text: 'Status', filtertype: 'input', datafield: 'statusName', width: "10%", cellsrenderer: this.cellsrenderer  },
        //    { text: 'Milestone', filtertype: 'input', datafield: 'mileStone', cellsalign: 'left', width: "10%", cellsrenderer: this.cellsrenderer },
        //    { text: 'Target', filtertype: 'input', datafield: 'timeFrame', cellsalign: 'left', width: "10%", cellsrenderer: this.cellsrenderer },
        //    { text: 'Summary', filtertype: 'input', datafield: 'summary', cellsalign: 'left', width: "38%", cellsrenderer: this.cellsrenderer },
        //    { text: 'Duedate', filtertype: 'input', datafield: 'duedate', cellsalign: 'left', width: 125, cellsrenderer: this.cellsrenderer, hidden: true },
        //    { text: 'userId', filtertype: 'input', datafield: 'userId', cellsalign: 'left', width: 125, cellsrenderer: this.cellsrenderer, hidden: true }
        //];

        this.jqxGridConfig.columns = [
            { text: 'Type', filtertype: 'input', datafield: 'type', width: "10%", hidden: true },
            { text: 'ID', filtertype: 'number', datafield: 'id', cellsalign: 'left', align: 'left', width: "10%" },
            { text: 'PR', filtertype: 'input', datafield: 'priority', align: 'left', cellsalign: 'left', width: "5%" },
            { text: 'Order', filtertype: 'input', datafield: 'displayOrder', cellsalign: 'left', width: "5%" },
            { text: 'Type', filtertype: 'input', datafield: 'typeName', width: "10%" },
            { text: 'Status', filtertype: 'input', datafield: 'statusName', width: "10%" },
            { text: 'Milestone', filtertype: 'input', datafield: 'mileStone', cellsalign: 'left', width: "10%" },
            { text: 'Target', filtertype: 'input', datafield: 'timeFrame', cellsalign: 'left', width: "10%" },
            { text: 'Summary', filtertype: 'input', datafield: 'summary', cellsalign: 'left', width: "38%" },
            { text: 'Duedate', filtertype: 'input', datafield: 'duedate', cellsalign: 'left', width: 125, hidden: true },
            { text: 'userId', filtertype: 'input', datafield: 'userId', cellsalign: 'left', width: 125, hidden: true }
        ];

        this.jqxGridConfig.columnTypes = {
            'type': FilterColumnTypeEnum.Number,
            'id': FilterColumnTypeEnum.String,
            'priority': FilterColumnTypeEnum.String,
            'displayOrder': FilterColumnTypeEnum.String,    
            'milestone': FilterColumnTypeEnum.String,
            'status': FilterColumnTypeEnum.String,
            'duedate': FilterColumnTypeEnum.Date,
            'summary': FilterColumnTypeEnum.String,
            'typeName': FilterColumnTypeEnum.String,
            'statusName': FilterColumnTypeEnum.String,
            'userId': FilterColumnTypeEnum.String
        }
    }

    Search(): void
    {
        var searchUrl = "/product/product/queryactions/0/2";
        if (window.location.href.indexOf("localhost") < 0) {
            searchUrl = "/pulsarplus" + searchUrl;
        }
        //this.location.prepareExternalUrl("/product/product/queryactions/0/2");
        window.open(this.location.prepareExternalUrl("/product/product/queryactions/0/2"), "_blank");

        //window.open("/Excalibur/Query/actions.asp?ID=0&Type=2", "_blank");
    }

    Details(): void
    {
        window.open("/Excalibur/Query/actionreport.asp?txtTitle=My%20Working%20List&lstOwners=" + this.userId + "&lstStatus=0,1,3&chkWorkingList=1&Sort1Column=DisplayOrder", "_blank");
    }

    ReorderActions(UserID: any): void {
        var strID;

        var url = "/Excalibur/Actions/WorkingListReorder.asp?ID=" + this.userId + "&app=" + "PulsarPlus";
        var title = "Reorder tasks";
        var height = 650;
        var width = 900;
        //showPopup(url, title, height, width);
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['workinglistreorder', this.userId, 0, 0] } }]);
        modalPopup.show('#externalpopupMessage', "80%", "650px", "Reorder tasks");
        //if (typeof (strID) != "undefined") {
        //    window.location.reload(true);
        //}
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    sendMail(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = 750;
        var width = 650;
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var NewTop;
        var NewLeft;

        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2

        var action = 1;

        // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=770,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")


       // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        //url = "actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid;
        //title = "Send Email";
        //showPopup(url, title, height, width);
    }
    properties(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = "450px";
        var width = "80%";
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        url = "/Excalibur/mobilese/today/action.asp?ID=" + id + "&Type=" + typeid + '&app=' + 'PulsarPlus';
        title = "Properties";
        //showPopup(url, title, height, width);
        if (typeid == "2") {
            //url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['action', 0, id, 0, 0, 2, 0, 0, 'myworkinglist'] } }]);
            modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");
        }
        else {
            url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + id + "/" + typeid + "/0/0");
           // showPopup(url, "Properties", height, width);
            showPopupWithHeightInPercentage(url, "Properties", "75%", "94%");
        }
    }
    //Menu Code – Sample menu item click to get the Grid row data.
    printPreview(event: any): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var id = "";
        var typeid = "";
        var url = "";
        var title = "";
        var height = 750;
        var width = 650;
        var strResult;
        var NewTop;
        var NewLeft;

        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        id = this.myGrid.getrowdata(selectedIndices).id;
        typeid = this.myGrid.getrowdata(selectedIndices).type;
        var action = 0;

        // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + id + "/" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=770,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

       // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=0&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")
        //url = "actionReport.asp?Action=0&ID=" + id + "&Type=" + typeid;
        // title = "PrintReport";
        //showPopup(url, title, height, width);
    }
    ActionPrint(strID, strType) {
        var strResult;
        var NewTop;
        var NewLeft;

        NewLeft = (screen.width - 655) / 2
        NewTop = (screen.height - 650) / 2
        var action = 0;

        // window.open("/Excalibur/mobilese/today/actionReport.asp?Action=1&ID=" + id + "&Type=" + typeid, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        strResult = window.open("/pulsarplus/product/product/GetActionReportMobileSE/" + action + "/" + strID + "/" + strType, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")

        //strResult = window.open("/Excalibur/mobilese/today/actionReport.asp?Action=0&ID=" + strID + "&Type=" + strType, "_blank", "Left=" + NewLeft + ",Top=" + NewTop + ",Width=655,Height=650,menubar=no,toolbar=no,resizable=Yes,status=No")
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick");
        var args = event.args;
        let rowIndex: number;
        rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        console.log(rowIndex);
        var data = this.myGrid.getrowdata(rowIndex);// get the Row data based on the row index
        console.log(data);
        console.log($(args).find("a").text()); // Get the Menu Item name          
        if ($(args).find("a").text() == "Edit Row") {
            console.log("Edit Row clicked");
            //Do something
        }
    }
    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            //   $("#jqxgrid").jqxGrid('selectrow', event.args.rowindex);
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }   
        else {
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            var data = this.myGrid.getrowdata(event.args.rowindex);
            console.log(data);
            var url = '';
            var height = "450px";
            var width = "80%";
            if (data != null) {
               // ActionPropertiesMvc(data.id, data.type);
                if (data.type == 2) {
                    //url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + deliverableIssueId + "/" + crType + "/0/0");
                    this.router.navigate([{ outlets: { 'externalpopupWindow': ['action', 0, data.id, 0, 0, 2, 0, 0, 'myworkinglist'] } }]);
                    modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");
                }
                else {
                    url = this.location.prepareExternalUrl("/product/product/GetTodayAction/" + data.id + "/" + data.type + "/0/0");
                    //showPopup(url, "Properties", height, width);
                    showPopupWithHeightInPercentage(url, "Properties", "75%", "94%");
                }
            }

            return false;
        }
    }    
    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row

    };


    AddToolAction(ID) {
        
    //var url = "/Excalibur/actions/action.asp?AppErrorID=" + ID + "&ID=0&Working=1&ProdID=0&Type=2"+ '&app=' + 'PulsarPlus';
    //var title = "Convert to Action Item";
    //var height = 530;
    //var width = 705;
    //showPopup(url, title, height, width)
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['action', ID, 0, 1,0,2,0,0,'workinglist'] } }]);
        modalPopup.show('#externalpagepopup', "85%", "650px", "Convert to Action Item");
}
    getMyWorkingList(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMyWorkingListService(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            console.log(result.json());
            if (result.json().length > 0) {
                this.userId = result.json()[0]['userId'];
            } 
            this.myGrid.updatebounddata("data");
            this.myGrid.hideloadelement();
        });
    }
    /********* the below event is fired whenever page number is changed
             Call the service method here and refresh the grid.
     *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyWorkingList(paginationInfo);
        //this.getProducts(paginationInfo);

    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyWorkingList(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyWorkingList(paginationInfo);
    }

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMyWorkingList(paginationInfo);
        this.userInfoService.getImpersonateName().subscribe(result => {
            this.title = result.json().title;
        });
        this.myMenu.createComponent(this.MenuSettings);
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {

     // return "<a class='jqx-anchor-hover'  href='javascript:ActionPropertiesMvc(" + rowdata.id + "," + rowdata.type + " );' /> " + value + "</a>";

        var element = $(defaulthtml);
        element[0].innerHTML = "<a class='jqx-anchor-hover'  href='javascript:ActionPropertiesMvc(" + rowdata.id + "," + rowdata.type + " );' /> " + value + "</a>";
        return element[0].outerHTML;
    };

}

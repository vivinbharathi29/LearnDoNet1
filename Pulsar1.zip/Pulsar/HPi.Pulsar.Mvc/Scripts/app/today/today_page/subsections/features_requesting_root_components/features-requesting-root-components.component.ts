﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router';
import { FeaturesRequestingRootComponentsService } from './features-requesting-root-components.service';
import { FeaturesRequestingRootComponentsVM } from './features-requesting-root-components.view-model';
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';


@Component({
    selector: 'features-requesting-root-components',
    templateUrl:'./features-requesting-root-components.component.html',
    providers: [FeaturesRequestingRootComponentsService]
})


export class FeaturesRequestingRootComponents implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    public selectedRowIndex: string;
    jqxGridConfig: jqxGridConfiguration;
    public featuresRequestingRootComponents: FeaturesRequestingRootComponentsVM[];
    comments: string = "";
    mbp: MessageBoxButton;
    

    featuresRequestingRootComponentsCallback(strID: any) {
        console.log("FEature callback", strID);
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.pageReload();
            //}
        }
    }

    constructor(private http: Http, private service: FeaturesRequestingRootComponentsService, private _ngZone: NgZone, private activatedRoute: ActivatedRoute, private router: Router, private messageBox: MessageBox) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.featuresRequestingRootComponentsCallback(value),
            component: this
        };

        this.comments = "";
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = "490px";
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id', type:'number' },
            { name: 'featureName', map: 'featureName', type: 'string' },
            { name: 'rootNamingSuggestion', map: 'rootNamingSuggestion', type: 'string' },
            { name: 'featureCategory', map: 'featureCategory', type: 'string' },
            { name: 'category', map: 'category', type: 'string' },
            { name: 'updatedBy', map: 'updatedBy', type: 'string' },
            { name: 'updated', map: 'updated' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: '8%' },
            { text: 'Marketing/Supply Chain Feature Name', filtertype: 'input', datafield: 'featureName', width: '23%' },
            { text: 'R&D Component Name', filtertype: 'input', datafield: 'rootNamingSuggestion', width: '22.9%' },
            { text: 'Feature Category', filtertype: 'input', datafield: 'featureCategory', width: '10%' },
            { text: 'Component Category', filtertype: 'input', datafield: 'category', width: '10%' },
            { text: 'Requested By', filtertype: 'input', datafield: 'updatedBy', width: '12%' },
            { text: 'Date Requested', filtertype: 'date', cellsformat: 'MM/dd/yyyy', datafield: 'updated', width: '12.1%' },
        ];

        this.jqxGridConfig.columnTypes = {
            'id': FilterColumnTypeEnum.Number,
            'featureName': FilterColumnTypeEnum.String,
            'rootNamingSuggestion': FilterColumnTypeEnum.String,
            'featureCategory': FilterColumnTypeEnum.String,
            'category': FilterColumnTypeEnum.String,
            'updatedBy': FilterColumnTypeEnum.String,
            'updated': FilterColumnTypeEnum.Date
        }

    }

    getFeaturesRequestingRootComponents(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getFeaturesRequestingRootComponents(paginationInfo).subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }

    onPageChanged(event: any): void {
        
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeaturesRequestingRootComponents(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {
        
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeaturesRequestingRootComponents(paginationInfo);

    }

    onFilter(event: any): void {         
        var paginationInfo: PaginationModel;      
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeaturesRequestingRootComponents(paginationInfo);        
    }

    pageReload(): void {   
        console.log("pagereload");     
        var paginationInfo: PaginationModel;
        this.myGrid.clearselection();
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeaturesRequestingRootComponents(paginationInfo);
    }

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '350px', height: '85px', mode: 'popup', autoOpenPopup: false,

    };

    ngAfterViewInit(): void {
        
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getFeaturesRequestingRootComponents(paginationInfo);
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    multiFeatureRootReject(): void {
        if (this.comments == "") {
            this.messageBox.Show("Features Requesting Root Components", "You must provide a comment to reject a Feature Root Request.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback);
            return;
        }

        var selectedIndices = this.myGrid.selectedrowindexes();
        console.log("selected row", selectedIndices);
        if (selectedIndices.length == 0) {
            this.messageBox.Show("Features Requesting Root Components", "No item selected.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback);
            return;
        }

        var idList = "";
        var index: number;
        var cntSuccess = 0;
        var strSuccessIDs = '';
        var cntFail = 0;
        var strFailIDs = '';

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = this.myGrid.getrows().length;
        var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
        var endIndex = startIndex + paginationInfo.PageSize - 1;
        if (displayRowsLength < paginationInfo.PageSize) {
            endIndex = startIndex + displayRowsLength - 1;
        }
        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                idList = displayRows[index].id;
                console.log(idList);
                multiFeatureRootRejectRequest(idList, this.comments, index, selectedIndices.length - 1);
                
            }
        }
        (<HTMLInputElement>document.getElementById("txtTodayFeatureRootRequest_Comment")).value = "";
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick", this.selectedRowIndex);

        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        let rowNumber: any;
        rowNumber = this.selectedRowIndex;
        args = event.args;
        menuItem = $(args).text();
        //rowIndex = this.myGrid.getselectedrowindex();// Get the Row index of grid
        //console.log(rowIndex);
        //rowIndex = rowIndex == -1 ? this.selectedRowIndex : rowIndex;
        /*gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);*/// get the Row data based on the row index
        gridData = this.myGrid.getrowdata(rowNumber); 
        console.log(gridData);
        console.log(menuItem); // Get the Menu Item name    
        if (gridData != undefined) {
            switch (menuItem) {
                case "Reject this request":
                    this.featureRequestReject(gridData.id);
                    break;
                case "Select existing Component Root":
                    this.featureRequestSelectRoot(gridData.id);
                    break;
                case "Add New Component Root linked to this Feature":
                    this.featureRequestAddRoot(gridData.id);
                    break;
            }
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.selectedRowIndex = "";
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = event.args.rowindex;
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
        //}
    }

    featureRequestReject(featureId: number): void {
        var url = "";
        var title = "";
        var height = "200px";
        var width = "700px";
        url = "/excalibur/MobileSE/Today/Feature/RejectFeatureRequest.asp?ID=" + featureId + "&app=PulsarPlus";
        title = "Reject Feature Request";

        //showPopup(url, title, height, width);

        this.router.navigate([{ outlets: { 'externalpopupWindow': ['rejectfeature', featureId] } }]);
        modalPopup.show('#externalpopupMessage', width, height, title);
    }

    featureRequestSelectRoot(featureId: number): void {
        var url = "";
        var title = "";
        var height = "600px";
        var width = "90%";        
        url = "/excalibur/pmr/softpaqframe.asp?Title=Select Root For Feature&Page=/Pulsar/Component/linkroottofeature&FeatureID=" + featureId + "&app=PulsarPlus";        
        title = "Select Root For Feature";
        showPopup(url, title, height, width);
    }

    featureRequestAddRoot(featureId: number): void {
        var url = "";
        var title = "";
        var height = "650px";
        var width = "90%";
        url = "/excalibur/pmr/softpaqframe.asp?Title=Add New Component Root&Page=/Pulsar/Component/AddNewRootForFeatureFromTodayPage&FeatureID=" + featureId + "&app=PulsarPlus";
        title = "Add New Component Root";
        showPopup(url, title, height, width);
    }

    numCallback = (response: MessageBoxButton): void => {
        this.mbp = response;
    }

}


﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05/23/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="linked-component-not-used-by-commodity-team.service.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class LinkedComponentsNotUsedByCommodityTeamService {
    constructor(private http: Http, private location: Location) {
    }

    getLinkedComponentsNotUsedByCommodityTeam() {
        return this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetLinkedComponentsNotUsedByCommodityTeam'))
    }
}

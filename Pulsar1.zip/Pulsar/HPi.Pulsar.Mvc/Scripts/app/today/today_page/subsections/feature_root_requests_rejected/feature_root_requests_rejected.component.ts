﻿import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { FeatureRootRequestsRejectedService } from './feature_root_requests_rejected.service';


@Component({
    selector: 'feature_root_requests_rejected',
    templateUrl:'./feature_root_requests_rejected.component.html',
    providers: [FeatureRootRequestsRejectedService]
})

export class FeatureRootRequestsRejectedComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    public selectedRowIndex: string;

    featureRootRequestsRejectedCallback(strID: any) {
        if (typeof (strID) != "undefined") {
            //if (strID > 0) {
            console.log(strID);
            this.getFeatureRootRequestsRejected();
            //}
        }
    }

    constructor(private http: Http, private service: FeatureRootRequestsRejectedService, private _ngZone: NgZone) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            featurePropertiesPopUpCallBackFn : (value) => this.featureRootRequestsRejectedCallback(value),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;;
        this.jqxGridConfig.virtualmode = false;
        this.jqxGridConfig.settings.rowsheight = 50;
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },
            { name: 'feature', map: 'feature' },
            { name: 'category', map: 'category' },
            { name: 'reasonRejected', map: 'reasonRejected' },
            { name: 'fullName', map: 'fullName' },
            { name: 'email', map: 'email' },
        ];

        this.jqxGridConfig.columns = [
            { text: 'ID', filtertype: 'number', datafield: 'id', width: '10%' },
            { text: 'Feature Name', filtertype: 'input', datafield: 'feature', width: '35%' },
            { text: 'Feature Category', filtertype: 'input', datafield: 'category', width: '18%' },
            { text: 'Reason Rejected', filtertype: 'input', datafield: 'reasonRejected', width: '28%' },
            { text: 'User Name', filtertype: 'input', datafield: 'fullName', width: '13%' },
            { text: 'Email', filtertype: 'input', datafield: 'email', width: '12%', cellsrenderer: this.cellsrenderer },
        ];
    }

    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {
        var email = rowdata.email == null ? "" : rowdata.email;
        var fullName = rowdata.fullName == null ? "" : rowdata.fullName;

        return "<a class='actionLink' href='mailto:" + email + "?subject=Feature Root Requests Rejected&body=Hi " + fullName + ",'>" + email + "</a>";
    };

    //Menu Code – Menu popup display settings
    public MenuSettings: jqwidgets.MenuOptions =
    {
        width: '150px', height: '60px', mode: 'popup', autoOpenPopup: false,

    };

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.myMenu.createComponent(this.MenuSettings);
        this.getFeatureRootRequestsRejected();

    }

    getFeatureRootRequestsRejected() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getFeatureRootRequestsRejected().subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }

    //Menu Code – Hide the browser default context menu when right click inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {
        console.log("itemclick", this.selectedRowIndex);

        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index
        console.log(gridData);
        console.log(menuItem); // Get the Menu Item name    
        if (gridData != undefined) {
            switch (menuItem) {
                case "Delete Feature":
                    this.featureRequestDelete(gridData.id);
                    break;
                case "Modify Feature":
                    this.featureRequestModify(gridData.id);
                    break;
            }
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.selectedRowIndex = "";
            console.log("Row click", event.args.rowindex);
            this.selectedRowIndex = event.args.rowindex;
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            //this.myMenu.open(100, 100);
            return false;
        }
        //}
    }

    featureRequestDelete(featureId: number): void {
        var url = "";
        var title = "";
        var height = "620px";
        var width = "90%";
        url = "/IPulsar/Features/FeatureProperties.aspx?FeatureID=" + featureId + "&app=PulsarPlus";
        title = "Delete Feature Request";

        showPopup(url, title, height, width);
    }

    featureRequestModify(featureId: number): void {
        var url = "";
        var title = "";
        var height = "620px";
        var width = "90%";
        url = "/excalibur/pmr/softpaqframe.asp?Title=Modify Feature Request&Page=/IPulsar/Features/FeatureProperties.aspx&FromModule=1&FeatureID=" + featureId + "&app=PulsarPlus";
        title = "Modify Feature Request";
        showPopup(url, title, height, width);
    }


}

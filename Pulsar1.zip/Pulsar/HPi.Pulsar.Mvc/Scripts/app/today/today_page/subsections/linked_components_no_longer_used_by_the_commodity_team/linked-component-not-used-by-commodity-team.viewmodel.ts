﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc.
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 05-23-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="linked-component-not-used-by-commodity-team.viewmodel.ts" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

export class LinkedComponentsNotUsedByCommodityTeamViewModel {
    id: string;
    deliverableId: string;
    productId: Date;
    dotsName: string;
    deliverableName: string;
    modelNumber: string;
    partNumber: string;
    version: string;
    userId: string;
}
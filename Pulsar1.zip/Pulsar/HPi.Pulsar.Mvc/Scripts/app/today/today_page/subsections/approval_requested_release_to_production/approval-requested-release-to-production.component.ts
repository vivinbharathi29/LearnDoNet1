﻿import { Component, ViewChild, AfterViewInit ,NgZone} from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { ApprovalRequestedReleaseToProductionService } from './approval-requested-release-to-production.service';
import { jqxMenuComponent } from '../../../../jqwidgets-ts/angular_jqxmenu';
import { Router, ActivatedRoute, Params, NavigationExtras } from '@angular/router'
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';

@Component({
    selector: 'approval-requested-release-to-production',
    templateUrl:'./approval-requested-release-to-production.component.html'
})

export class ApprovalRequestedReleaseToProductionComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    @ViewChild('menuReference') myMenu: jqxMenuComponent;
    public selectedRowIndex: string;
    public title: string;
    mbp: MessageBoxButton;

    MultiDeveloperSignoffCallback(result) {
        if (typeof (result) != undefined) {
            if (result > 0) {
                this.reloadGrid();
            }
        }
    }

    constructor(http: Http, private service: ApprovalRequestedReleaseToProductionService, private messageBox: MessageBox, private _ngZone: NgZone, private router: Router) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.MultiDeveloperSignoffCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.datafields = [
            { name: 'id', map: 'id' },            
            { name: 'strMITTestStatus', map: 'mitTestStatus' },
            { name: 'strODMTestStatus', map: 'odmTestStatus' },
            { name: 'strWWANTestStatus', map: 'wwanTestStatus' },
            { name: 'strtargetDate', map: 'targetDate' },
            { name: 'product', map: 'product' },
            { name: 'vendor', map: 'vendor' },
            { name: 'strVersion', map: 'version' },
            { name: 'modelNumber', map: 'modelNumber' },
            { name: 'partNumber', map: 'partNumber' },
            { name: 'deliverableID', map: 'deliverableID' },
            { name: 'productID', map: 'productID' },
            { name: 'rootID', map: 'rootID' },
            { name: 'productDeliverableReleaseID', map: 'productDeliverableReleaseID' }
        ];

        this.jqxGridConfig.columns = [
            {
                text: 'ID', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'id', width: "10%", hidden: true,
            },
            {
                text: 'Deliverable Version Id', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'deliverableID', width: "10%",
            },
            {
                text: 'MIT', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'strMITTestStatus', width: "10%", 
            },
            {
                text: 'ODM', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'strODMTestStatus', width: "10%", filtertype: 'input' 
            },
            {
                text: 'WWAN', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'strWWANTestStatus', cellsalign: 'left', align: 'left', width: "10%", filtertype: 'input' 
            },
            {
                text: 'Target', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'strtargetDate', cellsalign: 'left', align: 'left', width: "10%", filtertype: 'date', cellsformat: 'MM/dd/yyyy'
            },
            {
                text: 'Product', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'product', cellsalign: 'left', align: 'left', width: "13%", filtertype: 'input' 
            },
            {
                text: 'Vendor', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'vendor', cellsalign: 'left', align: 'left', width: "12%" , filtertype: 'input'
            },
            {
                text: 'Component', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'strVersion', cellsalign: 'left', align: 'left', width: "35%" , filtertype: 'input' 
            },
            {
                text: 'Model', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'modelNumber', cellsalign: 'left', align: 'left', width: "20%", filtertype: 'input'
            }
            ,
            {
                text: 'PartNumber', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'partNumber', cellsalign: 'left', align: 'left', width: "12%" , filtertype: 'input'
            },
            {
                text: 'productDeliverableReleaseID', columngroup: 'OpenSupportTicketsISubmitted',
                datafield: 'productDeliverableReleaseID', hidden: true, width: "12%", filtertype: 'input'
            }           
        ];

    }

    reloadGrid(): void {
        this.myGrid.clearselection();
        this.getApprovalRequestedReleaseToProduction();
    }

    getApprovalRequestedReleaseToProduction() {
        this.myGrid.showdefaultloadelement(true);
        this.service.getApprovalRequestedReleaseToProduction().subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    ngAfterViewInit(): void {
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        this.getApprovalRequestedReleaseToProduction();
        this.myMenu.createComponent(this.MenuSettings);
    }

    onPageChanged(event: any): void {        
        this.myGrid.clearselection();
    }

    //Menu Code – Menu popup display settings
    MenuSettings: jqwidgets.MenuOptions =
    {
        width: '200px', height: '90px', mode: 'popup', autoOpenPopup: false, //this autoOpenPopup property fixed the menu position to display on grid row

    };

    //Menu Code – Hide the browser default context menu when right cliuck inside grid.
    contextmenu(): boolean {
        return false;
    }

    //Menu code - Item click Sample --- Use this method instead of individual menu item click
    menuItemClick(event: any): void {

        let rowIndex: number;
        let menuItem: string = "";
        let args: any;
        let gridData: any;
        args = event.args;
        menuItem = $(args).text();
        gridData = this.myGrid.getrowdatabyid(this.selectedRowIndex);// get the Row data based on the row index

        switch (menuItem) {
            case "Approve Release":
                this.displayHWDeveloperSignoff(gridData.id, gridData.productDeliverableReleaseID, 1);
                break;
            case "Reject Release":
                this.displayHWDeveloperSignoff(gridData.id, gridData.productDeliverableReleaseID, 2);
                break;
            case "Properties":
                this.deliverableProperties(gridData.deliverableID);
                break;           
        }
    }

    onRowClick(event: any): boolean {
        if (event.args.rightclick) {
            this.selectedRowIndex = "";
            this.selectedRowIndex = event.args.rowindex;
            this.myGrid.selectrow(event.args.rowindex);
            var scrollTop = $(window).scrollTop();
            var scrollLeft = $(window).scrollLeft();
            this.myMenu.open(parseInt(event.args.originalEvent.clientX) + 5 + scrollLeft, parseInt(event.args.originalEvent.clientY) + 5 + scrollTop);
            return false;
        }
    }


    deliverableProperties(versionId: number) {       
        var strDisplay;
        var url;
        var title;
        var height;
        var width;        
        title = "Component Version Properties";
        height = 650;
        width = 750;
        var strResult;
        url = "/Excalibur/WizardFrames.asp?Type=1&ID=" + versionId + "&app=PulsarPlus";
        showPopup(url, title, height, width);
    }

    displayHWDeveloperSignoff(id: any, productDeliverableReleaseID: number, statusID: any): void {
        
        var selectedIndices = this.myGrid.selectedrowindexes();
        var url;
        var title;
        var height;
        var width;
        var typeID = 2;        
        title = "HW Developer Signoff";
        height = "350px";
        width = "600px";
        var strResult;
        id = id + "_" + productDeliverableReleaseID;
        //url = "/Excalibur/UpdateDevStatus.asp?ID=" + id + "&StatusID=" + statusID + "&TypeID=2" + "&app=PulsarPlus";        
        //showPopup(url, title, height, width); 
        this.router.navigate([{ outlets: { 'externalpopupWindow': ['updatedeliverablestatus', id, statusID, typeID] } }]);
        modalPopup.show('#externalpagepopup', "60%", "440px", "HW Developer Signoff");       
    }
    numCallback = (response: MessageBoxButton): void => {

        this.mbp = response;
        //if (this.mbp == MessageBoxButton.Yes) {
        //    alert(this.mbp.toString());
        //}
        //else if (this.mbp == MessageBoxButton.No) {
        //    alert(this.mbp.toString());
        //}
        //else if (this.mbp == MessageBoxButton.Ok) {
        //    alert(this.mbp.toString());
        //}
        //else if (this.mbp == MessageBoxButton.Cancel) {
        //    alert(this.mbp.toString());
        //}
    }
    multiDeveloperSignoff(strValue) {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var idList = "";
        var idListForUpdate = "";
        var index: number;
        var rowcount: any;

        //for (index = 0; index < selectedIndices.length; index++) {
        //    idList += this.myGrid.getrowdata(selectedIndices[index]).id + ",";
        //    idListForUpdate += this.myGrid.getrowdata(selectedIndices[index]).id + "_" + this.myGrid.getrowdata(selectedIndices[index]).productDeliverableReleaseID + ",";
        //}

        var dataInfo = this.myGrid.getdatainformation();
        var paginationInfo = dataInfo.paginginformation;
        rowcount = dataInfo.rowscount;
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = Math.min(rowcount, (paginationInfo.pagenum + 1) * paginationInfo.pagesize) - (paginationInfo.pagenum * paginationInfo.pagesize);
        var startIndex = paginationInfo.pagenum * paginationInfo.pagesize;
        var endIndex = startIndex + displayRowsLength - 1;
        if (displayRowsLength < paginationInfo.pagesize) {
            endIndex = startIndex + displayRowsLength - 1;
        }        

        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                idList += displayRows[index].id + ",";
                idListForUpdate += displayRows[index].id + "_" + displayRows[index].productDeliverableReleaseID + ",";
            }
        }
        console.log("checked", idList);
        if (idList == "") {
            this.messageBox.Show("Approval Requested - Release to Production", "Please check at least one request and try again'", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
           // alert("Please check at least one request and try again");
        }
        else {
            idList = idList.slice(0, idList.length - 1); // Remove last two characters: comma and space
            var url = "";
            var title = "";
            var height = "600px";
            var width = "90%";
            //url = "/excalibur/Deliverable/MultiDevApproval.asp?NewValue=" + strValue + "&txtMultiID=" + idList + "&app=PulsarPlus";
            //title = "Update Developer Approval";
            //showPopup(url, title, height, width);
            this.router.navigate([{ outlets: { 'externalpopupWindow': ['updatedeveloperapproval', strValue, idList, idListForUpdate] } }]);
            modalPopup.show('#externalpagepopup', "80%", "480px", "Batch Dev Approval");      
        }
    }
    
}


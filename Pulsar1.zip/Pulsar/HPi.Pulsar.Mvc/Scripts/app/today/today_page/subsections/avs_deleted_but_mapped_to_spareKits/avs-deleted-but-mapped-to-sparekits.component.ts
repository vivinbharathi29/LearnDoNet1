﻿import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { AvsDeletedButMappedtoSparekitsService } from './avs-deleted-but-mapped-to-sparekits.service';

@Component({
    selector: 'avs-deleted-but-mapped-to-sparekits',
    templateUrl:'./avs-deleted-but-mapped-to-spareKits.component.html',
    providers: [AvsDeletedButMappedtoSparekitsService]
})

export class AvsDeletedButMappedtoSparekitsComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public userId: number;
    constructor(private http: Http, private service: AvsDeletedButMappedtoSparekitsService) {

        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.selectionmode = 'checkbox';
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.datafields = [
            { name: 'productName', map: 'productName' },
            { name: 'avDetailId', map: 'avDetailId' },            
            { name: 'avNo', map: 'avNo' },
            { name: 'category', map: 'category' },
            { name: 'brand', map: 'brand' },
            { name: 'gpgDescription', map: 'gpgDescription' },
            { name: 'deleted', map: 'deleted' }
        ];

        this.jqxGridConfig.columns = [
            { text: 'Product Name', filtertype: 'input', datafield: 'productName', width: '10%' },
            { text: 'AV Detail', filtertype: 'number', datafield: 'avDetailId', hidden: true },
            { text: 'AV Number', filtertype: 'input', datafield: 'avNo', width: '15%' },
            { text: 'Feature Category', filtertype: 'input', datafield: 'category', width: '15%' },
            { text: 'Brand', filtertype: 'input', datafield: 'brand', width: '15%' },
            { text: 'GPG Description', filtertype: 'input', datafield: 'gpgDescription', width: '27.98%' },
            { text: 'Deleted', datafield: 'deleted', width: '14.8%', filtertype: 'date', cellsformat: 'MM/dd/yyyy h:mm:ss tt', },
        ];

        this.jqxGridConfig.columnTypes = {
            'productName': FilterColumnTypeEnum.String,
            'avDetailId': FilterColumnTypeEnum.Number,
            'avNo': FilterColumnTypeEnum.String,
            'category': FilterColumnTypeEnum.String,
            'brand': FilterColumnTypeEnum.String,
            'gpgDescription': FilterColumnTypeEnum.String,
            'deleted': FilterColumnTypeEnum.Date
        }

    }
    getSpareKitsNotMappedtoAvs(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getAvsDeletedbutMappedtoSpareKits(paginationInfo).subscribe(
            (res: Response) => {
                this.jqxGridConfig.localdata = res.json();
                if (res.json().length!=0)
                {
                    this.userId = res.json()[0].userId;
                }
                this.myGrid.updatebounddata(null);
                this.myGrid.hideloadelement();
            });
    }
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getSpareKitsNotMappedtoAvs(paginationInfo);
        this.myGrid.clearselection();
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getSpareKitsNotMappedtoAvs(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getSpareKitsNotMappedtoAvs(paginationInfo);
    }


    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getSpareKitsNotMappedtoAvs(paginationInfo);
    }

    reloadGrid(): void {
        this.myGrid.clearselection();
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getSpareKitsNotMappedtoAvs(paginationInfo);
    }

    bUpdateAVsDeletedMapped(userId: number): void {
        var selectedIndices = this.myGrid.selectedrowindexes();
        var idList = "";
        var index: number;
        let param: string = "";

        //for (index = 0; index < selectedIndices.length; index++) {
        //    idList += this.myGrid.getrowdata(selectedIndices[index]).avDetailId + ",";
        //}

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        var displayRows = this.myGrid.getdisplayrows();
        var displayRowsLength = this.myGrid.getrows().length;
        var startIndex = (paginationInfo.PageNo) * paginationInfo.PageSize;
        var endIndex = startIndex + paginationInfo.PageSize - 1;
        if (displayRowsLength < paginationInfo.PageSize) {
            endIndex = startIndex + displayRowsLength - 1;
        }
        for (index = startIndex; index <= endIndex; index++) {
            if (selectedIndices.indexOf(displayRows[index].boundindex) != -1) {
                idList += displayRows[index].avDetailId + ",";
            }
        }

        if (idList == "") {
            alert("You must select the AVs Deleted mapped to unmapped first.");
        }
        else {
            idList = idList.slice(0, idList.length - 1); // Remove last two characters: comma and space
            param = "function=UpdateDeletedAvMappedToSPS&avDetailId=" + idList + "&UserID=" + userId + "";
            this.service.updateDeletedAvMappedToSPS(param).subscribe(
                (res: Response) => {
                    this.myGrid.clearselection();
                    this.reloadGrid();
                },
                error => {
                });
        }
    }
}


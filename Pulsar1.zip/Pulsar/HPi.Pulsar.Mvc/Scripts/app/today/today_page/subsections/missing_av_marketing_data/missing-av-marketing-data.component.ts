﻿/// <reference path="../../../../jqwidgets-ts/angular_jqxdatetimeinput.ts" />
import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response, URLSearchParams } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { MissingAVMarketingDataService } from './missing-av-marketing-data.service';
import { MissingAVMarketingDataViewModel } from './missing-av-marketing-data-view-model';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import { UserInfoService } from '../../dashboard/user-info.service';
import 'rxjs/add/operator/map';
import { Router, ActivatedRoute, Params } from '@angular/router'
import { MessageBox, MessageBoxButton, MessageBoxType, MessageBoxIcon } from '../../../../shared/messagebox/index';
import { jqxDateTimeInputComponent } from '../../../../jqwidgets-ts/angular_jqxdatetimeinput';
@Component({
    selector: 'missing-marketing-data',
    templateUrl:'./missing-av-marketing-data.component.html'
})    

export class MissingAVMarketingDataComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    @ViewChild('myDateTimeInput') myDateTimeInput: jqxDateTimeInputComponent;
     nestedgrids: jqxGridComponent[];
    public currentUserName: string = "";
    jqxGridConfig: jqxGridConfiguration;
    childJqxGridConfig: jqxGridConfiguration;
    public missingAVMarketingData: MissingAVMarketingDataViewModel[];
    daysUntil: number;
    public title: string;
    mbp: MessageBoxButton;
    userName: string = "";
    public childData: any[]
    constructor(http: Http, private service: MissingAVMarketingDataService, private userInfoService: UserInfoService, private activatedRoute: ActivatedRoute, private _ngZone: NgZone, private messageBox: MessageBox) {

        //this.userInfoService.getImpersonateName().subscribe(result => {
        //    this.title = result.json().title;
        //    this.userName = result.json().userName //this.currentUserName;
        //});
        this.activatedRoute.queryParams.subscribe((params: Params) => {
            this.currentUserName = params['CurrentUserName'];
        });
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            UpdateMarketingAvDataCallbackFn: (value, txtAvailabilityDate, txtDiscontinueDate) => this.UpdateMarketingAvDataCallback(value, txtAvailabilityDate, txtDiscontinueDate),
            component: this
        };

        this.jqxGridConfig = new jqxGridConfiguration();
        //this.jqxGridConfig.width = 1000;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightOneLineLinks;
        this.jqxGridConfig.virtualmode = true;
        //this.jqxGridConfig.selectionmode = 'checkbox';

        /*Nested Functionilty*/
        this.childJqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.datafields = [
            { name: 'avFeatureCategory', map: 'avFeatureCategory' },
            { name: 'avNo', map: 'avNo' },
            { name: 'gpgDescription', map: 'gpgDescription' },
            { name: 'rtpDate', map: 'rtpDate' },
            { name: 'rasDiscontinueDate', map: 'rasDiscontinueDate' },
            { name: 'bid', map: 'bid' },
            { name: 'avDetailID', map: 'avDetailID' },
            { name: 'daysUntil', map: 'daysUntil' },
            { name: 'dotsBrandName', map: 'dotsBrandName' }

        ];

        this.jqxGridConfig.columns = [
            { text: 'AV SCM/Feature Category', filtertype: 'input', datafield: 'avFeatureCategory', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'AV No.', filtertype: 'input', datafield: 'avNo', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'GPG Description', filtertype: 'input', datafield: 'gpgDescription', cellsalign: 'left', align: 'left', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'RTP/MR Date', filtertype: 'date', cellsformat: 'MM/dd/yyyy', datafield: 'rtpDate', align: 'left', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'End of Manufacturing', filtertype: 'date', cellsformat: 'MM/dd/yyyy', datafield: 'rasDiscontinueDate', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'bid', filtertype: 'input', datafield: 'bid', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'avdetailid', filtertype: 'input', datafield: 'avDetailID', cellsalign: 'left', width: "20%", cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'Product Name', filtertype: 'input', datafield: 'dotsBrandName', cellsalign: 'left', width: "60%", cellsrenderer: this.cellsrenderer },
            { text: 'Days Until', filtertype: 'number', datafield: 'daysUntil', cellsalign: 'left', width: "40%", cellsrenderer: this.cellsrenderer }

        ];

        this.jqxGridConfig.columnTypes = {
            'avFeatureCategory': FilterColumnTypeEnum.String,
            'avNo': FilterColumnTypeEnum.String,
            'gpgDescription': FilterColumnTypeEnum.String,
            'rtpDate': FilterColumnTypeEnum.Date,
            'rasDiscontinueDate': FilterColumnTypeEnum.Date,
            'bid': FilterColumnTypeEnum.Number,
            'avDetailID': FilterColumnTypeEnum.Number,
            'daysUntil': FilterColumnTypeEnum.Number,
            'dotsBrandName': FilterColumnTypeEnum.String
        }

        this.childJqxGridConfig.datafields = [
            { name: 'avFeatureCategory', map: 'avFeatureCategory' },
            { name: 'avNo', map: 'avNo' },
            { name: 'gpgDescription', map: 'gpgDescription' },
            { name: 'rtpDate', map: 'rtpDate' },
            { name: 'rasDiscontinueDate', map: 'rasDiscontinueDate' },
            { name: 'bid', map: 'bid' },
            { name: 'avDetailID', map: 'avDetailID' }
        ];

        this.childJqxGridConfig.columns = [
            { text: 'AV SCM/Feature Category', filtertype: 'input', datafield: 'avFeatureCategory', cellsalign: 'left', width: 200, cellsrenderer: this.cellsrenderer },
            { text: 'AV No.', filtertype: 'input', datafield: 'avNo', width: 200, cellsrenderer: this.cellsrenderer },
            { text: 'GPG Description', filtertype: 'input', datafield: 'gpgDescription', cellsalign: 'left', align: 'left', width: 200, cellsrenderer: this.cellsrenderer },
            { text: 'RTP/MR Date', filtertype: 'date', cellsformat: 'MM/dd/yyyy', datafield: 'rtpDate', align: 'left', cellsalign: 'left', width: 200, cellsrenderer: this.cellsrenderer },
            { text: 'End of Manufacturing', filtertype: 'date', cellsformat: 'MM/dd/yyyy', datafield: 'rasDiscontinueDate', cellsalign: 'left', width: 200, cellsrenderer: this.cellsrenderer },
            { text: 'bid', filtertype: 'input', datafield: 'bid', cellsalign: 'left', width: 200, cellsrenderer: this.cellsrenderer, hidden: true },
            { text: 'avdetailid', filtertype: 'input', datafield: 'avDetailID', cellsalign: 'left', width: 200, cellsrenderer: this.cellsrenderer, hidden: true }
        ];

        this.childJqxGridConfig.columnTypes = {
            'avFeatureCategory': FilterColumnTypeEnum.String,
            'avNo': FilterColumnTypeEnum.String,
            'gpgDescription': FilterColumnTypeEnum.String,
            'rtpDate': FilterColumnTypeEnum.Date,
            'rasDiscontinueDate': FilterColumnTypeEnum.Date,
            'bid': FilterColumnTypeEnum.Number,
            'avDetailID': FilterColumnTypeEnum.Number
        }

    }

    getMissingAVMarketingData(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getMissingAVMarketingDataService(paginationInfo).subscribe(result => {
            //this.childJqxGridConfig.localdata = result.json();
           this.jqxGridConfig.localdata = result.json();
            //this.childData = result.json();
            
            var data = result.json();
            if (result.json().length > 0) {
                this.userName = result.json()[0]['userName'];
                this.nestedgrids = new Array(result.json()[0]['totalNoOfRows']); //new jqxGridComponent;
                this.daysUntil = data[0].daysUntil;
            }
            console.log(data);
           
            this.myGrid.updatebounddata("data");
            

            this.myGrid.hideloadelement();
        });
    }

    getMissingAVMarketingDataBid(bid) {
        var paginationInfo = new PaginationModel();
        paginationInfo.PageNo = 0;
        paginationInfo.PageSize = 50;
        //this.myGrid.showdefaultloadelement(true);
        this.service.getMissingAVMarketingDataBIDService(paginationInfo, bid);
        
    }
    /********* the below event is fired whenever page number is changed
             Call the service method here and refresh the grid.
     *************/
    onPageChanged(event: any): void {
        
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingAVMarketingData(paginationInfo);
        //this.getProducts(paginationInfo);

    }

    onSortChanged(event: any): void {

        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingAVMarketingData(paginationInfo);

    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingAVMarketingData(paginationInfo);
    }

    ngAfterViewInit(): void {

        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getMissingAVMarketingData(paginationInfo);
        
        this.userInfoService.getImpersonateName().subscribe(result => {
            
            this.title = result.json().title;
        });
    }


    cellsrenderer = (row: any, columnfield: any, value: any, defaulthtml: any, columnproperties: any, rowdata: any) => {

        //  return "<a class='jqx-anchor-hover'   href='javascript:alert(\"" + rowdata.UnitPrice + "\");' /> " + value + "</a>";
        // return "<a class='jqx-anchor-hover'  href='javascript:unassignedotsrows_onclick(" + rowdata.id + " );' /> " + value + "</a>";

    };
    ValidateRASDiscDate() {
        //var dt=document.frmSample.txtDate
        var txtDiscontinueDate = (<HTMLInputElement>document.getElementById("txtEditDiscontinueDate")).value;
        if ((txtDiscontinueDate) != "") {
            if (this.isDate(txtDiscontinueDate) == false) {
               // txtDiscontinueDate.focus()
                return false
            }
        }
        return true
        //if (txtDiscontinueDate == "") {
        //    //txtDiscontinueDate.focus()
        //    return false
    }
       
    DaysArray(n) {
        for (var i = 1; i <= n; i++) {
            this[i] = 31
            if (i == 4 || i == 6 || i == 9 || i == 11) { this[i] = 30 }
            if (i == 2) { this[i] = 28 }
        }
        return this
    }

    isInteger(s) {
        var i;
        for (i = 0; i < s.length; i++) {
            // Check that current character is number.
            var c = s.charAt(i);
            if (((c < "0") || (c > "9"))) return false;
        }
        // All characters are numbers.
        return true;
    }

    stripCharsInBag(s, bag) {
        var i;
        var returnString = "";
        // Search through string's characters one by one.
        // If character is not in bag, append to returnString.
        for (i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (bag.indexOf(c) == -1) returnString += c;
        }
        return returnString;
    }


    isDate(dtStr) {
        var dtCh = "/";
        var minYear = 1900;
        var maxYear = 2100;
        var daysInMonth = this.DaysArray(12)
        var pos1 = dtStr.indexOf(dtCh)
        var pos2 = dtStr.indexOf(dtCh, pos1 + 1)
        var strMonth = dtStr.substring(0, pos1)
        var strDay = dtStr.substring(pos1 + 1, pos2)
        var strYear = dtStr.substring(pos2 + 1)
        var strYr = strYear
        if (strDay.charAt(0) == "0" && strDay.length > 1) strDay = strDay.substring(1)
        if (strMonth.charAt(0) == "0" && strMonth.length > 1) strMonth = strMonth.substring(1)
        for (var i = 1; i <= 3; i++) {
            if (strYr.charAt(0) == "0" && strYr.length > 1) strYr = strYr.substring(1)
        }
        var month = parseInt(strMonth)
        var day = parseInt(strDay)
        var year = parseInt(strYr)

        if (pos1 == -1 || pos2 == -1) {
            this.messageBox.Show("Missing AV Marketing Data", "The date format should be : mm/dd/yyyy", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            return false
        }
        if (strMonth.length < 1 || month < 1 || month > 12) {
            this.messageBox.Show("Missing AV Marketing Data", "Please enter a valid month", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            return false
        }
        if (strDay.length < 1 || day < 1 || day > 31 || (month == 2 && day != 28) || day != daysInMonth[month]) {
            this.messageBox.Show("Missing AV Marketing Data", "The End of Manufacturing must be the last day of the month", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            return false
        }
        if (strYear.length != 4 || year == 0 || year < minYear || year > maxYear) {
            this.messageBox.Show("Missing AV Marketing Data", "Please enter a valid 4 digit year between", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            return false
        }
        if (dtStr.indexOf(dtCh, pos2 + 1) != -1 || this.isInteger(this.stripCharsInBag(dtStr, dtCh)) == false) {
            this.messageBox.Show("Missing AV Marketing Data", "Please enter a valid date", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            return false
        }

        var parsedDate = Date.parse(dtStr);
        var today = new Date().getTime();

        if (parsedDate < today) {
            this.messageBox.Show("Missing AV Marketing Data", "The End of Manufacturing must not be in the past", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            return false
        }
        return true
    }

    stringToDate(_date, _format, _delimiter) {
        
        var formatLowerCase = _format.toLowerCase();
        var formatItems = formatLowerCase.split(_delimiter);
        var dateItems = _date.split(_delimiter);
        var monthIndex = formatItems.indexOf("mm");
        var dayIndex = formatItems.indexOf("dd");
        var yearIndex = formatItems.indexOf("yyyy");
        var month = parseInt(dateItems[monthIndex]);
        month -= 1;
        var formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex]);
        return formatedDate;
    }


    cmdUpdateMarketingAvData_onclick(CurrentUser) {
        
        var txtAvailabilityDate = (<HTMLInputElement>document.getElementById("txtEditAvailabilityDate")).value; // document.getElementById("txtEditAvailabilityDate");
        var txtDiscontinueDate = (<HTMLInputElement>document.getElementById("txtEditDiscontinueDate")).value; // document.getElementById("txtEditDiscontinueDate");
        var testDateStr = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;

        if (this.ValidateRASDiscDate() == true) {
            var SelectedAvs = "";
            var i;

            if ((txtAvailabilityDate) == "" && (txtDiscontinueDate) == "") {
                this.messageBox.Show("Missing AV Marketing Data", "Please Enter A Date(s) Prior To Updating The Selected AV's", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            }
            else if ((txtAvailabilityDate) != "" && !(testDateStr.test(txtAvailabilityDate))) {
                this.messageBox.Show("Missing AV Marketing Data", "RTP/MR Date must be in mm/dd/yyyy format.", MessageBoxType.Ok, MessageBoxIcon.Information, "400", this.numCallback)
            }
            else {
                for (var gridIndex = 0; gridIndex < this.nestedgrids.length; gridIndex++) {
                    if (this.nestedgrids[gridIndex] != undefined) {
                        var selectedIndices = this.nestedgrids[gridIndex].selectedrowindexes;
                        let parameters = new URLSearchParams();
                        this.myGrid.showdefaultloadelement(true);
                        for (var index = 0; index < selectedIndices.length; index++) {
                        parameters.set("RTPDate", txtAvailabilityDate);
                        parameters.set("DiscontinueDate", txtDiscontinueDate);
                        parameters.set("AVDetailID", this.nestedgrids[gridIndex].getrowdata(selectedIndices[index]).avDetailID);
                        parameters.set("BID", this.nestedgrids[gridIndex].getrowdata(selectedIndices[index]).bid);
                        this.service.updateMissingAVMarketingDataService(parameters)
                                .subscribe(result => {
                                    if (result.text) {
                                        var paginationInfo: PaginationModel;
                                        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                                        this.getMissingAVMarketingData(paginationInfo);
                                        this.myGrid.clearselection();
                                        (<HTMLInputElement>document.getElementById("txtEditAvailabilityDate")).value = "";
                                        (<HTMLInputElement>document.getElementById("txtEditDiscontinueDate")).value = "";
                                    }
                                });
                        }
                    }
                }
                this.myGrid.hideloadelement();
            }

        }
    }


    UpdateMarketingAvDataCallback(CurrentUser, txtAvailabilityDate, txtDiscontinueDate) {
        for (var gridIndex = 0; gridIndex < this.nestedgrids.length; gridIndex++) {
            if (this.nestedgrids[gridIndex] != undefined) {
                var selectedIndices = this.nestedgrids[gridIndex].selectedrowindexes;
                let parameters = new URLSearchParams();
                this.myGrid.showdefaultloadelement(true);
                for (var index = 0; index < selectedIndices.length; index++) {
                    parameters.set("RTPDate", txtAvailabilityDate);
                    parameters.set("DiscontinueDate", txtDiscontinueDate);
                    parameters.set("AVDetailID", this.nestedgrids[gridIndex].getrowdata(selectedIndices[index]).avDetailID);
                    parameters.set("BID", this.nestedgrids[gridIndex].getrowdata(selectedIndices[index]).bid);
                    this.service.updateMissingAVMarketingDataService(parameters)
                        .subscribe(result => {
                            if (result.text) {
                                var paginationInfo: PaginationModel;
                                paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
                                this.getMissingAVMarketingData(paginationInfo);
                                this.myGrid.clearselection();
                                (<HTMLInputElement>document.getElementById("txtEditAvailabilityDate")).value = "";
                                (<HTMLInputElement>document.getElementById("txtEditDiscontinueDate")).value = "";
                            }
                        });
                }
            }
        }
        this.myGrid.hideloadelement();
    }


    numCallback = (response: MessageBoxButton): void => {
        this.mbp = response;
    }
    //nestedGrids: any[] ;
    // create nested grid.
    initRowDetails: any = (index: number, parentElement: any, gridElement: any, record: any): void => {        
        let id = record.bid.toString();
        let nestedGridContainer = parentElement.children[0];
        //this.nestedGrids[index] = nestedGridContainer;
        let filtergroup = new $.jqx.filter();
        let filter_or_operator = 1;
        let filtervalue = id;
        let filtercondition = 'equal';
        let filter = filtergroup.createfilter('stringfilter', filtervalue, filtercondition);
        // fill the orders depending on the id.
        var paginationInfo = new PaginationModel();
        paginationInfo.PageNo = 0;
        paginationInfo.PageSize = 50;
        this.service.getMissingAVMarketingDataBIDService(paginationInfo, id).subscribe(result => {

            let missingAvMarketingDatas = result.json(); //this.childData;//this.ordersDataAdapter.records;
            console.log("missing", missingAvMarketingDatas);
            let ordersbyid = [];
            let missingAvMarketingSource = {
                datafields: [
                    { name: 'avFeatureCategory', type: 'string' },
                    { name: 'avNo', type: 'string' },
                    { name: 'gpgDescription', type: 'string' },
                    { name: 'rtpDate', type: 'date' },
                    { name: 'rasDiscontinueDate', type: 'date' },
                    { name: 'bid', type: 'string' },
                    { name: 'avDetailID', type: 'string' }
                ],
                id: 'bid',
                localdata: missingAvMarketingDatas
            }
            let nestedGridAdapter = new $.jqx.dataAdapter(missingAvMarketingSource);
            if (nestedGridContainer != null) {

                let settings = {
                    width: 900,
                    height: 200,
                    source: missingAvMarketingSource,
                    pageable: false,
                    pagesize: 50,
                    pagesizeoptions: ['10', '50', '100', '250', '500', '1000'],
                    selectionmode: 'checkbox',
                    theme: "energyblue",
                    columnsheight : 64,
                    columns: [
                        { text: 'AV SCM/<br/>Feature Category', name: 'AV SCM/Feature Category', datafield: 'avFeatureCategory', width: 120  },
                        { text: 'AV No.', name: 'AV No.', datafield: 'avNo', width: 90 },
                        { text: 'GPG Description', name: 'GPG Description', datafield: 'gpgDescription', width: 350 },
                        { text: 'RTP/MR Date', name: 'RTP/MR Date', datafield: 'rtpDate', width: 140, type: 'date', cellsFormat: 'MM/dd/yyyy' },
                        { text: 'End of<br/> Manufacturing', name: 'End of Manufacturing', datafield: 'rasDiscontinueDate', width: 150, type: 'date', cellsFormat: 'MM/dd/yyyy' },
                        {  name: 'bid', datafield: 'bid', hidden: true },
                        {  name: 'avDetailID', datafield: 'avDetailID', hidden: true }
                    ],

                };
                this.nestedgrids[index] = jqwidgets.createInstance(`#${nestedGridContainer.id}`, 'jqxGrid', settings)
               
            }
        });

      
    }
    
    photoRenderer = (row: number, column: any, value: string): string => {
        let name = this.myGrid.getrowdata(row).FirstName;
        let imgurl = '../../images/' + name.toLowerCase() + '.png';
        let img = '<div style="background: white;"><img style="margin:2px; margin-left: 10px;" width="32" height="32" src="' + imgurl + '"></div>';
        return img;
    }

    renderer = (row: number, column: any, value: string): string => {
        return '<span style="margin-left: 4px; margin-top: 9px; float: left;">' + value + '</span>';
    }

    rowdetailstemplate: any = { rowdetails: "<div id='grid' style='margin: 10px;'></div>", rowdetailsheight: 220, rowdetailshidden: true };

    ready: any = () => {
        this.myGrid.showrowdetails(1);
    };

}


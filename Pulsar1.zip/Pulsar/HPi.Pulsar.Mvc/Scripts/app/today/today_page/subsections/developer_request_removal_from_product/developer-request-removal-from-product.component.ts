﻿// **********************************************************************************************************
// Assembly         : HPi.Pulsar.Mvc
// Author           : Shanmugaraj.M
// Created          : 04/27/2017
// Last Modified By : Shanmugaraj.M
// Last Modified On : 02/15/2018
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="developer-request-removal-from-product.component.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

import { Component, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { jqxGridComponent } from '../../../../jqwidgets-ts/angular_jqxgrid';
import { jqxGridConfiguration } from '../../../../shared/jqxgrid_helper/jqxgrid-configuration';
import { Location } from '@angular/common';
import { PaginationModel } from '../../../../shared/pagination/pagination.model';
import { FilterColumnTypeEnum } from '../../../../shared/pagination/filter-column-type-enum';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { DeveloperRequestRemovalFromProductService } from './developer-request-removal-from-product.service';
import { DeveloperRequestRemovalFromProductViewModel } from './developer-request-removal-from-product.viewmodel';
import { Router } from '@angular/router';

@Component({
    selector: 'developer-requests-removal-from-Product',
    templateUrl: './developer-request-removal-from-product.component.html'
})

export class DeveloperRequestRemovalFromProductComponent implements AfterViewInit {
    @ViewChild('gridReference') myGrid: jqxGridComponent;
    jqxGridConfig: jqxGridConfiguration;
    public developerRequestsRemovalFromProduct: DeveloperRequestRemovalFromProductViewModel[];
    public selectedRowIndex: string;
    PopupCallback(result) {
        if (typeof (result) != "undefined") {
            this.reloadGrid();
        }
    }
    constructor(http: Http, private service: DeveloperRequestRemovalFromProductService, private router: Router, private _ngZone: NgZone, private location: Location) {
        window['angularComponentRef'] = { component: this, zone: _ngZone };
        window['angularComponentRef'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.PopupCallback(value),
            component: this
        };
        window['angularComponentRef_Developerrequest'] = { component: this, zone: _ngZone };
        window['angularComponentRef_Developerrequest'] = {
            zone: this._ngZone,
            popUpCallBackFn: (value) => this.PopupCallback(value),
            component: this
        };
        this.jqxGridConfig = new jqxGridConfiguration();
        this.jqxGridConfig.virtualmode = true;
        this.jqxGridConfig.height = this.jqxGridConfig.gridHeightNoLinks;
        this.jqxGridConfig.settings.rowsheight = 50;
        this.jqxGridConfig.datafields = [
            { name: 'productId', map: 'productId' },
            { name: 'rootId', map: 'rootId' },
            { name: 'versionId', map: 'versionId' },
            { name: 'product', map: 'product', type: 'string' },
            { name: 'component', map: 'component', type: 'string' },
            { name: 'developerTestNotes', map: 'developerTestNotes', type: 'string' },
            { name: 'developer', map: 'developer', type: 'string' },
            { name: 'release', map: 'release', type: 'string' }
        ];

        this.jqxGridConfig.columns = [

            {
                text: 'ProductId', columngroup: 'DeveloperRequestsRemovalFromProduct',
                datafield: 'productId', hidden: true
            },
            {
                text: 'RootId', columngroup: 'DeveloperRequestsRemovalFromProduct',
                datafield: 'rootId', hidden: true
            },
            {
                text: 'VersionId', columngroup: 'DeveloperRequestsRemovalFromProduct',
                datafield: 'versionId', hidden: true
            },
            {
                text: 'Product', columngroup: 'DeveloperRequestsRemovalFromProduct',
                datafield: 'product', width: '10%', filtertype: 'input'
            },
            {
                text: 'Release', columngroup: 'DeveloperRequestsRemovalFromProduct',
                datafield: 'release', cellsalign: 'left', align: 'left', width: '7%', filtertype: 'input'
            },
            {
                text: 'Component', columngroup: 'DeveloperRequestsRemovalFromProduct',
                datafield: 'component', cellsalign: 'left', align: 'left', width: '35%', filtertype: 'input'
            },
            {
                text: 'Reason', columngroup: 'DeveloperRequestsRemovalFromProduct',
                datafield: 'developerTestNotes', cellsalign: 'left', align: 'left', width: '38%', filtertype: 'input'
            },
            {
                text: 'Developer', columngroup: 'DeveloperRequestsRemovalFromProduct',
                datafield: 'developer', cellsalign: 'left', align: 'left', width: '10%', filtertype: 'input'
            }
        ];

        this.jqxGridConfig.columnTypes = {
            'product': FilterColumnTypeEnum.String,
            'component': FilterColumnTypeEnum.String,
            'developerTestNotes': FilterColumnTypeEnum.String,
            'developer': FilterColumnTypeEnum.String,
            'release': FilterColumnTypeEnum.String
        }
    }


    getDeveloperRequestsRemovalFromProduct(paginationInfo: PaginationModel) {
        this.myGrid.showdefaultloadelement(true);
        this.service.getDeveloperRequestsRemovalFromProduct(paginationInfo).subscribe(result => {
            this.jqxGridConfig.localdata = result.json();
            this.myGrid.updatebounddata(null);
            this.myGrid.hideloadelement();
        });
    }

    /********* the below event is fired whenever page number is changed
            Call the service method here and refresh the grid.
    *************/
    onPageChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDeveloperRequestsRemovalFromProduct(paginationInfo);
    }

    onSortChanged(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDeveloperRequestsRemovalFromProduct(paginationInfo);
    }

    onFilter(event: any): void {
        var paginationInfo: PaginationModel;
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDeveloperRequestsRemovalFromProduct(paginationInfo);
    }

    ngAfterViewInit(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDeveloperRequestsRemovalFromProduct(paginationInfo);
    }

    onRowClick(event: any): boolean {
        this.selectedRowIndex = "";
        this.selectedRowIndex = event.args.rowindex;
        var data = this.myGrid.getrowdata(event.args.rowindex);
        if (data != null) {
            var productId = data.productId;
            var versionId = data.versionId;
            var rootId = data.rootId;

            this.AdvancedTarget(productId, versionId, rootId);
        }
        return false;
    }   

    reloadGrid(): void {
        var paginationInfo: PaginationModel;
        this.myGrid.createComponent(this.jqxGridConfig.settings);
        paginationInfo = this.jqxGridConfig.getPaginationModel(this.myGrid);
        this.getDeveloperRequestsRemovalFromProduct(paginationInfo);
    }

    AdvancedTarget(ProductId, VerID, RootID) {
        //var url = "/Excalibur/Target/TargetAdvanced.asp?ProductID=" + ProdID + "&VersionID=" + VerID + "&RootID=" + RootID + "&app=" + "PulsarPlus";

        //var height = iBrowserHeight * 90 / 100;
        //var width = iBrowserWidth * 85 / 100;
        //showPopup(url, title, height, width);
        //this.router.navigate([{ outlets: { 'externalpopupWindow': ['targetadvanced', ProductId, RootID, VerID] } }]);
        var url = this.location.prepareExternalUrl("/product/product/GetTargetDeliverableRootDetails/" + ProductId + "/" + RootID + "/" + VerID + "/false");
        var title = "Target Version";
        var height = "521px";
        var width = "90%";
        //adjustableShowPopup(url, "Target Advanced", "600px", "80%", "565px");
        showPopup(url, title, height, width);
        //modalPopup.show('#externalpagepopup', "80%", "500px", "Target Advanced");
    }
}

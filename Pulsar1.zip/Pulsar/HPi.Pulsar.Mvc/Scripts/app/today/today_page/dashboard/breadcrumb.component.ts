﻿import { Component } from '@angular/core';

@Component({
    selector: 'bread-crumb',
    templateUrl: './breadcrumb.component.html',
})
export class BreadCrumbComponent {
    date: any;
    customdate: any;
    constructor() {
        
        this.date = new Date();
        this.customdate = formatDate(this.date);
    }

}
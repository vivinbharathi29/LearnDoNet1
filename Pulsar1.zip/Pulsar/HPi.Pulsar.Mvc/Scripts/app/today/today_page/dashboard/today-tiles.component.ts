﻿import { Component, Input, ElementRef, AfterViewInit, Output, EventEmitter, SimpleChange, NgZone } from '@angular/core'
import { Http } from '@angular/http'
import { ModalPopupComponent } from '../../../Shared/modal_popup/modal-popup.component'
import { Location } from '@angular/common';
import { Router, NavigationExtras } from '@angular/router'
import { DivisionEnum } from './division-tile.enum';
declare let $: any;
declare var modalPopup: any;
@Component({
    selector: 'today-tiles',
    template: `<div class='col-lg-3 col-md-6' [ngClass]="enableTile=='true'?'displayTile':'hideTile'">
    <div class='ibox float-e-margins'>
<div class="row">
         <a (click)="loadSubsection()" id="section">
        <div class="col-xs-10" style="height:10px">
            <div class='ibox-title-headercolor'>
                <h5 [ngClass]="subSection==31?'odmTest':''">{{ componentTitle }}</h5>
            </div>
           </div> 
        </a>
        <div class="col-xs-2 ibox-title-headercolor" style="margin-left:-15px">
                     <a class='dropdown-toggle' data-toggle='dropdown' id="refresh" href='#' (click)="refreshCount()">
                        <i class='fa fa-refresh pull-right' style='font-size: 14px'></i>
                    </a>
        </div>
       </div>
        <div [ngClass]="{'tile-content-purple' : isMarketing, 'tile-content-green' : isRnd,'tile-content-orange': isSupplyChain,'tile-content-yellow' : isService,'tile-content-gray' : isOthers}">
            <span class='pull-left' style="font-size:small">{{componentDescription}}</span>
            <h3 class='no-margins'>   
            <ng-container *ngIf="showLoading">
                <div class="refreshGif" id="loadingSpinner"><i class="fa fa-spinner fa-spin"></i></div>
            </ng-container>  
            <ng-container *ngIf="!showLoading">           
                <span class='pull-right'>{{totalNoOfRows}}</span>
            </ng-container>
            </h3>
            <br />           
        </div>
    </div>
</div>`,
    //templateUrl:'./today-tiles.component.html',
    styles: [`
.displayTile
{
display:block;
}
.hideTile
{
display:none;
}
.odmTest
{
 font-size:13px !important;
}
`],
})
export class TodayPageTilesComponent {
    @Input('Tiles') componentTitle: string;
    @Input('NoOfRows') totalNoOfRows: string;
    @Input('Url') componentUrl: string;
    @Input('SubSection') subSection: number;
    @Input('EnableTile') enableTile: string = 'false';
    @Input('Division') division: DivisionEnum;
    @Input('CurrentUserSysAdmin') currentUserSysAdmin: boolean;
    @Input('SEPMProductCount') sepmProductCount: number;
    @Input('UserId') userId: number;
    @Input('PopupHeight') popupHeight: string = '600px';
    @Input('PopupWidth') popupWidth: string = '90%';
    @Input('NewComponentTwoCount') newcomponentTwoCount: number;
    @Input('CurrentUserName') CurrentUserName: string;
    @Input('Description') componentDescription: string;
    @Input() impersonatedName: string = "";
    @Output() showTile = new EventEmitter();
    showLoading: boolean = false;

    public headerClass: string;
    public subSectionNumber: string;
    public isMarketing: boolean = false;
    public isSupplyChain: boolean = false;
    public isService: boolean = false;
    public isRnd: boolean = false;
    public isOthers: boolean = false;

    private _ngZone: NgZone;
    refreshCallback(subSection) {
        //this.sectionName = sectionName;
        this.subSection = subSection;
        this.refreshCount();
    }

    constructor(private http: Http, private location: Location, private router: Router, private elementRef: ElementRef, private ngZone: NgZone) {
        this._ngZone = ngZone;
        console.log('test' + this.subSection);
    }
    ngAfterViewInit() {

        window['angularComponentRef_' + this.subSection] = { component: this, zone: this._ngZone };
        window['angularComponentRef_' + this.subSection] = {
            zone: this._ngZone,
            refreshCallBackFn: (subSection) => this.refreshCallback(subSection),
            component: this
        };

        switch (this.division) {
            case DivisionEnum.RandD:
                this.isRnd = true;
                break;
            case DivisionEnum.Marketing:
                this.isMarketing = true;
                break;
            case DivisionEnum.SCM:
                this.isSupplyChain = true;
                break;
            case DivisionEnum.Service:
                this.isService = true;
                break;
            case DivisionEnum.Other:
                this.isOthers = true;
                break;
            default:
                this.isOthers = true;
                //$(this.elementRef.nativeElement).find('#boxContent').addClass("myTeamBrown");
                break;

        }
    }

    ViewPopup(url: string) {
        var width = 100;
        showPopup(url, this.componentTitle, 100, width);
    }
    ngOnChanges(changes: { [propName: string]: SimpleChange }) {
        if (this.totalNoOfRows != undefined) {
            let totalRow: number = 0;
            totalRow = parseInt(this.totalNoOfRows);
            if (totalRow > 0) {
                //console.log(this.totalNoOfRows);
                this.showTile.emit(this.subSection);
            }
        }
    }
    refreshCount() {
        debugger;
        this.showLoading = true;
        this.subSectionNumber = this.subSection.toString();
        this.http.get(this.location.prepareExternalUrl('/today/TodayPage/GetSubsectionsRowCount?todayPageSubsection=' + this.subSection)).subscribe(result => {
            this.subSection = parseInt(this.subSectionNumber);
            switch (this.subSection) {
                case 1:
                    this.totalNoOfRows = result.json().missingSystemBoardIds;
                    break;
                case 2:
                    this.totalNoOfRows = result.json().pastDueScheduleItems;
                    break;
                case 3:
                    this.totalNoOfRows = result.json().scmFeedErrors;
                    break;
                case 4:
                    this.totalNoOfRows = result.json().missingSETestLeads;
                    break;
                case 10:
                    this.totalNoOfRows = result.json().missingRequiredMilestones;
                    break;
                case 11:
                    this.totalNoOfRows = result.json().smrAwaitingApproval;
                    break;
                case 5:
                    this.totalNoOfRows = result.json().observationUnassigneds;
                    break;
                case 8:
                    this.totalNoOfRows = result.json().observationTransferRequested;
                    break;
                case 61:
                    this.totalNoOfRows = result.json().spareKitsNotMappedToAVs;
                    break;
                case 12:
                    this.totalNoOfRows = result.json().smrAlertNotStarted;
                    break;
                case 62:
                    this.totalNoOfRows = result.json().productsMissingPdmTeamMember;
                    break;
                case 63:
                    this.totalNoOfRows = result.json().aVsNotMappedtoSparekit;
                    break;
                case 13:
                    this.totalNoOfRows = result.json().developerRequestedRemoval;
                    break;
                case 43:
                    this.totalNoOfRows = result.json().productsWithExpiredServiceLifeDate;
                    break;
                case 64:
                    this.totalNoOfRows = result.json().userAndRolesRequest;
                    break;
                case 65:
                    this.totalNoOfRows = result.json().aVsDeletedButMappedToSpareKits;
                    break;
                case 14:
                    this.totalNoOfRows = result.json().legacySimpleAVsCreated;
                    break;
                case 15:
                    this.totalNoOfRows = result.json().pulsarSimpleAVsCreated;
                    break;
                case 66:
                    this.totalNoOfRows = result.json().spareKitsNotStructuredToFamily;
                    break;
                case 21:
                    this.totalNoOfRows = result.json().productSupportInTest;
                    break;
                case 22:
                    this.totalNoOfRows = result.json().productSupportInComplete;
                    break;
                case 23:
                    this.totalNoOfRows = result.json().productSupportInTestPending;
                    break;
                case 24:
                    this.totalNoOfRows = result.json().pastDuesAlert;
                    break;
                case 25:
                    this.totalNoOfRows = result.json().dueThisWeek;
                    break;
                case 26:
                    this.totalNoOfRows = result.json().openItemsISubmitted;
                    break;
                case 27:
                    this.totalNoOfRows = result.json().productsMissingPMOrServiceLifeDate;
                    break;
                case 28:
                    this.totalNoOfRows = result.json().productsWithMissingHWPM;
                    break;
                case 29:
                    this.totalNoOfRows = result.json().applicationErrorsOutstanding;
                    break;
                case 67:
                    this.totalNoOfRows = result.json().featuresRequestingRootComponents;
                    break;
                case 44:
                    this.totalNoOfRows = result.json().openSupportTicketsISubmitted;
                    break;
                case 16:
                    this.totalNoOfRows = result.json().helpAndSupportUpcomingRelease;
                    break;
                case 47:
                    this.totalNoOfRows = result.json().hardWareObservationUnassigneds;
                    break;
                case 48:
                    this.totalNoOfRows = result.json().hardWareObservationTransferRequested;
                    break;
                case 17:
                    this.totalNoOfRows = result.json().recentVersionReleased;
                    break;
                case 18:
                    this.totalNoOfRows = result.json().failedTtsComponentsToReview;
                    break;
                case 49:
                    this.totalNoOfRows = result.json().itemsAwaitingMyApproval;
                    break;
                case 68:
                    this.totalNoOfRows = result.json().featureRootRequestsRejected;
                    break;
                case 19:
                    this.totalNoOfRows = result.json().dcrWorkflowMilestone;
                    break;
                case 50:
                    this.totalNoOfRows = result.json().allOpenitemsIOwn;
                    break;
                case 51:
                    this.totalNoOfRows = result.json().myOpenTickets;
                    break;
                case 20:
                    this.totalNoOfRows = result.json().closedInLastSevenDays;
                    break;
                case 6:
                    this.totalNoOfRows = result.json().crProposed;
                    break;
                case 71:
                    this.totalNoOfRows = result.json().openObservationsAssignedToMe;
                    break;
                case 72:
                    this.totalNoOfRows = result.json().openObservationsOnMyComponent;
                    break;
                case 73:
                    this.totalNoOfRows = result.json().openObservationsSubmitted;
                    break;
                case 69:
                    this.totalNoOfRows = result.json().componentsAwaitingTestReview;
                    break;
                case 25:
                    this.totalNoOfRows = result.json().openItemsISubmitted;
                    break;
                case 70:
                    this.totalNoOfRows = result.json().functionalTestUpcomingRelease;
                    break;
                case 101:
                    this.totalNoOfRows = result.json().componentsAwaitingDeveloperReview;
                    break;
                case 43:
                    this.totalNoOfRows = result.json().productsWithExpiredServiceLifeDate;
                    break;
                case 120:
                    this.totalNoOfRows = result.json().newSMRRequest;
                    break;
                case 54:
                    this.totalNoOfRows = result.json().sharedAVActions;
                    break;
                case 102:
                    this.totalNoOfRows = result.json().missingSupplierCodes;
                    break;
                case 7:
                    this.totalNoOfRows = result.json().linkedComponentsNotUsed;
                    break;
                case 9:
                    this.totalNoOfRows = result.json().pendingZsrpReadyDate;
                    break;
                case 121:
                    this.totalNoOfRows = result.json().componentMissingSubAssemblyOrKitNumber;
                    break;
                case 122:
                    this.totalNoOfRows = result.json().engineeringDevelopmentWorkingList;
                    break;
                case 103:
                    this.totalNoOfRows = result.json().expiredPilotScheduleDates;
                    break;
                case 45:
                    this.totalNoOfRows = result.json().pHwebAVActionItemsLegacyProduct;
                    break;
                case 42:
                    this.totalNoOfRows = result.json().myWorkingList;
                    break;
                case 30:
                    this.totalNoOfRows = result.json().pastDueScheduleAlertItems;
                    break;
                case 104:
                    this.totalNoOfRows = result.json().errorTransmittingFilestoPreinstallServer;
                    break;
                case 55:
                    this.totalNoOfRows = result.json().missingAVMarketingData;
                    break;
                case 53:
                    this.totalNoOfRows = result.json().featureNamingOverrideRequested;
                    break;
                case 31:
                    this.totalNoOfRows = result.json().componentInTestOdmLead;
                    break;
                case 32:
                    this.totalNoOfRows = result.json().componentInTestSELead;
                    break;
                case 33:
                    this.totalNoOfRows = result.json().componentInTestWwanLead;
                    break;
                case 123:
                    this.totalNoOfRows = result.json().hwDeliverableEolCount;
                    break;
                case 124:
                    this.totalNoOfRows = result.json().hwDeliverableEolCount;
                    break;
                case 74:
                    this.totalNoOfRows = result.json().componentPassedPlannedReleaseDate;
                    break;
                case 75:
                    this.totalNoOfRows = result.json().coreTeamWorkingList;
                    break;
                case 76:
                    this.totalNoOfRows = result.json().featureRemovedFromPrl;
                    break;
                case 52:
                    this.totalNoOfRows = result.json().rejectedAVs;
                    break;
                case 46:
                    this.totalNoOfRows = result.json().pHwebAVActionItemsPulsarProduct;
                    break;
                case 56:
                    this.totalNoOfRows = result.json().approvalRequestedReleaseToProduction;
                    break;
                case 105:
                    this.totalNoOfRows = result.json().componentInFunctionalTest;
                    break;
                case 57:
                    this.totalNoOfRows = result.json().newComponentsReleased;
                    break;
                case 125:
                    this.totalNoOfRows = result.json().pmDeveloperRequestedRemoval;
                    break;
                case 90:
                    this.totalNoOfRows = result.json().newComponentsRequest;
                    break;
                case 92:
                    this.totalNoOfRows = result.json().componentNameChangeLinkedToAV;
                    break;
                case 34:
                    this.totalNoOfRows = result.json().leadProductSync;
                    break;
                case 87:
                    this.totalNoOfRows = result.json().componentsinReleaseWorkflowStep;
                    break;
                case 95:
                    this.totalNoOfRows = result.json().hardwareComponentsWithNoPartNumber;
                    break;
                case 91:
                    this.totalNoOfRows = result.json().missingSubassemblyNumberLegacy;
                    break;
                case 88:
                    this.totalNoOfRows = result.json().missingBaseUnitSubassemblyNumbers;
                    break;
                case 94:
                    this.totalNoOfRows = result.json().imageTabChangetoLocalization;
                    break;
                case 82:
                    this.totalNoOfRows = result.json().aVsNotRequested;
                    break;
                case 85:
                    this.totalNoOfRows = result.json().newComponentsReleasedForMyProductOne;
                    break;
                case 84:
                    this.totalNoOfRows = result.json().newComponentsReleasedForMyProductTwo;
                    break;
                case 41:
                    this.totalNoOfRows = result.json().componentsAwaitingFinalApproval;
                    break;
            }
            this.showLoading = false;
        });


    }

    loadSubsection() {
        //this.router.navigate([this.componentUrl]);
        let popupurl: string = "";
        let popupTitle: string = "";
        popupurl = this.componentUrl.replace('/', '');
        popupTitle = this.impersonatedName != "" ? this.componentTitle + this.impersonatedName : this.componentTitle;
        //console.log(popupTitle);
        let navigationExtras: NavigationExtras = {
            queryParams: { 'CurrentUserSysAdmin': this.currentUserSysAdmin, 'SEPMProductCount': this.sepmProductCount, 'UserId': this.userId, 'NewComponentTwoCount': this.totalNoOfRows, 'CurrentUserName': this.CurrentUserName },
            preserveQueryParams: false

        };
        console.log(popupurl);
        this.router.navigate([{ outlets: { 'popupWindow': [popupurl] } }], navigationExtras);

        modalPopup.show('#popup', this.popupWidth, this.popupHeight, popupTitle, this.subSection);
    }

}

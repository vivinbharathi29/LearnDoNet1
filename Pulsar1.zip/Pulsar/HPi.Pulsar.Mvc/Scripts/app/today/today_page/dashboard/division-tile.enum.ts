﻿
// ***********************************************************************************************************
// Assembly         : App Module
// Author           : Rajivgandhi R
// Created          : 04-23-2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="division-tile.enum.ts" company="HP">
//     Copyright ©  2017 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************
export enum DivisionEnum {
    RandD = 1,
    MyTeam = 2,
    DevTeam = 3,
    SCM = 4,
    ReleaseTeam = 5,
    Marketing = 6,
    NotMappedAvs = 7,
    Service = 8,
    Other=9
}
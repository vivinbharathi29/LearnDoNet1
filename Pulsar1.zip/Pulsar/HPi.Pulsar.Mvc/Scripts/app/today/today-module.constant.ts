﻿import { Routes } from '@angular/router';
import { jqxComboBoxComponent } from '../jqwidgets-ts/angular_jqxcombobox';
import { jqxMenuComponent } from '../jqwidgets-ts/angular_jqxmenu';
import { CustomValidationService } from '../shared/custom-validation.service';
import { DCRWorkflowStatusComponent } from './dcr-workflow-status/dcr-workflow-status.component';
import { DCRWorkflowStatusService } from './dcr-workflow-status/dcr-workflow-status.service';
//import { jqxTabsComponent } from '../jqwidgets-ts/angular_jqxtabs';
//import { jqxDateTimeInputComponent } from '../jqwidgets-ts/angular_jqxdatetimeinput';
//import { TodayTabsComponent } from './today_page/today-tabs/today-tabs.component';
//import { TodayTabsService } from './today_page/today-tabs/today-tabs.service';
//import { AdminAlertsTabComponent } from './today_page/today-tabs/tab-content/admin-alerts.component';
//import { AlertsTabComponent } from './today_page/today-tabs/tab-content/alerts.component';
//import { DCRSTabComponent } from './today_page/today-tabs/tab-content/dcrs.component';
//import { MyItemsTabComponent } from './today_page/today-tabs/tab-content/my-items.component';
//import { ProductAlertsTabComponent } from './today_page/today-tabs/tab-content/product-alerts.component';
//import { PulsarNewsTabComponent } from './today_page/today-tabs/tab-content/pulsar-news.component';
//import { TestTabComponent } from './today_page/today-tabs/tab-content/test.component';
//import { UserInfoService } from './today_page/dashboard/user-info.service';
import { OverrideFeatureFeedbackComponent } from './override-feature-feedback/override-feature-feedback.component';
import { TicketPreviewComponent } from './ticket/ticket-preview.component';
import { TicketPreviewService } from './ticket/ticket-preview.service';
import { TicketComponent } from './ticket/ticket.component';
import { TicketService } from './ticket/ticket.service';
import { AllOpenItemsIOwnComponent } from './today_page/subsections/all_open_items_i_own/all-open-items-i-own.component';
import { AllOpenItemsIOwnService } from './today_page/subsections/all_open_items_i_own/all-open-items-i-own.service';
import { ApplicationErrorsOutstandingComponent } from './today_page/subsections/application_errors_outstanding_investigation/application-errors-outstanding-investigation.component';
import { ApplicationErrorsOutstandingService } from './today_page/subsections/application_errors_outstanding_investigation/application-errors-outstanding-investigation.service';
import { ApprovalRequestedReleaseToProductionComponent } from './today_page/subsections/approval_requested_release_to_production/approval-requested-release-to-production.component';
import { ApprovalRequestedReleaseToProductionService } from './today_page/subsections/approval_requested_release_to_production/approval-requested-release-to-production.service';
import { AvsDeletedButMappedtoSparekitsComponent } from './today_page/subsections/avs_deleted_but_mapped_to_spareKits/avs-deleted-but-mapped-to-sparekits.component';
import { AvsDeletedButMappedtoSparekitsService } from './today_page/subsections/avs_deleted_but_mapped_to_spareKits/avs-deleted-but-mapped-to-sparekits.service';
import { AvsNotMappedtoSpareKitsComponent } from './today_page/subsections/avs_not_mapped_to_sparekits/avs-not-mapped-to-sparekits.component';
import { AvsNotMappedtoSpareKitsService } from './today_page/subsections/avs_not_mapped_to_sparekits/avs-not-mapped-to-sparekits.service';
//import { QuickSearchComponent } from './today_page/quick_search/quick-search.component';
//import { QuickPageService } from "./today_page/quick_search/quick-search.service";
//import { TodayPageTilesComponent } from './today_page/dashboard/today-tiles.component';
import { AVsNotRequestedComponent } from './today_page/subsections/avs_not_requested/avs-not-requested.component';
import { AVsNotRequestedService } from './today_page/subsections/avs_not_requested/avs-not-requested.service';
import { CRClosedInLastSevenDaysComponent } from './today_page/subsections/closed_in_last_seven_days/cr-closed-in-last-seven-days.component';
import { CRClosedInLastSevenDaysService } from './today_page/subsections/closed_in_last_seven_days/cr-closed-in-last-seven-days.service';
import { ComponentsPassedPlannedReleaseDateComponent } from './today_page/subsections/components-passed-planned-release-date/components-passed-planned-release-date.component';
import { ComponentsPassedPlannedReleaseDateService } from './today_page/subsections/components-passed-planned-release-date/components-passed-planned-release-date.service';
import { ComponentsAwaitingDeveloperReviewComponent } from './today_page/subsections/components_awaiting_developer_review/components-awaiting-developer-review.component';
import { ComponentsAwaitingDeveloperReviewService } from './today_page/subsections/components_awaiting_developer_review/components-awaiting-developer-review.service';
import { ComponentsAwaitingFinalApprovalComponent } from './today_page/subsections/components_awaiting_final_approval/components-awaiting-final-approval.component';
import { ComponentsAwaitingFinalApprovalService } from './today_page/subsections/components_awaiting_final_approval/components-awaiting-final-approval.service';
import { ComponentsAwaitingTestReviewComponent } from './today_page/subsections/components_awaiting_test_review/components-awaiting-test-review.component';
import { ComponentsAwaitingTestReviewService } from './today_page/subsections/components_awaiting_test_review/components-awaiting-test-review.service';
import { ComponentsinReleaseWorkflowStepComponent } from './today_page/subsections/components_in_release_workflow_step/components-in-release-workflow-step.component';
import { ComponentsinReleaseWorkflowStepService } from './today_page/subsections/components_in_release_workflow_step/components-in-release-workflow-step.service';
import { ComponentEndOfLifeDateExpiredComponent } from './today_page/subsections/component_end_of_life_date_expired/component-end-of-life-date-expired.component';
import { ComponentEndOfLifeDateExpiredService } from './today_page/subsections/component_end_of_life_date_expired/component-end-of-life-date-expired.service';
import { ComponentInFunctionalTestComponent } from './today_page/subsections/component_in_functional_test/component-in-functional-test.component';
import { ComponentInFunctionalTestService } from './today_page/subsections/component_in_functional_test/component-in-functional-test.service';
import { ComponentInTestOdmHardwareLeadComponent } from './today_page/subsections/component_in_test_odm_hardware_lead/component-in-test-odm-hardware-lead.component';
import { ComponentInTestOdmHardwareLeadService } from './today_page/subsections/component_in_test_odm_hardware_lead/component-in-test-odm-hardware-lead.service';
import { ComponentInTestSELeadComponent } from './today_page/subsections/component_in_test_se_lead/component-in-test-se-lead.component';
import { ComponentInTestSELeadService } from './today_page/subsections/component_in_test_se_lead/component-in-test-se-lead.service';
import { ComponentInTestWWanLeadComponent } from './today_page/subsections/component_in_test_wwan_lead/component-in-test-wwan-lead.component';
import { ComponentInTestWWanLeadService } from './today_page/subsections/component_in_test_wwan_lead/component-in-test-wwan-lead.service';
import { ComponentMissingSubAssemblyOrKitNumberComponent } from './today_page/subsections/component_missing_subassembly_or_kitnumber/component-missing-subassembly-or-kitnumber.component';
import { ComponentMissingSubAssemblyOrKitNumberService } from './today_page/subsections/component_missing_subassembly_or_kitnumber/component-missing-subassembly-or-kitnumber.service';
import { ComponentNameChangeLinkedToAVComponent } from './today_page/subsections/component_name_change_linked_to_av/component-name-change-linked-to-av.component';
import { ComponentNameChangeLinkedToAVService } from './today_page/subsections/component_name_change_linked_to_av/component-name-change-linked-to-av.service';
import { CoreTeamWorkingListComponent } from './today_page/subsections/core-team-working-list/core-team-working-list.component';
import { CoreTeamWorkingListService } from './today_page/subsections/core-team-working-list/core-team-working-list.service';
import { CRProposedComponent } from './today_page/subsections/cr_proposed/cr-proposed.component';
import { CRProposedService } from './today_page/subsections/cr_proposed/cr-proposed.service';
import { DCRWorkflowDefinitionsComponent } from './today_page/subsections/dcr_workflow_milestone/dcr-workflow-definitions.component';
import { DCRWorkflowDefinitionsService } from './today_page/subsections/dcr_workflow_milestone/dcr-workflow-definitions.service';
import { DeveloperRequestRemovalFromProductComponent } from "./today_page/subsections/developer_request_removal_from_product/developer-request-removal-from-product.component";
import { DeveloperRequestRemovalFromProductService } from './today_page/subsections/developer_request_removal_from_product/developer-request-removal-from-product.service';
import { DueThisWeekComponent } from './today_page/subsections/due_this_week/due-this-week.component';
import { DueThisWeekService } from './today_page/subsections/due_this_week/due-this-week.service';
import { EngineeringDevelopmentWorkingListComponent } from './today_page/subsections/engineering_development_working_list/engineering-development-working-list.component';
import { EngineeringDevelopmentWorkingListService } from './today_page/subsections/engineering_development_working_list/engineering-development-working-list.service';
import { ErrorTransmittingFilesToPreinstallServiceComponent } from './today_page/subsections/error_transmitting_files_to_preinstall_server/error-transmitting-files-to-preinstall-server.component';
import { ErrorTransmittingFilesToPreinstallService } from './today_page/subsections/error_transmitting_files_to_preinstall_server/error-transmitting-files-to-preinstall-server.service';
import { ExpiredPilotScheduleDatesComponent } from './today_page/subsections/expired_pilot_schedule_dates/expired-pilot-schedule-dates.component';
import { ExpiredPilotScheduleDatesService } from './today_page/subsections/expired_pilot_schedule_dates/expired-pilot-schedule-dates.service';
import { FailedTTSComponentsToReviewComponent } from './today_page/subsections/failed_tts_components/failed-tts-components-to-review.component';
import { FailedTTSComponentsToReviewService } from './today_page/subsections/failed_tts_components/failed-tts-components-to-review.service';
import { FeatureRemovedFromPRLComponent } from './today_page/subsections/feature-removed-from-post-prl-lock/feature-removed-from-post-prl-lock.component';
import { FeatureRemovedFromPRLService } from './today_page/subsections/feature-removed-from-post-prl-lock/feature-removed-from-post-prl-lock.service';
import { FeaturesRequestingRootComponents } from './today_page/subsections/features_requesting_root_components/features-requesting-root-components.component';
import { FeaturesRequestingRootComponentsService } from './today_page/subsections/features_requesting_root_components/features-requesting-root-components.service';
import { FeatureNamingOverrideRequestedComponent } from './today_page/subsections/feature_naming_override_requested/feature-naming-override-requested.component';
import { FeatureNamingOverrideRequestedService } from './today_page/subsections/feature_naming_override_requested/feature-naming-override-requested.service';
import { FeatureRootRequestsRejectedComponent } from './today_page/subsections/feature_root_requests_rejected/feature_root_requests_rejected.component';
import { FeatureRootRequestsRejectedService } from './today_page/subsections/feature_root_requests_rejected/feature_root_requests_rejected.service';
import { FunctionalTestUpcomingReleaseComponent } from './today_page/subsections/functional_test_upcoming_releases/functional-test-upcoming-releases.component';
import { FunctionalTestUpcomingReleaseService } from './today_page/subsections/functional_test_upcoming_releases/functional-test-upcoming-releases.service';
import { HardwareComponentsWithNoPartNumberComponent } from './today_page/subsections/hardware_components_with_no_part_number/hardware-components-with-no-part-number.component';
import { HardwareComponentsWithNoPartNumberService } from './today_page/subsections/hardware_components_with_no_part_number/hardware-components-with-no-part-number.service';
import { HelpAndSupportUpcomingReleasesComponent } from './today_page/subsections/help_support_upcmoing_releases/help-support-upcoming-releases.component';
import { HelpAndSupportUpcomingReleasesService } from './today_page/subsections/help_support_upcmoing_releases/help-support-upcoming-releases.service';
import { IHUBJobsDidnotRunAsScheduledComponent } from './today_page/subsections/ihub_job_did_not_run_as_scheduled/i-hub-jobs-did-not-run-as-scheduled.component';
import { IHUBJobsDidNotRunAsScheduledService } from './today_page/subsections/ihub_job_did_not_run_as_scheduled/i-hub-jobs-did-not-run-as-scheduled.service';
import { ImageTabChangetoLocalizationComponent } from './today_page/subsections/image_tab_change_to_localization_pulsarproduct/image-tab-change-to-localization.component';
import { ImageTabChangetoLocalizationService } from './today_page/subsections/image_tab_change_to_localization_pulsarproduct/image-tab-change-to-localization.service';
//import { BreadCrumbComponent } from './today_page/dashboard/breadcrumb.component';
import { InActiveComponentStillTargetedComponent } from './today_page/subsections/inactive_components_still_targeted/inactive-components-still-targeted.component';
import { InActiveComponentStillTargetedService } from './today_page/subsections/inactive_components_still_targeted/inactive-components-still-targeted.service';
import { InitialOfferingDeactivateSimpleAVsComponent } from './today_page/subsections/initial_offering_deactivate_simple_avs/initial-offering-deactivate-simple-avs.component';
import { InitialOfferingDeactivateSimpleAVsService } from './today_page/subsections/initial_offering_deactivate_simple_avs/initial-offering-deactivate-simple-avs.service';
import { ItemsAwaitingMyApprovalComponent } from './today_page/subsections/items_awaiting_my_approval/items-awaiting-myapproval.component';
import { ItemsAwaitingMyApprovalService } from './today_page/subsections/items_awaiting_my_approval/items-awaiting-myapproval.service';
import { JobsDidnotRunAsScheduledComponent } from './today_page/subsections/jobs_did_not_run_as_scheduled/jobs-did-not-run-as-scheduled.component';
import { JobsDidNotRunAsScheduledService } from './today_page/subsections/jobs_did_not_run_as_scheduled/jobs-did-not-run-as-scheduled.service';
import { LeadProductSynchronizationComponent } from './today_page/subsections/lead_product_synchronization/lead-product-synchronization.component'; //safeHTML
import { LeadProductSynchronizationService } from './today_page/subsections/lead_product_synchronization/lead-product-synchronization.service';
import { LegacySimpleAVComponent } from './today_page/subsections/legacy-create-simple-avs/legacy-simple-av.component';
import { LegacySimpleAVService } from './today_page/subsections/legacy-create-simple-avs/legacy-simple-av.service';
import { LinkedComponentsNotUsedByCommodityTeamComponent } from './today_page/subsections/linked_components_no_longer_used_by_the_commodity_team/linked-component-not-used-by-commodity-team.component';
import { LinkedComponentsNotUsedByCommodityTeamService } from './today_page/subsections/linked_components_no_longer_used_by_the_commodity_team/linked-component-not-used-by-commodity-team.service';
import { MissingAVMarketingDataComponent } from './today_page/subsections/missing_av_marketing_data/missing-av-marketing-data.component';
import { MissingAVMarketingDataService } from './today_page/subsections/missing_av_marketing_data/missing-av-marketing-data.service';
import { MissingBaseUnitSubassemblyNumberComponent } from './today_page/subsections/missing_base_unit_subassembly_numbers/missing-base-unit-subassembly-numbers.component';
import { MissingBaseUnitSubassemblyNumberService } from './today_page/subsections/missing_base_unit_subassembly_numbers/missing-base-unit-subassembly-numbers.service';
import { MissingRequiredMilestonesComponent } from "./today_page/subsections/missing_required_milestones/missing-required-milestone.component";
import { MissingRequiredMilestonesService } from './today_page/subsections/missing_required_milestones/missing-required-milestone.service';
import { MissingServiceSubassemblyNumberComponent } from './today_page/subsections/missing_service_subassembly_numbers/missing-service-subassembly-numbers.component';
import { MissingServiceSubassemblyNumberService } from './today_page/subsections/missing_service_subassembly_numbers/missing-service-subassembly-numbers.service';
import { MissingSETestLeadComponent } from './today_page/subsections/missing_se_test_lead/missing-se-test-lead.component';
import { MissingSETestLeadService } from './today_page/subsections/missing_se_test_lead/missing-se-test-lead.service';
import { MissingSubassemblyNumberLegacyComponent } from './today_page/subsections/missing_subassembly_numbers_legacy/missing-subassembly-numbers-legacy.component';
import { MissingSubassemblyNumberLegacyService } from './today_page/subsections/missing_subassembly_numbers_legacy/missing-subassembly-numbers-legacy.service';
import { MissingSupplierCodesComponent } from './today_page/subsections/missing_supplier_codes/missing-supplier-codes.component';
import { MissingSupplierCodesService } from './today_page/subsections/missing_supplier_codes/missing-supplier-codes.service';
import { MissingSystemBoardIDComponent } from './today_page/subsections/missing_system_board/missing-system-board-id.component';
import { MissingSystemBoardIDService } from './today_page/subsections/missing_system_board/missing-system-board-id.service';
import { MyOpenTicketsComponent } from './today_page/subsections/my_open_tickets/my-open-tickets.component';
import { MyOpenTicketsService } from './today_page/subsections/my_open_tickets/my-open-tickets.service';
import { MyWorkingListComponent } from './today_page/subsections/my_working_list/my-working-list.component';
import { MyWorkingListService } from './today_page/subsections/my_working_list/my-working-list.service';
import { NewComponentsReleasedComponent } from './today_page/subsections/new_component_released/new-component-released.component';
import { NewComponentsReleasedService } from './today_page/subsections/new_component_released/new-component-released.service';
import { MoveToDateForMyProductsOneComponent } from './today_page/subsections/new_component_released_for_myproduct_one/move-to-date-for-myproducts-one.component';
import { MoveToDateForMyProductsOneService } from './today_page/subsections/new_component_released_for_myproduct_one/move-to-date-for-myproducts-one.service';
import { NewComponentsReleasedForMyProductsOneComponent } from './today_page/subsections/new_component_released_for_myproduct_one/new-component-released-for-myproducts-one.component';
import { NewComponentsReleasedForMyProductsOneService } from './today_page/subsections/new_component_released_for_myproduct_one/new-component-released-for-myproducts-one.service';
import { NewComponentReleasedForMyProductTwoComponent } from './today_page/subsections/new_component_released_for_myproduct_two/new-component-released-for-myproducts-two.component';
import { NewComponentReleasedForMyProductTwoService } from './today_page/subsections/new_component_released_for_myproduct_two/new-component-released-for-myproducts-two.service';
import { NewComponetRequestComponent } from './today_page/subsections/new_component_requests/new_component_requests.component';
import { NewComponentRequestService } from './today_page/subsections/new_component_requests/new_component_requests.service';
import { NewSMRRequestComponent } from './today_page/subsections/new_smr_requests/new-smr-request.component';
import { NewSMRRequestService } from './today_page/subsections/new_smr_requests/new-smr-request.service';
import { HardwareObservationsTransferRequestedComponent } from './today_page/subsections/observations_transfer_requested/hardware-observation-transfer-requested-component';
import { HardwareObservationsTransferRequestedService } from './today_page/subsections/observations_transfer_requested/hardware-observation-transfer-requested.service';
import { ObservationsTransferRequestedComponent } from './today_page/subsections/observations_transfer_requested/observation-transfer-requested-component';
import { ObservationTransferRequestedService } from './today_page/subsections/observations_transfer_requested/observation-transfer-requested-service';
import { HardwareObservationsUnassignedComponent } from './today_page/subsections/observation_unassigned/hardware-observation-unassigned.component';
import { HardwareObservationsUnassignedService } from './today_page/subsections/observation_unassigned/hardware-observation-unassigned.service';
import { ObservationUnassignedComponent } from './today_page/subsections/observation_unassigned/observation-unassigned.component';
import { ObservationUnassignedService } from './today_page/subsections/observation_unassigned/observation-unassigned.service';
import { OpenObservationsAssignedToMeComponent } from './today_page/subsections/open-observations-assigned-to-me/open-observations-assigned-to-me.component';
import { OpenObservationsAssignedToMeService } from './today_page/subsections/open-observations-assigned-to-me/open-observations-assigned-to-me.service';
import { OpenObservationsOnMyComponentComponent } from './today_page/subsections/open-observations-on-my-component/open-observations-on-my-component.component';
import { OpenObservationsOnMyComponentService } from './today_page/subsections/open-observations-on-my-component/open-observations-on-my-component.service';
import { OpenObservationsSubmittedComponent } from './today_page/subsections/open-observations-submitted/open-observations-submitted.component';
import { OpenObservationsSubmittedService } from './today_page/subsections/open-observations-submitted/open-observations-submitted.service';
import { OpenItemsISubmitedComponent } from './today_page/subsections/open_items_i_submitted/open_items_i_submitted.component';
import { OpenItemsISubmittedService } from './today_page/subsections/open_items_i_submitted/open_items_i_submitted.service';
import { OpenSupportTicketsISubmittedComponent } from './today_page/subsections/open_support _tickets_i_submitted/open-support-tickets-i-submitted.component';
import { OpenSupportTicketsISubmittedService } from './today_page/subsections/open_support _tickets_i_submitted/open-support-tickets-i-submitted.service';
import { PastDueScheduleAlertItemsComponent } from './today_page/subsections/past_due_alert_items/past-due-schedule-alert-items.component';
import { PastDueScheduleAlertItemsService } from './today_page/subsections/past_due_alert_items/past-due-schedule-alert-items.service';
import { PastDueAlertItemsComponent } from './today_page/subsections/past_due_alert_items/past-dues-items.component';
import { PastDueAlertItemsService } from './today_page/subsections/past_due_alert_items/past-dues-items.service';
import { PastDueScheduleItemsComponent } from './today_page/subsections/past_due_schedule_items/past-due-schedule-items.component';
import { PastDueScheduleItemsService } from './today_page/subsections/past_due_schedule_items/past-due-schedule-items.service';
import { PendingZSRPReadyDateComponent } from './today_page/subsections/pending_zsrp_ready_date/pending-zsrp-ready-date.component';
import { PendingZSRPReadyDateService } from './today_page/subsections/pending_zsrp_ready_date/pending-zsrp-ready-date.service';
import { PHwebAVActionItemsLegacyProductComponent } from './today_page/subsections/phweb_av_ation_items_(legacy_product)/ph-web-av-action-items-legacy-product.component';
import { PHwebAVActionItemsLegacyProductService } from './today_page/subsections/phweb_av_ation_items_(legacy_product)/ph-web-av-action-items-legacy-product.service';
import { PHwebAVActionItemsPulsarProductComponent } from './today_page/subsections/phweb_av_ation_items_(pulsar_product)/ph-web-av-action-items-pulsar-product.component';
import { PHwebAVActionItemsPulsarProductService } from './today_page/subsections/phweb_av_ation_items_(pulsar_product)/ph-web-av-action-items-pulsar-product.service';
import { PMAlertsDeveloperRequestRemovalFromProductComponent } from "./today_page/subsections/pm_alerts_developer_request_removal_from_product/pm-alerts-developer-request-removal-from-product.component";
import { PMAlertsDeveloperRequestRemovalFromProductService } from './today_page/subsections/pm_alerts_developer_request_removal_from_product/pm-alerts-developer-request-removal-from-product.service';
import { ProductsMissingWithHWPMComponent } from './today_page/subsections/products_missing_with_hw_pm/products-missing-with-hw-pm.component';
import { ProductsMissingWithHWPMService } from './today_page/subsections/products_missing_with_hw_pm/products-missing-with-hw-pm.service';
import { ProductsPmOrEndOfServiceLifeDateComponent } from './today_page/subsections/products_pm_or_end_of_service_life_date/products-pm-or-end-of-service-life-date.component';
import { ProductsPmOrEndOfServiceLifeDateService } from './today_page/subsections/products_pm_or_end_of_service_life_date/products-pm-or-end-of-service-life-date.service';
import { ProductsWithExpiredServiceLifeDateComponent } from './today_page/subsections/products_with_expired_service_life_date/products-with-expired-service-life-date.component';
import { ProductsWithExpiredServiceLifeDateService } from './today_page/subsections/products_with_expired_service_life_date/products-with-expired-service-life-date.service';
import { ProductMissingPDMTeamMemberComponent } from './today_page/subsections/product_missing_pdm_team_member/product-missing-pdm-team-member.component';
import { ProductMissingPDMTeamMemberService } from './today_page/subsections/product_missing_pdm_team_member/product-missing-pdm-team-member.service';
import { PulsarSimpleAVComponent } from './today_page/subsections/pulsar-create-simple-avs/pulsar-simple-av.component';
import { PulsarSimpleAVService } from './today_page/subsections/pulsar-create-simple-avs/pulsar-simple-av.service';
import { RecentVersionsReleasedComponent } from './today_page/subsections/recent_versions_released/recent-versions-released.component';
import { RecentVersionsReleasedService } from './today_page/subsections/recent_versions_released/recent-versions-released.service';
import { AVPHwebRejectionItemComponent } from './today_page/subsections/rejected_avs(pulsarproduct)/av-ph-web-rejection-item.component';
import { AVPHwebRejectionItemService } from './today_page/subsections/rejected_avs(pulsarproduct)/av-ph-web-rejection-item.service';
import { SCMFeedErrorComponent } from './today_page/subsections/scm_feed_errors/scm-feed-error.component';
import { SCMFeedErrorService } from './today_page/subsections/scm_feed_errors/scm-feed-error.service';
import { SharedAVActionsComponent } from './today_page/subsections/shared_av_actions/shared-av-actions.component';
import { SharedAVActionsService } from './today_page/subsections/shared_av_actions/shared-av-actions.service';
import { SMRAwaitingApprovalComponent } from "./today_page/subsections/smr-awaiting-approval/smr-awaiting-approval.component";
import { SMRAwaitingApprovalService } from './today_page/subsections/smr-awaiting-approval/smr-awaiting-approval.service';
import { SMRWaitingOnDeveloperComponent } from "./today_page/subsections/smr-waiting-on-developer/smr-waiting-on-developer.component";
import { SMRWaitingOnDeveloperService } from './today_page/subsections/smr-waiting-on-developer/smr-waiting-on-developer.service';
import { SpareKitsNotMappedtoAvsComponent } from './today_page/subsections/sparekits_not_mapped_to_avs/sparekits-not-mapped-to-avs.component';
import { SpareKitsNotMappedtoAvsService } from './today_page/subsections/sparekits_not_mapped_to_avs/sparekits-not-mapped-to-avs.service';
import { SpareKitsNotStructuredtoFamilyComponent } from './today_page/subsections/sparekits_not_structured_to_family/sparekits-not-structured-to-family.component';
import { SpareKitsNotStructuredtoFamilyService } from './today_page/subsections/sparekits_not_structured_to_family/sparekits-not-structured-to-family.service';
import { SustainingProductSupportInCompleteComponent } from './today_page/subsections/sustaining_product_support_in_complete/sustaining-product-support-in-complete.component';
import { SustainingProductSupportInCompleteService } from './today_page/subsections/sustaining_product_support_in_complete/sustaining-product-support-in-complete.service';
import { SustainingProductSupportInTestComponent } from './today_page/subsections/sustaining_product_support_in_test/sustaining-product-support-in-test.component';
import { SustainingProductSupportInTestService } from './today_page/subsections/sustaining_product_support_in_test/sustaining-product-support-in-test.service';
import { SustainingProductSupportInTestPendingComponent } from './today_page/subsections/sustaining_product_support_in_test_pending/sustaining-product-support-in-test-pending.component';
import { SustainingProductSupportInTestPendingService } from './today_page/subsections/sustaining_product_support_in_test_pending/sustaining-product-support-in-test-pending.service';
import { UpcomingReleaseComponent } from './today_page/subsections/upcoming_releases/upcoming-releases.component';
import { UpcomingReleaseService } from './today_page/subsections/upcoming_releases/upcoming-releases.service';
import { UsersandRolesRequestsComponent } from './today_page/subsections/users_and_roles_requests/users-and-roles-requests.component';
import { UsersandRolesRequestsService } from './today_page/subsections/users_and_roles_requests/users-and-roles-requests.service';
import { UpdateScheduleMilestoneComponent } from './update-schedule-milestone/update-schedule-milestone.component';
import { UpdateScheduleMilestoneService } from './update-schedule-milestone/update-schedule-milestone.service';
import { UpdateScheduleComponent } from './update-schedule/update-schedule.component';
import { UpdateScheduleService } from './update-schedule/update-schedule.service';

export const todayRoutes: Routes = [
    //{ path: 'today', component: TodayTabsComponent },
    { path: 'missingsystemboard', component: MissingSystemBoardIDComponent, outlet: 'popupWindow' },
    { path: 'pastdue', component: PastDueScheduleItemsComponent, outlet: 'popupWindow' },
    { path: 'scmfeederror', component: SCMFeedErrorComponent, outlet: 'popupWindow' },
    { path: 'spareKitsnotmappedtoavs', component: SpareKitsNotMappedtoAvsComponent, outlet: 'popupWindow' },
    { path: 'productmissingpdmteammember', component: ProductMissingPDMTeamMemberComponent, outlet: 'popupWindow' },
    { path: 'missingrequiredmilestones', component: MissingRequiredMilestonesComponent, outlet: 'popupWindow' },
    { path: 'observationunassigned', component: ObservationUnassignedComponent, outlet: 'popupWindow' },
    { path: 'observationstransferrequested', component: ObservationsTransferRequestedComponent, outlet: 'popupWindow' },
    { path: 'hardwareobservationunassigned', component: HardwareObservationsUnassignedComponent, outlet: 'popupWindow' },
    //{ path: 'hardwareobservationstransferrequested', component: HardwareObservationsTransferRequestedComponent },
    { path: 'missingsetestlead', component: MissingSETestLeadComponent, outlet: 'popupWindow' },
    { path: 'smrawaitingdeveloper', component: SMRAwaitingApprovalComponent, outlet: 'popupWindow' },
    { path: 'smrwaitingondeveloper', component: SMRWaitingOnDeveloperComponent, outlet: 'popupWindow' },
    { path: 'ihubdidnotrunasscheduled', component: IHUBJobsDidnotRunAsScheduledComponent, outlet: 'popupWindow' },
    { path: 'avsnotrequested', component: AVsNotRequestedComponent, outlet: 'popupWindow' },
    { path: 'developerrequestremovalfromproduct', component: DeveloperRequestRemovalFromProductComponent, outlet: 'popupWindow' },
    { path: 'avsnotmappedtosparekit', component: AvsNotMappedtoSpareKitsComponent, outlet: 'popupWindow' },
    { path: 'componentsawaitingfinalapproval', component: ComponentsAwaitingFinalApprovalComponent, outlet: 'popupWindow' },
    { path: 'inactivecomponentstilltargeted', component: InActiveComponentStillTargetedComponent, outlet: 'popupWindow' },
    { path: 'usersandrolesrequests', component: UsersandRolesRequestsComponent, outlet: 'popupWindow' },
    { path: 'legacysimpleavs', component: LegacySimpleAVComponent, outlet: 'popupWindow' },
    { path: 'newcomponentreleasedformyproducttwo', component: NewComponentReleasedForMyProductTwoComponent, outlet: 'popupWindow' },
    { path: 'avsdeletedbutmappedtosparekits', component: AvsDeletedButMappedtoSparekitsComponent, outlet: 'popupWindow' },
    { path: 'pulsarsimpleavs', component: PulsarSimpleAVComponent, outlet: 'popupWindow' },
    { path: 'sparekitsnotstructuredtofamily', component: SpareKitsNotStructuredtoFamilyComponent, outlet: 'popupWindow' },
    { path: 'sustainingproductsupportintest', component: SustainingProductSupportInTestComponent, outlet: 'popupWindow' },
    { path: 'sustainingproductsupportincomplete', component: SustainingProductSupportInCompleteComponent, outlet: 'popupWindow' },
    { path: 'sustainingproductsupportintestpending', component: SustainingProductSupportInTestPendingComponent, outlet: 'popupWindow' },
    { path: 'upcomingreleases', component: UpcomingReleaseComponent, outlet: 'popupWindow' },
    { path: 'opensupportticketsisubmitted', component: OpenSupportTicketsISubmittedComponent, outlet: 'popupWindow' },
    { path: 'helpandsupportupcomingreleases', component: HelpAndSupportUpcomingReleasesComponent, outlet: 'popupWindow' },
    { path: 'featuresrequestingrootcomponents', component: FeaturesRequestingRootComponents, outlet: 'popupWindow' },
    { path: 'hardwareobservationtransferrequested', component: HardwareObservationsTransferRequestedComponent, outlet: 'popupWindow' },
    { path: 'componentsinreleaseworkflowstep', component: ComponentsinReleaseWorkflowStepComponent, outlet: 'popupWindow' },
    { path: 'recentversionsreleased', component: RecentVersionsReleasedComponent, outlet: 'popupWindow' },
    { path: 'failedttscomponentstoreview', component: FailedTTSComponentsToReviewComponent, outlet: 'popupWindow' },
    { path: 'itemsawaitingmyapproval', component: ItemsAwaitingMyApprovalComponent, outlet: 'popupWindow' },
    { path: 'featurerootrequestsrejected', component: FeatureRootRequestsRejectedComponent, outlet: 'popupWindow' },
    { path: 'missingbaseunitsubassemblynumber', component: MissingBaseUnitSubassemblyNumberComponent, outlet: 'popupWindow' },
    { path: 'dcrworkflowdefinition', component: DCRWorkflowDefinitionsComponent, outlet: 'popupWindow' },
    { path: 'allopenitemsiown', component: AllOpenItemsIOwnComponent, outlet: 'popupWindow' },
    { path: 'pastduesalert', component: PastDueAlertItemsComponent, outlet: 'popupWindow' },
    { path: 'myopentickets', component: MyOpenTicketsComponent, outlet: 'popupWindow' },
    { path: 'initialofferingdeactivatesimpleavs', component: InitialOfferingDeactivateSimpleAVsComponent, outlet: 'popupWindow' },
    { path: 'openobservationsassignedtome', component: OpenObservationsAssignedToMeComponent, outlet: 'popupWindow' },
    { path: 'openobservationsonmycomponent', component: OpenObservationsOnMyComponentComponent, outlet: 'popupWindow' },
    { path: 'openobservationssubmitted', component: OpenObservationsSubmittedComponent, outlet: 'popupWindow' },
    { path: 'crclosedinlastsevendays', component: CRClosedInLastSevenDaysComponent, outlet: 'popupWindow' },
    { path: 'crproposed', component: CRProposedComponent, outlet: 'popupWindow' },
    { path: 'openitemsisubmitted', component: OpenItemsISubmitedComponent, outlet: 'popupWindow' },
    { path: 'componentsawaitingtestreview', component: ComponentsAwaitingTestReviewComponent, outlet: 'popupWindow' },
    { path: 'duethisweek', component: DueThisWeekComponent, outlet: 'popupWindow' },
    { path: 'functionaltestupcomingreleases', component: FunctionalTestUpcomingReleaseComponent, outlet: 'popupWindow' },
    { path: 'newcomponentrequest', component: NewComponetRequestComponent, outlet: 'popupWindow' },
    { path: 'componentsawaitingdeveloperreview', component: ComponentsAwaitingDeveloperReviewComponent, outlet: 'popupWindow' },
    { path: 'productmissingpmorservicelifedate', component: ProductsPmOrEndOfServiceLifeDateComponent, outlet: 'popupWindow' },
    { path: 'missingsubassemblynumberslegacy', component: MissingSubassemblyNumberLegacyComponent, outlet: 'popupWindow' },
    { path: 'productswithexpiredservicelifedate', component: ProductsWithExpiredServiceLifeDateComponent, outlet: 'popupWindow' },
    { path: 'newsmrrequests', component: NewSMRRequestComponent, outlet: 'popupWindow' },
    { path: 'pmalertsdeveloperrequestedremoval', component: PMAlertsDeveloperRequestRemovalFromProductComponent, outlet: 'popupWindow' },
    { path: 'productmissinghwpm', component: ProductsMissingWithHWPMComponent, outlet: 'popupWindow' },
    { path: 'sharedavactions', component: SharedAVActionsComponent, outlet: 'popupWindow' },
    { path: 'missingsuppliercodes', component: MissingSupplierCodesComponent, outlet: 'popupWindow' },
    { path: 'newcomponentsreleasedformyproductsone', component: NewComponentsReleasedForMyProductsOneComponent, outlet: 'popupWindow' },
    { path: 'linkedcomponentnotusedbycommodityteam', component: LinkedComponentsNotUsedByCommodityTeamComponent, outlet: 'popupWindow' },
    { path: 'pendingzsrpreadydate', component: PendingZSRPReadyDateComponent, outlet: 'popupWindow' },
    { path: 'componentnamechangelinkedtoav', component: ComponentNameChangeLinkedToAVComponent, outlet: 'popupWindow' },
    { path: 'componentmissingsubassemblyorkitnumber', component: ComponentMissingSubAssemblyOrKitNumberComponent, outlet: 'popupWindow' },
    { path: 'applicationerrorsoutstanding', component: ApplicationErrorsOutstandingComponent, outlet: 'popupWindow' },
    { path: 'engineeringdevelopmentworkinglist', component: EngineeringDevelopmentWorkingListComponent, outlet: 'popupWindow' },
    { path: 'componentspassedplannedreleasedate', component: ComponentsPassedPlannedReleaseDateComponent, outlet: 'popupWindow' },
    { path: 'coreteamworkinglist', component: CoreTeamWorkingListComponent, outlet: 'popupWindow' },
    { path: 'expiredpilotscheduledates', component: ExpiredPilotScheduleDatesComponent, outlet: 'popupWindow' },
    { path: 'missingservicesubassemblynumbers', component: MissingServiceSubassemblyNumberComponent, outlet: 'popupWindow' },
    { path: 'phwebavactionitemslegacyproduct', component: PHwebAVActionItemsLegacyProductComponent, outlet: 'popupWindow' },
    { path: 'myworkinglist', component: MyWorkingListComponent, outlet: 'popupWindow' },
    { path: 'pastdueschedule', component: PastDueScheduleAlertItemsComponent, outlet: 'popupWindow' },
    { path: 'imagetabchangetolocalization', component: ImageTabChangetoLocalizationComponent, outlet: 'popupWindow' },
    { path: 'errortransmittingfilestopreinstallserver', component: ErrorTransmittingFilesToPreinstallServiceComponent, outlet: 'popupWindow' },
    { path: 'missingavmarketingdata', component: MissingAVMarketingDataComponent, outlet: 'popupWindow' },
    { path: 'featurenamingoverriderequested', component: FeatureNamingOverrideRequestedComponent, outlet: 'popupWindow' },
    { path: 'componentintestodm', component: ComponentInTestOdmHardwareLeadComponent, outlet: 'popupWindow' },
    { path: 'componentintestse', component: ComponentInTestSELeadComponent, outlet: 'popupWindow' },
    { path: 'componentintestwwan', component: ComponentInTestWWanLeadComponent, outlet: 'popupWindow' },
    { path: 'componentendoflifedateexpired', component: ComponentEndOfLifeDateExpiredComponent, outlet: 'popupWindow' },
    { path: 'featureremovedfromprl', component: FeatureRemovedFromPRLComponent, outlet: 'popupWindow' },
    { path: 'hardwarecomponentswithnopartnumber', component: HardwareComponentsWithNoPartNumberComponent, outlet: 'popupWindow' },
    { path: 'rejectedavs', component: AVPHwebRejectionItemComponent, outlet: 'popupWindow' },
    { path: 'phwebavactionitemspulsarproduct', component: PHwebAVActionItemsPulsarProductComponent, outlet: 'popupWindow' },
    { path: 'leadproductsynchronization', component: LeadProductSynchronizationComponent, outlet: 'popupWindow' },
    { path: 'approvalrequestedreleasetoproduction', component: ApprovalRequestedReleaseToProductionComponent, outlet: 'popupWindow' },
    { path: 'jobsdidnotrunasscheduled', component: JobsDidnotRunAsScheduledComponent, outlet: 'popupWindow' },
    { path: 'componentsinfunctionaltest', component: ComponentInFunctionalTestComponent, outlet: 'popupWindow' },
    { path: 'newcomponentsreleased', component: NewComponentsReleasedComponent, outlet: 'popupWindow' },
    { path: 'dcrworkflowstatus/:dcrId/:pvId/:milestoneComplete', component: DCRWorkflowStatusComponent, outlet: 'externalpopupWindow' },
    { path: 'ticket', component: TicketComponent, outlet: 'externalpopupWindow' },
    { path: 'ticketpreview', component: TicketPreviewComponent, outlet: 'externalpopupWindow' },
    { path: 'updateschedulemilestone', component: UpdateScheduleMilestoneComponent, outlet: 'externalpopupWindow' },
    { path: 'updateschedule/:scheduledataid', component: UpdateScheduleComponent, outlet: 'externalpopupWindow' },
    { path: 'overridefeaturefeedback', component: OverrideFeatureFeedbackComponent, outlet: 'externalpopupWindow' },
    { path: 'movetodateformyproductone', component: MoveToDateForMyProductsOneComponent, outlet: 'externalpopupWindow' },
    { path: 'dcrworkflowstatuspulsar2/:dcrId/:pvId/:milestoneComplete', component: DCRWorkflowStatusComponent },
    { path: 'ticketpulsar2', component: TicketComponent },
    { path: 'ticketpreviewpulsar2', component: TicketPreviewComponent },
    { path: 'updateschedulemilestonepulsar2', component: UpdateScheduleMilestoneComponent },
    { path: 'updateschedulepulsar2/:scheduledataid', component: UpdateScheduleComponent },
    { path: 'overridefeaturefeedbackpulsar2', component: OverrideFeatureFeedbackComponent },
    { path: 'movetodateformyproductonepulsar2', component: MoveToDateForMyProductsOneComponent }
    //{ path: '**', component: TodayTabsComponent }
];

export const todayComponents = [
    DeveloperRequestRemovalFromProductComponent, SMRWaitingOnDeveloperComponent, SMRAwaitingApprovalComponent,
    MissingRequiredMilestonesComponent, SCMFeedErrorComponent, MissingSystemBoardIDComponent, PastDueScheduleItemsComponent,
    ObservationUnassignedComponent, HardwareObservationsUnassignedComponent, ObservationsTransferRequestedComponent, MissingSETestLeadComponent, IHUBJobsDidnotRunAsScheduledComponent,
    AVsNotRequestedComponent, SpareKitsNotMappedtoAvsComponent, ProductMissingPDMTeamMemberComponent, AvsNotMappedtoSpareKitsComponent, ComponentsAwaitingFinalApprovalComponent,
    InActiveComponentStillTargetedComponent, UsersandRolesRequestsComponent, LegacySimpleAVComponent, NewComponentReleasedForMyProductTwoComponent, AvsDeletedButMappedtoSparekitsComponent,
    PulsarSimpleAVComponent, SpareKitsNotStructuredtoFamilyComponent, SustainingProductSupportInTestComponent, SustainingProductSupportInCompleteComponent, SustainingProductSupportInTestPendingComponent,
    UpcomingReleaseComponent, OpenSupportTicketsISubmittedComponent, HelpAndSupportUpcomingReleasesComponent, FeaturesRequestingRootComponents, HardwareObservationsTransferRequestedComponent,
    ComponentsinReleaseWorkflowStepComponent, RecentVersionsReleasedComponent, FailedTTSComponentsToReviewComponent, ItemsAwaitingMyApprovalComponent, FeatureRootRequestsRejectedComponent,
    MissingBaseUnitSubassemblyNumberComponent, DCRWorkflowDefinitionsComponent, CRClosedInLastSevenDaysComponent, AllOpenItemsIOwnComponent, PastDueAlertItemsComponent, MyOpenTicketsComponent,
    InitialOfferingDeactivateSimpleAVsComponent, OpenObservationsAssignedToMeComponent, OpenObservationsOnMyComponentComponent, OpenObservationsSubmittedComponent, CRProposedComponent,
    OpenItemsISubmitedComponent, ComponentsAwaitingTestReviewComponent, DueThisWeekComponent, FunctionalTestUpcomingReleaseComponent, NewComponetRequestComponent, ComponentsAwaitingDeveloperReviewComponent,
    ProductsPmOrEndOfServiceLifeDateComponent, MissingSubassemblyNumberLegacyComponent, ProductsWithExpiredServiceLifeDateComponent, NewSMRRequestComponent, PMAlertsDeveloperRequestRemovalFromProductComponent,
    ProductsMissingWithHWPMComponent, SharedAVActionsComponent, MissingSupplierCodesComponent, NewComponentsReleasedForMyProductsOneComponent, LinkedComponentsNotUsedByCommodityTeamComponent,
    PendingZSRPReadyDateComponent, ComponentNameChangeLinkedToAVComponent, jqxMenuComponent, ComponentMissingSubAssemblyOrKitNumberComponent, ApplicationErrorsOutstandingComponent,
    EngineeringDevelopmentWorkingListComponent, ComponentsPassedPlannedReleaseDateComponent, CoreTeamWorkingListComponent, ExpiredPilotScheduleDatesComponent, MissingServiceSubassemblyNumberComponent,
    PHwebAVActionItemsLegacyProductComponent, MyWorkingListComponent, PastDueScheduleAlertItemsComponent, ImageTabChangetoLocalizationComponent, ErrorTransmittingFilesToPreinstallServiceComponent,
    MissingAVMarketingDataComponent, JobsDidnotRunAsScheduledComponent, FeatureNamingOverrideRequestedComponent, ComponentInTestOdmHardwareLeadComponent, ComponentInTestSELeadComponent,
    ComponentInTestWWanLeadComponent, ComponentEndOfLifeDateExpiredComponent, FeatureRemovedFromPRLComponent, HardwareComponentsWithNoPartNumberComponent, AVPHwebRejectionItemComponent,
    PHwebAVActionItemsPulsarProductComponent, LeadProductSynchronizationComponent, ApprovalRequestedReleaseToProductionComponent, ComponentInFunctionalTestComponent, jqxComboBoxComponent, NewComponentsReleasedComponent,
    TicketComponent, DCRWorkflowStatusComponent, UpdateScheduleMilestoneComponent, UpdateScheduleComponent, OverrideFeatureFeedbackComponent, TicketPreviewComponent, MoveToDateForMyProductsOneComponent
];

export const todayProviders = [
    DeveloperRequestRemovalFromProductService, SMRWaitingOnDeveloperService, SMRAwaitingApprovalService, MissingRequiredMilestonesService, SCMFeedErrorService, PastDueScheduleItemsService,
    MissingSystemBoardIDService, ObservationTransferRequestedService, ObservationUnassignedService, HardwareObservationsTransferRequestedService,
    HardwareObservationsUnassignedService, MissingSETestLeadService, IHUBJobsDidNotRunAsScheduledService, SpareKitsNotMappedtoAvsService, ProductMissingPDMTeamMemberService,
    AVsNotRequestedService, AvsNotMappedtoSpareKitsService, ComponentsAwaitingFinalApprovalService, InActiveComponentStillTargetedService, UsersandRolesRequestsService, LegacySimpleAVService,
    NewComponentReleasedForMyProductTwoService, AvsDeletedButMappedtoSparekitsService, PulsarSimpleAVService, SpareKitsNotStructuredtoFamilyService, SustainingProductSupportInTestService,
    SustainingProductSupportInCompleteService, SustainingProductSupportInTestPendingService, UpcomingReleaseService, OpenSupportTicketsISubmittedService, HelpAndSupportUpcomingReleasesService,
    FeaturesRequestingRootComponentsService, ComponentsinReleaseWorkflowStepService, RecentVersionsReleasedService, FailedTTSComponentsToReviewService, ItemsAwaitingMyApprovalService,
    FeatureRootRequestsRejectedService, MissingBaseUnitSubassemblyNumberService, DCRWorkflowDefinitionsService, AllOpenItemsIOwnService, PastDueAlertItemsService, MyOpenTicketsService,
    InitialOfferingDeactivateSimpleAVsService, CRClosedInLastSevenDaysService, OpenObservationsAssignedToMeService, OpenObservationsOnMyComponentService, OpenObservationsSubmittedService,
    CRProposedService, OpenItemsISubmittedService, ComponentsAwaitingTestReviewService, DueThisWeekService, FunctionalTestUpcomingReleaseService, NewComponentRequestService,
    ComponentsAwaitingDeveloperReviewService, ProductsPmOrEndOfServiceLifeDateService, MissingSubassemblyNumberLegacyService, ProductsWithExpiredServiceLifeDateService, NewSMRRequestService,
    PMAlertsDeveloperRequestRemovalFromProductService, ProductsMissingWithHWPMService, SharedAVActionsService, MissingSupplierCodesService, NewComponentsReleasedForMyProductsOneService,
    LinkedComponentsNotUsedByCommodityTeamService, PendingZSRPReadyDateService, ApplicationErrorsOutstandingService, ComponentNameChangeLinkedToAVService,
    ComponentMissingSubAssemblyOrKitNumberService, EngineeringDevelopmentWorkingListService, ComponentsPassedPlannedReleaseDateService, CoreTeamWorkingListService,
    ExpiredPilotScheduleDatesService, MissingServiceSubassemblyNumberService, PHwebAVActionItemsLegacyProductService, MyWorkingListService, PastDueScheduleAlertItemsService,
    ImageTabChangetoLocalizationService, ErrorTransmittingFilesToPreinstallService, MissingAVMarketingDataService, FeatureNamingOverrideRequestedService,
    ComponentInTestOdmHardwareLeadService, ComponentInTestSELeadService, ComponentInTestWWanLeadService, ComponentEndOfLifeDateExpiredService, ApprovalRequestedReleaseToProductionService,
    FeatureRemovedFromPRLService, HardwareComponentsWithNoPartNumberService, AVPHwebRejectionItemService, PHwebAVActionItemsPulsarProductService, LeadProductSynchronizationService,
    JobsDidNotRunAsScheduledService, ComponentInFunctionalTestService, NewComponentsReleasedService, TicketService, CustomValidationService, DCRWorkflowStatusService, UpdateScheduleMilestoneService, UpdateScheduleService,
    TicketPreviewService, MoveToDateForMyProductsOneService
];
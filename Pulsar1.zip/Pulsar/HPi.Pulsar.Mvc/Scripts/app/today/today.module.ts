﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Routes } from '@angular/router';
import { Http, Headers, RequestOptions, Response, HttpModule } from '@angular/http';

import { SharedModule } from '../shared/shared.module';
import { todayComponents, todayProviders } from './today-module.constant';
import { TodayRoutingModule } from './today-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
    imports: [CommonModule, HttpModule, SharedModule, TodayRoutingModule,FormsModule, ReactiveFormsModule],
    declarations: [
        ...todayComponents
    ],
    providers: [
        ...todayProviders
    ]
})
export class TodayModule { }

﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.UnitOfWork.Contracts;
using HPi.Pulsar.UnitOfWork.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace HPi.Pulsar.Mvc.Controllers
{


    public class MegaMenuController : BaseMvcController<IMegaMenuUnitOfWork>
    {

        public MegaMenuController(IApplicationServices applicationServices, IMegaMenuUnitOfWork menuUnitOfWork, ICurrentUserProfile currentProfile, IConfiguration configuration)
        : base(applicationServices, menuUnitOfWork, configuration, currentProfile)
        {
            this.currentuserprofile = currentProfile;
        }

        public ICurrentUserProfile currentuserprofile { get; }

        // GET: /<controller>/
        #region AngularMenu
        public async Task<IActionResult> Index()
        {
            int userId = this.currentuserprofile.UserId;
            var megaMenuViewModel = await this.UnitOfWork.GetMegaMenuByUserIDAsync(userId).ConfigureAwait(false);
            megaMenuViewModel.UserId = userId;
            return this.Json(new { megaMenuViewModel });
        }

        [Route("MegaMenu/GetFavouriteMenuItems")]
        [ProducesResponseType(typeof(FavouriteMenuViewModel), 200)]
        [ProducesResponseType(typeof(FavouriteMenuViewModel), 404)]
        public async Task<JsonResult> GetFavouriteMenuItems()
        {
            int userId = this.currentuserprofile.UserId;
            var favouriteMenuViewModel = await this.UnitOfWork.GetFavoritesByUserIDAsync(userId).ConfigureAwait(false);
            favouriteMenuViewModel.UserId = userId;
            return this.Json(favouriteMenuViewModel);
        }
        #endregion AngularMenu

    }
}

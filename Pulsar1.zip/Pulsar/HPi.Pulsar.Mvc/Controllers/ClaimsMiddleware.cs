using System;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.Mvc.ClaimsTransformer;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace HPi.Pulsar.Mvc.Controllers
{


    public class ClaimsMiddleware
    {
        private readonly RequestDelegate next;

        private const string appCookieName = "PulsarSession";

        public ClaimsMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        //private bool TryValidateCustomAuthCookie(HttpContext httpContext, out int userId)
        //{
        //    bool isValid = false;
        //    var cookie = httpContext.Request.Cookies["Pulsar.Auth"];

        //    userId = 0;
        //    if (!string.IsNullOrEmpty(cookie))
        //    {
        //        var keyBytes = Encoding.UTF8.GetBytes("E6370D21688340A2B0299B79EA16DE2A");
        //        string decrptedCookie = AESEncryption.Decrypt(cookie, keyBytes);
        //        if (int.TryParse(decrptedCookie, out userId))
        //        {
        //            isValid = true;
        //        }
        //    }

        //    return isValid;
        //}

        public async Task Invoke(HttpContext httpContext, IUserInfoService userService, IConfiguration configuration)
        {
            string loginUserName = AppSettings.Get<string>("LoginUser:User") != "" ? AppSettings.Get<string>("LoginUser:User") : string.Empty;
            string loginUserDomain = AppSettings.Get<string>("LoginUser:Auth") != "" ? AppSettings.Get<string>("LoginUser:Auth") : string.Empty;
            string environmentMode = configuration["Environment:Mode"].ToString();

            var sessionCookie = httpContext.Request.Cookies[appCookieName];
            if (sessionCookie == null)
            {
                var sessionGuid = Guid.NewGuid().ToString().Replace("-", string.Empty);
                httpContext.Response.Cookies.Append(appCookieName, sessionGuid);
            }

            var isReverseProxy = false;
            // use ApplicationUser instead
            UserInfoModel userInfo = null;

            // Leverage PulsarMVC to get the authenticated user's corresponding UserId
            //if (TryValidateCustomAuthCookie(httpContext, out int userId))
            //{
            //    // Here can only get partial user information by using GetUserByIdAsync()
            //    userInfo = await userService.GetUserByIdAsync(userId).ConfigureAwait(false);
            //    loginUserName = userInfo.NtName;
            //    loginUserDomain = userInfo.NtDomain;
            //    // Retrieve the completed user information model via GetUserInfoByUserNameAsync()
            //    userInfo = await userService.GetUserInfoByUserNameAsync(loginUserName, loginUserDomain).ConfigureAwait(false);
            //}
            //else
            //{
                //if (context.HttpContext.User.Identity?.IsAuthenticated == false)
                if (httpContext.User.Identity.IsAuthenticated)
                {
                    int id = 0;
                    //if (context.HttpContext.User.Identity.Name != null)
                    if (httpContext.User.Identity.Name != null)
                    {
                        if (environmentMode != "Development")
                        {
                            //if (context.HttpContext.User.Identity.Name.Contains("\\"))
                            if (httpContext.User.Identity.Name.Contains("\\"))
                            {

                                loginUserDomain = httpContext.User.Identity.Name.Split('\\')[0];
                                loginUserName = httpContext.User.Identity.Name.Split('\\')[1];
                            }
                        }
                        userInfo = await userService.GetUserInfoByUserNameAsync(loginUserName, loginUserDomain).ConfigureAwait(false);
                    }
                    else
                    {
                        id = int.Parse(ClaimsPrincipal.Current.FindFirst("ActualUserID").Value);
                        userInfo = await userService.GetUserByIdAsync(id).ConfigureAwait(false);
                    }

                }
                else
                {
                    // check for prp connection
                    string httpHost = httpContext.Request.Headers["HOST"];

                    if (!string.IsNullOrWhiteSpace(httpHost))
                    {
                        if (httpHost.IndexOf("prp", StringComparison.Ordinal) != -1)
                        {
                            isReverseProxy = true;
                        }
                    }

                    // get auth user *** FOR NON-PROD SUPPORT ***
                    string authUser = httpContext.Request.Headers["AUTH_USER"];
                    if (!string.IsNullOrWhiteSpace(authUser))
                    {
                        userInfo = await userService.GetUserByNameAsync(authUser).ConfigureAwait(false);
                    }

                    // if auth user lookup failed, try nt user
                    string userDomainId = httpContext.Request.Headers["HPPF_AUTH_NTUSERDOMAINID"];

                    if (userInfo == null && !string.IsNullOrWhiteSpace(userDomainId))
                    {
                        var splitter = new[] { ':', '\\', ' ' };
                        var userDomainIdParts = userDomainId.Split(splitter);
                        if (userDomainIdParts.Length == 2)
                        {
                            var userName = $"{userDomainIdParts[0]}\\{userDomainIdParts[1]}";
                            userInfo = await userService.GetUserByNameAsync(userName).ConfigureAwait(false);
                            if (userInfo != null)
                            {
                                loginUserName = userInfo.NtName;
                                loginUserDomain = userInfo.NtDomain;
                                userInfo = await userService.GetUserInfoByUserNameAsync(loginUserName, loginUserDomain).ConfigureAwait(false);
                            }
                        }
                    }

                    // if nt user lookup failed, try email address
                    string email = httpContext.Request.Headers["HPPF_AUTH_UID"];
                    //string email = "pandian.parthasarathi.madurai.veera@hp.com";

                    if (userInfo == null && !string.IsNullOrWhiteSpace(email))
                    {
                        userInfo = await userService.GetUserByEmailAsync(email).ConfigureAwait(false);
                        if (userInfo != null)
                        {
                            loginUserName = userInfo.NtName;
                            loginUserDomain = userInfo.NtDomain;
                            userInfo = await userService.GetUserInfoByUserNameAsync(loginUserName, loginUserDomain).ConfigureAwait(false);
                        }
                    }
                }
            //}

            ClaimsIdentity userIdentity = null;
            if (userInfo == null)
            {
                // create default claims principal
                userIdentity = UserInfoModel.Empty().CreateClaimsIdentity(isReverseProxy);
            }
            else
            {
                // create claims principal for user & impersonation
                var actualUserId = userInfo.UserId;
                var actualUserName = userInfo.FullNameAuthendication;
                //if (userInfo.ImpersonateId > 0)
                //{
                //    userInfo = await UserService.GetUserById(userInfo.UserId);
                //}

                userIdentity = userInfo.CreateClaimsIdentity(isReverseProxy, loginUserName, loginUserDomain);
            }

            // update last activity
            //context.HttpContext.User.AddIdentity(userIdentity);
            httpContext.User.AddIdentity(userIdentity);
            //context.HttpContext.User = claimsPrincipal;

            if (userInfo == null || (userInfo != null && userInfo.UserId <= 0))
            {
                throw new Exception("Userid is 0");

                //string loginpage = context.Context.Request.Headers["HOST"].ToString()  + "/Pulsar/user/loginfailed";
                //context.Context.Response.Redirect(loginpage);
            }





            await this.next(httpContext); // Run the next Middleware

        }


    }
}

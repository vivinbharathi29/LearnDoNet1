using Microsoft.AspNetCore.Mvc;

namespace HPi.Pulsar.Mvc.Controllers
{


    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            var pulsar2LayoutName = "pulsar2";
            var pulsarPlusLayoutName = "pulsarplus";
            var preferredLayoutCookieName = "PreferredLayout2";
            // The angular popup redirection will work fine using the determined query string value from the Pulsar2 without checking the
            // cookie values. Need to find the right way to fix this as it is a temporary solution.
            if (HttpContext.Request.Cookies[preferredLayoutCookieName] != pulsarPlusLayoutName && !HttpContext.Request.QueryString.HasValue)
            {
                return Redirect("/" + pulsar2LayoutName + "/");
            }

            return View();
        }

        public JsonResult GetUserName()
        {
            var loggedInUser = HttpContext.User.Identity.Name;
            return this.Json(loggedInUser);
        }

        public IActionResult Error()
        {
            return this.View();
        }
    }
}

﻿using System.Linq;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace HPi.Pulsar.Mvc.Controllers
{


    public class RerouteMiddleware
    {
        private readonly RequestDelegate next;

        public RerouteMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext httpContext, IOptions<RerouteMapCollection> rerouteMaps)
        {
            var currentUrlPath = httpContext.Request.Path;
            var newUrl = GetNewRoute(rerouteMaps, currentUrlPath);

            if (newUrl != "")
            {
                httpContext.Response.Redirect(newUrl);
            }
            else
            {
                await this.next(httpContext);
            }
        }

        public string GetNewRoute(IOptions<RerouteMapCollection> rerouteMaps, string oldUrl)
        {
            string newRoute = string.Empty;
            var routes = rerouteMaps.Value.RerouteMaps.Select(Reroute => new RerouteMap
            {
                NewUrl = Reroute.NewUrl,
                OldUrl = Reroute.OldUrl
            }).ToList();
            var newUrl = routes.SingleOrDefault(reroute => reroute.OldUrl == oldUrl);
            if (newUrl != null)
            {
                newRoute = newUrl.NewUrl.ToString();
            }
            return newRoute;
        }
    }
}

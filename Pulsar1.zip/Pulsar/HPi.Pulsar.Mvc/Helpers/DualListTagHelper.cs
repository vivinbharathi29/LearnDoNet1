﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace HPi.Pulsar.Mvc.Helpers
{
    // You may need to install the Microsoft.AspNetCore.Razor.Runtime package into your project
    [HtmlTargetElement("TEST")]
    public class DualListTagHelper : TagHelper
    {

        //[HtmlAttributeName("Control-Id")]
        //public string Id { get; set; }

        //[HtmlAttributeName("Control-Name")]
        //public string Name { get; set; }

        //[HtmlAttributeName("Data-Source")]
        //public object DataSource { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = string.Empty;
            //output.Content.AppendHtml("<div><select></select><div>");
        }
    }
}

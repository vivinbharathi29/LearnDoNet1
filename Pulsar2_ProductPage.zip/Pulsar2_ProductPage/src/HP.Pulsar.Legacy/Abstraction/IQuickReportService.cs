﻿namespace HP.Pulsar.Legacy.Abstraction
{
    public interface IQuickReportService
    {
        IQuickReport GetReport(int reportId);
    }
}
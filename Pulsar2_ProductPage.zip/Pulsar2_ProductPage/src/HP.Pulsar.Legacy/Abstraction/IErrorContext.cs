﻿namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public class IErrorContext
    {
        public string ApplicationName { get; set; }
        public string ApplicationVersion { get; set; }
        public string IPAddress { get; set; }
        public string UserID { get; set; }
    }
}

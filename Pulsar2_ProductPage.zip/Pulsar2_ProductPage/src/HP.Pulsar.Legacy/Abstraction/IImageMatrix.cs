﻿using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.ImageMatrix;
using HP.Pulsar.Legacy.ViewModels.ImageMatrix;

namespace HP.Pulsar.Legacy.Abstraction
{
    public interface IImageMatrix
    {
        Task<ImageMatrixViewModel> GetImageMatrixAsync(ImageMatrixRequestModel request);

        Task<ImageMatrixViewModel> GetImageMatrixDataForPulsarProductAsync(ImageMatrixRequestModel request);

        Task<ImageMatrixViewModel> GetImageMatrixDataFusionAsync(ImageMatrixRequestModel request);

        Task<ImageMatrixViewModel> GetImageMatrixDataForLegacyProductAsync(ImageMatrixRequestModel request);
    }
}

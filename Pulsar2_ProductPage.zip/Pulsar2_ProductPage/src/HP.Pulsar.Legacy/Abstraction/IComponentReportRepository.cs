﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.DcrModels;
using HP.Pulsar.Legacy.Models.UserInfo;

namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public interface IComponentReportRepository
    {
        Task<IReadOnlyList<ReportProfileModel>> GetReportProfilesAsync(int employeeId, int type);
        Task<IReadOnlyList<ReportProfileModel>> GetReportProfilesSharedAsync(int employeeId, int type);
        Task<IReadOnlyList<ReportProfileModel>> GetReportProfilesGroupSharedAsync(int employeeId, int type);
        Task<IReadOnlyList<PartnerOdmProductWhitelistModel>> GetProductWhitelistAsync(int partnerId);
        Task<PartnerModel> GetPartnerDetailAsync(int partnerId);
        Task<IReadOnlyList<DeliverableRootModel>> GetDeliverableRootsAsync(int type, int pageNumber, int pageSize);
        Task<IReadOnlyList<ProductVersionModel>> GetProductsOnCommodityMatrixAsync(int divisionId);
        Task<IReadOnlyList<UserInfoModel>> GetDeliverableRootDevManagersAsync();
        Task<IReadOnlyList<ProductVersionModel>> GetProductGroupsAsync(int type);
        Task<IReadOnlyList<VendorModel>> GetVendorsAsync();
        Task<IReadOnlyList<UserInfoModel>> GetDeliverableVersionDevelopersAsync();
        Task<IReadOnlyList<TestStatusModel>> GetTestStatusesAsync();
        Task<IReadOnlyList<LanguageModel>> GetLanguagesAsync();
        Task<EmployeeUserSettingModel> GetUserSettingAsync(int employeeId, int userSettingsId);
        Task<IReadOnlyList<DeliverableCoreTeamModel>> GetDeliverableCoreTeamsAsync();
        Task<IReadOnlyList<DeliverableCategoryModel>> GetHWCategoriesAsync();
        Task<IReadOnlyList<DeliverableTypeModel>> GetDeliverableCategoriesAsync(int productId);
        Task<IReadOnlyList<UserInfoModel>> GetCommodityPMsAsync();
        Task<IReadOnlyList<OSLookupModel>> GetOperatingSystemsAsync(bool isActive, bool isImagePackage);
        Task<IReadOnlyList<PartnerModel>> GetPartnersAsync(int reportTypeId);
        Task<IReadOnlyList<ProgramModel>> GetProgramsAsync();
        Task<IReadOnlyList<DevCenterModel>> GetDevCentersAsync();
        Task<IReadOnlyList<ProductStatusModel>> GetProductStatusesAsync();
        Task<int> RenameProfileAsync(int profileId, string profileName, int? employeeId);
        Task<int> DeleteProfileAsync(int profileId, int? employeeId);
        Task<int> UpdateProfileAsync(ReportProfileModel reportProfile);
        Task<int> AddProfileAsync(ReportProfileModel reportProfile);
    }
}

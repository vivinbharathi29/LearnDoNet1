﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.ImageMatrix;

namespace HP.Pulsar.Legacy.Abstraction
{
    public interface IImageMatrixRepository
    {
        Task<IReadOnlyList<ImageDefinitionModel>> GetImageDefinitionBrandsAsync(int imageDefinitionId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImageDefinitionBrandsFusionAsync(int imageDefinitionId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImageDefinitionsByProductAsync(int productId, int reportId, int includedProductId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImageDefinitionsForImageMatrixAsync(int productId, int? imageTypeId, int? productReleaseId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImageDefinitionsForImageMatrixFusionAsync(int productId, int? imageTypeId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImageDefinitionsLocalizationAsync(int imageDefinitionId);

        Task<(int Id, string Priority)> GetImagePropertiesForPulsarProductAsync(int imageDefinitionId, string priority);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImagesForDefinitionAsync(int imageDefinitionId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImagesForDefinitionLocalizationAsync(int imageDefinitionId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImagesForProductAsync(int productId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImagesForProductFusionAsync(int productId);

        Task<IReadOnlyList<ImageDefinitionModel>> GetImagesForProductLocalizationAsync(int productId, int includeProductId);
    }
}

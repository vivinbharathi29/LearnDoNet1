﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.ActionItem;
using HP.Pulsar.Legacy.Models.DcrModels;

namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public interface IActionItem
    {
        Task<List<SelectOptions>> GetProfilesAsync(int userId);
        Task<IReadOnlyList<ProductVersionViewModel>> GetProductGroupsAsync(int? productId);
        Task<List<SelectOptions>> GetSubmittersAsync();
        Task<List<SelectOptions>> GetApproversAsync();
        Task<List<SelectOptions>> GetOwnersAsync();
        Task<List<SelectOptions>> GetProductsAsync(int productId);
        Task<List<SelectOptions>> GetProductLinesAsync();
        Task<List<SelectOptions>> GetBusinessSegmentsAsync();
        Task<List<SelectOptions>> GetProductGroupsAsync();
        Task<ReportProfileModel> GetReportProfileDetailsAsync(int profileId, int userId);
        Task<int> AddProfileAsync(QueryActionPostModel reportProfile);
        Task<int> RenameProfileAsync(int profileId, string profileName, int employeeId);
        Task<int> DeleteProfileAsync(int profileId, int employeeId);
        Task<int> RemoveSharedProfileAsync(int sharingId);
        Task<int> UpdateProfileAsync(QueryActionPostModel reportProfile);
        Task<QueryActionResultModel> GetActionReportAdvancedAsync(QueryActionPostModel queryAction);
        Task<ShareProfileViewModel> ShareProfileAsync(int profileId, int employeeId);

        Task<int> UpsertDeliverableActionWebAsync(ActionViewModel actionViewModel, int currentUserId, string currentUserEmail);
        public Task<ActionViewModel> GetWorkingListActionAsync(int currentUserId,                                                               
                                                               int? defaultWorkingListProduct,
                                                               int? productId,
                                                               int? id,
                                                               int? type,
                                                               int? appErrorId,
                                                               int working,
                                                               int? roadmapId,
                                                               int? ticketId,
                                                               string userName);
    }
}

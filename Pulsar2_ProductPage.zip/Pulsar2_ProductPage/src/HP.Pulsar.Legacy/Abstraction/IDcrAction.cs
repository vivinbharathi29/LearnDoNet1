﻿using System.Threading.Tasks;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Legacy.Models.DcrModels;

namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public interface IDcrAction
    {
        Task<DcrActionViewModel> GetDcrAsync(int deliverableIssueId, string typeId, IPulsarUser currentUser);

        Task<SelectEmployeeViewModel> GetEmployeeListAsync(string userNamePattern);

        Task<int> UpdateDcrActionAsync(DcrUpdateViewModel dcrUpdateModel, IPulsarUser currentUser);
    }
}

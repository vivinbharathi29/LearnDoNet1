﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.HardwareMatrix;

namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public interface IHardwareMatrixRepository
    {
        Task<HardwareMatrixSearchModel> GetHardwareMatrixSearchResultAsync(HardwareMatrixInputModel input);

        Task<HardwareMatrixSearchModel> GetHardwareMatrixProductListForDisplayAsync(HardwareMatrixInputModel input);

        Task<HardwareMatrixSearchModel> GetProductHardwareMatrixResultAsync(HardwareMatrixInputModel input);

        Task<IReadOnlyList<ProductVersionReleaseModel>> GetProductValuesAsync(string productPulsarId);

        Task<ProductVersionModel> GetProductsAsync(int productId);

        Task<ProductVersionModel> GetPulsarProductsAsync(int productId);

        Task<IReadOnlyList<ProductFamilyModel>> GetProductFamiliesAsync(int productId);

        Task<DeliverableCategoryModel> GetComponentCategoryAsync(int categoryId);

        Task<DeliverableRootModel> GetComponentRootAsync(int componentRootId);

        Task<ProductStatusModel> GetProductPhaseAsync(int id);

        Task<IReadOnlyList<ProductStatusModel>> GetSelectedProductPhaseAsync();

        Task<IReadOnlyList<DeliverableCategoryModel>> GetSelectedComponentCategoriesAsync();

        Task<IReadOnlyList<ReportProfileModel>> GetReportProfilesAsync(int employeeId);

        Task<IReadOnlyList<ProductVersionReleaseModel>> GetSelectProductReleasesAsync(string productIds);

        Task<IReadOnlyList<ProductDelRootReleaseModel>> GetSubAssembliesForBaseAsync(string baseName);

        Task<IReadOnlyList<ProductDelRootReleaseModel>> GetSubAssembliesForBaseServiceAsync(string subAssemblyBase);

        Task<IReadOnlyList<ProductDelRootModel>> GetSubassembliesForComponentRootAsync(int componentRootId);

        Task<IReadOnlyList<ProductDelRootModel>> GetNativeSubAssemblyBaseAsync(string subAssemblyBase, int nativeComponentRootId, int productId);

        Task<ReleaseNotesModel> GetChangeNotesAsync(int Id);

        Task<(int? OtsNumber, string OtsDescription)> GetOtsDetailsAsync(int Id);
    }
}

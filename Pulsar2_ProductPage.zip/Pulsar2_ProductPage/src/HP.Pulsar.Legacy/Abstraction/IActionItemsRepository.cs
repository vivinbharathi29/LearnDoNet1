﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.ActionItem;
using HP.Pulsar.Legacy.Models.DcrModels;

namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public interface IActionItemsRepository
    {
        Task<IReadOnlyList<ReportProfileModel>> GetReportProfilesAsync(int employeeId, int type);

        Task<IReadOnlyList<ReportProfileModel>> GetReportProfilesSharedAsync(int employeeId, int type);

        Task<IReadOnlyList<ReportProfileModel>> GetReportProfilesGroupSharedAsync(int employeeId, int type);

        Task<IReadOnlyList<ReportProfileModel>> GetReportProfileNameAsync(int employeeId);

        Task<ReportProfileModel> GetReportProfileDetailsAsync(int profileId, int? userId);

        Task<int> RenameProfileAsync(int profileId, string profileName, int employeeId);

        Task<int> DeleteProfileAsync(int profileId, int employeeId);

        Task<int> UpdateProfileAsync(ReportProfileModel reportProfile);

        Task<int> AddProfileAsync(ReportProfileModel reportProfile);

        Task<int> RemoveSharedProfileAsync(int sharingId);

        Task<IReadOnlyList<ReportProfileModel>> GetReportProfileSharedAsync(int profileId, int employeeId);

        Task<IReadOnlyList<ReportProfileModel>> GetReportProfileGroupsAsync(int profileId);

        Task<int> RemoveSharedProfilesAsync(ReportProfileSharedModel reportProfileShared);

        Task<int> RemoveSharedProfileGroupAsync(ReportProfileSharedModel reportProfileShared);

        Task<int> UpdateSharedProfileGroupAsync(ReportProfileSharedModel reportProfileShared);

        Task<int> UpdateSharedProfilesAsync(ReportProfileSharedModel reportProfileShared);

        Task<IReadOnlyList<ProductVersionModel>> GetProductGroupsAsync(int type);

        Task<IReadOnlyList<DeliverableIssueModel>> GetDeliverableIssueSubmittersAsync();

        Task<IReadOnlyList<ActionApprovalModel>> GetActionApprovalAsync();

        Task<IReadOnlyList<DeliverableIssueModel>> GetActionOwnersAsync();

        Task<IReadOnlyList<ProductVersionModel>> GetActionReportProductVersionsAsync();

        Task<IReadOnlyList<ProductLineModel>> GetProductLinesAsync();

        Task<IReadOnlyList<BusinessSegmentModel>> GetBusinessSegmentsAsync();

        Task<IReadOnlyList<PartnerModel>> GetPartnersAsync(int reportTypeId);

        Task<IReadOnlyList<ProgramModel>> GetProgramsAsync();

        Task<IReadOnlyList<DevCenterModel>> GetDevCentersAsync();

        Task<IReadOnlyList<ProductStatusModel>> GetProductStatusesAsync();

        Task<IReadOnlyList<DeliverableIssueModel>> GetActionReportAsync(QueryActionModel queryAction);

        Task<IReadOnlyList<FunctionalGroupModel>> GetGroupsForActionAsync(int issueId);

        Task<IReadOnlyList<ActionRoadmapModel>> GetActionRoadmapItemForTaskAsync(int actionRoadMapId);

        Task<SupportIssueModel> GetSupportTicketInfoAsync(int ticketNumber);

        Task<AppErrorModel> GetApplicationErrorOutstandingAsync(int appErrorId);

        Task<DeliverableIssueModel> GetActionPropertiesAsync(int productId);

        Task<EmployeeModel> GetEmployeeByIdAsync(int userId);

        Task<ProductVersionModel> GetProductVersionAsync(int productVersionId);

        Task<IReadOnlyList<EmployeeModel>> GetToolsProjectOwnersAsync(int productId);

        Task<IReadOnlyList<ActionStatusModel>> GetActionStatusesByTypeAsync(int type);

        Task<IReadOnlyList<ActionSponsorModel>> GetAllActionSponsorsAsync();

        Task<IReadOnlyList<ActionRoadmapModel>> GetActionsRoadmapByProductIdAsync(int productId);

        Task<IReadOnlyList<EmployeeModel>> GetToolsPMsAsync();

        Task<int> InsertComponentActionWebAsync(DeliverableIssueModel deliverableIssue);

        Task<int> UpdateDeliverableActionWebAsync(DeliverableIssueModel deliverableIssue);

        Task<DeliverableIssueModel> GetActionPropertiesForPrintAsync(int id);

        Task<int> UpdateApplicationErrorAsync(int appId, string cause);

        Task<int> UpdateSupportTicketConvertToActionAsync(int ticketId, int actionItemId);
    }
}

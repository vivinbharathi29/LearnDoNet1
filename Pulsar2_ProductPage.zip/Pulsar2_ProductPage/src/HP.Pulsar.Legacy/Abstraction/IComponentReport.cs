﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.DcrModels;
using HP.Pulsar.Legacy.Models.UserInfo;
using HP.Pulsar.Legacy.ViewModels.Dcr;

namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public interface IComponentReport
    {
        Task<ComponentViewModel> GetDeliverablesReportAsync(DeliverablesInputViewModel deliverablesInputViewModel);
        Task<IReadOnlyList<DeliverableRootViewModel>> GetDeliverableRootsAsync(int pageNumber, int pageSize, int hardWareMatrix, int commodityMatrix, int? partnerId);
        Task<ComponentViewModel> GetAllProductsAsync(int? id, int commodityMatrix);
        Task<IReadOnlyList<DevManagerViewModel>> GetDevManagersAsync();
        Task<IReadOnlyList<ProductVersionViewModel>> GetProductGroupsAsync(int? productVersionId, int? productId, string productName);
        Task<IReadOnlyList<VendorViewModel>> GetAllVendorsAsync();
        Task<IReadOnlyList<UserInfoModel>> GetDeliverableVersionDevelopersAsync();
        Task<IReadOnlyList<TestStatusViewModel>> GetTestStatusesAsync();
        Task<IReadOnlyList<LanguageViewModel>> GetLanguagesAsync();
        Task<IReadOnlyList<string>> GetUserSettingAsync(int userId);
        Task<IReadOnlyList<DeliverableCoreTeamViewModel>> GetDeliverableCoreTeamsAsync();
        Task<IReadOnlyList<DeliverableCategoryViewModel>> GetHWCategoriesAsync(int? partnerId, int isCommodityMatrix);
        Task<IReadOnlyList<CommodityPMViewModel>> GetCommodityPMsAsync();
        Task<IReadOnlyList<OSLookUpViewModel>> GetOperatingSystemsAsync();
        Task<IReadOnlyList<SelectOptions>> GetProductGroupsAvailableAsync();
        Task<int> DeliverableProfileFilterActionAsync(ReportProfilePostModel reportProfile);
    }
}

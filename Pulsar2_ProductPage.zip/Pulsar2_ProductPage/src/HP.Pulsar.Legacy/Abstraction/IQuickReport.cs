﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;

namespace HP.Pulsar.Legacy.Abstraction
{
    public interface IQuickReport
    {
        int ReportId { get; }

        Task<IControllerToViewDataModelShim> GetContentModelAsync(IReadOnlyDictionary<string, string> inputModel);

        Task<(IReadOnlyList<IGridGeneralOutput> DataList, int DataCount)> GetGridDataAsync(IReadOnlyDictionary<string, string> inputModel, IPaginationModel pagination);
    }
}
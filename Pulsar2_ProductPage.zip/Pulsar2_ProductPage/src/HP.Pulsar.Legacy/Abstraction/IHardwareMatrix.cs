﻿using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.HardwareMatrix;
using HP.Pulsar.Legacy.ViewModels.HardwareMatrix;
using Infragistics.Web.Mvc;

namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public interface IHardwareMatrix
    {
        Task<HardwareMatrixViewModel> GetProductHardwareMatrixAsync(HardwareMatrixInputViewModel input, HardwareMatrixViewModel hardwareMatrixData);

        Task<HardwareMatrixViewModel> GetProductHardwareMatrixDataAsync(HardwareMatrixInputViewModel input);

        Task<HardwareMatrixViewModel> GetHardwareMatrixAsync(HardwareMatrixInputViewModel input);

        string GetHardwareMatrixReportHtmlContent(HardwareMatrixViewModel input, string lstProducts);

        GridColumn GetGridColumn(string columnKey);

        Task<ReleaseNotesModel> GetChangeNotesAsync(int Id);

        Task<(int? OtsNumber, string OtsDescription)> GetOtsDetailsAsync(int Id);
    }
}

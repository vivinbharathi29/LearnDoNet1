﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Legacy.Models.DcrModels;
using HP.Pulsar.Legacy.Models.UserInfo;

namespace HP.Pulsar.Legacy.Abstraction
{
    //Copied from Pulsar Plus
    public interface IDcrActionRepository
    {
        Task<int> AddActionApproverAsync(ActionApprovalModel actionApproval);

        Task AddBiosPmToInitialAssessmentReviewer(int deliverableIssueId, int? biosPmId, int initialAssessmentCount);

        Task<int> AddDeliverableIssuesHistory(DeliverableIssuesHistoryModel deliverableIssue);

        Task<int> AddDeliverableTodayActionAsync(DeliverableIssueModel deliverableIssue);

        Task<DeliverableIssueModel> GetActionforMailAsync(int deliverableIssueId);

        Task<DeliverableIssueModel> GetActionPropertiesAsync(int id);

        Task<IReadOnlyList<ProductVersionModel>> GetAllProductsAsync(int type, int? partnerId);

        Task<ProductVersionModel> GetApproversAsync(int programId);

        Task<IReadOnlyList<DeliverableIssueModel>> GetChangeRequestGroupAsync(int issueId, long? changeRequestId);

        Task<long?> GetChangeRequestIdAsync(int issueId);

        Task<IReadOnlyList<ProductVersionModel>> GetChangeRequestProductSegementSelectionAsync(int? selectionType, int? selectionFilterId);

        Task<IReadOnlyList<ProductVersionModel>> GetChangeRequestProductSelectionAsync(int? selectionType, int? selectionFilterId);

        Task<IReadOnlyList<CoreTeamRepModel>> GetCoreTeamRepsAsync();

        Task<string> GetDCRNotificationAsync(int programId);

        Task<DcrWorkflowStagingModel> GetDCRWorkflowCheckAsync(int dcrId);

        Task<ProductVersionModel> GetDefaultDCROwnerAsync(int productId, bool isBiosChangeRequest = false);

        Task<DeliverableRootModel> GetDeliverableRootNameAsync(int deliverableRootId);

        Task<IReadOnlyList<EmployeeModel>> GetDeliverableRootScrApproversAsync(int deliverableRootId);

        Task<UserInfoModel> GetEmployeeByIDAsync(int impersonateId);

        Task<IReadOnlyList<DcrUserInfoModel>> GetEmployeeListAsync(string userNamePattern);

        Task<IReadOnlyList<FunctionalGroupModel>> GetGroupsForActionAsync(int issueId);

        Task<IReadOnlyList<RegionModel>> GetLanguagesAsync();

        Task<IReadOnlyList<DcrActionApprovalModel>> GetListApprovalsAsync(int actionId, int? approverId);

        Task<IReadOnlyList<OSLookupModel>> GetOperatingSystemsAsync(bool isActive, bool isImagePackage);

        Task<string> GetPCEmailForTodayActionAsync(int productId);

        Task<EmployeeModel> GetPMAsync(int productId);

        Task<EmployeeModel> GetProductBiosLeadAsync(int productId);

        Task<IReadOnlyList<EmployeeModel>> GetProductDcrApproversAsync(int productVersionId);

        Task<IReadOnlyList<ProgramModel>> GetProductProgramTreeAsync(string productGroupIds = null);

        Task<ProductVersionModel> GetProductVersionAsync(int productVersionID);

        Task<ProductVersionModel> GetProductVersionNameAsync(int productId, int releaseId = 0);

        Task<IReadOnlyList<DcrWorkflowStagingModel>> GetScheduleRTPandEOMDatebyProductIdAsync(int productId, string releaseName);

        Task<IReadOnlyList<EmployeeModel>> GetSystemTeamApproversAsync(int productVersionId);

        Task<IReadOnlyList<EmployeeModel>> GetSystemTeamAsync(int? prodId);

        Task<IReadOnlyList<ProductVersionModel>> GetTodayActionProductsAsync();

        Task<EmployeeModel> GetUserNameAndEmailAsync(int userId);

        Task<ActionApprovalModel> GetVerifyAutoApproveAsync(int actionId);

        Task<IReadOnlyList<DeliverableIssueModel>> ListAllActionOwnersAsync();

        Task<int> SetApprovalForActionAsync(int actionId);

        Task<int> UpdateActionApproverAsync(ActionApprovalModel actionApproval);

        Task<int> UpdateDeliverableIssueActionWebAsync(DeliverableIssueModel deliverableIssue);
    }
}

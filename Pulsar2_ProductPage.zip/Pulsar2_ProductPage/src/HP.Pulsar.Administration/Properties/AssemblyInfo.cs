﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("HP.Pulsar.MVC")]
[assembly: InternalsVisibleTo("PulsarUnitTests")]

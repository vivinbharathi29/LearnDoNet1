﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HP.Pulsar.Administration.Abstraction;
using HP.Pulsar.Administration.Models;
using HP.Pulsar.CommonContracts.Repository;

namespace HP.Pulsar.Administration.Repository
{
    internal class MessageQueueRepository : IMessageQueueRepository
    {
        private readonly IPulsarDataContext _dataContext;

        public MessageQueueRepository(IPulsarDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public async Task<IReadOnlyList<EmailModel>> GetEmailsAsync(int dataLimitCount, bool isNotSent)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                 new SqlParameter("Number", dataLimitCount),
                 new SqlParameter("IsNotSent", isNotSent)
            };

            List<(string, string, Type)> modelMappings = new List<(string, string, Type)>
            {
                (nameof(EmailModel.EmailId), "QueuedEmailID", typeof(int)),
                (nameof(EmailModel.Priority), "Priority", typeof(int)),
                (nameof(EmailModel.From), "From", typeof(string)),
                (nameof(EmailModel.FromName), "FromName", typeof(string)),
                (nameof(EmailModel.To), "To", typeof(string)),
                (nameof(EmailModel.ToName), "ToName", typeof(string)),
                (nameof(EmailModel.Cc), "Cc", typeof(string)),
                (nameof(EmailModel.Bcc), "Bcc", typeof(string)),
                (nameof(EmailModel.Subject), "Subject", typeof(string)),
                (nameof(EmailModel.Body), "Body", typeof(string)),
                (nameof(EmailModel.CreatedDate), "Created", typeof(DateTime)),
                (nameof(EmailModel.RetryCount), "SendTries", typeof(int)),
                (nameof(EmailModel.SentDate), "Sent", typeof(DateTime?)),
                (nameof(EmailModel.AccountId), "EmailAccountId", typeof(int)),
                (nameof(EmailModel.Attachments), "Attachments", typeof(string))
            };

            (IReadOnlyList<EmailModel> Models, _) = await _dataContext.GetDataModelsAsync<EmailModel>(AdminProcedureNames.GetMessageQueuedEmails, parameters, modelMappings).ConfigureAwait(false);

            return Models;
        }

        public async Task<bool> UpdateEmailsAsync(int queuedEmailId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("QueuedEmailID", queuedEmailId)
            };

            return await _dataContext.ExecuteNonQueryAsync(AdminProcedureNames.ResendMessageQueuedEmails, parameters) > 0;
        }
    }
}
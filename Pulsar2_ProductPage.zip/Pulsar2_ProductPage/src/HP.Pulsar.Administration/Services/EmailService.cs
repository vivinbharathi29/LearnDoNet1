﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Administration.Abstraction;
using HP.Pulsar.Administration.Models;

namespace HP.Pulsar.Administration.Services
{
    internal class EmailService : IEmailService
    {
        private IMessageQueueRepository _repository;

        public EmailService(IMessageQueueRepository messageQueuedRepository)
        {
            _repository = messageQueuedRepository;
        }

        public Task<IReadOnlyList<EmailModel>> GetEmailsAsync(int dataLimitCount, bool isNotSent)
        {
            if(dataLimitCount == 0)
            {
                return null;
            }

            return _repository.GetEmailsAsync(dataLimitCount, isNotSent);
        }

        public async Task SendEmailsAsync(IReadOnlyList<int> Ids)
        {
            foreach (int id in Ids)
            {
                await _repository.UpdateEmailsAsync(id);
            };
        }
    }
}

﻿using System;

namespace HP.Pulsar.Administration.Models
{
    public class EmailModel
    {
        public int AccountId { get; set; }
        public string Attachments { get; set; }
        public string Bcc { get; set; }
        public string Body { get; set; }
        public string Cc { get; set; }
        public DateTime CreatedDate { get; set; }
        public string From { get; set; }
        public string FromName { get; set; }
        public int Priority { get; set; }
        public int EmailId { get; set; }
        public int RetryCount { get; set; }
        public DateTime? SentDate { get; set; }
        public string Subject { get; set; }
        public string To { get; set; }
        public string ToName { get; set; }
    }
}

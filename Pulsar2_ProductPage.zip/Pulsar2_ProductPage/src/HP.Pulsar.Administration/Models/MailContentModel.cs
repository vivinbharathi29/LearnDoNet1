﻿using System.Collections.Generic;

namespace HP.Pulsar.Administration.Models
{
    public class MailContentModel
    {
        public IReadOnlyList<EmailModel> MessageQueuedEmailList;
    }
}

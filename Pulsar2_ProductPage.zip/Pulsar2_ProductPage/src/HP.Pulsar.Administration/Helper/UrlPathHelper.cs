﻿using System;

namespace HP.Pulsar.Administration.Helper
{
    public static class UrlPathHelper
    {
        public static string GetPageUrlPath(string controlerName, string actionName)
        {
            if(String.IsNullOrEmpty(controlerName) || String.IsNullOrEmpty(actionName))
            {
                return String.Empty;
            }

            return $"{controlerName}/{actionName}";
        }
    }
}

﻿namespace HP.Pulsar.Administration
{
    public static class ControllerNameConstants
    {
        public static readonly string MailStatus = "MailStatus";
    }
}

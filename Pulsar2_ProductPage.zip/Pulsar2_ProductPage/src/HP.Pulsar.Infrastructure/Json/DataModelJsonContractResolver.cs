﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace HP.Pulsar.Infrastructure.Json
{
    public class DataModelJsonContractResolver : DefaultContractResolver
    {
        private readonly Dictionary<string, JsonConverter> _mappingDictionary;

        public DataModelJsonContractResolver(Dictionary<string, JsonConverter> mappingDictionary)
        {
            _mappingDictionary = mappingDictionary ?? new Dictionary<string, JsonConverter>(StringComparer.OrdinalIgnoreCase);
        }

        protected override JsonProperty CreateProperty(MemberInfo member, MemberSerialization memberSerialization)
        {
            JsonProperty property = base.CreateProperty(member, memberSerialization);

            if (_mappingDictionary.TryGetValue(property.PropertyName, out JsonConverter converter))
            {
                property.Converter = converter;
            }

            return property;
        }
    }
}

﻿using System;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.Json
{
    public class EnumClassToStringJsonConvertor<T> : JsonConverter<T> where T : class
    {
        public override void WriteJson(JsonWriter writer, T value, JsonSerializer serializer)
        {
            writer.WriteValue(value.ToString());
        }

        public override T ReadJson(JsonReader reader, Type objectType, T existingValue, bool hasExistingValue, JsonSerializer serializer)
        {
            return existingValue;
        }
    }
}

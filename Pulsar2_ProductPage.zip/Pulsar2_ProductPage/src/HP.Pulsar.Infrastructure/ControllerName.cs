﻿namespace HP.Pulsar.Infrastructure
{
    public static class ControllerName
    {
        public static readonly string Tile = "Tile";

        public static readonly string Popup = "Popup";

        public static readonly string QuickSearchMoreResults = "QuickSearchMoreResults";
    }
}
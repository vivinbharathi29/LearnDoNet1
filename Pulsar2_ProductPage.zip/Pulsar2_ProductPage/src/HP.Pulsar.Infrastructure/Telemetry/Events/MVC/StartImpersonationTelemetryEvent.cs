﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class StartImpersonationTelemetryEvent : MVCProjectRootTelemetryEvent
    {
        public StartImpersonationTelemetryEvent()
            : base("Start-Impersonation", TelemetryType.Event, TelemetryEventIdConstants.StartImpersonationEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.StartImpersonationEventId;
    }
}

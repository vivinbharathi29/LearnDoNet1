﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class UserHasInvalidLoginNameTelemetryEvent : MVCProjectRootTelemetryEvent
    {
        public UserHasInvalidLoginNameTelemetryEvent()
            : base("Has-InvalidLoginName",
                   TelemetryType.Event,
                   TelemetryEventIdConstants.UserHasInvalidLoginNameEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.UserHasInvalidLoginNameEventId;
    }
}

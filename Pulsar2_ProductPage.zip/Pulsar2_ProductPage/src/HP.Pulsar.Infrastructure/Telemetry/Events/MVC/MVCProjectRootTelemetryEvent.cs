﻿using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.MVC
{
    public abstract class MVCProjectRootTelemetryEvent : PulsarRootTelemetryEvent
    {
        public MVCProjectRootTelemetryEvent(string leafEventName, TelemetryType telemetryType, int telemetryEventId)
            : base(leafEventName, telemetryType, telemetryEventId)
        {
            AddPrefixSegment("MVCProject");
        }
    }
}

﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class UserAddFavoriteTelemetryEvent : MVCProjectRootTelemetryEvent
    {
        public UserAddFavoriteTelemetryEvent()
            : base("Add-UserFavorite",
                   TelemetryType.Event,
                   TelemetryEventIdConstants.UserAddFavoriteEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.UserAddFavoriteEventId;
    }
}

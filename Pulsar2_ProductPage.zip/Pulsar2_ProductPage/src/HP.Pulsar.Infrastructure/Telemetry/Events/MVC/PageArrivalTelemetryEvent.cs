﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class PageArrivalTelemetryEvent : MVCProjectRootTelemetryEvent
    {
        public PageArrivalTelemetryEvent()
            : base("Arrive-Page",
                   TelemetryType.Event,
                   TelemetryEventIdConstants.PageOrActionArrivalEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.PageOrActionArrivalEventId;
    }
}

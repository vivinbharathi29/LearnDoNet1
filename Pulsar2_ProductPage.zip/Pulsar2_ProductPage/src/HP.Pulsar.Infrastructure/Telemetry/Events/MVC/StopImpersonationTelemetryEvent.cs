﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class StopImpersonationTelemetryEvent : MVCProjectRootTelemetryEvent
    {
        public StopImpersonationTelemetryEvent()
            : base("Stop-Impersonation", TelemetryType.Event, TelemetryEventIdConstants.StopImpersonationEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.StopImpersonationEventId;
    }
}

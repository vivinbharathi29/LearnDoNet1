﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class UserFeedbackTelemetryEvent: MVCProjectRootTelemetryEvent
    {
        public UserFeedbackTelemetryEvent()
            : base("Send-UserFeedback",
                   TelemetryType.Event,
                   TelemetryEventIdConstants.UserFeedbackEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.UserFeedbackEventId;
    }
}

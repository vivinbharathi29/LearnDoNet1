﻿using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.Infrastructure
{
    public class PulsarUserRootTelemetryEvent : PulsarRootTelemetryEvent
    {
        protected PulsarUserRootTelemetryEvent(string eventName, TelemetryType telemetryType, int telemetryEventId)
            : base(eventName, telemetryType, telemetryEventId)
        {
            AddPrefixSegment("PulsarUser");
        }
    }
}

﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.Infrastructure
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class MenuItemWithNoRootTelemetryEvent : PulsarUserRootTelemetryEvent
    {
        public MenuItemWithNoRootTelemetryEvent()
          : base("MenuItem-NoRoot", TelemetryType.Event, TelemetryEventIdConstants.MenuItemWithNoRootEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.MenuItemWithNoRootEventId;
    }
}

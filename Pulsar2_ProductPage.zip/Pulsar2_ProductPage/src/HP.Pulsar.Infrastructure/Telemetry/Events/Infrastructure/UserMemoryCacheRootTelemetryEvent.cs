﻿using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.Infrastructure
{
    public abstract class UserMemoryCacheRootTelemetryEvent : PulsarRootTelemetryEvent
    {
        protected UserMemoryCacheRootTelemetryEvent(string leafEventName, TelemetryType telemetryType, int telemetryEventId)
            : base(leafEventName, telemetryType, telemetryEventId)
        {
            AddPrefixSegment("MemoryCache");
        }
    }
}

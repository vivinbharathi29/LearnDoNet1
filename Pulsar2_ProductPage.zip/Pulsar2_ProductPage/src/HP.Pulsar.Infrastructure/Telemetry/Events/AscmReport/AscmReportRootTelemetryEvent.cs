﻿using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.AscmReport
{
    public abstract class AscmReportRootTelemetryEvent : PulsarRootTelemetryEvent
    {
        public AscmReportRootTelemetryEvent(string leafEventName, TelemetryType telemetryType, int telemetryEventId)
            : base(leafEventName, telemetryType, telemetryEventId)
        {
            AddPrefixSegment("AscmProject");
        }
    }
}
﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;
using HP.Pulsar.Infrastructure.Telemetry.Events.AscmReport;

namespace HP.Pulsar.Infrastructure.Telemetry.Events.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class AscmReportPublishedTelemetryEvent : AscmReportRootTelemetryEvent
    {
        public AscmReportPublishedTelemetryEvent()
            : base("Trigger-AscmReportApi",
                   TelemetryType.Event,
                   TelemetryEventIdConstants.AscmReportPublishedTelemetryEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.AscmReportPublishedTelemetryEventId;
    }
}
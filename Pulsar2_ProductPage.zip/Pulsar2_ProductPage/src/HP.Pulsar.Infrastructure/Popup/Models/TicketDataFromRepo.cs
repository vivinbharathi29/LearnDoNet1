﻿using System;
using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.TodayPage.Popup;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;

namespace HP.Pulsar.Infrastructure.Popup.Models
{
    public class TicketDataFromRepo : IGridGeneralOutput
    {
        public int? ActionItemId { get; set; }

        public int? ActionProjectId { get; set; }

        public string Attachment1 { get; set; }

        public string Attachment2 { get; set; }

        public string Attachment3 { get; set; }

        public int? CategoryId { get; set; }

        public string CategoryName { get; set; }

        public DateTime? ClosedDate { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string Details { get; set; }

        public string DeveloperResponse { get; set; }

        public int Id { get; set; }

        public bool IsFunctional { get; set; }

        public string IssueType { get; set; }

        public DateTime? LastUpdatedDate { get; set; }

        public string OwnerEmail { get; set; }

        public int? OwnerId { get; set; }

        public string OwnerName { get; set; }

        public int? PreventionId { get; set; }

        public int? PriorityLevelId { get; set; }

        public int? ProjectId { get; set; }

        public string ProjectName { get; set; }

        public string Resolution { get; set; }

        public int? RootCauseId { get; set; }

        public string Status { get; set; }

        public int? StatusId { get; set; }

        public DateTime? SubmittedDate { get; set; }

        public string SubmitterEmail { get; set; }

        public int? SubmitterId { get; set; }

        public string SubmitterName { get; set; }

        public int? SubmitterPartnerId { get; set; }

        public string Summary { get; set; }

        public IReadOnlyList<IUserInfoModel> SupportAdmin { get; set; }

        public IDictionary<int, string> SupportCategory { get; set; }

        public SupportIssueStatus SupportIssueStatus { get; set; }

        public SupportIssueType SupportIssueType { get; set; }

        public IDictionary<int, string> SupportProjects { get; set; }

        public int? TypeId { get; set; }

        public int? UserPriorityId { get; set; }

        public int? UserStatusId { get; set; }
    }
}

﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    //JsontProperty Attribute was used to align the IgGrid feature names in camel case.
    //https://www.igniteui.com/help/iggrid-column-resizing
    public class IgGridColumnResizing
    {
        public IgGridColumnResizing()
        {
            Name = "Resizing";
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "columnSettings")]
        public IList<IgGridResizingColumnSettings> ColumnSettings { get; set; }
    }
}

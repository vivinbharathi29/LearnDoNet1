﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Infrastructure.Popup;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridContentModelOperation : IGridContentModelOperation
    {
        private string _confirmationMessageBeforePost;
        private ColumnValueSeparator _gridColumnValueSeparator;

        public IgGridContentModelOperation()
        {
            _gridColumnValueSeparator = ColumnValueSeparator.Hyphen;
            _confirmationMessageBeforePost = PostDataConfirmationMessage;
        }

        public string ConfirmationMessageBeforePost
        {
            get
            {
                return _confirmationMessageBeforePost;
            }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    _confirmationMessageBeforePost = value;
                }
            }
        }

        public static string CommentRequiredErrorMessage => "Comment is Required. Enter comment and try again.";

        public IReadOnlyList<string> GridColumnNames { get; set; }

        public ColumnValueSeparator GridColumnValueSeparator
        {
            get
            {
                return _gridColumnValueSeparator;
            }
            set
            {
                if (value != null)
                {
                    _gridColumnValueSeparator = value;
                }
            }
        }

        public bool IsGridRefreshRequired { get; set; }

        public bool IsSeparateQueryStringRequiredForGridColumns { get; set; }

        public string JavascriptFunctionName { get; set; }

        public static string NoSelectedRowErrorMessage => "Select at least one row in the grid by checking the checkbox in the first column.";

        public string OnRenderJavascriptionFunctionName { get; set; }

        public string OperationName { get; set; }

        public string OperationUrlPath { get; set; }

        public static string PostDataConfirmationMessage => "Are you sure you like to post the data?";

        public PopupSize PopupSize { get; set; }

        public string PopupTitle { get; set; }

        public GridContentModelOperationType Type { get; set; }
    }
}
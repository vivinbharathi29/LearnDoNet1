﻿using System;
using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public static class IgGridHelper
    {
        public static string GetFilterColumnType(string inputValue)
        {
            if (string.IsNullOrWhiteSpace(inputValue))
            {
                // default to string
                return nameof(FilterColumnType.String).ToLower();
            }

            if (DateTime.TryParse(inputValue, out DateTime time)
                || inputValue.IndexOf("DateTime", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return nameof(FilterColumnType.Date).ToLower();
            }

            if (long.TryParse(inputValue, out long intValue)
                || inputValue.IndexOf("Int32", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return nameof(FilterColumnType.Number).ToLower();
            }

            //Iggrid accept bool instead of boolean.
            if (bool.TryParse(inputValue, out bool boolValue)
                || inputValue.IndexOf("Boolean", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "bool";
            }

            // default to string
            return nameof(FilterColumnType.String).ToLower();
        }


        public static IgGridFeatures GetDefaultGridFeatures()
        {
            return new IgGridFeatures
            {
                RowSelector = new IgGridRowSelector(),
                RowSelection = new IgGridRowSelection(),
                Paging = new IgGridPaging(),
                Filtering = new IgGridFiltering
                {
                    ColumnSettings = new List<IgGridFilterColumnSettings>
                    {
                        new IgGridFilterColumnSettings("",false)
                    }
                },
                Sorting = new IgGridSorting
                {
                    ColumnSettings = new List<IgGridSortingColumnSettings>
                    {
                        new IgGridSortingColumnSettings("",false)
                    }
                },
                ToolTips = new IgGridToolTips(),
                Updating = new IgGridUpdating
                {
                    ColumnSettings = new List<IgGridUpdateColumnSettings>
                    {
                        new IgGridUpdateColumnSettings("")
                    }
                },
                GroupBy = new IgGridGroupBy
                {
                    ColumnSettings = new List<IgGridGroupByColumnSettings>
                    {
                        new IgGridGroupByColumnSettings("", false)
                    }
                },
                ColumnResizing = new IgGridColumnResizing
                { 
                   ColumnSettings= new List<IgGridResizingColumnSettings>
                   { 
                       new IgGridResizingColumnSettings("", false)
                   }
                }
            };
        }
    }
}

﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridResizingColumnSettings
    {
        public IgGridResizingColumnSettings(string columnKey, bool allowResizing)
        {
            ColumnKey = columnKey;
            AllowResizing = allowResizing;
        }

        [JsonProperty(PropertyName = "columnKey", NullValueHandling = NullValueHandling.Ignore)]
        public string ColumnKey { get; }

        [JsonProperty(PropertyName = "allowResizing", NullValueHandling = NullValueHandling.Ignore)]
        public bool AllowResizing { get; }
    }
}

﻿namespace HP.Pulsar.Infrastructure.IgGrid
{
    public enum IgGridEvent
    {
        CheckBoxStateChanging,
        RowSelectionChanging
    }
}

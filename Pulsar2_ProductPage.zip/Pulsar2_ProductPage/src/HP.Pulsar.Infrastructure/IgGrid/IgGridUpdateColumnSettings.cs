﻿using System.Collections.Generic;
using HP.Pulsar.Infrastructure.Json;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridUpdateColumnSettings
    {
        public IgGridUpdateColumnSettings(string columnKey)
        {
            ColumnKey = columnKey;
            ReadOnly = true;
        }

        public IgGridUpdateColumnSettings(string columnKey, string editorType, bool required, IDictionary<string, object> editorOptions)
        {
            ColumnKey = columnKey;
            EditorType = editorType;
            Required = required;
            EditorOptions = GetEditorOptionsFromDictionary(editorOptions);
        }

        [JsonProperty(PropertyName = "columnKey", NullValueHandling = NullValueHandling.Ignore)]
        public string ColumnKey { get; }

        [JsonProperty(PropertyName = "readOnly", NullValueHandling = NullValueHandling.Ignore)]
        public bool ReadOnly { get; }

        [JsonProperty(PropertyName = "required", NullValueHandling = NullValueHandling.Ignore)]
        public bool Required { get; }

        [JsonProperty(PropertyName = "editorType", NullValueHandling = NullValueHandling.Ignore)]
        public string EditorType { get; }

        [JsonProperty(PropertyName = "editorOptions", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(PlainJsonStringConverter))]
        public string EditorOptions { get; }

        private static string GetEditorOptionsFromDictionary(IDictionary<string, object> editorOptions)
        {
            return JsonConvert.SerializeObject(editorOptions);
        }
    }
}

﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridMultiColumnHeaders
    {
        public IgGridMultiColumnHeaders()
        {
            Name = "MultiColumnHeaders";
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }
    }
}

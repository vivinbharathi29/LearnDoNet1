﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridColumnData
    {
        public IgGridColumnData(string key, string headerText, string dataType, string width, bool isHidden, string format, string columnCssClass, string template)
        {
            Key = key;
            HeaderText = headerText;
            DataType = dataType;
            Width = width;
            IsHidden = isHidden;
            Format = format;
            ColumnCssClass = columnCssClass;
            Template = template;
        }

        [JsonProperty(PropertyName = "headerText", NullValueHandling = NullValueHandling.Ignore)]
        public string HeaderText { get; set; }

        [JsonProperty(PropertyName = "key")]
        public string Key { get; }

        [JsonProperty(PropertyName = "dataType")]
        public string DataType { get; }

        [JsonProperty(PropertyName = "width", NullValueHandling = NullValueHandling.Ignore)]
        public string Width { get; }

        [JsonProperty(PropertyName = "hidden", NullValueHandling = NullValueHandling.Ignore)]
        public bool IsHidden { get; set; }

        [JsonProperty(PropertyName = "format", NullValueHandling = NullValueHandling.Ignore)]
        public string Format { get; }

        [JsonProperty(PropertyName = "columnCssClass", NullValueHandling = NullValueHandling.Ignore)]
        public string ColumnCssClass { get; }

        [JsonProperty(PropertyName = "template", NullValueHandling = NullValueHandling.Ignore)]
        public string Template { get; }
    }
}

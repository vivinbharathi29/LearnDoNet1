﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    //JsonProperty Attribute was used to align the IgGrid feature names in camel case.
    //https://www.igniteui.com/grid/append-rows-on-demand
    public class IgGridAppendRowsOnDemand
    {
        public IgGridAppendRowsOnDemand(int? chunkSize = null)
        {
            Name = "AppendRowsOnDemand";
            LoadTrigger = "auto";
            Type = "local";
            ChunkSize = chunkSize.HasValue ? chunkSize.Value : default;
        }

        [JsonProperty(PropertyName = "chunkSize")]
        public int ChunkSize { get; }

        [JsonProperty(PropertyName = "loadTrigger")]
        public string LoadTrigger { get; }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "type")]
        public string Type { get; }
    }
}

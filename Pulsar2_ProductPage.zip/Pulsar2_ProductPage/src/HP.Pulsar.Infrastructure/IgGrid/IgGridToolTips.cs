﻿using HP.Pulsar.Infrastructure.Json;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridToolTips
    {
        public IgGridToolTips()
        {
            Name = "Tooltips";
            Style = "popover";
            Visibility = "overflow";
            ToolTipShowing = "igGridTooltTipShowing";
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "style")]
        public string Style { get; }

        [JsonProperty(PropertyName = "visibility")]
        public string Visibility { get; } 

        [JsonProperty(PropertyName = "tooltipShowing")]
        [JsonConverter(typeof(PlainJsonStringConverter))]
        public string ToolTipShowing { get; }
    }
}

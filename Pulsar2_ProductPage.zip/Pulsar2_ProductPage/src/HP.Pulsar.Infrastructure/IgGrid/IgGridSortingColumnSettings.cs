﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
  public  class IgGridSortingColumnSettings
  {
        public IgGridSortingColumnSettings(string columnKey, bool allowSorting)
        {
            ColumnKey = columnKey;
            AllowSorting = allowSorting;
        }

        [JsonProperty(PropertyName = "columnKey", NullValueHandling = NullValueHandling.Ignore)]
        public string ColumnKey { get; }

        [JsonProperty(PropertyName = "allowSorting", NullValueHandling = NullValueHandling.Ignore)]
        public bool AllowSorting { get; }
    }
}

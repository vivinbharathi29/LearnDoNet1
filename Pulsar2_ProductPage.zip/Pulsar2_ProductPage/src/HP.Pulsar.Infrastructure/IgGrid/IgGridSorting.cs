﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    //JsontProperty Attribute was used to align the IgGrid feature names in camel case.
    //https://www.igniteui.com/help/iggrid-sorting-overview
    public class IgGridSorting
    {
        public IgGridSorting()
        {
            Name = "Sorting";
            Type = "remote";
            SortUrlKey = "sort";
            SortUrlKeyAscValue = "asc";
            SortUrlKeyDescValue = "desc";
            Persist = true;
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "type")]
        public string Type { get; set; }

        [JsonProperty(PropertyName = "persist")]
        public bool Persist { get; }

        [JsonProperty(PropertyName = "sortUrlKey")]
        public string SortUrlKey { get; }

        [JsonProperty(PropertyName = "sortUrlKeyAscValue")]
        public string SortUrlKeyAscValue { get; }

        [JsonProperty(PropertyName = "sortUrlKeyDescValue")]
        public string SortUrlKeyDescValue { get; }

        [JsonProperty(PropertyName = "columnSettings")]
        public IList<IgGridSortingColumnSettings> ColumnSettings { get; set; }
    }
}

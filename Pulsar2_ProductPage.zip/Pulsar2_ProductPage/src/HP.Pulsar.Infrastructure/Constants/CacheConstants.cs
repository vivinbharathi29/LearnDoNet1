﻿namespace HP.Pulsar.Infrastructure.Constants
{
    public static class CacheConstants
    {
        /// <summary>
        /// Cache expiration duration and the measure unit is minute
        /// </summary>
        public static readonly int DefaultExpirationDuration = 30;

        /// <summary>
        /// This is for tile count item. Cache expiration duration and the measure unit is minute
        /// </summary>
        public static readonly int TileCountAbsoluteDuration = 10;

        /// <summary>
        /// Cache scan frequency and the measure unit is minute
        /// </summary>
        public static readonly int DefaultScanFrequence = 30;

        /// <summary>
        /// Default size of cache
        /// </summary>
        public static readonly int DefaultSize = 1024;
    }
}

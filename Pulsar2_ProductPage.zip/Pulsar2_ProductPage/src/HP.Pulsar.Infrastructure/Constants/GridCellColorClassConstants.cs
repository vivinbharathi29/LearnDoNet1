﻿namespace HP.Pulsar.Infrastructure.Constants
{
    // The class names for the grid cell background color's are here.
    public static class GridCellColorClassConstants
    {
        public static string GroupHeaderColor = "HighlightCell__groupHeading";

        public static string LightGrayBackgroundColor = "HighlightCell__gray";

        public static string LightGreenBackgroundColor = "HighlightCell__safe";

        public static string LightRedBackgroundColor = "HighlightCell__dangerous";

        public static string LightYellowBackgroundColor = "HighlightCell__warning";
    }
}
﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.Model
{
    public class AutoCompleteItem
    {
        [JsonProperty(PropertyName = "id")]
        public int Id { get; }

        [JsonProperty(PropertyName = "label")]
        public string Label { get; }

        public AutoCompleteItem(int id, string label)
        {
            Id = id;
            Label = label;
        }
    }
}
﻿namespace HP.Pulsar.Infrastructure
{
    // TODO - when TodayPage is going to move to RCL, this class should 
    // be moved to TodayPage.Infrastructure folder.
    public static class ActionName
    {
        public static readonly string GetTileCount = "GetTileCount";

        public static readonly string GetTileData = "GetTileData";

        public static readonly string PostData = "PostData";

        public static readonly string ShowContent = "ShowContent";
    }
}
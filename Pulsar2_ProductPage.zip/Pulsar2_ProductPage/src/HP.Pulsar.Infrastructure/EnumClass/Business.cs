﻿namespace HP.Pulsar.Infrastructure.EnumClass
{
    public enum Business
    {
        Commercial = 1,
        Consumer = 2,
        SMB = 3,
        Tablet = 4,
        Mobility = 5
    }
}
﻿namespace HP.Pulsar.Infrastructure.EnumClass
{
    public enum BusinessSegmentOperation
    {
        MobileAndNoteBook = 0,
        Desktop = 1,
        AccessoriesAndDisplays = 2
    }
}

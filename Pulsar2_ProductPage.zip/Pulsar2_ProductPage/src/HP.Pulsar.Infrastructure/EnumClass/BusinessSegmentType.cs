﻿namespace HP.Pulsar.Infrastructure.EnumClass
{
    public sealed class BusinessSegmentType
    {
        public static BusinessSegmentType None = new BusinessSegmentType(-1, "", "", -1);
        public static BusinessSegmentType DesktopCommercial = new BusinessSegmentType(1, "Desktop - Commercial", "bDT", 1);
        public static BusinessSegmentType DesktopConsumer = new BusinessSegmentType(2, "Desktop - Consumer", "cDT", 2);
        public static BusinessSegmentType DesktopThinClients = new BusinessSegmentType(3, "Desktop - Thin Clients", "TCD", 1);
        public static BusinessSegmentType DesktopRetailSolutions = new BusinessSegmentType(4, "Desktop - Retail Solutions", "RPOS", 1);
        public static BusinessSegmentType MobileWorkstations = new BusinessSegmentType(5, "Mobile Workstations", "WksM", 1);
        public static BusinessSegmentType MobilityConsumer = new BusinessSegmentType(6, "Mobility - Consumer", "cMB", 2);
        public static BusinessSegmentType NotebookCommercial = new BusinessSegmentType(7, "Notebook - Commercial", "bNB", 1);
        public static BusinessSegmentType NotebookConsumer = new BusinessSegmentType(8, "Notebook - Consumer", "CNB", 2);
        public static BusinessSegmentType DesktopWorkstations = new BusinessSegmentType(9, "Desktop - Workstations", "WksD", 1);
        public static BusinessSegmentType MobilityCommercial = new BusinessSegmentType(10, "Mobility - Commercial", "bMB", 1);
        public static BusinessSegmentType MobileThinClients = new BusinessSegmentType(11, "Mobile Thin Clients", "TCM", 1);
        public static BusinessSegmentType PSGOther = new BusinessSegmentType(12, "PSG Other", "Other", 2);
        public static BusinessSegmentType ImmersiveComputing = new BusinessSegmentType(13, "Immersive Computing", "IMMCOMPT", 1);
        public static BusinessSegmentType DisplaysCommercial = new BusinessSegmentType(14, "Displays - Commercial", "DisplayBus", 1);
        public static BusinessSegmentType DisplaysConsumer = new BusinessSegmentType(15, "Displays - Consumer", "DisplaycPC", 1);
        public static BusinessSegmentType DisplaysNotebooks = new BusinessSegmentType(16, "Displays Notebooks", "DisplayNB", 1);
        public static BusinessSegmentType DisplaysPersonalWorkstations = new BusinessSegmentType(17, "Displays Personal Workstations", "DisplayWks", 2);
        public static BusinessSegmentType VirtualReality = new BusinessSegmentType(18, "Virtual Reality", "Comm - VR", 1);
        public static BusinessSegmentType AccessoriesCommercial = new BusinessSegmentType(19, "Accessories - Commercial", "AccyBus", 1);
        public static BusinessSegmentType AccessoriesConsumer = new BusinessSegmentType(20, "Accessories - Consumer", "AccyCPC", 2);
        public static BusinessSegmentType Accessories3PO = new BusinessSegmentType(21, "Accessories - 3PO", "Accy3PO", 1);

        private BusinessSegmentType(int id, string name, string abbreviation, int businessId)
        {
            Id = id;
            Name = name;
            Abbreviation = abbreviation;
            BusinessId = businessId;
        }

        public int Id { get; }

        public string Name { get; }

        public string Abbreviation { get; }

        public int BusinessId { get; }

        public static bool TryGet(int businessSegmentTypeId, out BusinessSegmentType businessSegmentType)
        {
            if (businessSegmentTypeId == 1)
            {
                businessSegmentType = DesktopCommercial;
                return true;
            }

            if (businessSegmentTypeId == 2)
            {
                businessSegmentType = DesktopConsumer;
                return true;
            }

            if (businessSegmentTypeId == 3)
            {
                businessSegmentType = DesktopThinClients;
                return true;
            }

            if (businessSegmentTypeId == 4)
            {
                businessSegmentType = DesktopRetailSolutions;
                return true;
            }

            if (businessSegmentTypeId == 5)
            {
                businessSegmentType = MobileWorkstations;
                return true;
            }

            if (businessSegmentTypeId == 6)
            {
                businessSegmentType = MobilityConsumer;
                return true;
            }

            if (businessSegmentTypeId == 7)
            {
                businessSegmentType = NotebookCommercial;
                return true;
            }

            if (businessSegmentTypeId == 8)
            {
                businessSegmentType = NotebookConsumer;
                return true;
            }

            if (businessSegmentTypeId == 9)
            {
                businessSegmentType = DesktopWorkstations;
                return true;
            }

            if (businessSegmentTypeId == 10)
            {
                businessSegmentType = MobilityCommercial;
                return true;
            }

            if (businessSegmentTypeId == 11)
            {
                businessSegmentType = MobileThinClients;
                return true;
            }

            if (businessSegmentTypeId == 12)
            {
                businessSegmentType = PSGOther;
                return true;
            }

            if (businessSegmentTypeId == 13)
            {
                businessSegmentType = ImmersiveComputing;
                return true;
            }

            if (businessSegmentTypeId == 14)
            {
                businessSegmentType = DisplaysCommercial;
                return true;
            }

            if (businessSegmentTypeId == 15)
            {
                businessSegmentType = DisplaysConsumer;
                return true;
            }

            if (businessSegmentTypeId == 16)
            {
                businessSegmentType = DisplaysNotebooks;
                return true;
            }

            if (businessSegmentTypeId == 17)
            {
                businessSegmentType = DisplaysPersonalWorkstations;
                return true;
            }

            if (businessSegmentTypeId == 18)
            {
                businessSegmentType = VirtualReality;
                return true;
            }

            if (businessSegmentTypeId == 19)
            {
                businessSegmentType = AccessoriesCommercial;
                return true;
            }

            if (businessSegmentTypeId == 20)
            {
                businessSegmentType = AccessoriesConsumer;
                return true;
            }

            if (businessSegmentTypeId == 21)
            {
                businessSegmentType = Accessories3PO;
                return true;
            }

            businessSegmentType = null;
            return false;
        }

        // Used by repository data conversion
        public static object Convert(object input)
        {
            if (input != null
                && int.TryParse(input.ToString(), out int value)
                && TryGet(value, out BusinessSegmentType segmentType))
            {
                return segmentType;
            }

            return None;
        }
    }
}

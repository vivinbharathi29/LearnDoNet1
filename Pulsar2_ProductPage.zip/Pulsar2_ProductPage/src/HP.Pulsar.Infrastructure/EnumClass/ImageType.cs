﻿namespace HP.Pulsar.Infrastructure.EnumClass
{
    //This Enum Class is a reference of imagetype table and spListImageTypes stored procedure. 
    public sealed class ImageType
    {
        public static ImageType None = new ImageType(-1, "None", false);
        public static ImageType FactoryImage = new ImageType(1, "Factory Image", true);
        public static ImageType RestoreImage = new ImageType(2, "Restore Image", true);
        public static ImageType CTOSoftware = new ImageType(3, "CTOSoftware", false);
        public static ImageType FactoryPatch = new ImageType(4, "Factory Patch", false);
        public static ImageType FusionImage = new ImageType(5, "Fusion Image", false);

        private ImageType(int id, string name, bool isActive)
        {
            Id = id;
            Name = name;
            IsActive = isActive;
        }

        public int Id { get; }

        public string Name { get; }

        public bool IsActive { get; }

        public static object Convert(object input)
        {
            if (input != null
                && int.TryParse(input.ToString(), out int value)
                && TryParse(value, out object result))
            {
                return result;
            }

            return None;
        }

        public static bool TryParse(int id, out object result)
        {
            if (id == 1)
            {
                result = FactoryImage;
                return true;
            }
            else if (id == 2)
            {
                result = RestoreImage;
                return true;
            }
            else if (id == 3)
            {
                result = CTOSoftware;
                return true;
            }
            else if (id == 4)
            {
                result = FactoryPatch;
                return true;
            }
            else if (id == 5)
            {
                result = FusionImage;
                return true;
            }

            result = None;
            return false;
        }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using Microsoft.Extensions.Caching.Memory;

namespace HP.Pulsar.Infrastructure.Application
{
    // This class lives in DI. Singleton type.
    // This simple data cache is designed for storing data for 30 minutes in server memory under sliding fashion.
    public class SimpleDataCache : ISimpleDataCache
    {
        private readonly MemoryCache _cache;
        private readonly int _itemExpirationDuration = 30;
        private readonly int _cacheSizeLimit = 128;

        public SimpleDataCache()
        {
            MemoryCacheOptions options = new MemoryCacheOptions
            {
                // set scan expiration identical to item expired duration
                ExpirationScanFrequency = TimeSpan.FromMinutes(_itemExpirationDuration),
                SizeLimit = _cacheSizeLimit
            };

            _cache = new MemoryCache(options);
        }

        public void Set(string key, object value, int minutesToBeExpired = 30)
        {
            if (string.IsNullOrWhiteSpace(key) || value == null)
            {
                return;
            }

            MemoryCacheEntryOptions options = new MemoryCacheEntryOptions();
            options.SetSlidingExpiration(TimeSpan.FromMinutes(minutesToBeExpired));
            options.SetSize(1);

            _cache.Set(key, value, options);
        }

        public bool TryGet(string key, out object value)
        {
            value = null;

            if (string.IsNullOrWhiteSpace(key))
            {
                return false;
            }

            if (_cache.TryGetValue(key, out object result))
            {
                value = result;
                return true;
            }

            return false;
        }

        public bool TryGet<T>(string key, out T value)
            where T : class
        {
            if (TryGet(key, out object cacheObject)
                && cacheObject != null
                && cacheObject is T result)
            {
                value = result;
                return true;
            }

            value = null;
            return false;
        }
    }
}

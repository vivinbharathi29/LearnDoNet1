﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;

namespace HP.Pulsar.Infrastructure.Application.Wizard
{
    public class WizardService : IWizardService
    {
        private readonly IEnumerable<IWizardStateMachine> _wizardStateMachine;

        public WizardService(IServiceProvider serviceProvider)
        {
            _wizardStateMachine = serviceProvider.GetServices<IWizardStateMachine>();
        }

        public IWizardStateMachine GetWizardStateMachine(int machineId)
        {
            return _wizardStateMachine?.FirstOrDefault(x => x.Id == machineId);
        }
    }
}
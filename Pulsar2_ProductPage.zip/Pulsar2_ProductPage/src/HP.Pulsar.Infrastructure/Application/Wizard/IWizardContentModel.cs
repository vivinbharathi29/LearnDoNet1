﻿namespace HP.Pulsar.Infrastructure.Application.Wizard
{
    public interface IWizardContentModel
    {
        bool CanGoToNext { get; }

        bool CanGoToPrevious { get; }

        string WizardControllerUrl { get; }

        int WizardId { get; }

        string WizardDisplayName { get; }
    }
}
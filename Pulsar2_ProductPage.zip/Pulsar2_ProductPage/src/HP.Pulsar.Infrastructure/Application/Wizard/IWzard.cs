﻿using System.Collections.Generic;

namespace HP.Pulsar.Infrastructure.Application.Wizard
{
    public interface IWizard
    {
        int Id { get; }

        IWizardContentModel GetContentModel(IReadOnlyDictionary<string, string> InputData);
    }
}
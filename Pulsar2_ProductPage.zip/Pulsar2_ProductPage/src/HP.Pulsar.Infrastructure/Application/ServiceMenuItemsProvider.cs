﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.Infrastructure.Abstractions.Application;
using HP.Pulsar.Infrastructure.CommonModels.Application;

namespace HP.Pulsar.Infrastructure.Application
{
    // This class lives in DI and it's singleton type.
    public class ServiceMenuItemsProvider : IMenuProvider
    {
        private readonly IAppMenuRepository _menuRepository;
        private IReadOnlyList<GeneralMenuItem> _serviceMenuItems;
        private DateTime _repositoryNextAccessTime;

        public ServiceMenuItemsProvider(IAppMenuRepository menuRepository)
        {
            _menuRepository = menuRepository;
            _repositoryNextAccessTime = DateTime.Now;
        }

        public MenuProviderType ProviderType => MenuProviderType.Service;

        public async Task<IReadOnlyList<GeneralMenuItem>> GetMenuItemsAsync()
        {
            // Let's have a chance to visit repository every 30 minutes
            if (_serviceMenuItems == null || _repositoryNextAccessTime < DateTime.Now)
            {
                _serviceMenuItems = await _menuRepository.GetServiceMenuItemsAsync().ConfigureAwait(false);
                _repositoryNextAccessTime = DateTime.Now.AddMinutes(30);

#if DEBUG
                // refresh every 1 minutes in debug build
                _repositoryNextAccessTime = DateTime.Now.AddMinutes(1);
#endif
            }

            return _serviceMenuItems;
        }
    }
}

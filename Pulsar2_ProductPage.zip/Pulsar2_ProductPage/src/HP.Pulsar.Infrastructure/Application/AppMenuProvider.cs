﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Infrastructure.Configuration;
using HP.Pulsar.CommonContracts.TodayPage.Tiles;
using HP.Pulsar.Infrastructure.Abstractions.Application;
using HP.Pulsar.Infrastructure.Abstractions.Tiles;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.CommonModels.Application;
using Microsoft.Extensions.DependencyInjection;

namespace HP.Pulsar.Infrastructure.Application
{
    // This class lives in DI and it is scope type.
    public class AppMenuProvider : IAppMenuProvider
    {
        private readonly ITileService _tileService;
        private readonly IEnumerable<IMenuProvider> _menuProviders;
        private readonly IAppConfiguration _appConfig;

        public AppMenuProvider(ITileService tileService, IServiceProvider serviceProvider, IAppConfiguration appConfig)
        {
            _tileService = tileService;
            _menuProviders = serviceProvider.GetServices<IMenuProvider>();
            _appConfig = appConfig;
        }

        public async Task<IReadOnlyList<GeneralMenuItem>> GetServiceMenuItemsAsync()
        {
            IMenuProvider menuProvider = _menuProviders.FirstOrDefault(x => x.ProviderType == MenuProviderType.Service);

            if (menuProvider == null)
            {
                return new List<GeneralMenuItem>();
            }

            IReadOnlyList<GeneralMenuItem> menuItems = await menuProvider.GetMenuItemsAsync().ConfigureAwait(false);

            return RunExceptionRules(menuItems);
        }

        private IReadOnlyList<GeneralMenuItem> RunExceptionRules(IReadOnlyList<GeneralMenuItem> items)
        {
            // @Test Environment    => IRS service return empty url
            // @Sandbox Environment => IRS service return IRS-Sandbox Url
            if (IsCurrentEnvironmentMatched("test"))
            {
                foreach (GeneralMenuItem irsMenuItem in GetIRSMenuItems(items))
                {
                    irsMenuItem.Link = "";
                    irsMenuItem.DisplayMode = MenuItemDisplayMode.None;
                }
            }
            else if (IsCurrentEnvironmentMatched("sandbox"))
            {
                foreach (GeneralMenuItem irsMenuItem in GetIRSMenuItems(items))
                {
                    irsMenuItem.Link = irsMenuItem.Link.Replace(_appConfig.IrsUrlFromDatabase, _appConfig.IrsUrl);
                }
            }

            return items;
        }

        public IReadOnlyList<TileMenuItem> GetTileMenuItems(IPulsarUser user)
        {
            if (user == null)
            {
                return new List<TileMenuItem>();
            }

            IEnumerable<ITile> userTiles = user.IsPulsarAdmin ? _tileService.GetTiles() : _tileService.GetTiles(user);

            return ConvertFromTileToMenuItem(userTiles);
        }

        private IReadOnlyList<TileMenuItem> ConvertFromTileToMenuItem(IEnumerable<ITile> tiles)
        {
            List<TileMenuItem> menuItems = new List<TileMenuItem>();
            int count = 0;

            foreach (ITile tile in tiles)
            {
                TileMenuItem item = new TileMenuItem
                {
                    DisplayName = tile.Name,
                    GroupName = tile.TileGroup.ToString(),
                    Sequence = count++,
                    TileId = tile.Id
                };

                menuItems.Add(item);
            }

            return menuItems;
        }

        private bool IsCurrentEnvironmentMatched(string environmentName)
        {
            return _appConfig.Environment.IndexOf(environmentName, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private IEnumerable<GeneralMenuItem> GetIRSMenuItems(IReadOnlyList<GeneralMenuItem> items)
        {
            return items.Where(x => x.Link?.IndexOf(_appConfig.IrsUrlFromDatabase, StringComparison.OrdinalIgnoreCase) >= 0);
        }
    }
}

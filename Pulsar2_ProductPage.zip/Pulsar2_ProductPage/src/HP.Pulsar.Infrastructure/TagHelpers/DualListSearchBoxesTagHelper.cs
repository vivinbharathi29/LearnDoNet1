﻿using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace HP.Pulsar.Infrastructure.TagHelpers
{
    //Copied from pulsarPlus
    [HtmlTargetElement("dual-list")]
    public class DualListSearchBoxesTagHelper : TagHelper
    {
        [HtmlAttributeName("Control-Id")]
        public string ControlId { get; set; }

        [HtmlAttributeName("Available-Title")]
        public string AvailableTitle { get; set; }

        [HtmlAttributeName("Assigned-Title")]
        public string AssignedTitle { get; set; }

        [HtmlAttributeName("CustomFunctionForAdd")]
        public string CustomFunctionForAdd { get; set; }

        [HtmlAttributeName("CustomFunctionForRemove")]
        public string CustomFunctionForRemove { get; set; }

        [HtmlAttributeName("CustomFunctionForAllAdd")]
        public string CustomFunctionForAllAdd { get; set; }

        [HtmlAttributeName("CustomFunctionForAllRemove")]
        public string CustomFunctionForAllRemove { get; set; }

        [HtmlAttributeName("AvailableModelData")]
        public IReadOnlyDictionary<string, string> AvailableModels { get; set; }

        [HtmlAttributeName("AssignedModelData")]
        public IReadOnlyDictionary<string, string> AssignedModels { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            string availableId = ControlId + "Available";
            string assignedId = ControlId + "Assigned";
            string availableIdFilter = availableId + "Filter";
            string availableIdContainer = availableId + "Container";
            string assignedIdFilter = assignedId + "Filter";
            string assignedIdContainer = assignedId + "Container";
            StringBuilder availbleBuilder = new StringBuilder();
            StringBuilder assignedBuilder = new StringBuilder();
            output.TagName = string.Empty;

            if (AvailableModels != null)
            {
                foreach (KeyValuePair<string, string> available in AvailableModels)
                {
                    availbleBuilder.Append($"<option value={available.Key}>{available.Value}</option>");
                }
            }

            if (AssignedModels != null)
            {
                foreach (KeyValuePair<string, string> assigned in AssignedModels)
                {
                    assignedBuilder.Append($"<option value={assigned.Key}>{assigned.Value}</option>");
                }
            }

            output.Content.AppendHtml("<div class='coll3 action-box'>");
            output.Content.AppendHtml(" <div class='show'>");
            output.Content.AppendHtml("     <div class='col-width-45'>");
            output.Content.AppendHtml("         <div class='col-sm-12'>");
            output.Content.AppendHtml("             <label class='action-fonts' for='Available-Columns'>" + AvailableTitle + ":</label>");
            output.Content.AppendHtml("                 <input name='" + availableIdFilter + "' id='" + availableIdFilter + "' type='text' class='form-control action-form-control' onkeyup=leftFilterKeUp('" + availableId + "')>");
            output.Content.AppendHtml("         </div>");
            output.Content.AppendHtml("         <div class='col-sm-12'>");
            output.Content.AppendHtml("             <select name='" + availableId + "' class='action-txt-area wid100' id='" + availableId + "' multiple='multiple'> ");
            output.Content.AppendHtml(availbleBuilder.ToString());
            output.Content.AppendHtml("             </select>");
            output.Content.AppendHtml("             <select name='" + availableIdContainer + "' id='" + availableIdContainer + "' style='display: none'></select>");
            output.Content.AppendHtml("         </div>");
            output.Content.AppendHtml("     </div>");

            output.Content.AppendHtml("     <div class='col-width-10 but-top-height'>");
            output.Content.AppendHtml("         <button name='cmdAdd' class='action-ui-button btn-action' id='cmdAdd' onclick=\"return cmdAddAvailable('" + availableId + "', '" + assignedId + "')\" type='button'> &gt; </button>");
            output.Content.AppendHtml("         <button name='cmdRemove' class='action-ui-button btn-action' id='cmdRemove' onclick=\"return cmdRemoveAvailable('" + availableId + "', '" + assignedId + "')\" type='button'> &lt; </button>");
            output.Content.AppendHtml("         <br>");
            output.Content.AppendHtml("         <button name='cmdAddAll' class='action-ui-button btn-action' id='cmdAddAll' onclick=\"return cmdAddAllAvailable('" + availableId + "', '" + assignedId + "')\" type='button'>&gt;&gt;</button>");
            output.Content.AppendHtml("         <button name='cmdRemoveAll' class='action-ui-button btn-action' id='cmdRemoveAll' onclick=\"return cmdRemoveAllAvailable('" + availableId + "', '" + assignedId + "')\" type='button'>&lt;&lt;</button>");
            output.Content.AppendHtml("     </div>");

            output.Content.AppendHtml("     <div class='col-width-45'>");
            output.Content.AppendHtml("         <div class='col-sm-12'><label class='action-fonts' for='Assigned-Columns'>" + AssignedTitle + ":</label>");
            output.Content.AppendHtml("             <input name='" + assignedIdFilter + "' id='" + assignedIdFilter + "' type='text' class='form-control action-form-control' onkeyup=leftFilterKeUp('" + assignedId + "')>");
            output.Content.AppendHtml("         </div>");
            output.Content.AppendHtml("         <div class='col-sm-12'>");
            output.Content.AppendHtml("             <select name='" + assignedId + "' class='action-txt-area wid100' id='" + assignedId + "' multiple='multiple'>");
            output.Content.AppendHtml(assignedBuilder.ToString());
            output.Content.AppendHtml("             </select>");
            output.Content.AppendHtml("             <select name='" + assignedIdContainer + "' id='" + assignedIdContainer + "' style='display: none'></select>");
            output.Content.AppendHtml("         </div>");
            output.Content.AppendHtml("     </div>");
            output.Content.AppendHtml(" </div>");
            output.Content.AppendHtml("</div>");
        }
    }
}

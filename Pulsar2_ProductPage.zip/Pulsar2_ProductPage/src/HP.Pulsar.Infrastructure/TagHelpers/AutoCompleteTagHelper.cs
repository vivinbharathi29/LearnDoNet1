﻿using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace HP.Pulsar.Infrastructure.TagHelpers
{
    [HtmlTargetElement("auto-complete")]
    public class AutoCompleteTagHelper : TagHelper
    {
        private const string IdAttributeName = "id";
        private const string DefaultBinding = "default";
        private const string SourceAttributeName = "items-source";
        private const string SourceUrlAttributeName = "items-source-url";
        private const string SelectCustomFunction = "select-function";
        private const string MinimumLengthAttributeName = "min-length";
        private readonly IAppUrlProvider _appUrlProvider;

        [HtmlAttributeName(IdAttributeName)]
        public string Id { get; set; }

        [HtmlAttributeName(DefaultBinding)]
        public bool IsAllUsers { get; set; }

        // The items-source is provided only for backward compatibility. It should be avoided as it would render the dictionary rows as the javascript array
        [HtmlAttributeName(SourceAttributeName)]
        public IReadOnlyDictionary<int, string> ItemsSource { get; set; } = null;

        [HtmlAttributeName(SourceUrlAttributeName)]
        public string ItemSourceUrl { get; set; }

        [HtmlAttributeName(MinimumLengthAttributeName)]
        public int MinimumLength { get; set; } = 0;

        [HtmlAttributeName(SelectCustomFunction)]
        public string CustomFunction { get; set; } = null;

        public AutoCompleteTagHelper(IAppUrlProvider appUrlProvider)
        {
            _appUrlProvider = appUrlProvider;
        }

        public override Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "script";
            StringBuilder autoComplete = new StringBuilder();
            autoComplete.AppendLine("")
                        .AppendLine("$(function() { ")
                        .Append("$('#")
                        .Append(Id)
                        .Append("').autocomplete({")
                        .AppendLine("");

            // If default attribute is true, Get Active Users through a Web Api
            if (IsAllUsers)
            {
                GetAutoCompleteSourceUrl(autoComplete, _appUrlProvider.ActiveUsersWebApiUrl);
            }
            else if (!string.IsNullOrWhiteSpace(ItemSourceUrl))
            {
                // If default attribue is false and items-source-url attribute is set with a url, Get the users through that web api url
                GetAutoCompleteSourceUrl(autoComplete, ItemSourceUrl);
            }
            else if (ItemsSource?.Count > 0)
            {
                // If default attribute is false and items-source attribute is set with a IReadOnlyDictionary, render dictionary rows as the javascript array
                // The items-source is provided only for backward compatibility. It should be avoided as it would render the dictionary rows as the javascript array
                GetAutoCompleteSource(autoComplete, ItemsSource);
            }

            if (CustomFunction?.Length > 0)
            {
                autoComplete.Append(", select: function (event, ui) {")
                            .Append(CustomFunction)
                            .Append("(ui.item.id,ui.item.label);}");
            }

            autoComplete.AppendFormat(", minLength: {0}", MinimumLength)
                        .AppendLine("});")
                        .AppendLine("});");
            output.Content.AppendHtml(autoComplete.ToString());

            return Task.CompletedTask;
        }

        private static void GetAutoCompleteSourceUrl(StringBuilder autoComplete, string webApiUrl)
        {
            autoComplete.Append("source: function(request, response) {");
            autoComplete.Append("var searchText = request.term;");
            autoComplete.Append($"$.getJSON('{webApiUrl}/' + searchText");
            autoComplete.Append(",{}, function(data) {");
            autoComplete.Append("response(data);");
            autoComplete.Append("});");
            autoComplete.Append("}");
        }

        private static void GetAutoCompleteSource(StringBuilder autoComplete, IReadOnlyDictionary<int, string> activeUsers)
        {
            autoComplete.AppendLine("source: ")
                        .Append("[");

            List<string> users = new List<string>();

            foreach (KeyValuePair<int, string> user in activeUsers)
            {
                users.Add($"{{'id':'{user.Key}','label':'{user.Value.Replace('\'', ' ')}'}}");
            }

            autoComplete.Append(string.Join(",", users))
                        .Append("]");
        }
    }
}
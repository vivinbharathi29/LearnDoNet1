﻿namespace HP.Pulsar.Infrastructure.Email
{
    public static class LegacyEmailTemplateIds
    {
        public static readonly int ActionItemProperties = 216;

        public static readonly int CommercialHardwarePMAssignment = 200;

        public static readonly int GraphicsControllerPMAssignment = 202;

        public static readonly int PDMFeedbackAvailable = 6;

        public static readonly int ProcessorPMAssignment = 201;

        public static readonly int UpdateTicket = 208;

        public static readonly int VideoMemoryPMAssignment = 203;
    }
}

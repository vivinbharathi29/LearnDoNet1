﻿using System;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Configuration;
using HP.Pulsar.CommonContracts.Infrastructure.Email;
using HP.Pulsar.CommonContracts.Repository;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure
{
    // This class live in DI (transient type)
    public class EmailManager : IEmailManager
    {
        private readonly IAppConfiguration _appConfiguration;
        private readonly IUtilityRepository _repository;
        private readonly ILogger _logger;

        public EmailManager(IUtilityRepository repository,
                            IAppConfiguration appConfiguration,
                            ILogger<EmailManager> logger)
        {
            _appConfiguration = appConfiguration;
            _repository = repository;
            _logger = logger;
        }

        public async Task SendAsync(EmailMessage emailMessage)
        {
            if (emailMessage == null)
            {
                return;
            }

            // TODO Peter mark this for testing the email temporaily
            //if (_appConfiguration.Environment.IndexOf("production", StringComparison.OrdinalIgnoreCase) == -1)
            //{
            //    _logger.LogInformation($"Email Message : {JsonConvert.SerializeObject(emailMessage)}");
            //    return;
            //}

            await _repository.WriteToEmailQueueAsync(emailMessage).ConfigureAwait(false);
        }

        public async Task<(string subject, string body)> GetEmailTemplateAsync(int templateId)
        {
            return await _repository.GetEmailTemplateAsync(templateId).ConfigureAwait(false);
        }
    }
}
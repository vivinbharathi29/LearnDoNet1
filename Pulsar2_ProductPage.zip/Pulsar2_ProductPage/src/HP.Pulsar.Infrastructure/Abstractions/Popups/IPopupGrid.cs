﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.Infrastructure.Abstractions.Application.Grid;

namespace HP.Pulsar.Infrastructure.Abstractions.Popups
{
    // For Popups With Generic Grid
    public interface IPopupGrid : IPopup
    {
        string GridDataUrlRelativePath { get; set; }

        string GetColumnsDataJsonString();

        string GetColumnsToDisableGridCellClickingJsonString();

        string GetColumnTemplatesJsonString();

        string GetContextMenuItemsJsonString();

        string GetFeaturesDataJsonString();

        Task<(IReadOnlyList<IGridGeneralOutput> DataList, int DataCount)> GetGridDataAsync(IGridGeneralInput inputModel);
    }
}

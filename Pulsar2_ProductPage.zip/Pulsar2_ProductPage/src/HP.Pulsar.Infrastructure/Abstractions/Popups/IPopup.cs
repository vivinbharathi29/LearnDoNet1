﻿using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.TodayPage.Popup;
using HP.Pulsar.Infrastructure.Abstractions.Application.Grid;
using Newtonsoft.Json.Serialization;

namespace HP.Pulsar.Infrastructure.Abstractions.Popups
{
    // For Popups No Grid
    public interface IPopup
    {
        int PopupId { get; }

        Task<IPopupRootContentModel> GetContentModel(IGridGeneralInputRoot inputModel);

        IContractResolver GetJsonContractResolver();

        Task<bool> PostData(IGridGeneralInputRoot inputModel);
    }
}

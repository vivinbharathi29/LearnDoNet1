﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Infrastructure.Abstractions.Tiles;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles
{
    public interface ITileService
    {
        /// <summary>
        /// Gets tile by tile Id
        /// </summary>
        /// <param name="tileId"></param>
        /// <returns></returns>
        ITile GetTile(int tileId);

        /// <summary>
        /// Gets all tiles
        /// </summary>
        /// <returns></returns>
        IEnumerable<ITile> GetTiles();

        /// <summary>
        /// Gets tiles that are registered by the given user
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        Task<IReadOnlyList<ITile>> GetRegisteredTilesAsync(IPulsarUser user);

        /// <summary>
        /// Gets tiles available to the given user
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        IEnumerable<ITile> GetTiles(IPulsarUser user);
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.TodayPage.Tiles;
using HP.Pulsar.Infrastructure.Abstractions.Application.Grid;
using Newtonsoft.Json.Serialization;

namespace HP.Pulsar.Infrastructure.Abstractions.Tiles
{
    public interface ITile
    {
        string ContentCountUrlPath { get; }

        string ContentUrlPath { get; }

        string ExcelExportUrlPath { get; }

        int Id { get; }

        string Name { get; }

        string ShowContentUrlPath { get; }

        TileArea TileArea { get; }

        TileGroup TileGroup { get; }

        string GetColumnsDataJsonString();

        string GetColumnsToDisableGridCellClickingJsonString();

        string GetColumnTemplatesJsonString();

        string GetContextMenuItemsJsonString();

        Task<int> GetCountAsync(IGridGeneralInputRoot inputModel);

        string GetFeaturesDataJsonString();

        IContractResolver GetJsonContractResolver();

        // TODO - this function should become async function
        ITileContentModel GetTileContentModel(IGridGeneralInput inputModel);

        Task<(IReadOnlyList<IGridGeneralOutput> DataList, int DataCount)> GetTileDataAsync(IGridGeneralInput inputModel);

        Task<bool> PostData(IGridGeneralInputRoot inputModel);
    }
}

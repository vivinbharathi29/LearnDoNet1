﻿namespace HP.Pulsar.Infrastructure.Abstractions.UserInfo
{
    public interface IUserMemoryCache
    {
        bool TryGetUser(string userAliasOrEmail, out IPulsarUser pulsarUser);

        void SetUser(IPulsarUser pulsarUser, string email = "");
    }
}

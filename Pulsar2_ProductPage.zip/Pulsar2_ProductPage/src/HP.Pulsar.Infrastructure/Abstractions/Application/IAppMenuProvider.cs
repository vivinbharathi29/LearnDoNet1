﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.CommonModels.Application;

namespace HP.Pulsar.Infrastructure.Abstractions.Application
{
    public interface IAppMenuProvider
    {
        /// <summary>
        /// Gets all items in All Service menu
        /// </summary>
        Task<IReadOnlyList<GeneralMenuItem>> GetServiceMenuItemsAsync();

        /// <summary>
        /// Gets all items that are registered by the given user in All Tiles menu
        /// </summary>
        /// <param name="user"></param>
        IReadOnlyList<TileMenuItem> GetTileMenuItems(IPulsarUser user);
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Infrastructure.CommonModels.Application;

namespace HP.Pulsar.Infrastructure.Abstractions.Application
{
    public interface IAppMenuRepository
    {
        Task<IReadOnlyList<GeneralMenuItem>> GetServiceMenuItemsAsync();
    }
}
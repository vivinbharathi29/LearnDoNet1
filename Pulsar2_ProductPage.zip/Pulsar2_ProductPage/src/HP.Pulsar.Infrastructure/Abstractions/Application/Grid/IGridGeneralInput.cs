﻿using HP.Pulsar.CommonContracts.Infrastructure.Pagination;

namespace HP.Pulsar.Infrastructure.Abstractions.Application.Grid
{
    public interface IGridGeneralInput : IGridGeneralInputRoot
    {
        IPaginationModel Pagination { get; }
    }
}

﻿using System.Collections.Generic;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;

namespace HP.Pulsar.Infrastructure.Abstractions.Application.Grid
{
    public interface IGridGeneralInputRoot
    {
        IPulsarUser CurrentUser { get; }

        IReadOnlyDictionary<string, string> InputData { get; }

        bool IsImpersonated { get; }
    }
}

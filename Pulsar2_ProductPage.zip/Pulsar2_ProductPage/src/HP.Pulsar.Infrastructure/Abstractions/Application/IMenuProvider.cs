﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Infrastructure.CommonModels.Application;

namespace HP.Pulsar.CommonContracts.Infrastructure.Application
{
    public interface IMenuProvider
    {
        MenuProviderType ProviderType { get; }

        /// <summary>
        /// Gets all items in the menu
        /// </summary>
        Task<IReadOnlyList<GeneralMenuItem>> GetMenuItemsAsync();
    }
}

﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PulsarUnitTests")]

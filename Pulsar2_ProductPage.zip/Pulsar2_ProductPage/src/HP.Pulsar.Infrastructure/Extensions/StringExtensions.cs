﻿using System;
using System.Collections.Generic;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class StringExtensions
    {
        public static bool ContainsAll(this string input, string[] targets, bool canIgnoreCase = true)
        {
            if (input == null)
            {
                return false;
            }

            for (int i = 0; i < targets.Length; i++)
            {
                if (canIgnoreCase && input.IndexOf(targets[i], StringComparison.OrdinalIgnoreCase) == -1)
                {
                    return false;
                }

                if (!canIgnoreCase && input.IndexOf(targets[i]) == -1)
                {
                    return false;
                }
            }

            return true;
        }

        public static bool Contains(this IReadOnlyList<string> input, string target, bool canIgnoreCase = true)
        {
            if (input == null || input.Count == 0)
            {
                return false;
            }

            for (int i = 0; i < input.Count; i++)
            {
                if ((canIgnoreCase && string.Equals(input[i], target, StringComparison.OrdinalIgnoreCase))
                    || (!canIgnoreCase && string.Equals(input[i], target)))
                {
                    return true;
                }
            }

            return false;
        }

        public static int GetIntPrefix(this string input)
        {
            if (!string.IsNullOrWhiteSpace(input))
            {
                input = input.TrimStart();
                for (int size = input.Length; size > 0; size--)
                {
                    if (int.TryParse(input.Substring(0, size), out int result))
                    {
                        return result;
                    }
                }
            }

            return 0;
        }

        // Returns the given number of characters from the left
        public static string Left(this string input, int noOfChars)
        {
            if (string.IsNullOrEmpty(input) || noOfChars <= 0)
            {
                return string.Empty;
            }

            return input.Substring(0, Math.Min(noOfChars, input.Length));
        }

        public static string RemoveEmptyEntries(this string input, char separator)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return string.Empty;
            }

            string[] splits = input.Split(new char[] { separator }, StringSplitOptions.RemoveEmptyEntries);

            if (splits.Length == 1)
            {
                return input;
            }

            List<string> results = new List<string>(splits.Length);

            for(int index = 0; index < splits.Length; index++)
            {
                if (!string.IsNullOrWhiteSpace(splits[index]))
                {
                    results.Add(splits[index].Trim());
                }
            }

            return string.Join(separator.ToString(), results);
        }

        public static List<int> SplitToIntList(this string input, char separator)
        {
            List<int> values = new List<int>();

            if (!string.IsNullOrEmpty(input))
            {
                foreach (string stringValue in input.Split(new char[] { separator }, StringSplitOptions.RemoveEmptyEntries))
                {
                    if (int.TryParse(stringValue, out int intValue) && intValue > 0)
                    {
                        values.Add(intValue);
                    }
                }
            }

            return values;
        }
    }
}
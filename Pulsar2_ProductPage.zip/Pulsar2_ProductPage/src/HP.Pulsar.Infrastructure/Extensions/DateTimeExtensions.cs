﻿using System;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class DateTimeExtensions
    {
        public static DateTime GetFirstDateOfMonth(this DateTime date)
        {
            return new DateTime(date.Year, date.Month, 1);
        }

        public static DateTime GetLastDateOfMonth(this DateTime date)
        {
            return GetFirstDateOfMonth(date).AddMonths(1).AddDays(-1);
        }

        public static DateTime GetFirstDateOfCurrentYear(this DateTime date)
        {
            return new DateTime(date.Year, 1, 1);
        }

        public static DateTime GetLastDateOfCurrentYear(this DateTime date)
        {
            return new DateTime(date.Year, 12, 31);
        }

        public static DateTime GetFirstDateOfLastYear(this DateTime date)
        {
            if (date.Year <= 0)
            {
                new DateTime(date.Year, 1, 1);
            }

            return new DateTime(date.Year - 1, 1, 1);
        }

        public static DateTime GetLastDateOfLastYear(this DateTime date)
        {
            if (date.Year <= 0)
            {
                new DateTime(date.Year, 12, 31);
            }

            return new DateTime(date.Year - 1, 12, 31);
        }

        public static DateTime GetFirstDateOfNextYear(this DateTime date)
        {
            if (date.Year == int.MaxValue)
            {
                return new DateTime(date.Year, 1, 1);
            }

            return new DateTime(date.Year + 1, 1, 1);
        }

        public static DateTime GetLastDateOfNextYear(this DateTime date)
        {
            if (date.Year == int.MaxValue)
            {
                return new DateTime(date.Year, 12, 31);
            }

            return new DateTime(date.Year + 1, 12, 31);
        }
    }
}

﻿using System;
using System.Threading.Tasks;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.CommonModels.UserInfo;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class UserExtensions
    {
        public static async Task<IPulsarUser> GetSystemLevelImpersonatedUserAsync(this IPulsarUser user)
        {
            if (user == null)
            {
                return null;
            }

            (ImpersonationArea Area, IPulsarUser ImpersonatedUser) = await user.GetImpersonatedUserAsync().ConfigureAwait(false);

            return Area == ImpersonationArea.SystemLevel && ImpersonatedUser != null ? ImpersonatedUser : null;
        }

        /// <summary>
        /// Convert to Firstname Lastname format
        /// </summary>
        /// <param name="lastNameFirstName"></param>
        /// <returns></returns>
        public static string ToFirstNameLastName(this string lastNameFirstName)
        {
            if (string.IsNullOrWhiteSpace(lastNameFirstName))
            {
                return lastNameFirstName;
            }

            string[] names = lastNameFirstName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            if (names.Length != 2)
            {
                return lastNameFirstName.Trim();
            }

            names[0] = names[0].Trim();
            names[1] = names[1].Trim();
            int leftParenthesesIndex = names[1].IndexOf("(");
            int rightParenthesesIndex = names[1].IndexOf(")");

            if (leftParenthesesIndex >= 0 && rightParenthesesIndex >= 0 && leftParenthesesIndex < rightParenthesesIndex)
            {
                names[0] = $"{names[0]} {names[1].Substring(leftParenthesesIndex, rightParenthesesIndex - leftParenthesesIndex + 1)}";
                names[1] = names[1].Substring(0, leftParenthesesIndex).TrimEnd();
            }

            return $"{names[1]} {names[0]}";
        }
    }
}

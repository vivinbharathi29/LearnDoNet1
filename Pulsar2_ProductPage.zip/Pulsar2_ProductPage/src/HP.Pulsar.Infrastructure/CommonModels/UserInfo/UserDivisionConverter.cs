﻿namespace HP.Pulsar.Infrastructure.CommonModels.UserInfo
{
    public static class UserDivisionConverter
    {
        // This information comes from Division table of PRS database
        public static object ConvertUserDivision(object input)
        {
            if (input != null && int.TryParse(input.ToString(), out int value))
            {
                if (value == 1)
                {
                    return UserDivision.Notebooks;
                }

                if (value == 2)
                {
                    return UserDivision.Desktops;
                }

                if (value == 3)
                {
                    return UserDivision.Other;
                }
            }

            return UserDivision.None;
        }
    }
}

﻿namespace HP.Pulsar.Infrastructure.CommonModels.UserInfo
{
    public enum UserDivision
    {
        None = 0,
        Notebooks,
        Desktops,
        Other,
    }
}

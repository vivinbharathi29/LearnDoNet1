﻿using System;

namespace HP.Pulsar.Infrastructure.CommonModels.UserInfo
{
#pragma warning disable CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
#pragma warning disable CS0661 // Type defines operator == or operator != but does not override Object.GetHashCode()
    public sealed class ImpersonationArea
#pragma warning restore CS0661 // Type defines operator == or operator != but does not override Object.GetHashCode()
#pragma warning restore CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    {
        private ImpersonationArea(int id)
        {
            Id = id;
        }

        public string Name
        {
            get
            {
                if (Id == None.Id)
                {
                    return nameof(None);
                }

                if (Id == SystemLevel.Id)
                {
                    return nameof(SystemLevel);
                }

                if (Id == ProgramCoordinator.Id)
                {
                    return nameof(ProgramCoordinator);
                }

                if (Id == ConfigurationManager.Id)
                {
                    return nameof(ConfigurationManager);
                }

                if (Id == PhWeb.Id)
                {
                    return nameof(PhWeb);
                }

                if (Id == Marketing.Id)
                {
                    return nameof(Marketing);
                }

                if (Id == PM.Id)
                {
                    return nameof(PM);
                }

                return string.Empty;
            }
        }

        public int Id { get; }

        public override bool Equals(object obj)
        {
            if (obj is null || !(obj is ImpersonationArea area))
            {
                return false;
            }

            return Id == area.Id;
        }

        public static bool operator ==(ImpersonationArea a, ImpersonationArea b)
        {
            if (a is null || b is null)
            {
                return false;
            }

            return a.Id == b.Id;
        }

        public static bool operator !=(ImpersonationArea a, ImpersonationArea b)
        {
            return !(a == b);
        }

        public static bool TryParse(int id, out ImpersonationArea area)
        {
            if (id == None.Id)
            {
                area = None;
                return true;
            }

            if (id == SystemLevel.Id)
            {
                area = SystemLevel;
                return true;
            }

            if (id == ProgramCoordinator.Id)
            {
                area = ProgramCoordinator;
                return true;
            }

            if (id == ConfigurationManager.Id)
            {
                area = ConfigurationManager;
                return true;
            }

            if (id == PhWeb.Id)
            {
                area = PhWeb;
                return true;
            }

            if (id == Marketing.Id)
            {
                area = Marketing;
                return true;
            }

            if (id == PM.Id)
            {
                area = PM;
                return true;
            }

            area = null;
            return false;
        }

        public static bool TryParse(string value, out ImpersonationArea area)
        {
            if (string.Equals(value, nameof(None), StringComparison.OrdinalIgnoreCase))
            {
                area = None;
                return true;
            }

            if (string.Equals(value, nameof(SystemLevel), StringComparison.OrdinalIgnoreCase))
            {
                area = SystemLevel;
                return true;
            }

            if (string.Equals(value, nameof(ProgramCoordinator), StringComparison.OrdinalIgnoreCase))
            {
                area = ProgramCoordinator;
                return true;
            }

            if (string.Equals(value, nameof(ConfigurationManager), StringComparison.OrdinalIgnoreCase))
            {
                area = ConfigurationManager;
                return true;
            }

            if (string.Equals(value, nameof(PhWeb), StringComparison.OrdinalIgnoreCase))
            {
                area = PhWeb;
                return true;
            }

            if (string.Equals(value, nameof(Marketing), StringComparison.OrdinalIgnoreCase))
            {
                area = Marketing;
                return true;
            }

            if (string.Equals(value, nameof(PM), StringComparison.OrdinalIgnoreCase))
            {
                area = PM;
                return true;
            }

            area = null;
            return false;
        }

        public static ImpersonationArea ConfigurationManager => new ImpersonationArea(3);

        public static ImpersonationArea Marketing => new ImpersonationArea(5);

        public static ImpersonationArea None => new ImpersonationArea(0);

        public static ImpersonationArea PhWeb => new ImpersonationArea(4);

        public static ImpersonationArea PM => new ImpersonationArea(6);

        public static ImpersonationArea ProgramCoordinator => new ImpersonationArea(2);

        public static ImpersonationArea SystemLevel => new ImpersonationArea(1);
    }
}

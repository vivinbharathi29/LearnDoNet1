﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace HP.Pulsar.Infrastructure.CommonModels.QuickSearch
{
    // TFS55269 move to infra prj
#pragma warning disable CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    public class QuickSearchItem
#pragma warning restore CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    {
        public long Id { get; set; }

        public string Name { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public QuickSearchType TargetType { get; set; }
        
        [JsonConverter(typeof(MenuItemDisplayModeConverter))]
        public MenuItemDisplayMode DisplayMode { get; set; }

        public string Url { get; set; }

        public override bool Equals(object obj)
        {
            return obj is QuickSearchItem target
                   && Id == target.Id
                   && string.Equals(Name, target.Name, StringComparison.OrdinalIgnoreCase)
                   && target.TargetType.Equals(TargetType);
        }
    }
}

﻿namespace HP.Pulsar.Infrastructure.CommonModels.Application
{
    public class TileMenuItem
    {
        public string DisplayName { get; set; }

        // My Items, Products, Admin, and so on.
        public string GroupName { get; set; }

        public int Sequence { get; set; }

        public int TileId { get; set; }
    }
}
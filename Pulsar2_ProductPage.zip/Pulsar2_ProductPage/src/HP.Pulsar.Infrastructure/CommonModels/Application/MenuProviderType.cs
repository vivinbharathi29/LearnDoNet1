﻿namespace HP.Pulsar.Infrastructure.CommonModels.Application
{
    public enum MenuProviderType
    {
        Service = 0,
        Report
    }
}

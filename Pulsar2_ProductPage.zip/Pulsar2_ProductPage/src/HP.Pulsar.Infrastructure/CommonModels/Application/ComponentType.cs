﻿using System;

namespace HP.Pulsar.Infrastructure.CommonModels.Application
{
#pragma warning disable CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
#pragma warning disable CS0661 // Type defines operator == or operator != but does not override Object.GetHashCode()
    public sealed class ComponentType : IEquatable<ComponentType>
#pragma warning restore CS0661 // Type defines operator == or operator != but does not override Object.GetHashCode()
#pragma warning restore CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    {
        public static readonly ComponentType None = new ComponentType(-1, "None");
        public static readonly ComponentType Hardware = new ComponentType(1, "Hardware");
        public static readonly ComponentType Software = new ComponentType(2, "Software");
        public static readonly ComponentType Firmware = new ComponentType(3, "Firmware");
        public static readonly ComponentType Documentation = new ComponentType(4, "Documentation");


        private ComponentType(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public int Id { get; }

        public string Name { get; }

        public static bool TryParse(int id, out ComponentType type)
        {
            if (id == -1)
            {
                type = None;
                return true;
            }

            if (id == 1)
            {
                type = Hardware;
                return true;
            }

            if (id == 2)
            {
                type = Software;
                return true;
            }

            if (id == 3)
            {
                type = Firmware;
                return true;
            }

            if (id == 4)
            {
                type = Documentation;
                return true;
            }

            type = null;
            return false;
        }

        public static object Convert(object input)
        {
            if (input != null
                && int.TryParse(input.ToString(), out int value)
                && TryParse(value, out ComponentType type))
            {
                return type;
            }

            return None;
        }

        public bool Equals(ComponentType type)
        {
            if (type is null)
            {
                return false;
            }

            return type.Id == Id;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is ComponentType other))
            {
                return false;
            }

            return Equals(other);
        }

        public static bool operator ==(ComponentType input1, ComponentType input2)
        {
            if (input1 is null || input2 is null)
            {
                return false;
            }

            return input1.Equals(input2);
        }

        public static bool operator !=(ComponentType input1, ComponentType input2)
        {
            return !(input1 == input2);
        }
    }
}

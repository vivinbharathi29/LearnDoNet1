﻿using HP.Pulsar.CommonContracts.Infrastructure.Application;

namespace HP.Pulsar.Infrastructure.CommonModels.Application
{
    public class GeneralMenuItem
    {
        public MenuItemDisplayMode DisplayMode { get; set; }

        public string DisplayName { get; set; }

        public int Id { get; set; }

        public bool IsActive { get; set; }

        public bool IsOnlyForHPEmployee { get; set; }

        public string Link { get; set; }

        public string Name { get; set; }

        public int? ParentId { get; set; }

        public int Sequence { get; set; }

        public bool IsNew { get; set; }
    }
}
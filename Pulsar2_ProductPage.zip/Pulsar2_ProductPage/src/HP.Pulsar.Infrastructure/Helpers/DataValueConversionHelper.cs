﻿using System;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.Infrastructure.Helpers
{
    public static class DataValueConversionHelper
    {
        public static object ConvertByteToBoolean(object value)
        {
            if (value != null
                && byte.TryParse(value.ToString(), out byte byteValue))
            {
                return byteValue > 0;
            }

            return false;
        }

        public static object ConvertToNullableInteger(object value)
        {
            if (value != null
                && int.TryParse(value.ToString(), out int intValue))
            {
                return intValue;
            }

            return null;
        }

        public static object ConvertIntegerToBoolean(object value)
        {
            if (value != null
                && int.TryParse(value.ToString(), out int intValue))
            {
                return intValue > 0;
            }

            return false;
        }

        public static object ConvertIntegerToEnum<TEnum>(object value)
            where TEnum : struct
        {
            if (value != null
                && int.TryParse(value.ToString(), out int intValue)
                && Enum.TryParse(intValue.ToString(), out TEnum enumValue)
                && Enum.IsDefined(typeof(TEnum), enumValue))
            {
                return enumValue;
            }

            return null;
        }

        public static object ConvertNullableBooleanToBoolean(object value)
        {
            if (value != null
                && bool.TryParse(value.ToString(), out bool boolValue))
            {
                return boolValue;
            }

            return false;
        }

        public static bool TryGetEnumValue<TEnum>(int intValue, out TEnum enumValue)
            where TEnum : struct
        {
            return Enum.TryParse(intValue.ToString(), out enumValue)
                   && Enum.IsDefined(typeof(TEnum), enumValue);
        }

        public static object ConvertToInteger(object value)
        {
            if (value != null
                && int.TryParse(value.ToString(), out int intValue))
            {
                return intValue;
            }

            return -1;
        }

        public static object ConvertToDateTime(object input)
        {
            if (input == null)
            {
                return null;
            }

            if (DateTime.TryParse(input.ToString(), out DateTime datetime))
            {
                return datetime;
            }

            return null;
        }

        public static object ConvertToBoolean(object input)
        {
            return input != null
                   && (string.Equals(input.ToString(), "True", StringComparison.OrdinalIgnoreCase)
                   || string.Equals(input.ToString(), "T", StringComparison.OrdinalIgnoreCase)
                   || string.Equals(input.ToString(), "Y", StringComparison.OrdinalIgnoreCase)
                   || string.Equals(input.ToString(), "1", StringComparison.OrdinalIgnoreCase));
        }

        public static object ConvertBooleanToInteger(object input)
        {
            if (bool.TryParse(input?.ToString(), out bool boolValue))
            {
                return boolValue ? 1 : 0;
            }

            return 0;
        }

        public static object TrimString(object input)
        {
            if (input != null)
            {
                return input.ToString().Trim();
            }

            return string.Empty;
        }

        public static object ConvertChangeRequestStatus(object input)
        {
            if (input != null && int.TryParse(input.ToString(), out int value))
            {
                if (value == 1)
                {
                    return ChangeRequestStatus.Open;
                }
                else if (value == 2)
                {
                    return ChangeRequestStatus.Closed;
                }
                else if (value == 3)
                {
                    return ChangeRequestStatus.NeedMoreInfo;
                }
                else if (value == 4)
                {
                    return ChangeRequestStatus.Approved;
                }
                else if (value == 5)
                {
                    return ChangeRequestStatus.Disapproved;
                }
                else if (value == 6)
                {
                    return ChangeRequestStatus.Investigating;
                }
                else if (value == 7)
                {
                    return ChangeRequestStatus.NotApplicable;
                }
            }

            return ChangeRequestStatus.NewRequest;
        }
    }
}

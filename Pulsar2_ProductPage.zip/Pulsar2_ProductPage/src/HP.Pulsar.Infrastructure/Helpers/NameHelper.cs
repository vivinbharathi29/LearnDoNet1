﻿using System;
using System.Text;

namespace HP.Pulsar.Infrastructure.Helpers
{
    public static class NameHelper
    {
        // Copy the logic from ExcaliburWeb/pmview.asp from line:61 to 91
        public static string FormatSystemId(string comments)
        {
            if (!comments.Contains("^") && !comments.Contains("|"))
            {
                return comments;
            }

            StringBuilder sb = new StringBuilder();

            foreach (string item in comments.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries))
            {
                if (!item.Contains("^"))
                {
                    sb.Append(", ").Append(item);
                    continue;
                }

                string[] splitItems = item.Split(new string[] { "^" }, StringSplitOptions.RemoveEmptyEntries);
                sb.Append(", ").Append(splitItems[0]);

                if (splitItems.Length > 1)
                {
                    sb.Append($" ({splitItems[1]})");
                }
            }

            string result = sb.ToString();
            return !string.IsNullOrEmpty(result) && result.Length > 2 ? result.Substring(2) : string.Empty;
        }

        public static string GetComponentVersionName(string componentName, string Revision, string Pass)
        {
            if (!string.IsNullOrWhiteSpace(Revision))
            {
                componentName += $", {Revision}";
            }

            if (!string.IsNullOrWhiteSpace(Pass))
            {
                componentName += $", {Pass}";
            }

            return componentName;
        }
    }
}

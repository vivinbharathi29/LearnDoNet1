﻿using System.IO;
using System.Xml.Serialization;

namespace HP.Pulsar.Infrastructure.Helpers
{
    public static class XmlHelper
    {
        public static string GetXml<T>(this T value, string prefix = "", string ns = "")
        {
            if (value == null)
            {
                return string.Empty;
            }

            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(prefix, ns);

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
            StringWriter stringWriter = new StringWriter();
            xmlSerializer.Serialize(stringWriter, value, namespaces);

            return stringWriter.ToString();
        }
    }
}

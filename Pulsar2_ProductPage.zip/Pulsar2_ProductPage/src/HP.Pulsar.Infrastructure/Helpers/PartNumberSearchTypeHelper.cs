﻿using HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber;
using HP.Pulsar.Infrastructure.PartNumber;

namespace HP.Pulsar.Infrastructure.Helpers
{
    public static class PartNumberSearchTypeHelper
    {
        public static IPartNumberType GetModelByType(PartNumberSearchType searchType)
        {
            if (searchType.Id == PartNumberSearchType.MaterialDescription.Id)
            {
                return new MaterialDescriptionModel();
            }
            if (searchType.Id == PartNumberSearchType.BOMStructure.Id)
            {
                return new BOMStructureModel();
            }
            if (searchType.Id == PartNumberSearchType.WhereUsedInformation.Id)
            {
                return new WhereUsedInformationModel();
            }
            if (searchType.Id == PartNumberSearchType.WhereUsedInSpareKits.Id)
            {
                return new WhereUsedInSpareKitsModel();
            }
            if (searchType.Id == PartNumberSearchType.ODMPartInformation.Id)
            {
                return new ODMPartInformationModel();
            }
            if (searchType.Id == PartNumberSearchType.Subassemblies.Id)
            {
                return new SubassembliesModel();
            }

            return new MaterialDescriptionModel();
        }

        public static string GetGridDataUrlByID(PartNumberSearchType searchType)
        {
            // TODO - those URL should get improved.
            if (searchType.Id == PartNumberSearchType.MaterialDescription.Id)
            {
                return "~/PartNumber/GetMaterialDescription";
            }
            if (searchType.Id == PartNumberSearchType.BOMStructure.Id)
            {
                return "~/PartNumber/GetBOMStructure";
            }
            if (searchType.Id == PartNumberSearchType.WhereUsedInformation.Id)
            {
                return "~/PartNumber/GetWhereUsedInformation";
            }
            if (searchType.Id == PartNumberSearchType.WhereUsedInSpareKits.Id)
            {
                return "~/PartNumber/GetWhereUsedInSpareKits";
            }
            if (searchType.Id == PartNumberSearchType.ODMPartInformation.Id)
            {
                return "~/PartNumber/GetODMPartInformation";
            }
            if (searchType.Id == PartNumberSearchType.Subassemblies.Id)
            {
                return "~/PartNumber/GetSubassemblies";
            }

            return "";
        }
    }
}

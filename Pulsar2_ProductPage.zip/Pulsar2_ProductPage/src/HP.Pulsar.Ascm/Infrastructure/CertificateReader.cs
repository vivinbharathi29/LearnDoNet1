﻿using System.Security.Cryptography.X509Certificates;

namespace HP.Pulsar.Ascm.Infrastructure
{
    internal class CertificateReader
    {
        public bool TryGetCertificate(string subjectKey, out X509Certificate2 cert)
        {
            if (!string.IsNullOrWhiteSpace(subjectKey))
            {
                using (X509Store store = new X509Store(StoreName.My, StoreLocation.LocalMachine))
                {
                    store.Open(OpenFlags.ReadOnly);
                    X509Certificate2Collection x509Certificate2Collection = store.Certificates.Find(X509FindType.FindBySubjectKeyIdentifier, subjectKey, false);

                    if (x509Certificate2Collection.Count == 0)
                    {
                        cert = null;
                        return false;
                    }

                    cert = x509Certificate2Collection[0];
                    return true;
                }
            }

            cert = null;
            return false;
        }
    }
}
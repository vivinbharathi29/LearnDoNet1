﻿using System;
using System.Collections.Generic;

namespace HP.Pulsar.Ascm.Infrastructure
{
    //TODO: Remove this class later, because Pulsar2 Infra will have UrlPathModel and we can reference it from there.
    public class UrlPathModel
    {
        public UrlPathModel(string controllerName, string actionName, IDictionary<string, string> queryStrings)
        {
            ControllerName = controllerName;
            ActionName = actionName;
            if (queryStrings != null)
            {
                QueryStrings = new Dictionary<string, string>(queryStrings, StringComparer.OrdinalIgnoreCase);
            }
        }

        public UrlPathModel(string controllerName, string actionName, IReadOnlyDictionary<string, string> queryStrings)
        {
            ControllerName = controllerName;
            ActionName = actionName;

            if (queryStrings != null)
            {
                QueryStrings = new Dictionary<string, string>(queryStrings, StringComparer.OrdinalIgnoreCase);
            }
        }

        public string ControllerName { get; }

        public string ActionName { get; }

        public IDictionary<string, string> QueryStrings { get; }

        public string UrlPath
        {
            get
            {
                if (QueryStrings == null || QueryStrings.Count == 0)
                {
                    return $"{ControllerName}/{ActionName}";
                }

                List<string> pairs = new List<string>();

                foreach (KeyValuePair<string, string> item in QueryStrings)
                {
                    pairs.Add($"{item.Key}={item.Value}");
                }

                string query = string.Join("&", pairs);

                return $"{ControllerName}/{ActionName}?{query}";
            }
        }
    }
}
﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;
using HP.Pulsar.Infrastructure.Constants;
using HP.Pulsar.Infrastructure.Extensions;
using HP.Pulsar.Infrastructure.Telemetry;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Reports
{
    internal class AscmReportApiRequester : IAscmReportApiRequester
    {
        private readonly IAppUrlProvider _appUrlProvider;
        private readonly IHttpClientFactory _clientFactory;
        private readonly ITelemetryFactory _telemetryFactory;
        public static string ClientName = "AscmReport";

        public AscmReportApiRequester(IAppUrlProvider appUrlProvider,
                                      IHttpClientFactory clientFactory,
                                      ITelemetryFactory telemetryFactory)
        {
            _appUrlProvider = appUrlProvider;
            _clientFactory = clientFactory;
            _telemetryFactory = telemetryFactory;
        }

        public Task<(HttpStatusCode HttpStatusCode, string Response)> GetLinkDataAsync(IReadOnlyList<LinkApiInputRequest> linkInputRequests)
        {
            if (linkInputRequests == null)
            {
                return Task.FromResult<(HttpStatusCode, string)>((HttpStatusCode.BadRequest, null));
            }

            LinkApiRequestDataModel linkInputRequest = new LinkApiRequestDataModel()
            {
                RequesterId = EmailConstants.PrismApiRequesterEmail,
                InputRequests = linkInputRequests
            };

            return CallApi(_appUrlProvider.PrismLinkApiUrl, linkInputRequest);
        }

        public Task<(HttpStatusCode HttpStatusCode, string Response)> GetChunkDataAsync(IReadOnlyList<ChunkApiInputRequest> chunkInputRequests)
        {
            if (chunkInputRequests == null)
            {
                return Task.FromResult<(HttpStatusCode, string)>((HttpStatusCode.BadRequest, null));
            }

            ChunkApiRequestDataModel chunkInputRequest = new ChunkApiRequestDataModel()
            {
                RequesterId = EmailConstants.PrismApiRequesterEmail,
                InputRequests = chunkInputRequests
            };

            return CallApi(_appUrlProvider.PrismChunkApiUrl, chunkInputRequest);
        }

        private async Task<(HttpStatusCode HttpStatusCode, string Response)> CallApi(string requestUrlPath, object parameter)
        {
            HttpClient httpClinet = _clientFactory.CreateClient(ClientName);
            string requestContent = JsonConvert.SerializeObject(parameter);

            _telemetryFactory.SendTelemetryEvent(TelemetryEventIdConstants.AscmReportPublishedTelemetryEventId, nameof(CallApi), note: $"API:{requestUrlPath} - request:{requestContent}");

            StringContent data = new StringContent(requestContent, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await httpClinet.PostAsync(requestUrlPath, data).ConfigureAwait(false);
            string responseContent = await response?.Content.ReadAsStringAsync();

            _telemetryFactory.SendTelemetryEvent(TelemetryEventIdConstants.AscmReportPublishedTelemetryEventId, nameof(CallApi), note: $"API:{requestUrlPath} - response:{responseContent}");

            return (response?.StatusCode ?? HttpStatusCode.BadRequest, responseContent);
        }
    }
}
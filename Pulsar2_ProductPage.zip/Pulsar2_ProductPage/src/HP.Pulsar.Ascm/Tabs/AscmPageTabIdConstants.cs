﻿namespace HP.Pulsar.Ascm.Tabs
{
    public static class AscmPageTabIdConstants
    {
        public static readonly int AllOptions = 1;
        
        public static readonly int Report = 2;
    }
}
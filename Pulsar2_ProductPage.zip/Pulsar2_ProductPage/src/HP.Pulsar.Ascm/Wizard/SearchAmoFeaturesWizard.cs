﻿using System.Collections.Generic;
using System.Linq;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.Infrastructure;
using HP.Pulsar.Infrastructure.Application.Wizard;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Wizard
{
    public class SearchAmoFeaturesWizard : IWizard
    {
        private readonly string _key;
        private readonly ISimpleDataCache _cache;

        public SearchAmoFeaturesWizard(string cacheKey, ISimpleDataCache cache)
        {
            _key = cacheKey;
            _cache = cache;
        }

        private string GetGridDataFromCache(AddHpPartNumberDataCacheModel dataFromCache)
        {

            int selectedFeatureCategoryId = dataFromCache.FeatureCategories.Where(item => item.IsSelected).Select(item => item.Id).FirstOrDefault();
            IReadOnlyList<int> selectedNamingStandardIds = dataFromCache.NamingStandards.Where(item => item.IsSelected).Select(item => item.Id).ToList();

            List<SearchAmoFeaturesGridDataModel> features = new List<SearchAmoFeaturesGridDataModel>();
            foreach (var newAmofeature in dataFromCache.AmoFeatures)
            {
                if (newAmofeature.FeatureCategoryId == selectedFeatureCategoryId
                    && (selectedNamingStandardIds == null || selectedNamingStandardIds.Count == 0 || selectedNamingStandardIds.Any(Id => Id == newAmofeature.NamingStandardId)))
                {
                    features.Add(new SearchAmoFeaturesGridDataModel
                    {
                        FeatureId = newAmofeature.FeatureId,
                        FeatureFullName = newAmofeature.FeatureFullName,
                        PMG100DTDescription = newAmofeature.Description,
                        FeatureCategoryId = newAmofeature.FeatureCategoryId,
                        FeatureCategoryName = newAmofeature.FeatureCategoryName,
                        DeliveryType = newAmofeature.DeliveryType,
                        AscmCategoryId = newAmofeature.AscmCategoryId,
                        AscmCategoryName = newAmofeature.AscmCategoryName,
                        NamingStandardId = newAmofeature.NamingStandardId
                    });
                }
            }

            IPaginationModel pagination = new PaginationModel();
            var result = new
            {
                page = pagination.PageNo,
                pageSize = pagination.PageSize,
                Records = features.AsQueryable(),
                TotalRecordsCount = features.Count
            };

            return JsonConvert.SerializeObject(result);
        }

        public IWizardContentModel GetContentModel(IReadOnlyDictionary<string, string> inputData)
        {
            string gridDataUrl = UrlPathHelper.GetWizardGridDataUrllPath(Id).UrlPath;
            IGridContentModel searchAmoFeaturesGridContentMode = new SearchAmoFeaturesGridContentModel(canShowGridCheckBox: true, gridDataUrlPath: gridDataUrl);
            SearchAmoFeaturesWizardContentModel wizardContentModel = new SearchAmoFeaturesWizardContentModel(_key, searchAmoFeaturesGridContentMode);

            if (_cache.TryGet(_key, out object cacheData)
                && cacheData is AddHpPartNumberDataCacheModel addNewHpPartNumberCacheData)
            {
                wizardContentModel.FeatureClassesFromCache = JsonConvert.SerializeObject(addNewHpPartNumberCacheData.FeatureClasses);
                wizardContentModel.FeatureCategoriesFromCache = JsonConvert.SerializeObject(addNewHpPartNumberCacheData.FeatureCategories);
                wizardContentModel.FeatureNamingStandardsFromCache = JsonConvert.SerializeObject(addNewHpPartNumberCacheData.NamingStandards);
                wizardContentModel.SearchTextFromCache = JsonConvert.SerializeObject(addNewHpPartNumberCacheData.SearchText);
                wizardContentModel.GriDataFromCache = GetGridDataFromCache(addNewHpPartNumberCacheData);
            }

            return wizardContentModel;
        }

        public int Id => WizardIdConstants.SearchAmoFeatures;
    }
}
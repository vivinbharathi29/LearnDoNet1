﻿using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.Infrastructure.Application.Wizard;

namespace HP.Pulsar.Ascm.Wizard
{
    public class AddHpPartNumberStateMachine : IWizardStateMachine
    {
        private readonly ISimpleDataCache _cache;

        public AddHpPartNumberStateMachine(ISimpleDataCache cache)
        {
            _cache = cache;
        }

        public bool TryGetCurrentWizard(int currentWizardId, string cacheKey, out IWizard currentWizard)
        {
            currentWizard = new SearchAmoFeaturesWizard(cacheKey, _cache);
            return true;
        }

        public bool TryGetNextWizard(int currentWizardId, string cacheKey, out IWizard nextWizard)
        {
            if (currentWizardId == WizardIdConstants.AddAmoFeaturesToAscm)
            {
                nextWizard = new AddAmoFeaturesToAscmWizard(cacheKey, _cache);
                return true;
            }

            nextWizard = null;
            return false;
        }

        public bool TryGetPreviousWizard(int currentWizardId, string cacheKey, out IWizard previousWizard)
        {
            if (currentWizardId == WizardIdConstants.SearchAmoFeatures)
            {
                previousWizard = new SearchAmoFeaturesWizard(cacheKey, _cache);
                return true;
            }

            previousWizard = null;
            return false;
        }

        public int Id => StateMachineIdConstants.AddHpPartNumbers;
    }
}
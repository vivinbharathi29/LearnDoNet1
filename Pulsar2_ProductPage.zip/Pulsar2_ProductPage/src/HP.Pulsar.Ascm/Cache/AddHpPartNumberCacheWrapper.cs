﻿using System.Collections.Generic;
using System.Linq;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Cache
{
    public class AddHpPartNumberCacheWrapper : IAddHpPartNumberCacheWrapper
    {
        private readonly ISimpleDataCache _simpleDataCache;

        public AddHpPartNumberCacheWrapper(ISimpleDataCache simpleDataCache)
        {
            _simpleDataCache = simpleDataCache;
        }

        public void SetDataToCache(int wizardId, string cacheKey, string content)
        {
            if (wizardId == 0 || string.IsNullOrWhiteSpace(cacheKey) || string.IsNullOrWhiteSpace(content))
            {
                return;
            }

            AddHpPartNumberDataCacheModel newCacheDataModel = JsonConvert.DeserializeObject<AddHpPartNumberDataCacheModel>(content);

            if (!_simpleDataCache.TryGet(cacheKey, out object cacheData) || !(cacheData is AddHpPartNumberDataCacheModel cachedDataModel))
            {
                _simpleDataCache.Set(cacheKey, newCacheDataModel);
            }
            else if (wizardId == WizardIdConstants.SearchAmoFeatures)
            {
                ReplaceCachedDataBySearchAmoFeaturesResult(cacheKey, cachedDataModel, newCacheDataModel);
            }
            else if (wizardId == WizardIdConstants.AddAmoFeaturesToAscm)
            {
                ReplaceCachedDataByAddAmoFeatures(cacheKey, cachedDataModel, newCacheDataModel);
            }
        }

        public bool TryGetDataFromCache(string cacheKey, out AddHpPartNumberDataCacheModel addHpPartNumberDataCacheModel)
        {
            if (!_simpleDataCache.TryGet(cacheKey, out object cacheData) || !(cacheData is AddHpPartNumberDataCacheModel cachedDataModel))
            {
                addHpPartNumberDataCacheModel = null;
                return false;
            }
            addHpPartNumberDataCacheModel = cachedDataModel;

            return true;
        }

        private void ReplaceCachedDataBySearchAmoFeaturesResult(string cacheKey, AddHpPartNumberDataCacheModel existingDataCacheModel, AddHpPartNumberDataCacheModel newDataCacheModel)
        {
            //save dropdown options to cache
            existingDataCacheModel.FeatureClasses = newDataCacheModel.FeatureClasses;
            existingDataCacheModel.FeatureCategories = newDataCacheModel.FeatureCategories;
            existingDataCacheModel.NamingStandards = newDataCacheModel.NamingStandards;

            //save search text
            existingDataCacheModel.SearchText = newDataCacheModel.SearchText;

            //convert IList to List is not a good solution, because error may happend if the implementation is not List.
            List<AddNewHpPartNumberGridDataCacheModel> cachedAmoFeatures;
            if (existingDataCacheModel.AmoFeatures is List<AddNewHpPartNumberGridDataCacheModel> existingAmoFeaturesInCache)
            {
                cachedAmoFeatures = existingAmoFeaturesInCache;
            }
            else
            {
                cachedAmoFeatures = new List<AddNewHpPartNumberGridDataCacheModel>();
            }

            List<AddNewHpPartNumberGridDataCacheModel> newAmoFeatures;
            if (newDataCacheModel.AmoFeatures is List<AddNewHpPartNumberGridDataCacheModel> newAmoFeaturesDataCacheModel)
            {
                newAmoFeatures = newAmoFeaturesDataCacheModel;
            }
            else
            {
                newAmoFeatures = new List<AddNewHpPartNumberGridDataCacheModel>();
            }

            //remove unselected features in the cache
            cachedAmoFeatures.RemoveAll(item => !item.IsSelected);

            //remove the duplicate features
            foreach (AddNewHpPartNumberGridDataCacheModel cachedFeature in cachedAmoFeatures)
            {
                newAmoFeatures.RemoveAll(newItem => newItem.FeatureId == cachedFeature.FeatureId);
            }

            cachedAmoFeatures.AddRange(newAmoFeatures);
            existingDataCacheModel.AmoFeatures = cachedAmoFeatures;
            _simpleDataCache.Set(cacheKey, existingDataCacheModel);
        }

        private void ReplaceCachedDataByAddAmoFeatures(string cacheKey, AddHpPartNumberDataCacheModel existingDataCacheModel, AddHpPartNumberDataCacheModel newDataCacheModel)
        {
            //convert IList to List is not a good solution, because error may happend if the implementation is not List.
            List<AddNewHpPartNumberGridDataCacheModel> cachedAmoFeatures;
            if (existingDataCacheModel.AmoFeatures is List<AddNewHpPartNumberGridDataCacheModel> existingAmoFeaturesInCache)
            {
                cachedAmoFeatures = existingAmoFeaturesInCache;
            }
            else
            {
                cachedAmoFeatures = new List<AddNewHpPartNumberGridDataCacheModel>();
            }

            //update the properties for the features in the cache
            foreach (AddNewHpPartNumberGridDataCacheModel newFeature in newDataCacheModel.AmoFeatures)
            {
                AddNewHpPartNumberGridDataCacheModel feature = cachedAmoFeatures.FirstOrDefault(item => item.FeatureId == newFeature.FeatureId);
                if (feature != null)
                {
                    feature.ProductLineIds = newFeature.ProductLineIds;
                    feature.ProductLineNames = newFeature.ProductLineNames;
                    feature.SkuTypeIds = newFeature.SkuTypeIds;
                    feature.SkuTypeNames = newFeature.SkuTypeNames;
                    feature.RegionIds = newFeature.RegionIds;
                    feature.RegionNames = newFeature.RegionNames;
                }
            }

            existingDataCacheModel.AmoFeatures = cachedAmoFeatures;
            _simpleDataCache.Set(cacheKey, existingDataCacheModel);
        }
    }
}
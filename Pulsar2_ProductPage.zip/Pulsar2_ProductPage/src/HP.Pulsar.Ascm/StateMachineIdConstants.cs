﻿namespace HP.Pulsar.Ascm
{
    public static class StateMachineIdConstants
    {
        public static readonly int AddHpPartNumbers = 1;
    }
}
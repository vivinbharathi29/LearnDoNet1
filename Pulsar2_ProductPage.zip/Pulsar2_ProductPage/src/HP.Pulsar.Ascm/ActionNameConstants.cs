﻿namespace HP.Pulsar.Ascm
{
    public static class ActionNameConstants
    {
        public static readonly string AddFeaturesToAscm = "AddFeaturesToAscm";
        public static readonly string AddMoreLocalizations = "AddMoreLocalizations";
        public static readonly string AllOptionsBatchUpdate = "BatchUpdateHpPartNumbers";
        public static readonly string DeletePartNumberActionName = "DeleteHpPartNumber";
        public static readonly string GetAmoFeatureCategories = "GetAmoFeatureCategories";
        public static readonly string GetAmoFeatureClasses = "GetAmoFeatureClasses";
        public static readonly string GetAmoFeatureLocalizations = "GetAmoFeatureLocalizations";
        public static readonly string GetAscmCategories = "GetAscmCategories";
        public static readonly string GetFeatureNamingStandards = "GetFeatureNamingStandards";
        public static readonly string GetGridData = "GetGridData";
        public static readonly string GetProductLines = "GetProductLines";
        public static readonly string GetRegions = "GetRegions";
        public static readonly string GetSkuTypes = "GetSkuTypes";
        public static readonly string GetTopRecommendGridData = "GetTopRecommendGridData";
        public static readonly string GetWizardGridData = "GetWizardGridData";
        public static readonly string HpPartNoPropertiesActionName = "GetHpPartNumber";
        public static readonly string Index = "Index";
        public static readonly string SaveHpPartNumber = "SaveHpPartNumber";
        public static readonly string Set = "Set";
        public static readonly string SetDataCache = "SetDataCache";
        public static readonly string UpdateAmoFeatureLocalization = "UpdateAmoFeatureLocalization";
    }
}
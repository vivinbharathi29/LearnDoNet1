﻿using System.Collections.Generic;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IAscmTabService
    {
        bool TryGetAscmTab(int tabId, out IAscmTab ascmTab);

        IEnumerable<IAscmTab> GetAscmTabs();
    }
}
﻿using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using HP.Pulsar.Ascm.Models;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IAscmReportApiRequester
    {
        Task<(HttpStatusCode HttpStatusCode, string Response)> GetChunkDataAsync(IReadOnlyList<ChunkApiInputRequest> chunkInputRequests);

        Task<(HttpStatusCode HttpStatusCode, string Response)> GetLinkDataAsync(IReadOnlyList<LinkApiInputRequest> linkInputRequests);
    }
}
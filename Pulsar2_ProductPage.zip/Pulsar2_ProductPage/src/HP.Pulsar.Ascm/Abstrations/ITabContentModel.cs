﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface ITabContentModel : IGridContentModel
    {
        int ActiveTabId { get; }

        IEnumerable<IAscmShortcut> Shortcuts { get; }
    }
}
﻿namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IGridDataModel
    {
    }
}

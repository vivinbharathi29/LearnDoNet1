﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.Infrastructure.Application.Wizard;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IAscmWizardContentModel : IWizardContentModel
    {
        string SetCacheUrl { get; }

        IGridContentModel GridContentModel { get; }
    }
}
﻿using HP.Pulsar.Ascm.Models;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IAddHpPartNumberCacheWrapper
    {
        void SetDataToCache(int wizardId, string cacheKey, string content);

        bool TryGetDataFromCache(string cacheKey, out AddHpPartNumberDataCacheModel addHpPartNumberDataCacheModel);
    }
}
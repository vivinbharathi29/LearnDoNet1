﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IAscmAdminRepository
    {
        Task<(IReadOnlyList<IGridDataModel> DataList, int? DataCount)> GetHpPartNumbersAsync(IPaginationModel pagination);

        Task<IReadOnlyList<(int LocalizationId, string LocalizationName, bool IsSelected)>> GetAmoFeatureLocalizationsAsync(int featureId);
        
        Task<IReadOnlyList<(int ProductLineId, string ProductLineName)>> GetProductLinesAsync();

        Task<IReadOnlyList<(int AscmCategoryId, string AscmCategoryName)>> GetAscmCategoriesAsync();

        Task<HpPartNumberOutputDataModel> GetHpPartNumberAsync(int featureId, int productLineId, int skuTypeId, int localizationId);

        Task<string> SaveHpPartNumberAsync(HpPartNumberInputDataModel properties, int updaterUserId);

        Task UpdateAmoFeatureLocalizationsAsync(SaveMoreLocalizationsInputDataModel model, int userId);
        
        Task<string> BatchUpdateHpPartNumbersAsync(BatchUpdateHpPartNumbersModel batchUpdateHpPartNumbers, int updaterUserId);

        Task DeleteHpPartNumberDateAsync(HpPartNumberIdsModel seletedItems, int updaterUserId);

        Task<IReadOnlyList<(int FeatureClassId, string FeatureClassName)>> GetFeatureClassesAsync();

        Task<IReadOnlyList<(int FeatureCategoryId, string FeatureCategoryName)>> GetFeatureCategoriesAsync(int featureClassId);

        Task<IReadOnlyList<(int NamingStandardId, string NamingStandardName)>> GetFeatureNamingStandardsAsync(int featureCategoryId);

        Task<(IReadOnlyList<SearchAmoFeaturesGridDataModel> DataList, int? DataCount)> GetFeatureSearchResultAsync(IPaginationModel pagination, int featureCategoryId, string namingStandardIds, string searchText);

        Task<IReadOnlyList<(int SkuTypeId, string SkuTypeName)>> GetSkuTypesAsync();

        Task<IReadOnlyList<(int RegionId, string RegionName)>> GetRegionsAsync();

        Task<string> AddFeaturesToAscmAsync(IReadOnlyList<AddAmoFeaturesToAscmInputModel> featurestoAscmInputModels, int updaterUserId);
    }
}
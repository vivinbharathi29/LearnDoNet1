﻿using System.Collections.Generic;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.CommonContracts.Infrastructure;

namespace HP.Pulsar.Ascm.Models
{
    public class AscmPageModel : IControllerToViewDataModelShim
    {
        public IEnumerable<IAscmTab> AscmTabs { get; set; }
        public string PartialViewUrl { get; set; }
        public ITabContentModel TabContentModel { get; set; }
        public string ViewUrlPath => ViewUrlPathConstants.AscmAdminViewUrlPath;
    }
}

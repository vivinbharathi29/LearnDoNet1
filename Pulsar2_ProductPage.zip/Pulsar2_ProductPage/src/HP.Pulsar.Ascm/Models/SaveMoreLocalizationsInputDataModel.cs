﻿namespace HP.Pulsar.Ascm.Models
{
    public class SaveMoreLocalizationsInputDataModel
    {
        public int FeatureId { get; set; }

        public string LocalizationIds { get; set; }
    }
}
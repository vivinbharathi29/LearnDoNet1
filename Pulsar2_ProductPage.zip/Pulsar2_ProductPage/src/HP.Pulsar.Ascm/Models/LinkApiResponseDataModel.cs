﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Models
{
    public class LinkApiResponseDataModel
    {
        [JsonProperty("OutputResponse")]
        public IReadOnlyList<LinkOutputResponse> OutputResponses { get; set; }
    }
}
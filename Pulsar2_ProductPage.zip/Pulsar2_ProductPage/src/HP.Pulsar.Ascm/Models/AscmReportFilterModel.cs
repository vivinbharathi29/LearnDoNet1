﻿using System;
using System.Collections.Generic;

namespace HP.Pulsar.Ascm.Models
{
    public class AscmReportFilterModel
    {
        public IReadOnlyList<string> AscmCategories { get; set; }

        public DateTime? BaseUnitEmDate { get; set; }

        public DateTime? BaseUnitGaDate { get; set; }

        public IReadOnlyList<string> BusinessSegments { get; set; }

        public IReadOnlyList<string> HppnBusinessSegments { get; set; }

        public DateTime? HppnEmDate { get; set; }

        public DateTime? HppnGaDate { get; set; }

        public IReadOnlyList<string> HppnProductLines { get; set; }

        public bool IsIncludedHppnNotInPrl { get; set; }

        public bool IsIncludedInactiveBaseUnits { get; set; }

        public int UserId { get; set; }
    }
}
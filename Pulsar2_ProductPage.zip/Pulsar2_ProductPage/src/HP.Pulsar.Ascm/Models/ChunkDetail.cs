﻿namespace HP.Pulsar.Ascm.Models
{
    public class ChunkDetail
    {
        //Use char because this is always "F" which is the specification of api.        
        public char ChunkStatus => 'F';

        public string ChunkValue { get; set; }

        public string Tag { get; set; }
    }
}
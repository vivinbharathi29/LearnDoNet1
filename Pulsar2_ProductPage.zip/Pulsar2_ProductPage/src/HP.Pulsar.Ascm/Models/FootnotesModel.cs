﻿namespace HP.Pulsar.Ascm.Models
{
    public class FootnotesModel
    {
        public string Item { get; set; }

        public string Note { get; set; }
    }
}
﻿namespace HP.Pulsar.Ascm.Models
{
    public sealed class PublishedResultType
    {
        public static readonly PublishedResultType None = new PublishedResultType(-1, "None");
        public static readonly PublishedResultType Success = new PublishedResultType(0, "Success");
        public static readonly PublishedResultType ExcelGenerationFailed = new PublishedResultType(1, "Excel ASCM Report generation failed");
        public static readonly PublishedResultType PrismApiFailed = new PublishedResultType(2, "Publish to PRISM failed");
        public static readonly PublishedResultType UnexpectedError = new PublishedResultType(3, "Unexpected exception");

        private PublishedResultType(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public int Id { get; }

        public string Name { get; }

        public static bool TryParse(int id, out PublishedResultType resultType)
        {
            if (id == 0)
            {
                resultType = Success;
            }
            else if (id == 1)
            {
                resultType = ExcelGenerationFailed;
            }
            else if (id == 2)
            {
                resultType = PrismApiFailed;
            }
            else if (id == 3)
            {
                resultType = UnexpectedError;
            }
            else
            {
                resultType = None;
            }

            return true;
        }

        public static object ConvertToString(object publishedResultType)
        {
            if (publishedResultType != null
                && int.TryParse(publishedResultType.ToString(), out int value)
                && TryParse(value, out PublishedResultType statuType))
            {
                return statuType.Name;
            }

            return None.Name;
        }

        public static object ConvertToInt(object publishedResultType)
        {
            if (publishedResultType != null
                && int.TryParse(publishedResultType.ToString(), out int value)
                && TryParse(value, out PublishedResultType statuType))
            {
                return statuType.Id;
            }

            return None.Id;
        }
    }
}
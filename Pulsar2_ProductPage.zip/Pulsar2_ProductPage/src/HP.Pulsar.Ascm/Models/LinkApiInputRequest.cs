﻿using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Models
{
    public class LinkApiInputRequest
    {
        public string Action { get; set; }

        //This is always "WW" in the specification of api.
        public string Catalog => "WW";

        [JsonProperty("CompProdNr")]
        public string HpPartNumber { get; set; }

        [JsonProperty("KmatNr")]
        public string Kmat { get; set; }

        //This is always "Accessories" in the specification of api.
        public string LinkTypeName => "Accessories";

        public string SortOrder { get; set; }
    }
}
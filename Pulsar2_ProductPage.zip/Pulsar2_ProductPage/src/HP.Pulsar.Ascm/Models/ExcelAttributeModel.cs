﻿using Infragistics.Documents.Excel;

namespace HP.Pulsar.Ascm.Models
{
    public class ExcelAttributeModel
    {
        public CellBorderLineStyle BottomBorderStyle { get; set; } = CellBorderLineStyle.Default;

        public bool CanRotate { get; set; }

        public CellFill FilledColor { get; set; }

        public int FirstColumn { get; set; }

        public int FirstRow { get; set; }

        public ExcelDefaultableBoolean FontBold { get; set; } = ExcelDefaultableBoolean.False;

        public HorizontalCellAlignment HorizontalCellAlignment { get; set; } = HorizontalCellAlignment.Center;

        public int LastColumn { get; set; }

        public int LastRow { get; set; }

        public CellBorderLineStyle LeftBorderStyle { get; set; } = CellBorderLineStyle.Default;

        public int MergedIndex { get; set; }

        public CellBorderLineStyle RightBorderStyle { get; set; } = CellBorderLineStyle.Default;

        public CellBorderLineStyle TopBorderStyle { get; set; } = CellBorderLineStyle.Default;

        public string Value { get; set; }

        public VerticalCellAlignment VerticalCellAlignment { get; set; } = VerticalCellAlignment.Center;

        public int Width { get; set; }
    }
}
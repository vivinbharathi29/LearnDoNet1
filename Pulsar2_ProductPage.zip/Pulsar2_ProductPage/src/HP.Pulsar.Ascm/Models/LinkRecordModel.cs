﻿namespace HP.Pulsar.Ascm.Models
{
    public class LinkRecordModel
    {
        public string HpPartNumber { get; set; }

        public string Kmat { get; set; }

        public string SortOrder { get; set; }
    }
}
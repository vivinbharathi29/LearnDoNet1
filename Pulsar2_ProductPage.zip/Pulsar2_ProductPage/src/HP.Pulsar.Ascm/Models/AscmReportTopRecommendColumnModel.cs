﻿namespace HP.Pulsar.Ascm.Models
{
    public class AscmReportTopRecommendColumnModel
    {
        public int ProductBrandId { get; set; }

        public string LongName { get; set; }

        public string Kmat { get; set; }
    }
}

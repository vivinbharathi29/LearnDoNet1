﻿namespace HP.Pulsar.Ascm.Models
{
    public class LinkDataModel
    {
        public int FeatureID { get; set; }

        public string HpPartNumber { get; set; }

        public string Kmat { get; set; }

        public int SortOrder { get; set; }
    }
}
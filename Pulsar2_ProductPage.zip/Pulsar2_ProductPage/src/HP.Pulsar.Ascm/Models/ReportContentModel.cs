﻿using System.Collections.Generic;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Ascm.Models
{
    public class ReportContentModel : ITabContentModel
    {
        public int ActiveTabId { get; set; }

        public IReadOnlyDictionary<string, string> AscmCategoriesAssigned { get; set; }

        public IReadOnlyDictionary<string, string> AscmCategoriesAvailable { get; set; }

        public IReadOnlyDictionary<string, string> BusinessSegmentsAssigned { get; set; }

        public IReadOnlyDictionary<string, string> BusinessSegmentsAvailable { get; set; }

        public bool CanShowGridCheckBox { get; set; }

        public bool CanShowGridRecordCount { get; set; }

        public string ColumnsData { get; set; }

        public string ColumnsToDisableGridCellClickingJsonString { get; set; }

        public string ColumnTemplateDefinition { get; set; }

        public IReadOnlyList<IGridContentModelOperation> ContextMenuOperations => new List<IGridContentModelOperation>();

        public ExcelExportWays ExcelExport { get; set; }

        public string ExcelExportFileName { get; set; }

        public AscmReportFilterRecordModel FilterRecord { get; set; }

        public string GridDataSpecialMessage => string.Empty;

        public string GridDataUrlPath { get; set; }

        public string GridFeatures { get; set; }

        public string GridPrimaryKey { get; set; }

        public IGridContentModelOperation GridRowOperation { get; set; }

        public IReadOnlyDictionary<string, string> HppnBusinessSegmentsAssigned { get; set; }

        public IReadOnlyDictionary<string, string> HppnBusinessSegmentsAvailable { get; set; }

        public IReadOnlyDictionary<string, string> HppnProductLinesAssigned { get; set; }

        public IReadOnlyDictionary<string, string> HppnProductLinesAvailable { get; set; }

        public string RowsRenderedOperation { get; set; }

        public IEnumerable<IAscmShortcut> Shortcuts { get; set; }

        public IReadOnlyList<IGridContentModelOperation> TopLinkOperations { get; set; }
    }
}
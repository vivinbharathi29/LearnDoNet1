﻿namespace HP.Pulsar.Ascm.Models
{
    public class AddAmoFeaturesToAscmInputModel
    {
        public int FeatureId { get; set; }
        public int? AscmCategoryId { get; set; }
        public string ProductLineIds { get; set; }
        public string SkuTypeIds { get; set; }
        public string RegionIds { get; set; }
    }
}
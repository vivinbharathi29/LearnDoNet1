﻿namespace HP.Pulsar.Ascm.Models
{
    public enum PublishToPrismType
    {        
        Delta = 0,
        Full = 1
    }
}
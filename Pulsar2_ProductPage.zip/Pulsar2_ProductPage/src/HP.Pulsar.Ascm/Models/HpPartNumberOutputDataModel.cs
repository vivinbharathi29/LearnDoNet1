﻿using System;

namespace HP.Pulsar.Ascm.Models
{
    public class HpPartNumberOutputDataModel
    {
        public int FeatureId { get; set; }
        public int SkuTypeId { get; set; }
        public int LocalizationId { get; set; }
        public string HpPartNo { get; set; }
        public string SkuType { get; set; }
        public string FeatureName { get; set; }
        public string GpgDescription { get; set; }
        public string Pmg100Description { get; set; }
        public string Pmg250Description { get; set; }
        public string CountryCode { get; set; }
        public int? AscmCategoryId { get; set; }
        public string AscmCategoryName { get; set; }
        public int? ProductLineId { get; set; }
        public string ProductLineName { get; set; }
        public DateTime? RTPDate { get; set; }
        public DateTime? SaDate { get; set; }
        public DateTime? PaadDate { get; set; }
        public DateTime? GaDate { get; set; }
        public DateTime? EmDate { get; set; }
        public DateTime? GsEolDate { get; set; }
        public string PreviousProduct { get; set; }
        public string Comments { get; set; }
        public int CreatorId { get; set; }
        public string Creator { get; set; }
        public DateTime Created { get; set; }
        public int? UpdaterId { get; set; }
        public string Updater { get; set; }
        public DateTime? Updated { get; set; }
        public int CurrentUserId { get; set; }
    }
}

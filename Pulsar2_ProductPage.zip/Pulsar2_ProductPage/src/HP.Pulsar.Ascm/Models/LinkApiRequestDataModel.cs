﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Models
{
    public class LinkApiRequestDataModel
    {
        [JsonProperty("InputRequest")]
        public IReadOnlyList<LinkApiInputRequest> InputRequests { get; set; }

        public string RequesterId { get; set; }
    }
}
﻿using System;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Ascm.Models
{
    public class AscmReportGridDataModel : IGridDataModel
    {
        [IgGridColumnAttributes(HeaderText = "Date Published", Format = "MM/dd/yyyy HH:mm:ss")]
        public DateTime DatePublished { get; set; }

        [IgGridColumnAttributes()]
        public string Publisher { get; set; }

        [IgGridColumnAttributes(HeaderText = "Published Result")]
        public string PublishedStateText { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feed to XROST Result")]
        public string FeedToXrostResultText { get; set; }

        [IgGridColumnAttributes(HeaderText = "Compatibility Feed to PRISM Result")]
        public string LinkApiHttpStatusText { get; set; }

        [IgGridColumnAttributes(HeaderText = "Footnote feed to PRISM Result")]
        public string ChunkApiHttpStatusText { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int? PublishedRecordId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int? PublishedStateId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int? FeedToXrostResultCode { get; set; }
    }
}
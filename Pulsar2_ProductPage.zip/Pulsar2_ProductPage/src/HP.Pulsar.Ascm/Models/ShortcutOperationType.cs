﻿namespace HP.Pulsar.Ascm.Models
{
    public enum ShortcutOperationType
    {
        ShowURLInPopup,
        ShowURLInPage,
        ShowURLInNewBrowserTab
    }
}
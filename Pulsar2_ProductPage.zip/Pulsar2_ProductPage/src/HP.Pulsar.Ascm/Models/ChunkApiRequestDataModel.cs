﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Models
{
    public class ChunkApiRequestDataModel
    {
        [JsonProperty("InputRequest")]
        public IReadOnlyList<ChunkApiInputRequest> InputRequests { get; set; }

        public string RequesterId { get; set; }
    }
}
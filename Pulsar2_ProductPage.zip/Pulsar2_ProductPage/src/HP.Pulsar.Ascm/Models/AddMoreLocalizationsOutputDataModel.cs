﻿namespace HP.Pulsar.Ascm.Models
{
    public class AddMoreLocalizationsOutputDataModel
    {
        public int FeatureId { get; set; }
    }
}
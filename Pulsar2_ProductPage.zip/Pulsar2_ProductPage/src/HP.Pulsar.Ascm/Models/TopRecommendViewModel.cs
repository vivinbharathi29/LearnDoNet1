﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure;

namespace HP.Pulsar.Ascm.Models
{
    public class TopRecommendViewModel : IControllerToViewDataModelShim
    {
        public IReadOnlyList<(int BusinessSegmentId, string BusinessSegmentName)> BusinessSegments { get; set; }

        public string GridFeatures { get; set; }

        public string GUID { get; set; }

        public IReadOnlyList<(int ProductLineId, string ProductLineName)> ProductLines { get; set; }

        public string TopRecommendGridDataUrlPath { get; set; }

        public string ViewUrlPath => ViewUrlPathConstants.TopRecommendViewUrlPath;
    }
}

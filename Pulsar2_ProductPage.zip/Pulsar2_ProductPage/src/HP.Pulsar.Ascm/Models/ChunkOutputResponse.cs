﻿using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Models
{
    public class ChunkOutputResponse
    {
        public string ChunkValue { get; set; }

        public string Sku { get; set; }

        public string StatusCode { get; set; }

        [JsonProperty("StatusMsg")]
        public string StatusMessage { get; set; }

        public string Tag { get; set; }
    }
}
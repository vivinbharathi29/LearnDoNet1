﻿using System.Collections.Generic;

namespace HP.Pulsar.Ascm.Models
{
    public class ChunkApiInputRequest
    {
        public IReadOnlyList<ChunkDetail> ChunkDetails { get; set; }

        //This is always "ww-en" in the specification of api.
        public string CultureCode => "ww-en";

        public string Sku { get; set; }
    }
}
﻿using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Ascm.Models
{
    public class AddAmoFeaturesToAscmGridDataModel : IGridDataModel
    {
        [IgGridColumnAttributes(HeaderText = "Feature ID")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Full Name")]
        public string FeatureFullName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Description(Marketing 100 Character - PMG)")]
        public string Description { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int FeatureCategoryId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Category")]
        public string FeatureCategoryName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Delivery Type")]
        public string DeliveryType { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int AscmCategoryId { get; set; }

        [IgGridColumnAttributes(HeaderText = "ASCM Category")]
        public string AscmCategoryName { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string ProductLineIds { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product Line")]
        public string ProductLineNames { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string SkuTypeIds { get; set; }

        [IgGridColumnAttributes(HeaderText = "Sku Type")]
        public string SkuTypeNames { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string RegionIds { get; set; }

        [IgGridColumnAttributes(HeaderText = "Localization")]
        public string RegionNames { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int NamingStandardId { get; set; }
    }
}

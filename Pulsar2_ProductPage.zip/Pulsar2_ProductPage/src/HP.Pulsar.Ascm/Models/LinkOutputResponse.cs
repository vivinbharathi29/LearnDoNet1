﻿using System;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Models
{
    public class LinkOutputResponse
    {
        public string Action { get; set; }

        public DateTime? EffectiveDate { get; set; }

        [JsonProperty("CompProdNr")]
        public string HpPartNumber { get; set; }

        [JsonProperty("KmatNr")]
        public string Kmat { get; set; }

        public string SortOrder { get; set; }

        public string StatusCode { get; set; }

        [JsonProperty("StatusMsg")]
        public string StatusMessage { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace HP.Pulsar.Ascm.Models
{
    public class AddHpPartNumberDataCacheModel
    {
        public IList<AddNewHpPartNumberGridDataCacheModel> AmoFeatures { get; set; }
        public IReadOnlyList<DropDownOptionDataModel> FeatureCategories { get; set; }
        public IReadOnlyList<DropDownOptionDataModel> FeatureClasses { get; set; }
        public IReadOnlyList<DropDownOptionDataModel> NamingStandards { get; set; }
        public string SearchText { get; set; }
    }
}
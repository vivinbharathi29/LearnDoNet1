﻿namespace HP.Pulsar.Ascm.Models
{
    public sealed class FeedToXrostResultType
    {
        public static readonly FeedToXrostResultType None = new FeedToXrostResultType(-1, "None");
        public static readonly FeedToXrostResultType Success = new FeedToXrostResultType(0, "Success");
        public static readonly FeedToXrostResultType InProgress = new FeedToXrostResultType(1, "Success"); // TODO Albert: Will change string to "In Progress" when Shanti finishs the XROST changes.
        public static readonly FeedToXrostResultType Failed = new FeedToXrostResultType(2, "Failed");
        public static readonly FeedToXrostResultType InitFailed = new FeedToXrostResultType(3, "Initialization failed");

        private FeedToXrostResultType(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public int Id { get; }

        public string Name { get; }

        public static bool TryParse(int id, out FeedToXrostResultType resultType)
        {
            if (id == 0)
            {
                resultType = Success;
            }
            else if (id == 1)
            {
                resultType = InProgress;
            }
            else if (id == 2)
            {
                resultType = Failed;
            }
            else if (id == 3)
            {
                resultType = InitFailed;
            }
            else
            {
                resultType = None;
            }

            return true;
        }

        public static object ConvertToName(object publishedResultType)
        {
            if (publishedResultType != null
                && int.TryParse(publishedResultType.ToString(), out int value)
                && TryParse(value, out FeedToXrostResultType statuType))
            {
                return statuType.Name;
            }

            return None.Name;
        }

        public static object ConvertToId(object publishedResultType)
        {
            if (publishedResultType != null
                && int.TryParse(publishedResultType.ToString(), out int value)
                && TryParse(value, out FeedToXrostResultType statuType))
            {
                return statuType.Id;
            }

            return None.Id;
        }
    }
}
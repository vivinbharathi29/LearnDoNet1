﻿using System.Collections.Generic;

namespace HP.Pulsar.Ascm.Models
{
    public class AllOptionsHPPartNumber
    {
        public static AllOptionsHPPartNumber ProductLine = new AllOptionsHPPartNumber("productLineId", "Product Line");
        public static AllOptionsHPPartNumber AscmCategory = new AllOptionsHPPartNumber("ascmCategoryId", "ASCM Category");
        public static AllOptionsHPPartNumber GaDate = new AllOptionsHPPartNumber("gaDate", "General Availability (GA) Date");
        public static AllOptionsHPPartNumber RtpDate = new AllOptionsHPPartNumber("rtpDate", "RTP/MR Date");
        public static AllOptionsHPPartNumber EmDate = new AllOptionsHPPartNumber("emDate", "End of Manufacturing (EM) Date");
        public static AllOptionsHPPartNumber GsEolDate = new AllOptionsHPPartNumber("gsEolDate", "Global Series EOL Date");

        private AllOptionsHPPartNumber(string key, string name)
        {
            Key = key;
            Name = name;
        }

        public string Key { get; set; }

        public string Name { get; set; }

        public static IReadOnlyList<AllOptionsHPPartNumber> Items => new List<AllOptionsHPPartNumber>() { ProductLine, AscmCategory, GaDate, RtpDate, EmDate, GsEolDate };
    }
}

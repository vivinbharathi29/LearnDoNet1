﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Models
{
    public class ChunkApiResponseDataModel
    {
        [JsonProperty("OutputResponse")]
        public IReadOnlyList<ChunkOutputResponse> OutputResponses { get; set; }
    }
}
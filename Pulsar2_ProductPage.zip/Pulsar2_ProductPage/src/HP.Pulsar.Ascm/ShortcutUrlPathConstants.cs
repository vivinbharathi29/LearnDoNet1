﻿
namespace HP.Pulsar.Ascm
{
    public static class ShortcutUrlPathConstants
    {
        public static string ImportPNFromS4 = "/Pulsar/Import/ImportPN?isASCM=true";
        public static string ExportRPNToS4 = "/Pulsar/Report/ExportRPNToS4View";
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using HP.Pulsar.Ascm.Abstrations;
using Microsoft.Extensions.DependencyInjection;

namespace HP.Pulsar.Ascm.Service
{
    public class AscmTabService : IAscmTabService
    {
        private readonly IEnumerable<IAscmTab> _tabs;

        public AscmTabService(IServiceProvider serviceProvider)
        {
            _tabs = serviceProvider.GetServices<IAscmTab>();
        }

        public IEnumerable<IAscmTab> GetAscmTabs()
        {
            return _tabs;
        }

        public bool TryGetAscmTab(int tabId, out IAscmTab ascmTab)
        {
            ascmTab = _tabs.FirstOrDefault(t => t.Id == tabId);
            return ascmTab != null;
        }
    }
}
﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace HP.Pulsar.Ascm.Helper
{
    public static class JsonHelper
    {
        public static JsonSerializerSettings GetJsonSerializerSettings(IContractResolver resolver)
        {
            return new JsonSerializerSettings
            {
                ContractResolver = resolver
            };
        }
    }
}

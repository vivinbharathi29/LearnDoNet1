﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;

namespace HP.Pulsar.Ascm.Helper
{
    internal static class HpPartNumberHelper
    {
        public static Task<IReadOnlyList<(int LocalizationId, string LocalizationName, bool IsSelected)>> GetAmoFeatureLocalizations(IAscmAdminRepository ascmRepository, int featureId)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult<IReadOnlyList<(int LocalizationId, string LocalizationName, bool IsSelected)>>(new List<(int LocalizationId, string LocalizationName, bool IsSelected)>());
            }

            return ascmRepository.GetAmoFeatureLocalizationsAsync(featureId);
        }

        public static Task<IReadOnlyList<(int ProductLineId, string ProductLineName)>> GetProductLines(IAscmAdminRepository ascmRepository)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult<IReadOnlyList<(int ProductLineId, string ProductLineName)>>(new List<(int ProductLineId, string ProductLineName)>());
            }

            return ascmRepository.GetProductLinesAsync();
        }

        public static Task<IReadOnlyList<(int AscmCategoryId, string AscmCategoryName)>> GetAscmCategories(IAscmAdminRepository ascmRepository)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult<IReadOnlyList<(int AscmCategoryId, string AscmCategoryName)>>(new List<(int AscmCategoryId, string AscmCategoryName)>());
            }

            return ascmRepository.GetAscmCategoriesAsync();
        }

        public static Task<string> BatchUpdateHpPartNumbers(IAscmAdminRepository ascmRepository, BatchUpdateHpPartNumbersModel batchUpdateHpPartNumbersModel, int updaterUserId)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult(string.Empty);
            }

            return ascmRepository.BatchUpdateHpPartNumbersAsync(batchUpdateHpPartNumbersModel, updaterUserId);
        }

        public static Task<HpPartNumberOutputDataModel> GetHpPartNumber(IAscmAdminRepository ascmRepository, int featureId, int productLineId, int skuTypeId, int localizationId)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult(new HpPartNumberOutputDataModel());
            }

            return ascmRepository.GetHpPartNumberAsync(featureId, productLineId, skuTypeId, localizationId);
        }

        public static Task<string> SaveHpPartNumberAsync(IAscmAdminRepository ascmRepository, HpPartNumberInputDataModel hpPartNumberModel, int updaterUserId)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult(string.Empty);
            }

            return ascmRepository.SaveHpPartNumberAsync(hpPartNumberModel, updaterUserId);
        }

        public static Task UpdateAmoFeatureLocalizationAsync(IAscmAdminRepository ascmRepository, SaveMoreLocalizationsInputDataModel model, int userId)
        {
            if (ascmRepository == null)
            {
                return Task.CompletedTask;
            }

            return ascmRepository.UpdateAmoFeatureLocalizationsAsync(model, userId);
        }

        public static Task DeleteHpPartNumberAsync(IAscmAdminRepository ascmRepository, HpPartNumberIdsModel seletedItem, int updaterUserId)
        {
            if (ascmRepository == null)
            {
                return Task.CompletedTask;
            }

            return ascmRepository.DeleteHpPartNumberDateAsync(seletedItem, updaterUserId);
        }

        public static Task<IReadOnlyList<(int FeatureClassId, string FeatureClassName)>> GetFeatureClasses(IAscmAdminRepository ascmRepository)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult<IReadOnlyList<(int FeatureClassId, string FeatureClassName)>>(new List<(int FeatureClassId, string FeatureClassName)>());
            }

            return ascmRepository.GetFeatureClassesAsync();
        }

        public static Task<IReadOnlyList<(int FeatureCategoryId, string FeatureCategoryName)>> GetFeatureCategories(IAscmAdminRepository ascmRepository, int featureClassId)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult<IReadOnlyList<(int FeatureCategoryId, string FeatureCategoryName)>>(new List<(int FeatureCategoryId, string FeatureCategoryName)>());
            }

            return ascmRepository.GetFeatureCategoriesAsync(featureClassId);
        }

        public static Task<IReadOnlyList<(int NamingStandardId, string NamingStandardName)>> GetFeatureNamingStandards(IAscmAdminRepository ascmRepository, int featureCategoryId)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult<IReadOnlyList<(int NamingStandardId, string NamingStandardName)>>(new List<(int NamingStandardId, string NamingStandardName)>());
            }

            return ascmRepository.GetFeatureNamingStandardsAsync(featureCategoryId);
        }

        public static Task<IReadOnlyList<(int SkuTypeId, string SkuTypeName)>> GetSkuTypes(IAscmAdminRepository ascmRepository)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult<IReadOnlyList<(int SkuTypeId, string SkuTypeName)>>(new List<(int SkuTypeId, string SkuTypeName)>());
            }

            return ascmRepository.GetSkuTypesAsync();
        }

        public static Task<IReadOnlyList<(int RegionId, string RegionName)>> GetRegions(IAscmAdminRepository ascmRepository)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult<IReadOnlyList<(int RegionId, string RegionName)>>(new List<(int RegionId, string RegionName)>());
            }

            return ascmRepository.GetRegionsAsync();
        }

        public static Task<string> AddFeaturesToAscm(IAscmAdminRepository ascmRepository, IReadOnlyList<AddAmoFeaturesToAscmInputModel> featuresToAscmInputModel, int updaterUserId)
        {
            if (ascmRepository == null)
            {
                return Task.FromResult(string.Empty);
            }

            return ascmRepository.AddFeaturesToAscmAsync(featuresToAscmInputModel, updaterUserId);
        }

        public static async Task<(IReadOnlyList<IGridDataModel> DataList, int? DataCount)> GetSearchNewAmoFeaturesGridDataAsync(int featureCategoryId, string namingStandardIds, string searchText, IAscmAdminRepository ascmRepository, IPaginationModel pagination)
        {
            if (ascmRepository == null)
            {
                return (new List<SearchAmoFeaturesGridDataModel>(), 0);
            }

            return await ascmRepository.GetFeatureSearchResultAsync(pagination, featureCategoryId, namingStandardIds, searchText);
        }

        public static (int FeatureCategoryId, string NamingStandardIds, string SearchText) GetQueryStringParameterFromCache(ISimpleDataCache dataCache, string cacheKey)
        {
            if (dataCache == null || !dataCache.TryGet(cacheKey, out object queryStringParams))
            {
                return (0, string.Empty, string.Empty);
            }

            string[] paramsFromCache = queryStringParams.ToString().Split('|');

            if (paramsFromCache.Length < 2)
            {
                return (0, string.Empty, string.Empty);
            }

            int.TryParse(paramsFromCache[0], out int featureCategoryIdFromCache);
            return (featureCategoryIdFromCache, paramsFromCache[1], paramsFromCache[2]);
        }
    }
}
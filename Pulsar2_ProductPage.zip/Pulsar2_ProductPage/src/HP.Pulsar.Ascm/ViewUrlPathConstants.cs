﻿namespace HP.Pulsar.Ascm
{
    public static class ViewUrlPathConstants
    {
        public static readonly string AddAmoFeaturesToAscmWizardUrlPath = "~/Views/Wizard/AddAmoFeaturesToAscmWizard.cshtml";
        public static readonly string AddMoreLocalizationsUrlPath = "~/Views/Ascm/AddMoreLocalizations.cshtml";
        public static readonly string AllOptionsPartialViewUrlPath = "~/Views/Ascm/_AllOptions.cshtml";
        public static readonly string AscmAdminViewUrlPath = "~/Views/Ascm/Ascm.cshtml";
        public static readonly string AscmReportViewUrlPath = "~/Views/Ascm/AscmReport.cshtml";
        public static readonly string ErrorViewUrlRelativePath = "~/Views/Home/Error.cshtml";
        public static readonly string HpPartNumberPropertiesUrlPath = "~/Views/Ascm/HpPartNumberProperties.cshtml";
        public static readonly string SearchAmoFeaturesWizardUrlPath = "~/Views/Wizard/SearchAmoFeaturesWizard.cshtml";
        public static readonly string TopRecommendViewUrlPath = "~/Views/Ascm/AscmTopRecommend.cshtml";
    }
}
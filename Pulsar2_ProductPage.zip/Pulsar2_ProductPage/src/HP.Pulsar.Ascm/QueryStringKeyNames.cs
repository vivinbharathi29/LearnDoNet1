﻿namespace HP.Pulsar.Ascm
{
    public static class QueryStringKeyNames
    {
        public static readonly string AscmTabId = "ascmTabId";
        public static readonly string StateMachineId = "stateMachineId";
        public static readonly string WizardId = "wizardId";
        public static readonly string IsNextStep = "isNextStep";
        public static readonly string CacheKey = "cacheKey";
        public static readonly string Guid = "guid";
    }
}
﻿using System;
using System.Collections.Generic;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.Ascm.Models;

namespace HP.Pulsar.Ascm.Shortcuts
{
    public class AddHpPartNumberShortcut : IAscmShortcut
    {
        public string Name => "Add HP Part Number(s)";

        public int TabId => TabIdConstants.AllOptions;

        public ShortcutOperationType Type => ShortcutOperationType.ShowURLInPage;

        public string JavaScriptFunctionName { get; set; }

        public string GetUrlPath()
        {
            return UrlPathHelper.GetShortcutUrlPath(ControllerNameConstants.Wizard,
                                                    ActionNameConstants.Index,
                                                    GetShortcutParameters()).UrlPath;
        }

        private IReadOnlyDictionary<string, string> GetShortcutParameters()
        {
            Dictionary<string, string> dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            dict[QueryStringKeyNames.StateMachineId] = StateMachineIdConstants.AddHpPartNumbers.ToString();
            dict[QueryStringKeyNames.WizardId] = WizardIdConstants.SearchAmoFeatures.ToString();
            return dict;
        }
    }
}
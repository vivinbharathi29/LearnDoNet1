﻿using System;

namespace HP.Pulsar.CommonContracts.Infrastructure.Grid
{
    public class IgGridColumnAttributes : Attribute
    {
        public string ColumnCssClass { get; set; }

        public string ColumnWidth { get; set; }

        public string Format { get; set; }

        public string HeaderText { get; set; }

        public bool IsHidden { get; set; }

        public string Template { get; set; }
    }
}

﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Grid
{
    public class ColumnValueSeparator
    {
        private char _character;

        // The following are the only valid column value separators.
        public readonly static ColumnValueSeparator Hyphen = new ColumnValueSeparator('-');
        public readonly static ColumnValueSeparator Underscore = new ColumnValueSeparator('_');
        public readonly static ColumnValueSeparator Colon = new ColumnValueSeparator(':');
        public readonly static ColumnValueSeparator Comma = new ColumnValueSeparator(',');

        //The constructor is private, so the class cannot be instantiated outside this class
        private ColumnValueSeparator(char character)
        {
            _character = character;
        }

        public override string ToString()
        {
            return _character.ToString();
        }
    }
}
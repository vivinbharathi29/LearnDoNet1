﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Grid
{
    public interface IGridGeneralOutput
    {
    }
}

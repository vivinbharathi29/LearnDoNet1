﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Configuration
{
    public interface IAppConfiguration
    {
        string AppName { get; }

        string BcrUrlForEmail { get; }

        string DcrUrlForEmail { get; }

        string ElasticApmEnableApmClientSideTelemetryKey { get; }

        string ElasticApmInternalClientSideServiceName { get; }

        string ElasticApmInternalClientSideUrl { get; }

        string ElasticApmLogLevel { get; }

        string ElasticApmPRPClientSideServiceName { get; }

        string ElasticApmPRPClientSideUrl { get; }

        string ElasticApmServerSideServiceName { get; }

        string ElasticApmServerSideUrl { get; }

        string Environment { get; }

        string GridLoadOnDemandChunkSize { get; }

        string IrsUrl { get; }

        string IrsUrlFromDatabase { get; }

        string IrsUrlReplacementSearch { get; }

        //The below are for to get the Nebula Url path for Legacy Quick search
        string NebulaOnLegacySearchUrl { get; }

        //The below are for to get the Nebula Url path for Legacy Quick search
        string NebulaUrl { get; }

        string OdmServerNameEmailLink { get; }

        string ProductDocsFullFilePathHouHpqExcal { get; }

        string ProductDocsFullFilePathTpopsgDev { get; }

        string ProductDocsPartialFilePathHouHpqExcal { get; }

        string ProductDocsPartialFilePathTpopsgDev { get; }

        string PRSDatabaseConnectionString { get; }

        string Pulsar2ServerName { get; }

        // ticket support legacy code from PulsarPlus
        string PulsarFileStorePath { get; }

        // ticket support legacy code from PulsarPlus
        string PulsarServerName { get; }

        string PulsarServerNameEmailLink { get; }

        // ticket support legacy code from PulsarPlus
        string SupportEmailLink { get; }
    }
}
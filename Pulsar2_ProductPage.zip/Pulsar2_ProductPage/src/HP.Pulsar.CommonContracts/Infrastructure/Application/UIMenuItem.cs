﻿using System.Diagnostics;

namespace HP.Pulsar.CommonContracts.Infrastructure.Application
{
    [DebuggerDisplay("ItemId={ItemId} GroupName={GroupName} SubGroupName={SubgroupName} DisplayName={DisplayName}")]
    public class UIMenuItem
    {
        public string DisplayName { get; set; }

        public string GroupName { get; set; }

        public bool IsUserFavorite { get; set; }

        public int ItemId { get; set; }

        public string Link { get; set; }

        public MenuItemDisplayMode MenuItemDisplayMode { get; set; }

        public int Sequence { get; set; }

        public string SubgroupName { get; set; }
    }
}
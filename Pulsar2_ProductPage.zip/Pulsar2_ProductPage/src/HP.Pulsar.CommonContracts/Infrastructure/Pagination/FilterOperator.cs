﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Pagination
{
    public enum FilterOperator
    {
        Between,
        Contains,
        ContainsCaseSensitive,
        Empty,
        EndsWith,
        EndsWithCaseSensitive,
        Equal,
        EqualToCaseSensitive,
        GreaterThan,
        GreaterThanOrEqual,
        LessThan,
        LessThanOrEqual,
        NotContains,
        NotContainsCaseSensitive,
        NotEmpty,
        NotEqual,
        NotNull,
        Null,
        StartsWith,
        StartsWithCaseSensitive,
        IN,
    }
}

﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.Infrastructure.Pagination
{
    public interface IPaginationModel
    {
        IList<FilterModel> Filters { get; }

        int PageNo { get;  }

        int PageSize { get; }

        IReadOnlyList<int> PageSizeOptions { get;}

        string SortBy { get; }

        SortDirection SortDirection { get; }
    }

    public enum SortDirection
    {
        Ascending = 1,
        Descending = 2
    }
}

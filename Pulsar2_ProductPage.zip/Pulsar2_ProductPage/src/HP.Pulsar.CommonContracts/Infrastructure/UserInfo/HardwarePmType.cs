﻿namespace HP.Pulsar.CommonContracts.Infrastructure.UserInfo
{
    public enum HardwarePmType
    {
        None = 0,
        PlatformDevelopment = 1,
        CommercialHardware = 2,
        Processor = 3,
        GraphicsController = 4,
        VideoMemory = 5
    }
}

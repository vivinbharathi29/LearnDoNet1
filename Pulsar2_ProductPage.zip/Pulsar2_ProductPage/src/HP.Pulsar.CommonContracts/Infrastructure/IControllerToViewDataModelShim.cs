﻿namespace HP.Pulsar.CommonContracts.Infrastructure
{
    /// <summary>
    /// This is a shim that will be used in between controller 
    /// and view to make abstraction in an easier way in many 
    /// business entities and services.
    /// </summary>
    public interface IControllerToViewDataModelShim
    {
        public string ViewUrlPath { get; }
    }
}

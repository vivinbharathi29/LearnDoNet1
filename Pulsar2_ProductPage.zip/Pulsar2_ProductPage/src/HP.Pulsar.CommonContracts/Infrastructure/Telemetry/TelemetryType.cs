﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HP.Pulsar.CommonContracts.Infrastructure.Telemetry
{
    public enum TelemetryType
    {
        /// <summary>
        /// Used to track user behavior or to monitor performance
        /// </summary>
        Event = 0,

        /// <summary>
        /// Logging exceptions for diagnosis. Trace where they occur in relation to other events and examine stack traces.
        /// </summary>
        Fault,
    }
}

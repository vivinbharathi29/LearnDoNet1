﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Popup
{
    public enum PopupSize
    {
        Small = 0,
        Medium,
        Big,
    }
}

﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Email
{
    public enum EmailImportance
    {
        High = 1,
        Normal = 2,
        Low = 3
    }
}

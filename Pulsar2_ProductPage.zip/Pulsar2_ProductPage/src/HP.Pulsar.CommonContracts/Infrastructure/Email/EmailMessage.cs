﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.Infrastructure.Email
{
    public class EmailMessage
    {
        public string AttachmentPaths { get; set; }

        public IReadOnlyList<string> Attachments { get; set; }

        public string CreatedBy { get; set; }

        public string EmailBcc { get; set; }

        public string EmailBody { get; set; }

        public string EmailCc { get; set; }

        public EmailImportance EmailImportance { get; set; }

        public string EmailSubject { get; set; }

        public string EmailTo { get; set; }

        public string EmailType { get; set; }

        public string SenderEmail { get; set; }

        public string SenderName { get; set; }
    }
}
﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Tiles;
using HP.Pulsar.CommonContracts.TodayPage.Tiles.Models;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IComponentTestRepository
    {
        Task<(IReadOnlyList<ComponentsAwaitingTestReviewTileDataFromTile> DataList, int DataCount)> GetComponentsAwaitingTestReviewAsync(IPaginationModel pagination);

        Task<int> GetComponentsAwaitingTestReviewCountAsync();

        Task<(IReadOnlyList<ComponentInFunctionalTestTileDataFromRepo> DataList, int DataCount)> GetComponentsInFunctionalTestAsync(string userName, string domainName, IPaginationModel pagination);

        Task<int> GetComponentsInFunctionalTestCountAsync(string userName, string domainName);
    }
}
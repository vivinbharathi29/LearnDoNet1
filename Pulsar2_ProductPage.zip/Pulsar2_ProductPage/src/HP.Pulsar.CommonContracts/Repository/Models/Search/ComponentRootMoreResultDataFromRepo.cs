﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HP.Pulsar.CommonContracts.Repository.Models.Search
{
    public class ComponentRootMoreResultDataFromRepo
    {
        public int ComponentRootId { get; set; }

        public string ComponentRootName { get; set; }

        public string ComponentRootDescription { get; set; }

        public bool IsDeactivated { get; set; }

        public string Url { get; set; }
    }
}

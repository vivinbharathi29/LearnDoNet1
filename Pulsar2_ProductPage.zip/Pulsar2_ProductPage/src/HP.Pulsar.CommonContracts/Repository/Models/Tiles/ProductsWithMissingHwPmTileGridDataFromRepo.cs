﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class ProductsWithMissingHwPmTileGridDataFromRepo
    {
        public int ConsumerProducts { get; set; }

        public int CommercialProducts { get; set; }

        public string Description { get; set; }

        public string DevCenter { get; set; }

        public int Id { get; set; }

        public string Partner { get; set; }

        public string Product { get; set; }
    }
}
﻿using System;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class NewComponentRequestsTileDataFromRepo
    {
        public string ComponentName { get; set; }
        public int DataId { get; set; }
        public int ComponentVersionId { get; set; }
        public int ReleaseId { get; set; }
        public ComponentType ComponentType { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? EndOfLifeDate { get; set; }
        public string Product { get; set; }
        public int ComponentRootId { get; set; }
        public string Vendor { get; set; }
        public string Version { get; set; }
        public int VersionId { get; set; }
    }
}

﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class NewComponentReleasedTileDataFromRepo
    {
        public string Component { get; set; }
        public int ComponentRootId { get; set; }
        public int ComponentVersionId { get; set; }
        public string DeveloperName { get; set; }
        public DeveloperNotificationStatus DeveloperNotificationStatus { get; set; }
        public string ImageSummary { get; set; }
        public int CriticalChangesCount { get; set; }
        public int IssuesCount { get; set; }
        public bool IsPreInstall { get; set; }
        public bool IsPreload { get; set; }
        public bool IsWeb { get; set; }
        public bool IsDropInBox { get; set; }
        public bool IsSelectiveRestore { get; set; }
        public bool IsArcd { get; set; }
        public bool IsDRDvd { get; set; }
        public bool IsRacdAmericas { get; set; }
        public bool IsRacdEmea { get; set; }
        public bool IsOSCD { get; set; }
        public bool IsDocCD { get; set; }
        public bool IsFusion { get; set; }
        public bool IsPulsar { get; set; }
        public bool IsRacdApd { get; set; }
        public string OSSupported { get; set; }
        public string Pass { get; set; }
        public string PartNumber { get; set; }
        public string ProductName { get; set; }
        public byte Patch { get; set; }
        public int ProductId { get; set; }
        public string Release { get; set; }
        public string Revision { get; set; }
        public string TargetNotes { get; set; }
        public int TargetVersionCount { get; set; }
        public string Version { get; set; }
    }
}

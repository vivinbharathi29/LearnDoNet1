﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class OpenObservationsISubmittedTileDataFromRepo
    {
        public string Component { get; set; }

        public string CpqVersion { get; set; }

        public long ObservationId { get; set; }

        public string OwnerName { get; set; }

        public string Priority { get; set; }

        public string Product { get; set; }

        public string ShortDescription { get; set; }

        public string State { get; set; }
    }
}

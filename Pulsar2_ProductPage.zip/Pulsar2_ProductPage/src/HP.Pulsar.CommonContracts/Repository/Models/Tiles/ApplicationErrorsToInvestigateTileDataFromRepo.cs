﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class ApplicationErrorsToInvestigateTileDataFromRepo
    {
        public string AuthUser { get; set; }

        public string Email { get; set; }

        public DateTime ErrorDateTime { get; set; }

        public string ErrorDescription { get; set; }

        public int? ErrorLine { get; set; }

        public int Id { get; set; }

        public string Page { get; set; }

        public string User { get; set; }
    }
}
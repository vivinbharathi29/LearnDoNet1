﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public enum DeveloperNotificationStatus
    {
        Review = 0,
        Accepted,
        Rejected,
    }
}
﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ProductVersionReleaseDetailsDataFromRepo
    {
        public int ProductDeliverableId { get; set; }

        public int ProductDeliverableReleaseId { get; set; }

        public int ReleaseId { get; set; }

        public string ReleaseName { get; set; }
    }
}
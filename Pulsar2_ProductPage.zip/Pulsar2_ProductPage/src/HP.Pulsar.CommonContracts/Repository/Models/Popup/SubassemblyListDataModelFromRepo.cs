﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class SubassemblyListDataModelFromRepo : IGridGeneralOutput
    {
        public int Id { get; set; }

        public bool IsActive { get; set; }

        public bool IsSelected { get; set; }

        public string Name { get; set; }

        public int RealRootId { get; set; }

        public string SubAssembly { get; set; }
    }
}

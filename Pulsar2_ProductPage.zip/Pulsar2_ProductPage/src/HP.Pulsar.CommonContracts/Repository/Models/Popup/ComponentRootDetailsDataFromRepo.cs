﻿using System;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentRootDetailsDataFromRepo
    {
        public int ComponentRootId { get; set; }

        public string ComponentName { get; set; }

        public string DotsName { get; set; }

        public DateTime? EoaDate { get; set; }

        public HardwareIntegrationTestStatus HardwareIntegrationTestStatus { get; set; }

        public string ModelNumber { get; set; }

        public ODMTestStatus ODMTestStatus { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public int ProductDeliverableReleaseId { get; set; }

        public int ProductId { get; set; }

        public string Revision { get; set; }

        public string VendorName { get; set; }

        public string Version { get; set; }

        public int VersionId { get; set; }

        public WWANTestStatus WWANTestStatus { get; set; }
    }
}
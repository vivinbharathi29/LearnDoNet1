﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
   public class ProductComponentModelFromRepo
    {
        public string DeveloperTestNotes { get; set; }
        public int ComponentId { get; set; }
        public string ModelNumber { get; set; }
        public string Name { get; set; }
        public string PartNumber { get; set; }
        public int ProductComponentReleaseId { get; set; }
        public string ProductName { get; set; }
        public string Vendor { get; set; }
        public string Version { get; set; }        
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentVersionDataFromRepo : IGridGeneralOutput
    {
        public string ComponentName { get; set; }

        public string Pass { get; set; }

        public string Revision { get; set; }

        public string Version { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class MilestonePlanScheduleUpdateDataFromRepo : IGridGeneralOutput
    {
        public DateTime? ActualDate { get; set; }

        public int Id { get; set; }

        public string Milestone { get; set; }

        public DateTime? PlannedDate { get; set; }
    }
}

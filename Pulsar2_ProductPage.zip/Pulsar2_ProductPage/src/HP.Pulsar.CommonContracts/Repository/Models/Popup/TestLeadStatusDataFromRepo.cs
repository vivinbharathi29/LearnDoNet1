﻿using HP.Pulsar.CommonContracts.TodayPage.Popup;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class TestLeadStatusDataFromRepo
    {
        public string OdmTestNotes { get; set; }

        public string ProductName { get; set; }

        public ComponentVersionTestStatus TestStatus { get; set; }

        public int? UnitsReceived { get; set; }
    }
}
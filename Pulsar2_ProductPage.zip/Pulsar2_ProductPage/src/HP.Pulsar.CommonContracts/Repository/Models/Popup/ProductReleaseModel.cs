﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ProductReleaseModel
    {
        public int ProductReleaseVersionId { get; set; }

        public string ProductReleaseVersionName { get; set; }

        public bool IsSelected { get; set; }
    }
}

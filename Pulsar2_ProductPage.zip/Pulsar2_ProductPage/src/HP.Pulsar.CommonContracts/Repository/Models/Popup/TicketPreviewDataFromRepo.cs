﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class TicketPreviewDataFromRepo : IGridGeneralOutput
    {
        public string Attachment1 { get; set; }
        public string Attachment2 { get; set; }
        public string Attachment3 { get; set; }
        public string Details { get; set; }
        public int Id { get; set; }
        public string OwnerName { get; set; }
        public string Resolution { get; set; }
        public string SubmitterName { get; set; }
        public string Summary { get; set; }
        public string SupportCategoryName { get; set; }
        public string SupportIssueTypeName { get; set; }
        public string SupportProjectName { get; set; }
        public string SupportStatusName { get; set; }
        public int? UserPriorityId { get; set; }
    }
}

﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ProductMultiQualificationStatusDataFromRepo
    {
        public DateTime? AccessoryDate { get; set; }

        public string AccessoryNotes { get; set; }

        public string AccessoryStatusName { get; set; }

        public int DeliverableId { get; set; }

        public DateTime? EndOfLifeDate { get; set; }

        public bool IsActive { get; set; }

        public string ModelNumber { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public DateTime? PilotDate { get; set; }

        public string PilotNotes { get; set; }

        public string PilotStatusName { get; set; }

        public int ProductDeliverableReleaseId { get; set; }

        public string ProductName { get; set; }

        public string Release { get; set; }

        public string Revision { get; set; }

        public string RootName { get; set; }

        public string Status { get; set; }

        public int StatusId { get; set; }

        public string TargetNotes { get; set; }

        public DateTime? TestDate { get; set; }

        public string VendorName { get; set; }

        public int VersionId { get; set; }
        
        public string Version { get; set; }
    }
}

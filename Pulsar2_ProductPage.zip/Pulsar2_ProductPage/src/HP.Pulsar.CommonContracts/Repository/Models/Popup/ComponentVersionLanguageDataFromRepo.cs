﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentVersionLanguageDataFromRepo
    {
        public string Abbreviation { get; set; }

        public int LanguageId { get; set; }
    }
}
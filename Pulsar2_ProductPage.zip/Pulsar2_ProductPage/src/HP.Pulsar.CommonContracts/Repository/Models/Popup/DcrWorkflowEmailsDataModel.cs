﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class DcrWorkflowEmailsDataModel
    {
        public string ReceiversEmail { get; set; }

        public string ProductName { get; set; }

        public string Summary { get; set; }
    }
}

﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class AddAvNumberToFeatureFromPopup : IGridGeneralOutput
    {
        public int AvCreateId { get; set; }

        public int FeatureId { get; set; }

        public string FeatureName { get; set; }

        public IDictionary<string, string> AvDescriptions { get; set; }
    }
}
﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public enum ComponentVersionOperation
    {
        Release = 1,
        Cancel = 2
    }
}

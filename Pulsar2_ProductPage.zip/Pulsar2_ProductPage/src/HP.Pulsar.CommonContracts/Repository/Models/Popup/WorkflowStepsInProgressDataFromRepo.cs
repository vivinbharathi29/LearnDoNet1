﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentWorkflowStepsInProgressDataFromRepo
    {
        public string Milestone { get; set; }

        public int MilestoneId { get; set; }

        public string NotificationEmailAddresses { get; set; }

        public string CommercialSpecificNotificationEmailAddresses { get; set; }

        public string ConsumerSpecificNotificationEmailAddresses { get; set; }

        public byte ReportMilestone { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class AddAvNumberToDeliverableFromPopup : IGridGeneralOutput
    {
        public int AvCreateId { get; set; }

        public string ComponentName { get; set; }

        public int ComponentRootId { get; set; }

        public int ProductBrandId { get; set; }
    }
}
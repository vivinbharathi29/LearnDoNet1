﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ApplicationErrorsFromRepo
    {
        public string File { get; set; }

        public string RequestForm { get; set; }

        public string RequestQueryString { get; set; }

        public int Line { get; set; }

        public string Referrer { get; set; }

        public string ServerVariable { get; set; }
    }
}

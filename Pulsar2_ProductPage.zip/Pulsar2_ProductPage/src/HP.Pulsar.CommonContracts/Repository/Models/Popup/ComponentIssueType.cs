﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public enum ComponentIssueType
    {
        Question = 0,
        Issue,
        Suggestion,
        Request,
        ExistingFunction
    }
}
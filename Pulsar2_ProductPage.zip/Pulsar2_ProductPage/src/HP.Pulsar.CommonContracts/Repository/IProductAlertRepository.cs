﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Tiles;
using HP.Pulsar.CommonContracts.TodayPage.Tiles.Models;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IProductAlertRepository
    {
        // Invoked as a toplink in the tile Lead Product Synchronization.
        Task<bool> AddLeadProductExclusionAsync(string exceptionsIds);

        Task<(IReadOnlyList<DeveloperRequestsRemovalFromProductTileDataFromRepo> DataList, int DataCount)> GetDeveloperRequestsRemovalFromProductAsync(int userId, IPaginationModel pagination);

        Task<int> GetDeveloperRequestsRemovalFromProductCountAsync(int userId);

        Task<(IReadOnlyList<LeadProductSynchronizationTileDataFromTile> DataList, int DataCount)> GetLeadProductDiscrepenciesAsync(int userId, int reportId, IPaginationModel pagination);

        Task<int> GetLeadProductDiscrepenciesCountAsync(int userId, int reportId);

        Task<(IReadOnlyList<MissingRequiredMilestonesTileData> DataList, int DataCount)> GetMissingRequiredMilestonesAsync(int userId, IPaginationModel pagination);

        Task<int> GetMissingRequiredMilestonesCountAsync(int userId);

        Task<(IReadOnlyList<MissingSystemBoardIdTileData> DataList, int DataCount)> GetMissingSystemBoardIdAsync(int userId, IPaginationModel pagination);

        Task<int> GetMissingSystemBoardIdCountAsync(int userId);

        Task<(IReadOnlyList<NewComponentReleasedTileDataFromRepo> DataList, int DataCount)> GetNewComponentsReleasedAsync(int userId, bool isPreinstallPM, int? productId, IPaginationModel pagination);

        Task<int> GetNewComponentsReleasedCountAsync(int userId, bool isPreinstallPM);

        Task<(IReadOnlyList<PastDueScheduleItemsTileDataFromRepo> DataList, int DataCount)> GetPastDueScheduleItemsAsync(int userId, IPaginationModel pagination);

        Task<int> GetPastDueScheduleItemsCountAsync(int userId);

        Task<(IReadOnlyList<ProductsMissingPdmTeamMemberTileDataFromTile> DataList, int DataCount)> GetProductsMissingPdmTeamMemberAsync(int userId, IPaginationModel pagination);

        Task<int> GetProductsMissingPdmTeamMemberCountAsync(int userId);

        Task<int> GetSEPMProductCountAsync(int userId);

        Task<(IReadOnlyList<UnassignedTestLeadTileData> DataList, int DataCount)> GetUnassignedTestLeadsAsync(int userId, IPaginationModel pagination);

        Task<int> GetUnassignedTestLeadsCountAsync(int userId);

        Task<bool> TrySyncSelectedProductsAsync(IReadOnlyList<(int productId, int rootId, bool isPulsarProduct)> syncProducts, string userName, string domainName);
    }
}
﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IPartNumberRepository
    {
        Task<IReadOnlyList<BOMStructureModel>> GetBOMStructureModelsAsync(string searchText);

        Task<IReadOnlyList<MaterialDescriptionModel>> GetMaterialDescriptionModelsAsync(string searchText);

        Task<IReadOnlyList<ODMPartInformationModel>> GetODMPartInformationModelsAsync(string searchText);

        Task<IReadOnlyList<SubassembliesModel>> GetSubassembliesModelsAsync(string searchText);

        Task<IReadOnlyList<WhereUsedInformationModel>> GetWhereUsedInformationModelsAsync(string searchText);

        Task<IReadOnlyList<WhereUsedInSpareKitsModel>> GetWhereUsedInSpareKitsModelsAsync(string searchText);
    }
}

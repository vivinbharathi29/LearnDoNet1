﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;
using HP.Pulsar.CommonContracts.Repository.Models.Tiles;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IAdminAlertRepository
    {
        Task<(IReadOnlyList<ApplicationErrorsToInvestigateTileDataFromRepo> DataList, int DataCount)> GetApplicationErrorsToInvestigateAsync(IPaginationModel pagination);

        
        Task<int> GetApplicationErrorsToInvestigateCountAsync();

        Task<(IReadOnlyList<JobsDidNotRunAsScheduledTileDataFromTile> DataList, int DataCount)> GetJobsDidNotRunAsScheduledAsync(int offset, bool isIHubOnly, IPaginationModel pagination);

        Task<int> GetJobsDidNotRunAsScheduledCountAsync(int offset, bool isIHubOnly);

        //This is consumed in Application Errors to Investigate tile.
        Task<ApplicationErrorsFromRepo> GetApplicationErrorsAsyc(int appErrorId);

        //This is consumed in Application Errors to Investigate tile.
        Task<bool> UpdateAllApplicationErrorAsync(int appErrorId, string errorCause);

        //This is consumed in Application Errors to Investigate tile.
        Task<bool> UpdateSelectedApplicationErrorAsync(int appErrorId, string errorCause);
    }
}
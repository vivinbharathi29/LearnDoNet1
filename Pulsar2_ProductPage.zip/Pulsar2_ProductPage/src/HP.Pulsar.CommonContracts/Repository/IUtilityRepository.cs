﻿using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Email;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IUtilityRepository
    {
        Task<(string subject, string body)> GetEmailTemplateAsync(int templateId);

        Task WriteToEmailQueueAsync(EmailMessage emailMessage);
    }
}
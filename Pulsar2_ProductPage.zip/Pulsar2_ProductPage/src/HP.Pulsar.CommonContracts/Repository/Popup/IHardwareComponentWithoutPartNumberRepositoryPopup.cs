﻿using HP.Pulsar.CommonContracts.Repository.Models.Popup;
using System.Threading.Tasks;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IHardwareComponentWithoutPartNumberRepositoryPopup
    {
        Task<ComponentPartNumberDataFromRepo> GetComponentVersionPartNumberAsync(int componentVersionId);

        Task<bool> UpdateComponentVersionPartNumberAsync(int componentVersionId, string partNumber);
    }
}

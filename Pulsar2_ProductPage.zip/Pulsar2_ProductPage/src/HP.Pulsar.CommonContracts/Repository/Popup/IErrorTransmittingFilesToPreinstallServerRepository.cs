﻿using System.Threading.Tasks;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface IErrorTransmittingFilesToPreinstallServerRepository
    {
        Task<bool> UpdateComponentTransferStatusAsync(int componentVersionId);
    }
}
﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface ILeadProductSynchronizationIssueRepository
    {
        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<(IReadOnlyList<ViewExcludedComponentsData> DataList, int DataCount)> GetAllLeadProductExclusionsAsync(int userId, IPaginationModel pagination);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<string> GetComponentRootNameAsync(int componentRootId);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<IReadOnlyList<int>> GetComponentVersionIdsAsync(int rootId, int leadId, int productId, bool isPulsarProduct);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<IReadOnlyList<LeadProductComponentDataFromRepo>> GetLeadProductComponentsAsync(int productId, IReadOnlyList<string> componentVersionIds);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<(int ProductId, string ProductName, int LeadId, string LeadName)> GetLeadProductDetailsAsync(int prodId, bool isPulsarProduct);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<(IReadOnlyList<ViewUsageExceptionsData> DataList, int DataCount)> GetLeadProductExceptionsAsync(int userId, IPaginationModel pagination);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.         
        Task<IReadOnlyList<LeadProductComponentDataFromRepo>> GetLeadProductReleaseComponentsAsync(int productId, int productReleaseId, IReadOnlyList<string> componentVersionIds);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<LeadProductRootExceptionDataFromRepo> GetLeadProductComponentRootExceptionsAsync(int productId, int componentRootId, int productReleaseId);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<(int? ProductId, int? ProductReleaseId)> GetProductReleasesAsync(int productReleaseId);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<IReadOnlyList<ProductComponentDataFromRepo>> GetRequestedComponentsAsync(int leadId, int productId, IReadOnlyList<int> componentsIds, bool isPulsarProduct, IPaginationModel pagination);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.        
        Task<bool> TryRemoveLeadProductExclusionAsyn(IReadOnlyList<int> productLeadRootExceptionsIds);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<bool> ResetLeadProductComponentRootExceptionsAsync(int productId, int componentRootId, string comments, int productReleaseId = 0);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<bool> TryUpdateLeadProductRootExceptionAsync(IReadOnlyList<int> productLeadRootExceptionIds);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<bool> TryUpdateLeadProductVersionExceptionAsync(IReadOnlyList<int> productLeadVersionExceptionIds);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<bool> TryAddLeadProductExceptionsAsync(int productId, IReadOnlyList<int> componentVersionIds, IReadOnlyList<int> imageSyncIds, IReadOnlyList<int> distributionSyncIds, IReadOnlyList<int> noteSyncIds);

        // Invoked for the contextmenu(Edit Usage Exception) in the tile Lead Product Synchronization.
        Task<bool> UpdateLeadProductComponentRootExceptionsAsync(int productId, int componentRootId, bool isImageAll, bool isDistributionAll, bool isNotesAll, string comments, int releaseId);
    }
}
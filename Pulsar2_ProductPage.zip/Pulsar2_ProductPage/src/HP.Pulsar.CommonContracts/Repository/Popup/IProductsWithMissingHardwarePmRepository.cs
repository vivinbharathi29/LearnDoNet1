﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface IProductsWithMissingHardwarePmRepository
    {
        Task<IReadOnlyList<UserDetailsWithProductDataModel>> GetHardwareDetailsForProductAsync(int userId, int productId);

        Task<ProductHardwarePmDataModel> GetProductDetailsAsync(int productId);

        Task<string> GetPmEmailAsync(int hardwarePMId);

        Task<bool> TryUpdateProductVersionHardwarePMAsync(UserDetailsWithProductDataModel productProperties);
    }
}

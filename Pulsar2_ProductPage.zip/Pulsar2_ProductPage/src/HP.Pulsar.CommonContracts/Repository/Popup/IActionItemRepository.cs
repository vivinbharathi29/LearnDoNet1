﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface IActionItemRepository
    {
        Task<ComponentIssueModel> GetActionItemDetailsAsync(int actionItemId);

        Task<ActionItemErrorDetails> GetApplicationErrorDetailsAsync(int applicationErrorId);

        Task<ComponentIssueModel> GetDeliverableIssueDetailsAsync(int actionItemId);

        //TODO Get the Product details from function in Product Page
        Task<IReadOnlyList<(int ProductId, string ProductName, string VersionNumber)>> GetProductGroupsAsync(int componentType);

        //TODO To get the user details from Cache by userid 
        Task<string> GetSubmitterEmailAsync(int userId);

        //Return Integer is the new action item id which is just added in database 
        Task<int> AddDeliverableActionDetailsAsync(ComponentIssueModel componentIssueModel);
        
        Task<bool> UpdateDeliverableActionDetailsAsync(ComponentIssueModel componentIssueModel);

        Task<bool> UpdateApplicationErrorAsync(int applicationErrorId, string reason);
    }
}

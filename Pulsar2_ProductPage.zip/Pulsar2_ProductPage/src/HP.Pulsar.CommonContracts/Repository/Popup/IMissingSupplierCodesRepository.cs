﻿using System.Threading.Tasks;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface IMissingSupplierCodesRepository
    {
        Task<string> GetCategoryNameAsync(int categoryId);

        Task<string> GetSupplierNameAsync(int supplierId);

        Task<bool> AddMissingSupplierCodesAsync(int categoryId, int supplierId, string supplierCode);
    }
}

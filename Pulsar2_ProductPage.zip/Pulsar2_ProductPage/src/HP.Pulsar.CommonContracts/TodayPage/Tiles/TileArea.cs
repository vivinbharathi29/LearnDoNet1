﻿namespace HP.Pulsar.CommonContracts.TodayPage.Tiles
{
    public enum TileArea
    {
        None = 0,
        Marketing,
        RnD,
        Other,
        Service,
        SupplyChain,
    }
}

﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles
{
    public interface ITilePopupRelation
    {
        bool TryGetTileId(int popupId, out int tileId);
    }
}

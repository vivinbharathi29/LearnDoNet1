﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class OpenObservationsAssignedToMeTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public long ObservationId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string State { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Priority { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "40%")]
        public string Summary { get; set; }
    }
}
﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class FeatureNamingOverrideRequestTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "10%", HeaderText = "Feature ID")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "50%", HeaderText = "Reason For Override Request")]
        public string OverrideReason { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%", HeaderText = "Requested By")]
        public string RequestedBy { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%", HeaderText = "Requested Date", Format = "MM/dd/yyyy")]
        public DateTime? DateRequested { get; set; }

        //Hidden filed was to get the Popup page data
        [IgGridColumnAttributes(IsHidden = true)]
        public string RequesterEmail { get; set; }
    }
}

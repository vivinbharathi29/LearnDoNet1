﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class DeveloperRequestsRemovalFromProductTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "10%")]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Release { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "35%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(HeaderText = "Reason", ColumnWidth = "35%")]
        public string DeveloperNotes { get; set; }

        [IgGridColumnAttributes(HeaderText = "Developer", ColumnWidth = "10%")]
        public string DeveloperName { get; set; }

        //Columns are hidden to use the data for Popup window
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentVersionId { get; set; }
    }
}

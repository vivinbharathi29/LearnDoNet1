﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class SpareKitsNotStructuredToFamilyTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Program", ColumnWidth = "20%")]
        public string DotsName { get; set; }
        [IgGridColumnAttributes(HeaderText = "Kit No", ColumnWidth = "20%")]
        public string SpareKitNo { get; set; }
        [IgGridColumnAttributes(HeaderText = "GPG Description", ColumnWidth = "40%")]
        public string Description { get; set; }
        [IgGridColumnAttributes(ColumnWidth = "20%")]
        public string Status { get; set; }
    }
}

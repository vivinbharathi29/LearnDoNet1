﻿using System;
using HP.Pulsar.CommonContracts.EntityStatus;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ComponentQualificationStatusUpdateModel
    {
        public QualificationBatchModeType BatchMode { get; set; }

        public int ComponentId { get; set; }

        public int ComponentReleaseId { get; set; }

        public string ConfigurationRestriction { get; set; }

        public int DcrId { get; set; }

        public bool IsRiskRelease { get; set; }

        public QualificationConfidenceType QualificationConfidenceType { get; set; }

        public QualificationStatusType QualificationStatus { get; set; }

        public string SupplyChainRestriction { get; set; }

        public string TargetNotes { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class MissingAVMarketingTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Days Until", ColumnWidth = "10%")]
        public int DaysUntil { get; set; }

        [IgGridColumnAttributes(HeaderText = "AV SCM/Feature Category", ColumnWidth = "15%")]
        public string FeatureCategory { get; set; }

        [IgGridColumnAttributes(HeaderText = "AV Number", ColumnWidth = "15%")]
        public string AVNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "GPG Description", ColumnWidth = "20%")]
        public string GPGDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "RTP/MR Date", ColumnWidth = "10%", Format = "MM/dd/yyyy")]
        public DateTime? RTPDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "End Of Manufacturing", ColumnWidth = "10%", Format = "MM/dd/yyyy")]
        public DateTime? EndOfManufacturing { get; set; }

        //Passed as an input parameter for the top link operation.
        [IgGridColumnAttributes(IsHidden = true)]
        public int AvDetailId { get; set; }

        //Passed as an input parameter for the top link operation.
        [IgGridColumnAttributes(IsHidden = true)]
        public int BrandId { get; set; }
    }
}
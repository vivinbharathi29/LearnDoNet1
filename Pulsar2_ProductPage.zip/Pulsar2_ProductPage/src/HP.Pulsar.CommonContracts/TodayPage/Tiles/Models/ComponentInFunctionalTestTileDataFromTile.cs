﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ComponentInFunctionalTestTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "8%")]
        public int ComponentVersionId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "24%")]
        public string DeliverableRootName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Version, Revision, Pass", ColumnWidth = "15%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Level", ColumnWidth = "12%")]
        public string BuildLevel { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Developer { get; set; }

        [IgGridColumnAttributes(HeaderText = "Planned Completion", ColumnWidth = "13%")]
        public DateTime PlannedCompletion { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "13%")]
        public string Team { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string TransferPath { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }
    }
}
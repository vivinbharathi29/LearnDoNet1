﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class FeatureRemovedFromPostPRLLockTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product Name", ColumnWidth = "30%")]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(HeaderText = "SCM Name", ColumnWidth = "20%")]
        public string SCMName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature ID", ColumnWidth = "15%")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Full Name", ColumnWidth = "35%")]
        public string FeatureName { get; set; }

        //Hidden filed is used for context menu operation
        [IgGridColumnAttributes(IsHidden = true)]
        public int FeatureActionItemId { get; set; }
    }
}
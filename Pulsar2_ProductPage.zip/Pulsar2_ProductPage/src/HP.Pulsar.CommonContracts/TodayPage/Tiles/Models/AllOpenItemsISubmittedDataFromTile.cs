﻿using System;
using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class AllOpenItemsISubmittedDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Owner { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "13%", HeaderText = "Type")]
        public ComponentIssueActionType ComponentIssueActionType { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%", HeaderText = "Status")]

        public ComponentIssueActionStatus ComponentIssueActionStatus { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%", Format ="MM/dd/yyyy")]
        public DateTime? DueDate { get; set; }
        
        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "15%")]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "30%")]
        public string Summary { get; set; }

        // Passed as an input parameter to the context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public ComponentIssueActionType IssueActionType { get; set; }
    }
}
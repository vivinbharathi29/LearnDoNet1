﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class HelpAndSupportUpcomingReleasesTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "20%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(HeaderText = "Planned", ColumnWidth = "10%")]
        public DateTime? Planned { get; set; }

        [IgGridColumnAttributes(HeaderText = "Languages", ColumnWidth = "40%")]
        public string Languages { get; set; }

        [IgGridColumnAttributes(HeaderText = "Current Workflow Step", ColumnWidth = "20%")]
        public string CurrentWorkflowStep { get; set; }

        //RootId is passed to a page as a querystring when the tile grid row is clicked
        [IgGridColumnAttributes(IsHidden = true)]
        public int RootId { get; set; }
    }
}
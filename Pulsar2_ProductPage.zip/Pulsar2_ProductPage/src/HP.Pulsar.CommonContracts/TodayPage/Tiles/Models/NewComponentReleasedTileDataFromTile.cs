﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class NewComponentReleasedTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "25%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(HeaderText = "Version, Revision, Pass", ColumnWidth = "10%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part Number", ColumnWidth = "10%")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Alert { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "7%")]
        public string Distribution { get; set; }

        [IgGridColumnAttributes(HeaderText = "OS", ColumnWidth = "7%")]
        public string SupportedOS { get; set; }

        [IgGridColumnAttributes(HeaderText = "Target Notes", ColumnWidth = "7%")]
        public string TargetNotes { get; set; }

        [IgGridColumnAttributes(HeaderText = "Images", ColumnWidth = "7%")]
        public string ImageSummary { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "7%")]
        public string Developer { get; set; }

        // Below columns are hidden, because the values are needed for Context menu popups
        [IgGridColumnAttributes(IsHidden = true)]
        public bool IsFusion { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool IsPulsar { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int RootId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int VersionId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int TargetVersionCount { get; set; }
    }
}

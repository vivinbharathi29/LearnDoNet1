﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class FeatureRootRequestsRejectedTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Name", ColumnWidth = "40%")]
        public string FeatureName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Category", ColumnWidth = "20%")]
        public string FeatureCategory { get; set; }

        [IgGridColumnAttributes(HeaderText = "Reason Rejected", ColumnWidth = "10%")]
        public string ReasonRejected { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string UserName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Email { get; set; }
    }
}
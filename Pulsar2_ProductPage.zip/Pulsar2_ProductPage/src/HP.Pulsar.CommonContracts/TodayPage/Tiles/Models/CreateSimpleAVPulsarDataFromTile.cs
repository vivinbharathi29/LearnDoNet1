﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class CreateSimpleAVPulsarDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Feature ID", ColumnWidth = "7%")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "10%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Brand", ColumnWidth = "12%")]
        public string BrandName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature", ColumnWidth = "25%")]
        public string FeatureName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component Linkage", ColumnWidth = "10%")]
        public string ComponentLinkage { get; set; }

        [IgGridColumnAttributes(HeaderText = "SCM Category", ColumnWidth = "10%")]
        public string Category { get; set; }

        [IgGridColumnAttributes(HeaderText = "Requested From PRL/ Platform", ColumnWidth = "16%")]
        public string RequestFrom { get; set; }

        [IgGridColumnAttributes(HeaderText = "Release", ColumnWidth = "10%")]
        public string Release { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int AvCreateId { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductBrandId { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ScmCategoryId { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductVersionId { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int UserId { get; set; }
    }
}
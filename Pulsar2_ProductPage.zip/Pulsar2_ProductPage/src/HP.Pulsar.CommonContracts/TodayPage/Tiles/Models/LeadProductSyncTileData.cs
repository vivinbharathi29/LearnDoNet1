﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class LeadProductSyncTileData : IGridGeneralOutput
    {
        public string Deliverablename { get; set; }

        public string FollowDistribution { get; set; }

        public int FollowerId { get; set; }

        public bool? IsFusionRequirements { get; set; }

        public string LeadDistribution { get; set; }

        public string LeadProduct { get; set; }

        public string LeadProductSynchronizationsSummary { get; set; }

        public string Product { get; set; }

        public int RootId { get; set; }

        public int VersionId { get; set; }

        public string VersionList { get; set; }
    }
}

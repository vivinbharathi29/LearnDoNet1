﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class UnassignedTestLeadTileData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product")]
        public string ProductName { get; set; }

        //Passed as an input paramter for the rowclick event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductRequirementValue { get; set; }

        //Passed as an input paramter for the rowclick event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductVersionId { get; set; }
    }
}
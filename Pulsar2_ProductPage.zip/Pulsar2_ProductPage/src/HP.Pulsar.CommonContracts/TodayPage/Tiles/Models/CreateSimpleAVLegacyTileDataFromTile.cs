﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class CreateSimpleAVLegacyTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int ComponentRootId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Brand", ColumnWidth = "15%")]
        public string BrandName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "45%")]
        public string ComponentName { get; set; }

        [IgGridColumnAttributes(HeaderText = "AV Feature Category", ColumnWidth = "10%")]
        public string AVFeatureCategory { get; set; }

        [IgGridColumnAttributes(HeaderText = "IO Generated", ColumnWidth = "10%")]
        public bool IOGenerated { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int AvCreateId { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductBrandId { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int OverMaxLength { get; set; }

        // Passed as an input parameter for the row click and context menus.
        [IgGridColumnAttributes(IsHidden = true)]
        public int UserId { get; set; }
    }
}
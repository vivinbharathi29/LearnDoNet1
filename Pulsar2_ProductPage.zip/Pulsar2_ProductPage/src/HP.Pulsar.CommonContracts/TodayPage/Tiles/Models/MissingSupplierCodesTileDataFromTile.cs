﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class MissingSupplierCodesTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Category", ColumnWidth = "50%")]
        public string Category { get; set; }

        [IgGridColumnAttributes(HeaderText = "Supplier", ColumnWidth = "50%")]
        public string Supplier { get; set; }

        // CategoryId is passed as the querystring parameter to /excalibur/Deliverable/SupplierCode.asp in OnGridRow click event of Grid Tile
        [IgGridColumnAttributes(IsHidden = true)]
        public int CategoryId { get; set; }

        // SupplierId is passed as the querystring parameter to /excalibur/Deliverable/SupplierCode.asp in OnGridRow click event of Grid Tile
        [IgGridColumnAttributes(IsHidden = true)]
        public int SupplierId { get; set; }
    }
}
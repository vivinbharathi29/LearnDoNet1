﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class MissingBaseUnitSubAssemblyNumbersTileData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Base Unit Feature ID", ColumnWidth = "15%")]
        public int FeatureId { get;  set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "40%")]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(HeaderText = "GPG (40c SA)", ColumnWidth = "45%")]
        public string FeatureName { get;  set; }

        //Columns are hidden to use the data for Popup window
        [IgGridColumnAttributes(IsHidden = true)]
        public int Id { get;  set; }
    }
}

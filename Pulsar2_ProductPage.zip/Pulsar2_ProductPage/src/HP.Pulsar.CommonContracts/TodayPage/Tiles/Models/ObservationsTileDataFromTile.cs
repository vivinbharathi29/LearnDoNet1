﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ObservationsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public long Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "15%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Milestone", ColumnWidth = "25%")]
        public string Milestone { get; set; }

        [IgGridColumnAttributes(HeaderText = "Summary", ColumnWidth = "50%")]
        public string Summary { get; set; }
    }
}
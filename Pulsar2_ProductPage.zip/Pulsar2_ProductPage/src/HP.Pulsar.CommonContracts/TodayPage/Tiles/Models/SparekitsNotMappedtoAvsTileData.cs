﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class SparekitsNotMappedtoAvsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Spare Kit", ColumnWidth = "15%")]
        public string SpareKitNo { get; set; }

        [IgGridColumnAttributes(HeaderText = "Description", ColumnWidth = "35%")]
        public string Description { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Category", ColumnWidth = "25%")]
        public string CategoryName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Products", ColumnWidth = "25%")]
        public string DotsName { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class InactiveComponentsStillTargetedTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "8%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "9%")]
        public string Release { get; set; }

        [IgGridColumnAttributes(HeaderText = "Available Until", ColumnWidth = "8%")]
        public DateTime? EOLDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "35%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "12%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part Number", ColumnWidth = "9%")]
        public string PartNumber { get; set; }

        //Columns are hiddien, used for popup window
        [IgGridColumnAttributes(IsHidden = true)]
        public int RootId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class RejectedAvsPulsarProductTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "11%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "AV Part No.", ColumnWidth = "11%")]
        public string AvNo { get; set; }

        [IgGridColumnAttributes(HeaderText = "Marketing Description", ColumnWidth = "15%")]
        public string MarketingDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Phweb Action", ColumnWidth = "14%")]
        public string PhWebAction { get; set; }

        [IgGridColumnAttributes(HeaderText = "Reason Code", ColumnWidth = "14%")]
        public string ReasonCode { get; set; }

        [IgGridColumnAttributes(HeaderText = "Sub-Reason Code", ColumnWidth = "13%")]
        public string SubReasonCode { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "19%")]
        public string Comments { get; set; }

        // Hidden fields are used to fetch the data for popup 
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductVersionId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int? ProductBrandId { get; set; }
        
        [IgGridColumnAttributes(IsHidden = true)]
        public int AvDetailId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int AvPhWebRejectionItemId { get; set; }
    }
}

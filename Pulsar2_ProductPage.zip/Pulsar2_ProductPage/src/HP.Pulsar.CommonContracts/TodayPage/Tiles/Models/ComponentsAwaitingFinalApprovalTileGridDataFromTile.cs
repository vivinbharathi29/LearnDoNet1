﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ComponentsAwaitingFinalApprovalTileGridDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Version ID", ColumnWidth = "8%")]
        public int VersionId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "8%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "8%")]
        public string Release { get; set; }

        [IgGridColumnAttributes(HeaderText = "Status", ColumnWidth = "8%")]
        public string TestStatus { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "8%")]
        public string Vendor { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "18%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(HeaderText = "HW", ColumnWidth = "10%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "FW", ColumnWidth = "8%")]
        public string Revision { get; set; }

        [IgGridColumnAttributes(HeaderText = "ReV", ColumnWidth = "8%")]
        public string Pass { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "8%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part", ColumnWidth = "8%")]
        public string PartNumber { get; set; }

        //Below Columns are hidden to use values in UpdateStatus Functionality
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableReleaseId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ID { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool? IsPulsarProduct { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ChangeRequestClosedIn7DaysTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Status", ColumnWidth = "10%")]
        public ComponentIssueActionStatus ComponentIssueActionStatus { get; set; }

        [IgGridColumnAttributes(HeaderText = "Closed", ColumnWidth = "10%", Format = "MM/dd/yyyy")]
        public DateTime? ActualDate { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Owner { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Submitter { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "40%")]
        public string Summary { get; set; }
    }
}
﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class HardwareComponentsWithNoPartNumberTileGridDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int ComponentVersionId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "40%")]
        public string Commodity { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model No", ColumnWidth = "10%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%")]
        public string Supplier { get; set; }

        [IgGridColumnAttributes(HeaderText = "Version, Revision, Pass", ColumnWidth = "20%")]
        public string VersionRevisionPass { get; set; }
    }
}

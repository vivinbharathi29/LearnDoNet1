﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ComponentsAwaitingTestReviewTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int ComponentVersionId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "30%")]
        public string ComponentName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Level", ColumnWidth = "20%")]
        public string BuildLevel { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Developer { get; set; }

        [IgGridColumnAttributes(HeaderText = "Planned Completion", ColumnWidth = "10%")]
        public DateTime PlannedCompletionDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Team" , ColumnWidth = "15%")]
        public string FunctionalTestTeam { get; set; }

        //Columns are hidden to use the data for tile operation
        [IgGridColumnAttributes(IsHidden = true)]
        public string TransferPath { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }
    }
}
﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class MyWorkingListTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "PR", ColumnWidth = "5%")]
        public byte? Priority { get; set; }

        [IgGridColumnAttributes(HeaderText = "Order", ColumnWidth = "8%")]
        public int DisplayOrder { get; set; }

        [IgGridColumnAttributes(HeaderText = "Type", ColumnWidth = "10%")]
        public string TypeName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Status", ColumnWidth = "10%")]
        public string StatusName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Milestone", ColumnWidth = "10%")]
        public string Milestone { get; set; }

        [IgGridColumnAttributes(HeaderText = "Target", ColumnWidth = "10%")]
        public string TimeFrame { get; set; }

        [IgGridColumnAttributes(HeaderText = "Summary", ColumnWidth = "35%")]
        public string Summary { get; set; }

        [IgGridColumnAttributes(IsHidden = true, Format = "MM/dd/yyyy")]
        public DateTime? DueDate { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public byte? Type { get; set; }
    }
}

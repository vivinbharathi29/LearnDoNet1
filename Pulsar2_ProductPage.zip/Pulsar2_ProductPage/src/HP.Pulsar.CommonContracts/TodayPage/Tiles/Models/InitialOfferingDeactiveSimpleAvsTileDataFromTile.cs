﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class InitialOfferingDeactiveSimpleAvsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product Version", ColumnWidth = "10%")]
        public string DotsName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Brand", ColumnWidth = "15%")]
        public string BrandName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component ID", ColumnWidth = "10%")]
        public int? DeliverableRootId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Name", ColumnWidth = "25%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(HeaderText = "AV No", ColumnWidth = "10%")]
        public string AvNo { get; set; }

        [IgGridColumnAttributes(HeaderText = "GPG Description", ColumnWidth = "15%")]
        public string GpgDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Category", ColumnWidth = "10%")]
        public string AvFeatureCategory { get; set; }
    }
}

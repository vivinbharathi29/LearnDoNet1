﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class NewComponentRequestDetailsModel
    {
        public string Comment { get; set; }

        public IReadOnlyList<int> ComponentIds { get; set; }

        public IReadOnlyList<int> ComponentReleaseIds { get; set; }

        public NewComponentRequestOperationType ComponentRequestOperation { get; set; }

        public IReadOnlyList<ComponentType> ComponentRootTypes { get; set; }

        public int UserId { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ChangeRequestProposedTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "14%")]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Status { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "12%")]
        public string Owner { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "12%")]
        public string Submitter { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "42%")]
        public string Summary { get; set; }

        //This is used for grid row click operation
        [IgGridColumnAttributes(IsHidden = true)]
        public ComponentIssueType IssueType { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class AllOpenItemsIOwnTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "7%", HeaderText = "ID")]
        public int Id { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "13%", HeaderText = "Type")]
        public ComponentIssueActionType ComponentIssueActionType { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%", HeaderText = "Status")]

        public ComponentIssueActionStatus ComponentIssueActionStatus { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "5%", HeaderText = "Due Date", Format = "MM/dd/yyyy")]
        public DateTime? DueDate { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Owner { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "35%")]
        public string Summary { get; set; }

        //The below property is used in On Grid Row Click event of the Tile to pass value as the query string to a popup.
        [IgGridColumnAttributes(IsHidden = true)]
        public ComponentIssueActionType IssueActionType { get; set; }
    }
}
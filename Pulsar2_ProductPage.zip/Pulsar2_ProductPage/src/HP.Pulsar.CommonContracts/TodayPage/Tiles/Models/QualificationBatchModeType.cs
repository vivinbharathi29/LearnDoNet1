﻿namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class QualificationBatchModeType
    {
        public static readonly QualificationBatchModeType None = new QualificationBatchModeType(0, "None");
        public static readonly QualificationBatchModeType UpdateRelease = new QualificationBatchModeType(1, "Update Release");
        public static readonly QualificationBatchModeType UpdateRiskRelease = new QualificationBatchModeType(2, "Update Risk Release");
        public static readonly QualificationBatchModeType UpdateDcr = new QualificationBatchModeType(3, "Update Dcr");

        private QualificationBatchModeType(int id, string name)
        {
            Name = name;
            Id = id;
        }

        public string Name { get; set; }

        public int Id { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class JobsDidNotRunAsScheduledTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Job ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Job Name", ColumnWidth = "40%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(HeaderText = "Last Run", Format = "MM/dd/yyyy HH:mm:ss", ColumnWidth = "20%")]
        public DateTime? LastRun { get; set; }

        [IgGridColumnAttributes(HeaderText = "Run Interval (hour)", ColumnWidth = "30%")]
        public int? RunEveryHours { get; set; }
    }
}
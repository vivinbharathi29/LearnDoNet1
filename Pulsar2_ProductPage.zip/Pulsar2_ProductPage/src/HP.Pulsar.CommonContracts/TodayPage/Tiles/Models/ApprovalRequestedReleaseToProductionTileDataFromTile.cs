﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ApprovalRequestedReleaseToProductionTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Deliverable Version Id", ColumnWidth = "15%")]
        public int ComponentId { get; set; }

        [IgGridColumnAttributes(HeaderText = "MIT", ColumnWidth = "10%")]
        public ComponentsTestStatus IntegrationTestStatus { get; set; }

        [IgGridColumnAttributes(HeaderText = "ODM", ColumnWidth = "10%")]
        public ComponentsTestStatus OdmTestStatus { get; set; }

        [IgGridColumnAttributes(HeaderText = "WWAN", ColumnWidth = "15%")]
        public ComponentsTestStatus WwanTestStatus { get; set; }

        [IgGridColumnAttributes(HeaderText = "Target", ColumnWidth = "15%")]
        public DateTime? TestDate { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%")]
        public string Vendor { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "20%")]
        public string ComponentVersionName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "20%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part Number", ColumnWidth = "20%")]
        public string PartNumber { get; set; }

        //Hidden fields was used to trasfer data to Popup windows
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableReleaseId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int Id { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string CompositId { get; set; }
    }
}

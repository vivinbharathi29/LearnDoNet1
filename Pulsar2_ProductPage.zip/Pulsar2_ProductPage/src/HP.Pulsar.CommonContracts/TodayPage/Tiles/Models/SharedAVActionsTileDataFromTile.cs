﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class SharedAVActionsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Av No.", ColumnWidth = "8%")]
        public string AvNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "AV Marketing Long <br>Description (100 char)", ColumnWidth = "20%")]
        public string MarketingDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Missing <br>Load to  PHweb", ColumnWidth = "8%")]
        public string MissingLoadToPHweb { get; set; }

        [IgGridColumnAttributes(HeaderText = "SCM(s) Where Used", ColumnWidth = "25%", ColumnCssClass = "contentwrap")]
        public string SCMsWhereUsed { get; set; }

        [IgGridColumnAttributes(HeaderText = "RTP/MR Date", ColumnWidth = "8%")]
        public DateTime RTPDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "PA:AD <br>(Intro) Date", ColumnWidth = "8%")]
        public DateTime PhWebDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Select Availability <br>(SA) Date", ColumnWidth = "8%")]
        public DateTime CPLBlindDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "General Availability <br>(GA) Date", ColumnWidth = "8%")]
        public DateTime GeneralAvailabilityDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "End of Manufacturing <br>(EM) Date", ColumnWidth = "8%")]
        public DateTime RASDiscontinueDate { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Reason { get; set; }

        //Columns are hidden to use the data for row click event
        [IgGridColumnAttributes(IsHidden = true)]
        public int AvDetailId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ReasonId { get; set; }
    }
}

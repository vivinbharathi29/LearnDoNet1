﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class AddAMOFeaturesToASCMTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "20%", HeaderText = "Feature ID")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%")]
        public string Category { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%", HeaderText = "ASCM Category")]
        public string ASCMCategory { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "40%", HeaderText = "Description 1")]
        public string Description1 { get; set; }
    }
}
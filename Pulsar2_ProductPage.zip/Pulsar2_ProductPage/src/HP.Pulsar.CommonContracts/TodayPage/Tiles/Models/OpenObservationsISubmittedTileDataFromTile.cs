﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class OpenObservationsISubmittedTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "7%")]
        public long ObservationId { get; set; }

        [IgGridColumnAttributes(HeaderText = "State", ColumnWidth = "14%")]
        public string State { get; set; }

        [IgGridColumnAttributes(HeaderText = "Pr", ColumnWidth = "5%")]
        public string Priority { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "16%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "20%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(HeaderText = "Owner", ColumnWidth = "8%")]
        public string OwnerName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Summary", ColumnWidth = "24%")]
        public string ShortDescription { get; set; }
    }
}

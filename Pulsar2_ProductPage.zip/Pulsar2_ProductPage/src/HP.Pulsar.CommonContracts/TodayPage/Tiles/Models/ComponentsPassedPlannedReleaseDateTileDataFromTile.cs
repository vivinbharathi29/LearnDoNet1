﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ComponentsPassedPlannedReleaseDateTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "30%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%", Format = "yyyy-MM-dd")]
        public DateTime? PlannedDate { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Developer { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Vendor { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "10%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Current Workflow", ColumnWidth = "10%")]
        public string Location { get; set; }

        //Field Was hidden. Data was used to fetch the data for pop up window
        [IgGridColumnAttributes(IsHidden = true)]
        public int RootId { get; set; }
    }
}

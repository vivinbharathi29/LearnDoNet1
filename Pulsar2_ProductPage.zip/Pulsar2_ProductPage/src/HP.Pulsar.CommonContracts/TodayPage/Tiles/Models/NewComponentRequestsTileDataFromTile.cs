﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class NewComponentRequestsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "7%")]
        public int VersionId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "14%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "35%")]
        public string ComponentName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "8%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Vendor { get; set; }

        [IgGridColumnAttributes(HeaderText = "Requested", ColumnWidth = "8%")]
        public DateTime? CreatedDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Available Until", ColumnWidth = "8%")]
        public DateTime? EndOfLifeDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component Type", ColumnWidth = "10%")]
        public string ComponentTypeName { get; set; }

        // Below columns are hidden, because the values are needed for Context menu popups
        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentReleaseId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int RootId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentVersionId { get; set; }
    }
}

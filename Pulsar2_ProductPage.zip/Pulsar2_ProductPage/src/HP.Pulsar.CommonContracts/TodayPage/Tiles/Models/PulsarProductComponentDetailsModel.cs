﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class PulsarProductComponentDetailsModel
    {
        public int ComponentId { get; set; }

        public string ComponentName { get; set; }

        public ComponentType ComponentType { get; set; }

        public string EmailReceipent { get; set; }

        public string ModelNumber { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public string ProductName { get; set; }

        public string Revision { get; set; }

        public IReadOnlyList<string> SystemTeamEmails { get; set; }

        public string VendorName { get; set; }

        public string Version { get; set; }
    }
}

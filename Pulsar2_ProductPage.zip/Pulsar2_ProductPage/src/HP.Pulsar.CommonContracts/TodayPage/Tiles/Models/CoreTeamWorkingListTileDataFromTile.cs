﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class CoreTeamWorkingListTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int ComponentVersionId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "40%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(HeaderText = "Version", ColumnWidth = "10%")]
        public string ComponentVersion { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Vendor { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "10%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part", ColumnWidth = "10%")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Developer", ColumnWidth = "10%")]
        public string Developer { get; set; }

        //Columns are hidden to use the data to invoke Popup pages
        [IgGridColumnAttributes(IsHidden = true)]
        public int? CategoryId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }
    }
}

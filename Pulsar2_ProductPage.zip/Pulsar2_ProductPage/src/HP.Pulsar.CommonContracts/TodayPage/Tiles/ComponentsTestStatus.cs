﻿namespace HP.Pulsar.CommonContracts.TodayPage.Tiles
{
    public enum ComponentsTestStatus
    {
        None = 0,
        Pass = 1,
        Fail = 2,
        Block = 3
    }
}

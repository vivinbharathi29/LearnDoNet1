﻿namespace HP.Pulsar.CommonContracts.TodayPage.Tiles
{
    public enum TileGroup
    {
        None = 0,
        MyItems,
        ProductAlert
    }
}

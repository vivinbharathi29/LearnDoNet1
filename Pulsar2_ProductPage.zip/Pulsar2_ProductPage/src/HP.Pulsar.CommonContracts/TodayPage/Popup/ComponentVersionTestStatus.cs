﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup
{
    public enum ComponentVersionTestStatus
    {
        Pass = 1,
        Fail,
        Block,
        Watch,
        NotApplicable
    }
}
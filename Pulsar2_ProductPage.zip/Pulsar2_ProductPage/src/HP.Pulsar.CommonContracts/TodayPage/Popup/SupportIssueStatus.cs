﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup
{
    public enum SupportIssueStatus
    {
        New = 1,
        Closed = 2,
        InProgress = 3,
        Blocked = 4,
        RequestUserAction = 5,
        UserActionComplete = 6
    }
}

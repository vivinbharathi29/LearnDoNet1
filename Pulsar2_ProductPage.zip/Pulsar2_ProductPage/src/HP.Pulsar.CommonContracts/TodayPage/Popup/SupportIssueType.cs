﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup
{
    public enum SupportIssueType
    {
        Question = 0,
        Issue = 1,
        Suggestion = 2,
        Request = 3,
        ExistingFunction = 4
    }
}

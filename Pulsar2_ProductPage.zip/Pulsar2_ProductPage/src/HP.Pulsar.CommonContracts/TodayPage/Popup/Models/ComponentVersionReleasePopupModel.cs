﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    // Used in the poupup ComponentRootVersionReleasePopup to Fill Form Control values
    public class ComponentVersionReleasePopupModel : IGridGeneralOutput
    {
        public IReadOnlyList<ComponentVersionReleaseDetailData> ComponentVersionReleases { get; set; }

        public ComponentVersionOperation Operation { get; set; }
    }
}

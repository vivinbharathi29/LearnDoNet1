﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class LeadProductEditUsageExceptionsData : IGridGeneralOutput
    {
        public string CheckedComponentRootExceptionsCss { get; set; }

        public string CheckedComponentVersionExceptionsCss { get; set; }

        public string Comments { get; set; }

        public IReadOnlyList<LeadProductComponentsData> LeadProductComponents { get; set; }

        public string ComponentRootName { get; set; }

        public bool IsSupportNeeded { get; set; }

        public bool IsRootExceptions { get; set; }

        public bool IsProductExceptions { get; set; }

        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public int ComponentRootId { get; set; }

        public int ProductReleaseId { get; set; }

        public string ComponentRootDistributionCheckedCss { get; set; }

        public string ComponentRootImagesCheckedCss { get; set; }

        public string ComponentRootNotesCheckedCss { get; set; }

        public string VersionIds { get; set; }
    }
}
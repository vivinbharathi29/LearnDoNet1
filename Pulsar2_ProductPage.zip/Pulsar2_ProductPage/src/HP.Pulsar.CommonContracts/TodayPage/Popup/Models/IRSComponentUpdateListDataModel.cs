﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class IRSComponentUpdateListDataModel : IGridGeneralOutput
    {
        public IReadOnlyList<string> OSDetails { get; set; }
        public IReadOnlyList<(int ProductId, string ProductName)> ProductDetails { get; set; }
    }
}
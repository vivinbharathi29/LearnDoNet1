﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ApplicationErrorDataModel : IGridGeneralOutput
    {
        public string CopyTo { get; set; }

        public string ErrorFile { get; set; }

        public string ErrorForm { get; set; }

        public int ErrorId { get; set; }

        public int ErrorLine { get; set; }

        public string Referrer { get; set; }

        public string ServerVariable { get; set; }
    }
}
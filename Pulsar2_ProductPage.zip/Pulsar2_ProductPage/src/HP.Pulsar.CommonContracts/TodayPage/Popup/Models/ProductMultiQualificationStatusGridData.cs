﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ProductMultiQualificationStatusGridData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Version Id", ColumnWidth = "10%")]
        public int VersionId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Release", ColumnWidth = "10%")]
        public string Release { get; set; }

        [IgGridColumnAttributes(HeaderText = "Qualification", ColumnWidth = "10%")]
        public string Qualification { get; set; }

        [IgGridColumnAttributes(HeaderText = "Pilot", ColumnWidth = "10%")]
        public string PilotStatusName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Accessory", ColumnWidth = "10%")]
        public string AccessoryStatusName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Available Until", ColumnWidth = "10%")]
        public string AvailableUntil { get; set; }

        [IgGridColumnAttributes(HeaderText = "Vendor", ColumnWidth = "10%")]
        public string VendorName { get; set; }

        [IgGridColumnAttributes(HeaderText = "HWFWRev", ColumnWidth = "10%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "10%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part", ColumnWidth = "10%")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Comments", ColumnWidth = "10%")]
        public string PilotNotes { get; set; }

        // Below are hidden to use it for popup save functionality
        [IgGridColumnAttributes(IsHidden = true)]
        public int Id { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableReleaseId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string StatusName { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class BatchUpdateDcrInfoModel : IGridGeneralOutput
    {
        // Which are separated by comma
        public string Ids { get; set; }

        public string postUrl { get; set; }
    }
}

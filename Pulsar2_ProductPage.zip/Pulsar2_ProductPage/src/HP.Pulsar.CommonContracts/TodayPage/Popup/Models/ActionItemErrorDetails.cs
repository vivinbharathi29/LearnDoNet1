﻿using System;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ActionItemErrorDetails
    {
        public int ErrorColumn { get; set; }

        public DateTime ErrorDateTime { get; set; }

        public string ErrorDescription { get; set; }

        public string ErrorFile { get; set; }

        public int ErrorLine { get; set; }

        public string RequestQueryString { get; set; }

        public string UserAlias { get; set; }
    }
}

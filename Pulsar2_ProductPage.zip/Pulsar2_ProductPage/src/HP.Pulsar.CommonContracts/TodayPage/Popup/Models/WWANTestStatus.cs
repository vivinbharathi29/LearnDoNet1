﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum WWANTestStatus
    {
        TBD = 0,
        Passed = 1,
        Failed = 2,
        Blocked = 3
    }
}
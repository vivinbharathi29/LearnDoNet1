﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class TestLeadStatusLegacyAndPulsarPostData
    {
        public ComponentVersionField ComponentVersionFieldId { get; set; }

        public string DeveloperTestNotes { get; set; }

        public int StatusId { get; set; }

        public IReadOnlyList<TestLeadStatusProductDetailsData> TestLeadStatusProductDetails { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }
    }
}
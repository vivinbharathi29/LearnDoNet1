﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class AddAMOFeaturesToASCMData : IGridGeneralOutput
    {
        public int FeatureId { get; set; }
        public string GetAllAmoSkuTypesUrl { get; set; }
        public string GetAllProductLinesUrl { get; set; }
        public string GetFeatureLocalizationsUrl { get; set; }
    }

    public class ASCMSelectOptionModel {
        public int Id { get; set; }
        public string Text { get; set; }
    }
}

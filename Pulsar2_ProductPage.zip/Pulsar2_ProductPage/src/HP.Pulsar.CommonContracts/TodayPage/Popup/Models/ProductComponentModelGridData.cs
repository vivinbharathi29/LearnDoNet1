﻿using System;
using System.Collections.Generic;
using System.Text;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{  
    //This Grid Model is used by DeveloperApprovalPopup  
    public class ProductComponentModelGridData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "15%")]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Vendor { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Deliverable { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "20%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part", ColumnWidth = "15%")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Comments", ColumnWidth = "20%")]
        public string DeveloperTestNotes { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string Version { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int Id { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string Name { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductComponentReleaseId { get; set; }
    }
}

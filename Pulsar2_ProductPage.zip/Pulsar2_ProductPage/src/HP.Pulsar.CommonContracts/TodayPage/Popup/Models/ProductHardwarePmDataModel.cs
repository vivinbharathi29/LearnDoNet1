﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ProductHardwarePmDataModel
    {
        public int CommercialHardwarePMId { get; set; }

        public int GraphicsControllerPMId { get; set; }

        public int ProcessorPMId { get; set; }

        public string ProductName { get; set; }

        public int VideoMemoryPMId { get; set; }
    }
}

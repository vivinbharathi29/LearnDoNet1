﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ComponentVersionTestStatusModelForPulsarProduct : IGridGeneralOutput
    {
        public ComponentVersionField FieldId { get; set; }

        public int ProudctId { get; set; }

        public int ReleaseId { get; set; }

        public IReadOnlyList<ComponentVersionReleaseData> Releases { get; set; }

        public ComponentTestStatusDetails TestStatusDetail { get; set; }

        public ComponentVersionProperty VersionDetail { get; set; }

        public int VersionId { get; set; }
    }
}
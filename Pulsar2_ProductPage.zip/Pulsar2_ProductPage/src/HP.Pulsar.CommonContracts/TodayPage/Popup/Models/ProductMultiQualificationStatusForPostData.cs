﻿using System;
using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    // Used in the poupup ProductMultiQualificationStatusPopup to Save User Inputs to DB
    public class ProductMultiQualificationStatusForPostData
    {
        public string Comments { get; set; }

        public short Confidence { get; set; }

        public IReadOnlyList<int> ProductDeliverableIds { get; set; }

        public DateTime? QualificationDate { get; set; }

        public short RiskRelease { get; set; }

        public int StatusId { get; set; }

        public int UserId { get; set; }

        public string UserNameWithDomain { get; set; }
    }
}

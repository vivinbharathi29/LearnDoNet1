﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ComponentVersionProperty
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string FirmwareVersion { get; set; }

        public string HardwareVersion { get; set; }

        public string ModelNumber { get; set; }

        public string PartNumber { get; set; }

        public string ReleaseLinkName { get; set; }

        public string Revision { get; set; }

        public int ComponentRootId { get; set; }

        public string VendorName { get; set; }
    }
}
﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class QualificationStatusGridData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Number", ColumnWidth = "30%")]
        public string Subassembly { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "70%")]
        public string Name { get; set; }

        // Below are hidden to use it for popup save functionality
        [IgGridColumnAttributes(IsHidden = true)]
        public string CheckboxStatus { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool IsActive { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int Id { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool IsSelected { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int RealRootId { get; set; }      

        [IgGridColumnAttributes(IsHidden = true)]
        public int Selected { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int SubassemblyCount { get; set; }    

        [IgGridColumnAttributes(IsHidden = true)]
        public bool ShowMissingSubAssembly { get; set; }
    }
}

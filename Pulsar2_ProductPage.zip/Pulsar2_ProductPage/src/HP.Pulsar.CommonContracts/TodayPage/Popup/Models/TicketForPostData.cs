﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class TicketForPostData
    {
        public int CategoryId { get; set; }
        public string Details { get; set; }
        public int OwnerId { get; set; }
        public int ProjectId { get; set; }
        public string Resolution { get; set; }
        public int StatusId { get; set; }
        public int SubmitterId { get; set; }
        public string Summary { get; set; }
        public int TicketId { get; set; }
        public SupportIssueType TicketType { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class DcrWorkflowMilestonesStatusDataModel : IGridGeneralOutput
    {
        [IgGridColumnAttributes(IsHidden = true)]
        public int DefinitionID { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int WorkflowId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int MilestoneOrder { get; set; }

        [IgGridColumnAttributes]
        public string Milestone { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string SystemTeamRoleId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string Name { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string Description { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string CreatedBy { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public DateTime? CreateDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Status")]
        public string StatusDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Assigned To")]
        public string AssignedTo { get; set; }

        [IgGridColumnAttributes(HeaderText = "Comments")]
        public string Comment { get; set; }
    }
}

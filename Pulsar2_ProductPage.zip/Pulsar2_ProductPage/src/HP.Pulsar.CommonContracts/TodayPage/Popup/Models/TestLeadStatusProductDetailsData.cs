﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class TestLeadStatusProductDetailsData
    {
        public int ComponentId { get; set; }

        public int ProductDeliverableReleaseId { get; set; }

        public int ProductId { get; set; }

        public int VersionId { get; set; }
    }
}
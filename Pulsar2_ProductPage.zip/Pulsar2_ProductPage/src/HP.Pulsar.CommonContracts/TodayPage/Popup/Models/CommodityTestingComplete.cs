﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum CommodityTestingComplete
    {
        None = 0,
        Passed,
        Failed,
        Blocked
    }
}
﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class HardwareTypePmUsersModel
    {
        public IReadOnlyDictionary<int, string> CommercialHardwarePMs { get; set; }

        public IReadOnlyDictionary<int, string> GraphicsControllerPMs { get; set; }

        public IReadOnlyDictionary<int, string> ProcessorPMs { get; set; }

        public IReadOnlyDictionary<int, string> VideoMemoryPMs { get; set; }
    }
}

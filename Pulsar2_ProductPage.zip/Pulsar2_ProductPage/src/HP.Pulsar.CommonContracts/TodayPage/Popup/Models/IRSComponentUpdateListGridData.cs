﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class IRSComponentUpdateListGridData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "IRS Part Number", ColumnWidth = "10%")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Excalibur ID", ColumnWidth = "10%")]
        public int ComponentVersionId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Name", ColumnWidth = "10%")]
        public string ComponentName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Version", ColumnWidth = "10%")]
        public string ComponentVersionName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Revision { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "7%")]
        public string Pass { get; set; }

        [IgGridColumnAttributes(HeaderText = "Issues", ColumnWidth = "10%")]
        public string TransferStatus { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Action { get; set; }

        [IgGridColumnAttributes(HeaderText = "Replace", ColumnWidth = "10%")]
        public string PreviousVersionPartNumbers { get; set;}

        //Indicating whether or not a Windows7 version is supported. Displays 'X' if supported.
        [IgGridColumnAttributes(HeaderText = "Windows 7", ColumnWidth = "8%")]
        public string Windows7Capable { get; set; }

        //Indicating whether or not a Windows 8 version is supported. Displays 'X' if supported.
        [IgGridColumnAttributes(HeaderText = "Windows 8", ColumnWidth = "8%")]
        public string Windows8Capable { get; set; }

        //Indicating whether or not a Windows 8.1 version is supported. Displays 'X' if supported.
        [IgGridColumnAttributes(HeaderText = "Windows 8.1", ColumnWidth = "9%")]
        public string Windows81Capable { get; set; }

        //Indicating whether or not a Windows 10 version is supported. Displays 'X' if supported.
        [IgGridColumnAttributes(HeaderText = "Windows 10", ColumnWidth = "8%")]
        public string Windows10Capable { get; set; }

        [IgGridColumnAttributes(HeaderText = "Target Notes", ColumnWidth = "10%")]
        public string TargetNotes { get; set; }

        [IgGridColumnAttributes(HeaderText = "Image Summary", ColumnWidth = "10%")]
        public string ImageSummary { get; set; }
    }
}

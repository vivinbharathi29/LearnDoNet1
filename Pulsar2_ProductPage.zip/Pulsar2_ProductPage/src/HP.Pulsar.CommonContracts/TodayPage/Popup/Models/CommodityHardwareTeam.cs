﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum CommodityHardwareTeam
    {
        ProgramCoordinator = 0,
        PlatformDevelopment,
        Processor,
        Comm,
        GraphicsController,
        VideoMemory,
        SuperUser
    }
}
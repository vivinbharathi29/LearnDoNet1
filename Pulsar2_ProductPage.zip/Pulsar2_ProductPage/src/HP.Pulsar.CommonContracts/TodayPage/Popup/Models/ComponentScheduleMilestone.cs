﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum ComponentScheduleMilestone
    {
        Unknown = 0,
        CoreTeam,
        DeveloperReview,
        Development,
        EngDevelopment,
        EngineeringDevelopment,
        Evaluation,
        FunctionalTest,
        PendingPlatformUse,
        PM,
        PreinstallPackaging,
        ReleaseTeam,
        TestReview
    }
}

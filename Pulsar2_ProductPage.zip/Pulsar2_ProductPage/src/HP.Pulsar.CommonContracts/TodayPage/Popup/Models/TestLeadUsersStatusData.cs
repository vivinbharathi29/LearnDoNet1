﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class TestLeadUsersStatusData : IGridGeneralOutput
    {
        public HardwareIntegrationTestStatus HardwareIntegrationTestStatus { get; set; }

        public bool IsOdmTestLead { get; set; }

        public bool IsSeTestLead { get; set; }

        public bool IsWwanTestLead { get; set; }

        public bool IsDevTestLead { get; set; }

        public ODMTestStatus ODMTestStatus { get; set; }

        public WWANTestStatus WWANTestStatus { get; set; }
    }
}
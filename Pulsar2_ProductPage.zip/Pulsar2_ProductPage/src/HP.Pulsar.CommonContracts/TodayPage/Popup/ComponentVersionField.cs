﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup
{
    public enum ComponentVersionField
    {
        None = 0,
        SeTest = 1,
        OdmTest = 2,
        WwanTest = 3,
        DeveloperTest = 4
    }
}

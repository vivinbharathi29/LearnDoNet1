﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup
{
    public interface IPopupContentModel : IPopupRootContentModel
    {
    }
}
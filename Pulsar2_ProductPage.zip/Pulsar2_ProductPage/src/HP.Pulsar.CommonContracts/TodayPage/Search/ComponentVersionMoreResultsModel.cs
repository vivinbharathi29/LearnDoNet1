﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search
{
    public class ComponentVersionMoreResultModel : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID")]
        public int ComponentVersionId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component Version Name")]
        public string ComponentVersionName { get; set; }

        [IgGridColumnAttributes]
        public string Version { get; set; }

        [IgGridColumnAttributes]
        public string Revision { get; set; }

        [IgGridColumnAttributes]
        public string Pass { get; set; }

        [IgGridColumnAttributes(HeaderText = "HP Part Number")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model Number")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes]
        public string Workflow { get; set; }

        //Iggrid bool is true or false, so to display 'Yes' or 'No' changed data type as string
        [IgGridColumnAttributes(HeaderText = "Deactivated")]
        public string IsDeactivated { get; set; }

        [IgGridColumnAttributes(HeaderText = "Open In New Tab")]
        public string Url { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public DateTime? DisabledDate { get; set; }
    }
}

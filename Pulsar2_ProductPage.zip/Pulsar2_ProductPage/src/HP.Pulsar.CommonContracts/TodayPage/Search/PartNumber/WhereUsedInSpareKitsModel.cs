﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber
{
    public class WhereUsedInSpareKitsModel : IPartNumberType
    {
        [IgGridColumnAttributes(HeaderText = "Spare Kit Part No", Template = "<a href='#' onclick='searchAsKeyword(\"${SpareKitPartNumber}\")' />${SpareKitPartNumber}</a>")]
        public string SpareKitPartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Spare Kit Desc")]
        public string SpareKitDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Spare Kit Category")]
        public string SpareKitCategory { get; set; }
    }
}

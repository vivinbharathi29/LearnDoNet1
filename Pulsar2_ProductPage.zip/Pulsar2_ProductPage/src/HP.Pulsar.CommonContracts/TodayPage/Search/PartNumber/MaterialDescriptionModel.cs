﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber
{
    public class MaterialDescriptionModel : IPartNumberType
    {
        [IgGridColumnAttributes(HeaderText = "Number", Template = "<a href='#' onclick='searchAsKeyword(\"${PartNumber}\")'/>${PartNumber}</a>")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "GPG Description")]
        public string GPGDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Material Type")]
        public string MaterialType { get; set; }

        [IgGridColumnAttributes()]
        public string Division { get; set; }

        [IgGridColumnAttributes(HeaderText = "Revision Level")]
        public string RevisionLevel { get; set; }

        [IgGridColumnAttributes(HeaderText = "Cross Plant Status")]
        public string CrossPlantStatus { get; set; }

        [IgGridColumnAttributes(HeaderText = "UPC/JAN")]
        public string Ian_UPC { get; set; }
    }
}

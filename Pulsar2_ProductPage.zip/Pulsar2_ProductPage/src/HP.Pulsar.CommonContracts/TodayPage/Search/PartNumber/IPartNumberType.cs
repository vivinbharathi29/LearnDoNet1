﻿namespace HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber
{
    public interface IPartNumberType
    {
    }
}

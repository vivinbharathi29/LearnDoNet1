﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber
{
    public interface IPartNumberSearchEngine
    {
        Task<IReadOnlyList<BOMStructureModel>> SearchBOMStructureAsync(string searchText, string userAliasWithDomain);

        Task<IReadOnlyList<MaterialDescriptionModel>> SearchMaterialDescriptionAsync(string searchText, string userAliasWithDomain);

        Task<IReadOnlyList<ODMPartInformationModel>> SearchODMPartInformationAsync(string searchText, string userAliasWithDomain);

        Task<IReadOnlyList<SubassembliesModel>> SearchSubassembliesAsync(string searchText, string userAliasWithDomain);

        Task<IReadOnlyList<WhereUsedInformationModel>> SearchWhereUsedInformationAsync(string searchText, string userAliasWithDomain);

        Task<IReadOnlyList<WhereUsedInSpareKitsModel>> SearchWhereUsedInSpareKitsAsync(string searchText, string userAliasWithDomain);
    }
}

﻿namespace HP.Pulsar.CommonContracts.TodayPage.Search
{
    public enum FeatureMoreResultComponentLinkage
    {
        NotApplicable = -4,
        NotApplicableCombo = -3,
        LinkPending = -2,
        LinkRejected = -1,
        LinkRequested = 0,
        Linked = 1
    }
}

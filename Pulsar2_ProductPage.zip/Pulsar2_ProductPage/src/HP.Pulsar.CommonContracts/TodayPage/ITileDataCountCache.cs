﻿namespace HP.Pulsar.CommonContracts.TodayPage
{
    public interface ITileDataCountCache
    {
        void SetCount(string userAliasWithDomainName, int tileId, int count);

        bool TryGetCount(string userAliasWithDomainName, int tileId, out int count);
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Application;

namespace HP.Pulsar.CommonContracts.TodayPage.Favorites
{
#pragma warning disable CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    public class UserFavorite
#pragma warning restore CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    {
        public UserFavoriteType FavoriteType { get; set; }

        public int ItemId { get; set; }

        public string ItemLink { get; set; }

        public string ItemName { get; set; }

        public MenuItemDisplayMode MenuItemDisplayMode { get; set; }

        public int Sequence { get; set; }

        // TODO Bruce: cannot be here. Need to find a better place.
        // Equal must be override to use in PulsarUser class.
        public override bool Equals(object obj)
        {
            if (obj is UserFavorite target)
            {
                return target.ItemId == ItemId && target.FavoriteType == FavoriteType;
            }

            return false;
        }
    }
}

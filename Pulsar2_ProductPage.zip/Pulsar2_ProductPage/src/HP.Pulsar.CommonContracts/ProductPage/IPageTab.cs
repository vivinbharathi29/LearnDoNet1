﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HP.Pulsar.CommonContracts.ProductPage
{
    public interface IPageTab
    {
        public int Id { get; }

        public string Name { get; }
    }
}

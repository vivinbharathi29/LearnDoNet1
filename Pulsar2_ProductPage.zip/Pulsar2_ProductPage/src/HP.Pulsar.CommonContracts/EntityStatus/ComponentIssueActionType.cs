﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum ComponentIssueActionType
    {
        None = 0,
        Issue = 1,
        Action = 2,
        ChangeRequest = 3,
        StatusNote = 4,
        ImprovementOpportunity = 5,
        TestRequest = 6,
        SpdmEcr = 7
    }
}
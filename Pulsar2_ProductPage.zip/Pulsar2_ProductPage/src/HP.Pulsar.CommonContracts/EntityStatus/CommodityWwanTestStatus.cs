﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum CommodityWwanTestStatus
    {
        None = 0,
        Passed,
        Failed,
        Blocked,
        Watch,
        NA
    }
}
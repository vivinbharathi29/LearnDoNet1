﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    //TODO : Karthi, once HP.Pulsar.CommonContracts.TodayPage.Popup.Models.DevelopmentCenter reference removed then  this can be renamed as DevelopmentCenter
    public enum DevelopmentCenters
    {
        HoustonBNB = 1,
        TaiwanConsumer,
        TaiwanBNB,
        SingaporeBNB,
        BrazilBNB,
        Mobility,
        SanDiego,
        NoDevCenter
    }
}

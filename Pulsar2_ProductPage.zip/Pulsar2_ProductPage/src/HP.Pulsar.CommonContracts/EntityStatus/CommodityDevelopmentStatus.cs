﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum CommodityDevelopmentStatus
    {
        TBD = 0,
        ApprovedForTesting,
        NotApprovedForTesting,
        ApprovedForProduction,
        NotApprovedForProduction,
        AwaitingDevelopmentTeamApproval
    }
}
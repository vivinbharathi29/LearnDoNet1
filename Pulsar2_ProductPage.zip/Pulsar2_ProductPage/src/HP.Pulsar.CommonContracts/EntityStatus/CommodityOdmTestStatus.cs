﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum CommodityOdmTestStatus
    {
        None = 0,
        Passed,
        Failed,
        Blocked,
        Watch,
        NA
    }
}
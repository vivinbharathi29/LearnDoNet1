﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum ChangeRequestType
    {
        Issue = 1,
        ActionItem = 2,
        ChangeRequest = 3,
        Note = 4,
        Improvement = 5,
        TestRequest = 6,
        ServiceECR = 7
    }
}

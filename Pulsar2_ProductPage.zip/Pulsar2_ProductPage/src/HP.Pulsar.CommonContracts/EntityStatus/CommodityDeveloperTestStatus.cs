﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum CommodityDeveloperTestStatus
    {
        None = 0,
        Passed,
        Failed,
        Blocked,
        Watch,
        NA
    }
}
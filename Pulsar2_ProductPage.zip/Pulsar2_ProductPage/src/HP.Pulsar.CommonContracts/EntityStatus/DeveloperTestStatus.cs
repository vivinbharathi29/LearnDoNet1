﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum DeveloperTestStatus
    {
        TBD = 0,
        ApprovedforProduction,
        NotApprovedforProduction        
    }
}
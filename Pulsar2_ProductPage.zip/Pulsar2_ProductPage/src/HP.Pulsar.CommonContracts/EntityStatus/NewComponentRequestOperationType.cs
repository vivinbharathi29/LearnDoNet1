﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum NewComponentRequestOperationType
    {
        None = 0,
        Accepted,
        Rejected,
        RejectedRemovedSupport,
    }
}

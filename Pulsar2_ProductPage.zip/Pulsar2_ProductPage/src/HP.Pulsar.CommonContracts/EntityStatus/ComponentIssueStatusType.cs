﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum ComponentIssueStatusType
    {
        Open = 1,
        Closed = 2,
        Blocked = 3,
    }
}

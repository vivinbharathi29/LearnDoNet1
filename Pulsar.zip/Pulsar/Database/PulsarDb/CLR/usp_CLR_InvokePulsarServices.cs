using System;
using System.Data.SqlTypes;
using System.IO;
using System.Net;
using System.Xml;

public partial class StoredProcedures
{
	[Microsoft.SqlServer.Server.SqlProcedure(Name = "usp_CLR_InvokePulsarServices")]
	public static void InvokePulsarServices(SqlString uri, out SqlInt32 returnValue, out SqlString message, out SqlString severity, out SqlString customStatus, out SqlString rawResponse)
	{
		rawResponse = "EMPTY_RESPONSE";
		message = string.Empty;
		severity = string.Empty;
		customStatus = string.Empty;

		try
		{
            var req = (HttpWebRequest)WebRequest.Create(Convert.ToString(uri));

			req.Credentials = CredentialCache.DefaultNetworkCredentials;
			req.UserAgent = "SQL CLR PulsarDb.InvokePulsarServices";
			req.Accept = "application/xml";  //so webAPI will return XML

			using (WebResponse resp = req.GetResponse())
			using (Stream dataStream = resp.GetResponseStream())
			using (StreamReader rdr = new StreamReader(dataStream))
			{
				//rawResponse is an output parameter
				rawResponse = (SqlString)rdr.ReadToEnd();
			}
			var xmldoc = new XmlDocument();
			xmldoc.LoadXml((string)rawResponse);

			//if response is not well formed will throw exception (rawResponse will be returned to caller)
			XmlNodeList nodeList = xmldoc.GetElementsByTagName("ReturnValue");
			if (nodeList.Count == 0) //this is the only mandatory value
				throw new Exception("Could not find element \"ReturnValue\" in the service response.");

			returnValue = int.Parse(nodeList[0].InnerText);

			nodeList = xmldoc.GetElementsByTagName("Message");
			if (nodeList.Count != 0)
				message = nodeList[0].InnerText;

			nodeList = xmldoc.GetElementsByTagName("Severity");
			if (nodeList.Count != 0)
				severity = nodeList[0].InnerText;

			nodeList = xmldoc.GetElementsByTagName("CustomStatus");
			if (nodeList.Count != 0)
				customStatus = nodeList[0].InnerText;

		}
		catch (Exception ex)
		{
			returnValue = 1;
			message = "An unexpected error occured in PulsarDb.InvokePulsarServices ["+ Convert.ToString(uri) + "]\n(Check also 'rawResponse' value):\n" + ex.ToString();
		}
		return;
	}
}

using System;
using System.Data.SqlClient;
using System.Data.SqlTypes;

public partial class StoredProcedures

{
    [Microsoft.SqlServer.Server.SqlProcedure(Name = "usp_CLR_XROSTBulkCopy")]
    public static void XROSTBulkCopy(int batchId, string sourceTableName, string destTableName, string destConnStr)
    {        
      
        using (var cn = new SqlConnection("context connection=true"))
        using (var cmd = cn.CreateCommand())
        {

            cmd.Parameters.AddWithValue("@batchid", batchId);
            cmd.CommandText = @"SELECT DISTINCT [SRP_KMAT],[EZC_KMAT],[Product_Name],[Brand],[Series],[Chassis],[Generation],[Feature_Code_Name],
		                        [Category],[Subcategory],[Material_Part_Number],[Is_Localized],[Is_Shared],[GPG_Description],[Marketing_Description_40_Characters],
		                        [Marketing_Description_100_Characters],[SA_Date],[GA_Date],[EM_Date],[ES_Date],[Global_Series_EOL_Date],
		                        [Category_Rules],[Subcategory_Rules],[Material_Rules],[Category_Manufacturing_Notes],[Subcategory_Manufacturing_Notes],
                                [Material_Manufacturing_Notes],[Cycle_Release],[Material_PL], [IDS],[IDS_CTO],[RCTO],[BSAM_B],[PM_Revision_of_Publication],
                                [SCM_Revision_of_Publication],[Delivery_Type],[Batch_ID] FROM " + sourceTableName;
            cn.Open();

            using (var dr = cmd.ExecuteReader())
            {
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destConnStr))
                {
                    bulkCopy.BulkCopyTimeout = 180;
                    bulkCopy.DestinationTableName = destTableName;
                    bulkCopy.WriteToServer(dr);
                }
            }

        }           
    }
}

﻿
CREATE FUNCTION [dbo].[fnGetProductName] 
(
	@p_ProductId int
)
RETURNS varchar(200)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result varchar(200)

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = pv.dotsname
	from ProductVersion pv WITH (NOLOCK)
	where pv.id = @p_ProductId
	-- Return the result of the function
	RETURN @Result

END


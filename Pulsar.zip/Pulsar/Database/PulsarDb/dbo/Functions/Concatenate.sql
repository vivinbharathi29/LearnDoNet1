﻿CREATE AGGREGATE [dbo].[Concatenate](@input NVARCHAR (max))
    RETURNS NVARCHAR (max)
    EXTERNAL NAME [StringUtilities].[Microsoft.Samples.SqlServer.Concatenate];


﻿CREATE function [dbo].[ufn_GetComponentVersion_ExportCompliance]
    (@p_VersionID	INT = NULL,
    @bol_Cursor		BIT
	)
	
	RETURNS varchar(Max)
	
AS
BEGIN

	Declare @lang as varchar(Max)
	Declare @TextString as varchar(Max)
	Declare @Rec_Count as int
	Select @TextString = ''
	Select @Rec_Count = 0

	Select @Rec_Count = COUNT(*)
	From [dbo].[ComponentVersion_ExportCompliance] CV_EC (NoLock) inner join SosdExportLocation lang on CV_EC.CountryId = lang.ID
	Where ComponentVersionID = @p_VersionID  and CV_EC.[disabled] is null

	if (@bol_Cursor=1)
		Begin
			--if @Rec_Count > 0
				--begin
					--Cursor for the XML Tags ********************************************************************************************
					DECLARE GetCompVer_ExpComp_CURSOR CURSOR
					FOR
						Select REPLACE(l.location, 'USA', 'UnitedStates') lang
						From ComponentVersion_ExportCompliance e, SosdExportLocation l
						Where e.countryid = l.id
						and e.componentversionid = @p_VersionID
						and e.[disabled] is null
						 
					open GetCompVer_ExpComp_CURSOR

					FETCH NEXT FROM GetCompVer_ExpComp_CURSOR Into @lang
					WHILE (@@fetch_status <> -1)
						BEGIN
							If (@@fetch_status <> -2)
								BEGIN
									Select @TextString = @TextString + '<ExportCompliance ExportCompliantID="' + @lang + '" />' + CHAR(13) + CHAR(10)
								END
							FETCH NEXT FROM GetCompVer_ExpComp_CURSOR Into @lang
						END
					DEALLOCATE GetCompVer_ExpComp_CURSOR	
					--***********************************************************************************************************
				--end
			--else
				--Select @TextString = '<ExportCompliance ExportCompliantID="All" />'
		end
	Else 
		Begin
			--if @Rec_Count > 0
			--	begin
					Select @TextString = 'ExportCompliantIDs=' + '"' + Replace(dbo.Concatenate(l.Location), 'USA', 'UnitedStates') + '"' -- AS lang
						From ComponentVersion_ExportCompliance e, SosdExportLocation l
						Where e.countryid = l.id
						and e.componentversionid = @p_VersionID
						and e.[disabled] is null
			--	end
			--else
			--	Select @TextString = 'ExportCompliantIDs="All"'
		end

	Return @TextString
End
GO
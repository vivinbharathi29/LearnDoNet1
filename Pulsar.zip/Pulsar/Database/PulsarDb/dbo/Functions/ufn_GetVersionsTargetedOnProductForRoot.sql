﻿

CREATE FUNCTION [dbo].[ufn_GetVersionsTargetedOnProductForRoot] (@p_DeliverableRootID INT, @p_ProductversionID INT)
RETURNS INT
AS
BEGIN

DECLARE @v_Count int
SELECT @v_Count = COUNT(1)
FROM 
	Product_Deliverable pd WITH(NOLOCK) join
	DeliverableVersion v WITH(NOLOCK) on v.ID = pd.deliverableversionid
WHERE v.deliverablerootid = @p_DeliverableRootID
and pd.productversionid = @p_ProductversionID
and targeted=1
RETURN @v_Count

END




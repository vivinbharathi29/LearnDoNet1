﻿
CREATE FUNCTION [dbo].[ufn_GetMinIrsModuleIdByDescription] (@p_GpgDescription VARCHAR(100), @p_GroupId INT)
RETURNS int
WITH EXECUTE AS CALLER
AS
-- place the body of the function here
BEGIN
	DECLARE @IrsModuleId INT
	SELECT @IrsModuleId = MIN(NULLIF(ModuleID, 0)) FROM irs_module WITH(NOLOCK) WHERE Description = @p_GpgDescription AND GroupId = @p_GroupId
	AND statusid = (select statusid from IRS_Status where StatusType=8 and constant='MOL_MODULE_ACTIVE')
	
	IF (@IrsModuleId IS NULL) BEGIN
		RETURN 0
	END

    RETURN(@IrsModuleId)
END


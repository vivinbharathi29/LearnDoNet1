﻿CREATE FUNCTION [dbo].[ufn_GetOSList4ProductDropTable] (@p_ProductDropID INT)  
RETURNS @t_OSList table(v_OSList VARCHAR(8000))
AS  
BEGIN  
  
DECLARE @v_OSList VARCHAR(8000), @FusionRequirements bit  
  
SELECT @FusionRequirements = isnull(FusionRequirements,0) FROM productversion pv WITH(NOLOCK)  
INNER JOIN productversion_productdrop pvpd WITH(NOLOCK) on pv.id = pvpd.productversionid  
WHERE pvpd.productdropid = @p_ProductDropID  
  
IF (@FusionRequirements = 0)  
 SELECT @v_OSList = coalesce(@v_OSList + ', ', '') + o.shortname  
 From  
  ImageDefinitions d WITH(NOLOCK) join  
  OSLookup o WITH(NOLOCK) on o.id = d.OSID  
 WHERE d.ProductDropID = @p_ProductDropID  
 ORDER BY o.name  
  
ELSE  
 SELECT @v_OSList = coalesce(@v_OSList + ', ', '') + o.shortname  
 From  
  ImageDefinitions d WITH(NOLOCK) join  
  Feature f WITH(NOLOCK) on d.featureID = f.featureID join  
  OSLookup o WITH(NOLOCK) on o.id = f.OSID  
 WHERE d.ProductDropID = @p_ProductDropID  
 ORDER BY o.name  
  
  INSERT INTO @t_OSList 
  SELECT @v_OSList

return
END

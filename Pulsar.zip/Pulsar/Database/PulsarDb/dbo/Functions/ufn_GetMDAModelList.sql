﻿-- =============================================
-- Author:		Kenneth M. Berntsen
-- Create date: 9/22/2006
-- Description:	Concatenates the list of models into one comma seperated string
-- =============================================
--	01/16/2007 - KMB - Modified the query to return the short Model/Series Name
-- =============================================
CREATE FUNCTION [dbo].[ufn_GetMDAModelList] 
(
	-- Add the parameters for the function here
	@p_WhqlID int
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result VARCHAR(MAX)

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = COALESCE(@Result + ', ', '') + RTRIM(ShortName)
	FROM 
		(SELECT DISTINCT 
			b.streetname2 + ' ' + s.name as ShortName
		FROM         
	ProductWHQL w WITH(NOLOCK)
	INNER JOIN ProductWHQL_Series ws WITH(NOLOCK) ON w.ID = ws.ProductWhqlID
	INNER JOIN Series s WITH(NOLOCK) ON s.id = ws.SeriesID
	INNER JOIN Product_Brand pb WITH(NOLOCK) ON pb.id = s.ProductBrandID
	INNER JOIN Brand b WITH(NOLOCK) ON pb.BrandID = b.ID
		WHERE
			w.ID = @p_WhqlID) T1
	ORDER BY ShortName

	-- Return the result of the function
	RETURN COALESCE(@Result, '')

END






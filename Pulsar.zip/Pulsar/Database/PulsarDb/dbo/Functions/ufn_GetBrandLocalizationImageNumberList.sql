﻿CREATE FUNCTION [dbo].[ufn_GetBrandLocalizationImageNumberList] 
	(
	@p_ProductVersionID INT,
	@p_BrandID INT,
	@p_RegionID INT
	)
RETURNS VARCHAR(1000)
AS
BEGIN

DECLARE @v_ImageNumber varchar(1000)

SELECT @v_ImageNumber =
	CASE
		WHEN imd.SKUNumber != '' THEN COALESCE(@v_ImageNumber + ', ', '') + LEFT(imd.SKUNumber, 6) + LEFT(r.Dash, 3) + RIGHT(imd.SKUNumber, 1)
		WHEN imd.SKUNumber = '' THEN COALESCE(@v_ImageNumber + ', ', '') + 'ID:' + CAST(i.ID AS VARCHAR(20))
		ELSE @v_ImageNumber
	END
FROM ImageDefinitions imd WITH(NOLOCK)
INNER JOIN Images i WITH(NOLOCK) ON imd.ID = i.ImageDefinitionID 
INNER JOIN Regions r ON i.RegionID = r.ID
WHERE imd.BrandID = @p_BrandID
AND imd.ProductVersionID = @p_ProductVersionID
AND i.RegionID = @p_RegionID

RETURN @v_ImageNumber 

END


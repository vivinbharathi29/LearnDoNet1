﻿-- =================================================
-- Gets the specified value of an item from an array
-- =================================================
CREATE FUNCTION [dbo].[item]
(
@TheArray XML, @index INT 

)
RETURNS VARCHAR(MAX)
AS
BEGIN
RETURN (SELECT element.value('item[1]', 'VARCHAR(max)')
    FROM @TheArray.nodes('/stringarray/element[position()=sql:variable("@index")]') array(element))

END


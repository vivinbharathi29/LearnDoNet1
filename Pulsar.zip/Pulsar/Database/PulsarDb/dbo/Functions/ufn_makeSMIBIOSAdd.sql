CREATE FUNCTION [dbo].[ufn_makeSMIBIOSAdd] ( 
/**************************************************************************************************
 * Purpose:	Make a delimited string of the values from Module_SMIBIOSAdd based on the ModuleID passed (copied from IRS)
 * Created By:	10/14/2009 JCope
 * Modified By:	
 **************************************************************************************************/
	@intModuleID int,
	@chrDelimiter varchar(10),
	@intType int	-- 0=IDs, 1=Names
)
RETURNS varchar(max) AS  
BEGIN 
	--set @CRLF = char(13)+char(10)
	if @chrDelimiter = ''
		set @chrDelimiter = ';'

	declare @chrList varchar(max)
	set @chrList = null

	if @intType = 0
		SELECT @chrList = COALESCE(@chrList + @chrDelimiter, '') + convert(varchar(10),i.Id)
		FROM Feature_SMBIOSAdd ms
			inner join CommonInstallOption i on i.Id = ms.Id
		WHERE ms.FeatureID = @intModuleID
		order by i.DMIString
	else if @intType = 1
		SELECT @chrList = COALESCE(@chrList + @chrDelimiter, '') + rtrim(i.DMIString)
		FROM Feature_SMBIOSAdd ms
			inner join CommonInstallOption i on i.Id = ms.Id
		WHERE ms.FeatureID = @intModuleID
		order by i.DMIString
	
	if @chrList is null
		set @chrList = ''

	return (@chrList)
END




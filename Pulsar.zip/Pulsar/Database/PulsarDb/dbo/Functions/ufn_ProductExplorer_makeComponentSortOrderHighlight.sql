﻿CREATE FUNCTION [dbo].[ufn_ProductExplorer_makeComponentSortOrderHighlight]
/* ************************************************************************************************
 * Purpose:	return 1 if the PE side has different Sort Order than Component side and then it needs to be highlighted
 * Created By:	linshan 04/17/2018
 * Modified By:	
 **************************************************************************************************/
(@p_intDeliverableversionID int, 
@p_intPDID int
)
RETURNS bit AS  
BEGIN 
	
	DECLARE @productReleaseID int, @highlighted bit =0
	SELECT     @productReleaseID = pd.ProductversionReleaseID FROM ProductDrop pd WHERE pd.ProductDropID = @p_intPDID
	
	IF NOT EXISTS(SELECT 1 FROM Product_Component_SortOrder pcs 
	    WHERE pcs.DeliverableVersionID = @p_intDeliverableversionID and pcs.ProductversionReleaseID = @productReleaseID) 
			SELECT @highlighted = CASE WHEN EXISTS (SELECT 1 FROM DeliverableVersion WHERE id = @p_intDeliverableversionID and ISNULL(SortOrder,0) = 0)
			                      THEN 0 ELSE 1 END
	ELSE 
			SELECT @highlighted = CASE WHEN ISNULL(pcs.SortOrder,0) = ISNULL(dv.SortOrder,0) THEN 0 ELSE 1 END
			FROM Product_Component_SortOrder pcs 
			JOIN DeliverableVersion dv on pcs.DeliverableVersionID = dv.ID 
			WHERE pcs.DeliverableVersionID = @p_intDeliverableversionID and pcs.ProductversionReleaseID =@productReleaseID

	return @highlighted
END


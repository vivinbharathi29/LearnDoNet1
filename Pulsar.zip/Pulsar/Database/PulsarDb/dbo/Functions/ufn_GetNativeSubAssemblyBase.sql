﻿CREATE FUNCTION [dbo].[ufn_GetNativeSubAssemblyBase] 
 (
	@SubAssemblyBase as varchar(10),
	@NativeRootID as int
)  
RETURNS varchar(10)
AS
BEGIN
	Declare @DevCenter as int
	Declare @Result as varchar(10)

	Select @DevCenter = max(v.devcenter)
	from product_delroot pd WITH(NOLOCK), productversion v WITH(NOLOCK)
	where base = @SubAssemblyBase
	and v.id = pd.productversionid

	if @DevCenter <> 2 
		Select @DevCenter = 1

	Select distinct @Result = pd.base
	from product_delroot pd WITH(NOLOCK), productversion v WITH(NOLOCK)
	where ( (DevCenter=2 and @DevCenter = 2) or (DevCenter<>2 and @DevCenter <> 2) )
	and pd.deliverablerootid = @NativeRootID
	and v.id = pd.productversionid
	and pd.base is not null
Return( @Result)

END



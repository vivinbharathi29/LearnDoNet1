﻿CREATE FUNCTION [dbo].[ufn_MakeEmailBody]
 ( @chrMsg varchar(max))  
/* ************************************************************************************************
 * Purpose:	
 * Created By:	Ywang moved to pulsar on 9/15/2014
Modified by:
 **************************************************************************************************/

RETURNS varchar(max) AS  
BEGIN 
	declare @CRLF varchar(10), @chrHeader varchar(512), @chrFooter varchar(255)
	set @CRLF = char(13)+char(10)
	set @chrHeader = ''
	set @chrFooter = ''
	set @chrHeader = @chrHeader + '<html>' + @CRLF
	set @chrHeader = @chrHeader + '<head>' + @CRLF
	set @chrHeader = @chrHeader + '<TITLE>Message</TITLE>' + @CRLF
	set @chrHeader = @chrHeader + '<STYLE>BODY' + @CRLF
	set @chrHeader = @chrHeader + '{' + @CRLF
	set @chrHeader = @chrHeader + 'COLOR: black;' + @CRLF
	set @chrHeader = @chrHeader + 'FONT-FAMILY: Arial;' + @CRLF
	set @chrHeader = @chrHeader + 'FONT-SIZE: 9pt;' + @CRLF
	set @chrHeader = @chrHeader + 'MARGIN-LEFT: 10px;' + @CRLF
	set @chrHeader = @chrHeader + 'MARGIN-RIGHT: 10px' + @CRLF
	set @chrHeader = @chrHeader + '}' + @CRLF
	set @chrHeader = @chrHeader + 'TABLE' + @CRLF
	set @chrHeader = @chrHeader + '{' + @CRLF
	set @chrHeader = @chrHeader + 'FONT-FAMILY: Arial;' + @CRLF
	set @chrHeader = @chrHeader + 'FONT-SIZE: 9pt;' + @CRLF
	set @chrHeader = @chrHeader + 'MARGIN: 0px;' + @CRLF
	set @chrHeader = @chrHeader + 'PADDING-BOTTOM: 0px;' + @CRLF
	set @chrHeader = @chrHeader + 'PADDING-LEFT: 0px;' + @CRLF
	set @chrHeader = @chrHeader + 'PADDING-RIGHT: 0px;' + @CRLF
	set @chrHeader = @chrHeader + 'PADDING-TOP: 0px' + @CRLF
	set @chrHeader = @chrHeader + '}</STYLE>' + @CRLF
	set @chrHeader = @chrHeader + '</head>' + @CRLF
	set @chrHeader = @chrHeader + '<body bgcolor="FFFFFF">' + @CRLF

	set @chrFooter = @chrFooter + '<p align = center><i style=''mso-bidi-font-style:normal''><span style=''font-size:8.0pt;''>This is an automated email from Pulsar. ' + @CRLF + 'Please do not respond.</span></i></p>' + @CRLF
	set @chrFooter = @chrFooter + '</body>' + @CRLF
	set @chrFooter = @chrFooter + '</html>' + @CRLF

	set @chrMsg = @chrHeader + @chrMsg + @chrFooter

	return (@chrMsg)
END


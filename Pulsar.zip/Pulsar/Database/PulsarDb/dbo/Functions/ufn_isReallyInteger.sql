﻿CREATE FUNCTION [dbo].[ufn_isReallyInteger]
(  
/**************************************************************************************************
 * Purpose:	ms sql server built-in ismuneric function is not working for some characters, 
 *		create a custom function to make sure it always works
 * 		This verifies that it is truly an integer so no decimal points.
 *
 * Created By:	11/05/2007 JCope for IRS; Yong moved this to pulsar on 11/7/2017
 * Modified By:	
 **************************************************************************************************/
    @num VARCHAR(64)  
)  
RETURNS BIT  
BEGIN  
    IF LEFT(@num, 1) = '-'  
        SET @num = SUBSTRING(@num, 2, LEN(@num))  
 
    RETURN CASE  
    WHEN PATINDEX('%[^0-9-]%', @num) = 0  
        AND CHARINDEX('-', @num) <= 1  
        AND @num NOT IN ('.', '-', '+', '^') 
        AND LEN(@num)>0  
        AND @num NOT LIKE '%-%' 
    THEN  
        1  
    ELSE  
        0  
    END  
END  

﻿

CREATE FUNCTION [dbo].[ufn_GetPreviousVersionPartNumbersInImage] (@p_ProductVersionID INT,@p_DeliverableVersionID INT)
RETURNS varchar(8000)
AS
BEGIN

DECLARE @v_Summary varchar(8000)
SELECT @v_Summary = dbo.concatenate(v.IRSPartNumber)
FROM 
	Product_Deliverable pd WITH(NOLOCK) join
	DeliverableVersion v WITH(NOLOCK) on v.ID = pd.deliverableversionid
WHERE pd.productversionid = @p_ProductVersionID
and pd.deliverableversionid < @p_DeliverableVersionID
and InImage=1
and v.DeliverablerootID in (Select v.deliverablerootid from deliverableversion v where ID = @p_DeliverableVersionID)

RETURN @v_Summary

END




﻿CREATE FUNCTION [dbo].[ufn_IsLinkedServerEnabled]
(
	@linkedServerName VARCHAR(128)
)
RETURNS BIT
AS
BEGIN
	DECLARE @RET AS BIT
	SET @RET = 1

	SELECT @RET = ISNULL(TRY_CONVERT(BIT, s.Value), 0)
	FROM dbo.Setting AS s 
	WHERE s.Name = CONCAT('LinkedServer.', @linkedServerName, '.Enabled')
	
	RETURN @RET
END

﻿

CREATE FUNCTION [dbo].[ufn_GetPreviousVersionsInImage] (@p_ProductVersionID INT,@p_DeliverableVersionID INT)
RETURNS INT
AS
BEGIN

DECLARE @v_Count int
SELECT @v_Count = COUNT(1)
FROM 
	Product_Deliverable pd WITH(NOLOCK) join
	DeliverableVersion v WITH(NOLOCK) on v.ID = pd.deliverableversionid
WHERE pd.productversionid = @p_ProductVersionID
and pd.deliverableversionid < @p_DeliverableVersionID
and InImage=1
and v.DeliverablerootID in (Select v.deliverablerootid from deliverableversion v where ID = @p_DeliverableVersionID)
RETURN @v_Count

END




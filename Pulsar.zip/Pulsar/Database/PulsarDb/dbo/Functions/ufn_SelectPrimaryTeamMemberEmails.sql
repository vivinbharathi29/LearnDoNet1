﻿
CREATE FUNCTION [dbo].[ufn_SelectPrimaryTeamMemberEmails]
(
  @p_PVID INT
) 
RETURNS VARCHAR(1000)
 
AS

  BEGIN
	DECLARE @v_EmailList VARCHAR(1000)
	SELECT  @v_EmailList =	COALESCE(@v_EmailList + ';', '') + Employee.Email

	FROM   ProductVersion WITH(NOLOCK) INNER JOIN
		   Employee WITH(NOLOCK) ON ProductVersion.PMID = Employee.ID OR ProductVersion.SEPMID = Employee.ID OR ProductVersion.SMID = Employee.ID OR 
		   ProductVersion.PDEID = Employee.ID OR ProductVersion.ComMarketingID = Employee.ID OR ProductVersion.SMBMarketingID = Employee.ID OR 
		   ProductVersion.ConsMarketingID = Employee.ID OR ProductVersion.PlatformDevelopmentID = Employee.ID OR ProductVersion.SupplyChainID = Employee.ID OR 
		   ProductVersion.ServiceID = Employee.ID OR ProductVersion.FinanceID = Employee.ID 
		   OR ProductVersion.QualityID = Employee.ID  
		   or ProductVersion.ProcurementPMID =Employee.id 
		   or ProductVersion.PlanningPMID =Employee.id
		   OR ProductVersion.TDCCMID = Employee.ID
	WHERE  ProductVersion.ID = @p_PVID

	RETURN @v_EmailList
  END



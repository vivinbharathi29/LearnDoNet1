

CREATE FUNCTION [dbo].[ufn_ProductHasValidScheduleDate]
(  
/**************************************************************************************************
Purpose: check if release to production and End of Manufactuing schedules exist and verify if they have actual dates
CreatedDate: 03/23/2015 wgomero
Modified By : 11/18/2015, santodip Change Release to Production (RTP) to Target RTP/MR/FCS
			: 12/1/2015, santodip check for projected_start_dt from Schedule_Date instead of por_start_dt - bug 14752
			: 12/7/2015, santodip check for 'End of Manufacturing' and 'End of Production' - task 15088 
			: 12/11/2015, santodip added else condition to set @ItHasDate = 0 when EP/EM is empty task 15131
			: 5/10/2016 SruthiR - Remove "FCS" from all areas that use "RTP/MR/FCS" - task 20243
			: 5/13/2016 santodip - User is able to change product phase when Target RTP/MR/FCS is empty - Bug 20529 
**************************************************************************************************/
  	@p_ProcuctVersionId int
)  
returns int
BEGIN
DECLARE @count int, @ItHasDate varchar(10), @scheduleID int, @PorDateRTP varchar(10), @PorDateEMD varchar(10), @ReleaseToProductionDate varchar(64), @EndOfManufactureDate varchar(64)
SET @ItHasDate = 0 --False
SET @ReleaseToProductionDate = 'Target RTP/MR'
--SET @EndOfManufactureDate = 'End of Manufacturing'

SELECT TOP 1
	@scheduleID = s.schedule_id

FROM
	schedule s with (NOLOCK) INNER JOIN
		product_release pr with (NOLOCK) ON pr.id = s.product_release_id
WHERE
	pr.productversionid = COALESCE(@p_ProcuctVersionId, pr.productversionid)
	AND s.active_yn = COALESCE('Y', s.active_yn)
ORDER BY pr.releaseid

IF @scheduleID > 0
 BEGIN

		IF EXISTS (select * from Schedule_Data  where Schedule_id = @scheduleId AND item_description = @ReleaseToProductionDate)
					BEGIN
					SELECT @PorDateRTP = projected_start_dt FROM Schedule_Data  where Schedule_id = @scheduleId AND item_description = @ReleaseToProductionDate
					IF (@PorDateRTP IS NOT NULL AND @PorDateRTP <> '')
							BEGIN
							IF EXISTS (select * from Schedule_Data  where Schedule_id = @scheduleId AND item_description in ('End of Production', 'End of Manufacturing'))--= @EndOfManufactureDate)
								BEGIN
								SELECT @PorDateEMD = projected_start_dt FROM Schedule_Data  where Schedule_id = @scheduleId AND item_description in ('End of Production', 'End of Manufacturing')--= @EndOfManufactureDate
								IF @PorDateEMD IS NOT NULL AND @PorDateEMD <> ''
									SET @ItHasDate = 1
								ELSE
									SET @ItHasDate = 0
								END 
							ELSE
								SET @ItHasDate = 0
							END
					ELSE
							SET @ItHasDate = 0
					END		
		ELSE
					SET @ItHasDate = 0
END

RETURN @ItHasDate

END


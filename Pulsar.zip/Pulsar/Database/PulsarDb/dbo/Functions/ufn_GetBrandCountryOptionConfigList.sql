﻿
CREATE FUNCTION [dbo].[ufn_GetBrandCountryOptionConfigList] (@p_CountryID INT, @p_ProductBrandID INT)
RETURNS VARCHAR(1000)
AS
BEGIN

DECLARE @v_ConfigCodes VARCHAR(1000)
SELECT @v_ConfigCodes = coalesce(@v_ConfigCodes + '<BR>', '') + l.OptionConfig + ' (' + b.Abbreviation + ')'
FROM 
	Business b WITH(NOLOCK)
	INNER JOIN ProdBrand_Country pbc WITH(NOLOCK) ON b.ID = pbc.BusinessID 
	INNER JOIN ProdBrandCountry_Localization pbcl WITH(NOLOCK) 
	INNER JOIN Regions l WITH(NOLOCK) ON pbcl.LocalizationID = l.ID ON pbc.ID = pbcl.ProdBrandCountryID
WHERE
	pbc.CountryID = @p_CountryID
AND	pbc.ProductBrandID = @p_ProductBrandID
ORDER BY l.DisplayOrder

RETURN @v_ConfigCodes 

END


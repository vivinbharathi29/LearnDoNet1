﻿CREATE FUNCTION [dbo].[ufn_BusinessDays]
 (
	@StartDate as DateTime,
	 @EndDate as DateTime
)  

RETURNS int

AS  
BEGIN 

DECLARE @Days int
DECLARE @DaysInStartWeek int
DECLARE @DaysInEndWeek int
DECLARE @FullWeeks int
DECLARE @StartDayOfWeek int
DECLARE @EndDayOfWeek int
DECLARE @TotalDays int


Select @FullWeeks = datediff(week,@StartDate,@EndDate)
if abs(@FullWeeks) < 2
	Select @Days = 0
else
	Select @Days = (abs(@FullWeeks)-1) * 5

Select @StartDayOfWeek = datepart(dw,@StartDate) -1
if @StartDayofWeek > 5
	Select @StartDayofWeek=5
Select @EndDayOfWeek = datepart(dw,@EndDate) -1
if @EndDayofWeek > 5
	Select @EndDayofWeek=5

if @FullWeeks = 0
	Select @TotalDays = @EndDayofWeek - @StartDayofWeek
else if @FullWeeks = 1
	Select @TotalDays = (5 - @StartDayofWeek) + @EndDayofWeek
else if @FullWeeks = -1
	Select @TotalDays = 0-((5 - @EndDayofWeek) + @StartDayofWeek)
else if @FullWeeks > 1
	Select @TotalDays = (5 - @StartDayofWeek) + @EndDayofWeek + @Days
else
	Select @TotalDays = 0-((5 - @EndDayofWeek) + @StartDayofWeek) - @Days


Return @TotalDays



/*
DECLARE @Days int
DECLARE @DaysInStartWeek int
DECLARE @DaysInEndWeek int

Select @Days = (datediff(week,@StartDate,@EndDate) - 1) * 5

if datepart(dw,@StartDate) = 7
	Select @DaysInStartWeek = 7 - datepart(dw,@StartDate)
else
	Select @DaysInStartWeek = 7 - datepart(dw,@StartDate)-1

if datepart(dw,@EndDate) = 7
	Select @DaysInEndWeek = 7 - datepart(dw,@EndDate)
else
	Select @DaysInEndWeek = 7 - datepart(dw,@EndDate)-1


Return( @Days + @DaysInStartWeek + @DaysInEndWeek)
*/

END






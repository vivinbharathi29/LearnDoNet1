

CREATE FUNCTION [dbo].[ufn_makeODMBOMVisibility_Pulsar] ( 
/**************************************************************************************************
 * Purpose:		Make a delimited string of the ODM BOM Visibility values
 * Created By:	06/22/2015 ThTran
 * Modified By:	Copied from ufn_makeODMBOMVisibility (by Jeff Cope)
 **************************************************************************************************/
	@intProductBrandID int,
	@chrDelimiter varchar(10) = ''
)
RETURNS varchar(max) AS  
BEGIN 

	if @chrDelimiter = ''
		set @chrDelimiter = ';'

	declare @chrList varchar(max)
	set @chrList = null

	select @chrList = COALESCE(@chrList + @chrDelimiter, '') + O.Value
	from ProductBrand_OdmBom PBO
		inner join ODMBom O on PBO.OdmBomID = O.ID
	where PBO.ProductBrandID = @intProductBrandID
	order by O.Value

	if @chrList is null
		set @chrList = ''

	return (@chrList)
END


GO


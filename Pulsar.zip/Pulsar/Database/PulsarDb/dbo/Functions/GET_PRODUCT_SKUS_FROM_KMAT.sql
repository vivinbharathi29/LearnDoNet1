﻿CREATE FUNCTION [dbo].[GET_PRODUCT_SKUS_FROM_KMAT]
(
	@KMAT VARCHAR(MAX)=NULL
)

RETURNS @DATASET TABLE 
(
	SKU VARCHAR(18)
)
AS
BEGIN
	DECLARE @v_KMATs Table (kmat varchar(15));

	INSERT INTO @v_KMATs
	SELECT StringElement COLLATE DATABASE_DEFAULT FROM dbo.Split(@KMAT)

	 IF (SELECT COUNT(1) FROM @v_KMATs) > 0 BEGIN
		INSERT INTO @DATASET

		SELECT DISTINCT 
			bom.PartNumber 
		FROM
			@v_KMATs k 
			INNER JOIN Product_Brand pb ON k.kmat = pb.KMAT 
			INNER JOIN AvDetail_ProductBrand ab ON pb.ID = ab.ProductBrandID
			INNER JOIN AvDetail d ON ab.AvDetailID = d.AvDetailID
			INNER JOIN DATAWAREHOUSE.dbo.iHUB_BillOfMaterial bom ON bom.ChildPartNumber = d.AvNo
		WHERE 
			CHARINDEX('-999',bom.PartNumber,1)=0
			AND (d.FeatureCategoryID = 1 OR d.FeatureCategoryID = 86)
			AND (bom.StartDt <= GETDATE())
			AND (bom.EndDt > GETDATE())


		--SELECT DISTINCT
		--	B2.partnumber
		--FROM 
		--	@v_KMATs kmats INNER JOIN
		--	DATAWAREHOUSE.dbo.iHUB_BillOfMaterial B  WITH (NOLOCK) ON b.PartNumber = kmats.kmat
		--	INNER JOIN 
		--	DATAWAREHOUSE.dbo.iHUB_MaterialDescription MD  WITH (NOLOCK) ON B.ChildPartNumber = MD.PartNumber 
		--	INNER JOIN 
		--	DATAWAREHOUSE.dbo.iHUB_BillOfMaterial B2  WITH (NOLOCK) ON B2.ChildPartNumber = B.ChildPartNumber
		--	INNER JOIN
		--	DATAWAREHOUSE.dbo.iHUB_MaterialDescription AS MD2   WITH (NOLOCK) ON B2.PartNumber = MD2.PartNumber 			
		--WHERE
		--	CHARINDEX('-999',B2.PartNumber,1)=0 
		--	AND 
		--	CHARINDEX('BU ',MD.GPGDescription,1)=1	
		--	AND
		--	B2.EndDt > GETDATE()
		--	AND 
		--	B.EndDt > GETDATE()
	END
	RETURN
	
END

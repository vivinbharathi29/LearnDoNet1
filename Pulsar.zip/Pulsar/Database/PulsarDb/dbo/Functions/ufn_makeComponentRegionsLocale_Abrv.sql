﻿CREATE FUNCTION [dbo].[ufn_makeComponentRegionsLocale_Abrv]
/**************************************************************************************************
 * Purpose:		Make a delimited string of the Supported Regions or Image Locale for a Component, only get the region dash code
 * Created By:	08/03/2016 wgomero, based on ufn_makeComponentRegionsLocale from JCope
 * Modified By:	
 **************************************************************************************************/
(   @intProductVersionReleaseID int,
	@intDeliverableVersionID int,
	@chrDelimiter varchar(10) = '',
	@intType int -- 0 = Supported Regions, 1 = Image Locale
)
RETURNS varchar(max) AS  
BEGIN 
	--set @CRLF = char(13)+char(10)
	if @chrDelimiter = ''
		set @chrDelimiter = ';'

	declare @chrList varchar(max)
	set @chrList = null

	select @chrList = COALESCE(@chrList + @chrDelimiter, '') +  rtrim(r.OptionConfig)
	from Product_Component_SupportedRegions pcs
		inner join Regions r on pcs.RegionID = r.ID
	where pcs.ProductversionReleaseID = @intProductVersionReleaseID
		and pcs.DeliverableVersionID = @intDeliverableVersionID
		and pcs.TypeID = @intType
	order by r.OptionConfig

	if @chrList is null
		set @chrList = ''

	return (@chrList)
END


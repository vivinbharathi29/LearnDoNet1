﻿CREATE FUNCTION [dbo].[ufn_ListOS4IRSComponentUpdateList]
/* ************************************************************************************************
 * Purpose: ExcaliburWeb - IRS Component Update List - List OS
 * Created By:	06/30/2016 Herb, List OS for IRS Component Update List.
								 take FeatureID to find OS when Pulsar Product.
 * Modified By: 
 **************************************************************************************************/
(
	@FusionRequirements int,
	@ProductVersionID int,
	@Images VARCHAR(MAX)
)
RETURNS VARCHAR(MAX)
AS 
BEGIN

	DECLARE 
		@isPulsar int,
		@pID int,
		@strImages varchar(max),
		@listOS varchar(8000)

	SELECT
		@isPulsar = ISNULL(@FusionRequirements, 0);

	IF @Images is not null and @Images <> '0,' and @Images <> ''
	BEGIN

		if @Images like '%:%'
			select @strImages = left(@Images, CHARINDEX(':',@Images)-1);
		ELSE
			select @strImages = @Images;

		if right(@strImages,1) = ','
			select @strImages = left(@strImages, len(@strImages)-1)

		if @isPulsar=1
			SELECT @listOS =
			(
			SELECT (CAST(shortname AS NVARCHAR) + ',')
			FROM (	
				SELECT DISTINCT f.shortname
				FROM images i WITH (NOLOCK)
				JOIN ImageDefinitions d WITH (NOLOCK) ON i.imagedefinitionid = d.id
				JOIN Feature f1 WITH (NOLOCK) ON f1.FeatureID=d.FeatureID
				JOIN oslookup o WITH (NOLOCK) ON f1.osid = o.id
				JOIN osfamily f WITH (NOLOCK) ON f.id = osfamilyid
				WHERE i.id IN (SELECT * FROM dbo.Split(@strImages))
				) AS OSList1
			FOR XML PATH ('') 
			) 
		ELSE 
			SELECT @listOS =
			(
			SELECT (CAST(shortname AS NVARCHAR) + ',')
			FROM (	
				SELECT DISTINCT f.shortname
				FROM images i WITH (NOLOCK)
				JOIN ImageDefinitions d WITH (NOLOCK) ON i.imagedefinitionid = d.id
				JOIN oslookup o WITH (NOLOCK) ON d.osid = o.id
				JOIN osfamily f WITH (NOLOCK) ON f.id = osfamilyid
				WHERE i.id IN (SELECT * FROM dbo.Split(@strImages))
				) AS OSList1
			FOR XML PATH ('') 
			) 
	END 
	ELSE 
	BEGIN
		SELECT @pID = @ProductVersionID

		IF @isPulsar = 1 
			SELECT @listOS =
			(
			SELECT (CAST(shortname AS NVARCHAR) + ',')
			FROM (
				SELECT DISTINCT f.shortname
				FROM ProductVersion_ProductDrop ppd WITH (NOLOCK)
				JOIN imagedefinitions d WITH (NOLOCK) ON ppd.ProductDropID = d.ProductDropID
				JOIN Feature f1 WITH (NOLOCK) ON f1.FeatureID=d.FeatureID
				JOIN OSLookup o WITH (NOLOCK) ON o.ID=f1.OSID
				JOIN osfamily f WITH (NOLOCK) ON f.id = o.OSFamilyID
				WHERE ppd.ProductVersionID = @pID AND d.active = 1
				) AS OSList1
			FOR XML PATH ('') 
			) 
		ELSE 
			SELECT @listOS =
			(
			SELECT (CAST(shortname AS NVARCHAR) + ',')
			FROM (
				SELECT DISTINCT f.shortname
				FROM ProductVersion_ProductDrop ppd WITH (NOLOCK)
				JOIN imagedefinitions d WITH (NOLOCK) ON ppd.ProductDropID = d.ProductDropID
				JOIN oslookup o WITH (NOLOCK) ON o.id = d.osid
				JOIN osfamily f WITH (NOLOCK) ON f.id = o.OSFamilyID
				WHERE ppd.ProductVersionID = @pID AND d.active = 1
				) AS OSList1
			FOR XML PATH ('')
			)
	END
	;

	if right(@listOS,1) = ','
		select @listOS = left(@listOS, len(@listOS)-1)

RETURN @listOS
END

﻿
Create FUNCTION [dbo].[function_string_to_table]
/* ************************************************************************************************
 * Purpose:	Convert delimiter string to table
 * Created By:	Dien Bui 3/5/2009 
 * Modified By: ADao - 06/23/2015 - Moved from IRS to Pulsar for SCMX Editor
 **************************************************************************************************/
(
    @string VARCHAR(MAX),
    @delimiter CHAR(1)
)
RETURNS @output TABLE(
	id varchar(5), 
    data VARCHAR(256)
)
BEGIN

    DECLARE @start INT, @end INT, @count INT 
    SELECT @start = 1, @end = CHARINDEX(@delimiter, @string)
	SET @count = 0
    WHILE @start < LEN(@string) + 1 BEGIN
        IF @end = 0 
            SET @end = LEN(@string) + 1

        INSERT INTO @output (id, data) 
        VALUES(@count, SUBSTRING(@string, @start, @end - @start))
		SET @count = @count + 1
        SET @start = @end + 1
        SET @end = CHARINDEX(@delimiter, @string, @start)
    END

    RETURN

END

﻿CREATE FUNCTION [dbo].[ufn_GetBrandLocalizationCountryList] 
	(
	@p_ProductBrandID INT,
	@p_LocalizationID INT
	)
RETURNS VARCHAR(1000)
AS
BEGIN

DECLARE @v_CountryList VARCHAR(1000)

SELECT @v_CountryList =	COALESCE(@v_CountryList + ', ', '') + c.Language
FROM
	ProdBrand_Country pbc WITH(NOLOCK)
	INNER JOIN Language c WITH(NOLOCK) ON pbc.CountryID = c.ID 
	INNER JOIN ProdBrandCountry_Localization pbcl WITH(NOLOCK) ON pbc.ID = pbcl.ProdBrandCountryID
WHERE
	pbcl.LocalizationID = @p_LocalizationID
AND pbc.ProductBrandID = @p_ProductBrandID
ORDER BY c.OrderID

RETURN @v_CountryList 

END


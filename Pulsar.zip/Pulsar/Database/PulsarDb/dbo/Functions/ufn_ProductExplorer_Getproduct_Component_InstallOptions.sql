﻿CREATE FUNCTION [dbo].[ufn_ProductExplorer_Getproduct_Component_InstallOptions]
(/**************************************************************************************************
 * Purpose:		Make a delimited string of the Install Option for a Product_Component
 * Created By:	05/31/2016 Ywang, based on irs ufn_makeComponentInstallOptions
 * Modified By:	
 **************************************************************************************************/
	@intProductversionReleaseID int,
	@intDeliverableVersionID int,
	@chrDelimiter varchar(10) = ''
)
RETURNS varchar(max) AS  
BEGIN 
	--set @CRLF = char(13)+char(10)
	if @chrDelimiter = ''
		set @chrDelimiter = ';'

	declare @chrList varchar(max)
	set @chrList = null

	select @chrList = COALESCE(@chrList + @chrDelimiter, '') + rtrim(io.DMIString)
	from Product_Component_InstallOption pcio with (nolock)
		inner join CommonInstallOption io with (nolock) on io.ID = pcio.IOID
	where pcio.ProductversionReleaseID = @intProductversionReleaseID
		and pcio.DeliverableVersionID = @intDeliverableVersionID
	order by io.DMIString

	if @chrList is null
		set @chrList = ''

	return (@chrList)
END


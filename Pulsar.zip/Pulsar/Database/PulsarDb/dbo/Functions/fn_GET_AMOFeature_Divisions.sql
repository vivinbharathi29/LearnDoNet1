﻿CREATE FUNCTION [dbo].[fn_GET_AMOFeature_Divisions]
/* ************************************************************************************************
 * Purpose:		Return Concatenated string of AMO Feature's Selected Division IDs
 *				used to populate FeatureDivisionIDs field in AMO Feature Search
 * Created By:	Harris, Valerie (09/09/2016)  
 * Modified By: 
 **************************************************************************************************/ 
(
	@p_FeatureID						bigint = 0
)
RETURNS VARCHAR(MAX) 
AS
BEGIN
	-- Declare variables: ---
	DECLARE @m_FeatureID	int = 0
	DECLARE @GetValue		varchar(1000) = NULL

	SET @m_FeatureID = @p_FeatureID

	SELECT @GetValue = COALESCE(@GetValue,'') + CONVERT(varchar(50),DivisionID) + ','  
	FROM AMOFeature_Division
	WHERE (FeatureID = @m_FeatureID) 

	if right(@GetValue, 1) = ',' 
		set @GetValue = left(@GetValue, len(@GetValue)-1)

	RETURN @GetValue
END

﻿CREATE FUNCTION [dbo].[ufn_GetComponentLanguages]
(
/* =============================================
   Purpose:		get the lis of component Languages in comma separated string
   Create :		04/17/2018: wgomero
   Modified By: 
   ============================================= */
	@DeliverableVersionID int
)
Returns varchar(max)

AS

BEGIN
	DECLARE @results AS Varchar(MAX) 

SELECT  @results = COALESCE(@results + ',', '') + l.Abbreviation + '-' + l.Language 
     FROM   Language l INNER JOIN Language_DelVer dv ON l.ID = dv.LanguageID 
	WHERE dv.deliverableversionid = @DeliverableVersionID
return @results

END

GO
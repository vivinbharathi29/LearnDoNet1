﻿-- ==========================================================================================
-- Author:		Patrick Ruland
-- Create date: 6/3/2011
-- Description:	Accepts a date 
--				Returns a string in yyyymmdd format
-- ==========================================================================================
CREATE FUNCTION [dbo].[GET_YMD_DATE]
(
	@ANYDATE DATETIME
)
RETURNS VARCHAR(8)
AS
BEGIN

	DECLARE @RESULT VARCHAR(8)
	
	IF(ISDATE(@ANYDATE)=1) SET @RESULT=CONVERT(VARCHAR(4),YEAR(@ANYDATE))+REPLACE(SPACE(2-LEN(CONVERT(VARCHAR(2),MONTH(@ANYDATE))))+CONVERT(VARCHAR(2),MONTH(@ANYDATE)),' ','0')+REPLACE(SPACE(2-LEN(CONVERT(VARCHAR(2),DAY(@ANYDATE))))+CONVERT(VARCHAR(2),DAY(@ANYDATE)),' ','0')
		
	RETURN @RESULT

END


﻿CREATE FUNCTION [dbo].[RegexMatches]
(@input NVARCHAR (MAX), @pattern NVARCHAR (MAX))
RETURNS 
     TABLE (
        [MatchID]      INT             NULL,
        [MatchIndex]   INT             NULL,
        [MatchValue]   NVARCHAR (4000) NULL,
        [GroupID]      INT             NULL,
        [GroupIndex]   INT             NULL,
        [GroupValue]   NVARCHAR (4000) NULL,
        [CaptureIndex] INT             NULL,
        [CaptureValue] NVARCHAR (4000) NULL)
AS
 EXTERNAL NAME [StringUtilities].[Microsoft.Samples.SqlServer.RegularExpression].[Matches]


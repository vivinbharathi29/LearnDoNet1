﻿
--ufn_GetIRSVendorID 20190

CREATE FUNCTION [dbo].[ufn_GetIRSVendorID] 
(
	@VendorID int
)
Returns int

AS

Begin
	Declare @results int

	Select @results = IRSID
	From Vendor
	Where ID = @VendorID

	return @results
End


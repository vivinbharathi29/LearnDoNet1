﻿CREATE FUNCTION [dbo].[ufn_ViewIRSCompInstallOptions] ( 
/**************************************************************************************************
 * Purpose:		Make a delimited string of the Install Option Combinations and Install Options for a Component of IRS Product
 * Created By:	08/23/2017 linshan
 * Modified By:	
 **************************************************************************************************/
	@intIRSProductID int, 
	@intComponentPassID int,
	@chrDelimiter varchar(10) = ''
)
RETURNS varchar(max) AS  
BEGIN 
	
	if @chrDelimiter = ''
		set @chrDelimiter = ';'

	declare @chrList varchar(max)
	set @chrList = null
	select @chrList = COALESCE(@chrList + @chrDelimiter, '') + rtrim(io.Combination)
		from IRS_Product_Component_InstallOptionCombination pcio
			inner join View_InstallOptionCombination io on io.IOCombinationID = pcio.IOCombinationID
		where pcio.ProductID = @intIRSProductID
			and pcio.ComponentPassID = @intComponentPassID
		

		select @chrList = COALESCE(@chrList + @chrDelimiter, '') + rtrim(io.DMIString)
		from IRS_Product_Component_InstallOption pcio
			inner join View_InstallOption io on io.IOID = pcio.IOID
		where pcio.ProductID = @intIRSProductID
			and pcio.ComponentPassID = @intComponentPassID
		order by io.DMIString

	if @chrList is null
		set @chrList = ''

	return (@chrList)
END
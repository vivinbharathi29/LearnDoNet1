﻿CREATE FUNCTION [dbo].[ufn_GetComponentOSs]
(
/* =============================================
   Purpose:		get the lis of component Operating Systems in comma separated string
   Create :		10/24/2016: wgomero
   Modified By: 
   ============================================= */
	@DeliverableVersionID int
)
Returns varchar(512)

AS

BEGIN
	DECLARE @results AS Varchar(MAX) 

SELECT  @results = COALESCE(@results + ',', '') + OS.CVAKey 
FROM   OS_DelVer OSD INNER JOIN OSLookup OS ON OSD.OSID = OS.ID 
	WHERE OSD.deliverableversionid = @DeliverableVersionID

return @results

END

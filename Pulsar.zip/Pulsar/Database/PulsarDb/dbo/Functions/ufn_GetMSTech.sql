﻿-- =============================================
-- Author:		Kenneth M. Berntsen
-- Create date: 2/16/2007
-- Description:	Returns All Non OS Microsoft Deliverables in the Image
-- =============================================
CREATE FUNCTION [dbo].[ufn_GetMSTech]
(
	-- Add the parameters for the function here
	@p_ProductVersionID int
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result VARCHAR(MAX)

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = COALESCE(@Result + ', ', '') + RTRIM(DeliverableName)
	FROM (
		SELECT DISTINCT DeliverableName 
		FROM deliverableroot r  WITH(NOLOCK)
			INNER JOIN deliverableversion v WITH(NOLOCK) on r.id = v.deliverablerootid
			INNER JOIN product_deliverable pd WITH(NOLOCK) on v.id = pd.deliverableversionid
		WHERE 
			v.VendorID = 201
		AND r.CategoryID IN (7, 164)
		AND pd.InImage = 1
		AND pd.ProductVersionID = @p_ProductVersionID
	) T1
	ORDER BY DeliverableName

	-- Return the result of the function
	RETURN @Result

END


/* *************************************************************************************************************************************************************
 * Purpose:   Construct default SCM name based on this formula: SCM_Brand Name_Series_Generation_Form Factor_Product Name_Cycle_KMAT#_Date_Revision 
 ***************************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[ufn_SCM_GetDefaultSCMName] 
(
	@p_ProductBrandID INT
)
RETURNS VARCHAR(1000)
AS
BEGIN

	declare @SCMName varchar(260)
	declare @productversionID int, @BrandID int
	select @productversionID = productversionID,@BrandID = brandID
		from product_Brand where ID=@p_ProductBrandID
	declare @chrRevision varchar(10), @chrLatestSCMRevision varchar(10), @chrPrevSCMName varchar(260)

	select 	@chrRevision = isnull(SCMPublish.Revision,'') 			
		from SCMPublish where SCMID in (select max(SCMID) from SCMPublish where ProductBrandID =@p_ProductBrandID and StandardRelease <> 0)

	select 	@chrLatestSCMRevision = isnull(SCMPublish.Revision,'')  ,
		@chrPrevSCMName = isnull(SCMName, '')
	from SCMPublish where SCMID in (select max(SCMID) from SCMPublish where ProductBrandID =@p_ProductBrandID and StandardRelease <> 2)

	--construct default name based on this formula:
	--SCM_Brand Name_Series_Generation_Form Factor_Product Name_Cycle_KMAT#_Date_Revision 

	--if it's a combined scm then use the combined name
	select @SCMName = isnull('SCM ' + REPLACE(CombinedName,'/','_'), '') from Product_brand where  ID = @p_ProductBrandID
	Declare @series varchar(2000)

	if @SCMName ='' or @SCMName is null
	begin
		select @SCMName ='SCM '
		select @SCMName =@SCMName + isnull(brand.Streetname,brand.Name)  
		from brand 
		where ID=@BrandID
	
		IF EXISTS(SELECT 1 FROM Product_Brand pb join ProductVersion pv on pb.ProductVersionID = pv.ID WHERE pb.ID=@p_ProductBrandID and pv.AllowFollowMarketingName = 0 )
			SELECT @series = SeriesSummary FROM Product_Brand WHERE ID=@p_ProductBrandID 
		ELSE
		BEGIN
			SELECT TOP 1 @series = COALESCE(s.Name, pb.SeriesSummary,'') FROM ProductVersion_Platform pvpf
            JOIN Product_Brand pb on pvpf.productbrandid = pb.id
            LEFT JOIN Series s on pvpf.SeriesID = s.ID
            WHERE pb.ID =@p_ProductBrandID 
			ORDER BY pvpf.PlatformID	
		END

		  
		SELECT @SCMName =trim(CONCAT_WS(' ', @SCMName, @series, Generation, FormFactor))
		FROM product_Brand 
		WHERE ID=@p_ProductBrandID

		select @SCMName =@SCMName + ' ' + ProductName   
		from productversion
		where ID=@productversionID
	
	end
	--product release info:
	declare @intCurrentReleaseID int = 0
	
	DECLARE  @intMOLPOR int, @intMOLPOSTPOR int		
	select	@intMOLPOR = StatusID from PRLStatus where Constant = 'MOL_ENG_TEST'
	select	@intMOLPOSTPOR = StatusID from PRLStatus where Constant = 'MOL_POST_POR'

	SELECT TOP 1 @intCurrentReleaseID = ISNULL(PRL_Products.releaseID , 0)
	FROM PRL_Revision
	INNER JOIN PRL_Products ON PRL_Revision.PRLRevisionID=PRL_Products.PRLRevisionID
    WHERE PRL_Products.ProductVersionID = @ProductversionID
	  AND PRL_Revision.StatusID in (@INTMOLPOR, @INTMOLPOSTPOR)
	ORDER BY PRL_Revision.PRLID DESC

	SELECT @SCMName =@SCMName + isnull(' ' + (select name from ProductVersionRelease with (nolock) where ID= @intCurrentReleaseID) , '')
		
	--moved the following out of the if statement so combined brand will display it too
	select @SCMName =@SCMName + isnull(' ' + KMAT, '')    
		from product_Brand 
		where ID=@p_ProductBrandID

	--date and revision will be filled in the ui
	
	RETURN @SCMName 

END


﻿
CREATE FUNCTION [dbo].[ufn_GetPlatformBaseUnitCount] (@p_PlatformID Int)
/* ************************************************************************************************
 * Purpose:	Get platform base unit count

 **************************************************************************************************/
RETURNS int
AS
BEGIN
	DECLARE @v_BaseUnitCount int

	SELECT  @v_BaseUnitCount = count(1)
	FROM
		Feature FE
		INNER JOIN Alias A ON FE.AliasID = A.AliasID
		INNER JOIN Platform_Alias PA ON PA.AliasID = A.AliasID
	WHERE 
		PA.PlatformID = @p_PlatformID AND ltrim(rtrim(A.Name)) <> ''

	RETURN @v_BaseUnitCount

END






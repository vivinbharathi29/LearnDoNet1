﻿CREATE FUNCTION [dbo].[ufnGetProductPrograms]
/*
-- Purpose:	get Programs associated to a product
-- Created: wgomero 04/13/2017
-- Updated: 
*/
(
	@ID int
)
RETURNS varchar(1000)
AS
BEGIN
-- Declare the return variable here
DECLARE @ProgramNameString  nvarchar(max)
SET @ProgramNameString = ''

SELECT @ProgramNameString = Coalesce(@ProgramNameString + ',', '') + cast(pg2.FullName as varchar) 
					FROM Product_Program pg INNER JOIN Program pg2 ON pg.ProgramId = pg2.ID
						WHERE pg.ProductVersionID = @ID;

--Remove leading comma	
SELECT @ProgramNameString = STUFF(@ProgramNameString,1,1,'')
	-- Return the result of the function
	RETURN @ProgramNameString
END
GO

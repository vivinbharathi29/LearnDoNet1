﻿

-- ====================================================================================================================================================================================
-- Author:		Patrick Ruland
-- Create date: 8/9/2011
-- Description:	Accepts a USER_ID and an optional PARAMETER denoting the ProductStatusIDs (Comma delimited string0 to INCLUDE
--				Returns a comma delimited string consisting of all applicable Product Versions of which the specified user has access
--
--				UPDATES 8/25/2011 - Added optional PARAMETER, AutoPublishRslOnly
--						9/01/2011 - Added Test for AutoPublishRslOnly NULL value (if true, sets to false)
-- ====================================================================================================================================================================================

CREATE FUNCTION [dbo].[GET_USER_PVLIST]
(
@USER_ID INT,
@PRODUCT_STATUS_IDS VARCHAR(100)=NULL,
@AUTO_PUBLISH_RSL_ONLY BIT=NULL
)
RETURNS VARCHAR(MAX) 
AS
BEGIN
	
	DECLARE @PVLIST VARCHAR(MAX)
	SET @PVLIST=''
	
	IF(LEN(ISNULL(@PRODUCT_STATUS_IDS,''))=0)
	BEGIN
		SET @PRODUCT_STATUS_IDS=''
		SELECT @PRODUCT_STATUS_IDS=dbo.CONCATENATE_ROW_COLUMN(ID,',',@PRODUCT_STATUS_IDS,0) FROM ProductStatus WITH(NOLOCK)
	END
	
	DECLARE @USER_PARTNER_ID INT
	DECLARE @USER_PARTNER_TYPE_ID INT

	SELECT @USER_PARTNER_ID=ISNULL(PartnerID,-1) FROM Employee WITH(NOLOCK) WHERE Active=1 AND ID=@USER_ID
	SELECT @USER_PARTNER_TYPE_ID=ISNULL(PartnerTypeID,-1) FROM Partner WITH(NOLOCK) WHERE Active=1 AND ID=@USER_PARTNER_ID

	IF(@USER_PARTNER_TYPE_ID!=-1)
	BEGIN
		IF(@USER_PARTNER_ID=1) -- INTERNAL HP, RETURN ALL
			IF(ISNULL(@AUTO_PUBLISH_RSL_ONLY,0)=0)
				SELECT @PVLIST=dbo.CONCATENATE_ROW_COLUMN(PV.ID,',',@PVLIST,0)
				FROM 
				ProductVersion PV WITH(NOLOCK) 
				WHERE 
				CHARINDEX(','+CONVERT(VARCHAR(10),PV.ProductStatusID)+',',','+@PRODUCT_STATUS_IDS+',')>0
				GROUP BY PV.ID
				ORDER BY PV.ID ASC	
			ELSE
				SELECT @PVLIST=dbo.CONCATENATE_ROW_COLUMN(PV.ID,',',@PVLIST,0)
				FROM 
				ProductVersion PV WITH(NOLOCK) 
				INNER JOIN
				ServiceFamilyDetails SFD WITH(NOLOCK)
				ON
				PV.ServiceFamilyPn=SFD.ServiceFamilyPn
				WHERE 
				CHARINDEX(','+CONVERT(VARCHAR(10),PV.ProductStatusID)+',',','+@PRODUCT_STATUS_IDS+',')>0
				AND
				ISNULL(SFD.AutoPublishRsl,0)=1--SFD.AutoPublishRsl=1
				GROUP BY PV.ID
				ORDER BY PV.ID ASC	
				
		ELSE -- ODM, OSSP, OR OTHER VENDOR, RETURN ALL APPLICABLE
			IF(ISNULL(@AUTO_PUBLISH_RSL_ONLY,0)=0)
				SELECT @PVLIST=dbo.CONCATENATE_ROW_COLUMN(PV.ID,',',@PVLIST,0)
				FROM 
				ProductVersion PV WITH(NOLOCK) 
				LEFT JOIN
				ProductVer_Partner PVP WITH(NOLOCK)
				ON
				PV.ID=PVP.ProductVersionID
				WHERE 
				(
				CHARINDEX(','+CONVERT(VARCHAR(10),PV.ProductStatusID)+',',','+@PRODUCT_STATUS_IDS+',')>0
				AND
				PV.PartnerID=@USER_PARTNER_ID
				)
				OR
				(
				CHARINDEX(','+CONVERT(VARCHAR(10),PV.ProductStatusID)+',',','+@PRODUCT_STATUS_IDS+',')>0
				AND			
				PVP.Status='A'
				AND
				PVP.PartnerID=@USER_PARTNER_ID
				)
				GROUP BY PV.ID
				ORDER BY PV.ID ASC			
			ELSE
				SELECT @PVLIST=dbo.CONCATENATE_ROW_COLUMN(PV.ID,',',@PVLIST,0)
				FROM 
				ProductVersion PV WITH(NOLOCK) 
				INNER JOIN
				ServiceFamilyDetails SFD WITH(NOLOCK)
				ON
				PV.ServiceFamilyPn=SFD.ServiceFamilyPn
				LEFT JOIN
				ProductVer_Partner PVP WITH(NOLOCK)
				ON
				PV.ID=PVP.ProductVersionID
				WHERE 
				(
				(
				CHARINDEX(','+CONVERT(VARCHAR(10),PV.ProductStatusID)+',',','+@PRODUCT_STATUS_IDS+',')>0
				AND
				PV.PartnerID=@USER_PARTNER_ID
				)
				OR
				(
				CHARINDEX(','+CONVERT(VARCHAR(10),PV.ProductStatusID)+',',','+@PRODUCT_STATUS_IDS+',')>0
				AND			
				PVP.Status='A'
				AND
				PVP.PartnerID=@USER_PARTNER_ID
				)
				)
				AND
				ISNULL(SFD.AutoPublishRsl,0)=1--SFD.AutoPublishRsl=1
				GROUP BY PV.ID
				ORDER BY PV.ID ASC			
			
	END

		
	RETURN @PVLIST

END




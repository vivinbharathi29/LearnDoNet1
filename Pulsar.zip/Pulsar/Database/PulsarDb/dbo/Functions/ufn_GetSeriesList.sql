﻿
CREATE FUNCTION [dbo].[ufn_GetSeriesList] (@p_ProductVersionID INT)
RETURNS VARCHAR(1000)
AS
BEGIN

DECLARE @v_SeriesTxt VARCHAR(1000)
SELECT @v_SeriesTxt = coalesce(@v_SeriesTxt + ', ', '') + series.name
FROM 
	series WITH(NOLOCK) INNER JOIN 
	product_brand WITH(NOLOCK) ON productbrandid = product_brand.id
WHERE productversionid = @p_ProductVersionID
ORDER BY series.name
RETURN @v_SeriesTxt 

END



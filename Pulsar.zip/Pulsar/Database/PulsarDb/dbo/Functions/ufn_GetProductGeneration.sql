﻿
CREATE FUNCTION [dbo].[ufn_GetProductGeneration] (@p_ProductVersionID INT)
RETURNS VARCHAR(1000)
AS
BEGIN
	declare @GenerationTxt VARCHAR(max)
	set @GenerationTxt = ''

	SELECT @GenerationTxt = case len(@GenerationTxt) when 0 then coalesce(pb.Generation, '') else @GenerationTxt + ', ' + coalesce(pb.Generation, '') end
	FROM 
		product_brand pb
	WHERE ProductVersionID = @p_ProductVersionID
	RETURN @GenerationTxt 
END



﻿CREATE FUNCTION [dbo].[RegexReplace]
(@input NVARCHAR (MAX), @pattern NVARCHAR (MAX), @replacement NVARCHAR (MAX))
RETURNS NVARCHAR (MAX)
AS
 EXTERNAL NAME [StringUtilities].[Microsoft.Samples.SqlServer.RegularExpression].[Replace]


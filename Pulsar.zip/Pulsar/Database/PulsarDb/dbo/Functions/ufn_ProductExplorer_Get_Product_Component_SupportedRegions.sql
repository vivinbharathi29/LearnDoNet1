﻿CREATE FUNCTION [dbo].[ufn_ProductExplorer_Get_Product_Component_SupportedRegions]
( 
/**************************************************************************************************
 * Purpose:		Make a delimited string of the Supported Regions or Image Locale for a productrelease/Component
 * Created By:	5/31/2016, Ywang, based on irs [ufn_makeComponentRegionsLocale]
 * Modified By:	
 **************************************************************************************************/
	@intProductversionReleaseID int,
	@intDeliverableVersionID int,
	@chrDelimiter varchar(10) = '',
	@intType int -- 0 = Supported Regions, 1 = Image Locale
)
RETURNS varchar(max) AS  
BEGIN 
	--set @CRLF = char(13)+char(10)
	if @chrDelimiter = ''
		set @chrDelimiter = ';'

	declare @chrList varchar(max)
	set @chrList = null

	select @chrList = COALESCE(@chrList + @chrDelimiter, '') + rtrim(r.Name) + '(' + rtrim(r.OptionConfig) + ')'
	from Product_Component_SupportedRegions pcs
		inner join Regions r on pcs.RegionID = r.ID
	where pcs.ProductversionReleaseID = @intProductversionReleaseID
		and pcs.DeliverableVersionID = @intDeliverableVersionID
		and pcs.TypeID = @intType
	order by r.Name

	if @chrList is null
		set @chrList = ''

	return (@chrList)
END
﻿CREATE FUNCTION [dbo].[ufn_ProductExplorer_makeComponentSupportedRegionHighlight]
/* ************************************************************************************************
 * Purpose:	return 1 if the PE side has different SupportedRegion(TypeID=0)/ImageLocale(TypeID=1) than Componentside and then it needs to be highlighted
 * Created By:	linshan 11/17/2017
 * Modified By:	
 **************************************************************************************************/
(@p_intDeliverableversionID int, 
@p_intPDID int,
@regionTypeID int
)
RETURNS int AS  
BEGIN 
	
	declare @productID int, @businessSegmentID int
	SELECT     @productID = pd.ProductversionReleaseID, @businessSegmentID = pv.BusinessSegmentID
	FROM         ProductDrop pd
	join ProductVersion_Release pvr on pd.ProductversionReleaseID = pvr.ID
	join ProductVersion pv on pvr.ProductVersionID = pv.ID
	where pd.ProductDropID = @p_intPDID
	
	declare @numberOfCompRegion int

	if (@regionTypeID = 0)
		  select	@numberOfCompRegion = count(1) from DeliverableVersion_Region dvr 
	      join Region_BusinessSegment rbs on dvr.RegionID = rbs.RegionID 
	      where DeliverableVersionID = @p_intDeliverableversionID and rbs.BusinessSegmentID = @businessSegmentID
	else
		select	@numberOfCompRegion = count(1) from DeliverableVersion_ImageLocale dvi
	      join Region_BusinessSegment rbs on dvi.RegionID = rbs.RegionID 
	      where DeliverableVersionID = @p_intDeliverableversionID and rbs.BusinessSegmentID = @businessSegmentID
	
	declare @numberOfPERegion int
	select @numberOfPERegion = count(1) from Product_Component_SupportedRegions 
		   where TypeID = @regionTypeID and DeliverableVersionID = @p_intDeliverableversionID AND ProductversionReleaseID = @productID 		

	if (@numberOfCompRegion <> @numberOfPERegion)
		 return 1
    if(@regionTypeID = 0) and 
		exists ( select RegionID from Product_Component_SupportedRegions where TypeID =0 and DeliverableVersionID = @p_intDeliverableversionID AND ProductversionReleaseID = @productID
						except
						select dvr.RegionID from DeliverableVersion_Region dvr 
						join Region_BusinessSegment rbs on dvr.RegionID = rbs.RegionID 
						where DeliverableVersionID = @p_intDeliverableversionID and rbs.BusinessSegmentID = @businessSegmentID
		) 
				return 1
	if exists ( select RegionID from Product_Component_SupportedRegions where TypeID =1 and DeliverableVersionID = @p_intDeliverableversionID AND ProductversionReleaseID = @productID
						except
						select dvi.RegionID from DeliverableVersion_ImageLocale dvi
						join Region_BusinessSegment rbs on dvi.RegionID = rbs.RegionID 
						where DeliverableVersionID = @p_intDeliverableversionID and rbs.BusinessSegmentID = @businessSegmentID
		)
			return 1
		
	
	return 0
END



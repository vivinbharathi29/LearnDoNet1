﻿/* ************************************************************************************************
 * Purpose:	Splite string by comma. [,]
 * Sample Code: 
DECLARE @str nvarchar(max)
set @str = '123,456,ccc'
select * from dbo.Split(@str)
 *	     
 * Return of Sample Code: 
123
456
ccc
 **************************************************************************************************/
CREATE FUNCTION [dbo].[Split]
(@input NVARCHAR (MAX))
RETURNS 
     TABLE (
        [StringElement] NVARCHAR (MAX) NULL)
AS
 EXTERNAL NAME [StringUtilities].[Microsoft.Samples.SqlServer.StringSplitter].[Split]


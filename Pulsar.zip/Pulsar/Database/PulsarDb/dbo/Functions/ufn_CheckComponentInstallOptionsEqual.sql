﻿CREATE FUNCTION [dbo].[ufn_CheckComponentInstallOptionsEqual]
(
/* ************************************************************************************************
 * Purpose:	given a ProductVersionReleaseID, return the records if the install options of component is different between component and product drop
 * Created By:	linshant 12/07/2016
 * Modified By:	
				linshant 12/04/2016 - Add to Product Explorer to consider Component Version's Destination Country/Region and Image Locale settings - PBI 146239
 **************************************************************************************************/
	@p_ProductVersionReleaseID int,
	@p_ComponentVersionID int
	
)
RETURNS bit AS 

BEGIN 
	Declare @recordCount int;
	With Query1 as (Select IOID from Product_Component_InstallOption where DeliverableVersionID = @p_ComponentVersionID and ProductversionReleaseID = @p_ProductVersionReleaseID),
	     Query2 as (Select InstallOptionID from ComponentVersion_InstallOption where ComponentVersionID = @p_ComponentVersionID)

	 Select @recordCount = count(1) From ((Select * from Query1 EXCEPT Select * from Query2)
						                  UNION ALL
						                  (Select * from Query2 EXCEPT Select * from Query1)) X 
		

	
	 If(@recordCount > 0) 
		Return 1

	 Return 0
	 
END
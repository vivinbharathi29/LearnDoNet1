﻿CREATE FUNCTION [dbo].[ufn_SetBGColor]
(@sColor varchar(10))

returns varchar(10)
as
begin
	if @sColor = '#CCCCCC'
		set @sColor = 'white'
	else
		set @sColor = '#CCCCCC'

	return (@sColor)
end 	


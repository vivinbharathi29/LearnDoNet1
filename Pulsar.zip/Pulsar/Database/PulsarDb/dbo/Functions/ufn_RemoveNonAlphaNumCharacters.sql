﻿CREATE FUNCTION [dbo].[ufn_RemoveNonAlphaNumCharacters](@Text VarChar(MAX))

RETURNS VARCHAR(MAX)

AS

BEGIN
	DECLARE @KeepValues AS VARCHAR(50)
    SET @KeepValues = '%[^a-zA-Z0-9 ]%'

    WHILE PatIndex(@KeepValues, @Text) > 0
        SET @Text = Stuff(@Text, PatIndex(@KeepValues, @Text), 1, '')

    RETURN @Text
END
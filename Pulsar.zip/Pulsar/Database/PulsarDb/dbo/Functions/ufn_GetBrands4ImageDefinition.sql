﻿
CREATE FUNCTION [dbo].[ufn_GetBrands4ImageDefinition] (@p_ImageDefinitionID INT)
RETURNS VARCHAR(8000)
AS
BEGIN

DECLARE @v_BrandList VARCHAR(8000)
SELECT @v_BrandList = coalesce(@v_BrandList + ', ', '') + b.name
FROM 
	ImageDefinitions d WITH(NOLOCK) join
	ImageDefinition_Brand ib WITH(NOLOCK) on ib.imagedefinitionid = d.id join
	Brand b WITH(NOLOCK) on ib.brandid = b.id
WHERE d.id = @p_ImageDefinitionID
ORDER BY b.name
RETURN @v_BrandList 

END



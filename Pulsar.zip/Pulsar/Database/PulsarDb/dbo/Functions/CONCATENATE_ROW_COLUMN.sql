﻿
-- ==========================================================================================
-- Author:		Patrick Ruland
-- Create date: 3/10/2011
-- Description:	Accepts a column value, delimiter, and accumulative delimited string
--				Returns the latest version of the string
-- ==========================================================================================
CREATE FUNCTION [dbo].[CONCATENATE_ROW_COLUMN]
(
@COLUMN_VALUE VARCHAR(MAX), @DELIMITER VARCHAR(10), @CURRENT_DELIMITED_STRING VARCHAR(MAX), @ADD_TO_BEGINNING BIT
)
RETURNS VARCHAR(MAX) 
AS
BEGIN
	
	DECLARE @RETURN_DELIMITED_STRING VARCHAR(MAX)
	
	IF(LEN(COALESCE(@CURRENT_DELIMITED_STRING,''))=0)
		SET @RETURN_DELIMITED_STRING=COALESCE(@COLUMN_VALUE,'')
	ELSE
	BEGIN
		IF(@ADD_TO_BEGINNING=1)
			SET @RETURN_DELIMITED_STRING=COALESCE(@COLUMN_VALUE,'')+COALESCE(@DELIMITER,'')+COALESCE(@CURRENT_DELIMITED_STRING,'')
		ELSE
			SET @RETURN_DELIMITED_STRING=COALESCE(@CURRENT_DELIMITED_STRING,'')+COALESCE(@DELIMITER,'')+COALESCE(@COLUMN_VALUE,'')
	END
		
	RETURN @RETURN_DELIMITED_STRING

END



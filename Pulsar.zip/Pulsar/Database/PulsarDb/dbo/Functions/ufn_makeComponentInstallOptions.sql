﻿CREATE FUNCTION [dbo].[ufn_makeComponentInstallOptions]
/**************************************************************************************************
 * Purpose:		Make a delimited string of the Install Option Combinations and Install Options for a Component, copied from the same function in IRS
 * Created By:	07/19/2016 SPathak
 * Modified By:	 04/25/2017 wgomero: added the function to the solution, for some reason it was excluded from the solution. 
 * Modified By:	 05/09/2017 PMV Pandian: Modified the logic of mapping with DeliverableVersion table to fetch the installoption for the Bug 129948 Task 130098
 **************************************************************************************************/
 (
	@intProductID int,
	@intComponentPassID int,
	@chrDelimiter varchar(10) = ''
)

RETURNS varchar(max)
AS
BEGIN
	--set @CRLF = char(13)+char(10)
	if @chrDelimiter = ''
		set @chrDelimiter = ';'
	declare
 @chrList varchar(max)
		set @chrList = null

	if exists(select 1 from DeliverableVersion where IRSID = @intComponentPassID) --component created in pulsar, use pulsar tables
	begin
		select @chrList = COALESCE(@chrList + @chrDelimiter, '') + rtrim(io.DMIString)
		from Product_Component_InstallOption pcio
			inner join CommonInstallOption io on io.Id = pcio.IOID
			inner join DeliverableVersion dv on dv.ID = pcio.DeliverableVersionID
		where pcio.ProductversionReleaseID = @intProductID
			and dv.IRSID = @intComponentPassID
	end
	else
	begin	
		
		select @chrList = COALESCE(@chrList + @chrDelimiter, '') + rtrim(io.Combination)
		from IRS_Product_Component_InstallOptionCombination pcio
			inner join View_InstallOptionCombination io on io.IOCombinationID = pcio.IOCombinationID
		where pcio.ProductID = @intProductID
			and pcio.ComponentPassID = @intComponentPassID
		--order by io.Combination

		select @chrList = COALESCE(@chrList + @chrDelimiter, '') + rtrim(io.DMIString)
		from IRS_Product_Component_InstallOption pcio
			inner join View_InstallOption io on io.IOID = pcio.IOID
		where pcio.ProductID = @intProductID
			and pcio.ComponentPassID = @intComponentPassID
		order by io.DMIString
	end

	if @chrList is null
		set @chrList = ''

	return (@chrList)
END
﻿CREATE FUNCTION [dbo].[ufn_ProductExplorer_makeComponentInstallOptionsHighlight]
/* ************************************************************************************************
 * Purpose:	given a PDID,deliverable versionID,  return 1 if the PE side has different IO than Componentside  and then it needs to be highlighted
 * Created By:	Ywang 12/21/2016, converted from irs [ufn_makeComponentInstallOptionsHighlight]
 * Modified By:	ywang 12/22/2016, if the @highlight is already set to 1, no need to execute the last block; save time for teh function to run
 **************************************************************************************************/
(@p_intDeliverableversionID int, 
@p_intPDID int
)
RETURNS int AS  
BEGIN 
	declare @highlight int	
	declare @productID int
	SELECT     @productID = ProductversionReleaseID
	FROM         ProductDrop 
	where ProductDropID = @p_intPDID
	
	declare @numberOfLCMInstallOptions int
	select @numberOfLCMInstallOptions = count(*)
	from componentversion_installOption where componentversion_installOption.ComponentVersionID = @p_intDeliverableversionID	
	
	declare @numberOfPEInstallOptions int
	select @numberOfPEInstallOptions = count(*)
	from Product_Component_InstallOption where DeliverableVersionID = @p_intDeliverableversionID AND ProductversionReleaseID = @productID
			
	set @highlight = 0
	if @numberOfLCMInstallOptions != @numberOfPEInstallOptions
	begin
		set @highlight = 1
	end
	else
	begin		
		if exists (select IOID from Product_Component_InstallOption where Product_Component_InstallOption.DeliverableVersionID = @p_intDeliverableversionID AND ProductVersionReleaseID = @productID
					except
					select InstallOptionID from componentversion_installOption where componentversion_installOption.ComponentVersionID = @p_intDeliverableversionID 
				 )
		begin
			if (@numberOfLCMInstallOptions > 0)
			begin
				set @highlight = 1
			end
		end
	end
	return (@highlight)
END


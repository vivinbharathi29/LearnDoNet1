﻿CREATE FUNCTION [dbo].[ufn_SCM_LCDM_CalculatePEDate]

-- =============================================
-- Author:		YWANG
-- Create date: 08/17/2017, for the ldm report PLC Import pbi 92361.
-- Modified By: YWang, 12/1/2017: change the calculation based on Susan Semin's feedback: 
--				The Commercial PE should be only 4 months before the EM and on the first of the month’, using 9/28/2018 as example, 
--					need to count the month of September as one of the months, so the 4 months will be September, August, July and June.  The PE would be 6/1.
-- =============================================
(
	@EMDate datetime,
	@BusinessID int
)
RETURNS Datetime

AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result datetime

	select @Result =case when @EMDate is null then null
				else case when @BusinessID = 2 then  DATEADD(mm, DATEDIFF(mm,0, dateadd(mm,-2,@EMDate)), 0) --consumer
					else DATEADD(mm, DATEDIFF(mm,0, dateadd(mm,-3,@EMDate)), 0) --others
					end
				end
	IF DATEDIFF(DAY,GETDATE(), @EMDate) > 0 AND  DATEDIFF(DAY,GETDATE(), @EMDate) < 6 --NEAR FUTURE
	BEGIN
		if @Result < getdate()
			select @Result = dateadd(dd,-1,@EMDate)
	END

	IF DATEDIFF(DAY,GETDATE(), @EMDate) >5 -- FUTURE
	BEGIN
		if @Result < getdate()
			select @Result = dateadd(dd,7,getdate())
	END
	
	-- Return the result of the function
	RETURN @Result
END

﻿CREATE FUNCTION [dbo].[ufn_GetTblVersionsTargetedOnProductForRoot] ( 
@p_DeliverableRootID INT, 
@p_ProductversionID  INT) 
RETURNS TABLE 
AS 
    RETURN 
      SELECT Count(1) AS noOfRows 
      FROM   Product_Deliverable pd WITH(NOLOCK) 
             JOIN DeliverableVersion v WITH(NOLOCK) 
               ON v.ID = pd.deliverableversionid 
      WHERE  v.deliverablerootid = @p_DeliverableRootID 
             AND pd.productversionid = @p_ProductversionID 
             AND targeted = 1 
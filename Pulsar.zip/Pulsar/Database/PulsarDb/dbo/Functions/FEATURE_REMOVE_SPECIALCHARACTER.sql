﻿-- =============================================
-- Author:		ADao
-- Create date: 11/07/2014
-- Description:	Remove special characters from Feature Name
-- =============================================
create function [dbo].[FEATURE_REMOVE_SPECIALCHARACTER](@Name varchar(1000))
returns varchar(1000)
as
begin
    declare @KeepValues as varchar(50)
    set @KeepValues = '%[^a-zA-Z0-9 ]%'
    while patIndex(@KeepValues, @Name) > 0
        Set @Name = stuff(@Name, patIndex(@KeepValues, @Name), 1, ' ')

    return @Name
end
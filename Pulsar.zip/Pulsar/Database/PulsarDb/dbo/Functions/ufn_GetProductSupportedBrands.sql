﻿CREATE FUNCTION [dbo].[ufn_GetProductSupportedBrands]
(
/* =============================================
   Purpose:		get the lis of Product Supported Brands in comma separated string
   Create :		10/24/2016: wgomero
   Modified By: 
   ============================================= */
	@ProductVersionID int
)
Returns varchar(MAX)

AS
BEGIN
	DECLARE @results AS Varchar(MAX) 

	SELECT  @results = ISNULL(COALESCE(@results + ',', '') + S.BIOSBranding, PB.BrandName) 
	FROM Product_Brand PB
	LEFT JOIN Series S ON PB.ID = S.ProductBrandID
	WHERE PB.ProductVersionID = @ProductVersionID

	return @results
END

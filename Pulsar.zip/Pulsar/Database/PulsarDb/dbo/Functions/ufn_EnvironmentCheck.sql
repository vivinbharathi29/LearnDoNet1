﻿CREATE FUNCTION [dbo].[ufn_EnvironmentCheck]()
RETURNS INT
AS
BEGIN

 IF (@@SERVERNAME!='TDCPULSARS02' AND @@SERVERNAME!='HOUPULSARS02') OR DB_NAME()!= 'PRS'
	BEGIN
		IF EXISTS (SELECT 1 FROM protected.Setting WHERE ([Name]='Environment' AND [Value]='1') OR ([Name]='Pulsar.ProductionInstance' AND [Value]='true'))
			RETURN CAST('READ CAREFULLY: ufn_EnvironmentCheck: Settings table has production values, but DB server name does not match production.' AS INT);
	END

RETURN 0;
END
﻿CREATE FUNCTION [dbo].[ufn_GetBrandLocalizationCustomStatus] 
	(
	@p_ProductBrandID INT,
	@p_LocalizationID INT
	)
RETURNS VARCHAR(6)
AS
BEGIN

DECLARE @v_RetVal VARCHAR(1000)

SELECT @v_RetVal = COALESCE(Keyboard, KWL, PowerCord, DocKits, RestoreMedia)
FROM ProdBrandCountry_Localization pbcl WITH(NOLOCK) INNER JOIN ProdBrand_Country pbc WITH(NOLOCK) ON pbc.ID = pbcl.ProdBrandCountryID
WHERE LocalizationID = @p_LocalizationID AND pbc.ProductBrandID = @p_ProductBrandID
GROUP BY Keyboard, KWL, PowerCord, DocKits, RestoreMedia

IF @v_RetVal IS NULL
	SET @v_RetVal = '&nbsp;'
ELSE
	SET @v_RetVal = 'X'
	
RETURN CAST(@v_RetVal AS VARCHAR(6))

END


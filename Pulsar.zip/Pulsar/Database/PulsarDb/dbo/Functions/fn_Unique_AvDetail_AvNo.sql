﻿

CREATE FUNCTION [dbo].[fn_Unique_AvDetail_AvNo](@AvNo VARCHAR(18))
RETURNS bit
AS 
BEGIN
	DECLARE @Count INT
	DECLARE @retval bit

	SELECT @Count = COUNT(1) 
	FROM   AvDetail a LEFT OUTER JOIN
	       AvDetail b WITH (NOLOCK) on a.AvDetailID = b.ParentId  
	WHERE  a.AvNo = @AvNo
	--AND    b.ParentId IS NULL 
	--AND    AvNo IS NOT NULL
	
	IF @Count > 1
	   SET @retval = 1 --FAIL
	ELSE
	   SET @retval = 1 --PASS
		
	RETURN @retval
END


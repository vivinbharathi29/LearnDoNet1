﻿-- =============================================
-- Author:		Kenneth M. Berntsen
-- Create date: 04/21/2011
-- Description:	Gets the Date for the requested Mileston
-- =============================================
CREATE FUNCTION [dbo].[ufnGetScheduledDate] 
(
	-- Add the parameters for the function here
	@p_ScheduleDefinitionDataId int,
	@p_ProductVersionId int
)
RETURNS datetime
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result datetime

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = COALESCE(actual_end_dt, projected_end_dt, por_end_dt)
	FROM
	    schedule_data sd WITH(NOLOCK) INNER JOIN
		schedule s WITH(NOLOCK) ON sd.schedule_id = s.schedule_id INNER JOIN
		product_release pr WITH(NOLOCK) ON s.product_release_id = pr.id
	WHERE
		schedule_definition_data_id = @p_ScheduleDefinitionDataId
	AND pr.productversionid = @p_ProductVersionID
	AND pr.releaseid = 1

	-- Return the result of the function
	RETURN @Result

END


﻿CREATE FUNCTION [dbo].[fn_GET_ODMSEPM_Details]
/* ************************************************************************************************
 * Purpose:		Return ODM SEPM Email Address
 * Created By:	Harris, Valerie (12/02/2015)  
 * Modified By: Harris, Valerie (12/04/2015) - Get ODM SEPM User from Product Version tables's ODMSEPMID field
 **************************************************************************************************/ 
(
	@ProductVersionID				bigint = 0,
	@ReturnType						varchar(50) = NULL
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- Declare variables: ---
	DECLARE @RETURNVALUE			varchar(max) = NULL
	DECLARE @GetValue				varchar(max) = NULL

	-- Return ODM SEPM's name, email or id from the Employee table: --- 
	SELECT @GetValue = (CASE @ReturnType 
						WHEN 'name' THEN ISNULL(RTRIM(LTRIM(o.name)),NULL)
						WHEN 'email' THEN ISNULL(RTRIM(LTRIM(o.email)),NULL)
						WHEN 'id' THEN ISNULL(CONVERT(varchar(100),o.id),NULL)
						ELSE NULL END)
	FROM (SELECT DISTINCT u.pid, u.pname, u.id, u.name, u.email, u.[role], u.partnerid
			FROM (SELECT DISTINCT v.ID as pid, v.DOTSName as pname, e.id, e.name, e.email, 'ODM SEPM' as [Role], e.partnerid
					FROM productversion v WITH (NOLOCK) 
					INNER JOIN employee e  WITH (NOLOCK) ON e.ID = v.ODMSEPMID
				) as u
		) as o 
	WHERE o.pid = @ProductVersionID

	-- Set/Return the value
	SET @RETURNVALUE = @GetValue

	RETURN @RETURNVALUE
END

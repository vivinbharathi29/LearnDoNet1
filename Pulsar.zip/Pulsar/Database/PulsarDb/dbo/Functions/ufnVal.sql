﻿
--Returns the leading numeric value from a string
--Passthrough is a parameter that allows you to specify if you just want to return the original value 
--Similar to the Val function in VB
--
--Example ufnVal ('1234abcd',0) returns '1234'
--Example ufnVal ('1234abcd',1) returns '1234abcd'
--
 
CREATE FUNCTION [dbo].[ufnVal]
(
	@String_Value VARCHAR(MAX),
	@Passthrough bit
)
	RETURNS varchar(max)
AS
BEGIN
	Declare @ReturnString as varchar(max)
	
	if @Passthrough!=0
		set @ReturnString = @String_Value
	else
		set @ReturnString = LEFT(@String_Value + ' ',PATINDEX('%[^0-9]%',@String_Value + ' ')-1)	
	
	return rtrim(@ReturnString)

END



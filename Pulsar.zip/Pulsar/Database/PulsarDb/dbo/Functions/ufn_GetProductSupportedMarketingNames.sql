﻿CREATE FUNCTION [dbo].[ufn_GetProductSupportedMarketingNames]  
(  
 @ProductVersionID int  
)  
Returns varchar(MAX)  
  
AS  
  
BEGIN  
  
DECLARE @results AS Varchar(MAX)   

Select  @results = COALESCE(@results + ',', '') + mktNameMaster
	from [Platform] ip with (nolock) inner join
		 ProductVersion_Platform pp with (nolock) on  pp.PlatformID = ip.platformid 
	where pp.ProductVersionID=@ProductVersionID
  
 
return @results  
  
END  

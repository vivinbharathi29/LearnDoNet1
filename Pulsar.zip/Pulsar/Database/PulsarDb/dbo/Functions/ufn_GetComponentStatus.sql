﻿CREATE FUNCTION [dbo].[ufn_GetComponentStatus]
(
/* =============================================
   Purpose:		get the lis of component status history
   Create :		10/24/2016: wgomero
   Modified By: 11/14/2016 wgomero: add query to the PMR server
				04/17/2018 wgomero: check for NULL Actual dates
   ============================================= */
	@DeliverableVersionID int,
	@LinkServerConnection int,
	@isPulsarstatus int = 0
)
Returns varchar(256)
AS
BEGIN
	DECLARE @results AS Varchar(MAX);

	SELECT  @results = ISNULL(COALESCE(@results + ',', '') +  Milestone + ' (' + ISNULL(CONVERT(VARCHAR(10), ACTUAL,110),'') + ')','') 
	FROM   deliverableschedule 
	WHERE deliverableversionid = @DeliverableVersionID;

SET @results = RTRIM(@results);

return @results;
END

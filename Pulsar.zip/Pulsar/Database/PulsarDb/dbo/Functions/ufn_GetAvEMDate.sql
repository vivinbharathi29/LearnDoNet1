﻿CREATE FUNCTION [dbo].[ufn_GetAvEMDate]
/* ************************************************************************************************
 * Purpose:	For a given productversionID, and Release retirive the EM date at the schedule tab so it can be easily coded in places need that value
 * Created By:	buidi 
 * Modified by: 
 **************************************************************************************************/
(
	@p_ProductVersionId int,
	@p_ReleaseID varchar(8000) = ''
)
RETURNS datetime
AS

BEGIN
	-- Declare the return variable here
	DECLARE @Result datetime

	IF (SELECT count(*) FROM Product_Release WHERE ProductversionID = @p_ProductVersionId and isnull(ProductVersionReleaseID,0) > 0) = 0
	Begin

		SELECT
			top 1
			@Result = sd.projected_start_dt    
		FROM	
			Schedule_Data sd with (NOLOCK) INNER JOIN
			Schedule s with (NOLOCK) ON sd.schedule_id = s.schedule_id INNER JOIN
			Product_Release pr with (NOLOCK) ON s.product_release_id = pr.ID INNER JOIN
			ProductVersion pv with (NOLOCK) ON pv.id = pr.productversionid
		WHERE pv.id = @p_ProductVersionID   
		and	(sd.item_description like 'end of manufacturing' ) 
		and s.active_yn = 'y'
		and sd.active_yn = 'y'
		order by sd.schedule_data_id asc

	End
	Else
	Begin
	
		Declare @Release table(ReleaseID int)
		INSERT INTO @Release
		Select Value from dbo.ufnSplit(@p_ReleaseID,',')

		SELECT @Result = MAX(sd.projected_start_dt)
		FROM	
			Schedule_Data sd with (NOLOCK) INNER JOIN
			Schedule s with (NOLOCK) ON sd.schedule_id = s.schedule_id INNER JOIN
			Product_Release pr with (NOLOCK) ON s.product_release_id = pr.ID INNER JOIN
			ProductVersion pv with (NOLOCK) ON pv.id = pr.productversionid INNER JOIN
			ProductVersion_Release pv_r with (NOLOCK) ON pv_r.ProductVersionID = pv.ID and pv_r.ReleaseID = pr.ProductVersionReleaseID INNER JOIN
			@Release r ON r.ReleaseID = pv_r.ReleaseID
		WHERE pv.id = @p_ProductVersionId   
		and	(sd.item_description like 'end of manufacturing' ) 
		and s.active_yn = 'y'
		and sd.active_yn = 'y'

	End

	RETURN @Result
END
﻿CREATE FUNCTION [dbo].[fnGetProductSystemBoardIDs]
/*
-- Purpose:	get Platform-SystemBoardIds associated to a product
-- Created: wgomero 10/20/2016
-- Updated: herb, 07/19/2017, PBI 142352: Add Comments field to Base Unit Groups for Pulsar Products
*/
(
	@ID int
)
RETURNS varchar(max)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @SystemBoardIDComments varchar(max)
	SELECT
	@SystemBoardIDComments = coalesce(@SystemBoardIDComments + case len(@SystemBoardIDComments) when 0 then '' else ', ' end, '') + (t.SystemID + isnull(SystemIdComments2,'') )
	FROM (
			SELECT DISTINCT 
				SystemId, 
				SystemIdComments2 = (case ltrim(SystemIdComments) when '' then '' else ' (' + ltrim(SystemIdComments) + ')' end) 
			FROM [Platform]
			WHERE Platformid IN (
					SELECT Platformid FROM ProductVersion_Platform
					WHERE ProductVersionID = @ID
				)
			AND ltrim(SystemID) <> ''
		) t
	-- Return the result of the function
	RETURN @SystemBoardIDComments

END

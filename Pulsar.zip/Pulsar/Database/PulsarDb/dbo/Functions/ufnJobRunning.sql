﻿-- =============================================
-- Author:		Kenneth Berntsen
-- Create date: 5/17/2010
-- Description:	Determines if a job in the JobDefinitions table is running
-- =============================================
CREATE FUNCTION [dbo].[ufnJobRunning] 
(
	-- Add the parameters for the function here
	@p_JobDefinitionId int
)
RETURNS bit
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result bit

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = CASE WHEN COALESCE(JobStart, LastRun, GETDATE()) <= COALESCE(JobStop, LastRun, GETDATE()) THEN 0 ELSE 1 END FROM JobDefinitions WITH(NOLOCK) WHERE ID = @p_JobDefinitionId

	-- Return the result of the function
	RETURN @Result

END


﻿
-- =============================================
-- Author:		Vinothkumar Periyasamy
-- Create date: 22/06/2017
-- Description:	To get the  ph days 
-- =============================================
--Select dbo.UDF_SelectPhWebDaysUntil (1,2)
Create FUNCTION [dbo].[UDF_SelectPhWebDaysUntil] (
@PVID int,
	@BID  int
)
RETURNS nvarchar(100)
AS BEGIN

DECLARE @Business  tinyint
DECLARE @DaysUntil int

SELECT @Business = DevCenter
FROM   ProductVersion with (NOLOCK)
WHERE  ID = @PVID

IF @Business = 1
  BEGIN
	SELECT @DaysUntil = DATEDIFF(d, GETDATE(), COALESCE(actual_end_dt, projected_end_dt))
	FROM   schedule_data sd with (NOLOCK) INNER JOIN
		   schedule s with (NOLOCK) ON sd.schedule_id = s.schedule_id INNER JOIN
           product_release pr with (NOLOCK) ON s.product_release_id = pr.id
    WHERE  schedule_definition_data_id = 60
    AND    pr.releaseid = 1 AND pr.ProductVersionId = @PVID
  END
ELSE
  BEGIN
	SELECT   @DaysUntil = DATEDIFF(d, GETDATE(), Last_Upd_Date)
	FROM     AvHistory with (NOLOCK)
	WHERE    AvChangeTypeID = 4 
	AND      ProductBrandID = @BID 
	ORDER BY Last_Upd_Date
  END
  
Return @DaysUntil 
   
END
﻿/**************************************************************************************************
** Author  : Shanmugaraj.M (auth\maniseka) 
** Description : Returns the dynamic query based on the inputs. 
** Date   : 04/10/2017  
**************************************************************************************************
** Change History  
**************************************************************************************************
** SNo   Date        Author  Description  
** --    --------   -------   -------------------------  
**  
****************************************************************************************************/

CREATE FUNCTION [dbo].[GetPaginationQuery] (@TableName     VARCHAR(MAX), 
                                           @PageNumber      INT, 
                                           @PageSize    INT, 
                                           @OrderByClause VARCHAR(200), 
                                           @WhereClause   VARCHAR(MAX)) 
RETURNS VARCHAR(MAX) 
AS 
  BEGIN 
      DECLARE @OutPutQuery VARCHAR(MAX) 
      DECLARE @Where VARCHAR(MAX) 
      IF ISNULL(@WhereClause,'') <>''
        BEGIN 
            SET @Where = ' WHERE ' + @WhereClause; 
        END 
      ELSE 
        BEGIN 
            SET @Where = '' 
        END 
	 IF @PageSize > 0 
	 BEGIN
		SET @OutPutQuery = 'SELECT * FROM ' + @TableName + 
             + ' CROSS JOIN(SELECT Count(*) AS TotalNoOfRows FROM ' + @TableName + ' '+ @Where + ')'
             + ' AS NoOfRows '+ @Where + 'ORDER BY ' + @OrderByClause 
             + ' OFFSET ' 
             + CONVERT(VARCHAR(max), ((@PageNumber - 1) * @PageSize)) 
             + ' ROWS FETCH NEXT ' 
             + CONVERT(VARCHAR(max), @PageSize) 
             + ' ROWS ONLY'; 
	END
	ELSE
	BEGIN
		SET @OutPutQuery = 'SELECT * FROM ' + @TableName + 
             + ' CROSS JOIN(SELECT Count(*) AS TotalNoOfRows FROM ' + @TableName + ' '+ @Where + ')'
             + ' AS NoOfRows '+ @Where + 'ORDER BY ' + @OrderByClause 
	END 
		 RETURN @OutPutQuery
  END
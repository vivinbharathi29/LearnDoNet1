﻿/**************************************************************************************************
** Author  : RajivGandhi.R(auth\rajamanr)
** Description :  To get the statusName
** Date   : 05/15/2017 
**************************************************************************************************
** Change History    
**************************************************************************************************
** SNo   Date        Author  Description    
** --    --------   -------   -------------------------    
**    
****************************************************************************************************/
CREATE FUNCTION [dbo].[Ufn_GetActionStatusName] 
(
	@StatusId INT
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @StatusName VARCHAR(MAX)
	SELECT @StatusName = Name FROM ACTIONSTATUS WHERE id=@StatusId

	RETURN @StatusName

END
﻿/******************************************************************************
**	File: dbo.Udf_GetDotsNamesByVersionId.sql
**	Name: Udf_GetDotsNamesByVersionId
**	Desc: To get all product names by versionId
**
**	Author: auth\rajamanr
**	Date: 16/04/2018
**********************************************************************************************
**	Change History
**********************************************************************************************
**	Date:		Author:			Description:
**	----------	------------------	-------------------------------------------
**********************************************************************************************/
CREATE FUNCTION Udf_GetDotsNamesByVersionId
(@VersionId INT)
RETURNS VARCHAR(MAX)
AS
BEGIN
DECLARE @ProductName VARCHAR(MAX)=''

select @ProductName = @ProductName +  DotsName  + ',' from (SELECT  v.DOTSName as DotsName
FROM 
	ProductFamily f with (NOLOCK)
	INNER JOIN ProductVersion v with (NOLOCK) ON v.productfamilyid = f.id
	INNER JOIN Product_Deliverable pd with (NOLOCK) ON pd.productversionid = v.id
	INNER JOIN employee e with (NOLOCK) ON e.id = v.sepmid
	LEFT OUTER JOIN teststatus t with (NOLOCK) ON t.id = pd.teststatusid
WHERE (v.active=1 or v.sustaining=1)
and Deliverableversionid = @VersionId
and v.FusionRequirements <> 1
union
Select v.DOTSName + ' (' + pvr.Name + ')'  as DotsName
FROM 
	ProductFamily f with (NOLOCK)
	INNER JOIN ProductVersion v with (NOLOCK) ON v.productfamilyid = f.id
	INNER JOIN Product_Deliverable pd with (NOLOCK) ON pd.productversionid = v.id 
	INNER JOIN Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
	INNER JOIN ProductVersionRelease pvr with (NOLOCK) on  pvr.id = pdr.ReleaseID
	INNER JOIN employee e with (NOLOCK) ON e.id = v.sepmid
	LEFT OUTER JOIN teststatus t with (NOLOCK) ON t.id = pdr.teststatusid
Where (v.active=1 or v.sustaining=1)
and Deliverableversionid = @VersionId
and v.FusionRequirements = 1
) x
order by DotsName

RETURN  @ProductName
END
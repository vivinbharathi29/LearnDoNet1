﻿-- =============================================
-- Author:		RajivGandhi.R(auth\rajamanr)
-- Create date: 09/05/2017
-- Description:	To get the list of postrtm status products
-- =============================================
CREATE FUNCTION [dbo].[Ufn_GetPostRTMProducts]
(
	@RootID int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @Product NVARCHAR(MAX)=''
	Select @Product = @Product + v.DOTSName + ','
	FROM product_delRoot pr with (NOLOCK), ProductVersion v WITH (NOLOCK)
	WHERE pr.deliverablerootid = @RootID
	AND pr.productversionid = v.id AND pr.PostRTMStatus=1
	ORDER BY v.DOTSName
	RETURN CASE WHEN LEN(@Product)>1 THEN SUBSTRING(@Product,0,LEN(@Product)-1) ELSE '' END
END

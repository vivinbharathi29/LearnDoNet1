﻿/**************************************************************************************************
** Author  : Shanmugaraj.M (auth\maniseka)    
** Description : Return the fusionrequirement bit. 
** Date   : 05/11/2017     
**************************************************************************************************
** Change History     
**************************************************************************************************
** SNo   Date        Author                              Description     
** --    --------   -------                             -------------------------     

****************************************************************************************************/

CREATE FUNCTION [dbo].[UFN_GetProductVersionName] (@ID INT) 
RETURNS NVARCHAR(MAX) 
AS 
  BEGIN 
      DECLARE @DOTSName NVARCHAR(MAX) 

      SELECT DISTINCT @DOTSName = v.DOTSName 
      FROM   ProductFamily AS f WITH (NOLOCK) 
             INNER JOIN ProductVersion AS v WITH (NOLOCK) 
                     ON f.ID = v.ProductFamilyID 
             LEFT JOIN Product_Brand AS pb WITH (NOLOCK) 
                    ON pb.ProductVersionID = v.ID 
             LEFT JOIN Brand AS b WITH (NOLOCK) 
                    ON b.ID = pb.BrandID 
      WHERE  v.ID = @ID 

      RETURN @DOTSName 
  END 
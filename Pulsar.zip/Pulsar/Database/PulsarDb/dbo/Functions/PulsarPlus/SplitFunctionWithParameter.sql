﻿CREATE FUNCTION [dbo].[SplitFunctionWithParameter]
/* ************************************************************************************************
 * Purpose:	This function is used to avoid dynamic queries
 * Created By:	11/10/2017 Valentina E
 * Modified By:	
 **************************************************************************************************/	
(@@InPut VARCHAR(MAX),
 @Delimiter VARCHAR(10)=','
)  
RETURNS @TempTable table  
 (  
 OPParam VARCHAR(MAX)  
 )  
as  
Begin  
 DECLARE @location varchar(MAX)  
 DECLARE @POS INT  
 DECLARE @LenDelim INT
 DECLARE @PosDelim INT
 SET @Delimiter = LTRIM(RTRIM(@Delimiter))

 SET @@InPut = @@InPut + @Delimiter 
 SET @POS = CHARINDEX(@Delimiter,@@InPut)  
 SET @LenDelim = LEN(@Delimiter)

 WHILE (@POS > 0)  
 BEGIN  
  INSERT INTO @TempTable  
  SELECT LTRIM(RTRIM(LEFT (@@InPut,@POS-1)))

  SET @PosDelim = @POS + @LenDelim - 1
  
  SET @@InPut = RIGHT(@@InPut, (LEN(@@InPut) - @PosDelim))

  SET @POS = CHARINDEX(@Delimiter,@@InPut)  
 END  
 RETURN   
END

GO
﻿-- ==========================================================================================
-- Author:		Patrick Ruland	
-- Create date: 4/6/2011
-- Description:	Returns the Product SKUs for any combination of the specified 
--				Family, Version, Brand , or SKU
-- ==========================================================================================
CREATE FUNCTION [dbo].[GET_PRODUCT_SKUS]
(
	@PRODUCT_FAMILY_ID INT=NULL, 
	@PRODUCT_VERSION_ID INT=NULL,
	@PRODUCT_BRAND_ID INT=NULL,
	@KMAT VARCHAR(18)=NULL,
	@PRODUCT_SKU VARCHAR(18)=NULL
)

RETURNS @DATASET TABLE 
(
	PFID INT,
	PVID INT, 
	PBID INT,
	KMAT VARCHAR(10), 
	ServiceFamilyPn VARCHAR(10),
	SKU VARCHAR(18), 
	GPGDescription VARCHAR(50)
)
AS
BEGIN
	    IF(LEN(ISNULL(@PRODUCT_SKU,''))>0)
			INSERT INTO @DATASET
			SELECT DISTINCT PF.ID, PV.ID, PB.ID, PB.KMAT, PV.ServiceFamilyPn, B2.PartNumber, MD2.GPGDescription
			FROM         
			dbo.ProductFamily AS PF WITH (NOLOCK) 
			INNER JOIN
            dbo.ProductVersion AS PV WITH (NOLOCK) 
            ON 
            PF.ID = PV.ProductFamilyID 
            INNER JOIN
            dbo.Product_Brand AS PB WITH (NOLOCK) 
            ON 
            PV.ID = PB.ProductVersionID 
            INNER JOIN
            DATAWAREHOUSE.dbo.iHUB_BillOfMaterial AS B WITH (NOLOCK) ON PB.KMAT = B.PartNumber INNER JOIN
            DATAWAREHOUSE.dbo.iHUB_MaterialDescription AS MD WITH (NOLOCK) ON B.ChildPartNumber = MD.PartNumber INNER JOIN
            DATAWAREHOUSE.dbo.iHUB_BillOfMaterial AS B2 WITH (NOLOCK) ON B2.ChildPartNumber = B.ChildPartNumber INNER JOIN
            DATAWAREHOUSE.dbo.iHUB_MaterialDescription AS MD2 WITH (NOLOCK) ON B2.PartNumber = MD2.PartNumber 
			WHERE     
			(CHARINDEX('-', B2.PartNumber, 1) = 0) AND (CHARINDEX('BU ', MD.GPGDescription, 1) = 1) AND (B2.PartNumber = @PRODUCT_SKU)
			
				    
	    ELSE
			INSERT INTO @DATASET
			SELECT DISTINCT
			PF.ID,
			PV.ID, 
			PB.ID,
			PB.KMAT, 
			PV.ServiceFamilyPn,
			B2.partnumber, 
			MD2.GPGDescription 
		FROM 
			ProductFamily PF WITH(NOLOCK)
			INNER JOIN 
			ProductVersion PV WITH(NOLOCK) 
			ON
			PF.ID=PV.ProductFamilyID
			INNER JOIN
			Product_Brand PB WITH(NOLOCK)
			ON
			PV.ID=PB.ProductVersionID
		LEFT JOIN
			DATAWAREHOUSE.dbo.iHUB_BillOfMaterial B WITH(NOLOCK)
			ON
			PB.KMAT=B.PartNumber
			INNER JOIN 
			DATAWAREHOUSE.dbo.iHUB_MaterialDescription MD WITH(NOLOCK)
			ON 
			B.ChildPartNumber = MD.PartNumber 
			INNER JOIN 
			DATAWAREHOUSE.dbo.iHUB_BillOfMaterial B2 WITH(NOLOCK)
			ON
			B2.ChildPartNumber = B.ChildPartNumber
			INNER JOIN
            DATAWAREHOUSE.dbo.iHUB_MaterialDescription AS MD2 WITH (NOLOCK) 
            ON 
            B2.PartNumber = MD2.PartNumber 			
			WHERE
			CHARINDEX('-',B2.PartNumber,1)=0 
			AND 
			CHARINDEX('BU ',MD.GPGDescription,1)=1	
			AND 
			PB.ID=COALESCE(@PRODUCT_BRAND_ID, PB.ID)
			AND 
			PV.ID=COALESCE(@PRODUCT_VERSION_ID, PV.ID)
			AND 
			PF.ID=COALESCE(@PRODUCT_FAMILY_ID, PF.ID)
			AND
			PB.KMAT=COALESCE(@KMAT, PB.KMAT)
			AND
			B2.PartNumber=COALESCE(@PRODUCT_SKU, B2.PartNumber)
	RETURN
	
END

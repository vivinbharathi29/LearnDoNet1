﻿

CREATE FUNCTION [dbo].[ufn_GetProductIsInProgram] (@ProductVersionID INT, @ProgramGroupID int)
RETURNS bit
AS
BEGIN
RETURN	(select cast(count(*) as bit) from program as p WITH(NOLOCK) join Product_Program as i WITH(NOLOCK) on i.ProgramID = p.ID where p.ProgramGroupID = @ProgramGroupID 
and i.productversionid =  @ProductVersionID   )
END



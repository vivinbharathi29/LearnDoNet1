﻿

CREATE FUNCTION [dbo].[fnServiceSpareDetailCheck](@HpPartNo VARCHAR(50), @PartnerID INT, @OdmPartNo VARCHAR(50))
RETURNS bit
AS 
BEGIN
	DECLARE @Count INT
	DECLARE @retval bit

	SELECT @Count = COUNT(1) FROM ServiceSpareDetail WHERE PartnerId = @PartnerID AND OdmPartNo = @OdmPartNo

	IF (@OdmPartNo IS NULL)
		SET @retval = 1
	ELSE IF (@Count > 1) --FAIL
		SET @retval = 0
	ELSE IF (@Count = 1) AND ((SELECT ID FROM ServiceSpareDetail WHERE PartnerId=@PartnerID AND HpPartNo=@HpPartNo) != (SELECT ID FROM ServiceSpareDetail WHERE PartnerId=@PartnerID AND OdmPartNo=@OdmPartNo)) --FAIL
		SET @retval = 0
	ELSE --PASSEND;
		SET @retval = 1
		
	RETURN @retval
END


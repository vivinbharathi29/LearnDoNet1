﻿
CREATE FUNCTION [dbo].[ufn_DelRootSupportedCountry_YN] (@p_DeliverableRootID INT, @p_CountryID INT)
RETURNS CHAR(1)
AS
BEGIN

DECLARE @v_Result CHAR(1)

IF EXISTS
(
	SELECT ID
	FROM 
		Language_DelRoot ldr WITH(NOLOCK)
	WHERE
		DeliverableRootID = @p_DeliverableRootID
	AND (LanguageID = @p_CountryID OR LanguageID = 58)
)
	BEGIN
		SET @v_Result = 'Y'
	END
ELSE
	BEGIN
		SET @v_Result = 'N'
	END 

RETURN @v_Result
END

﻿CREATE FUNCTION [dbo].[ufn_CheckComponentSupportedRegionEqual]
(
/* ************************************************************************************************
 * Purpose:	given a ProductVersionReleaseID, return the records if the Destination Country/Region and Image Locale of component is different between component and product drop
 * Created By:	linshant 11/27/2017
 * Modified By:	
				linshant 12/04/2016 - Add to Product Explorer to consider Component Version's Destination Country/Region and Image Locale settings - PBI 146239
 **************************************************************************************************/
	@p_ProductVersionReleaseID int,
	@p_ComponentVersionID int,
	@BusinessSegmentId int,
	@TypeId int
	
)
RETURNS bit AS 

BEGIN 
	Declare @recordCount int, @recordCountLocale int;

	With Query1 as (SELECT pcsr.RegionId FROM Product_Component_SupportedRegions pcsr 
					JOIN Region_BusinessSegment rbs ON pcsr.RegionId = rbs.RegionId
					WHERE pcsr.DeliverableVersionID = @p_ComponentVersionID and pcsr.ProductversionReleaseID = @p_ProductVersionReleaseID and pcsr.TypeId =@TypeId and rbs.BusinessSegmentId = @BusinessSegmentId),
	     Query2 as (SELECT dvr.RegionId FROM DeliverableVersion_Region dvr 
					JOIN Region_BusinessSegment rbs ON dvr.RegionId = rbs.RegionId
					WHERE @TypeId = 0 and dvr.DeliverableVersionID = @p_ComponentVersionID and rbs.BusinessSegmentId = @BusinessSegmentId 
					UNION
					SELECT dvi.RegionId FROM DeliverableVersion_ImageLocale dvi 
					JOIN Region_BusinessSegment rbs ON dvi.RegionId = rbs.RegionId
					WHERE @TypeId = 1 and dvi.DeliverableVersionID = @p_ComponentVersionID and rbs.BusinessSegmentId = @BusinessSegmentId)
		 
	 Select @recordCount = count(1) From ((SELECT * FROM Query1 EXCEPT SELECT * FROM Query2)
						                  UNION ALL
						                  (SELECT * FROM Query2 EXCEPT SELECT * FROM Query1)) X 
		
	
		
	 If(@recordCount > 0) 
		return 1

	 Return 0
	 
END
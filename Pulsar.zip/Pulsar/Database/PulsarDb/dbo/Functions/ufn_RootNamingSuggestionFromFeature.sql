﻿CREATE FUNCTION [dbo].[ufn_RootNamingSuggestionFromFeature]
(
	@featureId int
)
RETURNS varchar(256)
begin

DECLARE @RootNaming varchar(256)
SELECT @RootNaming=f.FeatureName
FROM Feature f
WHERE 
f.FeatureID=@featureId

SELECT
	@RootNaming = REPLACE(@RootNaming, ddv.Value, '')
FROM DropDownValue ddv
JOIN Feature_NameField fnf
	ON fnf.DropDownValueID = ddv.DropDownValueID
JOIN NamingStandard_Field nsf
	ON nsf.FieldID = fnf.FieldID
		AND nsf.UseInRoot = 0
		AND nsf.UseInFeature = 1
JOIN Feature f
	ON f.NamingStandardID = nsf.NamingStandardID
		AND f.FeatureID = fnf.FeatureID
WHERE f.FeatureID = @featureId

return @RootNaming
end

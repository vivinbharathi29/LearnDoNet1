﻿CREATE FUNCTION [dbo].[ufn_GetProductScheduleEMDate]
/* ************************************************************************************************
 * Purpose:	For a given productversionID, retirive the End of manufacturing date at the schedule tab so it can be easily coded in places need that value
 * Created By:	ywang, 2/4/2016, 
 * Modified by: 04/10/2018  buidi - RTP date is first one out of all releases
 **************************************************************************************************/
(
	@p_ProductVersionId int,
	@p_ReleaseID varchar(500) = ''
)
RETURNS datetime
AS

Begin
	DECLARE @Result datetime

	IF (SELECT count(*) FROM Product_Release WHERE ProductversionID = @p_ProductVersionId and isnull(ProductVersionReleaseID,0) > 0) = 0
	Begin

		SELECT @Result = ISNULL((
		(SELECT
			MAX(sd.projected_start_dt) as EOM    
		FROM	
			Schedule_Data sd with (NOLOCK) INNER JOIN
			Schedule s with (NOLOCK) ON sd.schedule_id = s.schedule_id INNER JOIN
			Product_Release pr with (NOLOCK) ON s.product_release_id = pr.ID INNER JOIN
			ProductVersion pv with (NOLOCK) ON pv.id = pr.productversionid
		WHERE pv.id =  @p_ProductVersionId   
		and  (sd.item_description like 'end of manufacturing' ) 
		AND s.active_yn = 'y'
		and sd.active_yn = 'y')
		), NULL)

	End
	Else
	Begin

		Declare @Release table(ReleaseID int)
		INSERT INTO @Release
		Select Value from dbo.ufnSplit(@p_ReleaseID,',')

		IF (SELECT COUNT(*) FROM @Release WHERE ReleaseID > 0) = 0
		Begin
			SELECT @Result = ISNULL((
			(SELECT
				EOM = MAX(sd.projected_start_dt)    
			FROM	
				Schedule_Data sd with (NOLOCK) INNER JOIN
					Schedule s with (NOLOCK) ON sd.schedule_id = s.schedule_id INNER JOIN
					Product_Release pr with (NOLOCK) ON s.product_release_id = pr.ID INNER JOIN
					ProductVersion pv with (NOLOCK) ON pv.id = pr.productversionid INNER JOIN
					ProductVersion_Release pv_r with (NOLOCK) ON pv_r.ProductVersionID = pv.ID AND pv_r.ReleaseID = pr.ProductVersionReleaseID 
			WHERE pv.id = @p_ProductVersionId   
					and  (sd.item_description like 'end of manufacturing' ) 
			   AND s.active_yn = 'y'
			   and sd.active_yn = 'y'
			   )
			), NULL)
		End
		ELSE
		Begin
			SELECT @Result = ISNULL((
			(SELECT
				EOM = MAX(sd.projected_start_dt)
			FROM	
				Schedule_Data sd with (NOLOCK) INNER JOIN
					Schedule s with (NOLOCK) ON sd.schedule_id = s.schedule_id INNER JOIN
					Product_Release pr with (NOLOCK) ON s.product_release_id = pr.ID INNER JOIN
					ProductVersion pv with (NOLOCK) ON pv.id = pr.productversionid INNER JOIN
					ProductVersion_Release pv_r with (NOLOCK) ON pv_r.ProductVersionID = pv.ID AND pv_r.ReleaseID = pr.ProductVersionReleaseID INNER JOIN
					@Release r ON r.ReleaseID = pv_r.ReleaseID
			WHERE pv.id = @p_ProductVersionId   
					and  (sd.item_description like 'end of manufacturing' ) 
			   AND s.active_yn = 'y'
			   and sd.active_yn = 'y'
			   )
			), NULL)
		End
	End

	Return @Result
End
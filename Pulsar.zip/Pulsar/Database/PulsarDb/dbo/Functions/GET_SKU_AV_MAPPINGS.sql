﻿

-- ================================================================================================
-- Author:		Patrick Ruland
-- Create date: 4/6/2011
-- Description:	Accepts a [SKU] and a [Flag] for denoting whether or not to concatenate the 
--			    related AV Qualifiers
--				Returns the appropriate AV Mappings (i.e. - those of which the SKU qualifies) 
--
-- UPDATES		4/12/2011, Patrick Ruland - Updated code block for returning individual AVs
--											(i.e. - not concatenated)
--
--				6/7/2011, Patrick Ruland - Fixed bug in the "ConcatenateAVs" code block to remove
--						  extraneous regions where AV(s) do not have a specific region in their
--						  naming convention (NEED TO VERIFY THIS AS THE CAUSE)
--
-- ================================================================================================
CREATE FUNCTION [dbo].[GET_SKU_AV_MAPPINGS]
(
	@SKU VARCHAR(18),
	@ConcatenateAVs BIT=1,
	@KMAT_PARAM VARCHAR(18)=NULL,
	@SFPN_PARAM VARCHAR(18)=NULL
)
RETURNS @DATASET TABLE
(
	ID INT IDENTITY(1,1),
	GeoId INT,
	RegionId INT, 
	RegionCode VARCHAR(10),
	SpareKitId INT, 
	SpareKitNo CHAR(10), 
	ServiceSpareKitMapId INT, 
	AVLIST VARCHAR(MAX)
)

AS
BEGIN
		DECLARE @SKU_REGION_CODE VARCHAR(10)
		DECLARE @SKU_AV_TABLE TABLE(AVNO VARCHAR(18))
		DECLARE @KMAT VARCHAR(18)
		DECLARE @SFPN VARCHAR(18)
		
		IF(LEN(ISNULL(@KMAT_PARAM,''))=0 OR LEN(ISNULL(@SFPN_PARAM,''))=0)
		BEGIN
			DECLARE @SKU_START_TABLE TABLE(KMAT VARCHAR(18), SFPN VARCHAR(18))

			INSERT INTO @SKU_START_TABLE SELECT DISTINCT KMAT, ServiceFamilyPn FROM dbo.GET_PRODUCT_SKUS(NULL,NULL,NULL,NULL,@SKU)
			SELECT @KMAT=KMAT FROM @SKU_START_TABLE
			SELECT @SFPN=SFPN FROM @SKU_START_TABLE	
		END
		ELSE
		BEGIN
			SET @KMAT=@KMAT_PARAM
			SET @SFPN=@SFPN_PARAM
		END
		
		
		DECLARE @AV_DATA TABLE(ID BIGINT IDENTITY(1,1), GEOID INT, REGIONID INT, REGIONCODE VARCHAR(10), SpareKitId INT, SpareKitNo CHAR(10), SSKMID INT, AvNo VARCHAR(15))
		DECLARE @AV_MAPPING TABLE(ID BIGINT, GEOID INT, REGIONID INT, REGIONCODE VARCHAR(10), SpareKitId INT, SpareKitNo CHAR(10), SSKMID INT, AvNoLIST VARCHAR(MAX))
		DECLARE @WORK_DATA TABLE(RegionCode VARCHAR(10), SpareKitId INT, SpareKitNo CHAR(10), ServiceSpareKitMapId INT, AVLIST VARCHAR(MAX))
		
			INSERT INTO @AV_DATA(RegionCode, SpareKitId, SpareKitNo, SSKMID, AvNo) 
			SELECT DISTINCT
				dbo.GET_SKU_AV_REGION_ID(@SKU,AvNo,0),
				map.SpareKitId,
				SpareKitNo,
				ServiceSpareKitMapId,
				AvNo
			FROM 
			   dbo.ServiceSpareKitMapAv m WITH(NOLOCK)
			   INNER JOIN
			   dbo.ServiceSpareKitMap map WITH(NOLOCK)
			   ON 
			   map.ID = m.ServiceSpareKitMapId
			   INNER JOIN
			   ServiceSpareKit SSK WITH(NOLOCK)
			   ON
			   map.SpareKitId=SSK.ID
			   INNER JOIN
			   ServiceSpareKit_ServiceFamily SSK_SF WITH(NOLOCK)
			   ON
			   SSK.ID=SSK_SF.SpareKitId
			WHERE 
			  map.KMAT = @KMAT
			  AND 
			  m.Status = 'A'
			  AND
			  SSK_SF.ServiceFamilyPn=@SFPN

			  
			/*
				CORRECTION TO BUG WITH REGARD TO NON REGION SPECIFIC AVs (POSSIBLE CAUSE)
			----------------------------------------------------------------------------------------------------
			*/			  
			 SET @SKU_REGION_CODE=dbo.GET_SKU_AV_REGION_ID(@SKU,NULL,0)
			 
			 INSERT INTO @SKU_AV_TABLE SELECT ENTITY_ID FROM dbo.GET_ENTITY_DESCENDANTS(@SKU,0,0,0)
			  			  
			  INSERT INTO @WORK_DATA
			  (
				RegionCode,
				SpareKitId, 
				SpareKitNo, 
				ServiceSpareKitMapId, 
				AVLIST		  
			  )			  
			  SELECT DISTINCT 
				A.REGIONCODE, A.SpareKitId, A.SpareKitNo, A.SSKMID, A.AvNo
				FROM
				(
					SELECT 
					SpareKitId, 
					SSKMID,
					COUNT(SSKMID) AS KIT_AV_COUNT,
					SUM(
						CASE LEN(LTRIM(RTRIM(ISNULL(SKU_AVS.AVNO,''))))
						WHEN 0 THEN 0
						ELSE 1
						END
						)
						AS
					SKU_AV_COUNT
					FROM 
					@AV_DATA SSKMAV
					LEFT JOIN
					@SKU_AV_TABLE SKU_AVS
					ON
					SSKMAV.AvNo=SKU_AVS.AVNO
					GROUP BY SpareKitId, SSKMID
				) MATCH_CHECK			  
				INNER JOIN
				@AV_DATA A 
				ON
				MATCH_CHECK.SpareKitId=A.SpareKitId
				AND
				MATCH_CHECK.SSKMID=A.SSKMID
				INNER JOIN
				@SKU_AV_TABLE B
				ON
				A.AvNo=B.AVNO
				WHERE
				MATCH_CHECK.KIT_AV_COUNT=MATCH_CHECK.SKU_AV_COUNT
				AND
				A.REGIONCODE=@SKU_REGION_CODE
				ORDER BY SpareKitNo ASC			  
			  
			  /*
			  ----------------------------------------------------------------------------------------------------
			  */
      
          IF(COALESCE(@ConcatenateAVs,1)=1)
          BEGIN -- RETURN COMMA DELIMITED LIST OF AVs, WHERE APPLICABLE
          
			  DECLARE @GEOID INT
			  DECLARE @REGIONID INT
			  DECLARE @REGIONCODE VARCHAR(10)
			  DECLARE @SpareKitId INT
			  DECLARE @SpareKitNo VARCHAR(18)
			  DECLARE @SSKMID INT
			  DECLARE @AVLIST VARCHAR(MAX)
		  
			  DECLARE MAP_CURSOR CURSOR LOCAL READ_ONLY FOR
			  SELECT DISTINCT RegionCode, SpareKitId, SpareKitNo, ServiceSpareKitMapId FROM @WORK_DATA
			  
			  OPEN MAP_CURSOR
			  FETCH NEXT FROM MAP_CURSOR INTO @REGIONCODE, @SpareKitId, @SpareKitNo, @SSKMID
			  
			  WHILE(@@FETCH_STATUS=0)
			  BEGIN
				SET @AVLIST=''

				SELECT @AVLIST=dbo.CONCATENATE_ROW_COLUMN(AVLIST,',',@AVLIST,0) FROM @WORK_DATA WHERE REGIONCODE=@REGIONCODE AND SpareKitId=@SpareKitId AND ServiceSpareKitMapId=@SSKMID

				INSERT INTO @AV_MAPPING(GEOID, REGIONID, REGIONCODE, SpareKitId, SpareKitNo, SSKMID, AvNoLIST)
				VALUES(@GEOID, @REGIONID, @REGIONCODE, @SpareKitId, @SpareKitNo, @SSKMID, @AVLIST)
				 
				FETCH NEXT FROM MAP_CURSOR INTO @REGIONCODE, @SpareKitId, @SpareKitNo, @SSKMID
			  END
			  
			  CLOSE MAP_CURSOR
			  DEALLOCATE MAP_CURSOR
			  
			  INSERT INTO @DATASET
			  (
				RegionCode,
				SpareKitId, 
				SpareKitNo, 
				ServiceSpareKitMapId, 
				AVLIST		  
			  )
			  SELECT DISTINCT
			  REGIONCODE, 
			  SpareKitId, 
			  SpareKitNo, 
			  SSKMID, 
			  AvNoLIST 
			  FROM 
			  @AV_MAPPING AVM 
			  ORDER BY SpareKitNo ASC


		END
		ELSE
		BEGIN -- RETURN INDIVIDUAL AVs (NOT CONCATENATED)
						
			 SET @SKU_REGION_CODE=dbo.GET_SKU_AV_REGION_ID(@SKU,NULL,0)
			 
			 INSERT INTO @SKU_AV_TABLE SELECT ENTITY_ID FROM dbo.GET_ENTITY_DESCENDANTS(@SKU,0,0,0)
			  			  
			  INSERT INTO @DATASET
			  (
				RegionCode,
				SpareKitId, 
				SpareKitNo, 
				ServiceSpareKitMapId, 
				AVLIST		  
			  )			  
			  SELECT RegionCode, SpareKitId, SpareKitNo, ServiceSpareKitMapId, AVLIST FROM @WORK_DATA ORDER BY SpareKitNo ASC
		END
		
	RETURN
	
  END



﻿CREATE FUNCTION [dbo].[ufn_GetComponentImageLocale]
(
/* =============================================
   Purpose:		get the lis of component Language Locale in comma separated string
   Create :		04/20/2018: wgomero
   Modified By: 
   ============================================= */
	@DeliverableVersionID int
)
Returns varchar(max)

AS

BEGIN
	DECLARE @results AS Varchar(MAX) 

	SELECT @results = COALESCE(@results + ',', '') + R.[Name] + ' (' + R.OptionConfig + ')' 
                      FROM Regions R 
                      WHERE R.active=1 AND R.OptionConfig NOT IN('','AC3') 
				                   AND R.ID IN(select RegionID from [dbo].[DeliverableVersion_ImageLocale] where deliverableVersionID = @DeliverableVersionID)
                      ORDER BY R.[Name];
	return @results

END
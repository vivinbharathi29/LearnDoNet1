﻿
CREATE FUNCTION [dbo].[ufn_GetAgancyStatusProductName] (@p_AgencyStatusID INT)
RETURNS VARCHAR(255)
AS
BEGIN
RETURN	(SELECT pv.dotsname as product_name
	FROM productfamily pf WITH(NOLOCK), productversion pv WITH(NOLOCK), agency_status ags  WITH(NOLOCK)
	where ags.product_version_id = pv.id 
	AND pv.productfamilyid = pf.id 
	AND ags.agency_Status_id = @p_AgencyStatusID)
END


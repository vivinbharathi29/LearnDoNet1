﻿/* ************************************************************************************************
 * Purpose:	Splite string by delimiter, return table with 2 columns.
 * Sample Code: 
DECLARE @str nvarchar(max)
set @str = 'aaa;123;456;ccc'
select * from dbo.ufnSplit(@str,';')
 *	     
 * Return of Sample Code: 
ID	Value
1	aaa
2	123
3	456
4	ccc
 **************************************************************************************************/
CREATE FUNCTION [dbo].[ufnSplit]
(
 @String NVARCHAR(MAX),
 @Delimiter NVARCHAR(10)
)
RETURNS @ValueTable TABLE (ID INT IDENTITY(1,1), [Value] NVARCHAR(MAX))
BEGIN
	DECLARE @NextString NVARCHAR(MAX)
	DECLARE @Pos INT
	DECLARE @NextPos INT
	DECLARE @CommaCheck NVARCHAR(1)
 
	 --Initialize
	 SET @NextString = ''
	 SET @CommaCheck = right(@String,1) 
 
	 --Check for trailing Comma, if not exists, INSERT
	 --if (@CommaCheck <> @Delimiter )
	 SET @String = @String + @Delimiter
 
	 --Get position of first Comma
	 SET @Pos = CHARINDEX(@Delimiter,@String)
	 SET @NextPos = 1
 
	 --Loop while there is still a comma in the String of levels
	 WHILE (@pos <>  0) BEGIN
		SET @NextString = SUBSTRING(@String,1,@Pos - 1)
 
		INSERT INTO @ValueTable ([Value]) VALUES (@NextString)
 
		SET @String = SUBSTRING(@String, @pos +1, LEN(@String))
  
		SET @NextPos = @Pos
		SET @pos  = CHARINDEX(@Delimiter, @String)
	 END
 
	RETURN
END

﻿
CREATE MESSAGE TYPE [SupplyChainRequest]  VALIDATION = WELL_FORMED_XML 
GO

CREATE CONTRACT [SupplyChainContractOneWay]  
(
	[SupplyChainRequest] SENT BY INITIATOR
)
GO


CREATE QUEUE SupplychainTargetQueue WITH STATUS = ON, ACTIVATION  
(
    STATUS = ON,
    PROCEDURE_NAME = usp_SSSB_ProcessSupplyChainRequest,
    MAX_QUEUE_READERS = 1,
    EXECUTE AS OWNER
), 
	POISON_MESSAGE_HANDLING (STATUS = ON) 
GO


CREATE SERVICE SupplyChainTargetService ON QUEUE SupplychainTargetQueue([SupplyChainContractOneWay])  
GO

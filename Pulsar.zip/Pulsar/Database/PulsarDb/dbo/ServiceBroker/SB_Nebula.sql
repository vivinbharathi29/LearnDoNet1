﻿
CREATE MESSAGE TYPE [NebulaFeed]
GO

CREATE CONTRACT [NebulaFeedOneWay]  
(
	[NebulaFeed] SENT BY INITIATOR
)
GO

CREATE ROUTE [NebulaFeedTargetServiceRoute]   WITH  SERVICE_NAME  = N'NebulaFeedTarget' ,  ADDRESS  = N'TCP://xxx.auth.hpicorp.net:4022' 
GO



/**********THESE ARE THE SETTING FROM THE NEBULA SIDE**************/
/*
CREATE MESSAGE TYPE [NebulaFeed] 
GO


CREATE QUEUE NebulaTargetQueue WITH STATUS = ON, ACTIVATION  
(
    STATUS = ON,
    PROCEDURE_NAME = <sp_name_here>,
    MAX_QUEUE_READERS = 1,
    EXECUTE AS OWNER
), 
	POISON_MESSAGE_HANDLING (STATUS = ON) 
GO

CREATE CONTRACT [NebulaContract]  
(
	[NebulaFeed] SENT BY INITIATOR
)
GO


CREATE SERVICE NebulaFeedTarget ON QUEUE NebulaTargetQueue(NebulaContract)  
GO

GRANT SEND ON SERVICE::NebulaFeedTarget TO PUBLIC;
GO



CREATE ENDPOINT NebulaSBEndpoint
	STATE=STARTED
		AS TCP ( LISTENER_PORT = 4022)
	FOR SERVICE_BROKER 	(
		AUTHENTICATION = WINDOWS,
		ENCRYPTION = DISABLED
		)
	GO


CREATE ROUTE NebulaInitiatorServiceRoute
WITH SERVICE_NAME = 'NoResponseInitiator',
ADDRESS = 'TCP://AGPULSARPROD.TEX.RD.HPICORP.NET:4022'
GO

--create LOGIN [AUTH\$pulsaritga002]  FROM WINDOWS; --test
--create LOGIN [AUTH\$pulsarpsql001]  FROM WINDOWS; --production
--GO

--GRANT CONNECT ON ENDPOINT::NebulaSBEndpoint TO [AUTH\$pulsaritga002] --test
--GRANT CONNECT ON ENDPOINT::NebulaSBEndpoint TO [AUTH\$pulsarpsql001] --production

*/
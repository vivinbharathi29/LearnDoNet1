﻿CREATE MESSAGE TYPE [CompRevUpdateRequest] VALIDATION = WELL_FORMED_XML 
GO

CREATE CONTRACT [CompRevUpdateContract]
(
	[CompRevUpdateRequest] SENT BY INITIATOR
)
GO

CREATE QUEUE CompRevUpdateTargetQueue WITH STATUS = ON , ACTIVATION 
(  
	STATUS = ON , 
	PROCEDURE_NAME = usp_SSSB_ProcessCompRevUpdateRequest,	
	MAX_QUEUE_READERS = 1 , 
	EXECUTE AS OWNER  
), 
	POISON_MESSAGE_HANDLING (STATUS = ON)  
GO

CREATE SERVICE CompRevUpdateProcessingService ON QUEUE CompRevUpdateTargetQueue(CompRevUpdateContract)	
GO
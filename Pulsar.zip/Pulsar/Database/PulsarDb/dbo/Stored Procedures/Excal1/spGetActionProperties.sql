﻿CREATE PROCEDURE [dbo].[spGetActionProperties]
/* ************************************************************************************************
 * Purpose:
 * Created By:	
 * Modified By:	08/11/2017 wgomero: PBI 93328 add AVRequired and QualificationRequired fields
				08/18/2017 shraddha: PBI 93230 Add the Target Approval date and the check box for Important
				08/22/2017 buidi PBI91714 add 4 attachments
				05/16/2018 wgomero BUG 206243: Production Ticket 15480:  Cannot approve multiple DCR becuase Details returns NULL and it cannot be replaced
  **************************************************************************************************/
(@ID int)
AS SELECT  i.DisplayOrder, v.dotsname,v.typeid,v.PMID,v.SMID, v.PDEID,v.OnlineReports, i.ActionRoadmapID, isnull(i.NA,0) as NA, isnull(i.LA,0) as LA, i.CKK, i.APD, i.EMEA, i.Justification, i.Summary, i.Created, i.CategoryID, i.CoreTeamRep, i.OnStatusReport, i.PreinstallOwnerID,CommodityChange, ImageChange,SKUChange,ReqChange,BiosChange,OtherChange,DocChange,PendingImplementation,
                      i.duration, i.Submitter,i.SubmitterID, i.Notify, i.deliverableversionid, i.ProductVersionID, i.Type, i.Status, i.OwnerID, i.Sponsorid, i.TargetDate, i.ActualDate, i.ECNDate, i.Description, i.Actions, i.Resolution, i.Distribution, i.AvailableForTest, i.AvailableNotes, i.Commercial, i.consumer, i.smb,
                      i.BTODate, i.CTODate, i.RemoveChange, i.ModifyChange, i.AddChange, i.GCD, i.Priority, i.AffectsCustomers, i.ReleaseNotification, i.Americas, i.APJ, i.Details,'', i.SwChange, i.IDChange,i.DeliverableRootID, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, v.PCID, i.SpareKitPn, i.SubAssemblyPn, 
                      i.InventoryDisposition, i.InitiatedBy, i.QSpecSubmittedDt, i.CompEcoSubmittedDt, i.CompEcoNo, i.SaEcoSubmittedDt, i.SaEcoNo, i.SpsEcoSubmittedDt, i.SpsEcoNo, v.TDCCMID, v.ID, convert(varchar(10), StatusNotesUpdatedDt, 101) as StatusNotesUpdatedDt, OriginalTargetDt, StatusNotes, RTPDate, 
					  RASDiscoDate, AVRequired, QualificationRequired, TargetApprovalDate, Important, isnull(i.Attachment1,'') as Attachment1, isnull(i.Attachment2,'') as Attachment2, isnull(i.Attachment3,'') as Attachment3, isnull(i.Attachment4,'') as Attachment4, isnull(i.Attachment5,'') as Attachment5,i.ProductVersionRelease,i.CategoryBiosChange
FROM         dbo.DeliverableIssues i with (NOLOCK) INNER JOIN
                      dbo.ProductVersion v with (NOLOCK) ON i.ProductVersionID = v.ID
WHERE     (i.ID = @ID)

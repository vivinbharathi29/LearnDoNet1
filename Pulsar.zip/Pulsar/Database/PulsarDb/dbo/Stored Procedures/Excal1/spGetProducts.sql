﻿-- =================================================================
-- Update: Changed to new OUTER JOIN syntax - Paul Sanchez 3/11/2014
-- =================================================================
CREATE PROCEDURE [dbo].[spGetProducts]
	@Type int = -1
AS

/******************************************************************************
**	File: dbo.spGetProducts.sql
**	Name: spGetProducts
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		    Author:				Description:
**	----------	------------------	-------------------------------------------
**  14//05/2018		Aashish			 Added set nocount. Filtered the table before joining.

*******************************************************************************/

SET NOCOUNT ON
IF @Type=0
	SELECT
		v.ID AS ID,
		v.productName AS Name,
		v.Version AS Version,
		e.Name AS PM,
		e.ID as PMID,
		v.Distribution,
		v.OnCommodityMatrix,
		v.PRDReleased,
		v.PDDReleased,
		v.OnlineReports,
		v.ProductStatusID,
		v.AllowDCR,
		v.StreetName,
		v.Brands,
		v.SystemBoardID,
		v.PartnerID,
		v.PreinstallTeam,
		v.TypeID,
		e2.Name AS SEPM,
		v.Division,
		v.Sustaining,
		v.DevCenter,
		c.name as DevCenterName,
		v.ReleaseTeam,
		v.Active,
		e2.Email AS SEPMMail,
		e2.ID AS SEPMID,
		e3.Name AS SM,
		e3.Email AS SMMail,
		e3.ID AS SMID,
		v.ProductFilePath,
		v.PDDPath,
		v.SCMPath,
		v.ProgramMatrixPath,
		v.STLStatusPath,
		p.Name AS Partner,
		sepe.name AS SEPE,
		sepe.Email AS SEPEMail,
		sepe.ID AS SEPEID,
		pinpm.name AS PINPM,
		pinpm.Email as PINPMMail,
		pinpm.id as PINPMID,
		setl.name AS SETL,
		setl.email AS SETLMail,
		setl.id AS SETLID
	FROM
		ProductFamily f with (NOLOCK)  
		INNER JOIN 
		(SELECT ID ,
				productName,
				Version,
				Distribution,
				OnCommodityMatrix,
				PRDReleased,
				PDDReleased,
				OnlineReports,
				ProductStatusID,
				AllowDCR,
				StreetName,
				Brands,
				SystemBoardID,
				PartnerID,
				PreinstallTeam,
				TypeID,
				Division,
				Sustaining,
				DevCenter,
				ReleaseTeam,
				Active,
				ProductFilePath,
				PDDPath,
				SCMPath,
				ProgramMatrixPath,
				STLStatusPath,
				productfamilyid,
				pmid,
				sepmid,
				smid,
				sepe,
				pinpm,
				setestlead,
				dotsname
		FROM ProductVersion with (NOLOCK) WHERE (Active = 1 OR Sustaining = 1)) V
		ON f.id = v.productfamilyid
		INNER JOIN Partner p with (NOLOCK) ON v.partnerid = p.id
		LEFT OUTER JOIN DevCenter c with (NOLOCK) ON c.ID = v.devcenter  
		INNER JOIN Employee e with (NOLOCK) ON e.id = v.pmid
		INNER JOIN Employee e2 with (NOLOCK) ON e2.id = v.sepmid
		INNER JOIN Employee e3 with (NOLOCK) ON e3.id = v.smid
		LEFT OUTER JOIN Employee sepe with (NOLOCK) ON sepe.id = v.sepe
		LEFT OUTER JOIN Employee pinpm with (NOLOCK) ON pinpm.id = v.pinpm
		LEFT OUTER JOIN Employee setl with (NOLOCK) ON setl.id = v.setestlead
	--WHERE (v.Active = 1 OR v.Sustaining = 1)
	ORDER BY
		v.dotsname

ELSE IF @Type = -1
	SELECT
		v.ID AS ID,
		v.productName AS Name,
		v.Version AS Version,
		e.Name AS PM,
		e.ID as PMID,
		v.Distribution,
		v.OnCommodityMatrix,
		v.PRDReleased,
		v.PDDReleased,
		v.OnlineReports,
		v.ProductStatusID,
		v.AllowDCR,
		v.StreetName,
		v.Brands,
		v.SystemBoardID,
		v.PartnerID,
		v.PreinstallTeam,
		v.TypeID,
		e2.Name AS SEPM,
		v.Division,
		v.Sustaining,
		v.DevCenter,
		c.name as DevCenterName,
		v.Active,
		e2.Email AS SEPMMail,
		e2.ID AS SEPMID,
		e3.Name AS SM,
		e3.Email AS SMMail,
		e3.ID AS SMID,
		v.ProductFilePath,
		v.PDDPath,
		v.SCMPath,
		v.ProgramMatrixPath,
		v.STLStatusPath,
		p.Name AS Partner,
		sepe.name AS SEPE,
		sepe.Email AS SEPEMail,
		sepe.ID AS SEPEID,
		pinpm.name AS PINPM,
		pinpm.Email as PINPMMail,
		pinpm.id as PINPMID,
		setl.name AS SETL,
		setl.email AS SETLMail,
		setl.id AS SETLID
	FROM
		ProductFamily f with (NOLOCK)
		INNER JOIN (SELECT ID ,
				productName,
				Version,
				Distribution,
				OnCommodityMatrix,
				PRDReleased,
				PDDReleased,
				OnlineReports,
				ProductStatusID,
				AllowDCR,
				StreetName,
				Brands,
				SystemBoardID,
				PartnerID,
				PreinstallTeam,
				TypeID,
				Division,
				Sustaining,
				DevCenter,
				ReleaseTeam,
				Active,
				ProductFilePath,
				PDDPath,
				SCMPath,
				ProgramMatrixPath,
				STLStatusPath,
				productfamilyid,
				pmid,
				sepmid,
				smid,
				sepe,
				pinpm,
				setestlead,
				dotsname
		FROM ProductVersion with (NOLOCK) WHERE (Active = 1 OR Sustaining = 1) and TypeID <> 2) V ON f.id = v.productfamilyid
		INNER JOIN Partner p with (NOLOCK) ON v.partnerid = p.id
		LEFT OUTER JOIN DevCenter c with (NOLOCK) ON c.ID = v.devcenter
		INNER JOIN Employee e with (NOLOCK) ON e.id = v.pmid
		INNER JOIN Employee e2 with (NOLOCK) ON e2.id = v.sepmid
		INNER JOIN Employee e3 with (NOLOCK) ON e3.id = v.smid
		LEFT OUTER JOIN Employee sepe with (NOLOCK) ON sepe.id = v.sepe
		LEFT OUTER JOIN Employee pinpm with (NOLOCK) ON pinpm.id = v.pinpm
		LEFT OUTER JOIN Employee setl with (NOLOCK) ON setl.id = v.setestlead
	--WHERE (v.Active = 1 OR v.Sustaining = 1)
	--and TypeID <> 2
	ORDER BY
		v.dotsname
else
	SELECT
		v.ID AS ID,
		v.productName AS Name,
		v.Version AS Version,
		e.Name AS PM,
		e.ID as PMID,
		v.Distribution,
		v.OnCommodityMatrix,
		v.PRDReleased,
		v.PDDReleased,
		v.OnlineReports,
		v.ProductStatusID,
		v.AllowDCR,
		v.StreetName,
		v.Brands,
		v.SystemBoardID,
		v.PartnerID,
		v.PreinstallTeam,
		v.TypeID,
		e2.Name AS SEPM,
		v.Division,
		v.Sustaining,
		v.DevCenter,
		c.name as DevCenterName,
		v.Active,
		e2.Email AS SEPMMail,
		e2.ID AS SEPMID,
		e3.Name AS SM,
		e3.Email AS SMMail,
		e3.ID AS SMID,
		v.ProductFilePath,
		v.PDDPath,
		p.Name AS Partner,
		sepe.name AS SEPE,
		sepe.Email AS SEPEMail,
		sepe.ID AS SEPEID,
		pinpm.name AS PINPM,
		pinpm.Email as PINPMMail,
		pinpm.id as PINPMID,
		setl.name AS SETL,
		setl.email AS SETLMail,
		setl.id AS SETLID
	FROM
		ProductFamily f with (NOLOCK)
		INNER JOIN (SELECT ID ,
				productName,
				Version,
				Distribution,
				OnCommodityMatrix,
				PRDReleased,
				PDDReleased,
				OnlineReports,
				ProductStatusID,
				AllowDCR,
				StreetName,
				Brands,
				SystemBoardID,
				PartnerID,
				PreinstallTeam,
				TypeID,
				Division,
				Sustaining,
				DevCenter,
				ReleaseTeam,
				Active,
				ProductFilePath,
				PDDPath,
				SCMPath,
				ProgramMatrixPath,
				STLStatusPath,
				productfamilyid,
				pmid,
				sepmid,
				smid,
				sepe,
				pinpm,
				setestlead,
				dotsname
		FROM ProductVersion with (NOLOCK) WHERE (Active = 1 OR Sustaining = 1) and TypeID=@Type) V ON f.id = v.productfamilyid
		INNER JOIN Partner p with (NOLOCK) ON v.partnerid = p.id
		LEFT OUTER JOIN DevCenter c with (NOLOCK) ON c.ID = v.devcenter
		INNER JOIN Employee e with (NOLOCK) ON e.id = v.pmid
		INNER JOIN Employee e2 with (NOLOCK) ON e2.id = v.sepmid
		INNER JOIN Employee e3 with (NOLOCK) ON e3.id = v.smid
		LEFT OUTER JOIN Employee sepe with (NOLOCK) ON sepe.id = v.sepe
		LEFT OUTER JOIN Employee pinpm with (NOLOCK) ON pinpm.id = v.pinpm
		LEFT OUTER JOIN Employee setl with (NOLOCK) ON setl.id = v.setestlead
	--WHERE (v.Active = 1 OR v.Sustaining = 1)
	--and TypeID=@Type
	ORDER BY
		v.dotsname
SET NOCOUNT OFF



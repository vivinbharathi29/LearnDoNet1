﻿CREATE PROCEDURE [dbo].[spAddApprover]
/* ************************************************************************************************
 * Purpose:	  Add DCR approvers
 * Created By:	
 * Modified By: 05/31/2017 wgomero, If the DCR Submitter is on the approval chain then show that user as approving the DCR
  **************************************************************************************************/
(
	@ActionID int,
	@ApproverID int,
	@Role VARCHAR(300) = NULL
)
AS

DECLARE @SubmitterID int
SET @SubmitterID = 0;
SELECT @SubmitterID = SubmitterID FROM DeliverableIssues WITH (NOLOCK) WHERE SubmitterID = @ApproverID AND ID = @ActionID;

IF ((SELECT COUNT(1) FROM ActionApproval with (NOLOCK) WHERE ActionID = @ActionID AND ApproverID = @ApproverID) = 0)
BEGIN
   IF (@SubmitterID = 0)
	   BEGIN
		  Insert ActionApproval(ActionID, ApproverID, Status, Role)
		  Values(@ActionID,@ApproverID,1,@Role)
	   END
    ELSE
	   BEGIN
		  Insert ActionApproval(ActionID, ApproverID, Status, Updated, Comments, Role)
		  Values(@ActionID ,@ApproverID, 2, getdate(), 'Approved by submitter', @Role)
	   END
END



﻿-- =================================================================
-- Update: Changed to new OUTER JOIN syntax - Paul Sanchez 3/11/2014
-- Update: Changed to INNER JOIN syntax - Kenneth Berntsen 3/19/2014
-- =================================================================
CREATE PROCEDURE [dbo].[spGetProductMilestoneDate]
(
	@ProdID int,
	@MilestoneID int
)
 AS


Select coalesce(actual_start_dt, projected_start_dt,por_start_dt) as MilestoneDate
from product_release pr WITH (NOLOCK)
INNER JOIN schedule s WITH (NOLOCK) ON s.product_release_id = pr.id
INNER JOIN schedule_data sd WITH (NOLOCK) ON sd.schedule_id = s.schedule_id
where pr.productversionid = @ProdID
and releaseid = 1
and schedule_definition_data_id = @MilestoneID


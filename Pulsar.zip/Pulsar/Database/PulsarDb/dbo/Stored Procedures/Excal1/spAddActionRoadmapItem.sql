﻿/**************************************************************************************************    
** Author  :       
** Description :           
** Date   :    
**************************************************************************************************    
** Change History           
**************************************************************************************************    
** SNo   Date        Author                  Description           
** --    --------   -------                  -------------------------           
 ** 1    27/12/2018  Santhana K				Changed the text Data type to Varchar(max) for @Details
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spAddActionRoadmapItem]

(
	@ProductVersionID int,
	@OwnerID int,
	@ActionStatusID int,
	@Summary varchar(256),
	@Timeframe varchar(30),
	@TimeFrameNotes varchar(500),
	@DisplayOrder int,
	@Notes varchar(80),
	@Details Varchar(max),
	@NewID int output
)

AS

Insert into ActionRoadmap(ProductVersionID,OwnerID, ActionStatusID,Summary,Timeframe,TimeframeNotes, DisplayOrder,Notes,Details)
Values(@ProductVersionID,@OwnerID, @ActionStatusID,@Summary,@Timeframe,@Timeframenotes, @DisplayOrder,@Notes,@Details)

Select @NewID = SCOPE_IDENTITY()

GO



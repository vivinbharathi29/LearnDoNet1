﻿

CREATE PROCEDURE [dbo].[spGetTargetNotes]
 (
  @ProductID int,
  @DelId int
 
 )
 AS
Select TargetNotes, ID, OOCRelease
FROM Product_Deliverable with (NOLOCK)
WHERE ProductVersionID = @ProductID
AND DeliverableVersionID = @DelID




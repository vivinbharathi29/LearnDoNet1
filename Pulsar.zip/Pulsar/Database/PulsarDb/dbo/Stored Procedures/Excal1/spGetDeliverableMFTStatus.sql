﻿
CREATE PROCEDURE [dbo].[spGetDeliverableMFTStatus]
(
	@VersionID int
)
AS

SELECT        
	s.StatusID, 
	s.Description AS status, 
	v.MFTJobID, 
	v.MFTNotifySubmitter, 
	v.SubmitterID, 
	e.Name AS Submitter, 
	e.Email AS SubmitterEmail, 
	s.Constant AS MFTStatusConstant, 
	i.Comments, 
	v.ImagePath, 
	v.IRSPath
FROM
	DeliverableVersion AS v WITH (nolocK) INNER JOIN
    IRS_Component_Download AS i WITH (nolock) ON v.MFTJobID = i.JobID INNER JOIN
    IRS_Status AS s WITH (nolock) ON i.StatusID = s.StatusID INNER JOIN
    Employee AS e WITH (nolock) ON v.SubmitterID = e.ID
WHERE        
	(v.ID = @VersionID)

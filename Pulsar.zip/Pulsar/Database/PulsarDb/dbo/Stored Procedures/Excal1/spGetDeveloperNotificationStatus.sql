﻿CREATE PROCEDURE [dbo].[spGetDeveloperNotificationStatus]
(
	@PDID int,
	@PDRID int = 0
)
AS

if @PDRID = 0 
begin
	Select DeveloperNotificationStatus, DeveloperTestStatus 
	from Product_Deliverable with (NOLOCK)
	Where ID = @PDID
end
else
begin
	Select DeveloperNotificationStatus, DeveloperTestStatus 
	from Product_Deliverable_Release with (NOLOCK)
	Where ID = @PDRID
end
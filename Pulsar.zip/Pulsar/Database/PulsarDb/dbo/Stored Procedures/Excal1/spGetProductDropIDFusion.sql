﻿
CREATE PROCEDURE [dbo].[spGetProductDropIDFusion]
(
	@Name varchar(128)

)
AS

	Select ProductDropID
	from irs_ProductDrop WITH (NOLOCK)
	where name = @Name


﻿

/****** Object:  Stored Procedure dbo.spAddCategory    Script Date: 9/26/00 7:13:22 PM ******/
CREATE PROCEDURE [dbo].[spAddCategory]
 (
  @CatName varchar(50),
  @CatID int output
 )
As
 /* set nocount on */
 INSERT Category(Name)
 VALUES(@CatName) 
 select @CatID = (SELECT Max(ID)
                                      FROM Category  WITH (NOLOCK)
                                      WHERE Name = @CatNAme)
 return


﻿
CREATE PROCEDURE [dbo].[spCountImagesinDefinition]
(
	@DefID int
)

 AS

	DECLARE @SKUCount int
	DECLARE @ImageCount int

	Select @SKUCount = Count(1)
	from regions r with (NOLOCK), Images i with (NOLOCK), ImageDefinitions d with (NOLOCK), oslookup o with (NOLOCK)
	where r.ID = i.RegionID
	and d.Id = i.ImageDefinitionID
	and d.ID = @DefID
	and o.id = d.osid
	and i.priority <> '0'
	and i.Published=1


	Select @ImageCount = count(1) * max(o.oscount)
	from regions r with (NOLOCK), Images i with (NOLOCK), ImageDefinitions d with (NOLOCK), oslookup o with (NOLOCK)
	where r.ID = i.RegionID
	and d.Id = i.ImageDefinitionID
	and d.ID = @DefID
	and o.id = d.osid
	and isnumeric(i.priority) = 1
	and i.Published=1

	Select 	@SKUCount as SKUCount, @ImageCount as ImageCount




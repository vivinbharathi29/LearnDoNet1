﻿CREATE PROCEDURE [dbo].[spGetProductVersionName]
/* ************************************************************************************************
 * Purpose:	Modify the field for a Naming Standard
 * Created By:	Unknown
 * Modified By:	12/15/2015 SPathak - return the fusionrequirement bit
				07/17/2017 buidi - add release to product name
				07/20/2017 shraddha - cannot get the product information when the releaseid is not passed from the UI since it is defaulted to 0 - Bug 147399
				08/07/2017 wgomero - get IsDesktop value to remove Notebook DCR distribution when ONLY Desktop products are selected in the DCR PBI 92721
				14/6/2018 Monica Filtered the table before Joining
 **************************************************************************************************/
@ID int,
@ReleaseID int = 0
AS
SET NOCOUNT ON
if (@ReleaseID = 0)
	SELECT DISTINCT v.DOTSName AS name, v.EmailActive AS Email, v.PDDReleased, v.SEPMID, v.productName AS Family, v.TypeID, v.Version AS version, v.PartnerID, v.PreinstallTeam, 
       v.DCRAutoOpen, v.Division, v.DevCenter, v.Distribution, v.SEPE, v.PINPM, v.SETestLead, v.SustainingMgrID, v.PreInstallCutoff, v.ProductStatusID, v.Fusion, 
       v.AddDCRNotificationList, b.BusinessID, FusionRequirement = isnull(FusionRequirements,0), bs.Operation, StableConsistent = bStableConsistent
		FROM (SELECT  ID,v.DOTSName, v.EmailActive , v.PDDReleased, v.SEPMID, v.productName , v.TypeID, v.Version , v.PartnerID, v.PreinstallTeam, 
       v.DCRAutoOpen, v.Division, v.DevCenter, v.Distribution, v.SEPE, v.PINPM, v.SETestLead, v.SustainingMgrID, v.PreInstallCutoff, v.ProductStatusID, v.Fusion, 
       v.AddDCRNotificationList,ProductFamilyID,BusinessSegmentID,FusionRequirements, v.bStableConsistent
	   FROM ProductVersion AS v WITH (NOLOCK) 
		WHERE 	  v.ID = @ID)v
		INNER JOIN   ProductFamily AS f WITH (NOLOCK)
		ON f.ID = v.ProductFamilyID 
		Left JOIN   Product_Brand AS pb WITH (NOLOCK)
		ON pb.ProductVersionID = v.ID 
		left JOIN   Brand AS b WITH (NOLOCK) 
		ON b.ID = pb.BrandID 
		INNER JOIN  BusinessSegment as bs WITH (NOLOCK) 
		ON v.BusinessSegmentID = bs.BusinessSegmentID
	--	WHERE  v.ID = @ID
else
	SELECT DISTINCT case isnull(pv_r.ID,0) when 0 then DOTSName 
	else DOTSName + ' (' + pvr.Name + ')' end AS name, v.EmailActive AS Email, v.PDDReleased, v.SEPMID, v.productName AS Family, v.TypeID, v.Version AS version, v.PartnerID, v.PreinstallTeam, 
		   v.DCRAutoOpen, v.Division, v.DevCenter, v.Distribution, v.SEPE, v.PINPM, v.SETestLead, v.SustainingMgrID, v.PreInstallCutoff, v.ProductStatusID, v.Fusion, 
		   v.AddDCRNotificationList, b.BusinessID, FusionRequirement = isnull(FusionRequirements,0), bs.Operation, StableConsistent = bStableConsistent
		FROM   (SELECT v.EmailActive , DOTSName,FusionRequirements,v.PDDReleased, v.SEPMID, v.productName , v.TypeID, v.Version , v.PartnerID, v.PreinstallTeam, 
		   v.DCRAutoOpen, v.Division, v.DevCenter, v.Distribution, v.SEPE, v.PINPM, v.SETestLead, v.SustainingMgrID, v.PreInstallCutoff, v.ProductStatusID, v.Fusion, 
		   v.AddDCRNotificationList,v.ProductFamilyID,v.BusinessSegmentID,v.ID, v.bStableConsistent 
		FROM ProductVersion AS v WITH (NOLOCK)
		WHERE  v.ID = @ID )v
		INNER JOIN  ProductFamily AS f WITH (NOLOCK)  
		ON f.ID = v.ProductFamilyID
		Left JOIN  Product_Brand AS pb WITH (NOLOCK) 
		ON pb.ProductVersionID = v.ID 
		left JOIN   Brand AS b WITH (NOLOCK) 
		ON b.ID = pb.BrandID 
		left JOIN   ProductVersion_Release pv_r WITH (NOLOCK) 
		ON pv_r.ProductVersionID = v.ID 
		left JOIN   ProductVersionRelease pvr WITH (NOLOCK) 
		on pvr.ID = pv_r.ReleaseID 
		INNER JOIN   BusinessSegment as bs WITH (NOLOCK) 
		ON v.BusinessSegmentID = bs.BusinessSegmentID
		 WHERE pv_r.ReleaseID = @ReleaseID

	SET NOCOUNT OFF
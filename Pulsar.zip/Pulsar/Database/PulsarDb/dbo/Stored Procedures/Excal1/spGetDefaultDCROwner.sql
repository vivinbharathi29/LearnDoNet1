﻿CREATE PROCEDURE [dbo].[spGetDefaultDCROwner]
(
	@ProdID int
)
 AS
/* ************************************************************************************************
 * Purpose:	Get Default DCROwner
 * Created By:	?
 * Modified By:	4/27/2016, Herb, PBI19714/Task19857, Modify to fit the logic based on the PBI17178-Task17281, fix the confusion of TDCCMID and PMID.
 *			
 *				
**************************************************************************************************/
DECLARE 
	@DCROwner int,
	@TDCCMID int,
	@PMID int,
	@bCommercial int,
    @bConsumer int
;

SELECT
	@bCommercial = (
		CASE
			WHEN (ISNULL(v.FusionRequirements, 0) = 1) THEN 1
			WHEN (ISNULL(v.FusionRequirements, 0) = 0 
				AND v.DevCenter <> 2 
				AND v.DevCenter <> 6) THEN 1
			ELSE 0
		END
	),
	@bConsumer = (
		CASE
			WHEN (ISNULL(v.FusionRequirements, 0) = 1) THEN 0
			WHEN (ISNULL(v.FusionRequirements, 0) = 0 
				AND v.DevCenter = 2 
				OR v.DevCenter = 6) THEN 1
			ELSE 0
		END
	)
FROM productversion v
WHERE v.id = @ProdID
;

SELECT
	@DCROwner = DCRDefaultOwner,
	@TDCCMID = COALESCE(TDCCMID, 0),
	@PMID = COALESCE(PMID, 0)
FROM ProductVersion
WHERE ID = @ProdID
;

IF @DCROwner = 1
BEGIN
--Configuration Manager

	SELECT
		u.UserID aS ID,
		u.FullName AS Name,
		v.Distribution AS Email,
		v.smid,
		'Configuration Manager' as 'Role'
	FROM	productversion v WITH (NOLOCK),
			UserInfo u WITH (NOLOCK)
	WHERE v.id = @ProdID
	--Add Case statements to return correct config manager based on dev type: ---
	AND (CASE
		WHEN (ISNULL(v.FusionRequirements, 0) = 0 AND
			v.DevCenter = 2 OR
			v.DevCenter = 6) AND
			v.tdccmid = u.UserID THEN 1
		ELSE 0
	END) = @bConsumer
	AND (CASE
		WHEN (ISNULL(v.FusionRequirements, 0) = 1) AND
			v.pmid = u.UserID THEN 1
		WHEN (ISNULL(v.FusionRequirements, 0) = 0 AND
			v.DevCenter <> 2 AND
			v.DevCenter <> 6) AND
			v.pmid = u.UserID THEN 1
		ELSE 0
	END) = @bCommercial
	;

END
ELSE 
BEGIN
--Program Office Manager

	SELECT
		u.UserID AS ID,
		u.FullName AS Name,
		v.Distribution AS Email,
		v.smid,
		'Program Office Manager' as 'Role'
	FROM	productversion v WITH (NOLOCK),
			UserInfo u WITH (NOLOCK)
	WHERE v.id = @ProdID
	--Add Case statements to return correct program office manager based on dev type: ---
	AND (CASE
		WHEN (ISNULL(v.FusionRequirements, 0) = 0 AND
			v.DevCenter = 2 OR
			v.DevCenter = 6) AND
			v.pmid = u.UserID THEN 1
		ELSE 0
	END) = @bConsumer
	AND (CASE
		WHEN (ISNULL(v.FusionRequirements, 0) = 1) AND
			v.tdccmid = u.UserID THEN 1
		WHEN (ISNULL(v.FusionRequirements, 0) = 0 AND
			v.DevCenter <> 2 AND
			v.DevCenter <> 6) AND
			v.tdccmid = u.UserID THEN 1
		ELSE 0
	END) = @bCommercial
	;

END 
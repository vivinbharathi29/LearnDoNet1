﻿
CREATE PROCEDURE [dbo].[spGetImageSummary]
(
	@ProductID int,
	@DeliverableID int, 
	@Scope tinyint
)
AS
if @Scope=3
			Select	ImageSummary
			FROM Product_DelRoot with (NOLOCK)
			Where ProductVersionID = @ProductID
			and Deliverablerootid = @DeliverableID
else
			Select ImageSummary
			FROM Product_Deliverable with (NOLOCK)
			Where ProductVersionID = @ProductID
			and DeliverableVersionid = @DeliverableID


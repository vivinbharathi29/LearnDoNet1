﻿

CREATE PROCEDURE [dbo].[spGetDevCenterName]
(
	@ID int
)
AS
	Select ID, Name
	from DevCenter with (NOLOCK)
	where ID=@ID
	order by Name



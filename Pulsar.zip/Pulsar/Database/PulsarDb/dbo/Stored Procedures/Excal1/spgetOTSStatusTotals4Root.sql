﻿

CREATE PROCEDURE [dbo].[spgetOTSStatusTotals4Root]
(
	@RootID int
)
AS


DECLARE @TotalP2 int
Select @TotalP2 = count(1)
from  [$(SIO_Server)].[$(DbDataWarehouse)].dbo.SI_Snapshot_Observation o  with (NOLOCK)
where o.priority_name in (2) and o.status_Name = 'Open' 
and o.excaliburid in (Select id from deliverableversion with (NOLOCK) where deliverablerootid = @RootID)
and o.Division_ID=6
and o.report_date between getDate()-1 and getDate()


Select count(1) as TotalP1,
	   count(case when state_name = 'Cannot Duplicate' or state_name = 'Cannot Duplicate – Disagree' or state_name = 'Duplicate – Disagree' or state_name = 'Fix Failed' or state_name = 'Need Info' or state_name = 'New*/Reopen' or state_name = 'No Fix Needed – Disagree' or state_name = 'Transfer Requested' or state_name = 'Under Investigation' or state_name = 'Will Not Fix - Disagree' then 1 end) as UI,
       count(case when state_name = 'Fix in Progress' or state_name = 'Fix in Progress - Waiting on Vendor' then 1 end) as FIP,
       count(case when state_name = 'Understood/Problem Identified' then 1 end) as Identified,
       count(case when state_name <> 'Cannot Duplicate' and state_name <> 'Cannot Duplicate – Disagree' and state_name <> 'Duplicate – Disagree' and state_name <> 'Fix Failed' and state_name <> 'Need Info' and state_name <> 'New*/Reopen' and state_name <> 'No Fix Needed – Disagree' and state_name <> 'Transfer Requested' and state_name <> 'Under Investigation' and state_name <> 'Will Not Fix - Disagree' and state_name <> 'Understood/Problem Identified' and state_name <> 'Fix in Progress' and state_name <> 'Fix in Progress - Waiting on Vendor' then 1 end) as Retest,
	   count(case when coalesce(gating_Name,'') = 'Web Release' then 1 end) as Web,
       @TotalP2 as TotalP2
from [$(SIO_Server)].[$(DbDataWarehouse)].dbo.SI_Snapshot_Observation o  with (NOLOCK)
where o.priority_name in (0,1) and o.status_name = 'Open'
and o.ExcaliburID in (Select id from deliverableversion with (NOLOCK) where deliverablerootid = @RootID)
and o.Division_ID=6
and o.report_date between getDate()-1 and getDate()

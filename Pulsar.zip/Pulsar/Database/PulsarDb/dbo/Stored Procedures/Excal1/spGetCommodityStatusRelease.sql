﻿CREATE PROCEDURE [dbo].[spGetCommodityStatusRelease]
/* ************************************************************************************************
 * Purpose: Get Qualification Status Information
 * Created By:	
 * Modified By: Dien Bui 4/25/2017 - Combine Qualification Status Information lagacy product and pulsar product
 *				Dien BUi 7/3/2017 - switch IntegrationTestStatus, IntegrationTestNotes, ODMTestStatus, ODMTestnotes, WWANTestStatus, WWANTestNotes to pull from release
 *				Dien Bui 02/09/2018 - switch DeveloperTestStatus, DeveloperTestNotes and developernotificationstatus to pull from release
 **************************************************************************************************/
(
	@ProdID int,
	@VersionID int,
	@ProductDeliverableReleaseID int = 0
)
 AS

Select	pdr.id, pdr.ConfigurationRestriction, pdr.SupplyChainRestriction, v.TTS, pv.wwanproduct, 
		DeveloperTestStatus = isnull (pdr.DeveloperTestStatus, 0), 
		DeveloperTestNotes = isnull(pdr.DeveloperTestNotes,''), 
		IntegrationTestStatus = isnull(pdr.IntegrationTestStatus,0), 
		IntegrationTestNotes = isnull(pdr.IntegrationTestNotes,''), 
		ODMTestStatus = isnull(pdr.ODMTestStatus,0), 
		ODMTestnotes = isnull(pdr.ODMTestnotes,''), c.requiresTTS, c.requiresodmtestfinalapproval, c.requiresWWANtestfinalapproval, c.requiresMITtestfinalapproval, c.requiresdeveloperfinalapproval,
		WWANTestStatus = isnull(pdr.WWANTestStatus,0), 
		WWANTestNotes = isnull(pdr.WWANTestNotes,''), 
		TestStatusID = isnull(pdr.TestStatusID,0), 
		targetNotes = isnull(pdr.targetNotes,''), 
		TestConfidence = isnull(pdr.TestConfidence,0), pv.devcenter, 
		TestDate = isnull(pdr.TestDate,''), 
		DCRID = isnull(pdr.DCRID,0), 
		developernotificationstatus = isnull(pdr.developernotificationstatus,0), 
		c.name as category, c.id as CategoryID, r.name as DeliverableName, v.version, v.revision, v.pass, v.vendorid, v.deliverablerootid, v.modelnumber, SUBSTRING(v.partnumber,0,11) as partnumber, vd.name as vendor, pv.dotsname as Product, pv.PartnerID, pdr.RiskRelease,
		ProductDeliverableID = pdr.ProductDeliverableID
from product_deliverable pd with (NOLOCK)
inner join product_deliverable_release pdr with (NOLOCK) on pdr.ProductDeliverableID = pd.ID
inner join deliverableversion v with (NOLOCK) on pd.deliverableversionid = v.id 
inner join productversion pv with (NOLOCK) on pv.id = pd.productversionid
inner join productfamily f with (NOLOCK) on f.id=pv.productfamilyid
inner join vendor vd with (NOLOCK) on vd.id=v.vendorid
inner join deliverableroot r with (NOLOCK) on r.id = v.deliverablerootid
inner join deliverablecategory c with (NOLOCK) on c.id = r.categoryid
where pd.productversionid = @ProdID
and pd.deliverableversionid = @VersionID and pdr.ID = @ProductDeliverableReleaseID
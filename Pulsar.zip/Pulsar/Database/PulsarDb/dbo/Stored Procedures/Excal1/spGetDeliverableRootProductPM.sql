﻿

CREATE PROCEDURE [dbo].[spGetDeliverableRootProductPM]
(
	@PDRID int
)	

AS
	DECLARE @ProductName as varchar(30)
	DECLARE @SystemTeamEmail as varchar(1000)
	DECLARE @DeliverableName as varchar(120)
	DECLARE @PMField as varchar(50)
	DECLARE @RootID int
	DECLARE @ProductID int	
	DECLARE @TypeID int
	
	
	Select @RootID=DeliverableRootID,@ProductID = ProductVersionID
	from Product_DelRoot WITH (NOLOCK)
	where ID = @PDRID
	
	Select @ProductName = dotsname, @SystemTeamEmail = Distribution
	from ProductVersion WITH (NOLOCK)
	where id = @ProductID
	
	Select @ProductName = coalesce(@ProductName,'')
	
	Select  @PMField = ct.PMFieldName, @DeliverableName = r.Name, @TypeID= r.TypeID
	from deliverableroot r WITH (NOLOCK), deliverablecategory c WITH (NOLOCK), deliverablecategoryteam ct WITH (NOLOCK)
	where c.id = r.categoryid
	and ct.id = c.teamid
	and r.ID = @RootID

	Select @DeliverableName = coalesce(@DeliverableName,'')

	if @PMField is null
		Select '' as Email, @ProductName AS ProductName, @DeliverableName as DeliverableName, @SystemTeamEmail as SystemTeamEmail, @TypeID as TypeID
	else
		exec ('Select coalesce(e.email,'''') as Email,''' + @ProductName + ''' as ProductName, ''' + @DeliverableName + ''' as DeliverableName, ''' + @SystemTeamEmail + ''' as SystemTeamEmail, ''' + @TypeID + ''' as TypeID FROM dbo.ProductVersion AS v WITH (NOLOCK) LEFT OUTER JOIN dbo.Employee AS e WITH (NOLOCK) ON v.' + @PMField + ' = e.id where v.ID = ' + @ProductID + ' ')

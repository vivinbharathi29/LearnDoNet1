﻿

CREATE PROCEDURE [dbo].[spGetRoHSGreenDisplayName] 
(
	@RohsID int,
	@GreenSpecID int
)
AS

	DECLARE @ROHS varchar(50)
	DECLARE @GreenSpec varchar(50)

	Select @Rohs = name
	from Rohs with (NOLOCK)
	where id = @RohsID

	Select @GreenSpec = name
	from GreenSpec with (NOLOCK)
	where id = @GreenSpecID
	
	Select @ROHS as RoHS, @GreenSpec as GreenSpec
	


﻿
CREATE PROCEDURE [dbo].[spListCommodityRestrictions]
(
	@ID int = null
)
AS

SELECT pd.PilotDate, pd.TestDate, pt.Name AS partner, pd.ID AS ProdDelID, p.ID AS ProdID, v.ID AS DelID, p.DOTSName AS Product, e.Name AS PM, r.Name AS Deliverable, v.Version, v.Revision, v.Pass, v.PartNumber, v.ModelNumber, vd.Name AS Vendor, pd.TargetNotes AS QualComments, pd.PilotNotes AS PilotComments, v.Comments AS devComments
FROM            
	Product_Deliverable AS pd WITH (NOLOCK) INNER JOIN
    ProductVersion AS p WITH (NOLOCK) ON pd.ProductVersionID = p.ID INNER JOIN
    DeliverableVersion AS v WITH (NOLOCK) ON pd.DeliverableVersionID = v.ID INNER JOIN
    DeliverableRoot AS r WITH (NOLOCK) ON v.DeliverableRootID = r.ID INNER JOIN
    Partner AS pt WITH (NOLOCK) ON p.PartnerID = pt.ID INNER JOIN
    DeliverableCategory AS c WITH (NOLOCK) ON r.CategoryID = c.ID INNER JOIN
    Vendor AS vd WITH (NOLOCK) ON v.VendorID = vd.ID LEFT OUTER JOIN
    Employee AS e WITH (NOLOCK) ON p.PDEID = e.ID
WHERE
	(r.TypeID = 1) 
AND (r.ID = COALESCE (@ID, r.ID)) 
AND (pd.SupplyChainRestriction = 1) 
AND (p.OnCommodityMatrix = 1)
ORDER BY Product, Vendor, Deliverable

﻿/**************************************************************************************************    -- =============================================
-- Author:		??
-- Description:	add filters to report profile
-- Modified By: 07/05/2016 wgomero - add value55 to save selected Pulsar products
--              09/20/2016 linshant - set null as default value to value55
-- =============================================  
**************************************************************************************************    
** Change History           
**************************************************************************************************    
** SNo   Date        Author                     Description           
** --    --------   -------                     -------------------------           
 ** 1    27/12/2018  Santhana K					Changed the Text Data type to Varchar(max)
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spAddProfile]
(

	@ProfileName varchar(50),
	@ProfileType int,
	@EmployeeID int,
	@Value5 int,
	@Value6 varchar(4),
	@Value7 int,
	@Value8 int,
	@Value9 varchar(20),
	@Value10 varchar(20),
	@Value11 varchar(30),
	@Value12 varchar(80),
	@Value13 varchar(255),
	@Value14 varchar(255),
	@Value15 varchar(2000),
	@Value16 int,
	@Value17 bit,
	@Value18 bit,
	@Value19 bit,
	@Value20 bit,
	@Value21 bit,
	@Value22 int,
	@Value23 varchar(4),
	@Value24 int,
	@Value25 varchar(4),
	@Value27 varchar(255),
	@Value28 varchar(25),
	@Value29 varchar(25),
	@Value30 varchar(25),
	@Value31 varchar(25),
	@Value32 varchar(25),
	@Value33 bit,
	@Value34 bit,
	@Value35 bit,
	@Value36 bit,
	@Value37 bit,
	@Value38 bit,
	@Value41 varchar(255),
	@Value42 varchar(255),
	@Value44 bit,
	@Value45 varchar(2000),
	@Value46 varchar(2000),
	@Value47 varchar(120),
	@Value48 bit,
	@Value49 bit,
	@Value50 bit,
	@Value51 bit,
	@Value52 varchar(120),
	@Value53 varchar(1000),
	@Value54 varchar(2000),
	@Value1 Varchar(max),
	@Value2 Varchar(max),
	@Value3 Varchar(max),
	@Value4 Varchar(max),
	@Value26 Varchar(max),
	@Value39 Varchar(max),
	@Value40 Varchar(max),
	@Value43 Varchar(max),
	@DefaultSQL Varchar(max),
	@ReportFilters Varchar(max),
	@NewID int output,
	@Value55 Varchar(max) = null
)
 AS
Insert ReportProfiles (ProfileName, EmployeeID,ProfileType,Value1,Value2,Value3,Value4,Value5,Value6,Value7,Value8,Value9,Value10,Value11,Value12,Value13,Value14,Value15,Value16,Value17,Value18,Value19,Value20,Value21,Value22,Value23,Value24,Value25,Value26,Value27,Value28,Value29,Value30,Value31,Value32,Value33,Value34,Value35,Value36,Value37, Value38, Value39, Value40, Value41, Value42, Value43, Value44, Value45, Value46,Value47,Value48,Value49,Value50,Value51,Value52,Value53,Value54, DefaultSQL, ReportFilters,Value55)
Values(@ProfileName, @EmployeeID,@ProfileType,@Value1,@Value2,@Value3,@Value4,@Value5,@Value6,@Value7,@Value8,@Value9,@Value10,@Value11,@Value12,@Value13,@Value14,@Value15,@Value16,@Value17,@Value18,@Value19,@Value20,@Value21,@Value22,@Value23,@Value24,@Value25,@Value26,@Value27,@Value28,@Value29,@Value30,@Value31,@Value32,@Value33,@Value34,@Value35,@Value36,@Value37,@Value38,@Value39,@Value40,@Value41,@Value42,@Value43,@Value44,@Value45,@Value46,@Value47,@Value48,@Value49,@Value50,@Value51,@Value52,@Value53,@Value54,@DefaultSQL, @ReportFilters,@Value55)
Select @NewID = SCOPE_IDENTITY()
GO



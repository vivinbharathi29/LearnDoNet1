﻿

CREATE PROCEDURE [dbo].[spGetDeliverableBuildLevel]
(
	@ID int
)
AS

	Select ID, Name
	from DeliverableLevel with (NOLOCK)
	where id = @ID


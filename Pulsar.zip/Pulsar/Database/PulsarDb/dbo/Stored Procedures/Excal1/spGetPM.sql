﻿

CREATE PROCEDURE [dbo].[spGetPM]
(
	@ProdID int
)
 AS
SELECT e.ID, e.Name, p.Distribution as Email, p.smid
FROM Employee e with (NOLOCK), ProductVersion p with (NOLOCK)
Where p.PMID = e.ID
and p.ID = @ProdID




﻿

CREATE PROCEDURE [dbo].[spAddDeliverableActionEcr]
(
 @ProductID int,
 @Type tinyint,
 @Status tinyint,
 @Submitter varchar(50),
 @OwnerID int,
 @Notify varchar(8000),
 @Summary varchar(120),
 @Description varchar(8000),
 @Details VARCHAR(8000),
 @LastUpdUser VARCHAR(200),
 @Initiator  int,
 @SpareKitPn varchar(500),
 @SubAssemblyPn varchar(500),
 @InventoryDisposition int,
 @QSpecSubmitted DATETIME,
 @CompEcoSubmitted DATETIME,
 @CompEcoNo VARCHAR(50),
 @SaEcoSubmitted DATETIME,
 @SaEcoNo VARCHAR(50),
 @SpsEcoSubmitted DATETIME,
 @SpsEcoNo VARCHAR(50),
 @NewID int Output
)
 AS

Declare @ActualDate datetime

if @Status=2 or @Status=4 or @Status=5 
	Select @ActualDate = getdate()
else
	Select @ActualDate = null

INSERT DeliverableIssues(
	Productversionid,
	DeliverableRootID, 
	Type,
	Status,
	Submitter,
	OwnerID,
	Notify,
	Summary, 
	Description,
	Details,
	LastUpdUser,
	InitiatedBy,
	SpareKitPn,
	SubAssemblyPn,
	InventoryDisposition,
	Created,
	OnStatusReport,
	CategoryID,
	CoreTeamRep,
	LastModified,
	BiosChange,
	SwChange,
	QSpecSubmittedDt,
	CompEcoSubmittedDt,
	CompEcoNo,
	SaEcoSubmittedDt,
	SaEcoNo,
	SpsEcoSubmittedDt,
	SpsEcoNo
	
)
VALUES(
 @ProductID,
 0,
 @Type,
 @Status,
 @Submitter,
 @OwnerID,
 @Notify,
 @Summary,
 @Description,
 @Details,
 @LastUpdUser,
 @Initiator,
 @SpareKitPn,
 @SubAssemblyPn,
 @InventoryDisposition,
 GETDATE(),0,1,0,GETDATE(),0,0,
 @QSpecSubmitted,
 @CompEcoSubmitted,
 @CompEcoNo,
 @SaEcoSubmitted,
 @SaEcoNo,
 @SpsEcoSubmitted,
 @SpsEcoNo

)
SELECT @NewID = SCOPE_IDENTITY()





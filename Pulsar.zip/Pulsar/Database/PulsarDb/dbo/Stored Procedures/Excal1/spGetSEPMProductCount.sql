﻿CREATE PROCEDURE spGetSEPMProductCount
(
	@SEPMID int
)
/*
	poletto 16 Dec 2016: rather than the product count, return 1/0 since the count is just checked to determine if user is SEPM or not.
	Now it uses the same logic as in spgetuserinfo, query rewritten to make it faster
*/
AS

IF 
EXISTS(
	SELECT 1
	FROM Permission p
		INNER JOIN Role_Object_Permission rop ON rop.PermissionId=p.PermissionId
		INNER JOIN  RoleMembers rm ON rm.RoleId=rop.RoleId
	WHERE rm.UserId=@SEPMID	AND p.Name IN ('InstallOption.Edit','Feature.Edit','PRL.Edit','Schedule.Edit'))
OR EXISTS(
	SELECT 1
	FROM ProductVersion
	WHERE (SEPMID=@SEPMID OR SysEngrProgramCoordinatorID=@SEPMID OR ODMSEPMID=@SEPMID)
	AND productstatusid<4 AND typeid=1)
	SELECT 1
ELSE
	SELECT 0

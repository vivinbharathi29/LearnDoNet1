﻿CREATE PROCEDURE [dbo].[spFusion_PRODUCTDROP_CheckStateAndApprover]
/* ************************************************************************************************
 * Purpose:		Check State and Pre-Release Approver of Product Drop
 * Created By:	09/24/2015 Lin, Shanti
 * Modified By:	
 **************************************************************************************************/
	@p_intPDID int,
	@p_intUserID int,
	@p_hasPermission int output
AS
	DECLARE @pd_State int,
			@isApprover int

	SELECT @pd_State = State From IRS_ProductDrop WITH (NOLOCK) WHERE ProductDropID = @p_intPDID

	IF (@pd_State & 8) > 0  BEGIN-- Product drop is locked
		SELECT @isApprover = count (*) From IRS_ProductDrop_User WITH (NOLOCK) WHERE ProductDropID = @p_intPDID and Userid = @p_intUserID
		IF (@isApprover > 0)
			set @p_hasPermission = 1
		ELSE
			set @p_hasPermission = 0
	END
	ELSE
		set @p_hasPermission = 1
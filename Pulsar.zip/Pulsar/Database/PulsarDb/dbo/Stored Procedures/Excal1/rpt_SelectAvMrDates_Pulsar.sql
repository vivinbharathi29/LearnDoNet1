﻿CREATE PROCEDURE [dbo].[rpt_SelectAvMrDates_Pulsar]
/* ************************************************************************************************
 * Purpose:		Display MR Dates for AVs in Show MR Dates
 * Created By:	06/23/2015 JCope - copied rpt_SelectAvMrDates to create Pulsar version
 * Modified By:	
 **************************************************************************************************/
	@p_ProductBrandID INT
AS
SELECT
	ad.AvNo, ad.GPGDescription, amdp.*
FROM
	SCMCategory afc with (NOLOCK)
	INNER JOIN AvDetail ad with (NOLOCK) ON afc.SCMCategoryID = ad.SCMCategoryID 
	RIGHT OUTER JOIN AvDetail_ProductBrand adpb with (NOLOCK) ON ad.AvDetailID = adpb.AvDetailID 
	LEFT OUTER JOIN AvMrDates_Pivot amdp with (NOLOCK) ON amdp.DatesAvDetailID = adpb.AvDetailID 
		AND amdp.DatesProductBrandID = adpb.ProductBrandID
WHERE
	adpb.ProductBrandID = @p_ProductBrandID
ORDER BY
	afc.SortOrder, adpb.SortOrder, ad.GPGDescription, ad.AvNo

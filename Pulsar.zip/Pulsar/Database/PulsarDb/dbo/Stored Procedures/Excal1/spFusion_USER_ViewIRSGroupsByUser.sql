﻿
CREATE PROCEDURE [dbo].[spFusion_USER_ViewIRSGroupsByUser]
/* ************************************************************************************************
 * Purpose:		List IRS UserGroups for the IRS User
 * Created By:	08/01/2013 JCope
 * Modified By:	
 **************************************************************************************************/
	@p_intID int
AS
	SET NOCOUNT ON
	exec IRSTest_usp_USR_ViewGroupsByUser @p_intID

	if @@error <> 0 begin
		raiserror('Error:spFusion_USER_ViewIRSGroupsByUser - Error returned from IRSTest_usp_USR_ViewGroupsByUser.', 16, 1)
		return 1
	end

	return 0



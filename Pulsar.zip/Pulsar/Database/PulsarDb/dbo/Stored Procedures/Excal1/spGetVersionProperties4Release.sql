﻿


CREATE PROCEDURE [dbo].[spGetVersionProperties4Release]
 (
	@ID as int
) 
AS
SELECT  v.IRSPartNumber, v.md5, e.email as DevManagerEmail, e2.name as DeveloperName, e2.email as DeveloperEmail, v.tts, v.wwanfailureconfirmed, v.Version, v.Revision, v.Pass, v.ImagePath as Transfer, v.HFCN, v.Filename, v.ar, v.isoImage, v.ConsumerReleaseStatus, v.CommercialReleaseStatus, r.Name, r.MultiLanguage, r.TypeID, r.WorkflowID, r.CategoryID,r.testerid, r.notifications as AlsoNotify, v.CloneID,v.CloneType, c.RequiresTTS, case when r.CategoryID = 248 then 1 else 0 end as StructureCheck ,v.Comments
FROM DeliverableVersion v with (NOLOCK), DeliverableRoot r with (NOLOCK), employee e with (NOLOCK), employee e2 with (NOLOCK), deliverablecategory c with (NOLOCK)
WHERE v.id = @ID
and c.id = r.categoryid
and r.id = v.DeliverableRootID
and e.id = r.devmanagerid
and e2.id = v.developerid








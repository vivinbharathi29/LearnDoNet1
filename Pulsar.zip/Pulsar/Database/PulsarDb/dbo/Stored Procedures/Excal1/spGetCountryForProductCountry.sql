﻿

CREATE PROCEDURE [dbo].[spGetCountryForProductCountry]
(

	@ProductCountryID int
)
 AS

Select l.id, l.Language as Country, pc.productversionid, v.PartnerID
from Product_Country pc with (NOLOCK), language l with (NOLOCK), productversion v with (NOLOCK)
where l.id = pc.CountryID
and pc.id = @ProductCountryID
and v.id = pc.productversionid



﻿-- =================================================================
-- Update: Changed to new OUTER JOIN syntax - Paul Sanchez 3/11/2014
-- =================================================================
CREATE PROCEDURE [dbo].[spGetDeliverableVersionProductPM]
(
	@PDID int
)	

AS
	DECLARE @ProductName as varchar(30)
	DECLARE @SystemTeamEmail as varchar(1000)
	DECLARE @DeliverableName as varchar(120)
	DECLARE @PMField as varchar(50)
	DECLARE @VersionID int
	DECLARE @ProductID int	
	DECLARE @TypeID int
	Declare @Version varchar(20)
	DECLARE @Revision varchar(30)
	DECLARE @Pass varchar(20)
	DECLARE @PartNumber varchar(100)
	DECLARE @ModelNumber varchar(30)
	DECLARE @Vendor varchar(50)
	DECLARE @VendorID int
	
	Select @VersionID=DeliverableVersionID,@ProductID = ProductVersionID
	from Product_Deliverable with (NOLOCK)
	where ID = @PDID
	
	Select @ProductName = dotsname, @SystemTeamEmail = Distribution
	from ProductVersion with (NOLOCK)
	where id = @ProductID
	
	Select @ProductName = coalesce(@ProductName,'')
	
	
	Select  @PMField = ct.PMFieldName, @DeliverableName = v.DeliverableName, @TypeID= r.TypeID, @Version=v.Version,@Revision=v.Revision, @Pass=v.Pass,@PartNumber=v.PartNumber,@ModelNumber=v.ModelNumber,@VendorID=v.VendorID
	from deliverableroot r with (NOLOCK), deliverablecategory c with (NOLOCK), deliverablecategoryteam ct with (NOLOCK), deliverableversion v with (NOLOCK)
	where c.id = r.categoryid
	and v.deliverablerootid = r.id
	and ct.id = c.teamid
	and v.id= @VersionID

	Select @DeliverableName = coalesce(@DeliverableName,'')

	Select @Vendor = Name from Vendor with (NOLOCK) where ID = @VendorID

	Select @Vendor = coalesce(@Vendor,'')

	if @PMField is null
		Select '' as Email, @ProductName AS ProductName, @DeliverableName as DeliverableName, @SystemTeamEmail as SystemTeamEmail, @TypeID as TypeID, @Version as Version,@Revision as Revision, @Pass as Pass,@PartNumber as PartNumber,@ModelNumber as ModelNumber,@Vendor as Vendor
	else
		exec ('Select coalesce(e.email,'''') as Email,''' + @ProductName + ''' as ProductName, ''' + @DeliverableName + ''' as DeliverableName, ''' + @SystemTeamEmail + ''' as SystemTeamEmail, ''' + @TypeID + ''' as TypeID, ''' + @Version + ''' as Version, ''' + @Revision + ''' as Revision, ''' + @Pass + ''' as Pass, ''' + @PartNumber + ''' as PartNumber, ''' + @ModelNUmber + ''' as ModelNumber, ''' + @Vendor + ''' as Vendor from ProductVersion v with (NOLOCK) RIGHT OUTER JOIN employee e with (NOLOCK) ON e.id = v.' + @PMField + ' where v.ID = ' + @ProductID + '')




﻿

CREATE PROCEDURE [dbo].[spGetProductsInProgram] 
 (
  @ID int
 )
AS
SELECT Program.Name AS Program, Product_Program.CommonBucketLink,
    ProductFamily.Name AS Family, ProductVersion.Version, 
    ProductVersion.ID, Program.Active as ActiveProgram
FROM Product_Program with (NOLOCK) INNER JOIN
    ProductVersion with (NOLOCK) ON 
    Product_Program.ProductVersionID = ProductVersion.ID INNER JOIN
    ProductFamily with (NOLOCK) ON 
    ProductVersion.ProductFamilyID = ProductFamily.ID RIGHT OUTER
     JOIN
    Program with (NOLOCK) ON 
    Product_Program.ProgramID = Program.ID
WHERE (Program.ID = @ID)
ORDER BY ProductFamily.Name,ProductVersion.Version;





﻿
CREATE PROCEDURE [dbo].[spFusion_PRODUCTDROP_AddComponent]
/* ************************************************************************************************
 * Purpose:		Add component to an IRS product drop
 * Created By:	07/31/2013 JCope
 * Modified By:	
 **************************************************************************************************/
	@p_intPDID int,
	@p_chrPartNumber varchar(18),
	@p_chrDeliveryTypes varchar(20),	--Comma delimited list: DIB=16, In App Rcvry=8, Not in RCD=32, SRP=1
	@p_chrComponentPassID varchar(10),
	@p_chrUpdater varchar(18),
	@p_chrHTChangeReason varchar(255),
	@p_chrRetMsg varchar(8000) output
AS
	set @p_chrRetMsg = ''

	exec IRSTest_usp_Fusion_PRODUCTDROP_AddComponent @p_intPDID, @p_chrPartNumber, @p_chrDeliveryTypes, @p_chrComponentPassID, @p_chrUpdater, @p_chrHTChangeReason, @p_chrRetMsg output

	if @@error <> 0 begin
		raiserror('Error:spFusion_PRODUCTDROP_AddComponent - Error returned from IRSTest_usp_Fusion_PRODUCTDROP_AddComponent.', 16, 1)
		return 1
	end

	return 0



﻿CREATE PROCEDURE [dbo].[spGetDeliverableUpdateAccessList]
(
	@ID int,
	@RootID int =0
)
/*
	Modified By: buidi 12/08/2015 - Add ODMSEPMID Role
*/
 AS
if @RootID <> 0
	Begin
	--Root Developer	
	Select r.developerid as ID
	from deliverableRoot r WITH (NOLOCK)
	where r.id = @RootID
	Union
	--Devmanager	
	Select r.devmanagerid as ID
	from deliverableRoot r WITH (NOLOCK)
	where r.id = @RootID
	Union	
	--Developers
	Select distinct v.developerid as ID
	from deliverableversion v WITH (NOLOCK), deliverableRoot r WITH (NOLOCK)
	where r.id = @RootID
	and r.id = v.DeliverableRootID
	union
	--se pm
	Select Distinct SEPMID as ID
	from productversion WITH (NOLOCK)
	where active=1
	union
	--od se pm
	Select Distinct isnull(ODMSEPMID,0) as ID
	from productversion WITH (NOLOCK)
	where active=1
	union
	--commodity pm
	Select Distinct PDEID as ID
	from productversion WITH (NOLOCK)
	where active=1
	union
	--Sustaiing se pm
	Select Distinct SustainingSEPMID as ID
	from productversion WITH (NOLOCK)
	where active=1
	union 
	--ReleaseCoordinators
	Select ID
    from employee WITH (NOLOCK)
	where id in (2583,1816)
	union 
	--PIN PMs
	Select ID
    from employee WITH (NOLOCK)
	where PreinstallPM=1
	union
	--admins
	Select ID
	from Employee WITH (NOLOCK)
	where systemadmin = 1
	union
	--All Developers
	Select distinct v.developerid as ID
	from deliverableversion v WITH (NOLOCK), deliverableroot r WITH (NOLOCK)
	where r.id = v.deliverablerootid
	and r.active=1
	union
	--All DevManagers
	Select distinct r.devmanagerid as ID
	from deliverableroot r WITH (NOLOCK)
	where r.active=1
	union
	--All Managers of DevManagers
	Select distinct e.managerid as ID
	from deliverableroot r WITH (NOLOCK), employee e WITH (NOLOCK)
	where r.active=1
	and e.id = r.devmanagerid
	and e.ManagerID is not null
	union
	--for hardware Execution Engineeeer
	Select distinct r.TesterID as ID
	from deliverableroot r WITH (NOLOCK), employee e WITH (NOLOCK)
	where r.active=1
	and e.id = r.TesterID
	and r.TypeID = 1
	
	End
else
	BEGIN
	--Devmanager	
	Select r.devmanagerid as ID
	from deliverableversion v WITH (NOLOCK), deliverableRoot r WITH (NOLOCK)
	where v.id = @ID
	and r.id = v.deliverablerootid
	Union
	--Developer
	Select distinct v.developerid as ID
	from deliverableversion v WITH (NOLOCK)
	where v.id = @ID
	union
	--sepms
	Select Distinct SEPMID as ID
	from productversion WITH (NOLOCK)
	where active=1
	union
	--od se pm
	Select Distinct isnull(ODMSEPMID,0) as ID
	from productversion WITH (NOLOCK)
	where active=1
	union
	--commodity pms
	Select Distinct PDEID as ID
	from productversion WITH (NOLOCK)
	where active=1
	union
	--Sustaining sepms
	Select Distinct SustainingSEPMID as ID
	from productversion WITH (NOLOCK)
	where active=1
	union 
	--ReleaseCoordinators
	Select ID
    from employee WITH (NOLOCK)
	where id in (2583,1816)
	union 
	--PIN PMs
	Select ID
    from employee WITH (NOLOCK)
	where PreinstallPM=1
	union
	--Admins
	Select ID
	from Employee WITH (NOLOCK)
	where systemadmin = 1
	union
	--All Developers of Active Deliverables
	Select distinct v.developerid as ID
	from deliverableversion v WITH (NOLOCK), deliverableroot r WITH (NOLOCK)
	where r.id = v.deliverablerootid
	and r.active=1
	union
	--All DevManagers
	Select distinct r.devmanagerid as ID
	from deliverableroot r WITH (NOLOCK)
	where r.active=1

	union

	--All Managers of DevManagers
	Select distinct e.managerid as ID
	from deliverableroot r WITH (NOLOCK), employee e WITH (NOLOCK)
	where r.active=1
	and e.id = r.devmanagerid
	and e.ManagerID is not null

	order by id
	END
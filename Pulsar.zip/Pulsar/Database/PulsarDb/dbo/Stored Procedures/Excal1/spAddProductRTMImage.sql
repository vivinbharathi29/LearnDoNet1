﻿CREATE PROCEDURE [dbo].[spAddProductRTMImage]
(
	@ProductRTMID int,
	@ImageID int,
	@RTMDate datetime,
	@RTMDraftImageRemove int=0
)
AS
BEGIN
	set nocount on
	Declare @StatusID int
	DECLARE @DefinitionID int
	DECLARE @OldRTMDate datetime
	Declare @ImagesRemaining int
	IF(@RTMDraftImageRemove=1)
	  BEGIN
	  SET NOCOUNT ON
		delete  from ProductRTM_Image  where ProductRTMID=@ProductRTMID
	  SET NOCOUNT OFF
	  END
	Select @StatusID = d.StatusID, @OldRTMDate = d.RTMDate, @DefinitionID = d.id
	from imagedefinitions d with (NOLOCK), images i with (NOLOCK)
	where i.imagedefinitionid = d.id
	and i.id = @ImageID
	
	update images
	set rtmdate = @RTMDate
	where id = @ImageID
	
	Select @ImagesRemaining = count(1)
	from images  with (NOLOCK)
	where rtmdate is null
	and imagedefinitionid = @DefinitionID
	and isnumeric(priority)=1
	
	if @StatusID = 1 and @ImagesRemaining = 0 -- @OldRTMDate is null and
		update imagedefinitions
		set RTMDate = @RTMDate, StatusID = 2, ImageSnapshotsSaved=1
		where id = @DefinitionID
	
	set nocount off

		Insert into ProductRTM_Image (ProductRTMID,ImageID)
		Values(@ProductRTMID,@ImageID)
END
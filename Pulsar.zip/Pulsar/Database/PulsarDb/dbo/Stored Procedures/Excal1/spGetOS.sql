﻿



CREATE PROCEDURE [dbo].[spGetOS] 

(
	@Active bit = 1,  --null=All, 0=Inactive Only, 1=Active Only
	@ImagePackage bit = 0 --null=All, 0=OS Only, 1=ImagePackages Only
)

as

Select ID,Name, Active
FROM OSLookup with (NOLOCK)
where ImagePackage = coalesce(@ImagePackage,ImagePackage)
and Active = coalesce(@Active, Active)
Order By DisplayOrder






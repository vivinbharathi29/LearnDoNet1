﻿CREATE PROCEDURE [dbo].[spListAccessoryLeverageBroken]
/* ************************************************************************************************
 * Purpose:	Add Release support to Linked components no longer used by the commodity team - today page section
 * Created By:	
 * Modified By: 06/21/2017 wgomero: PBI: 138670
 **************************************************************************************************/
(
	@PMID int = null
)
AS

    SELECT  pd.id, 
		  p.dotsname, 
		  d.deliverablename, 
		  d.version, 
		  d.revision,
		  d.pass, 
		  d.partnumber, 
		  d.modelnumber, 
		  d.id as DeliverableID, 
		  p.id as ProductID,
		  [ProductDeliverableReleaseID] = 0,
		  [Release] = '',
		  AccessoryLeveraged = 0
    FROM product_deliverable pd with (NOLOCK) INNER JOIN productversion p with (NOLOCK) ON pd.productversionid = p.id
									 INNER JOIN deliverableversion d with (NOLOCK) ON d.id = pd.deliverableversionid
    WHERE pd.AccessoryLeveraged = 1
		  and pd.teststatusid = 0
		  and p.accessorypmid = coalesce(@PMID,p.accessorypmid)
		  and isnull(p.fusionrequirements,0) = 0
    
    UNION

       SELECT  pd.id, 
		  p.dotsname, 
		  d.deliverablename, 
		  d.version, 
		  d.revision,
		  d.pass, 
		  d.partnumber, 
		  d.modelnumber, 
		  d.id as DeliverableID, 
		  p.id as ProductID,
		  [ProductDeliverableReleaseID] = pdr.ID,
		  [Release] = pvr.name,
		  pdr.AccessoryLeveraged
    FROM product_deliverable pd with (NOLOCK)  INNER JOIN product_deliverable_release pdr with (NOLOCK) on pdr.ProductDeliverableID = pd.id
								       INNER JOIN ProductVersionRelease pvr with (NOLOCK) on pdr.ReleaseID = pvr.ID
								       INNER JOIN productversion p with (NOLOCK) ON pd.productversionid = p.id
									  INNER JOIN deliverableversion d with (NOLOCK) ON d.id = pd.deliverableversionid
    WHERE pdr.AccessoryLeveraged = 1
		  and pdr.teststatusid = 0
		  and p.accessorypmid = coalesce(@PMID,p.accessorypmid)
		  and isnull(p.fusionrequirements,0) = 1
    
    ORDER BY p.dotsname, d.deliverablename


﻿
CREATE PROCEDURE [dbo].[spFusion_PROJECT_SearchReplace_Preview]
/* ************************************************************************************************
 * Purpose:		Do a Preview for Search and Replace in IRS Projects to see if a part number can be replaced
 * Created By:	08/01/2013 
 * Modified By:	
 **************************************************************************************************/
	@p_OldPart varchar(200),
	@p_NewPart varchar(200),	
	@p_chrUserGroupIDs varchar(3000),
	@p_intUserID int,
	@p_NewPartRevision varchar(5),
	@p_IsCD bit,
	@p_ProductdropIDs varchar(8000)
AS
	SET NOCOUNT ON
--select @p_OldPart, @p_NewPart, @p_chrUserGroupIDs, @p_intUserID, @p_NewPartRevision, @p_IsCD, @p_ProductdropIDs
--return

	if ltrim(rtrim(@p_NewPartRevision)) = '' or @p_NewPartRevision is null
		exec IRSTest_usp_Project_SearchReplace_Preview @p_OldPart, @p_NewPart, @p_chrUserGroupIDs, @p_intUserID, '', @p_IsCD, @p_ProductdropIDs
	else
		exec IRSTest_usp_Project_SearchReplace_Preview @p_OldPart, @p_NewPart, @p_chrUserGroupIDs, @p_intUserID, @p_NewPartRevision, @p_IsCD, @p_ProductdropIDs

	if @@error <> 0 begin
		raiserror('Error:spFusion_PROJECT_SearchReplace_Preview - Error returned from ', 16, 1)
		return 1
	end

	return 0



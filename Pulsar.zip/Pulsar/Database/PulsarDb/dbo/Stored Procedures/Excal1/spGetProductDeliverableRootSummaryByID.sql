﻿CREATE PROCEDURE [dbo].[spGetProductDeliverableRootSummaryByID]
/*
	Purpose: New Component Requests on Today Page Section 
			 Developer reject product requested for the Root
	Created By: 
	Modified By: Dien Bui 7/14/2017 - display for Pulsar product and legacy product
*/
(
	@ID int, --Product DelrootID
	@ProductDeliverableReleaseID int = 0
)
AS

	if @ProductDeliverableReleaseID = 0 
	begin
		Select pd.id as ID, p.id as ProductID, r.typeid, r.id as DeliverableID, p.dotsname as Product, r.name as Deliverable,vd.name as Vendor, ProductDeliverableReleaseID = 0
		from product_delRoot pd with (NOLOCK) inner join
		productversion p with (NOLOCK) on pd.ProductVersionID = p.id inner join
		deliverableroot r with (NOLOCK) on r.id = pd.DeliverableRootID inner join 
		vendor vd with (NOLOCK) on r.vendorid = vd.id
		where pd.id = @ID and p.FusionRequirements <> 1
	end
	else 
	begin
		Select pd.id as ID, p.id as ProductID, r.typeid, r.id as DeliverableID, p.dotsname + ' (' + pvr.Name + ')' as Product, r.name as Deliverable,vd.name as Vendor, pdr.ID as ProductDeliverableReleaseID
		from product_delRoot pd with (NOLOCK) inner join
		productversion p with (NOLOCK) on pd.ProductVersionID = p.id inner join
		deliverableroot r with (NOLOCK) on r.id = pd.DeliverableRootID inner join 
		vendor vd with (NOLOCK) on r.vendorid = vd.id inner join
		Product_DelRoot_Release pdr with (NOLOCK) on pdr.ProductDelRootID = pd.ID inner join
		ProductVersionRelease pvr with (NOLOCK) on pvr.ID = pdr.ReleaseID
		where pd.id = @ID and p.FusionRequirements = 1
	end
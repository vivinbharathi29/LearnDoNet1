﻿

CREATE PROCEDURE [dbo].[spCopyImageDefinition]
(
	@CopyID int,
	@SKU varchar(20),
	@NewID int output
)	
 AS
insert ImageDefinitions(ProductVersionID,SKUNumber,BrandID, OSID , SWID, ImageType,Modified,Active, StatusID,RTMDate,Comments)
Select ProductVersionID,@SKU as SKUNumber,BrandID,OSID,SWID,ImageType,GetDate(),1,1,null,Comments
FROM ImageDefinitions with (NOLOCK)
where Id = @CopyID

Select @NewID = SCOPE_IDENTITY()


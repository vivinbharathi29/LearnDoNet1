﻿

CREATE PROCEDURE [dbo].[spAddSystemTeamMember]
(
	@ProdID int,
	@EmployeeID int,
	@Consumer bit,
	@Commercial bit,
	@SMB bit
)

AS

Insert SystemTeam(RoleID,Productversionid, employeeid, SMB,Commercial,Consumer)
values(1,@ProdID,@EmployeeID,@SMB,@Commercial,@Consumer)






﻿

CREATE PROCEDURE [dbo].[spAddSeries2Brand2]
(
	@ProductID int,
	@BrandID int,
	@Name varchar(50),
	@NewID int output
)

 AS

DECLARE @ProductBrandID int, @MasterLabel VARCHAR(50), @CTOModelNumber VARCHAR(50)

Select @ProductBrandID=ID, @MasterLabel = MasterLabel, @CTOModelNumber = CTOModelNumber from Product_Brand with (NOLOCK) where ProductVersionID = @ProductID and BrandID = @BrandID

IF EXISTS(SELECT 1 FROM Series WHERE ProductBrandID = @ProductBrandID AND Name =@Name)
BEGIN
	SELECT @NewID = ID FROM Series WHERE ProductBrandID = @ProductBrandID AND Name =@Name
	RETURN @NewID
END
ELSE IF @ProductBrandID is not null
	Begin
		INSERT  INTO Series(ProductBrandID,Name, MasterLabel, CTOModelNumber)
		VALUES(@ProductBrandID, @Name, @MasterLabel, @CTOModelNumber)

		SELECT @NewID = SCOPE_IDENTITY() 
	END
ELSE
	SELECT @NewID = 0




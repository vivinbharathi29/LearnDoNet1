﻿


CREATE PROCEDURE [dbo].[spAddLang2DelRootWeb]
 (
  @LanguageID int,
  @DeliverableRootID int,
  @Title nvarchar(1000),
  @Description nvarchar(4000)
 )
 AS
 Insert Language_DelRoot (LanguageID,DeliverableRootID, Title, Description)
 Values(@LanguageID,@DeliverableRootID,@Title,@Description)






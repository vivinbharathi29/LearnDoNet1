﻿/******************************************************************************
**	File: 
**	Name: 
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  02/15/2018	Santhana(auth\prabhuks) View Name changed from si_observation_report to SI_Observation_Report_Simplified from 
**  4/12/2018   Monica                Splitted the joins and used open query
*******************************************************************************/
CREATE PROCEDURE [dbo].[spCountOTS4OtherProductsRelated]
(
	@ProdID int,
	@ReportType int=1,
	@TeamID int = null
)
AS

	Begin

		DECLARE @DevCenter int
		DECLARE @DOTSName VARCHAR(30)
		DECLARE @OPENQUERY nvarchar(MAX), @TSQL nvarchar(4000), @LinkedServer nvarchar(4000)
		Select @DevCenter = devcenter from productversion with (NOLOCK) where id = @ProdID

		SELECT @DOTSName=DOTSName 
		from productversion with (NOLOCK) 
		where id = @ProdID 
	
	IF @DOTSName IS NULL OR @DOTSName=''
	SELECT  @DOTSName='#'



		SET @LinkedServer = 'HOUSIREPORT01'
			SET @OPENQUERY = 'SELECT * FROM OPENQUERY('+ @LinkedServer + ','''

				CREATE TABLE #remotequery(affected_state_Name VARCHAR(2000)
										  ,priority INT
										  ,[PrimaryProduct] VARCHAR(2000)
										  ,[Component] VARCHAR(2000))
		
		if @ReportType = 2 --System BIOS
		BEGIN



				SET @tsql='Select ap.affected_state_Name,priority,o.PrimaryProduct,o.component'+
						'	From [SIO].dbo.SI_Observation_Report_Simplified o with (NOLOCK) ' +
			' INNER JOIN [SIO].dbo.affectedProducts ap with (NOLOCK) '+
			' ON ap.observation_id = o.observationid '+
			' WHERE (ap.Platform_Cycle_Version = nullif('''''+@DOTSName +''''',''''#''''))'+
			' and o.status=''''Open'''''+
			' and (o.PrimaryProduct <>nullif('''''+ @DOTSName+''''',''''#''''))'')'

			
				INSERT INTO #remotequery
				EXEC (@OPENQUERY+@TSQL) 

			Select o.affected_state_Name as AffectedState, 
			case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end as Priority ,
			 count(1) as OTSCount
			 FROM #remotequery o
			--From [HOUSIREPORT01].[SIO].dbo.SI_Observation_Report_Simplified o with (NOLOCK)
			--INNER JOIN [HOUSIREPORT01].[SIO].dbo.affectedProducts ap with (NOLOCK)
			--ON ap.observation_id = o.observationid
			INNER JOIN  productversion p with (NOLOCK)
			ON p.dotsname = o.PrimaryProduct
			where ( (p.devcenter=2 and @Devcenter=2) or (p.devcenter<>2 and @Devcenter<>2) )			
			--and (ap.Platform_Cycle_Version = @DOTSName)
			--and o.status='Open'
			--and (o.PrimaryProduct <> @DOTSName)
			and o.component in 
				(
				select distinct d.deliverablename 
				from product_deliverable pd with (NOLOCK)
				INNER JOIN productversion p with (NOLOCK)
				ON pd.productversionid = p.id
				INNER JOIN deliverableversion d with (NOLOCK)
				ON pd.deliverableversionid = d.id
				INNER JOIN deliverableroot r with (NOLOCK)
				ON r.id = d.deliverablerootid
				where p.id = @ProdID
				and pd.targeted=1			
				and r.categoryid =161
				)
			group by o.affected_state_Name, case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end
			order by o.affected_state_Name, case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end
		END
		else if @ReportType = 3 --Hardware
		BEGIN 
	
			SET @tsql='Select ap.affected_state_Name,priority,o.PrimaryProduct,o.component'+
						'	From [SIO].dbo.SI_Observation_Report_Simplified o with (NOLOCK) ' +
			' INNER JOIN [SIO].dbo.affectedProducts ap with (NOLOCK) '+
			' ON ap.observation_id = o.observationid '+
			' WHERE (ap.Platform_Cycle_Version = nullif('''''+@DOTSName+''''',''''#''''))'+
			' and o.status=''''Open'''''+
			' and (o.PrimaryProduct <>nullif('''''+ @DOTSName++''''',''''#''''))'')'

			
			INSERT INTO #remotequery
				EXEC (@OPENQUERY+@TSQL) 


			Select o.affected_state_Name as AffectedState, case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end as Priority , count(1) as OTSCount
			From #remotequery o
			--[HOUSIREPORT01].[SIO].dbo.SI_Observation_Report_Simplified o with (NOLOCK)
			--INNER JOIN [HOUSIREPORT01].[SIO].dbo.affectedProducts ap with (NOLOCK)
			--ON ap.observation_id = o.observationid
			INNER JOIN productversion p with (NOLOCK)
			ON p.dotsname = o.PrimaryProduct
			where  ( (p.devcenter=2 and @Devcenter=2) or (p.devcenter<>2 and @Devcenter<>2) )			
			--and (ap.Platform_Cycle_Version = @DOTSName)
			--and o.status='Open'
			--and (o.PrimaryProduct <> @DOTSName)
			and o.component in 
				(
				select distinct d.deliverablename 
				from product_deliverable pd with (NOLOCK)
				INNER JOIN productversion p with (NOLOCK)
				ON pd.productversionid = p.id
				INNER JOIN deliverableversion d with (NOLOCK)
				ON pd.deliverableversionid = d.id
				INNER JOIN deliverableroot r with (NOLOCK)
				ON r.id = d.deliverablerootid
				where p.id = @ProdID
				and pd.targeted=1				
				and r.typeid = 1
				)
			group by o.affected_state_Name, case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end
			order by o.affected_state_Name, case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end
		END
		else --Non-HW
		BEGIN

		
		SET @tsql='Select ap.affected_state_Name,priority,o.PrimaryProduct,o.component'+
						'	From [SIO].dbo.SI_Observation_Report_Simplified o with (NOLOCK) ' +
			' INNER JOIN [SIO].dbo.affectedProducts ap with (NOLOCK) '+
			' ON ap.observation_id = o.observationid '+
			' WHERE (ap.Platform_Cycle_Version = nullif('''''+@DOTSName+''''',''''#''''))'+
			' and o.status=''''Open'''''+
			' and (o.PrimaryProduct <>nullif('''''+ @DOTSName+''''',''''#''''))'')'
	
			INSERT INTO #remotequery
				EXEC (@OPENQUERY+@TSQL) 
				

			Select o.affected_state_Name as AffectedState, case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end as Priority , count(1) as OTSCount
			From #remotequery o
			--[HOUSIREPORT01].[SIO].dbo.SI_Observation_Report_Simplified o with (NOLOCK)
			--INNER JOIN [HOUSIREPORT01].[SIO].dbo.affectedProducts ap with (NOLOCK)
			--ON ap.observation_id = o.observationid
			 INNER JOIN  productversion p with (NOLOCK)
			ON p.dotsname = o.PrimaryProduct
			where  ( (p.devcenter=2 and @Devcenter=2) or (p.devcenter<>2 and @Devcenter<>2) )		
			--and (ap.Platform_Cycle_Version = ( @DOTSName))
			--and o.status = 'Open'
			--and (o.PrimaryProduct <> ( @DOTSName ))
			and o.component in 
				(
				select distinct d.deliverablename 
				from product_deliverable pd with (NOLOCK)
				INNER JOIN productversion p with (NOLOCK)
				ON pd.productversionid = p.id
				INNER JOIN  deliverableversion d with (NOLOCK)
				ON pd.deliverableversionid = d.id
				INNER JOIN  deliverableroot r with (NOLOCK)
				ON r.id = d.deliverablerootid
				where  p.id = @ProdID
				and pd.targeted=1			
				and r.typeid <> 1
				)
			group by o.affected_state_Name, case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end
			order by o.affected_state_Name, case when o.priority in (0,1) then 1 when o.priority=2 then 2 else 3 end
		END

	END
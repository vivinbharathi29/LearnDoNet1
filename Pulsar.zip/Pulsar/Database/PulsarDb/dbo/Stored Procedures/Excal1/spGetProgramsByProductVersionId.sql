﻿/*************************************************************************************************
*     Purpose: Get Programs By Product Version Id            
*  Created By: Herb Lin
* Modified By:       
**************************************************************************************************/

CREATE PROCEDURE [dbo].[spGetProgramsByProductVersionId]
	@ProductVersionID int
AS

SELECT
	pg.ID,
	pg.FullName,
	pp.ProductVersionID

FROM Program pg
INNER JOIN Product_Program pp
	ON pg.ID = pp.ProgramID

WHERE pp.ProductVersionID = @ProductVersionID

ORDER BY pg.FullName

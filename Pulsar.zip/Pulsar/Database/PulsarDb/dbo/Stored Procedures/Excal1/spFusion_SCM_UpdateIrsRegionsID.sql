﻿
CREATE PROCEDURE [dbo].[spFusion_SCM_UpdateIrsRegionsID]
AS
	UPDATE Regions
	SET IRSRegionId = IRS_Region.RegionID
	FROM IRS_Region WITH (NOLOCK) INNER JOIN Regions WITH (NOLOCK) ON IRS_Region.DASHCode = Regions.OptionConfig
	WHERE Regions.IRSRegionId IS NULL


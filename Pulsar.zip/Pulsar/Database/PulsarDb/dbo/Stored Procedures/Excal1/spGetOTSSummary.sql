﻿/******************************************************************************
**	File: 
**	Name: 
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  02/15/2018	Santhana(auth\prabhuks) View Name changed from si_observation_report to SI_Observation_Report_Simplified 
**  12/10/2018	Santhana(auth\prabhuks) Used the Open Query to improve performance in Remote Query
*******************************************************************************/
CREATE PROCEDURE [dbo].[spGetOTSSummary]
(
	@ID as varchar(7)
)
 AS
 /*
Select CAST(observationid AS int) ID, shortdescription as Summary, Priority, State
FROM HOUSIREPORT01.SIO.dbo.SI_Observation_Report_Simplified with (NOLOCK)
Where  observationid = @ID*/
	DECLARE @OPENQUERY nvarchar(MAX), @TSQL nvarchar(4000), @LinkedServer nvarchar(4000)
	SET @ID = ISNULL(@ID,'')

	SET @LinkedServer = 'HOUSIREPORT01'
	SET @OPENQUERY = 'SELECT * FROM OPENQUERY('+ @LinkedServer + ','''
	SET @TSQL ='Select CAST(observationid AS int) ID, shortdescription as Summary, Priority, State
		FROM SIO.dbo.SI_Observation_Report_Simplified with (NOLOCK)
		Where  observationid =''''' + @ID + '''''''' +')'

	EXEC (@OPENQUERY+@TSQL) 
	
GO


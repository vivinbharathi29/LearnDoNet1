﻿
CREATE PROCEDURE [dbo].[spListAccessoriesWithNoPartorKitNumbers]
(
	@AccessoryPMID int
)
AS
	Select distinct r.id , r.name as deliverablename, r.subassembly, kitnumber
	from deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK), vendor vd with (NOLOCK), deliverablecategory c with (NOLOCK)
	where r.id = v.deliverablerootid
	and v.vendorid = vd.id
	and r.categoryid = c.id
	and c.accessory=1
	and (subassembly = '' or subassembly is null or KitNumber = '' or KitNumber is null)
	and v.filename not like 'HFCN%'
	and v.id in (Select pd.deliverableversionid from product_deliverable pd with (NOLOCK), productversion v with (NOLOCK) where v.id = pd.productversionid and pd.accessorystatusID > 1 and v.accessoryPMID=@AccessoryPMID)
	order by r.name
	





﻿CREATE PROCEDURE [dbo].[spGetPilotStatusRelease]
/* ************************************************************************************************
 * Purpose: for today page section "Expired Pilot Schedule Dates" and "Edit Pilot Status" in Deliverable Tab for Pulsar Product
 * Created By:	Dien Bui
 * Modified By: 
 *				  
 **************************************************************************************************/
(
	@ProductDeliverableReleaseID int
)
 AS

Select	pv.partnerid, 
		pdr.id, 
		pdr.PilotStatusID, 
		pdr.targetNotes,  
		pv.devcenter, 
		pdr.PilotNotes, 
		t.status as TestStatus, 
		pdr.TestStatusID, 
		pdr.TestDate, 
		pdr.PilotDate, 
		r.name as DeliverableName, 
		v.version, 
		v.revision, 
		v.pass, 
		v.modelnumber, 
		v.partnumber, 
		vd.name as vendor, 
		pv.dotsname as Product
from 
	product_deliverable pd WITH (NOLOCK)
	INNER JOIN deliverableversion v WITH (NOLOCK) on pd.deliverableversionid = v.id
	INNER JOIN productversion pv WITH (NOLOCK) on pv.id = pd.productversionid
	INNER JOIN productfamily f WITH (NOLOCK) on f.id=pv.productfamilyid
	INNER JOIN vendor vd WITH (NOLOCK) on vd.id=v.vendorid
	INNER JOIN deliverableroot r WITH (NOLOCK) on r.id = v.deliverablerootid
	INNER JOIN Product_Deliverable_Release pdr WITH (NOLOCK) on pdr.ProductDeliverableID = pd.ID
	LEFT OUTER JOIN TestStatus t WITH (NOLOCK) on t.id = pdr.teststatusid
where pdr.ID = @ProductDeliverableReleaseID

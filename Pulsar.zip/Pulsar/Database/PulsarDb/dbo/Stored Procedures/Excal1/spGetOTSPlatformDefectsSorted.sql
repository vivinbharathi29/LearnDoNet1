﻿/******************************************************************************
**	File: 
**	Name: 
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  02/15/2018	Santhana(auth\prabhuks) View Name changed from si_observation_report to SI_Observation_Report_Simplified  
**  02/15/2018	Santhana(auth\prabhuks) Used Open query for performance improvement in Remote Query 
*******************************************************************************/
CREATE Procedure [dbo].[spGetOTSPlatformDefectsSorted]
( 
	@Product varchar(20),
	@Status int)
AS

	DECLARE @OPENQUERY nvarchar(MAX), @TSQL nvarchar(MAX), @LinkedServer nvarchar(MAX)

	SET @LinkedServer = 'HOUSIREPORT01'
	SET @OPENQUERY = 'SELECT * FROM OPENQUERY('+ @LinkedServer + ','''
	SET @Product = ISNULL(@Product,'')


	if @Status = 0
		SET @TSQL = 'SELECT  observationid, status, state, OwnerName as [Owner], ComponentPMName as programmanager,
				priority, GatingMilestone, shortdescription 
		FROM SIO.dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
		WHERE status <> ''''Closed''''
		AND PrimaryProduct = '''''+ @Product + '''''
		ORDER BY observationid desc'''+')'
	else
		SET @TSQL = 'SELECT  observationid, status, state,OwnerName as [Owner], ComponentPMName as programmanager,
				priority, GatingMilestone, shortdescription 
		FROM SIO.dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
		WHERE PrimaryProduct ='''''+ @Product + '''''
		ORDER BY observationid desc'''+')'

		EXEC (@OPENQUERY+@TSQL) 
GO



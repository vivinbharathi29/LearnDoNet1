﻿

CREATE PROCEDURE [dbo].[spLinkOTS2Version]
 (
  @OTSNumber as varchar(7),
  @DeliverableID as int
 )
 AS
Insert OTS_DelVer (OTSNumber,DeliverableVersionId)
Values (@OTSNumber,  @DeliverableID)




﻿
CREATE PROCEDURE [dbo].[spGetPilotStatus]

(
	@ProdID int,
	@VersionID int
)
 AS

Select pv.partnerid, pd.id, pd.PilotStatusID, pd.targetNotes,  pv.devcenter, pd.PilotNotes, t.status as TestStatus, pd.TestStatusID, pd.TestDate, pd.PilotDate, r.name as DeliverableName, v.version, v.revision, v.pass, v.modelnumber, v.partnumber, vd.name as vendor, pv.dotsname as Product
from 
	product_deliverable pd WITH (NOLOCK)
	INNER JOIN deliverableversion v WITH (NOLOCK) on pd.deliverableversionid = v.id
	INNER JOIN productversion pv WITH (NOLOCK) on pv.id = pd.productversionid
	INNER JOIN productfamily f WITH (NOLOCK) on f.id=pv.productfamilyid
	INNER JOIN vendor vd WITH (NOLOCK) on vd.id=v.vendorid
	INNER JOIN deliverableroot r WITH (NOLOCK) on r.id = v.deliverablerootid
	LEFT OUTER JOIN TestStatus t WITH (NOLOCK) on t.id = pd.teststatusid
where 
	pd.productversionid = @ProdID
and pd.deliverableversionid = @VersionID


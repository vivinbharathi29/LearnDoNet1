﻿

CREATE PROCEDURE [dbo].[spGetRolloutDate]
(
	@ProductID int,
	@Priority int,
	@Dash varchar(10) = '',
	@ImageDefID int  =0
)
 AS
Declare @Result varchar(30)
Declare @ActualPriority sql_variant 
if @Dash <> ''
	Select @ActualPriority = i.Priority
	From Images i with (NOLOCK), Regions r with (NOLOCK)
	Where i.RegionID = r.id
	and r.Dash = @Dash
	and i.imagedefinitionid = @ImageDefID
else
	Select @ActualPriority = @Priority
if @ActualPriority=1
	Begin
		Select @result = TargetDate
		From Milestone with (NOLOCK)
		Where ProductVersionID = @ProductID
		and milestoneid = 433
	End
else if @ActualPriority=2
	Begin
		Select @result = TargetDate
		From Milestone with (NOLOCK)
		Where ProductVersionID = @ProductID
		and milestoneid = 463
	End
else if @ActualPriority=3
	Begin
		Select @result = TargetDate
		From Milestone with (NOLOCK)
		Where ProductVersionID = @ProductID
		and milestoneid = 464
	End
else if @ActualPriority=4
	Begin
		Select @result = TargetDate
		From Milestone with (NOLOCK)
		Where ProductVersionID = @ProductID
		and milestoneid = 470
	End
else if @ActualPriority=5
	Begin
		Select @result = TargetDate
		From Milestone with (NOLOCK)
		Where ProductVersionID = @ProductID
		and milestoneid = 471
	End
if @Result <> ''
	Select @Result as RTM
else
	Select @ActualPriority as RTM





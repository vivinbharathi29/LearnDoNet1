﻿/**************************************************************************************************/
  /** Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
**  1	21/3/18		Monica	Changed ansi standard,filtered and added join
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spGetLanguageStatuses4Milestone]
 (
  @DelID int,
  @MilestoneID int
 )
 AS
SELECT Abbreviation, 
Language,Status,
 Planned, milestone, 
 WorkflowComplete, 
 dl.ID as ID, 
 ds.ID as MilestoneID, 
 dl.Failed
FROM (SELECT ID, Planned, milestone,StatusID
FROM  DeliverableSchedule ds with (NOLOCK)
WHERE ds.DeliverableVersionID = @DelID
and ds.ID = @MilestoneID
) ds
 INNER JOIN (SELECT l.ID,
	Abbreviation, 
	Language,
	WorkflowComplete,dl.MilestoneId,dl.failed
 FROM Language l with (NOLOCK)
 INNER JOIN Language_DelVer dl with (NOLOCK)
 ON l.ID = dl.LanguageID
 WHERE dl.WorkflowComplete <> 1)dl
 ON dl.MilestoneId = ds.ID
  INNER JOIN ScheduleStatus ss with (NOLOCK)
  ON ss.ID = ds.StatusID




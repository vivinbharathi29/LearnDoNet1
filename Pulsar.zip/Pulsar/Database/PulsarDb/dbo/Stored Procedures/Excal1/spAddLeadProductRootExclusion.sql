﻿CREATE PROCEDURE [dbo].[spAddLeadProductRootExclusion] 
/* ************************************************************************************************
 * Purpose:	"Add Lead Product Root Exclusions" section in TodayPage
 * Created By:	?
 * Modified By: 03/23/2018 - buidi - Assign Lead Product Version Release to Release
 **************************************************************************************************/
(
	@ProductVersionID int, --Follower Product
	@DeliverableRootID int,
	@Comments varchar(8000)='',
	@ReleaseID int = 0
)
AS
	Insert Into ProductLeadRootExceptions(ProductVersionID, DeliverableRootID, Comments, ReleaseID)
	Values(@ProductVersionID, @DeliverableRootID, @Comments, @ReleaseID)
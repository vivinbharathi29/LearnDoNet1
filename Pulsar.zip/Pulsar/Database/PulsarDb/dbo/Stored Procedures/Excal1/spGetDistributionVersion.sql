﻿

CREATE PROCEDURE [dbo].[spGetDistributionVersion]
(
	@ProdID int,
	@VersionID int
)
 AS
	Select pd.patch,PD.DRDVD,PD.RACD_Americas,PD.RACD_APD,PD.RACD_EMEA,PD.OSCD,PD.DocCD, PD.Preinstall,  PD.Preload, PD.Web, PD.DropInBox as DIB, pd.ARCD,pd.SelectiveRestore, PD.ImageSummary, pd.restoreimages, PD.Images, r.typeid
	FROM Product_Deliverable pd with (NOLOCK), DeliverableVersion v with (NOLOCK), Deliverableroot r with (NOLOCK)
	Where pd.ProductVersionID = @ProdID
	and r.id = v.deliverablerootid
	and v.id = pd.deliverableversionid
	and pd.DeliverableVersionID = @VersionID





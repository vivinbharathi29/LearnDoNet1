﻿
CREATE PROCEDURE [dbo].[spAddEmployeeUserSetting]
(
	@EmployeeID int,
	@UserSettingsID int,
	@Value varchar(8000),
	@NewID int OUTPUT
)

AS

	Insert into Employee_UserSettings (EmployeeID, UserSettingsID, Setting)
	Values(@EmployeeID,@UserSettingsID,@Value)

	set nocount on
	Select @NewID = SCOPE_IDENTITY()
	set nocount off


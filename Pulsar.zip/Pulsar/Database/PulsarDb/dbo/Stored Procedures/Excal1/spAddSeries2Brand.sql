﻿

CREATE PROCEDURE [dbo].[spAddSeries2Brand]
(
	@BrandID int,
	@Name varchar(50)
)

 AS

DECLARE @MasterLabel VARCHAR(50), @CTOModelNumber VARCHAR(50) 

SELECT @MasterLabel = MasterLabel, @CTOModelNumber = CTOModelNumber from Product_Brand WITH (NOLOCK) WHERE ID = @BrandID

Insert into Series(ProductBrandID,Name, MasterLabel, CTOModelNumber)
Values(@BrandID, @Name, @MasterLabel, @CTOModelNumber);




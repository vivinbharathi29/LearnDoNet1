﻿
CREATE PROCEDURE [dbo].[spGetSubassemblyCount]
(
	@ProdID int,
	@VersionID int
)
 AS

DECLARE @ProdDelID int

Select @ProdDelID = ID from product_deliverable with (NOLOCK) where productversionid = @ProdID and deliverableversionid = @VersionID

Select Count(*) as Number
from proddel_delroot pd with (NOLOCK)
where pd.productdeliverableid  =@ProdDelID

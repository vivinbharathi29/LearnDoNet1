﻿

CREATE PROCEDURE [dbo].[spListActionItemsDetails]
(
	@ProdID int,
	@Type int,
	@Status int,
	@BiosChange bit = NULL
)
 AS

DECLARE @v_Type INT
If (@Type != 0)
	SET @v_Type = @Type

if @ProdID = 0
	Begin
	if @Status = 0
		Select  v.dotsname as Product, i.id, i.Type, i.Status, e.name as Owner, i.Summary, i.Description, i.Created, i.TargetDate, i.ActualDate, ct.Name as CoreTeamRep,i.Submitter,i.notify,i.BTO,i.CTO,i.NA,i.LA,i.APD,i.CKK,i.EMEA,i.GCD,i.OnStatusReport,i.LastModified,i.Justification,i.BTODate,i.CTODate, i.Approvals,i.Actions, i.Resolution
		FROM 
			DeliverableIssues i WITH (NOLOCK)
			inner join Employee e WITH (NOLOCK) on e.id = i.OwnerID
			inner join ProductVersion v WITH (NOLOCK) on v.ID = i.ProductVersionID
			inner join ProductFamily f WITH (NOLOCK) on f.id = v.ProductFamilyID
			left outer join CoreTeamRep ct WITH (NOLOCK) on ct.ID = i.CoreTeamRep
		Where 
			Type= COALESCE(@v_Type, Type)
		and f.ID = v.ProductFamilyID
		and i.ProductVersionID = v.ID
		and (@BiosChange IS NULL 
		 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
		 OR (@BiosChange = 0 AND 
			(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
		Order By Product, i.ID
	else if @Status =1
		Select  v.dotsname as Product, i.id, i.Type, i.Status, e.name as Owner, i.Summary, i.Description, i.Created, i.TargetDate, i.ActualDate, ct.Name as CoreTeamRep,i.Submitter,i.notify,i.BTO,i.CTO,i.NA,i.LA,i.APD,i.CKK,i.EMEA,i.GCD,i.OnStatusReport,i.LastModified,i.Justification,i.BTODate,i.CTODate, i.Approvals,i.Actions,i.resolution
		FROM 
			DeliverableIssues i WITH (NOLOCK)
			inner join Employee e WITH (NOLOCK) on e.id = i.OwnerID
			inner join ProductVersion v WITH (NOLOCK) on v.ID = i.ProductVersionID
			inner join ProductFamily f WITH (NOLOCK) on f.id = v.ProductFamilyID
			left outer join CoreTeamRep ct WITH (NOLOCK) on ct.ID = i.CoreTeamRep
		Where 
			Type= COALESCE(@v_Type, Type)
		and (i.Status = 1 or i.Status = 3 or i.status = 6)
		and f.ID = v.ProductFamilyID
		and i.ProductVersionID = v.ID
		and (@BiosChange IS NULL 
		 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
		 OR (@BiosChange = 0 AND 
			(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
		Order By Product, i.ID
	else if @Status =2
		Select  v.dotsname as Product, i.id, i.Type, i.Status, e.name as Owner, i.Summary, i.Description, i.Created, i.TargetDate, i.ActualDate, ct.Name as CoreTeamRep,i.Submitter,i.notify,i.BTO,i.CTO,i.NA,i.LA,i.APD,i.CKK,i.EMEA,i.GCD,i.OnStatusReport,i.LastModified,i.Justification,i.BTODate,i.CTODate, i.Approvals,i.Actions,i.resolution
		FROM 
			DeliverableIssues i WITH (NOLOCK)
			inner join Employee e WITH (NOLOCK) on e.id = i.OwnerID
			inner join ProductVersion v WITH (NOLOCK) on i.ProductVersionID = v.ID
			inner join ProductFamily f WITH (NOLOCK) on f.ID = v.ProductFamilyID
			left outer join CoreTeamRep ct WITH (NOLOCK) on ct.id = i.CoreTeamRep
		Where 
			Type= COALESCE(@v_Type, Type)
		and (i.Status = 2 or i.Status = 4 or i.Status = 5)
		and f.ID = v.ProductFamilyID
		and i.ProductVersionID = v.ID
		and (@BiosChange IS NULL 
		 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
		 OR (@BiosChange = 0 AND 
			(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
		Order By Product, i.ID
	else if @Status =3
		Select v.dotsname as Product, i.id, i.Type, i.Status, e.name as Owner, i.Summary, i.Description, i.Created, i.TargetDate, i.ActualDate, ct.Name as CoreTeamRep,i.Submitter,i.notify,i.BTO,i.CTO,i.NA,i.LA,i.APD,i.CKK,i.EMEA,i.GCD,i.OnStatusReport,i.LastModified,i.Justification,i.BTODate,i.CTODate, i.Approvals,i.Actions,i.resolution
		FROM 
			DeliverableIssues i WITH (NOLOCK)
			inner join Employee e WITH (NOLOCK) on e.id = i.OwnerID
			inner join ProductVersion v WITH (NOLOCK) on i.ProductVersionID = v.ID
			inner join ProductFamily f WITH (NOLOCK) on f.ID = v.ProductFamilyID
			left outer join CoreTeamRep ct WITH (NOLOCK) on ct.id = i.CoreTeamRep
		Where 
			Type= COALESCE(@v_Type, Type)
		and i.OnStatusReport = 1
		and f.ID = v.ProductFamilyID
		and i.ProductVersionID = v.ID
		and (@BiosChange IS NULL 
		 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
		 OR (@BiosChange = 0 AND 
			(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
		Order By Product, i.ID
	end
else
	begin
	if @Status = 0 
		Select  v.dotsname as Product, i.id, i.Type, i.Status, e.name as Owner, i.Summary, i.Description, i.Created, i.TargetDate, i.ActualDate, ct.Name as CoreTeamRep,i.Submitter,i.notify,i.BTO,i.CTO,i.NA,i.LA,i.APD,i.CKK,i.EMEA,i.GCD,i.OnStatusReport,i.LastModified,i.Justification,i.BTODate,i.CTODate, i.Approvals,i.Actions,i.resolution
		FROM 
			DeliverableIssues i WITH (NOLOCK)
			inner join Employee e WITH (NOLOCK) on e.id = i.OwnerID
			inner join ProductVersion v WITH (NOLOCK) on i.ProductVersionID = v.ID
			inner join ProductFamily f WITH (NOLOCK) on f.ID = v.ProductFamilyID
			left outer join CoreTeamRep ct WITH (NOLOCK) on ct.id = i.CoreTeamRep
		Where i.ProductVersionID = @ProdID
		and Type= COALESCE(@v_Type, Type)
		and f.ID = v.ProductFamilyID
		and i.ProductVersionID = v.ID
		and (@BiosChange IS NULL 
		 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
		 OR (@BiosChange = 0 AND 
			(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
		Order By Product, i.ID
	else if @Status =1
		Select  v.dotsname as Product, i.id, i.Type, i.Status, e.name as Owner, i.Summary, i.Description, i.Created, i.TargetDate, i.ActualDate, ct.Name as CoreTeamRep,i.Submitter,i.notify,i.BTO,i.CTO,i.NA,i.LA,i.APD,i.CKK,i.EMEA,i.GCD,i.OnStatusReport,i.LastModified,i.Justification,i.BTODate,i.CTODate, i.Approvals,i.Actions,i.resolution
		FROM 
			DeliverableIssues i WITH (NOLOCK)
			inner join Employee e WITH (NOLOCK) on e.id = i.OwnerID
			inner join ProductVersion v WITH (NOLOCK) on i.ProductVersionID = v.ID
			inner join ProductFamily f WITH (NOLOCK) on f.ID = v.ProductFamilyID
			left outer join CoreTeamRep ct WITH (NOLOCK) on ct.id = i.CoreTeamRep
		Where i.ProductVersionID = @ProdID
		and Type= COALESCE(@v_Type, Type)
		and ((i.Status = 1 or i.Status = 3 or i.status = 6) or ((v.sustaining = 1 or  i.CoreTeamRep = 12) and i.status=4 and i.ecndate is null))
		and f.ID = v.ProductFamilyID
		and i.ProductVersionID = v.ID
		and (@BiosChange IS NULL 
		 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
		 OR (@BiosChange = 0 AND 
			(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
		Order By Product, i.ID
	else if @Status =2
		Select  v.dotsname as Product,i.id, i.Type, i.Status, e.name as Owner, i.Summary, i.Description, i.Created, i.TargetDate, i.ActualDate, ct.Name as CoreTeamRep,i.Submitter,i.notify,i.BTO,i.CTO,i.NA,i.LA,i.APD,i.CKK,i.EMEA,i.GCD,i.OnStatusReport,i.LastModified,i.Justification,i.BTODate,i.CTODate, i.Approvals,i.Actions,i.resolution
		FROM 
			DeliverableIssues i WITH (NOLOCK)
			inner join Employee e WITH (NOLOCK) on e.id = i.OwnerID
			inner join ProductVersion v WITH (NOLOCK) on i.ProductVersionID = v.ID
			inner join ProductFamily f WITH (NOLOCK) on f.ID = v.ProductFamilyID
			left outer join CoreTeamRep ct WITH (NOLOCK) on ct.id = i.CoreTeamRep
		Where i.ProductVersionID = @ProdID
		and Type= COALESCE(@v_Type, Type)
--		and (i.Status = 2 or i.Status = 4 or i.Status = 5)
		and ((i.Status = 2  or i.Status = 5) or ((v.sustaining = 1 or  i.CoreTeamRep = 12) and i.status=4 and i.ecndate is not null) or ((v.sustaining <> 1 and  i.CoreTeamRep <> 12) and  i.Status = 4)  )
		and f.ID = v.ProductFamilyID
		and i.ProductVersionID = v.ID
		and (@BiosChange IS NULL 
		 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
		 OR (@BiosChange = 0 AND 
			(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
		Order By Product, i.ID
	else if @Status =3
		Select v.dotsname as Product, i.id, i.Type, i.Status, e.name as Owner, i.Summary, i.Description, i.Created, i.TargetDate, i.ActualDate, ct.Name as CoreTeamRep,i.Submitter,i.notify,i.BTO,i.CTO,i.NA,i.LA,i.APD,i.CKK,i.EMEA,i.GCD,i.OnStatusReport,i.LastModified,i.Justification,i.BTODate,i.CTODate, i.Approvals,i.Actions,i.resolution
		FROM 
			DeliverableIssues i WITH (NOLOCK)
			inner join Employee e WITH (NOLOCK) on e.id = i.OwnerID
			inner join ProductVersion v WITH (NOLOCK) on i.ProductVersionID = v.ID
			inner join ProductFamily f WITH (NOLOCK) on f.ID = v.ProductFamilyID
			left outer join CoreTeamRep ct WITH (NOLOCK) on ct.id = i.CoreTeamRep
		Where i.ProductVersionID = @ProdID
		and Type= COALESCE(@v_Type, Type)
		and i.OnStatusReport = 1
		and f.ID = v.ProductFamilyID
		and i.ProductVersionID = v.ID
		and (@BiosChange IS NULL 
		 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
		 OR (@BiosChange = 0 AND 
		(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
		Order By Product, i.ID
	end


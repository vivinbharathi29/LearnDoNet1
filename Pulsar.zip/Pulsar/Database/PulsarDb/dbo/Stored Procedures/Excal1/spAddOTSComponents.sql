﻿
CREATE PROCEDURE [dbo].[spAddOTSComponents] 
(
	@ProductID int,
	@Role1 int, --pdm
	@Role2 int, --sepm
	@Role3 int, --commoditypm
	@Role4 int, --pin pm
	@Role5 int, --pe
	@Role6 int, --BIOS Lead
	@Role7 int
)
AS

DECLARE @Pulsar BIT
SELECT @Pulsar = FusionRequirements FROM ProductVersion WHERE ID = @ProductID

IF ISNULL(@Pulsar,0) = 0
  BEGIN
	--Add Components to Excalbur
	Insert Into Product_OTSComponent (ProductVersionID, OTSComponentID, PMID,DeveloperID,Active)
	(Select @ProductID, ID, CASE When DefaultPMRole=0 then DefaultPMID WHEN DefaultPMRole = 1 THEN @Role1 When DefaultPMRole=2 Then @Role2  When DefaultPMRole=3 Then @Role3  When DefaultPMRole=4 Then @Role4  When DefaultPMRole=5 Then @Role5  When DefaultPMRole=6 Then @Role6  When DefaultPMRole=7 Then @Role7 END AS PMID, CASE When DefaultDeveloperRole=0 then DefaultDeveloperID WHEN DefaultDeveloperRole = 1 THEN @Role1 When DefaultDeveloperRole=2 Then @Role2  When DefaultDeveloperRole=3 Then @Role3  When DefaultDeveloperRole=4 Then @Role4  When DefaultDeveloperRole=5 Then @Role5  When DefaultDeveloperRole=6 Then @Role6  When DefaultDeveloperRole=7 Then @Role7 END AS DeveloperID,1
	from OTSComponent with (NOLOCK)
	where active=1
	and id not in	(
					Select OTSComponentID
					From product_OTSComponent with (NOLOCK)
					where productversionid = @ProductID
					)

	)
  END
ELSE IF @Pulsar = 1
  BEGIN
	--remove the Audio, Digitizer, Keyboard, System Board, and Video from OTS Generics ONLY for Pulsar Products
	Insert Into Product_OTSComponent (ProductVersionID, OTSComponentID, PMID,DeveloperID,Active)
	(Select @ProductID, ID, CASE When DefaultPMRole=0 then DefaultPMID WHEN DefaultPMRole = 1 THEN @Role1 When DefaultPMRole=2 Then @Role2  When DefaultPMRole=3 Then @Role3  When DefaultPMRole=4 Then @Role4  When DefaultPMRole=5 Then @Role5  When DefaultPMRole=6 Then @Role6  When DefaultPMRole=7 Then @Role7 END AS PMID, CASE When DefaultDeveloperRole=0 then DefaultDeveloperID WHEN DefaultDeveloperRole = 1 THEN @Role1 When DefaultDeveloperRole=2 Then @Role2  When DefaultDeveloperRole=3 Then @Role3  When DefaultDeveloperRole=4 Then @Role4  When DefaultDeveloperRole=5 Then @Role5  When DefaultDeveloperRole=6 Then @Role6  When DefaultDeveloperRole=7 Then @Role7 END AS DeveloperID,1
	from OTSComponent with (NOLOCK)
	where active=1
	and ID NOT IN (9,20,30,33,48,49)
	and id not in	(
					Select OTSComponentID
					From product_OTSComponent with (NOLOCK)
					where productversionid = @ProductID
					)

	)
  END

--Generate the Unique OTS ID for each component in Excalibur that doesn;t already have one
Update product_OTSComponent
set OTSPartNumber = 'EXC-A' + right('00000000' + cast(ID as varchar(20)),8)
where otspartnumber is null

--Deactivate unneeded components for docking stations
Update product_OTSComponent
set Active=0
where ProductVersionID in (
					Select id
					from ProductVersion 
					where TypeID = 3
					and id = @ProductID
							)
and OTSComponentID in (Select OTSComponentID from Product_OTSComponent where productversionID = 959 and active=0)



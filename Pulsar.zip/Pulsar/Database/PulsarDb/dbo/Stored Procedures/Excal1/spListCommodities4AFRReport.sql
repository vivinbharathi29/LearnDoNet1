﻿/****************************************
*THIS IS USED BY EXTERNAL USER; sql login TCE_Visor. DO NOT REMOVE. 
Some info:

Eastwood application 
eprid 203141 
is using pulsar data; these reports are seen by business, i think they will connect to SSAS cubes to see the reports or with Power BI
support owner: muthuvel.chenrayan@hp.com  and dilip.kumar2@hp.com
business owner: vidya.kamat@hp.com
More info in the Wiki
*****************************************/

CREATE PROCEDURE [dbo].[spListCommodities4AFRReport]
(
	@Report int = 0
)

 AS

If @Report=0
	SELECT cv.SupplierCode, vd.Name AS Vendor, v.PartNumber, r.Name AS DeliverableType, v.ModelNumber, c.Name AS Category, v.VendorVersion, v.Version AS HWVersion, v.Revision AS FWVersion, v.Pass AS Revision, v.CodeName
	FROM            
		DeliverableRoot AS r WITH (NOLOCK) INNER JOIN
		DeliverableVersion AS v WITH (NOLOCK) ON r.ID = v.DeliverableRootID INNER JOIN
		DeliverableCategory AS c WITH (NOLOCK) ON r.CategoryID = c.ID INNER JOIN
		Vendor AS vd WITH (NOLOCK) ON v.VendorID = vd.ID LEFT OUTER JOIN
		DeliverableCategory_Vendor AS cv WITH (NOLOCK) ON r.CategoryID = cv.DeliverableCategoryID AND vd.ID = cv.VendorID
	WHERE (r.CategoryID IN (2, 3, 33, 15, 71, 36, 40, 131, 205)) 
	AND (r.RootFilename <> 'HFCN')
	ORDER BY c.Name, r.Name, v.Version, v.Revision, v.Pass

else

	SELECT cv.SupplierCode, vd.Name AS Vendor, v.PartNumber, r.Name AS DeliverableType, v.ModelNumber, c.Name AS Category, v.VendorVersion, v.Version AS HWVersion, v.Revision AS FWVersion, v.Pass AS Revision, v.CodeName
	FROM            
		DeliverableRoot AS r WITH (NOLOCK) INNER JOIN
		DeliverableVersion AS v WITH (NOLOCK) ON r.ID = v.DeliverableRootID INNER JOIN
		DeliverableCategory AS c WITH (NOLOCK) ON r.CategoryID = c.ID INNER JOIN
		Vendor AS vd WITH (NOLOCK) ON v.VendorID = vd.ID LEFT OUTER JOIN
		DeliverableCategory_Vendor AS cv WITH (NOLOCK) ON r.CategoryID = cv.DeliverableCategoryID AND vd.ID = cv.VendorID
	WHERE 
		(r.CategoryID IN (2, 3, 33, 15, 71, 36, 40, 131, 205)) 
	AND (r.RootFilename <> 'HFCN')
	ORDER BY c.Name, r.Name, v.Version, v.Revision, v.Pass

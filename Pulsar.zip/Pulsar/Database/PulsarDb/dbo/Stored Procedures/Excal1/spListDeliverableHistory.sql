﻿/* ************************************************************************************************
 * Object:  StoredProcedure [dbo].[spListDeliverableHistory]    Script Date: 2019/1/4 上午 11:22:04 
 * Modified By: 01/04/2019 Dean,Chiang - Component view history need record the product release cycle- PBI121
 **************************************************************************************************/

CREATE PROCEDURE [dbo].[spListDeliverableHistory] 
(
	@RootID int,
	@VersionID int,
	@ActionID int
)

AS


if @VersionID=0 --AllVersion
	SELECT     e.Name AS Username, r.TypeID, r.Name AS Deliverable, v.Version, v.Revision, v.Pass, v.VendorVersion, v.ModelNumber, v.PartNumber, r.ID AS RootID, 
						  v.ID AS VersionID, vd.Name AS vendor, a.Name AS Action, a.ActionID
						  , product = case when PV.FusionRequirements = 1 then PV.DOTSName + ' (' + isnull(ProductVersionRelease.Name,'None') + ')' else PV.DOTSName end
						  , l.Updated, CAST(l.Details AS varchar(8000)) AS details
	FROM         ActionLog AS l WITH (NOLOCK)
		INNER JOIN Employee AS e WITH (NOLOCK) ON l.UserID = e.ID
		INNER JOIN Vendor AS vd WITH (NOLOCK) 
		INNER JOIN DeliverableVersion AS v WITH (NOLOCK) ON vd.ID = v.VendorID 
		INNER JOIN DeliverableRoot AS r WITH (NOLOCK) ON v.DeliverableRootID = r.ID ON l.DeliverableVersionID = v.ID 
		INNER JOIN Actions AS a WITH (NOLOCK) ON l.ActionID = a.ActionID 
		LEFT JOIN ProductVersion AS PV WITH (NOLOCK) ON l.ProductVersionID = PV.ID
		LEFT JOIN ProductVersion_Release PVR ON PVR.ID = l.ProductVersionReleaseID
		LEFT JOIN ProductVersionRelease ON ProductVersionRelease.ID =PVR.ReleaseID
	WHERE     (a.ActionID = COALESCE (@ActionID, a.ActionID)) AND (l.DeliverableVersionID IN
							  (SELECT     ID
								FROM          DeliverableVersion WITH (NOLOCK)
								WHERE      (DeliverableRootID = @RootID)))

	union

	SELECT     e.Name AS Username, r.TypeID, r.Name AS Deliverable, '' AS version, '' AS revision, '' AS pass, '' AS vendorversion, '' AS modelnumber, '' AS partnumber, 
						  r.ID AS RootID, 0 AS VersionID, '' AS vendor, a.Name AS Action, a.ActionID
						  , product = case when PV.FusionRequirements = 1 then PV.DOTSName + ' (' + isnull(ProductVersionRelease.Name,'None') + ')' else PV.DOTSName end
						  , l.Updated, CAST(l.Details AS varchar(8000)) AS details
	FROM         ActionLog AS l WITH (NOLOCK) 
		INNER JOIN Employee AS e WITH (NOLOCK) ON l.UserID = e.ID
		INNER JOIN DeliverableRoot AS r WITH (NOLOCK) ON l.DeliverableRootID = r.ID
		INNER JOIN Actions AS a WITH (NOLOCK) ON l.ActionID = a.ActionID
		LEFT JOIN ProductVersion AS PV WITH (NOLOCK) ON l.ProductVersionID = PV.ID
		LEFT JOIN ProductVersion_Release PVR ON PVR.ID = l.ProductVersionReleaseID
		LEFT JOIN ProductVersionRelease ON ProductVersionRelease.ID =PVR.ReleaseID
	WHERE     (l.DeliverableRootID = @RootID) AND (a.ActionID = COALESCE (@ActionID, a.ActionID))
	ORDER BY l.Updated
else --Single Version
	SELECT     e.Name AS Username, r.TypeID, r.Name AS Deliverable, v.Version, v.Revision, v.Pass, v.VendorVersion, v.ModelNumber, v.PartNumber, r.ID AS RootID, 
						  v.ID AS VersionID, vd.Name AS vendor, a.Name AS Action, a.ActionID
						  , product = case when PV.FusionRequirements = 1 then PV.DOTSName + ' (' + isnull(ProductVersionRelease.Name,'None') + ')' else PV.DOTSName end
						  , l.Updated, CAST(l.Details AS varchar(8000)) AS details
	FROM         ActionLog AS l WITH (NOLOCK)
		INNER JOIN Employee AS e WITH (NOLOCK) ON l.UserID = e.ID
		INNER JOIN Vendor AS vd WITH (NOLOCK)
		INNER JOIN DeliverableVersion AS v WITH (NOLOCK) ON vd.ID = v.VendorID 
		INNER JOIN  DeliverableRoot AS r WITH (NOLOCK) ON v.DeliverableRootID = r.ID ON l.DeliverableVersionID = v.ID 
		INNER JOIN Actions AS a WITH (NOLOCK) ON l.ActionID = a.ActionID 
		LEFT JOIN ProductVersion AS PV WITH (NOLOCK) ON l.ProductVersionID = PV.ID
		LEFT JOIN ProductVersion_Release PVR ON PVR.ID = l.ProductVersionReleaseID
		LEFT JOIN ProductVersionRelease ON ProductVersionRelease.ID =PVR.ReleaseID
	WHERE     (l.DeliverableVersionID = @VersionID) AND (a.ActionID = COALESCE (@ActionID, a.ActionID))
	ORDER BY l.Updated
﻿

CREATE PROCEDURE [dbo].[spDeleteExcelProfile]
(
	@ID int
)
 AS
Delete EmployeeExcelProfiles
Where ID = @ID




﻿

CREATE PROCEDURE [dbo].[spGetExcelProfile]
(
	@ID int
)
 AS
Select *
From EmployeeExcelProfiles with (NOLOCK)
Where Id = @ID




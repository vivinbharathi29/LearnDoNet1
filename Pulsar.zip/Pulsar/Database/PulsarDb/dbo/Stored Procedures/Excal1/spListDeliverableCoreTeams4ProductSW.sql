﻿CREATE PROCEDURE [dbo].[spListDeliverableCoreTeams4ProductSW]
(
	@ID int
)
/** Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
**  1  18/7/18     Monica   Changed the join to in condition and Changed the code from ANSI statndard 
****************************************************************************************************/

AS
SET NOCOUNT ON
	Select distinct ct.id, replace(replace(ct.name,'Software','SW'),'Operating Systems','OS') as Name
	from   DeliverableCoreTeam ct WITH (NOLOCK)
	 WHERE ct.ID in
	(SELECT r.CoreTeamID	
	FROM  (SELECT pd.DeliverableVersionID
	FROm Product_Deliverable pd WITH (NOLOCK)
	where  ProductVersionID = @ID)pd
	INNER JOIN  DeliverableVersion v WITH (NOLOCK)
	 ON pd.DeliverableVersionID = v.ID 
	 INNER JOIN  DeliverableRoot r WITH (NOLOCK)
	  ON r.ID = v.DeliverableRootID
	WHERE r.TypeID = 2)
	order by name
SET NOCOUNT OFF

﻿CREATE PROCEDURE [dbo].[spAddRelease2Product]
/* ************************************************************************************************
 * Purpose:	add product schedule release
 * Created By:	
 * Modified By: 11/27/2017 - buidi - Add ID from ProductVersion_Release table to link Release with Schedule
 *				03/23/2018 - buidi - Assign Lead Product Version Release to Release
 **************************************************************************************************/
(
	@ProdID int,
	@ReleaseID int = null OUTPUT,
	@ProductVersionReleaseID int = null,
	@IsOSRolloutSchedule bit = null
)
AS


IF ((SELECT COUNT(1) FROM Product_Release with (NOLOCK) WHERE ProductVersionID = @prodid) > 0)
BEGIN
	if (@ProductVersionReleaseID > 0) 
	Begin
		if not exists (Select 1 From Product_Release with (NOLOCK) Where ProductVersionID = @prodid and isnull(ProductVersionReleaseID,0) = @ProductVersionReleaseID)
		begin
			Insert Product_Release(Productversionid, ReleaseID, ProductVersionReleaseID, IsOSRolloutSchedule)
			SELECT ProductVersionID, COALESCE(@ReleaseID, COALESCE(MAX(ReleaseID), 0) + 1), @ProductVersionReleaseID, @IsOSRolloutSchedule
			FROM Product_Release with (NOLOCK)
			WHERE ProductVersionID = @prodid
			GROUP By ProductVersionID
		end
	End
	Else
	Begin
		Insert Product_Release(Productversionid, ReleaseID, IsOSRolloutSchedule)
		SELECT ProductVersionID, COALESCE(@ReleaseID, COALESCE(MAX(ReleaseID), 0) + 1), @IsOSRolloutSchedule
		FROM Product_Release with (NOLOCK)
		WHERE ProductVersionID = @prodid
		GROUP By ProductVersionID
	End
END
ELSE
BEGIN
	Insert Product_Release(Productversionid, ReleaseID, ProductversionReleaseID, IsOSRolloutSchedule)
	VALUES (@ProdID, 1, @ProductVersionReleaseID, @IsOSRolloutSchedule)
END

Set @ReleaseID = SCOPE_IDENTITY()

RETURN
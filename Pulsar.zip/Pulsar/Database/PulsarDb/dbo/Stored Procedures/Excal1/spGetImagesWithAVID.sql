﻿

CREATE PROCEDURE [dbo].[spGetImagesWithAVID]
(
	@ProductID int,
	@BID	   int
)

AS
 
DECLARE @KMAT CHAR(10)
SELECT @KMAT = KMAT FROM Product_Brand with (NOLOCK) WHERE ID = @BID

SELECT i.ID
FROM   Images i with (NOLOCK) INNER JOIN
       ImageDefinitions d with (NOLOCK) ON i.ImageDefinitionID = d.ID
       INNER JOIN KMAT_Image ki with (NOLOCK) ON ki.imageid = i.id
WHERE  ki.KMAT = @KMAT


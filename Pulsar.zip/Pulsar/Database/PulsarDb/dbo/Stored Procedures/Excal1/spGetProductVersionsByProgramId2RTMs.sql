﻿/*************************************************************************************************
*     Purpose: Get ProductVersions By ProgramId           
*  Created By: Herb Lin
* Modified By:       
**************************************************************************************************/

CREATE PROCEDURE [dbo].[spGetProductVersionsByProgramId2RTMs]
	@ProgramID int,
	@Fusion bit = 1
AS
SELECT
	pv.ID,
	pv.DOTSName,
	pv.Fusion,
	pp.ProgramID
FROM Product_Program pp
INNER JOIN ProductVersion pv
	ON pp.ProductVersionID = pv.ID

WHERE 
	pp.ProgramID = @ProgramID
	and pv.Fusion = @Fusion
ORDER BY pv.DOTSName
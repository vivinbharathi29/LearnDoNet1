﻿/******************************************************************************
**	File: rpt_ProdBrandLocalizationDiff.sql
**	Name: rpt_ProdBrandLocalizationDiff
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  2/14/2017 spathak increase the datalength to stored the list of localization selected for a country. Bug 31608
**  31/01/2018	Santhana(auth\prabhuks) CURSOR Based procedure changed to Normal Query
*******************************************************************************/
CREATE PROCEDURE [dbo].[rpt_ProdBrandLocalizationDiff] 

	@p_ProdBrandIDList VARCHAR(1000) 
AS

SET NOCOUNT ON

	IF ISNULL(@p_ProdBrandIDList,'') = '' 
		SET @p_ProdBrandIDList = '0'

	CREATE TABLE #Diff
	(
	CountryID INT,
	[Group] VARCHAR(15),
	Country VARCHAR(50)
	)

	INSERT INTO #Diff (CountryID, [Group], Country)
	SELECT ID, Region, Language
	FROM Language with (NOLOCK)
	WHERE ID IN (
	SELECT DISTINCT c.ID AS CountryID
	FROM 
		ProdBrandCountry_Localization pbcl with (NOLOCK)
		INNER JOIN ProdBrand_Country pbc with (NOLOCK) ON pbcl.ProdBrandCountryID = pbc.ID
		INNER JOIN Language c with (NOLOCK) ON pbc.CountryID = c.ID
	WHERE
		c.IsLanguage = 0
	AND	c.Active = 1
	AND	pbc.ProductBrandID IN (SELECT * FROM dbo.ufn_Split(@p_ProdBrandIdList, ','))
	GROUP BY pbcl.LocalizationID, c.ID
	HAVING COUNT(pbcl.ID) < (SELECT COUNT(*) FROM dbo.ufn_Split(@p_ProdBrandIdList, ','))
	)
	ORDER BY Region DESC, Language ASC


		Declare @Str varchar(max), @StrQuoted varchar(max);
		select @Str= COALESCE(@Str +', ','') 
		+ Value --QUOTENAME(Value) 
		FROM (SELECT Value FROM dbo.ufn_Split(@p_ProdBrandIDList,',')) as V;

		select @StrQuoted = COALESCE(@StrQuoted +', ','')+QUOTENAME(Value)
		FROM (SELECT Value FROM dbo.ufn_Split(@p_ProdBrandIDList,',')) as V1;

			exec(
			'with Columns1 AS
					 (
			select pb.ID id,
			 pv.dotsname +'' ''+ b.Name as SName
			 FROM ProductFamily f INNER JOIN ProductVersion pv ON f.id = pv.ProductFamilyID 
			INNER JOIN Product_Brand pb on pb.ProductVersionID = pv.ID INNER JOIN Brand b on pb.BrandID = b.ID WHERE pb.ID in ('+ @Str +'))
			'+
			'select ''Country'' as Country, '+@StrQuoted +' from Columns1
			 pivot (max(SName) for id IN ('+@StrQuoted+') )as P') 
		 
			exec(
			'with col2 AS
			(
			 select [Group],Country,value ProdBrandID,COALESCE(dbo.ufn_GetBrandCountryOptionConfigList(#Diff.CountryID , value), ''&nbsp;'') as Name
			 from dbo.ufn_Split('''+@p_ProdBrandIDList+''', '',''),#Diff  WHERE #Diff.CountryID = #Diff.CountryID
			)
			select [Group],Country,'+@StrQuoted +' from col2
			 pivot (max(Name) for ProdBrandID IN ('+@StrQuoted +') ) as P'
			)
			

	DROP TABLE #Diff

	SET NOCOUNT OFF

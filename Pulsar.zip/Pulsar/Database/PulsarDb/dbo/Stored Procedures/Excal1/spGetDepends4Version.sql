﻿

CREATE PROCEDURE [dbo].[spGetDepends4Version]
 (
  @ID as int
 )
 
 AS
SELECT r.name as Name, v.Version as Version, v.revision as revision, v.pass as pass, r.name as root, v.id as id
FROM Depend_DelRoot d with (NOLOCK), DeliverableRoot r with (NOLOCK), DeliverableVersion v with (NOLOCK)
WHERE d.DependID = r.ID
and r.id = v.deliverablerootid 
AND d.DeliverableRootID = @ID

union

SELECT r.name as Name, v.Version as Version, v.revision as revision, v.pass as pass, r.name as root, v.id as id
FROM Depend_DelRoot d with (NOLOCK), DeliverableRoot r with (NOLOCK), DeliverableVersion v with (NOLOCK)
WHERE d.DeliverableRootID = r.ID
and r.id = v.deliverablerootid 
AND d.DependID = @ID
Order By r.name, v.version desc,v.revision desc,v.pass desc;










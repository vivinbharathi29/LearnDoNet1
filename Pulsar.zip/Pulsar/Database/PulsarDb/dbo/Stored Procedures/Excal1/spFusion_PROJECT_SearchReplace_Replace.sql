﻿
CREATE PROCEDURE [dbo].[spFusion_PROJECT_SearchReplace_Replace]
/* ************************************************************************************************
 * Purpose:		Do a Replace for Search and Replace in IRS Projects
 * Created By:	08/01/2013 JCope
 * Modified By:	
				11/28/2016 linshant - update sort order depend on user selection - PBI 29943
				06/20/2018 linshant - Sync Images with IRS to consider Component Version's Destination Country/Region and Image Locale settings - PBI 208895
 **************************************************************************************************/
	@p_OldPart varchar(200),
	@p_NewPart varchar(200),	
	@p_intUserID int,
	@p_chrProductDropIDs varchar(max),
	@p_IsCD bit	= 0,
	@p_InstallOptionRequest int,
	@p_LockValue int,
	@p_SortOrderOverride int = 0,
	@p_DestOverride int = 0,
	@p_LocaleOverride int =0
AS
	SET NOCOUNT ON

	exec IRSTest_usp_Project_SearchReplace_Replace @p_OldPart, @p_NewPart, @p_intUserID, @p_chrProductDropIDs, @p_IsCD, @p_InstallOptionRequest, @p_LockValue, @p_SortOrderOverride, @p_DestOverride, @p_LocaleOverride

	if @@error <> 0 begin
		raiserror('Error:spFusion_PROJECT_SearchReplace_Replace - Error returned from IRSTest_usp_Project_SearchReplace_Replace.', 16, 1)
		return 1
	end

	return 0



﻿CREATE PROCEDURE [dbo].[spFusion_VENDOR_AddVendorToIRS]
(
	@ID int,
	@QueryType varchar(50) = NULL
)
AS

	/*****************************************************************************
 * Purpose:	Get All Operating Systems
 * Created By:	
 * Modified By: #2 2014-08-11 Luhit Young,  Description:Get the vendor name.If the vendor name does not exist in IRS, add the vendor.
                              Ragishet, Updated to feed IRS vendor table when Vendor created/updated in PRS - Task : 8118
	 
	******************************************************************************/

	            Declare @PRS_VendorID int = @ID
				Declare @PRS_VendorName varchar(50)
				Declare @PRS_Website varchar(50)

				Declare @IRS_VendorID int
				Declare @ChrFieldValues varchar(8000)

		if((@QueryType Is Null) or (@QueryType = ''))
			set @QueryType = 'create'


	if(lower(@QueryType) = 'create')

				Begin 

				-- Get the IRS Vendor ID for this PRS Vendor ID From the PRS Vendor table
				Select @IRS_VendorID = IRSID From [Vendor] (NoLock)
				Where [ID] = @PRS_VendorID

				-- Does the PRS Vendor have an IRSID?
				If ((@IRS_VendorID Is Null) Or (@IRS_VendorID <= 0)) Begin
		
					-- No, PRS Vendor table record has no valid IRSID
					-- Get the PRS Vendor Name from the PRS Vendor Table
					Select @PRS_VendorName = [Name], @PRS_Website = [Website] From [Vendor]
					Where [ID] = @ID

					-- Is the PRS Vendor Name valid?
					If ((@PRS_VendorName Is Not Null) And (@PRS_VendorName <> '')) Begin

						-- Yes, PRS Vendor Name is valid.
						-- Does the vendor name exist in IRS?
						Select @IRS_VendorID = [VendorID] From [IRS_Vendor]
						Where [Name] = @PRS_VendorName

						-- Does the vendor name exist in IRS?
						If ((@IRS_VendorID Is Not Null) And (@IRS_VendorID > 0)) Begin

							-- Yes, the vendor name exists in IRS

							-- Update Excalibur Vendor table with the IRS Vendor ID
							Update [Vendor]
							Set [IRSID] = @IRS_VendorID
							Where [ID] = @PRS_VendorID

						End
						Else Begin

							-- No, the Vendor Name does not exist in IRS

							-- Do we have a valid Vendor Name?
							If (@PRS_VendorName Is Not Null) Begin
				
								-- Yes, we have a valid Vendor Name

								-- If we don't have a valid website, set it to blank string
								If (@PRS_Website Is Null) Begin
									Set @PRS_Website = ''
								End

								-- SAMPLE CALL TO IRS ADMIN_Vendor stored procedure
								-- exec usp_Admin_Vendor @p_chrQueryType=N'create',@p_chrID=N'0',@p_chrTable=N'vendor',@p_chrPersonID=N'wgomero',@p_chrPersonFullName=NULL,@p_chrFieldValues=N'walter|\||\|1,0,37,'

								Select @ChrFieldValues = @PRS_VendorName + '|\|' + @PRS_Website + '|\|0,1,37'
								Print @ChrFieldValues 

								-- Add/create the Vendor Name does not exist in IRS
								Exec [IRS_usp_Admin_Vendor]
									@p_chrQueryType=@QueryType,
									@p_chrID='0',
									@p_chrTable='vendor',
									@p_chrPersonID='Excalibur', --NTUsername
									@p_chrPersonFullName=NULL,
									@p_chrFieldValues= @ChrFieldValues

								Select @IRS_VendorID = [VendorID] From IRS_Vendor With (NoLock)
								Where [Name] = @PRS_VendorName
			
								-- Update Excalibur Vendor table with the IRS Vendor ID
								If (@IRS_VendorID Is Not Null) Begin
									Update [Vendor]
									Set IRSID = @IRS_VendorID
									Where [ID] = @PRS_VendorID
								End
			
							End

						End

					End

				End


				Print 'PRS VendorID: [' + Cast(@PRS_VendorID As varchar(20)) + ']'
				Print 'IRS VendorID: [' + Cast(@IRS_VendorID As varchar(20)) + ']'
				End
	Else 
				IF(lower(@QueryType) = 'update')
				
				Begin
					
				
					Select @PRS_VendorName = [Name], @PRS_Website = [Website],@IRS_VendorID = [IRSID] From [Vendor]
					Where [ID] = @ID

					-- No, the Vendor Name does not exist in IRS

							-- Do we have a valid Vendor Name?
							If (@PRS_VendorName Is Not Null) Begin
				
								-- Yes, we have a valid Vendor Name

								-- If we don't have a valid website, set it to blank string
								If (@PRS_Website Is Null)
									Set @PRS_Website = ''
								

								-- SAMPLE CALL TO IRS ADMIN_Vendor stored procedure
								-- exec usp_Admin_Vendor @p_chrQueryType=N'create',@p_chrID=N'0',@p_chrTable=N'vendor',@p_chrPersonID=N'wgomero',@p_chrPersonFullName=NULL,@p_chrFieldValues=N'walter|\||\|1,0,37,'

								Select @ChrFieldValues = @PRS_VendorName + '|\|' + @PRS_Website + '|\|0,1,37'
								Print @ChrFieldValues 

								-- Add/create the Vendor Name does not exist in IRS
								Exec [IRS_usp_Admin_Vendor]
									@p_chrQueryType=@QueryType,
									@p_chrID=@IRS_VendorID,
									@p_chrTable='vendor',
									@p_chrPersonID='Excalibur', --NTUsername
									@p_chrPersonFullName=NULL,
									@p_chrFieldValues= @ChrFieldValues

			
							End

												

				End
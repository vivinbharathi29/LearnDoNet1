﻿

CREATE PROCEDURE [dbo].[spListActionStatuses] 
(
	@Type int =1
)


AS

if @Type=1
	Select ID, Name, OpenStatus
	from actionstatus with (NOLOCK)
	where PlatformActionStatus =1
	order by displayorder
else if @Type=2
	Select ID, Name, OpenStatus
	from actionstatus with (NOLOCK)
	where PlatformDCRStatus = 1
	order by displayorder
else if @Type=3
	Select ID, Name, OpenStatus
	from actionstatus with (NOLOCK)
	where ToolActionStatus =1
	order by displayorder





﻿

CREATE PROCEDURE [dbo].[spFusion_PROJECT_UpdateAvDetailProductBrand]
	@AvDetailProductBrandId int, 
	@IrsPlatformId int = NULL,
	@IrsPlatformAliasId int = NULL,
	@IrsHwId int = NULL
AS
	DECLARE @KMAT VARCHAR(10), @AvDetailId INT, @ProductBrandId INT
	SELECT @ProductBrandId = ProductBrandId, @AvDetailId = AvDetailID FROM AvDetail_ProductBrand WITH (NOLOCK) WHERE AvDetail_ProductBrand.Id = @AvDetailProductBrandId
	SELECT @KMAT = KMAT FROM Product_Brand WITH (NOLOCK) WHERE ID = @ProductBrandId
	
	UPDATE AvDetail_ProductBrand
	SET IRSPlatformId = COALESCE(@IrsPlatformId, IRsPlatformId),
		IRSPlatformAliasId = COALESCE(@IrsPlatformAliasId, IRSPlatformAliasId),
		IRSHwId = COALESCE(@IrsHwId, IRSHwId)
	WHERE ProductBrandID IN (SELECT Id FROM Product_Brand WITH (NOLOCK) WHERE KMAT = @KMAT)
	  AND AvDetailID = @AvDetailId


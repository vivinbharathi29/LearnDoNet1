﻿

CREATE PROCEDURE [dbo].[spGetRootScoreCard]
(
	@RootID int
)
AS

	Select *
	from deliverablerootscorecard with (NOLOCK)
	where DeliverableRootID = @RootID
	and DateReviewed is null



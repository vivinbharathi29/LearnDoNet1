﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spGetServiceSpareKit](
	@p_SpareKitNumber nvarchar(10)
	)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

      -- Insert statements for procedure here
      SELECT sk.SpareKitNo,cat.CategoryName,Description as SpareKitDesc,D_Mat.MaterialType
			,Division,RevisionLevel,D_Mat.CrossPlantStatus
			,(select top(1) ssp.OsspOrderable from ServiceSpareDetail ssp where ssp.HpPartNo=@p_SpareKitNumber) as OsspOrderable
			FROM DATAWAREHOUSE.dbo.iHUB_MaterialMasterGeneralData D_Mat WITH (NOLOCK)
			 left outer  join ServiceSpareKit sk WITH (NOLOCK) ON D_Mat.PartNumber=sk.SpareKitNo
			 inner join ServiceSpareCategory cat WITH (NOLOCK) ON sk.SpareCategoryId=cat.ID
			WHERE D_Mat.PartNumber = @p_SpareKitNumber

END


﻿/* **********************************************************************************************************************
 * Purpose:		feeding data from Pulsar to IRS 
 * Created By:	
 * Modified By:	
 *				12/08/2016 linshant - get ModuleID of base unit before sending data to IRS - bug 30007
 *				05/27/2015 linshant - Ensure that Parent AV number is not empty if its Localized AV is not empty - PBI 116319
				06/12/2017 PMV Pandian BUG 136382, To fix the run time error 'invalid lengh of character passed to the function LEFT or Substring'
 ************************************************************************************************************************/
CREATE PROCEDURE [dbo].[spFusion_SCM_PublishPAL]
	@p_ProductBrandId int = 0,
	@p_MajorPublish bit = 0
AS
	SET ARITHABORT ON
	SET NOCOUNT ON

	DECLARE
		@v_ProductVersionId INT, 
		@v_Kmat VARCHAR(10), 
		@v_AvListId INT, 
		@v_PalName VARCHAR(64), 
		@v_ProductYearId INT, 
		@v_BusinessSegmentId INT, 
		@v_CreatorId INT, 
		@v_LastPublishDt DATETIME,
		@v_MajorSCM TINYINT,
		@v_BaseUnitCount INT,
		@BusinessBnb INT, 
		@BusinessCnb INT,
		@ErrorCd INT,
		@ErrorMessage VARCHAR(MAX),
		@AvIrsPublishId INT,
		@v_HideFromUser INT,
		@v_ProductBrandId INT

	IF (@p_ProductBrandId = 0) BEGIN
		RETURN
	END

	--Only sync legacy products
	IF EXISTS (SELECT 1 FROM ProductVersion pv INNER JOIN Product_Brand pb ON pv.ID = pb.ProductVersionID WHERE FusionRequirements = 1 AND pb.ID = @p_ProductBrandId)
	  BEGIN
		RETURN
	  END

	SELECT @v_Kmat = Kmat FROM Product_Brand WITH (NOLOCK) WHERE ID = @p_ProductBrandId

	DECLARE @ParentID int = 0, @ParentAvNo varchar(18)
	DECLARE ParentAVCur CURSOR LOCAL FAST_FORWARD 
			FOR	SELECT  avParent.AvDetailID, substring(avChild.AvNo,1,charindex('#',avChild.AvNo)-1)
				from AvDetail avParent
				INNER JOIN AvDetail avChild on avParent.AvDetailID = avChild.ParentId
				INNER JOIN AvDetail_ProductBrand avpb on avChild.AvDetailID = avpb.AvDetailID
				INNER JOIN Product_Brand pb on avpb.ProductBrandID = pb.ID
				WHERE pb.KMAT = @v_Kmat and avpb.status ='A' and RTRIM(isnull(avParent.AvNo,''))='' and avChild.AvNo is not null
				and avParent.AvDetailID > 0 and CHARINDEX('#',avChild.AvNo) > 5  


	OPEN ParentAVCur
	FETCH NEXT FROM ParentAVCur INTO @ParentID, @ParentAvNo
	WHILE(@@FETCH_STATUS = 0)
		begin
			update AvDetail set AvNo = @ParentAvNo where AvdetailID = @ParentID and ParentId is null
			FETCH NEXT FROM ParentAVCur INTO @ParentID, @ParentAvNo
		end
	CLOSE ParentAVCur
	DEALLOCATE ParentAVCur

	-- MAINTENANCE SECTION:  Perform these tasks to make sure all of the IRS IDs are in place.
	EXEC spFusion_SCM_UpdateIrsRegionsID
	-- BaseUnit SECTION
		DECLARE @AvDetailProductbrandID int 
		DECLARE BaseUnitCur CURSOR FAST_FORWARD FOR
			SELECT avpb.Id FROM avdetail av 
			INNER JOIN AvDetail_ProductBrand avpb ON av.AvDetailID = avpb.AvDetailID 
			LEFT JOIN IRS_Module m on avpb.IRSBaseUnitModuleId = m.ModuleId
			WHERE avpb.ProductBrandID = @p_ProductBrandId and av.FeatureCategoryID in (1,86) and avpb.Status in ('A','O')
			 and (isnull(m.Description,'')='' or (av.GPGDescription <> m.Description)) 
	
		OPEN BaseUnitCur
		FETCH NEXT FROM BaseUnitCur INTO @AvDetailProductbrandID
	
		WHILE(@@FETCH_STATUS = 0)
		begin
			EXEC spFusion_PROJECT_AddUpdatePlatformSystemboardinIRS @AvDetailProductbrandID, 31
			FETCH NEXT FROM BaseUnitCur INTO @AvDetailProductbrandID
		end
		CLOSE BaseUnitCur
		DEALLOCATE BaseUnitCur
	 -- end of BaseUnit
	EXEC spFusion_MODULE_SyncIDNumbers @p_ProductBrandId

	

	SELECT @v_ProductBrandId = MIN(ID) FROM Product_Brand WHERE KMAT = @v_Kmat

	CREATE TABLE #Cycles
	(
	AvNo   VARCHAR(15),
	Cycles VARCHAR(1000)
	)

	INSERT INTO #Cycles 
	SELECT av1.AvNo,
	SUBSTRING((SELECT ','+ Name AS [text()]
	FROM (SELECT DISTINCT AvNo, p.Name
	FROM AvDetail AS av WITH (NOLOCK) INNER JOIN
	AvDetail_ProductBrand AS avpb WITH (NOLOCK) ON av.AvDetailID = avpb.AvDetailID INNER JOIN
	Product_Brand AS pb WITH (NOLOCK) ON pb.ID = avpb.ProductBrandID INNER JOIN
	ProductVersion AS pv WITH (NOLOCK) ON pv.ID = pb.ProductVersionID INNER JOIN
	Product_Program AS pp WITH (NOLOCK) ON pp.ProductVersionID = pv.ID INNER JOIN
	Program AS p WITH (NOLOCK) ON p.ID = pp.ProgramID
	WHERE av.AvDetailId = av1.AvDetailId) T
	ORDER BY Name
	FOR XML PATH('')),2,1000) [Cycles]
	FROM dbo.AvDetail av1 WITH (NOLOCK) INNER JOIN AvDetail_ProductBrand ab WITH (NOLOCK) ON av1.avdetailid = ab.avdetailid
	INNER JOIN Product_Brand pb ON ab.ProductBrandID = pb.ID
	WHERE NULLIF(av1.avno, '') is not null
	AND ab.Status != 'D'
	AND pb.KMAT = @v_KMAT

	CREATE TABLE #Shared
	(
	AvNo   VARCHAR(15),
	Shared BIT
	)

	INSERT INTO #Shared
	SELECT av.AvNo, CASE WHEN COUNT(ab.AvDetailID) > 1 THEN 1 ELSE 0 END
	FROM   #Cycles c WITH (NOLOCK) INNER JOIN
		   AvDetail av WITH (NOLOCK) ON c.AvNo = av.AvNo INNER JOIN 
		   AvDetail_ProductBrand ab WITH (NOLOCK) ON av.avdetailid = ab.avdetailid
	GROUP BY av.Avno


	INSERT INTO AvIrsPublish (ProductBrandId)
	SELECT @v_ProductBrandId
	SET @AvIrsPublishId = SCOPE_IDENTITY()


	-- Get the KMAT, PalID & Last Publish Date from the Product_Brand Table
	-- Using GETDATE instead of LastPublishDt so we can send SCIT publishes as needed
	SELECT @v_ProductVersionId = ProductVersionId, @v_AvListId = COALESCE(IrsAvListId, -1), @v_LastPublishDt = CONVERT(VARCHAR(25), GETDATE(), 120) FROM Product_Brand WITH (NOLOCK) WHERE ID = @v_ProductBrandId

	-- If @p_MajorPublish = 1 OR @v_AvListId = -1 Then @v_MajorSCM = 1 Else 2
	SELECT @v_MajorSCM = CASE WHEN (@p_MajorPublish = 1 OR @v_AvListId = -1) THEN 1 ELSE 2 END

	-- Get Product Year using RTM Date
	SELECT @v_ProductYearId = CategoryId FROM Irs_Category WITH (NOLOCK) WHERE CategoryType = 25 AND Description = CAST(DATEPART(yy,dbo.ufnGetScheduledDate(93, @v_ProductVersionId)) AS VARCHAR(4))

	-- Get BusinessId for Consumer (cnb) and Commercial (bnb)
	SELECT @BusinessBnb = CategoryId FROM Irs_Category WITH (NOLOCK) WHERE CategoryType=19 AND Abbreviation = 'bnb'
	SELECT @BusinessCnb = CategoryId FROM Irs_Category WITH (NOLOCK) WHERE CategoryType=19 AND Abbreviation = 'cnb'


	-- Assign BusinesSegmentId based on business assigned to the brand.
	SELECT @v_BusinessSegmentId = CASE BusinessID WHEN 2 THEN @BusinessCnb ELSE @BusinessBnb END from Product_Brand pb WITH (NOLOCK) INNER JOIN Brand WITH (NOLOCK) ON pb.BrandID = brand.ID WHERE pb.ID = @v_ProductBrandId

	-- Created by the PC for the product.
	SELECT @v_CreatorId = e.IRSUserID, @v_HideFromUser = CASE WHEN (pv.Fusion = 1 OR pv.ID IN (1131, 1145, 1176, 1164, 1155, 1092, 1147, 1101, 1152, 1090, 1197)) THEN 2 ELSE 3 END FROM ProductVersion pv WITH (NOLOCK) INNER JOIN Product_Brand pb WITH (NOLOCK) ON pb.ProductVersionID = pv.ID INNER JOIN Employee e WITH (NOLOCK) ON pv.PCID = e.ID WHERE pb.ID = @v_ProductBrandId

	IF (@v_HideFromUser <> 2)
	 BEGIN
           DECLARE @ProductBrand INT
           DECLARE @pv_Fusion BIT
           DECLARE Fusion_CURSOR CURSOR FOR
               SELECT pb.id, pv.Fusion FROM ProductVersion pv WITH (NOLOCK) INNER JOIN Product_Brand pb ON pv.id = pb.ProductVersionId WHERE pb.KMAT = @v_Kmat 
           OPEN  Fusion_CURSOR 
           FETCH NEXT FROM Fusion_CURSOR INTO @ProductBrand, @pv_Fusion
           WHILE @@FETCH_STATUS = 0
           BEGIN
                IF ( @pv_Fusion = 1) 
				 BEGIN
                     SET @v_HideFromUser = 2
                     BREAK
                 END
                FETCH NEXT FROM Fusion_CURSOR INTO @ProductBrand, @pv_Fusion
           END
     END


	-- Build the PAL name using Family Name, Version & Brand Abbreviation
	IF ((SELECT COUNT(1) FROM Product_Brand WITH (NOLOCK) WHERE KMAT = @v_KMAT) = 1) BEGIN
	SELECT @v_PalName = pf.Name + ' ' + pv.Version + ' ' + Brand.Abbreviation FROM ProductFamily pf WITH (NOLOCK) INNER JOIN ProductVersion pv WITH (NOLOCK) ON pf.id = pv.ProductFamilyId INNER JOIN Product_Brand pb WITH (NOLOCK) ON pb.ProductVersionID = pv.ID INNER JOIN Brand WITH (NOLOCK) ON Brand.ID = pb.BrandID WHERE pb.ID = @v_ProductBrandId
	END
	ELSE BEGIN
	SELECT @v_PalName = pf.Name + ' ' + SUBSTRING(pv.Version, 1, 1) + '.x ' + Brand.Abbreviation FROM ProductFamily pf WITH (NOLOCK) INNER JOIN ProductVersion pv WITH (NOLOCK) ON pf.id = pv.ProductFamilyId INNER JOIN Product_Brand pb WITH (NOLOCK) ON pb.ProductVersionID = pv.ID INNER JOIN Brand WITH (NOLOCK) ON Brand.ID = pb.BrandID WHERE pb.ID = @v_ProductBrandId
	END

	SELECT @v_BaseUnitCount = COUNT(1)
	FROM
		AvDetail AS av WITH (NOLOCK) INNER JOIN
		AvFeatureCategory fc WITH (NOLOCK) ON av.FeatureCategoryID = fc.AvFeatureCategoryID INNER JOIN
		AvDetail_ProductBrand AS avpb WITH (NOLOCK) ON av.AvDetailID = avpb.AvDetailID INNER JOIN
		Product_Brand AS pb WITH (NOLOCK) ON avpb.ProductBrandID = pb.ID 
	WHERE fc.AvFeatureCategoryID IN (1,86) 
	  AND pb.KMAT = @v_Kmat
	  AND ISNULL(avpb.IRSPlatformAliasId, 0) != 0


	IF (@v_BaseUnitCount = 0) BEGIN
		UPDATE AvIrsPublish 
		SET ErrorMessage = 'Base Unit Count: ' + CAST(@v_BaseUnitCount AS VARCHAR(10))
		WHERE AvIrsPublishId =  @AvIrsPublishId
		RETURN 0
	END

	
	-- Due to there is only 154/159 in Pulsar, set it to 159 if there is the value 157 in a particular PAL/SCM.
	if (@v_AvListId <> -1)
	BEGIN
		DECLARE @REQ_UPDATE INT, @COMPLETE INT
		SELECT  @REQ_UPDATE = StatusID FROM IRS_Status WHERE Constant = 'AVMODULE_REQ_UPDATE'
		SELECT  @COMPLETE = StatusID FROM IRS_Status WHERE Constant = 'AVMODULE_COMPLETE' 
		UPDATE  IRS_AvList_Module SET StatusID = @COMPLETE WHERE AVListID = @v_AvListId and SCMID = 1 and StatusID = @REQ_UPDATE
	END


	IF (@v_BaseUnitCount > 0) BEGIN

		/*
		 *	Start building the XML to submit to IRS
		 */
	 
		-- Create the Header
		DECLARE @InputXml XML, @OutputXml XML, @Output VARCHAR(8000)
		SET @InputXml = (
			SELECT * FROM (
				   SELECT     
						  1 AS Tag, 
						  NULL As Parent, 
						  @v_AvListId AS [root!1!AVListID!ELEMENT], 
						  @v_PalName AS [root!1!PALName!ELEMENT], 
						  @v_ProductYearId AS [root!1!ProductYearID!ELEMENT],
						  @v_BusinessSegmentId AS [root!1!BusinessSegmentID!ELEMENT],
						  @v_CreatorId AS [root!1!OwnerID!ELEMENT],
						  @v_CreatorId AS [root!1!CreatorID!ELEMENT],
						  @v_LastPublishDt AS [root!1!TimeCreated!ELEMENT],
						  @v_MajorSCM AS [root!1!MajorSCM!ELEMENT],
						  @v_Kmat AS [root!1!SRP_KMAT!ELEMENT],                              
						  @v_HideFromUser AS [root!1!AVListType!ELEMENT],
						  NULL AS [AVs!2],
						  NULL AS [AV!3!AliasID],
						  NULL AS [AV!3!ModuleID],
						  NULL AS [AV!3!PartNumber],
						  NULL AS [AV!3!RegionID],
						  NULL AS [AV!3!PALCategoryID],
						  NULL AS [AV!3!Status],
						  NULL AS [AV!3!GADate],
						  NULL AS [AV!3!Cycle],
						  NULL AS [AV!3!Shared],
						  NULL AS [AV!3!SADate],
						  NULL AS [AV!3!EMDate],
						  NULL AS [AV!3!EOLDate],
						  NULL AS [AV!3!AVRulesDesc],
						  NULL AS [AV!3!AVID],
						  NULL AS [AV!3!IDS_SKUS],
						  NULL AS [AV!3!IDS_CTO],
						  NULL AS [AV!3!RCTO_SKUS],
						  NULL AS [AV!3!RCTO_CTO],
						  NULL AS [AV!3!GROUP1],
						  NULL AS [AV!3!GROUP2],
						  NULL AS [AV!3!GROUP3],
						  NULL AS [AV!3!GROUP4],
						  NULL AS [AV!3!GROUP5],
						  NULL AS [AV!3!GROUP6],
						  NULL AS [CategoryRules!4],
						  NULL AS [PALCategory!5!PALCategoryID],
						  NULL AS [PALCategory!5!RuleDescription]

				   UNION ALL
				   SELECT 2 AS Tag, 1 AS Parent, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL

				   -- BASE UNITS
				   UNION ALL
				   SELECT DISTINCT 3 as Tag, 2 As Parent, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
						  CAST(ISNULL(avpb.IRSPlatformAliasID, 0) AS VARCHAR(10)) AS PlatformAliasId, 
						  ISNULL(CAST(NULLIF(avpb.IRSBaseUnitModuleID, 0) AS VARCHAR(10)), '') AS ModuleId, 
						  av.AvNo, '', fc.IrsCategoryId, CASE WHEN MIN(avpb.status) = 'A' THEN 'A' ELSE 'O' END, COALESCE(CONVERT(VARCHAR(10), av.GeneralAvailDt, 101), CONVERT(VARCHAR(10), av.CPLBlindDt, 101 ), ''),
						  cb.Cycles, s.Shared, ISNULL(CONVERT(VARCHAR(10),av.CPLBlindDt,101),''), ISNULL(CONVERT(VARCHAR(10),av.RASDiscontinueDt,101),''), 
						  CASE WHEN pv.DevCenter = 2 THEN ISNULL(CONVERT(VARCHAR(10),DATEADD(mm, DATEDIFF(mm, 0, av.RASDiscontinueDt)-3, 0),101),'') ELSE ISNULL(CONVERT(VARCHAR(10),DATEADD(mm, DATEDIFF(mm, 0, av.RASDiscontinueDt)-4, 0),101),'') END AS EOLDate,
						  ISNULL(avpb.ConfigRules,''), 
						  ISNULL(avpb.AvId,''), 
						  CASE WHEN ISNULL(avpb.IdsSkus_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.IdsCto_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.RctoSkus_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.RctoCto_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  ISNULL(avpb.Group1,''), 
						  ISNULL(avpb.Group2,''), 
						  ISNULL(avpb.Group3,''), 
						  ISNULL(avpb.Group4,''), 
						  ISNULL(avpb.Group5,''), 
						  '', 
						  NULL, NULL, NULL  
				   FROM
						  AvDetail AS av (NOLOCK ) INNER JOIN
						  AvFeatureCategory fc (NOLOCK ) ON av.FeatureCategoryID = fc.AvFeatureCategoryID INNER JOIN
						  AvDetail_ProductBrand AS avpb (NOLOCK ) ON av.AvDetailID = avpb.AvDetailID INNER JOIN
						  Product_Brand AS pb (NOLOCK ) ON avpb.ProductBrandID = pb.ID INNER JOIN
						  ProductVersion AS pv WITH (NOLOCK) ON pv.ID = pb.ProductVersionID INNER JOIN
						  #Cycles cb WITH (NOLOCK) ON cb.AvNo = av.AvNo INNER JOIN 
						  #Shared s WITH (NOLOCK) ON s. AvNo = av.AvNo
				   WHERE fc.AvFeatureCategoryID IN (1,86) 
						  AND pb.KMAT = @v_Kmat
						  AND ISNULL(avpb.IRSPlatformAliasId, 0) != 0
						  AND avpb.status <> 'D'
				   GROUP BY   avpb.IRSPlatformAliasID, avpb.IRSBaseUnitModuleID, av.AvNo, fc.IrsCategoryId, av.GeneralAvailDt, av.CPLBlindDt, cb.Cycles, s.Shared, pv.DevCenter, av.RASDiscontinueDt, avpb.ConfigRules, avpb.AvId,	avpb.IdsSkus_YN, avpb.IdsCto_YN, avpb.RctoSkus_YN, avpb.RctoCto_YN, avpb.Group1, avpb.Group2, avpb.Group3, avpb.Group4, avpb.Group5
				   -- Localized AVs
				   UNION ALL
				   SELECT DISTINCT 3 as Tag, 2 As Parent, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', ISNULL(CAST(avp.IRSModuleID AS VARCHAR(10)),''), LEFT(av.AvNo,7), ISNULL(NULLIF(CAST(r.IRSRegionId AS VARCHAR(10)), '0'), '') AS IRSRegionId, fc.IrsCategoryId, 
						  CASE WHEN MIN(avpb.status) = 'A' THEN 'A' ELSE 'O' END, COALESCE(CONVERT(VARCHAR(10), av.GeneralAvailDt, 101), CONVERT(VARCHAR(10), av.CPLBlindDt, 101 ), ''),
						  cb.Cycles, s.Shared, ISNULL(CONVERT(VARCHAR(10),av.CPLBlindDt,101), ''), ISNULL(CONVERT(VARCHAR(10),av.RASDiscontinueDt,101),''), 
						  CASE 
						  WHEN pv.DevCenter = 2 THEN ISNULL(CONVERT(VARCHAR(10),DATEADD(mm, DATEDIFF(mm, 0, av.RASDiscontinueDt)-3, 0),101),'') ELSE ISNULL(CONVERT(VARCHAR(10),DATEADD(mm, DATEDIFF(mm, 0, av.RASDiscontinueDt)-4, 0),101),'') END AS EOLDate,
						  ISNULL(avpb.ConfigRules,''), 
						  ISNULL(avpb.AvId,''), 
						  CASE WHEN ISNULL(avpb.IdsSkus_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.IdsCto_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.RctoSkus_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.RctoCto_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  ISNULL(avpb.Group1,''), 
						  ISNULL(avpb.Group2,''), 
						  ISNULL(avpb.Group3,''), 
						  ISNULL(avpb.Group4,''), 
						  ISNULL(avpb.Group5,''), 
						  '', 
						  NULL, NULL, NULL
				   FROM
						  AvDetail AS avp (NOLOCK ) INNER JOIN
						  AvDetail AS av (NOLOCK ) ON avp.AvDetailID = av.ParentId INNER JOIN
						  AvFeatureCategory fc (NOLOCK ) ON avp.FeatureCategoryID = fc.AvFeatureCategoryID INNER JOIN
						  AvDetail_ProductBrand AS avpb (NOLOCK ) ON av.AvDetailID = avpb.AvDetailID INNER JOIN
						  Product_Brand AS pb (NOLOCK ) ON avpb.ProductBrandID = pb.ID INNER JOIN
						  Brand AS b (NOLOCK ) ON pb.BrandID = b.ID INNER JOIN
						  Regions r (NOLOCK ) ON RIGHT(av.AvNo, 3) = r.OptionConfig AND r.Active=1 AND ((b.BusinessID=1 AND r.Commercial=1) OR (b.BusinessID=2 AND Consumer=1)) INNER JOIN
						  ProductVersion AS pv WITH (NOLOCK) ON pv.ID = pb.ProductVersionID INNER JOIN
						  --Product_Program AS pp WITH (NOLOCK) ON pp.ProductVersionID = pv.ID INNER JOIN
						  --Program AS p WITH (NOLOCK) ON p.ID = pp.ProgramID INNER JOIN
						  #Cycles cb WITH (NOLOCK) ON cb.AvNo = av.AvNo INNER JOIN 
						  #Shared s WITH (NOLOCK) ON s. AvNo = av.AvNo
				   WHERE fc.AvFeatureCategoryID NOT IN (1,86) AND av.ParentId IS NOT NULL AND ISNULL(avp.IRSModuleId,0) != 0
				   AND pb.KMAT = @v_Kmat
				   AND avpb.status <> 'D'
				   GROUP BY   avp.IRSModuleID, av.AvNo, r.IRSRegionId, fc.IrsCategoryId, av.GeneralAvailDt, av.CPLBlindDt, cb.Cycles, s.Shared, pv.DevCenter, av.RASDiscontinueDt, avpb.ConfigRules, avpb.AvId,	avpb.IdsSkus_YN, avpb.IdsCto_YN, avpb.RctoSkus_YN, avpb.RctoCto_YN, avpb.Group1, avpb.Group2, avpb.Group3, avpb.Group4, avpb.Group5
				   -- All Other AVs
				   UNION ALL
				   SELECT DISTINCT 3 as Tag, 2 As Parent, NULL, NULL, NULL, NULL, NULL, NULL, NULL,NULL, NULL, NULL, NULL, '', CAST(av.IRSModuleID AS VARCHAR(10)), LEFT(av.AvNo,7), '', fc.IrsCategoryId, 
						  CASE WHEN MIN(avpb.status) = 'A' THEN 'A' ELSE 'O' END, 
						  COALESCE(CONVERT(VARCHAR(10), av.GeneralAvailDt, 101), CONVERT(VARCHAR(10), av.CPLBlindDt, 101 ), ''),
						  cb.Cycles, s.Shared, ISNULL(CONVERT(VARCHAR(10),av.CPLBlindDt,101),''), ISNULL(CONVERT(VARCHAR(10),av.RASDiscontinueDt,101),''), 
						  CASE WHEN pv.DevCenter = 2 THEN ISNULL(CONVERT(VARCHAR(10),DATEADD(mm, DATEDIFF(mm, 0, av.RASDiscontinueDt)-3, 0),101),'') ELSE ISNULL(CONVERT(VARCHAR(10),DATEADD(mm, DATEDIFF(mm, 0, av.RASDiscontinueDt)-4, 0),101),'') END AS EOLDate,
						  ISNULL(avpb.ConfigRules,''), 
						  ISNULL(avpb.AvId,''), 
						  CASE WHEN ISNULL(avpb.IdsSkus_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.IdsCto_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.RctoSkus_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  CASE WHEN ISNULL(avpb.RctoCto_YN, 'N') = 'Y' THEN 1 ELSE 0 END,
						  ISNULL(avpb.Group1,''), 
						  ISNULL(avpb.Group2,''), 
						  ISNULL(avpb.Group3,''), 
						  ISNULL(avpb.Group4,''), 
						  ISNULL(avpb.Group5,''), 
						  '', 
						  NULL, NULL, NULL 
				   FROM
						  AvDetail AS av (NOLOCK ) INNER JOIN
						  AvFeatureCategory fc (NOLOCK ) ON av.FeatureCategoryID = fc.AvFeatureCategoryID INNER JOIN
						  AvDetail_ProductBrand AS avpb (NOLOCK ) ON av.AvDetailID = avpb.AvDetailID INNER JOIN
						  Product_Brand AS pb (NOLOCK ) ON avpb.ProductBrandID = pb.ID INNER JOIN
						  ProductVersion AS pv WITH (NOLOCK) ON pv.ID = pb.ProductVersionID INNER JOIN
						  --Product_Program AS pp WITH (NOLOCK) ON pp.ProductVersionID = pv.ID INNER JOIN
						  --Program AS p WITH (NOLOCK) ON p.ID = pp.ProgramID INNER JOIN
						  #Cycles cb WITH (NOLOCK) ON cb.AvNo = av.AvNo INNER JOIN 
						  #Shared s WITH (NOLOCK) ON s. AvNo = av.AvNo
				   WHERE fc.AvFeatureCategoryID NOT IN (1,86) AND av.ParentId IS NULL 
				   AND ISNULL(fc.IRSModuleCategoryId, 0) != 0 AND ISNULL(av.IRSModuleId, 0) != 0
				   AND av.AvNo IS NOT NULL
				   AND pb.KMAT = @v_Kmat
				   AND avpb.status <> 'D'
				   GROUP BY   av.IRSModuleID, av.AvNo, fc.IrsCategoryId, av.GeneralAvailDt, av.CPLBlindDt, cb.Cycles, s.Shared, pv.DevCenter, av.RASDiscontinueDt, avpb.ConfigRules, avpb.AvId,	avpb.IdsSkus_YN, avpb.IdsCto_YN, avpb.RctoSkus_YN, avpb.RctoCto_YN, avpb.Group1, avpb.Group2, avpb.Group3, avpb.Group4, avpb.Group5
				   UNION ALL
				   SELECT 4 AS Tag, 1 AS Parent, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
				   UNION ALL
				   SELECT DISTINCT 5 AS Tag, 4 AS Parent, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
						  fc2.IrsCategoryId, 
						  REPLACE(SUBSTRING((SELECT DISTINCT ','+ RTRIM(LTRIM(ISNULL(fb.ConfigRules, fc.ConfigRules))) AS [text()]
											 FROM AvFeatureCategory fc WITH (NOLOCK) LEFT OUTER JOIN 
												 (SELECT fb.AvFeatureCategoryId, fb.ConfigRules FROM Product_Brand b WITH (NOLOCK) INNER JOIN AvFeature_ProductBrand fb WITH (NOLOCK) ON fb.ProductBrandId = b.ID WHERE b.KMAT = @v_Kmat) fb ON fc.AvFeatureCategoryId = fb.AvFeatureCategoryId
											 WHERE NULLIF(fc.IrsCategoryId, 0) IS NOT NULL 
											 AND NULLIF(ISNULL(fb.ConfigRules, fc.ConfigRules), '') IS NOT NULL
											 AND fc.IrsCategoryId = fc2.IrsCategoryId
											 FOR XML PATH('')),2,6000),'''','') [ConfigRules]
				  FROM  AvFeatureCategory fc2 WITH (NOLOCK)
				  WHERE [ConfigRules] is not null
				  AND   fc2.IrsCategoryId <> 0 
			) AS T
			FOR XML EXPLICIT, TYPE
		)

		DROP TABLE #Cycles
		DROP TABLE #Shared


		UPDATE AvIrsPublish 
		SET OutgoingMessage = @InputXml
		WHERE AvIrsPublishId =  @AvIrsPublishId

		-- Convert XML Type to VARCHAR to send to remote server
		DECLARE @Input VARCHAR(MAX)
		SELECT @Input = CAST(@InputXml AS VARCHAR(MAX))

		-- Call IRS Procedure
		BEGIN TRY
			EXEC [dbo].[IRS_usp_AVL_GetSCM_FromFeed] @Input, @Output OUT
		END TRY
		BEGIN CATCH
			INSERT INTO AvIrsPublish (ProductBrandId, OutgoingMessage, Response, ErrorCd, ErrorMessage)
			SELECT @v_ProductBrandId, @InputXml, @OutputXml, ERROR_NUMBER(), ERROR_MESSAGE()

			--SELECT 
			--	ERROR_NUMBER() AS ErrorNumber
			--	,ERROR_SEVERITY() AS ErrorSeverity
			--	,ERROR_STATE() AS ErrorState
			--	,ERROR_LINE () AS ErrorLine
			--	,ERROR_PROCEDURE() AS ErrorProcedure
			--	,ERROR_MESSAGE() AS ErrorMessage	
		END CATCH
		                  
		SET @OutputXml = @Output

		-- Store Input, Output & ErrorCd

		-- Write results to Excalibur Database
		IF (@OutputXml IS NOT NULL) BEGIN	

			DECLARE @v_IrsAVListId INT
			
			SELECT @ErrorMessage = @OutputXml.value('(/root/Error)[1]', 'varchar(MAX)')

				SELECT @v_IrsAVListId = @OutputXml.value('(/root/AVListID)[1]', 'int')
				IF (@v_IrsAVListId IS NOT NULL ) BEGIN
					UPDATE Product_Brand
					SET IrsAvListId = @v_IrsAVListId
					WHERE KMAT = @v_KMAT
				END

			IF LEN(@ErrorMessage) = 0 BEGIN
			
				UPDATE AvDetail_ProductBrand
				SET IRSBaseUnitModuleId = Result.ModuleID
				FROM AvDetail WITH (NOLOCK) INNER JOIN AvDetail_ProductBrand WITH (NOLOCK) ON AvDetail.AvDetailId = AvDetail_ProductBrand.AvDetailId INNER JOIN
				(SELECT x.v.value('ModuleID[1]', 'int') AS ModuleID, x.v.value('PartNumber[1]','varchar(10)') AS AvNo 
				FROM @OutputXml.nodes('//BaseUnitModules/Module') x(v)) Result ON AvDetail.AvNo = Result.AvNo
				WHERE AvDetail_ProductBrand.ProductBrandID IN (SELECT ID FROM Product_Brand WITH (NOLOCK) WHERE KMAT = @v_Kmat)
			END

			-- update business segment if need
			SELECT @v_BusinessSegmentId = bs.IrsBusinessSegmentID 
			from Product_Brand pb WITH (NOLOCK) 
			INNER JOIN Brand WITH (NOLOCK) ON pb.BrandID = Brand.ID 
			INNER JOIN BusinessSegment bs WITH (NOLOCK) on Brand.BusinessSegmentID = bs.BusinessSegmentID 
			WHERE pb.ID = @v_ProductBrandId
			if ((ISNULL(@v_BusinessSegmentId,'') <>'') and @v_IrsAVListId IS NOT NULL and @v_BusinessSegmentId <> (select DivisionID from IRS_AVList_Division WITH (NOLOCK) where AVListID = @v_IrsAVListId) )
				update  IRS_AVList_Division set DivisionID = @v_BusinessSegmentId where AVListID = @v_IrsAVListId

		END -- @OutputXml IS NOT NULL
	END ELSE BEGIN -- BaseUnitCount > 0
		
		INSERT INTO AvIrsPublish (ProductBrandId, OutgoingMessage, Response, ErrorCd, ErrorMessage)
		SELECT @v_ProductBrandId, NULL, NULL, NULL, 'No Base Units in the SCM'

	END -- BaseUnitCount > 0
	
	UPDATE AvIrsPublish 
	SET Response = @OutputXml,
		ErrorCd = @ErrorCd,
		ErrorMessage = @ErrorMessage
	WHERE AvIrsPublishId = @AvIrsPublishId


	RETURN 0 --@ErrorCd

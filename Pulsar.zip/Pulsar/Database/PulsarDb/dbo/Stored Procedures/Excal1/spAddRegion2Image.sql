﻿

CREATE PROCEDURE [dbo].[spAddRegion2Image]
(
	@ImageDefID int,
	@RegionID int,
	@Priority varchar(50)
)
 AS
Insert Images (ImageDefinitionID,Priority, RegionID, Modified )
Values (@ImageDefID, @Priority, @RegionID, GetDate())


set nocount on
If (RIGHT(RTRIM(@Priority),1) = 'x')
BEGIN
update images
set skunumber = left(d.skunumber, 6) + left(LTRIM(@priority), 3) + right(d.skunumber, 1)
from imagedefinitions d with (NOLOCK) inner join
	images i  with (NOLOCK) on d.id = i.imagedefinitionid inner join
	regions r  with (NOLOCK) on i.regionid = r.id
where i.id = scope_identity()
END
ELSE
BEGIN
update images
set skunumber = left(d.skunumber, 6) + left(r.dash, 3) + right(d.skunumber, 1)
from imagedefinitions d with (NOLOCK) inner join
	images i with (NOLOCK) on d.id = i.imagedefinitionid inner join
	regions r with (NOLOCK) on i.regionid = r.id
where i.id = scope_identity()
END
set nocount off




﻿
CREATE PROCEDURE [dbo].[spListCommodityPMs] 
AS

Select distinct e.id, e.name
from ProductVersion v with (NOLOCK) LEFT OUTER JOIN Employee e with (NOLOCK) ON v.PDEID = e.ID
where v.productstatusid < 5
and v.pdeid <> 0

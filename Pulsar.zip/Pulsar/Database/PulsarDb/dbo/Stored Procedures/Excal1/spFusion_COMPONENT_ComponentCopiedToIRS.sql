﻿CREATE PROCEDURE [dbo].[spFusion_COMPONENT_ComponentCopiedToIRS]
(
	@ID INT,
    @Status INT = 1
)
AS
DECLARE @IRSRevisionID INT
DECLARE @IRSVersionID INT
DECLARE @IRSPassID INT
Declare @SKARStatus varchar(30) = ''

DECLARE @uri nvarchar(1000),
	@returnValue int,
	@message nvarchar(MAX)='',
	@rawResponse nvarchar(MAX)=''

-- only run the part @Status!=1 when using SSSB for CVA/SKAR

IF @Status = 1
	BEGIN
	 RETURN 1; -- CVA /SKAR handles by SSSB
	/*
		BEGIN TRY
			--SET @uri='http://pulsarw03.auth.hpicorp.net/pulsarapi/svc/FileExport/GenerateSKAR/180475'

			--##SKAR
			SELECT @uri=value from setting where Name='SKAR.GenerateSKARSvcUri'
			SET @uri=REPLACE(@uri, '{0}', CAST(@ID AS varchar(20)))

			EXECUTE [dbo].[spFusion_WebApiWrapper] 
				@uri
				,@returnValue OUTPUT
				,@message OUTPUT
				,@rawResponse OUTPUT

			IF @returnValue!=0  --check for error
				BEGIN
					--service call was succesfull, but the skar file generation failed, 
					RAISERROR ('SKAR JOB: spFusion_WebApiWrapper returnValue==1 (error managed by WS)',16,1); 
				END

			--reset values to avoind misleading error messages in case of exception in the following statements
			SET	@message=''
			SET	@rawResponse=''
			SET	@returnValue=-1

			--#######################
			--##CALL IRS SP to do other things (this stuff hopefully will be "moved to pulsar" soon)
			SELECT @IRSRevisionID = IRSRevisionID, @IRSVersionID = IRSVersionID , @IRSPassID = IRSID
				FROM DeliverableVersion WITH (NOLOCK)
				WHERE ID = @ID

			IF @IRSVersionID = 0 or @IRSVersionID is null or @IRSPassID = 0 
				or @IRSPassID is null or @IRSRevisionID = 0 or @IRSRevisionID is null
				BEGIN
					RAISERROR('Error: Unable to create CVA files in IRS, SKAR JOB file created', 16, 1)
					RETURN 1                                
				END
			ELSE
				BEGIN
					EXEC IRS_usp_LCMLang_GenerateCvaSKARFiles @IRSRevisionID, @IRSVersionID, @IRSPassID, 10 
				END

			--#######################
			--##Export compliance
	
			--queue request for EC creation
			EXECUTE [dbo].[usp_SSSB_SendEC_Message] @ID
			SET @SKARStatus = ' (SKAR Job Created)';
	

			UPDATE DeliverableVersion
				SET irsfilescopied = @Status, LastSentToPrism=GetDate()
				WHERE id = @ID

			insert into SIExcalSyncLog ([Message],TypeID, ObjectID,Success,Updated,Arg)
				values ('Transfer status set to: ' + cast(@Status as varchar(10)) + @SKARStatus,14, @ID,1,GetDate(),@Status)

		END TRY
		BEGIN CATCH
			--LOG WS call failure
			SET @message = 'Failed to generate SKAR/Export compliance files with WS: ' + @message + CHAR(13) + CHAR(10) 
							+ 'Service raw response: ' + @rawResponse + CHAR(13) + CHAR(10) 
							+ 'URI: ' + @uri + CHAR(13) + CHAR(10) 
							+ 'SQL ERROR: ' + ISNULL(ERROR_MESSAGE(),'no SQL error')
			INSERT INTO SIExcalSyncLog ([Message],TypeID,ObjectID,Success,Updated,Arg)
				VALUES (@message,14,@ID,0,GetDate(),@Status)
		
			-- 
			DECLARE @mail varchar(255), @body varchar(max)
			SELECT @mail = Value from Setting where Name ='Pulsar.SupportEmail'
			SELECT @Body = 'ComponentId: ' + cast(@ID as varchar(10)) + ' Exception detail: ' + @message
			INSERT INTO MessageQueuedEmail ([Priority], [From], FromName, [To], ToName, Cc, Bcc, [Subject], Body, AttachMents, Created, SendTries)
			VALUES (0, @mail, 'Pulsar Support', @mail, 'Pulsar Support', '', '', 'SKAR job file generation failed', @body, null, GETDATE(), 0);

		END CATCH
	
	*/
	END

ELSE --only for Status!=1
	BEGIN
		UPDATE DeliverableVersion
		SET irsfilescopied = @Status, LastSentToPrism=GetDate()
		WHERE id = @ID

		insert into SIExcalSyncLog ([Message],TypeID, ObjectID,Success,Updated,Arg)
		values ('Transfer status set to: ' + cast(@Status as varchar(10)) + @SKARStatus,14, @ID,1,GetDate(),@Status)
	END

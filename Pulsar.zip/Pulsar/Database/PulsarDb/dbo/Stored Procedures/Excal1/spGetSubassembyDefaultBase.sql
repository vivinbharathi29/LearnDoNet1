﻿CREATE PROCEDURE [dbo].[spGetSubassembyDefaultBase] 
/**************************************************************************
Purpose: get the base sub-assembly number for the component used in all the products
Created:
Modified: 7/24/2017 Shraddha - Subassembly numbers added to a root on a Legacy Product should show on Pulsar Product and vice-versa - Bug 148394
***************************************************************************/
(
	@ProductVersionID int,
	@DeliverableRootID int
)
AS

DECLARE @DevCenter as int

Select @DevCenter = devcenter
from productversion with (NOLOCK)
where id = @ProductVersionID

if @DevCenter <> 2
	Select distinct pd.Base as BaseNumber
	from product_delroot pd with (NOLOCK), productversion v with (NOLOCK)
	where v.id = pd.productversionid
	and v.devcenter <> 2
	and base is not null
	and base <> ''
	and DeliverableRootID = @DeliverableRootID

	UNION

	Select distinct isnull(pdr.Base,'') as BaseNumber
	from product_delroot pd with (NOLOCK)
	inner join productversion v with (NOLOCK) on v.id = pd.productversionid
	inner join product_delroot_release pdr with (NOLOCK) on pd.id = pdr.ProductDelrootID
	where v.devcenter <> 2
	and pdr.base is not null
	and pdr.base <> ''
	and DeliverableRootID = @DeliverableRootID
	
else
	Select distinct pd.Base as BaseNumber
	from product_delroot pd with (NOLOCK), productversion v with (NOLOCK)
	where v.id = pd.productversionid
	and v.devcenter = 2
	and base is not null
	and base <> ''
	and DeliverableRootID = @DeliverableRootID

	UNION

	Select distinct isnull(pdr.Base,'') as BaseNumber
	from product_delroot pd with (NOLOCK)
	inner join productversion v with (NOLOCK) on v.id = pd.productversionid
	inner join product_delroot_release pdr with (NOLOCK) on pd.id = pdr.ProductDelrootID
	where v.devcenter = 2
	and pdr.base is not null
	and pdr.base <> ''
	and DeliverableRootID = @DeliverableRootID
	



﻿

CREATE PROCEDURE [dbo].[spCloseApprovedDCRs]
(
	@ProdID int
)

 AS

Update DeliverableIssues
set ECNDate = getdate()
where ECNDate is null --NoECNDate
and Status=4 --Approved
and Type=3 --DCR
and ProductVersionID = @ProdID



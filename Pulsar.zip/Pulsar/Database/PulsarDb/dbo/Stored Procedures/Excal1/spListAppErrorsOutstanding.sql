﻿

CREATE PROCEDURE [dbo].[spListAppErrorsOutstanding]

 AS


SELECT     
	a.AppError_ID AS ID, a.ErrFile AS PAGE, a.ErrLine, e.Name, e.Email, e.ID AS USERID, a.AuthUser, a.ErrDescription, a.ErrSource, a.AppError_ID, a.ScriptName, 
    a.ErrorDateTime, a.ErrNumber
FROM         
	AppError AS a with (NOLOCK) LEFT OUTER JOIN
    Employee AS e with (NOLOCK) ON a.AuthUser = e.Domain + '\' + e.NTName
WHERE     
	COALESCE(a.Cause,'') = ''
ORDER BY 
	a.ErrorDateTime DESC, Page


﻿/**************************************************************************************************    
** Author  :       
** Description :           
** Date   :    
**************************************************************************************************    
** Change History           
**************************************************************************************************    
** SNo   Date        Author                                    Description           
** --    --------   -------                                   -------------------------           
 ** 1    27/12/2018  Santhana K					Changed the Text Data type to Varchar(max) for @Description and Objectives
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spAddProductVersion_Pulsar]
/* ************************************************************************************************
 * Purpose:	Based on spAddProductVersion, will be used for pulsar version of products.  An future changes
			for pulsar products will be in this sp and the legacy version will remain unchanged.
 * Created By:	Jason Malichi; Ywang, 2/2/2015
 * Modified By: Ywang. 02/10/2015, add factory data
				ADao	- 04/30/2015 - include IsDesktop based on Business Segment
				ThTran	- 05/21/2015 - Fixed @QualityID parameter added by Ariel - Bug 10061
				santodip - 09/03/2015 - Update CreatedBy,UpdatedBy to reflect actual user instead of dbo
				shraddha - 10/20/2015 - save the sharedavmarketing user id
				shraddha - 11/06/2015 - save the shared av program coordinator id
				buidi - 11/30/2015 - save new roles
				ADao - 01/21/2016 - Add SCMOwnerID and EngineeringDataManagementID
				buidi - 9/29/2016 - add two new parametter ODM HW PM and HW PC
				Ywang - 11/15/2016 - when team rosters added through the add button or removed from drop down, need to add/remove user accordingly to/from the corresponding user roles, task 19431
				shraddha - 03/28/2017 - add created date and created by fields in the RoleMembers and TeamOwners table
				Malichi, Jason - 04/24/2017 - BUG 124537 - Production: Add ability to enter End of Service Life and other data lost
				Dean chiang 12/11/2018 BPI 240104  Add a new checkbox in Development Activities field in Product Properties page
**************************************************************************************************/
(
  @FamilyID int,
  @Version varchar(20),
  @ProductName varchar(30),
  @ProductLineID int,
  @BusinessSegmentID int,
  @FactoryIds varchar(250),
  @PMID int,
  @TDCCMID int,
  @SMID int,
  @SEPMID int,
  @PDEID int,
  @SCFactoryEngineerID int,
  @AccessoryPMID int,
  @ComMarketingID int,
  @ConsMarketingID int,
  @SMBMarketingID int,
  @PlatformDevelopmentID int,
  @SupplyChainID int,
  @ServiceID int,
  @QualityID int,
  @UpdateReleases tinyint,
  @Active tinyint,
  @Sustaining tinyint,
  @ProductStatusID int,
  @DivisionID int,
  @TypeID tinyint,
  @DevCenter tinyint,
  @DCRDefaultOwner int,
  @ReferenceID int,
  @PartnerID int,
  @PreinstallTeam int,
  @ReleaseTeam int,
  @Distribution varchar(1000),
  @ConveyorBuildDistribution varchar(1000),
  @ConveyorReleaseDistribution varchar(1000),
  @ActionNotifyList varchar(1000),
  @ToolAccessList varchar(1000),
  @Brands varchar(255),
  @DOTSName varchar(30),
  @RCTOSites varchar(50),
  @RegulatoryModel varchar(15),
  @EmailActive tinyint,
  @Fusion bit,
  @FusionRequirements bit,
  @CreateSimpleAvTypeAuto bit,
  @AllowSMR bit,
  @AllowDeliverableReleases bit,
  @AllowImageBuilds bit,
  @AllowFollowMarketingName bit,
  @AllowDCR bit,
  @OnCommodityMatrix bit,
  @OnlineReports tinyint,
  @DCRAutoOpen tinyint,
  @BaseUnit varchar(2000),
  @CurrentROM varchar(200),
  @CurrentWebROM varchar(200),
  @OSSupport varchar(2000),
  @ImagePO varchar(8000),
  @ImageChanges varchar(2000),
  @SystemBoardID varchar(200),
  @SystemBoardComments varchar(1200),
  @MachinePnPID varchar(200),
  @MachinePnPComments varchar(1200),
  @CommonImages varchar(300),
  @CertificationStatus varchar(3000),
  @SWQAStatus varchar(8000),
  @PlatformStatus varchar(8000),
  @PDDPath varchar(256),
  @SCMPath varchar(256),
  @AccessoryPath varchar(256),
  @IDInformationPath varchar(256),
  @STLStatusPath varchar(256),
  @ProgramMatrixPath varchar(256),
  @Description Varchar(max),
  @Objectives Varchar(max),
  @SEPE int,
  @PINPM int,
  @SETestLead int,
  @SETestID int,
  @ODMTestLeadID int,
  @WWANTestLeadID int,
  @BIOSLead int,
  @CommHWPM int,
  @VideoMemoryPM int,
  @GraphicsControllerPM int,
  @ProcessorPM int,
  @SustainingMgrID int,
  @SustainingSEPMID int,
  @SysEngrProgramCoordinatorID int,
  @ProgramBusinessManagerID int,
  @PreinstallCutoff varchar(15),
  @PCID int,
  @MarketingOpsID int,
  @ShowOnWhql bit,
  @DCRApproverList varchar(1000),
  @GPLM int,
  @SPDM int,
  @SBA int,
  @DocPM int,
  @DKCID int,
  @MinRoHSLevel int,
  @BSAMFlag bit,
  @AffectedProduct int,
  @AddDCRNotificationList bit,
  @NewID int output,
  @FinanceID int = 0,
  @FullName varchar(50),
  @SharedAVMarketingPMID int = null,
  @SharedAVPCID int = null,
  @ODMSEPMID int = null,
  @ProcurementPMID int = null,
  @PlanningPMID int = null,
  @ODMPIMPMID int = null,
  @SCMOwnerId int = null,
  @EngineeringDataManagementId int = null,
  @ODMHWPMId int = null,
  @HWPCId int = null,
  @WWANProduct bit,
  @CommodityLock bit,
  @ServiceLifeDate datetime
 ) 
As 

DECLARE @BusinessOperation int
DECLARE @StableConsistent bit = NULL

select	@BusinessOperation = CASE WHEN Operation = 1 THEN 1 ELSE 0 END from BusinessSegment where BusinessSegmentID = @BusinessSegmentID

if @UpdateReleases = 0 
	 Insert ProductVersion(AutoSimpleAV,FusionRequirements,BusinessSegmentID,ProductName,Fusion,DCRDefaultOwner,AllowImageBuilds,AllowFollowMarketingName,RCTOSites,SETestID,GraphicsControllerPMID,ToolAccessList,ActionNotifyList,CurrentWebRom,ODMTestLeadID, WWANTestLeadID, TypeID,AllowSMR,AllowDeliverableReleases,AllowDCR,MachinePnPComments,SystemBoardComments,ProcessorPMID,VideoMemoryPMID,CommHWPMID,BIOSLeadID,AccessoryPath,IDInformationPath,SCFactoryEngineerID, AccessoryPMID, RegulatoryModel,ProductStatusID,ReferenceID, ReleaseTeam, DevCenter, PDDPath,SCMPath,STLStatusPath,ProgramMatrixPath,OnCommodityMatrix,PartnerID,DCRAutoOpen,Brands,Active, Sustaining, BaseUnit, CurrentRom, OSSupport, ImagePO, ImageChanges, SystemBoardID, MachinePnPID,CommonImages, CertificationStatus, SWQAStatus,PlatformStatus,Division, PreinstallTeam, EmailActive,OnlineReports, Version, ProductFamilyID,Distribution,DOTSName,Cycle,PMID,TDCCMID,SMID,SEPMID,PDEID,ComMarketingID, ConsMarketingID,SMBMarketingID,PlatformDevelopmentID,SupplyChainID,ServiceID,FinanceID,Description,Objectives,SEPE, PINPM, SETestLead, SustainingMgrID, SustainingSEPMID, ProductLineID, SysEngrProgramCoordinatorID, ProgramBusinessManagerID, PreinstallCutoff, PCID, MarketingOpsID, ShowOnWhql, DCRApproverList,GPLM,SPDM,SvcBomAnalyst,ConveyorBuildDistribution,ConveyorReleaseDistribution, DocPM, DKCID, MinRoHSLevel, BSAMFlag, AffectedProduct, AddDCRNotificationList, IsDesktop, QualityID, CreatedBy, UpdatedBy, SharedAVMarketingID, SharedAVPCID, ODMSEPMID, ProcurementPMID, PlanningPMID, ODMPIMPMID, SCMOwnerID, EngineeringDataManagementID, ODMHWPMID, HWPCID,
			WWANProduct, CommodityLock, ServiceLifeDate, bStableConsistent)
	 Values (@CreateSimpleAvTypeAuto, @FusionRequirements,@BusinessSegmentID,@ProductName,@Fusion,@DCRDefaultOwner,@AllowImageBuilds,@AllowFollowMarketingName,@RCTOSites,@SETestID,@GraphicsControllerPM,@ToolAccessList,@ActionNotifyList,@CurrentWebRom,@ODMTestLeadID, @WWANTestLeadID, @TypeID,@AllowSMR,@AllowDeliverableReleases,@AllowDCR,@MachinePnPComments,@SystemBoardComments,@ProcessorPM,@VideoMemoryPM,@CommHWPM,@BIOSLead,@AccessoryPath,@IDInformationPath,@SCFactoryEngineerID,@AccessoryPMID, @RegulatoryModel,@ProductStatusID,@ReferenceID,@ReleaseTeam, @DevCenter, @PDDPath,@SCMPath,@STLStatusPath,@ProgramMatrixPath,@OnCommodityMatrix,@PartnerID,@DCRAutoOpen,@Brands,@Active, @Sustaining, @BaseUnit, @CurrentROM, @OSSupport, @ImagePO, @ImageChanges, @SystemBoardID, @MachinePnPID,@CommonImages, @CertificationStatus, @SWQAStatus,@PlatformStatus,@DivisionID, @PreinstallTeam,@EmailActive,@OnlineReports, @version, @FamilyID,@Distribution,@DOTSName,'N/A',@PMID,@TDCCMID,@SMID,@SEPMID,@PDEID,@ComMarketingID, @ConsMarketingID,@SMBMarketingID,@PlatformDevelopmentID,@SupplyChainID,@ServiceID,@FinanceID,@Description,@Objectives,@SEPE,@PINPM,@SETestLead,@SustainingMgrID, @SustainingSEPMID, nullif(@ProductLineID, 0),	@SysEngrProgramCoordinatorID, @ProgramBusinessManagerID, @PreinstallCutoff, @PCID, @MarketingOpsID, @ShowOnWhql, @DCRApproverList,@GPLM,@SPDM,@SBA,@ConveyorBuildDistribution,@ConveyorReleaseDistribution, @DocPM, @DKCID, @MinRoHSLevel, @BSAMFlag, @AffectedProduct, @AddDCRNotificationList, @BusinessOperation, @QualityID,  @FullName, @FullName, @SharedAVMarketingPMID, @SharedAVPCID, @ODMSEPMID, @ProcurementPMID, @PlanningPMID, @ODMPIMPMID, @SCMOwnerId, @EngineeringDataManagementId, @ODMHWPMId, @HWPCId,
			 @WWANProduct, @CommodityLock, @ServiceLifeDate, @StableConsistent)
else if @UpdateReleases = 1
	 Insert ProductVersion(AutoSimpleAV,FusionRequirements,BusinessSegmentID,ProductName,Fusion,DCRDefaultOwner,AllowImageBuilds,AllowFollowMarketingName,RCTOSites,SETestID,GraphicsControllerPMID,ToolAccessList,ActionNotifyList,CurrentWebRom,ODMTestLeadID, WWANTestLeadID,TypeID,AllowSMR,AllowDeliverableReleases,AllowDCR,MachinePnPComments,SystemBoardComments,ProcessorPMID,VideoMemoryPMID,CommHWPMID,BIOSLeadID,AccessoryPath,IDInformationPath,SCFactoryEngineerID,AccessoryPMID, RegulatoryModel,ProductStatusID,ReferenceID, ReleaseTeam, DevCenter, PDDPath,SCMPath,STLStatusPath,ProgramMatrixPath,OnCommodityMatrix,PartnerID,DCRAutoOpen,Brands,Active, Sustaining, PRDReleased,PDDReleased, BaseUnit, CurrentRom, OSSupport, ImagePO, ImageChanges, SystemBoardID, MachinePnPID,CommonImages, CertificationStatus, SWQAStatus,PlatformStatus,Division,PreinstallTeam, EmailActive,OnlineReports, Version, ProductFamilyID,Distribution,DOTSName,Cycle,PMID,TDCCMID,SMID,SEPMID,PDEID,ComMarketingID, ConsMarketingID,SMBMarketingID,PlatformDevelopmentID,SupplyChainID,ServiceID,FinanceID,Description,Objectives,SEPE, PINPM, SETestLead, SustainingMgrID,SustainingSEPMID, ProductLineID, SysEngrProgramCoordinatorID, ProgramBusinessManagerID, PreinstallCutoff, PCID, MarketingOpsID, ShowOnWhql, DCRApproverList,GPLM,SPDM,SvcBomAnalyst,ConveyorBuildDistribution,ConveyorReleaseDistribution, DocPM, DKCID, MinRoHSLevel, BSAMFlag, AffectedProduct, AddDCRNotificationList, IsDesktop, QualityID, CreatedBy, UpdatedBy, SharedAVMarketingID, SharedAVPCID, ODMSEPMID, ProcurementPMID, PlanningPMID, ODMPIMPMID, SCMOwnerID, EngineeringDataManagementID, ODMHWPMID, HWPCID,
			WWANProduct, CommodityLock, ServiceLifeDate, bStableConsistent)
	 Values (@CreateSimpleAvTypeAuto,@FusionRequirements,@BusinessSegmentID,@ProductName,@Fusion,@DCRDefaultOwner,@AllowImageBuilds,@AllowFollowMarketingName,@RCTOSites,@SETestID,@GraphicsControllerPM,@ToolAccessList,@ActionNotifyList,@CurrentWebRom,@ODMTestLeadID, @WWANTestLeadID,@TypeID,@AllowSMR,@AllowDeliverableReleases,@AllowDCR,@MachinePnPComments,@SystemBoardComments,@ProcessorPM,@VideoMemoryPM,@CommHWPM,@BIOSLead,@AccessoryPath,@IDInformationPath,@SCFactoryEngineerID,@AccessoryPMID, @RegulatoryModel,@ProductStatusID,@ReferenceID, @ReleaseTeam, @DevCenter, @PDDPath,@SCMPath,@STLStatusPath,@ProgramMatrixPath,@OnCommodityMatrix,@PartnerID,@DCRAutoOpen,@Brands,@Active, @Sustaining, GetDate(),GetDate(), @BaseUnit, @CurrentROM, @OSSupport, @ImagePO, @ImageChanges, @SystemBoardID, @MachinePnPID,@CommonImages, @CertificationStatus, @SWQAStatus,@PlatformStatus,@DivisionID, @PreinstallTeam, @EmailActive,@OnlineReports, @version, @FamilyID,@Distribution,@DOTSName,'N/A',@PMID,@TDCCMID,@SMID,@SEPMID,@PDEID,@ComMarketingID, @ConsMarketingID,@SMBMarketingID,@PlatformDevelopmentID,@SupplyChainID,@ServiceID,@FinanceID,@Description,@Objectives,@SEPE,@PINPM,@SETestLead,@SustainingMgrID,@SustainingSEPMID, nullif(@ProductLineID, 0),	@SysEngrProgramCoordinatorID, @ProgramBusinessManagerID, @PreinstallCutoff, @PCID, @MarketingOpsID, @ShowOnWhql, @DCRApproverList,@GPLM,@SPDM,@SBA,@ConveyorBuildDistribution,@ConveyorReleaseDistribution, @DocPM, @DKCID, @MinRoHSLevel, @BSAMFlag, @AffectedProduct, @AddDCRNotificationList, @BusinessOperation, @QualityID,  @FullName, @FullName,@SharedAVMarketingPMID, @SharedAVPCID, @ODMSEPMID, @ProcurementPMID, @PlanningPMID, @ODMPIMPMID, @SCMOwnerId, @EngineeringDataManagementId, @ODMHWPMId, @HWPCId,
			 @WWANProduct, @CommodityLock, @ServiceLifeDate, @StableConsistent)
else if @UpdateReleases = 2
	 Insert ProductVersion(AutoSimpleAV,FusionRequirements,BusinessSegmentID,ProductName,Fusion,DCRDefaultOwner,AllowImageBuilds,AllowFollowMarketingName,RCTOSites,SETestID,GraphicsControllerPMID,ToolAccessList,ActionNotifyList,CurrentWebRom,ODMTestLeadID, WWANTestLeadID,TypeID,AllowSMR,AllowDeliverableReleases,AllowDCR,MachinePnPComments,SystemBoardComments,ProcessorPMID,VideoMemoryPMID,CommHWPMID,BIOSLeadID,AccessoryPath,IDInformationPath,SCFactoryEngineerID,AccessoryPMID, RegulatoryModel,ProductStatusID,ReferenceID, ReleaseTeam, DevCenter, PDDPath,SCMPath,STLStatusPath,ProgramMatrixPath,OnCommodityMatrix,PartnerID,DCRAutoOpen,Brands,Active, Sustaining, PRDReleased,PDDReleased, BaseUnit, CurrentRom, OSSupport, ImagePO, ImageChanges, SystemBoardID, MachinePnPID,CommonImages, CertificationStatus, SWQAStatus,PlatformStatus,Division, PreinstallTeam, EmailActive,OnlineReports, Version, ProductFamilyID,Distribution,DOTSName,Cycle,PMID,TDCCMID,SMID,SEPMID,PDEID,ComMarketingID, ConsMarketingID,SMBMarketingID,PlatformDevelopmentID,SupplyChainID,ServiceID,FinanceID,Description,Objectives,SEPE, PINPM, SETestLead, SustainingMgrID,SustainingSEPMID, ProductLineID, SysEngrProgramCoordinatorID, ProgramBusinessManagerID, PreinstallCutoff, PCID, MarketingOpsID, ShowOnWhql, DCRApproverList,GPLM,SPDM,SvcBomAnalyst,ConveyorBuildDistribution,ConveyorReleaseDistribution, DocPM, DKCID, MinRoHSLevel, BSAMFlag, AffectedProduct, AddDCRNotificationList, IsDesktop, QualityID, CreatedBy, UpdatedBy, SharedAVMarketingID, SharedAVPCID, ODMSEPMID, ProcurementPMID, PlanningPMID, ODMPIMPMID, SCMOwnerID, EngineeringDataManagementID, ODMHWPMID, HWPCID,
			WWANProduct, CommodityLock, ServiceLifeDate, bStableConsistent)
	 Values (@CreateSimpleAvTypeAuto,@FusionRequirements,@BusinessSegmentID,@ProductName,@Fusion,@DCRDefaultOwner,@AllowImageBuilds,@AllowFollowMarketingName,@RCTOSites,@SETestID,@GraphicsControllerPM,@ToolAccessList,@ActionNotifyList,@CurrentWebRom,@ODMTestLeadID, @WWANTestLeadID,@TypeID,@AllowSMR,@AllowDeliverableReleases,@AllowDCR,@MachinePnPComments,@SystemBoardComments,@ProcessorPM,@VideoMemoryPM,@CommHWPM,@BIOSLead,@AccessoryPath,@IDInformationPath,@SCFactoryEngineerID,@AccessoryPMID, @RegulatoryModel,@ProductStatusID,@ReferenceID, @ReleaseTeam, @DevCenter, @PDDPath,@SCMPath,@STLStatusPath,@ProgramMatrixPath,@OnCommodityMatrix,@PartnerID, @DCRAutoOpen,@Brands,@Active, @Sustaining, null,null, @BaseUnit, @CurrentROM, @OSSupport, @ImagePO, @ImageChanges, @SystemBoardID, @MachinePnPID,@CommonImages, @CertificationStatus, @SWQAStatus,@PlatformStatus,@DivisionID, @PreinstallTeam, @EmailActive,@OnlineReports, @version, @FamilyID,@Distribution,@DOTSName,'N/A',@PMID,@TDCCMID,@SMID,@SEPMID,@PDEID,@ComMarketingID, @ConsMarketingID,@SMBMarketingID,@PlatformDevelopmentID,@SupplyChainID,@ServiceID,@FinanceID,@Description,@Objectives,@SEPE,@PINPM,@SETestLead,@SustainingMgrID,@SustainingSEPMID, nullif(@ProductLineID, 0),	@SysEngrProgramCoordinatorID, @ProgramBusinessManagerID, @PreinstallCutoff, @PCID, @MarketingOpsID, @ShowOnWhql, @DCRApproverList,@GPLM,@SPDM,@SBA,@ConveyorBuildDistribution,@ConveyorReleaseDistribution, @DocPM, @DKCID, @MinRoHSLevel, @BSAMFlag, @AffectedProduct, @AddDCRNotificationList, @BusinessOperation, @QualityID,  @FullName, @FullName,@SharedAVMarketingPMID, @SharedAVPCID, @ODMSEPMID, @ProcurementPMID, @PlanningPMID, @ODMPIMPMID, @SCMOwnerId, @EngineeringDataManagementId, @ODMHWPMId, @HWPCId,
		     @WWANProduct, @CommodityLock, @ServiceLifeDate, @StableConsistent)
Select @NewID = SCOPE_IDENTITY()

--update the factory data:
	
	if len( @factoryIds) > 0
	exec('insert into Product_Factory (productversionID, factoryID)	
	select distinct ' + @NewID + ' ,ManufacturingSiteId
	from ManufacturingSite 
	where ManufacturingSiteId in (' +  @factoryIds + ')')

	
-- sync the roster to the user roles
declare @PrevRosterList varchar(max)
select @PrevRosterList = ''
	execute usp_Product_SyncSystemTeamRoster  @NewID, 1, @PrevRosterList output, @FullName
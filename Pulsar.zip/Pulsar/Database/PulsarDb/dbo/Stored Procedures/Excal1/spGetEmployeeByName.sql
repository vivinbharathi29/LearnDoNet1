﻿

CREATE PROCEDURE [dbo].[spGetEmployeeByName]
(
 @Name as varchar(80)
)
As
Select ID, Email, Division
From Employee with (NOLOCK)
Where Name = @Name
 
return 




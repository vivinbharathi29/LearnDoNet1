﻿

CREATE PROCEDURE [dbo].[spGetDistributionAll]
(
	@ProdID int,
	@VersionID int,
	@RootID int
)
 AS
Declare @PreinstallActual bit
Declare @PreLoadActual bit
Declare @WebActual bit
Declare @PatchActual tinyint
Declare @DropInBoxActual bit
Declare @PreinstallDefault bit
Declare @PreLoadDefault bit
Declare @WebDefault bit
Declare @PatchDefault tinyint
Declare @DropInBoxDefault bit
Declare @PreinstallDev bit
Declare @PreinstallROM bit
Declare @AR bit
Declare @CDImage bit
Declare @ISOImage bit
Declare @Scriptpaq bit
Declare @Rompaq bit
Declare @FloppyDisk bit
Declare @Softpaq bit
Declare @SelectiveRestore bit
Declare @ARCD bit
Declare	@DRDVD bit
Declare	@RACDAmericas bit
Declare	@RACDEMEA bit
Declare	@RACDAPD bit
Declare	@DOCCD bit
Declare	@OSCD bit
Declare	@DRDVDDefault bit
Declare	@RACDAmericasDefault bit
Declare	@RACDEMEADefault bit
Declare	@RACDAPDDefault bit
Declare	@DOCCDDefault bit
Declare	@OSCDDefault bit
Declare @SelectiveRestoreDefault bit
Declare @ARCDDefault bit
Declare @PreinstallBrand varchar(50)
Declare @PreloadBrand varchar(50)
Declare @WebBrand varchar(50)
Declare @PatchBrand varchar(50)
Declare @ARCDBrand varchar(50)
Declare @SelectiveRestoreBrand varchar(50)
Declare @DropInBoxBrand varchar(50)
Declare @DIBHWReq varchar(256)
Declare @DIBHWReqDefault varchar(256)
Declare @RCDOnly bit

Select @DIBHWReq=DIBHWReq,@OSCD=OSCD, @DOCCD=DOCCD,@RACDAPD=RACD_APD,@RACDEMEA=RACD_EMEA, @RACDAmericas=RACD_Americas, @DRDVD=DRDVD, @PreinstallBrand = PreinstallBrand, @PreloadBrand = PreloadBrand, @SelectiveRestoreBrand = SelectiveRestoreBrand, @PatchBrand='',@WebBrand=WebBrand,@DropInBoxBrand=DropInBoxBrand, @ARCDBrand=ARCDBrand,@PreinstallActual = Preinstall, @PreloadActual = Preload, @PatchActual=Patch,@WebActual = Web, @DropInBoxActual = DropInBox,@SelectiveRestore = SelectiveRestore,@ARCD=ARCD, @RCDOnly = RCDOnly
FROM Product_Deliverable pd with (NOLOCK)
Where pd.ProductVersionID = @ProdID
and pd.DeliverableVersionID = @VersionID

Select @DIBHWReqDefault=DIBHWReq,@OSCDDefault=OSCD, @DOCCDDefault=DOCCD, @RACDAPDDefault=RACD_APD,@RACDEMEADefault=RACD_EMEA, @RACDAmericasDefault=RACD_Americas, @DRDVDDefault=DRDVD, @PreinstallDefault = Preinstall, @PreloadDefault = Preload, @PatchDefault=patch,@WebDefault = Web, @DropInBoxDefault = DropInBox, @SelectiveRestoreDefault = SelectiveRestore,@ARCDDefault=ARCD
FROM Product_DelRoot pd with (NOLOCK)
Where pd.ProductVersionID = @ProdID
and pd.DeliverableRootID = @RootID

Select @Softpaq = r.Softpaq, @FloppyDisk = v.FloppyDisk, @Rompaq = v.Rompaq, @Scriptpaq = v.Scriptpaq, @AR=v.AR, @CDImage = v.CDImage, @ISOImage = v.ISOImage, @PreinstallROM = v.PreinstallROM, @PreinstallDev = v.Preinstall
FROM DeliverableRoot r with (NOLOCK), DeliverableVersion v with (NOLOCK)
Where r.Id = v.DeliverableRootID
and v.Id = @VersionID

Select @DIBHWReq as DIBHWReq, @DIBHWReqDefault as DIBHWReqDefault,@OSCDDefault as OSCDDefault, @DOCCDDefault as DOCCDDefault, @RACDAPDDefault as RACD_APDDefault, @RACDEMEADefault as RACD_EMEADefault, @RACDAmericasDefault as RACD_AmericasDefault, @DRDVDDefault as DRDVDDefault,@OSCD as OSCD, @DOCCD as DOCCD, @RACDAPD as RACD_APD, @RACDEMEA as RACD_EMEA, @RACDAmericas as RACD_Americas, @DRDVD as DRDVD, @PreinstallBrand as PreinstallBrand, @PreloadBrand as PreloadBrand, @SelectiveRestoreBrand as SelectiveRestoreBrand, @PatchBrand as PatchBrand,@WebBrand as webbrand,@DropInBoxBrand as dropinboxbrand, @ARCDBrand as arcdbrand,@SelectiveRestore as SelectiveRestore, @ARCD as ARCD ,@PreinstallDev as Preinstalldev, @PreinstallROM as PreinstallROM, @AR as AR, @CDImage as CDImage, @ISOImage as ISOImage, @Scriptpaq as Scriptpaq, @Rompaq as Rompaq, @Floppydisk as FloppyDisk, @Softpaq as Softpaq, @PreinstallActual as PreinstallActual, @PreloadActual as PreloadActual, @PatchActual as PatchActual ,@WebActual as WebActual, @DropInBoxActual as DropInBoxActual,@PreinstallDefault as PreinstallDefault, @PreloadDefault as PreloadDefault,@PatchDefault as PatchDefault ,@WebDefault as WebDefault, @DropInBoxDefault as DropInBoxDefault,@SelectiveRestoreDefault as SelectiveRestoreDefault,@ARCDDefault as ARCDDefault, @RCDOnly as RCDOnly


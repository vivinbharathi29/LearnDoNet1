﻿
CREATE PROCEDURE [dbo].[spApproveNewODMUser]
(
	@ID int
)
AS
	DECLARE @PartnerTypeID int
	set nocount on
		Select @PartnerTypeID = pt.id
		from employee e with (NOLOCK), partner p with (NOLOCK), partnertype pt with (NOLOCK)
		where e.partnerid = p.id
		and pt.id = p.partnertypeid
		and e.id = @ID
	set nocount off

	if @PartnerTypeID = 1
		Update Employee
		Set ODMLoginStatus=1
		Where ID = @ID
	else
		Update Employee
		Set ODMLoginStatus=1, approvalsection=0, pastduesection=0, duethisweeksection=0, allopensection=0, isubmittedsection=0,closedsection=0, proposedsection=0, otssubmittedsection=1, otsownersection=1
		Where ID = @ID
	



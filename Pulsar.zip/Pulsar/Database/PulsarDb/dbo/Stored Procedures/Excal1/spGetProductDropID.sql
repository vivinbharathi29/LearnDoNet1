﻿
CREATE PROCEDURE [dbo].[spGetProductDropID]
(
	@ProductDropID varchar(300)
)
AS

	select	ProductDropID 
	from IRS_ProductDrop WITH (NOLOCK)
	where Name = @ProductDropID


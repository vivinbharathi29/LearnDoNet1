﻿

CREATE PROCEDURE [dbo].[spAddProgram]
 (
  @Name as varchar(30),
  @FullName as varchar(34),
  @ProgramGroupID as int,
  @OTSCycleName as varchar(40),
  @Active as tinyint = 1,
  @ID as int output
 )

 AS

--if @CurrentProgram = 1
--	Update Program 
--	set CurrentProgram = 0
--	Where BusinessID = @BusinessID

Insert Program(Name,FullName,Active, ProgramGroupID, OTSCycleName)
Values(@Name,@FullName,@Active, @ProgramGroupID, @OTSCycleName);
Select @ID = SCOPE_IDENTITY()


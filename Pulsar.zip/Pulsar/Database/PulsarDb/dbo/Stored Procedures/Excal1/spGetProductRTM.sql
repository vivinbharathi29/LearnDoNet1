﻿/* ************************************************************************************************  
 * Purpose: GetProductRTM  
 * Created By: ?  
 * Modified By: Herb, 05/27/2016, PBI 20383 Add Firmware standalone RTM  
**************************************************************************************************  
** Change History      
**************************************************************************************************  
** SNo   Date        Author  Description      
** --   --------    -------    -------------------------      
** 2    03/22/2019 Santhana.k  New Columns RTPStatus,RTPDate,SerialNumber,RTPComments,typeid,RTMNotifications and RTPCompletedby included  
**************************************************************************************************/ 
--spGetProductRTM 1784 
CREATE PROCEDURE [dbo].[spGetProductRTM]  
(  
 @ID int  
)  
AS  
 
	SELECT  distinct
		 r.ID,  
		 p.dotsname AS Product,  
		 r.title,  
		 r.rtmDate,  
		 r.comments,  
		 u.FullName AS Submitter,  
		 r.created,  
		 r.bioscomments,  
		 r.FWComments,  
		 r.patchcomments,  
		 r.restorecomments,  
		 r.imagecomments,  
		 r.attachment1,  
		 r.RTPStatus, 
		 r.RTPDate, 
		 r.SerialNumber, 
		 r.RTPComments, 
		 ISNULL(STUFF((SELECT distinct ',' +  CAST(pd.typeid AS VARCHAR(10)) [text()]
				FROM ProductRTM t
				inner join ProductRTM_DeliverableVersion pd with (NOLOCK)  on r.id = pd.productRTMID 
				WHERE r.ID = t.ID
				FOR XML PATH(''), TYPE)
				.value('.','NVARCHAR(MAX)'),1,1,''),0
				) typeid ,  
				(select Top 1 Details from ProductRTM_DeliverableVersion where Details is not null and Details!='' and ProductRTMID=@ID) as Affectivity,		
		  STUFF(
                 (SELECT ';' + EMAIL 
				 FROM userinfo ui
				 INNER JOIN RoleMembers r
				 on ui.userid=r.userid
				 WHERE roleid='1904' 				
				 FOR XML PATH ('')), 1, 1, ''
					
               ) as Email,
		 RTPCompletedby,
		 u.FirstName +' '+u.LastName as RTMInitiatedBy
	FROM productrtm r WITH (NOLOCK)  
	INNER JOIN productversion p WITH (NOLOCK)  ON p.id = r.productversionid  
	INNER JOIN userinfo u WITH (NOLOCK) ON u.UserId = r.submittedByID  
	LEFT JOIN ProductRTM_DeliverableVersion pd  ON R.id = pd.productRTMID  
	WHERE r.id = @ID
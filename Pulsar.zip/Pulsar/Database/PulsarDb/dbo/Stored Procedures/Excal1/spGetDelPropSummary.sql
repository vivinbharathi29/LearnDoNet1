﻿

CREATE PROCEDURE [dbo].[spGetDelPropSummary]
(
	@RootID int
)
 AS

SELECT     
	r.DevManagerID, 
	r.LockReleases, 
	r.CoreTeamID, 
	r.BasePartNumber, 
	r.DeliverableSpec, 
	c.TeamID, 
	t.Name AS tester, 
	r.Name, 
	c.Name AS Category, 
	v.Name AS Vendor, 
	e.Name AS Manager, 
	r.Description, 
	r.Notes, 
	r.TypeID, 
	r.RootFilename AS Filename, 
	r.Active, 
	d.Name AS Developer, 
	r.ShowOnStatus,
	c.Id AS CategoryId
FROM
	DeliverableRoot AS r WITH (NOLOCK) INNER JOIN
    Vendor AS v  WITH (NOLOCK) ON r.VendorID = v.ID INNER JOIN
    Employee AS e WITH (NOLOCK) ON r.DevManagerID = e.ID INNER JOIN
    DeliverableCategory AS c WITH (NOLOCK) ON r.CategoryID = c.ID LEFT OUTER JOIN
    Employee AS t WITH (NOLOCK) ON r.TesterID = t.ID LEFT OUTER JOIN
    Employee AS d WITH (NOLOCK) ON r.DeveloperID = d.ID
WHERE     
	(r.ID = @RootID)

﻿

CREATE PROCEDURE [dbo].[spgetCoreTeamReps]
As
Select ID, Name
FROM CoreTeamRep with (NOLOCK)
Order By ID




﻿

CREATE PROCEDURE [dbo].[spGetSharedProfile]
(
	@ProfileID int
)
AS

	Select ID, employeeid, Setting
	from Employee_UserSettings with (NOLOCK)
	Where ID = @ProfileID



﻿CREATE PROCEDURE [dbo].[spGetHardwarePMProductCount] 
(
	@EmployeeID int
)
AS
/* ************************************************************************************************
 * Purpose:	
 * Created By: poletto   
 * Modified By: 
				buidi 10/05/2016 - allow ODMHWPM and HWPC to be HWPM
 **************************************************************************************************/ 
	DECLARE @ServicePM as int

	Select @ServicePM = ID
	from employee with (NOLOCK)
	where servicepm=1
	and id = @EmployeeID


	Select count(1) as Products, count(case when v.devcenter=2 then 1 else null end) as ConsumerProducts, count(case when v.devcenter=2 then null else 1 end) as CommercialProducts
	from ProductVersion v with (NOLOCK), Employee e with (NOLOCK)
	where e.id = v.pdeid
	and v.productstatusid < 5
	and (v.pdeid = @EmployeeID
		or v.CommHWPMID = @EmployeeID
		or v.VideoMemoryPMid = @EmployeeID
		or v.GraphicsControllerPMid = @EmployeeID
		or v.ProcessorPMid = @EmployeeID
		or v.CommHWPMID = @EmployeeID
		or v.PlatformDevelopmentID = @EmployeeID
		or v.ODMHWPMID = @EmployeeID
		or v.HWPCID = @EmployeeID
		or @ServicePM Is Not null
		)




﻿
CREATE PROCEDURE [dbo].[spGetSubassemblyBridge]
(
	@ProdDelID int,
	@RootID int
)
AS
	select pddr.bridged, p.dotsname as Product, v.deliverablename, v.partnumber, s.name as SubassemblyName, pdr.subassembly
	from  deliverableversion v with (NOLOCK), product_deliverable pd with (NOLOCK), ProdDel_DelRoot pddr with (NOLOCK), deliverableroot as s with (NOLOCK), product_delroot pdr with (NOLOCK), productversion p with (NOLOCK)
	where pddr.ProductDeliverableID = @ProdDelID
	and p.id = pd.productversionid
	and pddr.DeliverableRootID = @RootID
	and s.id = pddr.deliverablerootid
	and s.id = pdr.deliverablerootid
	and pd.id = pddr.productdeliverableid
	and pd.productversionid = pdr.productversionid
	and pd.deliverableversionid = v.id
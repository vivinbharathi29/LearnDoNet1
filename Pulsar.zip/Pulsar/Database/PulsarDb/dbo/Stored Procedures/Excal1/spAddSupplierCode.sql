﻿
CREATE PROCEDURE [dbo].[spAddSupplierCode]
(
	@CategoryID int,
	@VendorID int,
	@SupplierCode varchar(50)
)

AS

Insert Into DeliverableCategory_Vendor (SupplierCode, DeliverableCategoryID, VendorID)
Values(@SupplierCode,@CategoryID,@VendorID)


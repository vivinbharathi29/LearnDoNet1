﻿CREATE PROCEDURE [dbo].[spListDeliverableAlertDetailsAll]
(
	@ProdID int ,
	@ReportType int = 1,
	@TeamID int = null
)
AS
--ReportType: 1=non-HW, 3=HW, 2=SystemBIOS Only
if @ReportType = 1
	Select l.name as Buildlevel, v.DeveloperNotification, l.id as LevelID, pd.developernotificationstatus, v.location, r.certrequired, v.certificationstatus,v.endoflifeDate as EOLDate, pd.targeted, pd.Preinstall, preload, pd.DropInBox, pd.Patch, pd.web, pd.SelectiveRestore,pd.arcd,pd.drdvd,pd.racd_EMEA,pd.racd_APD,pd.Racd_Americas,pd.doccd,pd.oscd,v.id, r.id as RootID, v.PostRTMStatus, v.PostRTMTargetDate, r.categoryid,r.active, r.typeid,v.preinstallinternalrev, v.CertificationStatus, v.PostRTMComments, r.name, vd.name as vendor, v.Version, v.Revision, v.Pass, v.PartNumber, v.ModelNumber, v.filename, v.deliverablename, p.ProductStatusID, pd.DeveloperTestNotes
	FROM DeliverableVersion v WITH (NOLOCK) 
	INNER JOIN DeliverableRoot r WITH (NOLOCK) ON r.ID = v.DeliverableRootID  
	INNER JOIN vendor vd WITH (NOLOCK) ON vd.ID = v.VendorID
	INNER JOIN product_deliverable pd WITH (NOLOCK) ON v.id = pd.deliverableversionid
	INNER JOIN productversion p WITH (NOLOCK) ON p.id = pd.ProductVersionID	
	LEFT OUTER JOIN DeliverableLevel l WITH (NOLOCK) ON v.LevelID = l.ID
	Where pd.targeted = 1
	and r.typeid <> 1
	and p.id = @ProdID
	order by r.name
else if @ReportType = 2
	Select l.name as Buildlevel, v.DeveloperNotification, l.id as LevelID, pd.developernotificationstatus, v.location, r.certrequired, v.certificationstatus,v.endoflifeDate as EOLDate, pd.targeted, pd.Preinstall, preload, pd.DropInBox, pd.patch, pd.web, pd.SelectiveRestore,pd.arcd,pd.drdvd,pd.racd_EMEA,pd.racd_APD,pd.Racd_Americas,pd.doccd,pd.oscd,v.id, r.id as RootID, v.PostRTMStatus, v.PostRTMTargetDate, r.categoryid,r.active, r.typeid,v.preinstallinternalrev, v.CertificationStatus, v.PostRTMComments, r.name, vd.name as vendor, v.Version, v.Revision, v.Pass, v.PartNumber, v.ModelNumber, v.filename, v.deliverablename, p.ProductStatusID, pd.DeveloperTestNotes
	FROM 
		DeliverableRoot r WITH (NOLOCK)
		INNER JOIN DeliverableVersion v WITH (NOLOCK) ON r.id = v.deliverablerootid
		INNER JOIN vendor vd WITH (NOLOCK) ON vd.id = v.vendorid
		INNER JOIN product_deliverable pd WITH (NOLOCK) ON v.id = pd.deliverableversionid
		INNER JOIN productversion p WITH (NOLOCK) ON p.id = pd.productversionid
		LEFT OUTER JOIN DeliverableLevel l WITH (NOLOCK) ON l.id = v.levelid
	Where pd.targeted = 1
	and r.categoryid = 161
	and p.id = @ProdID
	order by r.name
else if @ReportType = 3
	Select l.name as Buildlevel, v.DeveloperNotification, l.id as LevelID, pd.developernotificationstatus, v.location, r.certrequired, v.certificationstatus,v.endoflifeDate as EOLDate, pd.targeted, pd.Preinstall, preload, pd.DropInBox, pd.patch, pd.web, pd.SelectiveRestore,pd.arcd,pd.drdvd,pd.racd_EMEA,pd.racd_APD,pd.Racd_Americas,pd.doccd,pd.oscd,v.id, r.id as RootID, v.PostRTMStatus, v.PostRTMTargetDate, r.categoryid,r.active, r.typeid,v.preinstallinternalrev, v.CertificationStatus, v.PostRTMComments, r.name, vd.name as vendor, v.Version, v.Revision, v.Pass, v.PartNumber, v.ModelNumber, v.filename, v.deliverablename, p.ProductStatusID, pd.DeveloperTestNotes
	FROM 
		DeliverableRoot r WITH (NOLOCK)
		INNER JOIN DeliverableVersion v WITH (NOLOCK) ON r.id = v.deliverablerootid
		INNER JOIN Deliverablecategory c WITH (NOLOCK) ON c.id = r.categoryid
		INNER JOIN vendor vd WITH (NOLOCK) ON vd.id = v.vendorid
		INNER JOIN product_deliverable pd WITH (NOLOCK) ON v.id = pd.deliverableversionid
		INNER JOIN productversion p WITH (NOLOCK) ON p.id = pd.productversionid
		LEFT OUTER JOIN DeliverableLevel l WITH (NOLOCK) ON l.id = v.levelid
	Where pd.targeted = 1
	and r.typeid = 1
	and c.TeamID = coalesce(@TeamID,c.TeamID)
	and p.id = @ProdID
	order by r.name


﻿-- spFusion_PROJECT_AddUpdatePlatformSystemboardinIRS 253187, 0
CREATE PROCEDURE [dbo].[spFusion_PROJECT_AddUpdatePlatformSystemboardinIRS]
/* ************************************************************************************************
 * Purpose:	Add and update platform system board
 * Created By:	Unknown
 *				09/21/2018 - wgomero - PBI 225464 Increase the Product Family character limit in the Base Unit Group to match the Product Family from Product Properties General Tab
 **************************************************************************************************/
 /**************************************************************************************************    
** SNo   Date        Author                     Description           
** --    --------   -------                     -------------------------           
 ** 1    09/01/2019  Santhana K					Used the Setting table instead of hardcoding email address
****************************************************************************************************/ 
(
    @AVDetailProductBrandID int,
    @Updater as int
)
AS
	SET NOCOUNT ON

    DECLARE @MarketingName as varchar(80)
    DECLARE @IntroYear as varchar(10)
    DECLARE @Family as varchar(64)
    DECLARE @Product as varchar(30)
    DECLARE @FieldValues as varchar(8000)
    DECLARE @Division as varchar(10)
    DECLARE @SystemBoardID as varchar(8000)
    DECLARE @IRSID int
    DECLARE @SystemID  as varchar(10)
    DECLARE @pPSID int
    DECLARE @ProductID int
    DECLARE @ShortUpdaterName as varchar(18)
    DECLARE @FullUpdaterName as varchar(64)
    DECLARE @Action varchar(6)
    DECLARE @AVID int
    DECLARE @IRSIDString as varchar(30)

    DECLARE @IRSIntroYear as varchar(10)
    DECLARE @IRSFamily as varchar(20)
    DECLARE @IRSProduct as varchar(30)

	Declare @RecipientEmail varchar(100)
	select @RecipientEmail = value from Setting
	where name = 'Pulsar.SupportEmail'
	

    SELECT @shortUpdaterName = name FROM Employee WITH (NOLOCK) WHERE id = @Updater
    IF @shortUpdaterName is null
        SELECT @shortUpdaterName = 'Excalibur'

    SELECT @FullUpdaterName = left(@shortUpdaterName,64)
    SELECT @shortUpdaterName = left(@shortUpdaterName,18)

    --- Select the details needed for the AvDetail_ProductBrand record submitted
    DECLARE IRS_Product_CURSOR CURSOR FOR
     SELECT pv.productname as name, LEFT(LTRIM(RTRIM(Av.GPGDescription)),40), pv.id, pv.DOTSName, avpb.irsplatformid,  case when pv.devcenter=2 then 278 else 269 end, dr.systemboardid
       FROM AvDetail_ProductBrand AvPb WITH (NOLOCK)
            INNER JOIN AvDetail Av WITH (NOLOCK) ON AvPb.AvDetailID = Av.AvDetailID
            INNER JOIN Product_Brand Pb WITH (NOLOCK) ON AvPb.ProductBrandID = Pb.ID
            --INNER JOIN AvCreate AvC WITH (NOLOCK) ON AvPb.ProductBrandID = AvC.ProductBrandID AND Av.AvDetailID = AvC.AvDetailID
            --INNER JOIN DeliverableRoot Dr WITH (NOLOCK) ON AvC.DeliverableRootID = Dr.ID
            INNER JOIN DeliverableRoot Dr WITH (NOLOCK) ON Av.DeliverableRootID = Dr.ID
            INNER JOIN ProductVersion Pv WITH (NOLOCK) ON Pb.ProductVersionID = Pv.ID
            INNER JOIN ProductFamily Pf WITH (NOLOCK) ON Pv.ProductFamilyID = Pf.ID
            LEFT OUTER JOIN Platform Irs WITH (NOLOCK) ON AvPb.IRSPlatformId = Irs.PlatformId
      WHERE (Av.FeatureCategoryID = 1 OR Av.FeatureCategoryID = 86)
        AND (Pv.ID >= 993)
        AND AvPb.Id = @AVDetailProductBrandID
        AND pv.id <> 100

    OPEN IRS_Product_CURSOR

    FETCH NEXT FROM IRS_Product_CURSOR Into @Family,@MarketingName,@ProductID , @Product, @IRSID, @Division, @SystemBoardID
    WHILE (@@FETCH_STATUS = 0)
        BEGIN

				DECLARE @IrsPlatformId INT, @IrsPlatformCount INT
				SELECT @IrsPlatformId = PlatformId FROM Platform WITH (NOLOCK) WHERE ProductFamily = @Family AND PCA = @Product AND MarketingName = @MarketingName
				SELECT @IrsPlatformCount = COUNT(1) FROM Platform WITH (NOLOCK) WHERE ProductFamily = @Family AND PCA = @Product AND MarketingName = @MarketingName

				-- Pull IntroYear, ProductFamily & PCA from the IRS Platform table.
				SELECT @IRSIntroYear = IntroYear, @IRSFamily = ProductFamily, @IRSProduct = PCA FROM Platform  WITH (NOLOCK) WHERE Platformid = @IRSID

				-- If @IrsId = 0 then Create a new record otherwise Update the existing record.
				IF (@IRSID = 0)
					SELECT @Action='create'
				ELSE
					SELECT @Action='update'

				-- Get the IntroYear from Excalibur based on the scheduled RTP Date in Excalibur.
				SELECT @IntroYear = DATEPART(yyyy, dbo.ufnGetScheduledDate(93, @ProductID))

				-- Build Field Values from collected data.
-- Changed because division was going into the wronge field.
--				SELECT @FieldValues = @IntroYear + '|\|' + @Family + '|\|' + @Product + '|\|1578|\|' + @MarketingName + '|\|' + @MarketingName + '|\|' + @MarketingName + '|\|0|\||\||\||\|' + @SystemBoardID + '|\|' + @Division + '|\||\|'
				SELECT @FieldValues = @IntroYear + '|\|' + @Family + '|\|' + @Product + '|\|1578|\|' + @MarketingName + '|\|' + @MarketingName + '|\|' + @MarketingName + '|\|0|\||\||\||\|' + @SystemBoardID + '|\||\|' + @Division + '|\||\|'
				--N'2014|\|Arch|\|Lavender-G Intel H87|\|2809|\|HP HP Pavilion23 All-in-One (Lavender-G)|\|HP 23-g0xx PC|\|HP 23-g0xx PC|\|0|\||\|GFX-0-0; LAN-0-0|\||\||\|1C14|\|266,267|\|0|\|'
				-- If @IntroYear is NULL we can't send the product.
				-- If @IrsId is not 0 and the IRS values don't match the Excalibur values we can not update.
				-- Else send the data to IRS.

				IF @IntroYear IS NULL
					PRINT 'Product is not ready to be sent: ' + @Product
				ELSE IF @IRSID <> 0  AND (@IntroYear <> @IRSIntroYear OR @Family <> @IRSFamily OR @Product <> @IRSProduct)
					PRINT 'Can not update because Intro Year, Family, or Product does not match the record referenced by the saved IRSPlatformID in Excalibur'
				ELSE IF (@IrsPlatformId IS NOT NULL) BEGIN
					PRINT 'Record Already Exists for ' + @FieldValues
					SET @IRSID = ISNULL(@IRSID,0)
					Print @Action
					Print CAST(@IRSID AS VARCHAR)

					SET @IRSIDString = CAST(@IRSID AS VARCHAR)
					SET @pPSID=0

					EXEC IRS_usp_ADMIN_PlatformsandSystemBoards
							@p_chrFunction=@Action,                 -- varchar(10) Create Mode
							@p_chrID=@IRSIDString,      -- varchar(30) Zero (no platform system board ID)
							@p_chrTable='LCMPlatform_Update',       -- varchar(255) Do not change this value, pass as is
							@p_chrFieldValues=@FieldValues,
							@p_chrPersonName= @ShortUpdaterName,    -- varchar(18) Name of user that creates the Platform System Board
							@p_chrPersonFullName=@FullUpdaterName,  -- varchar(64) Name of user that creates the Platform System Board
							@p_chrChildLinkID=NULL,                 -- VARCHAR(30) Null value
							@p_chrReturnID=@pPSID output            -- varchar(10) output Return Value

					SELECT @pPSID


					IF (@IrsPlatformCount = 1) BEGIN
						DECLARE @IrsAliasId INT
						SELECT @IrsAliasID = ia.aliasid FROM Platform_Alias ipa  WITH (NOLOCK) INNER JOIN Alias ia WITH (NOLOCK) on ia.aliasid = ipa.aliasid WHERE ipa.platformid = @IrsPlatformId

						-- Update AvDetail_ProductBrand records with the Platform System Board ID and the Alias ID.
						EXEC dbo.spFusion_PROJECT_UpdateAvDetailProductBrand  @AVDetailProductBrandID ,@IrsPlatformId, @IrsAliasID

						-- Create a HW Component for the Platform System Board.
						EXEC spFusion_HWCOMPONENT_UpdateSystemboardInIRS null, @AVDetailProductBrandID, 31
					END ELSE BEGIN
						DECLARE @ErrorBody varchar(5000)
						SELECT @ErrorBody = 'Duplicate Platform Found in IRS: ' + @FieldValues
		
					EXEC msdb.dbo.sp_send_dbmail
							@profile_name = 'Database Mail Profile',
							@recipients =@RecipientEmail , 
							@body = @ErrorBody,
							@subject = 'IRS Platform Duplicate Possibly Found' ;		
					END
				END ELSE BEGIN
					PRINT 'Creating Updating ' + @FieldValues
					SET @IRSID = ISNULL(@IRSID,0)
					SELECT @IRSIDString = CAST(@IRSID AS VARCHAR(30))
					SET @pPSID=0

					EXEC IRS_usp_ADMIN_PlatformsandSystemBoards
							@p_chrFunction=@Action,                 -- varchar(10) Create Mode
							@p_chrID= @IRSIDString,                 -- varchar(30) Zero (no platform system board ID)
							@p_chrTable='LCMPlatform_Update',       -- varchar(255) Do not change this value, pass as is
							@p_chrFieldValues=@FieldValues,
							@p_chrPersonName= @ShortUpdaterName,    -- varchar(18) Name of user that creates the Platform System Board
							@p_chrPersonFullName=@FullUpdaterName,  -- varchar(64) Name of user that creates the Platform System Board
							@p_chrChildLinkID=NULL,                 -- VARCHAR(30) Null value
							@p_chrReturnID=@pPSID output            -- varchar(10) output Return Value

					SELECT @pPSID

					DECLARE @AliasID INT

					-- Get the AliasId for the newley created Platform System Board record.
					SELECT @AliasID = ia.aliasid
						FROM
								Platform_Alias ipa WITH (NOLOCK)
								INNER JOIN Alias ia  WITH (NOLOCK) on ia.aliasid = ipa.aliasid
						WHERE	ipa.platformid = @pPSID

					-- Update AvDetail_ProductBrand records with the Platform System Board ID and the Alias ID.
					EXEC dbo.spFusion_PROJECT_UpdateAvDetailProductBrand  @AVDetailProductBrandID ,@pPSID, @AliasID

					-- Create a HW Component for the Platform System Board.
					EXEC spFusion_HWCOMPONENT_UpdateSystemboardInIRS null, @AVDetailProductBrandID, 31
					END
            FETCH NEXT FROM IRS_Product_CURSOR Into  @Family,@MarketingName,@ProductID , @Product, @IRSID, @Division, @SystemBoardID
        END
    DEALLOCATE IRS_Product_CURSOR
GO



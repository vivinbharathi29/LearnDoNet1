﻿CREATE PROCEDURE [dbo].[spGetOSForRoot] (@ID int)
 AS
 SET NOCOUNT ON
SELECT l.ID, l.Name
FROM  OSLookup l with (NOLOCK)
INNER JOIN  OS_DelRoot d with (NOLOCK)
ON l.ID = d.OSID
WHERE d.DeliverableRootID = @ID
ORDER By DisplayOrder
SET NOCOUNT OFF



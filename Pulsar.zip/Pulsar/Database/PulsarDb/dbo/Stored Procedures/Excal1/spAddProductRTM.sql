﻿CREATE PROCEDURE [dbo].[spAddProductRTM]
(
	@ProductRTMID int,
	@ProductVersionID int,
	@Title varchar(120),
	@RTMDate datetime,
	@Comments varchar(Max),
	@BIOSComments varchar(max),
	@RestoreComments varchar(max),
	@ImageComments varchar(max),
	@PatchComments varchar(max),
	@FWComments varchar(max),
	@Attachment1 varchar(300),
	@SubmittedByID int,
	@RTMAsDraft bit,
	@NewID int output
) 
AS
/* ************************************************************************************************
 *     Purpose:	AddProductRTM
 *  Created By:	?
 * Modified By: Herb, 05/27/2016, PBI 20383 Add Firmware standalone RTM
 *
 *
**************************************************************************************************/
BEGIN
IF(@ProductRTMID=0)
	BEGIN
		Insert into ProductRTM(ProductVersionID, Title,RTMDate,Comments, PatchComments, BIOSComments, RestoreComments,ImageComments,FWComments,Attachment1,SubmittedByID,IsRTMAsDraft)
		values (@ProductVersionID, @Title,@RTMDate,@Comments,@PatchComments, @BIOSComments, @RestoreComments,@ImageComments,@FWComments, @Attachment1, @SubmittedByID,@RTMAsDraft)

		SELECT @NewID = SCOPE_IDENTITY()
	END
ELSE
	BEGIN
		UPDATE ProductRTM SET ProductVersionID=@ProductVersionID,Title=@Title,RTMDate=@RTMDate,Comments=@Comments,
		PatchComments=@PatchComments,BIOSComments=@BIOSComments,RestoreComments=@RestoreComments,ImageComments=@ImageComments,
		FWComments=@FWComments,Attachment1=@Attachment1,SubmittedByID=@SubmittedByID,IsRTMAsDraft=@RTMAsDraft
		WHERE ID=@ProductRTMID

		SELECT @NewID=@ProductRTMID
	END
END
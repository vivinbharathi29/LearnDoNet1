﻿
CREATE PROCEDURE [dbo].[spGetEmployeeUserSetting]
(
	@ID int
)

 AS

	Select ID, Setting
	from Employee_UserSettings with (NOLOCK)
	Where ID = @ID


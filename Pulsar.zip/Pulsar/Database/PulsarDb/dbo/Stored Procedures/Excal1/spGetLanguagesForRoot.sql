﻿CREATE PROCEDURE [dbo].[spGetLanguagesForRoot] (@ID int)
 AS
 /** Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
**  1  6/8/2018     Monica   Changed from ANSI Join 
****************************************************************************************************/
DECLARE @TYPE int

SELECT @TYPE= TypeID 
from deliverableroot 
where ID=@ID

if @Type=1
	SELECT l.ID, 
	d.Title,
	 d.Description,
	 l.Language as Name, 
	 l.active
	FROM  Language l with (NOLOCK)
	INNER JOIN  Language_DelRoot d with (NOLOCK)
	ON l.ID = d.LanguageID
	WHERE d.DeliverableRootID = @ID
	order by l.orderid, l.Language
else
	SELECT l.ID, d.Title, d.Description, l.Abbreviation + ' - ' + l.Language as Name,
	 l.language as Country, l.active
	FROM  Language l with (NOLOCK)
	INNER JOIN  Language_DelRoot d with (NOLOCK)
	ON l.ID = d.LanguageID
	WHERE d.DeliverableRootID = @ID
	order by l.orderid, l.Language





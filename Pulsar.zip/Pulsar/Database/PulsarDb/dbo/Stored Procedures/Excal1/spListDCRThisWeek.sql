﻿
CREATE PROCEDURE [dbo].[spListDCRThisWeek]
(
	@Report		INT			= 1,
	@Duration	INT			= 7,
	@ProductID	INT			= NULL,
	@StartDt	DATETIME	= NULL,
	@EndDt		DATETIME	= NULL,
	@BiosChange BIT			= NULL
)
 AS

/******************************************************************************
**	File: dbo.spListDCRThisWeek.sql
**	Name: spListDCRThisWeek
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  
*******************************************************************************/
 
IF @Report=1 --Opened OR closed
	Select i.ID, Submitter, i.Created, e.Name AS Owner, status, TargetDate, Summary, v.dotsname AS product
	FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK), ProductVersion v WITH (NOLOCK), ProductFamily f WITH (NOLOCK)
	WHERE type = 3 
	AND v.ID = i.ProductVersionID
	AND f.Id = v.ProductFamilyID
	AND v.Division=1
	AND v.id = COALESCE(@ProductID, v.id)
	AND e.id = i.ownerid
	AND ( (i.Created BETWEEN COALESCE(@StartDt, GETDATE()-@Duration) AND COALESCE(@EndDt+1, GETDATE())) OR ( (i.ActualDate between  GETDATE()-@Duration AND GETDATE() AND v.sustaining=0 AND v.active=1) OR (i.ActualDate is not null AND i.ECNDate between  COALESCE(@StartDt,GETDATE()-@Duration) AND COALESCE(@EndDt+1,GETDATE())  AND v.sustaining=1) ))
	AND (@BiosChange IS NULL 
	 OR (@BiosChange = 1 AND BiosChange = @BiosChange) 
	 OR (@BiosChange = 0 AND 
		(BiosChange = 0 OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
	ORDER BY [Product], Status, i.ID
ELSE IF @Report=2 -- Opened
	Select i.ID, Submitter, i.Created, e.Name AS Owner, status, TargetDate, Summary, v.dotsname AS product
	FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK), ProductVersion v WITH (NOLOCK), ProductFamily f WITH (NOLOCK)
	WHERE 
		([type] = 3)
	AND (v.ID = i.ProductVersionID)
	AND (f.Id = v.ProductFamilyID)
	AND (v.Division=1)
	AND (v.id = COALESCE(@ProductID,v.id))
	AND (e.id = i.ownerid)
	AND (i.Created BETWEEN COALESCE(@StartDt, GETDATE()-@Duration) AND COALESCE(@EndDt+1, GETDATE()))
	AND ((@BiosChange IS NULL)
	 OR ((@BiosChange = 1) AND (BiosChange = @BiosChange)) 
	 OR ((@BiosChange = 0) AND 
		((BiosChange = 0) OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
	ORDER BY [Product], Status, i.ID
ELSE IF @Report=3 -- closed
	Select i.ID, Submitter, i.Created, e.Name AS Owner, status, TargetDate, Summary, v.dotsname AS product
	FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK), ProductVersion v WITH (NOLOCK), ProductFamily f WITH (NOLOCK)
	WHERE 
		([type] = 3)
	AND (v.ID = i.ProductVersionID)
	AND (f.Id = v.ProductFamilyID)
	AND (v.Division=1)
	AND (v.id = COALESCE(@ProductID,v.id))
	AND (e.id = i.ownerid)
	AND ((i.ActualDate BETWEEN COALESCE(@StartDt, GETDATE()-@Duration) AND COALESCE(@EndDt+1, GETDATE()) AND v.sustaining=0 AND v.active=1) OR (i.ActualDate is not null AND i.ECNDate between  COALESCE(@StartDt, GETDATE()-@Duration) AND COALESCE(@EndDt+1,GETDATE())  AND v.sustaining=1))
	AND ((@BiosChange IS NULL)
	 OR ((@BiosChange = 1) AND (BiosChange = @BiosChange))
	 OR ((@BiosChange = 0) AND 
		((BiosChange = 0) OR ((COALESCE(ImageChange, 0) | COALESCE(SkuChange, 0) | COALESCE(ReqChange, 0) | COALESCE(DocChange,0) | COALESCE(CommodityChange, 0) | COALESCE(OtherChange, 0) = 1 AND BiosChange = 1)))))
	ORDER BY [Product], Status, i.ID

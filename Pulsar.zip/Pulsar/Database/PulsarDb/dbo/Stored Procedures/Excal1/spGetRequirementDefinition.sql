﻿

CREATE PROCEDURE [dbo].[spGetRequirementDefinition]
 (
  @ReqID int,
  @ProdID int,
  @ProdReqID int
 )
 AS
If @ProdReqID <> 0
 SELECT pr.ID as ID, r.Name as Requirement, Specification, SpecTemplate, Deliverables, c.requiresdeliverables
 FROM Product_Requirement pr with (NOLOCK), Requirement r with (NOLOCK), Category c with (NOLOCK)
 WHERE pr.RequirementID = r.ID
 and c.ID = r.CategoryID
 and pr.ID = @ProdReqID
else
 SELECT pr.ID as ID, r.Name as Requirement, Specification, SpecTemplate, Deliverables, c.requiresdeliverables
 FROM Product_Requirement pr with (NOLOCK), Requirement r with (NOLOCK), Category c with (NOLOCK)
 WHERE pr.RequirementID = r.ID
 and r.ID = @ReqID
 and c.ID = r.CategoryID
 and pr.ProductID = @ProdID




﻿

CREATE PROCEDURE [dbo].[spGetPreinstallDeliverableProperties]
(
	@ID int
)
AS
	Select r.oscode, v.PreinstallPrepStatus, v.deliverablename as name, v.version, v.revision, v.pass, v.partnumber, v.multilanguage
	from deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK)
	where r.id = v.deliverablerootid
	and v.id = @ID


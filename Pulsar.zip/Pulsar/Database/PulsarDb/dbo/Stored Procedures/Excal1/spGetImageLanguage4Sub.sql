﻿CREATE PROCEDURE [dbo].[spGetImageLanguage4Sub]
(
	@ImageDefID int,
	@Dash varchar(5)
)
/* ************************************************************************************************
 * Purpose:		
 * Created By:	
 * Modified By:	10/14/2016 - buidi - pulling OSLanguage and OtherLanguage from new structure table
 *20/8/2018  Monica Changed to ANSI standard 
 **************************************************************************************************/
 AS
 SET NOCOUNT ON 


Select	i.ID, 
		[OSLanguage] = substring( 
			(	Select ' ' + Replace(L.Abbreviation, 'US', 'EN') AS [text()]
				From Language L WITH(NOLOCK)
				Inner Join Regions_ImgOS_Language RIOL WITH(NOLOCK) on RIOL.LanguageID = L.ID
				Where RIOL.RegionID = r.ID and RIOL.IsDefault = 1
				Order By l.Abbreviation
				For XML Path ('')
			), 2, 1000), 
		[OtherLanguage] = substring( 
			(	Select ',' + Replace(L.Abbreviation, 'US', 'EN') AS [text()]
				From Language L WITH(NOLOCK)
				Inner Join Regions_ImgOS_Language RIOL WITH(NOLOCK) on RIOL.LanguageID = L.ID
				Where RIOL.RegionID = r.ID and RIOL.IsDefault = 0
				Order By l.Abbreviation
				For XML Path ('')
			), 2, 1000)
from Images i with (NOLOCK)
 INNER JOIN imagedefinitions idef with (NOLOCK)
 ON i.imagedefinitionid = idef.id
 INNER JOIN  Regions r with (NOLOCK)
 ON r.ID = i.RegionID 
where idef.id = @ImageDefID
and r.dash = @Dash

SET NOCOUNT OFF
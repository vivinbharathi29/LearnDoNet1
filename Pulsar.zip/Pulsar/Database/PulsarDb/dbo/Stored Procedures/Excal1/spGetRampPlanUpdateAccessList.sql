﻿

CREATE PROCEDURE [dbo].[spGetRampPlanUpdateAccessList]
(
	@ProdID int
)
 AS
	--All SupplyChain
	Select distinct v.SupplyChainID as ID
	from ProductVersion v with (NOLOCK)
	union
	--se pm
	Select Distinct SEPMID as ID
	from productversion with (NOLOCK)
	where active=1
	union 
	--admins
	Select ID
	from Employee with (NOLOCK)
	where systemadmin = 1
	
	union
	--All Marketing System Team members for active products
	Select Distinct ComMarketingID as ID
	from productversion with (NOLOCK)
	where active=1
	union
	Select Distinct SMBMarketingID as ID
	from productversion with (NOLOCK)
	where active=1
	union
	Select Distinct ConsMarketingID as ID
	from productversion with (NOLOCK)
	where active=1




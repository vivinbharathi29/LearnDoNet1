﻿

CREATE PROCEDURE [dbo].[spGetExecutionEngineer]
(
	@VersionID int
)
AS


	Select e.name, e.email, e.id
	from deliverableroot r with (NOLOCK), deliverableversion v with (NOLOCK), employee e with (NOLOCK)
	where r.id = v.deliverablerootid
	and e.id = r.testerid
	and v.id = @VersionID


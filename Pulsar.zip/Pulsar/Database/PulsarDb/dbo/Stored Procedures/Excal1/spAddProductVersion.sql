﻿/**************************************************************************************************    
/* ************************************************************************************************
 * Purpose:	Based on spAddProductVersion, will be used for version of products. 
 * Created By:	N/A
 * Modified By: buidi - 11/30/2015 - save new roles
				Malichi, Jason - 04/24/2017 - BUG 124537 - Production: Add ability to enter End of Service Life and other data lost
 **************************************************************************************************/  
**************************************************************************************************    
** Change History           
**************************************************************************************************    
** SNo   Date        Author                      Description           
** --    --------   -------                     -------------------------           
 ** 1    27/12/2018  Santhana K					Changed the Text Data type to Varchar(max)
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spAddProductVersion]
 (
  @FamilyID int,
  @Version varchar(20),
   -- CG BEGIN OF CHANGE - ADD BUSINESS SEGMENT AND PRODUCT LINE
  @BusinessSegmentID int,
  @ProductLineID int,
  -- CG END OF CHANGE - ADD BUSINESS SEGMENT AND PRODUCT LINE
  @PMID int,
  @TDCCMID int,
  @SMID int,
  @SEPMID int,
  @PDEID int,
  @SCFactoryEngineerID int,
  @AccessoryPMID int,
  @ComMarketingID int,
  @ConsMarketingID int,
  @SMBMarketingID int,
  @PlatformDevelopmentID int,
  @SupplyChainID int,
  @ServiceID int,
  @QualityID int,
  @UpdateReleases tinyint,
  @Active tinyint,
  @Sustaining tinyint,
  @ProductStatusID int,
  @DivisionID int,
  @TypeID tinyint,
  @DevCenter tinyint,
  @DCRDefaultOwner int,
  @ReferenceID int,
  @PartnerID int,
  @PreinstallTeam int,
  @ReleaseTeam int,
  @Distribution varchar(1000),
  @ConveyorBuildDistribution varchar(1000),
  @ConveyorReleaseDistribution varchar(1000),
  @ActionNotifyList varchar(1000),
  @ToolAccessList varchar(1000),
  @Brands varchar(255),
  @DOTSName varchar(30),
  @RCTOSites varchar(50),
  @RegulatoryModel varchar(15),
  @EmailActive tinyint,
  @Fusion bit,
  @AllowSMR bit,
  @AllowDeliverableReleases bit,
  @AllowImageBuilds bit,
  @AllowDCR bit,
  @OnCommodityMatrix bit,
  @OnlineReports tinyint,
  @DCRAutoOpen tinyint,
  @BaseUnit varchar(2000),
  @CurrentROM varchar(200),
  @CurrentWebROM varchar(200),
  @OSSupport varchar(2000),
  @ImagePO varchar(8000),
  @ImageChanges varchar(2000),
  @SystemBoardID varchar(200),
  @SystemBoardComments varchar(1200),
  @MachinePnPID varchar(200),
  @MachinePnPComments varchar(1200),
  @CommonImages varchar(300),
  @CertificationStatus varchar(3000),
  @SWQAStatus varchar(8000),
  @PlatformStatus varchar(8000),
  @PDDPath varchar(256),
  @SCMPath varchar(256),
  @AccessoryPath varchar(256),
  @STLStatusPath varchar(256),
  @ProgramMatrixPath varchar(256),
  @Description Varchar(max),
  @Objectives Varchar(max),
  @SEPE int,
  @PINPM int,
  @SETestLead int,
  @SETestID int,
  @ODMTestLeadID int,
  @WWANTestLeadID int,
  @BIOSLead int,
  @CommHWPM int,
  @VideoMemoryPM int,
  @GraphicsControllerPM int,
  @ProcessorPM int,
  @SustainingMgrID int,
  @SustainingSEPMID int,
  @SysEngrProgramCoordinatorID int,
  @PreinstallCutoff varchar(15),
  @PCID int,
  @MarketingOpsID int,
  @ShowOnWhql bit,
  @DCRApproverList varchar(1000),
  @GPLM int,
  @SPDM int,
  @SBA int,
  @DocPM int,
  @DKCID int,
  @MinRoHSLevel int,
  @BSAMFlag bit,
  @AffectedProduct int,
  @AddDCRNotificationList bit,
  @NewID int output,
  @FinanceID int = 0,
  @ODMSEPMID int = null,
  @ProcurementPMID int = null,
  @PlanningPMID int = null,
  @ODMPIMPMID int = null,
  @WWANProduct bit,
  @CommodityLock bit,
  @ServiceLifeDate datetime
 ) 
As 

DECLARE @ProductFamilyName varchar(100)
DECLARE @v_PVID INT

SET @ProductFamilyName=(select Name from ProductFamily where ID=@FamilyID)
 

if @UpdateReleases = 0 
	 Insert ProductVersion(Fusion,DCRDefaultOwner,AllowImageBuilds,RCTOSites,SETestID,GraphicsControllerPMID,ToolAccessList,ActionNotifyList,CurrentWebRom,ODMTestLeadID, WWANTestLeadID, TypeID,AllowSMR,AllowDeliverableReleases,AllowDCR,MachinePnPComments,SystemBoardComments,ProcessorPMID,VideoMemoryPMID,CommHWPMID,BIOSLeadID,AccessoryPath,SCFactoryEngineerID, AccessoryPMID, RegulatoryModel,ProductStatusID,ReferenceID, ReleaseTeam, DevCenter, PDDPath,SCMPath,STLStatusPath,ProgramMatrixPath,OnCommodityMatrix,PartnerID,DCRAutoOpen,Brands,Active, Sustaining, BaseUnit, CurrentRom, OSSupport, ImagePO, ImageChanges, SystemBoardID, MachinePnPID,CommonImages, CertificationStatus, SWQAStatus,PlatformStatus,Division, PreinstallTeam, EmailActive,OnlineReports, Version, ProductFamilyID,Distribution,DOTSName,Cycle,PMID,TDCCMID,SMID,SEPMID,PDEID,ComMarketingID, ConsMarketingID,SMBMarketingID,PlatformDevelopmentID,SupplyChainID,ServiceID,FinanceID,Description,Objectives,SEPE, PINPM, SETestLead, SustainingMgrID, SustainingSEPMID, SysEngrProgramCoordinatorID, PreinstallCutoff, PCID, MarketingOpsID, ShowOnWhql, DCRApproverList,GPLM,SPDM,SvcBomAnalyst,ConveyorBuildDistribution,ConveyorReleaseDistribution, DocPM, DKCID, MinRoHSLevel, BSAMFlag, AffectedProduct, AddDCRNotificationList,BusinessSegmentID,ProductLineID,ProductName,QualityID,ODMSEPMID, ProcurementPMID, PlanningPMID, ODMPIMPMID,
			WWANProduct, CommodityLock, ServiceLifeDate)
	 Values (@Fusion,@DCRDefaultOwner,@AllowImageBuilds,@RCTOSites,@SETestID,@GraphicsControllerPM,@ToolAccessList,@ActionNotifyList,@CurrentWebRom,@ODMTestLeadID, @WWANTestLeadID, @TypeID,@AllowSMR,@AllowDeliverableReleases,@AllowDCR,@MachinePnPComments,@SystemBoardComments,@ProcessorPM,@VideoMemoryPM,@CommHWPM,@BIOSLead,@AccessoryPath,@SCFactoryEngineerID,@AccessoryPMID, @RegulatoryModel,@ProductStatusID,@ReferenceID,@ReleaseTeam, @DevCenter, @PDDPath,@SCMPath,@STLStatusPath,@ProgramMatrixPath,@OnCommodityMatrix,@PartnerID,@DCRAutoOpen,@Brands,@Active, @Sustaining, @BaseUnit, @CurrentROM, @OSSupport, @ImagePO, @ImageChanges, @SystemBoardID, @MachinePnPID,@CommonImages, @CertificationStatus, @SWQAStatus,@PlatformStatus,@DivisionID, @PreinstallTeam,@EmailActive,@OnlineReports, @version, @FamilyID,@Distribution,@DOTSName,'N/A',@PMID,@TDCCMID,@SMID,@SEPMID,@PDEID,@ComMarketingID, @ConsMarketingID,@SMBMarketingID,@PlatformDevelopmentID,@SupplyChainID,@ServiceID,@FinanceID,@Description,@Objectives,@SEPE,@PINPM,@SETestLead,@SustainingMgrID, @SustainingSEPMID, @SysEngrProgramCoordinatorID, @PreinstallCutoff, @PCID, @MarketingOpsID, @ShowOnWhql, @DCRApproverList,@GPLM,@SPDM,@SBA,@ConveyorBuildDistribution,@ConveyorReleaseDistribution, @DocPM, @DKCID, @MinRoHSLevel, @BSAMFlag, @AffectedProduct, @AddDCRNotificationList,@BusinessSegmentID,nullif(@ProductLineID, 0),@ProductFamilyName,@QualityID,@ODMSEPMID, @ProcurementPMID, @PlanningPMID, @ODMPIMPMID,
			 @WWANProduct, @CommodityLock, @ServiceLifeDate)
else if @UpdateReleases = 1
	 Insert ProductVersion(Fusion,DCRDefaultOwner,AllowImageBuilds,RCTOSites,SETestID,GraphicsControllerPMID,ToolAccessList,ActionNotifyList,CurrentWebRom,ODMTestLeadID, WWANTestLeadID,TypeID,AllowSMR,AllowDeliverableReleases,AllowDCR,MachinePnPComments,SystemBoardComments,ProcessorPMID,VideoMemoryPMID,CommHWPMID,BIOSLeadID,AccessoryPath,SCFactoryEngineerID,AccessoryPMID, RegulatoryModel,ProductStatusID,ReferenceID, ReleaseTeam, DevCenter, PDDPath,SCMPath,STLStatusPath,ProgramMatrixPath,OnCommodityMatrix,PartnerID,DCRAutoOpen,Brands,Active, Sustaining, PRDReleased,PDDReleased, BaseUnit, CurrentRom, OSSupport, ImagePO, ImageChanges, SystemBoardID, MachinePnPID,CommonImages, CertificationStatus, SWQAStatus,PlatformStatus,Division,PreinstallTeam, EmailActive,OnlineReports, Version, ProductFamilyID,Distribution,DOTSName,Cycle,PMID,TDCCMID,SMID,SEPMID,PDEID,ComMarketingID, ConsMarketingID,SMBMarketingID,PlatformDevelopmentID,SupplyChainID,ServiceID,FinanceID,Description,Objectives,SEPE, PINPM, SETestLead, SustainingMgrID,SustainingSEPMID, SysEngrProgramCoordinatorID, PreinstallCutoff, PCID, MarketingOpsID, ShowOnWhql, DCRApproverList,GPLM,SPDM,SvcBomAnalyst,ConveyorBuildDistribution,ConveyorReleaseDistribution, DocPM, DKCID, MinRoHSLevel, BSAMFlag, AffectedProduct, AddDCRNotificationList,BusinessSegmentID,ProductLineID,ProductName,QualityID,ODMSEPMID, ProcurementPMID, PlanningPMID, ODMPIMPMID,
			WWANProduct, CommodityLock, ServiceLifeDate)
	 Values (@Fusion,@DCRDefaultOwner,@AllowImageBuilds,@RCTOSites,@SETestID,@GraphicsControllerPM,@ToolAccessList,@ActionNotifyList,@CurrentWebRom,@ODMTestLeadID, @WWANTestLeadID,@TypeID,@AllowSMR,@AllowDeliverableReleases,@AllowDCR,@MachinePnPComments,@SystemBoardComments,@ProcessorPM,@VideoMemoryPM,@CommHWPM,@BIOSLead,@AccessoryPath,@SCFactoryEngineerID,@AccessoryPMID, @RegulatoryModel,@ProductStatusID,@ReferenceID, @ReleaseTeam, @DevCenter, @PDDPath,@SCMPath,@STLStatusPath,@ProgramMatrixPath,@OnCommodityMatrix,@PartnerID,@DCRAutoOpen,@Brands,@Active, @Sustaining, GetDate(),GetDate(), @BaseUnit, @CurrentROM, @OSSupport, @ImagePO, @ImageChanges, @SystemBoardID, @MachinePnPID,@CommonImages, @CertificationStatus, @SWQAStatus,@PlatformStatus,@DivisionID, @PreinstallTeam, @EmailActive,@OnlineReports, @version, @FamilyID,@Distribution,@DOTSName,'N/A',@PMID,@TDCCMID,@SMID,@SEPMID,@PDEID,@ComMarketingID, @ConsMarketingID,@SMBMarketingID,@PlatformDevelopmentID,@SupplyChainID,@ServiceID,@FinanceID,@Description,@Objectives,@SEPE,@PINPM,@SETestLead,@SustainingMgrID,@SustainingSEPMID,@SysEngrProgramCoordinatorID, @PreinstallCutoff, @PCID, @MarketingOpsID, @ShowOnWhql, @DCRApproverList,@GPLM,@SPDM,@SBA,@ConveyorBuildDistribution,@ConveyorReleaseDistribution, @DocPM, @DKCID, @MinRoHSLevel, @BSAMFlag, @AffectedProduct, @AddDCRNotificationList,@BusinessSegmentID,nullif(@ProductLineID, 0),@ProductFamilyName,@QualityID,@ODMSEPMID, @ProcurementPMID, @PlanningPMID, @ODMPIMPMID,
			 @WWANProduct, @CommodityLock, @ServiceLifeDate)
else if @UpdateReleases = 2
	 Insert ProductVersion(Fusion,DCRDefaultOwner,AllowImageBuilds,RCTOSites,SETestID,GraphicsControllerPMID,ToolAccessList,ActionNotifyList,CurrentWebRom,ODMTestLeadID, WWANTestLeadID,TypeID,AllowSMR,AllowDeliverableReleases,AllowDCR,MachinePnPComments,SystemBoardComments,ProcessorPMID,VideoMemoryPMID,CommHWPMID,BIOSLeadID,AccessoryPath,SCFactoryEngineerID,AccessoryPMID, RegulatoryModel,ProductStatusID,ReferenceID, ReleaseTeam, DevCenter, PDDPath,SCMPath,STLStatusPath,ProgramMatrixPath,OnCommodityMatrix,PartnerID,DCRAutoOpen,Brands,Active, Sustaining, PRDReleased,PDDReleased, BaseUnit, CurrentRom, OSSupport, ImagePO, ImageChanges, SystemBoardID, MachinePnPID,CommonImages, CertificationStatus, SWQAStatus,PlatformStatus,Division, PreinstallTeam, EmailActive,OnlineReports, Version, ProductFamilyID,Distribution,DOTSName,Cycle,PMID,TDCCMID,SMID,SEPMID,PDEID,ComMarketingID, ConsMarketingID,SMBMarketingID,PlatformDevelopmentID,SupplyChainID,ServiceID,FinanceID,Description,Objectives,SEPE, PINPM, SETestLead, SustainingMgrID,SustainingSEPMID, SysEngrProgramCoordinatorID, PreinstallCutoff, PCID, MarketingOpsID, ShowOnWhql, DCRApproverList,GPLM,SPDM,SvcBomAnalyst,ConveyorBuildDistribution,ConveyorReleaseDistribution, DocPM, DKCID, MinRoHSLevel, BSAMFlag, AffectedProduct, AddDCRNotificationList,BusinessSegmentID,ProductLineID,ProductName,QualityID,ODMSEPMID, ProcurementPMID, PlanningPMID, ODMPIMPMID,
			WWANProduct, CommodityLock, ServiceLifeDate)
	 Values (@Fusion,@DCRDefaultOwner,@AllowImageBuilds,@RCTOSites,@SETestID,@GraphicsControllerPM,@ToolAccessList,@ActionNotifyList,@CurrentWebRom,@ODMTestLeadID, @WWANTestLeadID,@TypeID,@AllowSMR,@AllowDeliverableReleases,@AllowDCR,@MachinePnPComments,@SystemBoardComments,@ProcessorPM,@VideoMemoryPM,@CommHWPM,@BIOSLead,@AccessoryPath,@SCFactoryEngineerID,@AccessoryPMID, @RegulatoryModel,@ProductStatusID,@ReferenceID, @ReleaseTeam, @DevCenter, @PDDPath,@SCMPath,@STLStatusPath,@ProgramMatrixPath,@OnCommodityMatrix,@PartnerID, @DCRAutoOpen,@Brands,@Active, @Sustaining, null,null, @BaseUnit, @CurrentROM, @OSSupport, @ImagePO, @ImageChanges, @SystemBoardID, @MachinePnPID,@CommonImages, @CertificationStatus, @SWQAStatus,@PlatformStatus,@DivisionID, @PreinstallTeam, @EmailActive,@OnlineReports, @version, @FamilyID,@Distribution,@DOTSName,'N/A',@PMID,@TDCCMID,@SMID,@SEPMID,@PDEID,@ComMarketingID, @ConsMarketingID,@SMBMarketingID,@PlatformDevelopmentID,@SupplyChainID,@ServiceID,@FinanceID,@Description,@Objectives,@SEPE,@PINPM,@SETestLead,@SustainingMgrID,@SustainingSEPMID, @SysEngrProgramCoordinatorID, @PreinstallCutoff, @PCID, @MarketingOpsID, @ShowOnWhql, @DCRApproverList,@GPLM,@SPDM,@SBA,@ConveyorBuildDistribution,@ConveyorReleaseDistribution, @DocPM, @DKCID, @MinRoHSLevel, @BSAMFlag, @AffectedProduct, @AddDCRNotificationList,@BusinessSegmentID,nullif(@ProductLineID, 0),@ProductFamilyName,@QualityID,@ODMSEPMID, @ProcurementPMID, @PlanningPMID, @ODMPIMPMID,
	         @WWANProduct, @CommodityLock, @ServiceLifeDate)

SET @v_PVID = SCOPE_IDENTITY()

if @CommodityLock = 1 -- Mark all versions with no DCRStatus as POR
	Update product_deliverable
	set dcrid = 1
	where productversionid = @v_PVID
	and deliverableversionid in (
				Select v.id
				from deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK), deliverablecategory c with (NOLOCK), product_Deliverable pd with (NOLOCK)
				where v.deliverablerootid = r.id
				and c.id = r.categoryid
				and c.commodity=1
				and pd.deliverableversionid = v.id
				and pd.productversionid = @v_PVID
				and pd.dcrid = 0
				)

Select @NewID = @v_PVID

return
GO



﻿CREATE PROCEDURE [dbo].[spGetProductDeliverableSummaryByID]
/***********************************************************************************************************
Purpose: New Component Requests on Today Page Section 
			Developer reject product requested for the version
Created By: 
Modified By: Dien Bui 7/14/2017 - display for Pulsar product and legacy product
			Shraddha 7/25/2017 - remove the fusionrequirements <> 1 condition when @ProductDeliverableReleaseID = 0, so that other pop ups using the same stored procedure will work
***********************************************************************************************************/
(
	@ID int, --Product DeliverableID
	@ProductDeliverableReleaseID int = 0
)
AS
	if @ProductDeliverableReleaseID = 0
	begin
		Select pd.id as ID, p.id as ProductID, v.tts, pd.DeveloperTestStatus, pd.DeveloperSignoff, pd.wwanteststatus, pd.odmteststatus, pd.integrationteststatus, r.typeid, v.id as DeliverableID, p.dotsname as Product, v.deliverablename as Deliverable, v.version, v.revision, v.pass, v.partnumber, v.modelnumber, vd.name as Vendor, pd.DeveloperTestNotes
		from product_deliverable pd with (NOLOCK) inner join
		productversion p with (NOLOCK) on pd.productversionid = p.id inner join
		deliverableversion v with (NOLOCK) on pd.deliverableversionid= v.id inner join
		vendor vd with (NOLOCK) on v.vendorid = vd.id inner join
		deliverableroot r with (NOLOCK) on r.id = v.deliverablerootid
		where pd.id = @ID 
	end
	else 
	begin
		Select pd.id as ID, p.id as ProductID, v.tts, pdr.DeveloperTestStatus, pdr.DeveloperSignoff, pdr.wwanteststatus, pdr.odmteststatus, pdr.integrationteststatus, r.typeid, v.id as DeliverableID, p.dotsname + ' (' + pvr.Name + ')' as Product, v.deliverablename as Deliverable, v.version, v.revision, v.pass, v.partnumber, v.modelnumber, vd.name as Vendor, pdr.DeveloperTestNotes
		from product_deliverable pd with (NOLOCK) inner join
		productversion p with (NOLOCK) on pd.productversionid = p.id inner join
		deliverableversion v with (NOLOCK) on pd.deliverableversionid= v.id inner join
		vendor vd with (NOLOCK) on v.vendorid = vd.id inner join
		deliverableroot r with (NOLOCK) on r.id = v.deliverablerootid inner join 
		Product_Deliverable_Release pdr with (NOLOCK) on pdr.ProductDeliverableID = pd.ID inner join
		ProductVersionRelease pvr with (NOLOCK) on pvr.ID = pdr.ReleaseID
		where pd.id = @ID and p.FusionRequirements = 1
	end
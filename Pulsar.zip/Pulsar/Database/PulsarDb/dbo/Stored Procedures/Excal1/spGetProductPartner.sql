﻿

CREATE PROCEDURE [dbo].[spGetProductPartner]
(
	@ProdID int = 0,
	@ImageID int =0
)
AS

If @ProdID=0
	select v.PartnerID
	from productversion v with (NOLOCK), images i with (NOLOCK) , imagedefinitions d with (NOLOCK)
	where v.id = d.productversionid
	and d.id = i.imagedefinitionid
	and i.id = @ImageID
	
else
	Select PartnerID
	from productversion with (NOLOCK)
	where id = @ProdID



﻿

CREATE PROCEDURE [dbo].[spCopyRequirement]
(
	@productID int,
	@RequirementID int,
	@CopyDel bit = 0
)
 AS
Declare @NewID int
Begin transaction
Insert Product_Requirement (ProductID,RequirementID, Specification, Deliverables, DeliverablesSaved, CopyProductID)
Select @ProductID, RequirementID, Specification, Deliverables, DeliverablesSaved, ProductID from Product_Requirement with (NOLOCK) where ID = @RequirementID
Select @NewID = SCOPE_IDENTITY()
if @CopyDel <> 0
	Begin
	
		Declare @DelID int
		Declare @Preinstall bit
		Declare @Preload bit
		Declare @Web bit
		Declare @DropInBox bit
		Declare @SelectiveRestore bit
		Declare @ARCD bit
		Declare @DRDVD bit
		Declare @RACD_Americas bit
		Declare @RACD_APD bit
		Declare @RACD_EMEA bit
		Declare @OSCD bit
		Declare @DocCD bit

		DECLARE Del_CURSOR CURSOR FOR  	SELECT Distinct pd.DeliverableRootID, pd.Preinstall, pd.Preload, pd.Web, pd.DropInBox, pd.SelectiveRestore, pd.ARCD, pd.DRDVD,pd.RACD_Americas,pd.RACD_APD,pd.RACD_EMEA,pd.OSCD,pd.DocCD
							FROM ProdReq_DelRoot pr with (NOLOCK), Product_DelRoot pd with (NOLOCK), product_requirement r with (NOLOCK)
							Where ProductRequirementID = @RequirementID
							and pd.ProductVersionID = r.productid
     							and pr.deliverablerootid = pd.deliverablerootid
							and r.id = pr.productrequirementid
		OPEN Del_Cursor
		FETCH NEXT FROM Del_Cursor Into @DelID, @Preinstall, @Preload, @Web, @DropInBox, @SelectiveRestore, @ARCD,@DRDVD,@RACD_Americas,@RACD_APD,@RACD_EMEA,@OSCD,@DocCD
		WHILE (@@fetch_status <> -1)
			 BEGIN
				 If (@@fetch_status <> -2)
					  BEGIN
						 exec spAddDelRoot2ProductReq @NewID, @ProductID, @DelID, @Preinstall, @Preload, @DropInBox, @Web, @SelectiveRestore, @ARCD,@DRDVD,@RACD_Americas,@RACD_APD,@RACD_EMEA,@OSCD,@DocCD
					  END
				 FETCH NEXT FROM Del_Cursor Into  @DelID, @Preinstall, @Preload, @Web, @DropInBox, @SelectiveRestore, @ARCD,@DRDVD,@RACD_Americas,@RACD_APD,@RACD_EMEA,@OSCD,@DocCD
			 END
		DEALLOCATE Del_Cursor
	
	end
commit transaction



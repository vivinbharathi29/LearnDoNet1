﻿

CREATE PROCEDURE [dbo].[spListCountries4Product] 

(
	@ProdID int
)

AS

Select l.Language as Country, p.ID, P.ProductversionID as prodID, l.ID as CountryID, l.region as Region, p.localizations
from Language l with (NOLOCK), Product_Country p with (NOLOCK)
where p.countryID = l.id
and l.IsLanguage = 0
and l.active=1
and p.Productversionid = @ProdID
order by l.region desc, l.Language asc



﻿

CREATE PROCEDURE [dbo].[spGetDelRoot] AS
Select ID,Name,CategoryID as CatID
From deliverableroot with (NOLOCK)
where active=1
order by name;




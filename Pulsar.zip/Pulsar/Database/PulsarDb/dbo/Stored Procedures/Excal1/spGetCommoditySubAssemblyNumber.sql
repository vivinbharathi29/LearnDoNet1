﻿

CREATE PROCEDURE [dbo].[spGetCommoditySubAssemblyNumber]

(
	@ProductID int,
	@RootID int
)
 AS

if @ProductID=0
	Select 0 as ID, '' as Product, 0 as ProductID, r.id as RootID, r.name as Deliverable, '' as Spin, '' as subassembly
	from Deliverableroot r WITH (NOLOCK)
	where r.id=@RootID
else
	Select pd.id, v.dotsname as Product, v.id as ProductID, r.id as RootID, r.name as Deliverable, pd.Spin, pd.base as subassembly, pd.ServiceSpin, pd.Servicebase as Servicesubassembly
	from product_delroot pd WITH (NOLOCK), productversion v WITH (NOLOCK), productfamily f WITH (NOLOCK), Deliverableroot r WITH (NOLOCK)
	where f.id=v.productfamilyid
	and v.id = pd.productversionid
	and r.id = pd.deliverablerootid
	and pd.DeliverableRootid=@RootID
	and pd.ProductVersionid=@ProductID

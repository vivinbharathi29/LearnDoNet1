﻿

CREATE PROCEDURE [dbo].[spGetHFCNDeliverables] 
AS
Select r.Name, r.ID, r.CategoryID, r.DevManagerID, r.VendorID, r.Description, v.Name as Vendor, c.Name as Category, e.name as DevManager
FROM DeliverableRoot r with (NOLOCK), Vendor v with (NOLOCK), deliverablecategory c with (NOLOCK), Employee e with (NOLOCK)
Where RootFilename='HFCN'
and v.id = r.vendorid
and c.ID = r.CategoryID
and e.id = r.DevManagerID
Order By r.Name




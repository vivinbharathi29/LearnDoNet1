﻿
CREATE PROCEDURE [dbo].[spGetOTSComponentCount]
(
	@ProductID int
)
AS

/* ****************************************************************************************************
 *     Purpose:	query the count and the missing count of OTS components in one product.	
 *  Created By:	unknown
 * Modified By:	03/24/2016 Herb - add Pulsar product's OTS count (exclude generic components) - PBI 18288 
 *              
 *              
 ******************************************************************************************************/

 
DECLARE @Excalibur int;
DECLARE @ExcaliburMissing int;
DECLARE @ProductName varchar(120);
DECLARE @isPulsar BIT;

SELECT
	@ProductName = Dotsname,
	@isPulsar = ISNULL(FusionRequirements,0)
FROM productversion WITH (NOLOCK)
WHERE ID = @ProductID;


SELECT
	@Excalibur = COUNT(1)
FROM Product_OTSComponent WITH (NOLOCK)
WHERE productversionid = @ProductID;


IF @isPulsar = 1
BEGIN

	SELECT
		@ExcaliburMissing = COUNT(1)
	FROM OTSComponent WITH (NOLOCK)
	WHERE 
		ID NOT IN (9, 20, 30, 33, 48, 49)
		AND ID NOT IN (
					SELECT
						OTSComponentID
					FROM Product_OTSComponent WITH (NOLOCK)
					WHERE productversionid = @ProductID
					)
		AND active = 1;

END;
ELSE
BEGIN

	SELECT
		@ExcaliburMissing = COUNT(1)
	FROM OTSComponent WITH (NOLOCK)
	WHERE ID NOT IN (
					SELECT
						OTSComponentID
					FROM Product_OTSComponent WITH (NOLOCK)
					WHERE productversionid = @ProductID
					)
		AND active = 1;

END;

SELECT
	@Excalibur AS Excalibur,
	@ExcaliburMissing AS ExcaliburMissing,
	@ProductName AS ProductName;



﻿
CREATE PROCEDURE [dbo].[spGetDefaultProductFilter]

(
	@EmployeeID int,
	@UserSettingsID int
)

 AS

	Select EmployeeID, UserSettingsID, Setting
	from Employee_UserSettings with (NOLOCK)
	Where EmployeeID = @EmployeeID
	and UserSettingsID = @UserSettingsID


﻿

/****** Object:  Stored Procedure dbo.spCopyPlatform    Script Date: 9/26/00 7:13:23 PM ******/
CREATE PROCEDURE [dbo].[spCopyPlatform]
 (
  @ID int,
  @Name varchar(100),
  @NewID Int OUTPUT
 )
As
/*
 begin transaction
 
 INSERT Platform(Name,Description,Published, PDDReleased)
  SELECT @Name, Description,Null,Null
  FROM Platform WITH (NOLOCK)
  WHERE ID = @ID
 /*Values (@Name,@Description,Null) */
 SELECT @NewID = (SELECT ID
                                          FROM Platform  WITH (NOLOCK)
         WHERE Name = @Name 
              ) 
  
 INSERT Platform_Requirement
  SELECT @NewID, RequirementID, @ID, Specification, SpecSaved, Deliverables, DeliverablesSaved
                        FROM Platform_Requirement WITH (NOLOCK)
                        WHERE PlatformID = @ID 
 commit transaction
*/
 return


﻿

CREATE PROCEDURE [dbo].[spGetReportProfileShared]
(
	@ID int,
	@EmployeeID int = null
)
 AS

Select p.*,s.ID as SharingID, s.CanEdit,s.CanDelete,e.name as SharedEmployeeName , e.id as SharedEmployeeID, o.name as PrimaryOwner
from reportprofiles p with (NOLOCK), reportprofilesshared s with (NOLOCK), employee e with (NOLOCK), employee o with (NOLOCK)
where p.id = s.reportprofileid
and p.ID=@ID
and s.EmployeeID = COALESCE(@EmployeeID, s.EmployeeID)
and e.id = s.employeeid
and o.id = p.employeeid






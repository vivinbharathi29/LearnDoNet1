﻿CREATE PROCEDURE [dbo].[spAddBrand2Product]

(
	@ProdID int,
	@BrandID int,	
	@SeriesSummary varchar(2000),
	@ProductBrandID int output
)
 AS

 IF EXISTS (SELECT 1 FROM Product_Brand WHERE ProductVersionID = @ProdID AND BrandID = @BrandID)
 BEGIN
	SELECT @ProductBrandID = ID FROM Product_Brand WHERE ProductVersionID = @ProdID AND BrandID = @BrandID
	RETURN ;
 END
 
Insert Product_Brand(Productversionid, BrandID,SeriesSummary,ShowPhWebActionItems)
Values(@ProdID, @BrandID,@SeriesSummary, 1)

Select @ProductBrandID = SCOPE_IDENTITY();


﻿/*
* Purpose: Return information about the user
*/
CREATE PROCEDURE [dbo].[spGetUserInfo]
(
	@userName varchar(80),
	@Domain varchar(30)='',
	@updateLastActivity bit =0
)
AS 

DECLARE @altuserName varchar(30),
		@altDomain varchar(30),
		@id int,
		@altId int,
		@PhWebImpersonate int,
		@IRSUserId int,
		@originalName varchar(200),
		@vUserName varchar(80),
		@OriginalUserId int,
		@Favorites VARCHAR(MAX) = '',
		@FavCount SMALLINT = 0

SET NOCOUNT ON 



--SET @originalID=@id --keep the original userid coming from params
SET @vUserName = @userName --the sp run faster if we assign parameter with a variable

--move orginal name to another query where userid is login user
--reset @Domain value so at least when updating irs table it doesn's send garbage
--Bug 17236:User sees 3 Today Page screens when logging in
--user frist login from pulsar we pass in username and domain, if we change our domain name the query below still return user record
--however the query in mvc can not find record cause the ui to display multiple, to fix the issue we need to add NTDomain to the query below
SELECT @id=UserID,
@PhWebImpersonate=PhWebImpersonate,
@Domain=ISNULL(NtDomain,''),
@IRSUserID=IRSUserID,
@originalName = FirstName + ' ' + LastName,@OriginalUserId=UserID 
from UserInfo  WITH (NOLOCK)
where  (NTDomain = ISNULL(@Domain,'') or ISNULL(@Domain,'') = '')
AND  ([Disabled] IS NULL OR IsActiveInGAL=1) 
AND (NTName=@vUserName OR Email = @vUserName) 


--Lookup to see if we are impersonating anyone
--also getting login user full name for pulsar page header @originalName incase of personating
Select @altuserName = e2.NTName,
 @altDomain=ISNULL(e2.NtDomain,''),
  @altId=e2.UserID
from UserInfo e WITH (NOLOCK) 
INNER JOIN UserInfo e2 WITH (NOLOCK)
ON e.impersonateid = e2.UserID
AND e.UserID=@id

/* get impersonated user */
if @altUserName is not null  
	SELECT @vUserName = @altUserName, @Domain=ISNULL(@altDomain,''), @id=@altId	 
ELSE  --set all ids with the current user id to avoid issues with dirty records
	SET @PhWebImpersonate=@id

/*	Show Today Page Section - PMID = Congifuration Manager, TDCCMID = Program Office Manager, SCMOwnerID = SCM Owner
	Congifuration Manager's permission ('Feature.Edit', 'SCMExport.Edit', 'PRL.Edit', 'SharedAV.Edit')
	Program Office Manager's permission ('Feature.Edit', 'PRL.Edit', 'FeatureCategory.Edit', 'FeatureChinaGPIdentifier.Edit')
	SCM Owner's permission: ('Feature.Edit', 'SCMExport.Edit', 'PRL.Edit', 'SharedAV.Edit', 'ODMBOMVisibility.Edit', 'ManufacturingSites.Edit', 'SharedAVProductLine.Edit', 'ABTBusinessSegment.Edit')
	Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/

DECLARE  @CMProductCount int;

IF Object_id('tempdb..#CTE_Permission') IS NOT NULL DROP TABLE #CTE_Permission


select rm.UserId,p.Name
INTO  #CTE_Permission
	from Permission p WITH (NOLOCK)
		INNER JOIN Role_Object_Permission rop  WITH (NOLOCK)
		on rop.PermissionId = p.PermissionId
		INNER JOIN RoleMembers rm  WITH (NOLOCK)
		on rm.RoleId = rop.RoleId
	where rm.UserId = @id


	CREATE CLUSTERED INDEX IDX_Name_CTE_Permission ON #CTE_Permission(Name)

	SELECT ComMarketingID,SMBMarketingID,ConsMarketingID,MarketingOpsID,ad.CPLBlindDt, ad.RASDiscontinueDt, ad.FeatureCategoryID,ad.SCMCategoryID
	INTO #avdetail
	FROM     dbo.AvDetail AS ad WITH (NOLOCK) INNER JOIN
			 dbo.AvDetail_ProductBrand AS adpb WITH (NOLOCK) ON ad.AvDetailID = adpb.AvDetailID INNER JOIN
			 dbo.Product_Brand AS pb WITH (NOLOCK) ON adpb.ProductBrandID = pb.ID INNER JOIN
			 dbo.ProductVersion pv WITH (NOLOCK) ON pb.ProductVersionID = pv.ID 
			 WHERE  (pv.ComMarketingID =@id AND pv.ComMarketingID <>0)	
			 OR  (pv.SMBMarketingID =@id AND pv.SMBMarketingID <>0)	
			 OR  (pv.ConsMarketingID =@id AND pv.ConsMarketingID <>0)		
			  OR  (pv.MarketingOpsID IN ( @id,@PhWebImpersonate) AND pv.MarketingOpsID <>0)	

	
SELECT @CMProductCount = Max(thecount) 
from (
	SELECT thecount = COUNT(1) 
	FROM ProductVersion v WITH (NOLOCK)
	WHERE (v.PMID = @id or v.TDCCMID = @id or v.SCMOwnerID = @id) -- SCM Owner System role has the same permission as Configuration Manager(PMID)
	AND v.productstatusid < 4
	AND typeid= 1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('Feature.Edit', 'SCMExport.Edit', 'PRL.Edit', 'SharedAV.Edit', 'FeatureCategory.Edit', 'FeatureChinaGPIdentifier.Edit', 'ODMBOMVisibility.Edit', 'ManufacturingSites.Edit', 'SharedAVProductLine.Edit', 'ABTBusinessSegment.Edit')
) q1

/* Program Coordinator 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @PCProductCount INT
SELECT @PCProductCount = Max(thecount)
from (
	SELECT thecount = COUNT(1) 
FROM ProductVersion v WITH (NOLOCK)
	WHERE (v.PCID = @id or v.EngineeringDataManagementID = @id)
AND v.productstatusid < 4
AND typeid= 1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('Feature.Edit', 'SCMExport.Edit', 'PRL.Edit', 'SharedAV.Edit', 'FeatureCategory.Edit', 'FeatureChinaGPIdentifier.Edit', 'ODMBOMVisibility.Edit', 'ManufacturingSites.Edit', 'SharedAVProductLine.Edit', 'ABTBusinessSegment.Edit')
) q1


/* MarketingOpsID = ? - missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @PhWebProductCount INT

SELECT @PhWebProductCount = COUNT(1) 
FROM ProductVersion v WITH (NOLOCK)
WHERE v.MarketingOpsID = @id
AND v.productstatusid < 4
AND typeid= 1

/* Marketing / Product Mgmt 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @MarketingProductCount INT
SELECT @MarketingProductCount = Max(thecount)
from (
	SELECT thecount = COUNT(1) 
FROM  ProductVersion v WITH (NOLOCK)
WHERE (v.ComMarketingID = @id or v.ConsMarketingID = @id)
AND v.productstatusid < 4
AND typeid= 1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('Feature.Edit', 'PRL.Edit', 'FeatureCategory.Edit', 'FeatureChinaGPIdentifier.Edit', 'SCMExport.Edit', 'PRL.MarketingSignoff', 'LifecycleDateManagement.Edit')
) q1

/* SEPMID = Systems Engineering PM, SysEngrProgramCoordinatorID = Systems Engineering PC, ODMSEPMID = ODM System Engineering PM 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @SEPMProducts int
SELECT @SEPMProducts = Max(thecount)
from (
	Select thecount = Count(1) 
FROM  ProductVersion v WITH (NOLOCK)
where (v.SEPMID = @id or v.SysEngrProgramCoordinatorID  = @id or v.ODMSEPMID = @id)
and v.productstatusid < 4
and typeid= 1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('InstallOption.Edit', 'Feature.Edit', 'PRL.Edit', 'Schedule.Edit')
) q1

/* SMID = System Manager - missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @SMProducts int
SELECT @SMProducts = Max(thecount)
from (
	Select thecount = Count(1) 
FROM ProductVersion v WITH (NOLOCK)
where v.SMID = @id
and v.productstatusid < 4
and typeid= 1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('N/A')
) q1

/* WWANTestLeadID = WWAN Test Lead - missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @TestLeadAssignments int
SELECT @TestLeadAssignments = Max(thecount)
from (
	Select thecount = Count(1) 
FROM  ProductVersion v WITH (NOLOCK)
where (v.WWANTestLeadID = @id or v.ODMTestLeadID = @id or v.seTestLead = @id )
and v.productstatusid < 5
and typeid= 1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('N/A')
) q1

/* SEPMID = Systems Engineering PM with devcenter = 2 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @ConsumerSEPMProducts int
SELECT @ConsumerSEPMProducts = Max(thecount)
from (
	Select thecount = Count(1) 
FROM ProductVersion v WITH (NOLOCK)
where v.SEPMID =@id
and v.productstatusid < 4
and v.devcenter=2
and typeid= 1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('InstallOption.Edit', 'Feature.Edit', 'PRL.Edit')
) q1

/* ServiceID = Service - missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @ServiceProducts int
SELECT @ServiceProducts = Max(thecount)
from (
	Select thecount = Count(1) 
FROM  ProductVersion v WITH (NOLOCK)
where v.ServiceID = @id
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('N/A')
) q1

/* PlatformDevelopmentID = Platform Development PM 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @HWProducts int
SELECT @HWProducts = Max(thecount)
from (
	Select thecount = Count(1) 
FROM  ProductVersion v WITH (NOLOCK)
where v.PlatformDevelopmentID = @id
and v.productstatusid < 5
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('Feature.Edit', 'PRL.Edit')
) q1


/* Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any  */
DECLARE  @AVsMissingCommMarketingData int -- if either query is a 1, then return 1
SELECT @AVsMissingCommMarketingData = Max(thecount)
from (
	SELECT   thecount = COUNT(1)
	FROM  #avdetail ad
		INNER JOIN	 dbo.AvFeatureCategory afc WITH (NOLOCK) ON ad.FeatureCategoryID = afc.AvFeatureCategoryID
	WHERE   (ad.CPLBlindDt IS NULL OR ad.RASDiscontinueDt IS NULL)
		AND ad.ComMarketingID=@id
		and ad.ComMarketingID <> 0
	UNION
	SELECT   CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	FROM   #avdetail ad
			INNER JOIN dbo.SCMCategory s WITH (NOLOCK) ON ad.SCMCategoryID = s.SCMCategoryID
	WHERE   (ad.CPLBlindDt IS NULL OR ad.RASDiscontinueDt IS NULL)
		AND ad.ComMarketingID =@id
		and ad.ComMarketingID <> 0
) q1

/* Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any  */
DECLARE  @AVsMissingSMBMarketingData int
SELECT   @AVsMissingSMBMarketingData = Max(thecount)
from (
	SELECT   thecount = COUNT(1)  
	FROM      #avdetail ad 
		 INNER JOIN	 dbo.AvFeatureCategory afc WITH (NOLOCK) ON ad.FeatureCategoryID = afc.AvFeatureCategoryID
	WHERE   (ad.CPLBlindDt IS NULL OR ad.RASDiscontinueDt IS NULL)
		AND ad.SMBMarketingID=@id
		AND      ad.SMBMarketingID <> 0
	UNION
	SELECT   CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	 	FROM      #avdetail ad 

		INNER JOIN 	 dbo.SCMCategory s WITH (NOLOCK) ON ad.SCMCategoryID = s.SCMCategoryID
	WHERE   (ad.CPLBlindDt IS NULL OR ad.RASDiscontinueDt IS NULL)
		AND ad.SMBMarketingID =@id
		AND      ad.SMBMarketingID <> 0
) q1

/* Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any  */
DECLARE  @AVsMissingConsMarketingData int
SELECT   @AVsMissingConsMarketingData = Max(thecount)
from (
	SELECT   thecount = COUNT(1)
	FROM    #avdetail ad 
		INNER JOIN 	 dbo.AvFeatureCategory afc WITH (NOLOCK)ON ad.FeatureCategoryID = afc.AvFeatureCategoryID
	WHERE   (ad.CPLBlindDt IS NULL OR ad.RASDiscontinueDt IS NULL)
		AND ad.ConsMarketingID=@id
		AND      ad.ConsMarketingID <> 0
	UNION
	SELECT   CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	FROM    #avdetail ad 
		INNER JOIN 	 dbo.SCMCategory s WITH (NOLOCK)ON ad.SCMCategoryID = s.SCMCategoryID
	WHERE   (ad.CPLBlindDt IS NULL OR ad.RASDiscontinueDt IS NULL)
		AND ad.ConsMarketingID =@id
		AND      ad.ConsMarketingID <> 0
) q1

/* Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any  */
DECLARE  @PDMUser int -- if either query is a 1, then return 1
SELECT @PDMUser = Max(thecount)
from (
	SELECT   thecount = COUNT(1)  
	FROM    #avdetail ad  
		INNER JOIN 	 dbo.AvFeatureCategory AS afc WITH (NOLOCK) ON ad.FeatureCategoryID = afc.AvFeatureCategoryID
	WHERE   ad.MarketingOpsID IN ( @id,@PhWebImpersonate)
		AND ad.MarketingOpsID <> 0
	UNION
	SELECT   CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	FROM     #avdetail ad 
		INNER JOIN 	 dbo.SCMCategory AS s WITH (NOLOCK) ON ad.SCMCategoryID = s.SCMCategoryID
	WHERE    ad.MarketingOpsID IN ( @id,@PhWebImpersonate)
		AND ad.MarketingOpsID <> 0
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from Permission p
		inner join Role_Object_Permission rop on rop.PermissionId = p.PermissionId
		inner join RoleMembers rm on rm.RoleId = rop.RoleId
	where rm.UserId IN ( @id, @PhWebImpersonate)
		and p.Name in ('Feature.Edit', 'PRL.Edit', 'FeatureCategory.Edit', 'FeatureChinaGPIdentifier.Edit', 'SCMExport.Edit', 'PRL.MarketingSignoff')
) q1
/* Program Coordination 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE  @PCAdmin int
SELECT @PCAdmin = Max(thecount)
from (
	SELECT	thecount = COUNT(1)  
	FROM    Employee_Role r WITH (NOLOCK)
WHERE   r.EmployeeId=@id 
	AND     r.RoleId = 46
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('ABTBusinessSegment.Edit','ODMBOMVisibility.Edit', 'Feature.Edit', 'ManufacturingSites.Edit', 'PRL.Edit', 'SCMExport.Edit')
) q1

/* Configuration Manager 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE  @CMAdmin int
SELECT @CMAdmin = Max(thecount)
from (
	SELECT   thecount = COUNT(1)  
	FROM     Employee_Role r WITH (NOLOCK)
	WHERE    r.EmployeeId=@id 
AND      r.RoleId = 47
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('ABTBusinessSegment.Edit','ODMBOMVisibility.Edit', 'Feature.Edit', 'ManufacturingSites.Edit', 'PRL.Edit', 'SCMExport.Edit', 'SharedAV.Edit')
) q1

/* RoleId = 48 = Switch PhWeb Admin -- missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE  @PDMAdmin int
SELECT @PDMAdmin = Max(thecount)
from (
	SELECT   thecount = COUNT(1)   
FROM    Employee_Role r WITH (NOLOCK)
WHERE     r.EmployeeId=@id 
AND      r.RoleId = 48
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('N/A')
) q1


/* RoleId = 49 = Switch Marketing Admin -- missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE  @MKTAdmin int
SELECT @MKTAdmin = Max(thecount)
from (
	SELECT   thecount = COUNT(1)   
	FROM    Employee_Role r WITH (NOLOCK)
	WHERE     r.EmployeeId=@id 
AND      r.RoleId = 49
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('Feature.Edit', 'PRL.Edit', 'FeatureCategory.Edit', 'FeatureChinaGPIdentifier.Edit', 'SCMExport.Edit', 'PRL.MarketingSignoff')
) q1

/* RoleId = 51 = Commodity Subassembly Admin -- missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE  @SAAdmin int
SELECT @SAAdmin = max(thecount)
from (
	SELECT   thecount = COUNT(1)   
FROM    Employee_Role r WITH (NOLOCK)
WHERE   r.EmployeeId=@id 
AND      r.RoleId = 51
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('N/A')
) q1

/* RoleId = 51 = Jupiter XLR8 Report Admin -- missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE  @JupiterXLR8Admin int
SELECT @JupiterXLR8Admin = Max(thecount)
from (
	SELECT   thecount = COUNT(1)   
	FROM    Employee_Role r WITH (NOLOCK)
WHERE   r.EmployeeId=@id 
AND      r.RoleId = 52
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('N/A')
) q1

/* Pulsar Developers 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE  @PulsarSystemAdmin int -- if either query is a 1, then return 1
SELECT @PulsarSystemAdmin = Max(thecount) --@PulsarSystemAdmin = count(thecount)
from (
	select thecount = COUNT(1)
	  FROM UserInfo e
	  WHERE e.UserID=@id
	  AND DevTeam=1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name = 'System.Admin'
) q1
   
/* PINPMId = PIN PM, ODMPIMPMID = ODM PIN PM -- PIN PM missing from spreadsheet 
   Because top section of Union return more than 1 row and sometime it taken the last row which will return 0, therefore we added Max so it will return value if any 
*/
DECLARE @IsPINPM int
SELECT @IsPINPM = Max(thecount) 
from (
	select thecount = COUNT(1)
FROM ProductVersion pv WITH(NOLOCK) 
WHERE pv.PINPMId = @id or pv.ODMPIMPMID = @id
AND pv.productstatusid < 4
AND typeid= 1
	UNION
	select CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END AS thecount
	from #CTE_Permission p
		WHERE p.Name in ('Feature.Edit', 'PRL.Edit', 'InstallOption.Edit')
) q1
 
DECLARE @CanEditProduct INT
SELECT  @CanEditProduct = CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END
FROM    Permission p WITH (NOLOCK)
INNER JOIN	Role_Object_Permission rop WITH (NOLOCK)
on rop.PermissionId = p.PermissionId 
INNER JOIN		RoleMembers rm WITH (NOLOCK)
on rm.RoleId = rop.RoleId
WHERE   rm.UserId = @id
AND     p.Name in ('Product.Edit')

declare	@EngCoordinator int
select  @EngCoordinator = case when count(1) > 0 then 1 else 0 end
from    Permission p WITH (NOLOCK)
		inner join Role_Object_Permission rop WITH (NOLOCK)
		on rop.PermissionId = p.PermissionId
		inner join RoleMembers rm WITH (NOLOCK)
		on rm.RoleId = rop.RoleId
where   rm.UserId = @id
		and p.Name in ('EngCoordinator.Edit')

		
declare	@ProductImageEdit int
select  @ProductImageEdit = case when count(1) > 0 then 1 else 0 end
from    Permission p WITH (NOLOCK)
		inner join Role_Object_Permission rop WITH (NOLOCK)
		on rop.PermissionId = p.PermissionId
		inner join RoleMembers rm WITH (NOLOCK)
		on rm.RoleId = rop.RoleId
where   rm.UserId = @id
		and p.Name in ('ProductImage.Edit')
		

declare	@AgencyDataMaintainer int
select  @AgencyDataMaintainer = case when count(1) > 0 then 1 else 0 end
from    Permission p  WITH (NOLOCK)
		inner join Role_Object_Permission rop WITH (NOLOCK)
		on rop.PermissionId = p.PermissionId
		inner join RoleMembers rm WITH (NOLOCK)
		on rm.RoleId = rop.RoleId
where   rm.UserId = @id
		and p.Name in ('Agency.Edit')

SELECT 
	@Favorites = @Favorites + 'P' + CAST(FavoriteItemId AS VARCHAR) + ','
FROM [dbo].[UserFavorite]
WHERE	UserId = @Id
	AND FavoriteType = 0 -- Product
ORDER BY [Sequence]

SELECT 
	@FavCount = COUNT(1)
FROM [dbo].[UserFavorite]
WHERE	UserId = @Id
	AND FavoriteType = 0 -- Product

SELECT   NtDomain AS Domain, e.FullName AS Name , e.UserID as ID, Email, Phone, e.Division, e.PartnerID, ApprovalSection,WorkingSection,resetpassword, PastDueSection, DueThisWeekSection, AllOpenSection, PIReassignedSection, ISubmittedSection, ClosedSection,PostRTMSection, OTSSubmittedSection,OTSDeliverableSection,OTSOwnerSection, systemadmin,PreinstallPM,DefaultProductTab, CommodityPM, MITTestLead, SCFactoryEngineer,CanReleaseLocalizations,
               @TestLeadAssignments as TestLeadAssignments, bpiaapprover, WWANEngineer, ServiceCommodityManager, ProcurementEngineer, ServicePM,ProposedSection, WorkgroupID, @ConsumerSEPMProducts as ConsumerSEPMProducts,  @HWProducts as HWProducts, @ServiceProducts as ServiceProducts, @SEPMProducts as SEPMProducts, LastStatusSection, lastStatusCategory, StatusDelegate, PIPMAlertSection, PINewRequestSection, 
               AccountSuspended,PIScripterSection, PIDBTeamSection, @FavCount AS FavCount, @Favorites AS Favorites, WhqlTestTeam, ServiceCoordinator, @EngCoordinator as EngCoordinator, AccessoryPM,FunctionalTestMADTSection, FunctionalTestOtherSection, FunctionalTest3rdPartySection,
 FunctionalTestMultimediaSection, FunctionalTestHelpAndSupportSection, FunctionalTestDeveloperSection, FunctionalTestUserGuidesSection,FunctionalTestToolsSection,FunctionalTest3rdPartyConsSection, 
               FunctionalTest3rdPartyInternalSection,FTVirtualizationSection,FTBIOSSection,FTThinClientSection,FTSecuritySection,FTMultimediaAppsSection,FTHWEnablingSection,FTIntelTechnologiesSection,ISNULL(PMImpersonate,0) as PMImpersonate, DefaultWorkingListProduct, ToolDeveloper, @SMProducts AS SMProducts, BpiaApprover,OtherPartnerNames,
               @AVsMissingCommMarketingData AS AVsMissingCommMarketingData, @AVsMissingSMBMarketingData AS AVsMissingSMBMarketingData, @AVsMissingConsMarketingData AS AVsMissingConsMarketingData, @PDMUser As PDMUser,
               @CMProductCount AS CMProductCount, @PCProductCount AS PCProductCount, @PhWebProductCount AS PhWebProductCount, ISNULL(CMImpersonate,0) AS CMImpersonate, ISNULL(PCImpersonate,0) AS PCImpersonate, ISNULL(PhWebImpersonate,0) AS PhWebImpersonate, p.PartnerTypeID,
               @MarketingProductCount AS MarketingProductCount, ISNULL(MarketingImpersonate,0) AS MarketingImpersonate, @PCAdmin AS PCAdmin, @CMAdmin AS CMAdmin, @PDMAdmin AS PDMAdmin, @MKTAdmin AS MKTAdmin, e.IRSUserID, @SAAdmin AS SAAdmin, @JupiterXLR8Admin AS JupiterXLR8Admin, e.Pulsar,@PulsarSystemAdmin as PulsarSystemAdmin, @IsPINPM as IsPINPM, PINPMImpersonate = ISNULL(PINPMImpersonate,0), @originalName as originalName,
			   @CanEditProduct AS CanEditProduct, CurrentName = e.FirstName + ' ' + e.LastName, @AgencyDataMaintainer AS AgencyDataMaintainer,@OriginalUserId AS OriginalUserId, @ProductImageEdit AS ProductImageEdit
	FROM       dbo.UserInfo e WITH (NOLOCK) INNER JOIN Partner p WITH (NOLOCK) ON p.ID = e.partnerid
	WHERE  e.UserID=@id
	
IF @updateLastActivity=1
	BEGIN
		Update Userinfo Set LastActivity = GetDate(), [Disabled] = null where UserId=@id;
	END

SET NOCOUNT OFF;

﻿

CREATE PROCEDURE [dbo].[spGetApproverEmail](@ApprovalID int)
AS SELECT     e.Email, i.ID AS ActionID, v.EmailActive, i.Type, i.Summary, v.dotsname AS Product, i.Submitter, i.Created, i.Notify, i.TargetDate, 
                      i.Approvals, i.Description, i.Actions, i.Resolution, i.Status, dbo.CoreTeamRep.Name AS CoreTeamRep, Employee_1.Name AS Owner
FROM         dbo.ActionApproval aa with (NOLOCK) INNER JOIN
                      dbo.Employee e with (NOLOCK) ON aa.ApproverID = e.ID INNER JOIN
                      dbo.DeliverableIssues i with (NOLOCK) ON aa.ActionID = i.ID INNER JOIN
                      dbo.ProductVersion v with (NOLOCK) ON i.ProductVersionID = v.ID INNER JOIN
                      dbo.ProductFamily f with (NOLOCK) ON v.ProductFamilyID = f.ID INNER JOIN
                      dbo.CoreTeamRep  with (NOLOCK)ON i.CoreTeamRep = dbo.CoreTeamRep.ID INNER JOIN
                      dbo.Employee Employee_1 with (NOLOCK) ON i.OwnerID = Employee_1.ID
WHERE     (aa.ID = @ApprovalID)




﻿

CREATE PROCEDURE [dbo].[rpt_ProgScheduleSummary]
    @p_Active INT = NULL,
    @p_DevCenter INT = NULL,
    @p_RunningProgramsOnly_YN CHAR(1) = 'N'
AS

/******************************************************************************
**  File: dbo.rpt_ProgScheduleSummary.sql
**  Name: rpt_ProgScheduleSummary
**  Desc:
**
**  Auth:
**  Date:
*******************************************************************************
**  Change History
*******************************************************************************
**  Date:       Author:             Description:
**  ----------  ------------------  -------------------------------------------
**
*******************************************************************************/

SET NOCOUNT ON

CREATE TABLE #RPT_PROGRAM_SCHEDULE_SUMMARY
(
    id INT,
    familyname VARCHAR(100),
    version VARCHAR(20),
    stl VARCHAR(80),
    cm VARCHAR(80),
    sepm VARCHAR(80),
    sepe VARCHAR(80),
    pinpm VARCHAR(80),
    setestlead VARCHAR(80),
    partner VARCHAR(30),
    systemboardid VARCHAR(500),
    streetname VARCHAR(2048),
    preinstallcutoff VARCHAR(50),
    schedulename VARCHAR(100),
    schedule_id INT,
    active TINYINT,
    typeid TINYINT,
    partnerid INT,
    devcenter INT,
    productstatusid INT,
    scheduledescription VARCHAR(500)
)

CREATE TABLE #RPT_PROGRAM_SCHEDULE_SUMMARY_COLUMNS
( ID INT )

INSERT INTO #RPT_PROGRAM_SCHEDULE_SUMMARY_COLUMNS (ID)
VALUES (1)


INSERT INTO #RPT_PROGRAM_SCHEDULE_SUMMARY (id, familyname, version, stl, cm, sepm, sepe, pinpm, setestlead, partner, systemboardid, streetname, preinstallcutoff, schedulename, schedule_id, active, typeid, partnerid, devcenter, productstatusid, scheduledescription)
SELECT pv.id, pv.productname, pv.version, stl.name, cm.name, sepm.name, sepe.name, pinpm.name, setl.name, p.name, systemboardid, dbo.ufn_GetSeriesList(pv.id), preinstallcutoff, s.schedule_name, s.schedule_id, pv.active, pv.typeid, pv.partnerid, pv.devcenter, pv.productstatusid, s.description
FROM
    productversion pv with (NOLOCK) LEFT OUTER JOIN
    employee stl with (NOLOCK) ON stl.id = pv.smid LEFT OUTER JOIN
    employee cm with (NOLOCK) ON cm.id = pv.smid LEFT OUTER JOIN
    employee sepm with (NOLOCK) ON sepm.id = pv.sepmid LEFT OUTER JOIN
    employee sepe with (NOLOCK) ON sepe.id = pv.sepe LEFT OUTER JOIN
    employee pinpm with (NOLOCK) ON pinpm.id = pv.pinpm LEFT OUTER JOIN
    employee setl with (NOLOCK) ON setl.id = pv.setestlead INNER JOIN
    partner p with (NOLOCK) ON p.id = pv.partnerid INNER JOIN
    Product_Release pr with (NOLOCK) ON pv.id = pr.productversionid INNER JOIN
    Release r with (NOLOCK) ON r.id = pr.ReleaseID INNER JOIN
    Schedule s with (NOLOCK) ON pr.id = s.product_release_id INNER JOIN
    productfamily pf with (NOLOCK) ON pf.id = pv.productfamilyid
WHERE
	s.active_yn = 'y'
AND	pv.DevCenter = COALESCE(@p_DevCenter, pv.DevCenter)
AND pv.Active = COALESCE(@p_Active, pv.Active)
--AND	pv.id != 100 --Exclude Test Product form the list

DECLARE @v_ScheduleID INT
DECLARE @v_ItemDesc VARCHAR(100)

DECLARE cur_schedule CURSOR FOR
SELECT schedule_definition_data_id, item_description
FROM schedule_definition_data with (NOLOCK)
WHERE active_yn_default = 'Y' -- IN (7, 8, 14, 19, 20, 22, 27, 33, 41, 42, 44, 50, 56, 58, 60, 61)
ORDER BY item_phase, item_order

OPEN cur_schedule

FETCH NEXT FROM cur_schedule
INTO @v_ScheduleID, @v_ItemDesc

WHILE @@FETCH_STATUS = 0
BEGIN

--    SET @v_ItemDesc = REPLACE(@v_ItemDesc, ' ', '_')
--    SET @v_ItemDesc = REPLACE(@v_ItemDesc, '@', '@@')
--    SET @v_ItemDesc = REPLACE(@v_ItemDesc, '&', '@and@')
--    SET @v_ItemDesc = REPLACE(@v_ItemDesc, '-', '@dash@')
    
    EXEC('ALTER TABLE #RPT_PROGRAM_SCHEDULE_SUMMARY_COLUMNS ADD [' + @v_ScheduleID + '] VARCHAR(100)')
    EXEC('UPDATE #RPT_PROGRAM_SCHEDULE_SUMMARY_COLUMNS SET [' + @v_ScheduleID + '] = ''' + @v_ItemDesc + '''')

    EXEC ('ALTER TABLE #RPT_PROGRAM_SCHEDULE_SUMMARY ADD [' + @v_ScheduleID  + '] DATETIME')
    EXEC ('UPDATE #RPT_PROGRAM_SCHEDULE_SUMMARY SET [' + @v_ScheduleID  + '] = COALESCE(actual_start_dt, projected_start_dt) FROM schedule_data WHERE #RPT_PROGRAM_SCHEDULE_SUMMARY.schedule_id = schedule_data.schedule_id AND schedule_definition_data_id = ' + @v_ScheduleID)

    FETCH NEXT FROM cur_schedule
    INTO @v_ScheduleID, @v_ItemDesc

END

CLOSE cur_schedule
DEALLOCATE cur_schedule

EXEC ('ALTER TABLE #RPT_PROGRAM_SCHEDULE_SUMMARY ADD pdd_dt DATETIME')
EXEC ('UPDATE #RPT_PROGRAM_SCHEDULE_SUMMARY SET pdd_dt = actual_start_dt FROM schedule_data WHERE #RPT_PROGRAM_SCHEDULE_SUMMARY.schedule_id = schedule_data.schedule_id AND schedule_definition_data_id = 8')

EXEC ('ALTER TABLE #RPT_PROGRAM_SCHEDULE_SUMMARY ADD fcs_dt DATETIME')
EXEC ('UPDATE #RPT_PROGRAM_SCHEDULE_SUMMARY SET fcs_dt = actual_start_dt FROM schedule_data WHERE #RPT_PROGRAM_SCHEDULE_SUMMARY.schedule_id = schedule_data.schedule_id AND schedule_definition_data_id = 60')


SELECT * FROM #RPT_PROGRAM_SCHEDULE_SUMMARY_COLUMNS


IF (@p_RunningProgramsOnly_YN = 'Y')
	EXEC ('SELECT * FROM #RPT_PROGRAM_SCHEDULE_SUMMARY WHERE pdd_dt IS NOT NULL AND fcs_dt IS NULL')
ELSE
	EXEC ('SELECT * FROM #RPT_PROGRAM_SCHEDULE_SUMMARY')

DROP TABLE #RPT_PROGRAM_SCHEDULE_SUMMARY
DROP TABLE #RPT_PROGRAM_SCHEDULE_SUMMARY_COLUMNS

SET NOCOUNT OFF





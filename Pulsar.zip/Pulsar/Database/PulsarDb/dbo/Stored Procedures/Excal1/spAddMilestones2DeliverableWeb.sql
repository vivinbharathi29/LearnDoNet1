﻿

CREATE PROCEDURE [dbo].[spAddMilestones2DeliverableWeb]
 (
  @Deliverable int,
  @Milestone varchar(50),
  @MilestoneOrder smallint,
  @Planned DateTime,
  @Actual DateTime,
  @Status int,
  @ReportMilestone tinyint,
  @WorkflowDefinitionID int,
  @NewID int output
 )
 AS
DECLARE @WorkflowStepID int
Select @WorkflowStepID = ID from DeliverableWorkflowDefinitions with (NOLOCK) where WorkflowID = @WorkflowDefinitionID and MilestoneOrder = @MilestoneOrder
if @WorkflowStepID = ''
	Select @WorkflowStepID = 0
INSERT DeliverableSchedule(DeliverableVersionID,Milestone, MilestoneOrder,Planned,Actual,StatusID,ReportMilestone, DefinitionID)
Values (@Deliverable,@Milestone,@MilestoneOrder,@Planned,@Actual,@Status,@ReportMilestone,@WorkflowStepID)
Select @NewID = SCOPE_IDENTITY()




﻿

CREATE PROCEDURE [dbo].[spGetProductBrands]
(
	@ProdID int
)
AS
Declare @VersionBrands varchar( 255)
Select @VersionBrands = Brands
from productversion with (NOLOCK)
where id = @Prodid
Select Distinct(b.name), @VersionBrands as VersionBrands, b.BusinessID
from ImageDefinitions d with (NOLOCK), Brand b with (NOLOCK)
where b.id = d.BrandID
and d.active=1
and d.productversionid = @Prodid


﻿CREATE PROCEDURE [dbo].[spGetEmployees]
/* ***********************************************************************************************************************************************
 * Purpose:		Return all users
 * Created By:	?
 * Modified By:	05/10/16 Malichi - PBI 10931: User Admin; Update the Impersonate menu to Include email address in () when the names are the same
 *21/8/2018  Monica  Modified the IN condition to temp table
 *************************************************************************************************************************************************/
 
 @p_intImpersonate INT = 0

AS
	IF @p_intImpersonate = 0
	  BEGIN
		SELECT   ID, Name,Email, Phone, Division, workgroupid, ntname, active, domain, 
		commoditypm, AccessoryPM,SCFactoryEngineer,ProgramCoordinator, partnerid
		FROM     Employee with (NOLOCK)
		ORDER BY Name
	  END
	ELSE
	  BEGIN
	  SELECT Name,COUNT(Name) AS CNT
	  INTO #tmp_employee
						FROM   Employee with (NOLOCK)
						WHERE  Active = 1
						GROUP BY Name

	    SELECT ID, Employee.Name, '' AS Email, NTName, Domain 
	    FROM   Employee with (NOLOCK)
		INNER JOIN #tmp_employee N
		ON Employee.Name=N.Name
		WHERE  Active = 1
		ANd CNT=1
		--AND    Name IN (SELECT Name
		--				FROM   Employee with (NOLOCK)
		--				WHERE  Active = 1
		--				GROUP BY Name
		--				HAVING COUNT(Name) = 1)
		UNION
		SELECT ID, Employee.Name, ' (' + Email + ')' AS Email, NTName, Domain
		FROM   Employee with (NOLOCK)
		INNER JOIN #tmp_employee N
		ON Employee.Name=N.Name
		WHERE  Active = 1
		ANd CNT>1
		--AND    Name IN (SELECT Name
		--				FROM   Employee with (NOLOCK)
		--				WHERE  Active = 1
		--				GROUP BY Name
		--				HAVING COUNT(Name) > 1)
		ORDER BY Name
	  END
RETURN

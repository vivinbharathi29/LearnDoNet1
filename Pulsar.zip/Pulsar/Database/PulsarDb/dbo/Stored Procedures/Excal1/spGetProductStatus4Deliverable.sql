﻿CREATE PROCEDURE [dbo].[spGetProductStatus4Deliverable]
(
	@VersionID int
)
-- =================================================================
-- Updated: 05/19/2016 wgomero: If product is legacy add (Legacy) else (Pulsar)
--		    06/08/2016 buidi: add release for pulsar product
-- =================================================================
AS
SELECT        
	e.Name AS SEPM, 
	Product = v.dotsname + ' (Legacy)', 
	dv.DeveloperNotification, 
	dv.PreReleased, 
	dv.DeveloperID, 
	pd.DeveloperNotificationStatus, 
	pd.DeveloperTestStatus, 
	pd.ID AS pdid, 
	pd.InImage, 
	pd.Preinstall, 
	pd.Targeted, 
	pd.PMAlert, 
	v.PartnerID, 
	pd.PreInstallStatus, 
	e2.Name AS PreinstallOwner, 
    pd.TargetNotes,
	ProductDeliverableReleaseID = 0
FROM
	ProductVersion AS v WITH (NOLOCK) 
	INNER JOIN ProductFamily AS f WITH (NOLOCK) ON v.ProductFamilyID = f.ID 
	INNER JOIN Product_Deliverable AS pd WITH (NOLOCK) ON v.ID = pd.ProductVersionID 
	INNER JOIN Employee AS e WITH (NOLOCK) ON v.SEPMID = e.ID 
	INNER JOIN DeliverableVersion AS dv WITH (NOLOCK) ON pd.DeliverableVersionID = dv.ID 
	LEFT OUTER JOIN Employee AS e2 WITH (NOLOCK) ON pd.PreInstallStatus = e2.ID
WHERE        
	pd.DeliverableVersionID = @VersionID and v.FusionRequirements <> 1
UNION
SELECT        
	e.Name AS SEPM, 
	Product = v.dotsname + ' (' + pvr.Name + ')', 
	dv.DeveloperNotification, 
	dv.PreReleased, 
	dv.DeveloperID, 
	pdr.DeveloperNotificationStatus, 
	pdr.DeveloperTestStatus, 
	pd.ID AS pdid, 
	pd.InImage, 
	pd.Preinstall, 
	pdr.Targeted, 
	pd.PMAlert, 
	v.PartnerID, 
	pd.PreInstallStatus, 
	e2.Name AS PreinstallOwner, 
    pdr.TargetNotes,
	ProductDeliverableReleaseID = 0
FROM
	ProductVersion AS v WITH (NOLOCK) 
	INNER JOIN ProductFamily AS f WITH (NOLOCK) ON v.ProductFamilyID = f.ID 
	INNER JOIN Product_Deliverable AS pd WITH (NOLOCK) ON v.ID = pd.ProductVersionID 
	INNER JOIN Product_Deliverable_Release AS pdr WITH (NOLOCK) on pdr.ProductDeliverableID = pd.ID
	INNER JOIN ProductVersionRelease AS pvr WITH (NOLOCK) on pvr.ID = pdr.ReleaseID
	INNER JOIN Employee AS e WITH (NOLOCK) ON v.SEPMID = e.ID 
	INNER JOIN DeliverableVersion AS dv WITH (NOLOCK) ON pd.DeliverableVersionID = dv.ID 
	LEFT OUTER JOIN Employee AS e2 WITH (NOLOCK) ON pd.PreInstallStatus = e2.ID
WHERE        
	pd.DeliverableVersionID = @VersionID and v.FusionRequirements = 1
ORDER BY Product



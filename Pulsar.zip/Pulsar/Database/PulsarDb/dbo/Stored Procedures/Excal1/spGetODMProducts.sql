﻿

CREATE PROCEDURE [dbo].[spGetODMProducts]
	@ODM int = -1
AS

If @ODM = -1
	SELECT
		v.ID AS ID,
		v.productName AS Name,
		v.dotsname as product,
		e.Name AS PM,
		e.ID as PMID,
		v.Distribution,
		v.OnCommodityMatrix,
		v.PRDReleased,
		v.PDDReleased,
		v.OnlineReports,
		v.Brands,
		v.SystemBoardID,
		v.PartnerID,
		v.PreinstallTeam,
		v.TypeID,
		e2.Name AS SEPM,
		v.Division,
		v.Sustaining,
		v.DevCenter,
		v.ReleaseTeam,
		v.Active,
		e2.Email AS SEPMMail,
		e2.ID AS SEPMID,
		e3.Name AS SM,
		e3.Email AS SMMail,
		e3.ID AS SMID,
		v.ProductFilePath,
		v.PDDPath,
		v.SCMPath,
		v.ProgramMatrixPath,
		v.STLStatusPath,
		p.Name AS Partner,
		sepe.name AS SEPE,
		sepe.Email AS SEPEMail,
		sepe.ID AS SEPEID,
		pinpm.name AS PINPM,
		pinpm.Email as PINPMMail,
		pinpm.id as PINPMID,
		setl.name AS SETL,
		setl.email AS SETLMail,
		setl.id AS SETLID
	FROM
		ProductFamily f WITH (NOLOCK)
		INNER JOIN ProductVersion v WITH (NOLOCK) on f.ID = v.ProductFamilyID
		INNER JOIN Partner p WITH (NOLOCK) on v.PartnerID = p.ID
		INNER JOIN Employee e WITH (NOLOCK) on v.pmid = e.id
		INNER JOIN Employee e2 WITH (NOLOCK) on v.SEPMID = e.ID
		INNER JOIN Employee e3 WITH (NOLOCK) on v.SMID = e.ID
		LEFT OUTER JOIN Employee sepe WITH (NOLOCK) on v.SEPE = sepe.ID
		LEFT OUTER JOIN Employee pinpm WITH (NOLOCK) on v.PINPM = pinpm.ID
		LEFT OUTER JOIN Employee setl WITH (NOLOCK) on v.SETestLead = setl.ID
	WHERE
	    typeid = 1
	and (v.Active = 1)
	ORDER BY
		v.dotsname


﻿

CREATE PROCEDURE [dbo].[spListApprovals]
(
@ActionID int,
@ApproverID int = NULL
)
AS 

SELECT a.ID, e.Name AS Approver, a.Status, a.Comments, a.Role, a.ApproverID, e.Email, 
	   a.Updated, DeliverableIssues.Created
FROM   ActionApproval AS a with (NOLOCK) INNER JOIN
       Employee AS e with (NOLOCK) ON a.ApproverID = e.ID INNER JOIN
       DeliverableIssues with (NOLOCK) ON a.ActionID = DeliverableIssues.ID
WHERE  (a.ActionID = @ActionID) AND (a.ApproverID = COALESCE (@ApproverID, a.ApproverID))






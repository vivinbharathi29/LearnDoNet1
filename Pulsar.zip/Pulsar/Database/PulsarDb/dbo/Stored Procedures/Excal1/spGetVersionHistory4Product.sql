﻿

CREATE PROCEDURE [dbo].[spGetVersionHistory4Product]

(
	@RootID int,
	@ProdID int
)
AS

Select v.ID,pd.PMAlert, pd.Targeted, pd.inimage, v.comments, v.packageforweb, r.certrequired, v.certificationstatus, v.languages, v.vendorversion, 
	   v.icondesktop,v.icontray,v.iconpanel, v.IconTile, v.IconTaskbarIcon, v.Version, v.Revision, v.Pass, v.PartNumber,v.Changes, e.Name as Developer 
FROM DeliverableVersion v with (NOLOCK), deliverableroot r with (NOLOCK), product_deliverable pd with (NOLOCK), Employee e  with (NOLOCK)
WHERE pd.deliverableversionid = v.id 
and pd.productversionid = @ProdID
and r.id = v.deliverablerootid
and e.id = v.DeveloperID 
and DeliverableRootID =  @RootID 
Order by Version, Revision, Pass;



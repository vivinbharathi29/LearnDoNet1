﻿/***************************************************************************************************************************************************************
 * Purpose:		create a new user
 * Modified By:	03/23/2016 - SPathak - record the created/createdby fields when a new user id added
				31/03/2016 Ravi Nukala - SR0015 - Deterministic function call (function) might cause an unnecessary table scan. Task 18941
				9/16/2016 SPathak - change the created by and updated by fie
				4/23/2018 linshant, feeding data to IRS after user account created/changed in pulsar - PBI 192766
				07/12/2018 wgomero PBI Rename UserInfo table in IRS and create a View with the same name, View will read data from Pulsar Userinfo table PBI 208537
				18/2/2019 Dean Chiang TICKET#: 16357 Can't create a account for IRS due to my account is inactive on Pulsar BUG 122
 ******************************************************************************************************************************************************************       
** SNo   Date        Author                        Description           
** --    --------   -------                        -------------------------           
 ** 1    27/12/2018  Santhana K					   Used the Setting table instead of hardcoding pulsar.support
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spAddEmployeeWeb]

 (
  @Name varchar(80),
  @FirstName varchar(30),
  @LastName varchar(30),
  @Phone varchar(30),
  @Email varchar(80),
  @NTName varchar(80),
  @Domain varchar(30),
  @WorkgroupID int,
  @DivisionID int,
  @PartnerID int,
  @User varchar(100) = 'dbo',
  @FTPAccessRequested bit,
  @ID int Output
 )
As
DECLARE @IsHp bit, @IsNTNameDup bit, @IsEmailDup bit, @IsActiveInGAL bit
DECLARE @PulsarSupportEmail varchar(100)

select @PulsarSupportEmail=value from Setting
where name = 'Pulsar.SupportEmail'

SET @IsNTNameDup = 0
SET @IsEmailDup = 0
SET @IsActiveInGAL = 0

IF (@PartnerID = 1)
 BEGIN
	SET @IsHp = 1
	SET @IsActiveInGAL = 1
END 

IF @User = 'Excalibur'
	SET @User = @LastName + ', ' + @FirstName

DECLARE @vNTName varchar(80), @vDomain varchar(30), @vEmail varchar(80)
SET @vNTName = ltrim(rtrim(@NTName))
SET @vDomain = ltrim(rtrim(@Domain))
SET @vEmail = ltrim(rtrim(@Email))

--check if a user with the same NT User Name already exists in the database
--DP, once user is no more active in GAL, its ntname can be reused
--It makes sense only for HP users. ODM should have IsActiveInGAL=0
IF EXISTS(SELECT 1 FROM UserInfo WHERE NTName = @vNTName
						          and NtDomain = @vDomain and IsActiveInGAL=1) 
	SET @IsNTNameDup = 1


-- check if a user with the same Email Address already exists in the database
--Email address must be unique among all activeInGAL users and ODM Users (an HP user might be disabled in pulsar just temporarily, for ODM users we don't wana create multiple users with same email)
IF EXISTS(SELECT 1 FROM UserInfo WHERE Email = @vEmail AND (IsHp=0 OR IsActiveInGAL=1)) 
	SET @IsEmailDup = 1


IF ((@IsNTNameDup = 1 ) and (@IsEmailDup = 1))
BEGIN
	RAISERROR('NT User Name and Email already exists.', 16, 1)
	RETURN 1
END
ELSE IF (@IsNTNameDup = 1 )
BEGIN
	RAISERROR('NT User Name already exists.', 16, 1)
	RETURN 1
END
ELSE IF (@IsEmailDup = 1)
BEGIN
	RAISERROR('Email Address already exists.', 16, 1)
	RETURN 1
END


 DECLARE @IRSUserID INT;
 SELECT @IRSUserID = MAX(IRSUserID) FROM UserInfo WITH(NOLOCK) WHERE IRSUserID > 0;
		SET @IRSUserID = @IRSUserID + 1;


INSERT UserInfo (FullName,FirstName,LastName,Phone,Email,WorkgroupID,NTName,Division, NtDomain, PartnerID, FTPAccessRequested, IsHp, IsActiveInGAL, Created, CreatedBy, Updated, UpdatedBy, IRSUserID)
	   Values (@Name,@FirstName,@LastName,@Phone,@Email,@WorkgroupID, @NTName, @DivisionID,@Domain,@PartnerID,@FTPAccessRequested,@IsHp,@IsActiveInGAL, GETDATE(), @User, GETDATE(), @User, @IRSUserID)
SELECT @ID = SCOPE_IDENTITY()

IF @@error <> 0	
BEGIN
		RAISERROR('spAddEmployeeWeb - Creating New User failed.', 16, 1)
		RETURN 1
END

IF (@ID > 0)
BEGIN
	BEGIN TRY
		IF (@PartnerID > 1)
		BEGIN
			DECLARE @partnerName varchar(100) =''
			SELECT @partnerName = Name FROM Partner WHERE PartnerId = @PartnerID
			UPDATE UserInfo SET NtName = @partnerName + convert(varchar(10),@ID), NtDomain = @partnerName WHERE UserId = @ID and PartnerId > 1
		END
		
		BEGIN
			INSERT INTO IRS_Group_User VALUES(207, @IRSUserID)
		END
	END TRY
	BEGIN CATCH
		INSERT INTO MessageQueuedEmail ([Priority], [From], FromName, [To], ToName, Cc, Bcc, [Subject], Body, AttachMents, Created, SendTries)
		VALUES(0, @PulsarSupportEmail, 'Pulsar Support', @PulsarSupportEmail, 'Pulsar Support', '', '', 'spAddEmployeeWeb - Creating user failed in IRS', 'Pulsar UserId: ' + cast(@ID as varchar(10)) + ' -- Error: ' + ERROR_MESSAGE(), null, GETDATE(), 0)
	END CATCH
END
GO



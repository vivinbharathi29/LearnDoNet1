﻿CREATE PROCEDURE [dbo].[spGetProductDelRootID]
(
	@ProdID int,
	@RootID int,
	@ReleaseID int = 0
)

AS

if @ReleaseID = 0 
begin
	Select ID, ProductVersionReleaseID = 0
	from Product_delroot with (NOLOCK)
	where productversionid = @ProdID
	and deliverablerootid = @RootID
end
else 
begin
	Select pdr.ID, pv_R.ID as ProductVersionReleaseID
	from Product_delroot pdr with (NOLOCK)  
	inner join Product_delroot_release pdrr on pdr.id = pdrr.ProductDelRootID
	inner join ProductVersion_Release pv_r on pv_r.ProductVersionID = pdr.ProductVersionID and pv_r.ReleaseID = pdrr.ReleaseID
	where pdr.ProductVersionID = @ProdID
	and deliverablerootid = @RootID
	and pdrr.ReleaseID = @ReleaseID
end
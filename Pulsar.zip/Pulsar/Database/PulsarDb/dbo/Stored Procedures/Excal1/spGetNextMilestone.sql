﻿

CREATE PROCEDURE [dbo].[spGetNextMilestone]
(
 @DelID int,
 @MilestoneID int
)
 AS
DECLARE @CurrentOrder as int
SELECT @CurrentOrder =MilestoneOrder From  DeliverableSchedule Where ID  = @MilestoneID
SELECT ID,Milestone
FROM DeliverableSchedule with (NOLOCK)
Where MilestoneOrder = @CurrentOrder + 1 
and DeliverableVersionID = @DelID




﻿
CREATE PROCEDURE [dbo].[spDeleteDefaultProductFilter]

(
	@EmployeeID int,
	@UserSettingsID int
)

 AS

	Delete Employee_UserSettings 
	where employeeid = @EmployeeID
	and UserSettingsID = @UserSettingsID



﻿CREATE PROCEDURE [dbo].[spGetImageProperties]
(
	@ImageID int
)
/* ************************************************************************************************
 * Purpose:		
 * Created By:	
 * Modified By:	10/14/2016 - buidi - pulling OSLanguage and OtherLanguage from new structure table
 *
 **************************************************************************************************/
 AS
SELECT     
	i.ID, def.SKUNumber, def.ImageSnapshotsSaved, def.BrandID, b.Name AS Brand, 
	def.OSID, def.Comments, o.Name AS OS, def.SWID, s.Name AS SW, def.ImageType, 
	def.StatusID, ss.Name AS Status, def.RTMDate, r.ID AS regionid, r.Name AS Region, 
	r.Dash, r.CountryCode, 
	[OSLanguage] = substring( 
			(	Select ' ' + Replace(L.Abbreviation, 'US', 'EN') AS [text()]
				From Language L
				Inner Join Regions_ImgOS_Language RIOL on RIOL.LanguageID = L.ID
				Where RIOL.RegionID = r.ID and RIOL.IsDefault = 1
				Order By l.Abbreviation
				For XML Path ('')
			), 2, 1000), 
	[OtherLanguage] = substring( 
			(	Select ',' + Replace(L.Abbreviation, 'US', 'EN') AS [text()]
				From Language L
				Inner Join Regions_ImgOS_Language RIOL on RIOL.LanguageID = L.ID
				Where RIOL.RegionID = r.ID and RIOL.IsDefault = 0
				Order By l.Abbreviation
				For XML Path ('')
			), 2, 1000), 
	r.OptionConfig, 
	i.LockedDeliverableList, v.DevCenter, COALESCE(i.ImageDriveDefinitionId, def.ImageDriveDefinitionId) AS ImageDriveDefinitionId 
	, drv.DivCd, drv.SiteCd, drv.DriveName, drv.PartNo, drv.PartNoRev, drv.IsAssembly, ipd.Languages AS ImgLanguages, o.PinOsCd, r.ImageLanguage
	,def.ImageTypeId
FROM         
	ProductVersion AS v WITH (NOLOCK) 
	INNER JOIN ImageDefinitions AS def WITH (NOLOCK) ON v.ID = def.ProductVersionID 
	INNER JOIN Images AS i WITH (NOLOCK) ON def.ID = i.ImageDefinitionID 
	INNER JOIN Regions AS r WITH (NOLOCK) ON i.RegionID = r.ID 
	INNER JOIN Brand AS b WITH (NOLOCK) ON def.BrandID = b.ID 
	INNER JOIN OSLookup AS o WITH (NOLOCK) ON def.OSID = o.ID 
	INNER JOIN ImageSWType AS s WITH (NOLOCK) ON def.SWID = s.ID 
	INNER JOIN ImageStatus AS ss WITH (NOLOCK) ON def.StatusID = ss.ID 
	LEFT OUTER JOIN ImageDriveDefinition AS drv WITH (NOLOCK) ON COALESCE(i.ImageDriveDefinitionId, def.ImageDriveDefinitionId) = drv.ID
	LEFT OUTER JOIN ImagePinDefinition AS ipd WITH (NOLOCK) ON ipd.Dash = SUBSTRING(r.Dash, 2,2) AND def.OsId = ipd.OsId
WHERE     
	(i.ID = @ImageID)





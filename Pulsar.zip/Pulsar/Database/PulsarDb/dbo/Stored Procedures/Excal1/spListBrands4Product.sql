﻿CREATE PROCEDURE [dbo].[spListBrands4Product] 
/*-- =================================================================
-- Update: Changed to new OUTER JOIN syntax - Paul Sanchez 3/11/2014
--		 Ywang, set businessID =isnull(businessID, 0) to fix an ui error
-- Modified By: 2/14/2015 SPathak - updated to return 1 instead of 0 if the BusinessID is null
--				Ywang, 2.27/2015, sort by brand name, pbi 8503
				Ywang, 6/29/2015, called from supply chain tab, chaneg history page
				Malichi, 09/20/2016 - PBI 25540: General Tab changes for Consumer Team
				wgomero 06/18/2018 - PBI 209863: get MasterLabel information from Series instead of Product_Brand table
				wgomero 07/02/2018 - PBI 212952: get CTOModelInformation information from Series instead of Product_Brand table
				16/7/2018 Monica Placed the if exists in selected only =1 and changed the In condition to Inner join in selected only =2
-- =================================================================
*/

(
	@ProductID int,
	@SelectedOnly tinyint = 1
)
 AS
 SET NOCOUNT ON
 	DECLARE @HasSeries BIT, @Count INT 

	--SET @HasSeries = 0
	---- check if Product Brand has Series
	--IF EXISTS (SELECT 1 FROM Product_Brand a  WITH(NOLOCK)
	--INNER JOIN Series b WITH(NOLOCK)
	--ON a.ID = b.ProductBrandID 
	--WHERE a.ProductVersionID = @ProductID)
	--	BEGIN
	--		SET @HasSeries = 1;
	--	END

if @SelectedOnly = 1
BEGIN 


	SET @HasSeries = 0
	-- check if Product Brand has Series
	IF EXISTS (SELECT 1 FROM 
	Product_Brand a  WITH(NOLOCK)
	INNER JOIN Series b WITH(NOLOCK)
	ON a.ID = b.ProductBrandID 
	WHERE a.ProductVersionID = @ProductID)
		BEGIN
			SET @HasSeries = 1;
		END

		Select DISTINCT l.ID, l.Name,
		l.streetname,l.streetname2,l.streetname3, 
		l.suffix,l.RASSegment, l.active,
			s.Name as SeriesSummary, 
			l.abbreviation, v.version as productversion, 
			v.productname as productfamily, p.ID as ProductBrandID, 
			v.dotsname as product, v.id as ProductID, l.id as brandid,
			pn.name as Partner, p.LastPublishDt,l.ShowSeriesNumberInLogoBadge,
			l.ShowSeriesNumberInBrandname,l.SplitSeriesForLogoAndBrand, 
			l.ShowSeriesNumberInShortName, 
		BusinessID = isnull(l.BusinessID, 1),
		p.KMAT, p.ServiceTag, p.BIOSBranding, p.LogoBadge,p.LongName,p.ShortName,p.FamilyName,p.BrandName,
		MasterLabel= CASE WHEN @HasSeries = 1 THEN isnull(s.MasterLabel, '')
								ELSE isnull(p.MasterLabel, '')
						END,
		BTOServiceTagName=isnull(p.BTOServiceTagName, ''),
		CTOModelNumber = CASE WHEN @HasSeries = 1 THEN isnull(s.CTOModelNumber, '')
								ELSE isnull(p.CTOModelNumber, '')
						END
		from 
			Brand l with (NOLOCK)
			INNER JOIN product_brand p with (NOLOCK)
				ON p.BrandID = l.ID
			INNER JOIN productversion v with (NOLOCK) 
			ON v.id = p.ProductVersionID
			INNER JOIN productfamily f with (NOLOCK) 
			ON f.id = v.ProductFamilyID
			INNER JOIN Partner pn with (NOLOCK) ON pn.ID = v.PartnerID
			LEFT OUTER JOIN Series s with (NOLOCK) 
			ON p.ID = s.ProductBrandId
		where p.productversionid = @ProductID
		order by l.Name

END 
else if @SelectedOnly=2 --need to display the combined brands
	Select  distinct
		name = isnull(p.CombinedName, l.Name),
		ProductBrandID =p.ID ,
		BrandName = isnull(p.CombinedName,isnull(p.BrandName,l.Name)) 
	from 
		Product_Brand p with (NOLOCK)
		inner join 	Brand l with (NOLOCK) 
		ON p.BrandID = l.ID
		INNER JOIN (select CombinedProductBrandId   As CombinedProductBrandId
				from Product_Brand pb2 WITH(NOLOCK)
				where pb2.ProductVersionID = @ProductID)pb2
				ON 	 p.ID = pb2.CombinedProductBrandId
	where p.productversionid = @ProductID

	order by name
else
	Select l.ID, l.Name,l.streetname,l.streetname2,l.streetname3,
	l.RasSegment, l.suffix,l.active,p.SeriesSummary, 
	p.ID as ProductBrandID, l.Abbreviation, p.LastPublishDt,
	l.ShowSeriesNumberInLogoBadge, l.ShowSeriesNumberInBrandname,
	l.SplitSeriesForLogoAndBrand, l.ShowSeriesNumberInShortName,
	BusinessID = isnull(l.BusinessID, 1) , p.KMAT
	from 
		Brand l with (NOLOCK)
		LEFT OUTER JOIN Product_Brand p with (NOLOCK) 
		ON p.BrandID = l.ID
		AND p.productversionid = @ProductID
	order by l.Name

	SET NOCOUNT OFF
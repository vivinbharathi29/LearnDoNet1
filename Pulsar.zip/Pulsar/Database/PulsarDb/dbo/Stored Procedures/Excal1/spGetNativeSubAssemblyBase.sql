﻿CREATE PROCEDURE [dbo].[spGetNativeSubAssemblyBase] 
/*
	Purpose: get Assembly Base for Hardware Matrix
	Modified By: Dien Bui 7/17/2018 - to get Native Subassembly from release
*/
(
	@SubAssemblyBase as varchar(10),
	@NativeRootID as int,
	@ProductVersionID as int,
	@ReleaseID as int = 0
)  

AS
	Declare @FusionRequirements bit
	Select @FusionRequirements = isnull(FusionRequirements,0) From ProductVersion Where id = @ProductVersionID

	if @FusionRequirements = 0
	begin
		Select pd.base as NativeSubassembly
		from product_delroot pd WITH (NOLOCK)
		where pd.deliverablerootid = @NativeRootID
		and pd.ProductVersionID = @ProductVersionID
		and pd.base is not null
	end
	else
	begin
		Select pdr.base as NativeSubassembly
		from product_delroot pd WITH (NOLOCK) inner join 
		product_delroot_release pdr WITH (NOLOCK) on pdr.ProductDelRootID = pd.ID
		where pd.deliverablerootid = @NativeRootID
		and pd.ProductVersionID = @ProductVersionID
		and pdr.base is not null
		and pdr.ReleaseID = @ReleaseID
	end


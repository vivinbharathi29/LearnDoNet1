﻿CREATE PROCEDURE [dbo].[spGetHardwareTeamAccessList] 
/* ************************************************************************************************
 * Purpose:
 * Created By:	
 * Modified By:	01/07/2016, SPathak - return the ODMSEPM
				10/03/2016, buidi   - add two new HWTeam: ODMHWPM and HWPC
				03/09/2018, wgomero - get HWPMRole and SWPMRoles, these roles will allow HW and SW PMs to Target SW and HW Components in a product: PBI187539.
  **************************************************************************************************/
(
	@EmployeeID int,
	@ProductID int =null
)
AS

Select 'ProgramCoordinator' as HWTeam, 1 as Products
from employee WITH (NOLOCK)
where ID = @EmployeeID
and programCoordinator =1

Union

Select 'PlatformDevelopment' as HWTeam, Count(1) as Products
from productversion WITH (NOLOCK)
where PlatformDevelopmentID = @EmployeeID
and productstatusid < 5

Union

Select 'Processor' as HWTeam, Count(1) as Products
from productversion WITH (NOLOCK)
where processorPMID = @EmployeeID
and productstatusid < 5

Union

Select 'Comm' as HWTeam, Count(1) as Products
from productversion WITH (NOLOCK)
where CommHWPMID = @EmployeeID
and productstatusid < 5

Union

Select 'VideoMemory' as HWTeam, Count(1) as Products
from productversion WITH (NOLOCK)
where VideoMemoryPMID = @EmployeeID
and productstatusid < 5

Union

Select 'GraphicsController' as HWTeam, Count(1) as Products
from productversion WITH (NOLOCK)
where GraphicsControllerPMID = @EmployeeID
and productstatusid < 5

Union

Select 'Commodity' as HWTeam, Count(1) as Products
from productversion WITH (NOLOCK)
where PDEID = @EmployeeID
and productstatusid < 5

Union

Select 'SupplyChain' as HWTeam, Count(1) as Products
from productversion WITH (NOLOCK)
where SupplyChainid = @EmployeeID
and id = @productid

union

Select 'SuperUser' as HWTeam, Count(1) as products
from productversion WITH (NOLOCK)
where (sepmid = @EmployeeID or PMID = @EmployeeID or SMID = @EmployeeID or TDCCMID = @EmployeeID)
and id = coalesce(@productid,ID)

union

Select 'ODMSEPM' as HWTeam, Count(1) as products
from productversion WITH (NOLOCK)
where (ODMSEPMID = @EmployeeID)
and id = coalesce(@productid,ID)

union

Select 'ODMHWPM' as HWTeam, Count(1) as products
from productversion WITH (NOLOCK)
where (ODMHWPMID = @EmployeeID)
and id = coalesce(@productid,ID)

union

Select 'HWPC' as HWTeam, Count(1) as products
from productversion WITH (NOLOCK)
where (HWPCID = @EmployeeID)
and id = coalesce(@productid,ID)

union

-- Check for HW targeting permission role
Select 'HWPMRole' as HWTeam, Count(1) as products
from RoleMembers r WITH (NOLOCK) 
    INNER JOIN Role_Object_Permission ro WITH (NOLOCK) ON r.RoleID = ro.RoleId
    INNER JOIN Permission p WITH (NOLOCK)  ON ro.PermissionID = p.PermissionID
WHERE
    r.userID = @EmployeeID AND p.Name ='HWTargeting.Edit'

union

-- Check for SW targeting permission role
Select 'SWPMRole' as HWTeam, Count(1) as products
from RoleMembers r WITH (NOLOCK) 
    INNER JOIN Role_Object_Permission ro WITH (NOLOCK) ON r.RoleID = ro.RoleId
    INNER JOIN Permission p WITH (NOLOCK)  ON ro.PermissionID = p.PermissionID
WHERE
    r.userID = @EmployeeID AND p.Name ='SWTargeting.Edit'







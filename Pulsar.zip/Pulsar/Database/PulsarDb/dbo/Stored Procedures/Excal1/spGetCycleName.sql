﻿

CREATE PROCEDURE [dbo].[spGetCycleName]
(
	@ID int
)
AS

	Select ID, Name, OTSCycleName, FullName
	From Program with (NOLOCK)
	where ID = @ID




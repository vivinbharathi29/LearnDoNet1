﻿

CREATE PROCEDURE [dbo].[spGetAppError]
(
	@ID int
)
 AS

SELECT
	a.RequestForm, 
	a.RequestQueryString, 
	a.ErrFile, 
	a.ErrLine, 
	a.ErrColumn, 
	a.ErrDescription, 
	a.ErrorDateTime, 
	a.HttpReferer AS Referrer, 
	a.AuthUser, 
	e.Email, 
    e.ID AS UserID, 
    e.Name AS Submitter, 
    a.ServerVariables
FROM
	AppError AS a with (NOLOCK) LEFT OUTER JOIN
	Employee AS e with (NOLOCK) ON a.AuthUser = e.Domain + '\' + e.NTName
WHERE
	(a.AppError_ID = @ID)




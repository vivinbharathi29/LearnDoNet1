﻿

CREATE PROCEDURE [dbo].[spGetDeliverableTester]
(
	@RootID int
)
AS

	Select e.id, e.Name, e.email
	from deliverableroot r with (NOLOCK), employee e with (NOLOCK)
	where e.id = testerid
	and r.id = @RootID


﻿

CREATE PROCEDURE [dbo].[spListArchiveCandidates]
(
	@TeamID int
)
AS

if @TeamID = 2
	Select v.id, v.deliverablename, v.version, v.revision, v.pass, v.tdcimagepath as Path1, v.path2location as Path2, v.path3location as Path3
	from deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK)
	where v.id not in (
					Select distinct v.id
					from productversion p with (NOLOCK), product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK)
					where p.productstatusid in (1,2,3)
					and pd.productversionid = p.id
					and v.id = pd.deliverableversionid
					)
	and v.id in (
				Select distinct v.id
				from productversion p with (NOLOCK), product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK)
				where pd.productversionid = p.id
				and v.id = pd.deliverableversionid
				)
	and r.id = v.deliverablerootid
	and r.typeid <> 1
	and coalesce(v.archivedtdc,0) <> 1
	and coalesce(actualreleasedate,releasedate) not between getDate()-365 and getDate()
	and (actualreleasedate is not null or releasedate is not null)
	and ConsumerReleaseStatus <> 0
	and tdcimagepath is not null 
	and tdcimagepath <> ''
	order by coalesce(actualreleasedate,releasedate)
	--order by tdcimagepath
else

	Select v.id, v.deliverablename, v.version, v.revision, v.pass, v.imagepath as Path1, v.path2location as Path2, v.path3location as Path3
	from deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK)
	where v.id not in (
					Select distinct v.id
					from productversion p with (NOLOCK), product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK)
					where p.productstatusid in (1,2,3)
					and pd.productversionid = p.id
					and v.id = pd.deliverableversionid
					)
	and v.id in (
				Select distinct v.id
				from productversion p with (NOLOCK), product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK)
				where pd.productversionid = p.id
				and v.id = pd.deliverableversionid
				)
	and r.id = v.deliverablerootid
	and r.typeid <> 1
	and coalesce(v.archived,0) <> 1
	and coalesce(actualreleasedate,releasedate) not between getDate()-365 and getDate()
	and (actualreleasedate is not null or releasedate is not null)
	and CommercialReleaseStatus <> 0
	and imagepath is not null 
	and imagepath <> ''
	order by coalesce(actualreleasedate,releasedate)
--	order by imagepath



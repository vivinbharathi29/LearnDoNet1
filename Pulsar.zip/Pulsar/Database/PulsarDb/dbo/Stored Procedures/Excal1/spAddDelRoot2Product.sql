﻿CREATE PROCEDURE [dbo].[spAddDelRoot2Product]
 (
  @ProductVersionID int,
  @DeliverableRootID int,
  @Preinstall bit = 0,
  @Preload bit = 0,
  @DropInBox bit = 0,
  @Web bit = 0,
  @Patch tinyint = 0,
  @RequirementID int = 0,
  @ProductVersionReleaseID int = 0,
  @UserID int = 0,
  @UserName varchar(80) = ''
 )
 AS
begin transaction

Declare @ReqID int

if @RequirementID = 0
  begin
	Select @ReqID = (Select ID
	From Product_Requirement WITH (NOLOCK)
	Where RequirementID = 1960
    And ProductID = @ProductVersionID)

    if @ReqID is null
	  begin
		Insert Product_Requirement (ProductID,RequirementID,Specification,DeliverablesSaved,CopyProductID)
		Values(@ProductVersionID,1960,'Deliverables that need to be assigned to other requirements',0,0)
		
		Select @ReqID = SCOPE_IDENTITY()
	  end
  end
else
  begin
    set @ReqID = @RequirementID
  end

DECLARE @RootCount int
DECLARE @CurrentDate datetime

Select @RootCount = Count(ID)
from product_DelRoot WITH (NOLOCK)
where ProductVersionId = @ProductVersionID 
and DeliverableRootID = @DeliverableRootID

if @RootCount = 0 -- if there is not one already added
	Begin
			
		Insert ProdReq_DelRoot (ProductRequirementID,DeliverableRootID)
		Values(@ReqID,@DeliverableRootID)

		Insert Product_DelRoot (ProductVersionID,DeliverableRootID,Preinstall,preload,dropinbox,web,patch,SelectiveRestore,ARCD,DRDVD,OSCD,DocCD,RACD_Americas,RACD_EMEA,RACD_APD,DeveloperNotificationStatus)
		Values(@ProductVersionID,@DeliverableRootID,@Preinstall,@Preload,@DropInBox,@Web,@Patch,0,0,0,0,0,0,0,0,1)

		declare @ProductDelRootID int
		set @ProductDelRootID = @@IDENTITY

		if @ProductVersionReleaseID > 0 
		begin
			Insert Into Product_DelRoot_Release(ProductDelRootID, ReleaseID) 
            Select @ProductDelRootID, ReleaseID From ProductVersion_Release Where ID = @ProductVersionReleaseID 

            Insert Into actionlog (ActionID, UserName, Updated, ProductVersionID, DeliverableRootID, Details, UserID, ProductVersionReleaseID)
            Select 17, @UserName, GetDate(), ProductVersionID, @DeliverableRootID, 'Add Product Version Release', @UserID, ID 
            From ProductVersion_Release Where ID = @ProductVersionReleaseID
		end
	end
Select @CurrentDate = getdate()

if @RootCount > 0 
	--Log
	INSERT INTO AppError (Category, ErrFile, ErrLine, AspDescription, ErrDescription, ErrorDateTime, AuthUser)
	VALUES ('User error', @ProductVersionID,@DeliverableRootID, '', 'user tried to add duplicate rocord in Product_DelRoot and Product_Requirement table', @CurrentDate, 'Dien Bui')

commit transaction

GO

﻿

CREATE PROCEDURE [dbo].[spGetActionProperties4Print] 
(@ID int)
AS
SELECT        
	v.PMID, v.OnlineReports, i.Americas, i.APJ, i.EMEA, i.Justification, i.Summary, i.Created, i.CategoryID, i.CoreTeamRep, i.OnStatusReport, i.PreinstallOwnerID, 
    v.Distribution AS CoreTeamEmail, i.Details, i.Submitter, i.Notify, i.ProductVersionID, i.Type, i.Status, i.OwnerID, i.TargetDate, i.ActualDate, i.Description, 
    i.Actions, i.Resolution, i.Distribution, i.AvailableForTest, i.AvailableNotes, i.Consumer, i.Commercial, i.SMB, i.BTODate, i.CTODate, i.RemoveChange, 
    i.ModifyChange, i.AddChange, i.GCD, i.Priority, i.AffectsCustomers, i.ReleaseNotification, v.dotsname AS ProductName, e.Name AS Owner, 
    e.Email AS OwnerEmail, c.Name AS CoreTeamRepText
FROM            
	DeliverableIssues AS i WITH (NOLOCK) INNER JOIN
    ProductVersion AS v WITH (NOLOCK) ON i.ProductVersionID = v.ID INNER JOIN
    ProductFamily AS f WITH (NOLOCK) ON v.ProductFamilyID = f.ID INNER JOIN
    Employee AS e WITH (NOLOCK) ON i.OwnerID = e.ID INNER JOIN
    CoreTeamRep AS c WITH (NOLOCK) ON i.CoreTeamRep = c.ID
WHERE        
	(i.ID = @ID)
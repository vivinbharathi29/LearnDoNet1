﻿
CREATE PROCEDURE [dbo].[spGetImageDefinitionFusion] 
(
	@ID int
)
AS

	Select d.id, dd.DriveName,  pd.name as ProductDrop , o.id as OSID,d.StatusID, d.ImageDriveDefinitionId, o.name as OS, [is].Name as Status, d.eoldate, d.RTMDate, d.ImageTypeID, t.Name as ImageTypeName, d.comments, isnull(osr.Id, 0) as OSReleaseId, isnull(osr.Description,'') as OSReleaseName
	from Imagedefinitions d WITH (NOLOCK) join 
		 ProductDrop1 pd WITH (NOLOCK) on pd.id = d.productdropid  join
		 Productversion_productdrop pvpd WITH (NOLOCK) on pvpd.productdropid = pd.id join
		 OSLookup o WITH (NOLOCK) on o.ID = d.osid join
		 ImageStatus [is] WITH (NOLOCK) on [IS].ID = d.statusid join
		 ImageType t WITH (NOLOCK) on t.id = d.ImageTypeID LEFT OUTER JOIN 
		 ImageDriveDefinition AS dd WITH (NOLOCK) ON d.ImageDriveDefinitionID = dd.ID left join
 		 OSRelease osr on d.OSReleaseId = osr.Id
		 
	where d.ID = @ID


﻿

CREATE PROCEDURE [dbo].[spAddOS2DelRoot]
 (
  @OSID int,
  @DeliverableRootID int
 )
 AS
 Insert OS_DelRoot (OSID,DeliverableRootID)
 Values(@OSID,@DeliverableRootID)




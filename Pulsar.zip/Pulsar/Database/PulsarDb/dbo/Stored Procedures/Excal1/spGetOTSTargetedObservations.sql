﻿/******************************************************************************
**	File: 
**	Name: 
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  02/15/2018	Santhana(auth\prabhuks) View Name changed from si_observation_report to SI_Observation_Report_Simplified 
**	17/12/2018	Monica					Open Query used to improve Remote Query performance 
*******************************************************************************/
CREATE PROCEDURE [dbo].[spGetOTSTargetedObservations] 
( 
   @ProductID int,
   @Report int =1
)
AS
SET NOCOUNT ON
DECLARE @Platform varchar(255)

SELECT @Platform = DOTSName FROM Productversion WITH (NOLOCK) where id = @ProductID

	DECLARE @OPENQUERY nvarchar(MAX), @TSQL nvarchar(4000), @LinkedServer nvarchar(4000)

		CREATE TABLE #remotequery([ObservationID] VARCHAR(200)
			,ProductFamily VARCHAR(2000)
			,[PrimaryProduct] VARCHAR(2000)
			,[Status] VARCHAR(2000)
			,[State]   VARCHAR(2000)
			,[Owner] VARCHAR(2000)
			,[Priority] VARCHAR(2000)
			,[Component] VARCHAR(2000)
			,[ComponentVersion] VARCHAR(2000)
			,[ShortDescription] VARCHAR(2000))
      
			IF @Platform IS NULL OR @Platform=''
			SELECT  @Platform='#'

	SET @LinkedServer = 'HOUSIREPORT01'
	SET @OPENQUERY = 'SELECT * FROM OPENQUERY('+ @LinkedServer + ','''

if @Report=1
BEGIN 

		SET @tsql=	'SELECT o.observationid,ProductFamily,PrimaryProduct, o.status, o.state, o.owner,o.priority,o.component ,o.ComponentVersion,o.shortdescription FROM [SIO].dbo.SI_Observation_Report_Simplified o	WHERE  	 (o.ProductFamily =  nullif('''''+@platform +''''',''''#'''')  or o.PrimaryProduct =  nullif('''''+@platform +''''',''''#'''') )	and o.status  = ''''Open'''''')' 

		INSERT INTO #remotequery
		EXEC (@OPENQUERY+@TSQL) 

		Select dv.id, dv.deliverablerootid as RootID, o.observationid, o.status, o.state, o.owner,
		o.priority,  dv.DeliverableName as Deliverable, o.component as OTSdeliverable, 
		dv.version, dv.revision, dv.pass,  o.ComponentVersion as OTSComponentVersion, 
		e.name as developer, o.shortdescription as summary
		FROM Product_deliverable pd WITH (NOLOCK)
		INNER JOIN  DeliverableVersion dv WITH (NOLOCK)
		ON pd.DeliverableVersionID = dv.ID
		INNER JOIN #remotequery o WITH (NOLOCK)
		ON o.Component = dv.DeliverableName
		INNER JOIN employee e WITH (NOLOCK)
		ON e.id = dv.developerid
		Where  pd.ProductVersionID = @ProductID
		and Targeted=1
		--and lower(o.cpqversion) <= lower(dv.version+','+dv.revision+','+dv.pass)
		--and (o.ProductFamily = @platform  or o.PrimaryProduct = @platform)
		--and o.status  = 'Open'
		Order by dv.deliverableName
END
else
BEGIN 

	--SET @tsql=	'SELECT o.observationid,ProductFamily,PrimaryProduct, o.status, o.state, o.owner,o.priority,o.component ,o.ComponentVersion,o.shortdescription FROM [SIO].dbo.SI_Observation_Report_Simplified o		WHERE  	 (o.ProductFamily = '''''+ @platform+'''''  or o.PrimaryProduct = '''''+@platform+''''')	and o.status  = ''''Open'''''')' 
		
	--	INSERT INTO #remotequery
	--	EXEC (@OPENQUERY+@TSQL) 

	Select dv.id, dv.deliverablerootid as RootID, o.observationid, o.status, 
	o.state, o.owner, o.priority,  dv.DeliverableName as Deliverable, 
	o.component as OTSdeliverable,  dv.version, dv.revision, dv.pass,  
	o.ComponentVersion as OTSComponentVersion,   e.name as developer, pd.TargetNotes, 
	o.shortdescription as summary
	FROM 		Product_deliverable pd WITH (NOLOCK)
		INNER JOIN DeliverableVersion dv WITH (NOLOCK) 
		ON pd.DeliverableVersionID = dv.ID
		INNER JOIN employee e WITH (NOLOCK) 
		ON e.id = dv.developerid
		LEFT OUTER JOIN HOUSIREPORT01.SIO.dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
		 ON o.Component = dv.DeliverableName
	Where
		pd.ProductVersionID = @ProductID
	and Targeted=1
	--and lower(o.cpqversion) <= lower(dv.version+','+dv.revision+','+dv.pass)
	and (o.ProductFamily = @platform  or o.PrimaryProduct = @platform)
	and o.status  = 'Open'
	Order by dv.deliverableName

END

SET NOCOUNT OFF

﻿

CREATE PROCEDURE [dbo].[spGetReferencePlatform]
(
	@ProdID int
)
 AS

Select f2.name + ' ' + v2.version as Name
from productversion v with (NOLOCK), productversion v2 with (NOLOCK), productfamily f2 with (NOLOCK)
where f2.id = v2.productfamilyid
and v2.id = v.referenceid
and v.id = @ProdID



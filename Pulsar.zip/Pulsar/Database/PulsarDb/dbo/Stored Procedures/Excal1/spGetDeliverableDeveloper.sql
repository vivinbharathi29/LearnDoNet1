﻿

CREATE PROCEDURE [dbo].[spGetDeliverableDeveloper]
(
	@VersionID int
)
 AS
Select e.Name as Developer, e.Email as DeveloperEmail, e2.Name as DevManager, e2.Email as DevManagerEmail
FROM DeliverableVersion v with (NOLOCK), Employee e with (NOLOCK), Employee e2 with (NOLOCK), DeliverableRoot r with (NOLOCK)
Where v.ID = @VersionID
and e.ID = v.Developerid
and e2.id = r.DevManagerID
and r.ID = v.DeliverableRootID




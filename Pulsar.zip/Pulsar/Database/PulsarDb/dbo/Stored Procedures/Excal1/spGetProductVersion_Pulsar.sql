﻿/** Change History       
**************************************************************************************************    
** SNo   Date        Author  Description      
** -    --------   -------   -------------------------    
**  1  27/3/2018	Aashish	 Changed the inner queries to INNER JOIN and Coalesce to ISNULL
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spGetProductVersion_Pulsar]

/* ************************************************************************************************
 * Purpose:  get the fields that display in the general tab of product property page 
 * Created By:  dave 
 * Modified By: Ywang, 2/6/2015, selected factory list need to be pulled differently as we store multiple factories
        santodip 9/3/2015 added - v.Created,v.CreatedBy,v.Updated,v.UpdatedBy to populate product properties
        spathak 11/16/2015 return the shared av program coordinator id 
        11/20/2015 - ADao return ProductRelease Column 
        buidi 11/30/2015 get new roles ODMSEPMID, ProcurementPMID, PlanningPMID, ODMPIMPMID 
        buidi 12/1/2015  combine 3 marketing roles into 1 
        ADao 01/22/2016  Return SCMOwnerID and EngineeringDataManagementId 
        ADao 02/02/2016  Link to Employee either v.PMID or v.TDCCMID or v.SCMOwnerID 
        02/19/2016 - Sruthi sort releases by year and month - task 16531 
        03/22/2016 - SPathak break the releases into month and year when saving the releases to the look up table and use those columns to sort
        08/04/2016 - Sruthi Ragishetti - Get SystemID based on the BAse unit groups selected for Product
        09/29/2016 - buidi - add ODM HW PM and HW PC 
        04/24/2017 - Malichi, Jason - BUG 124537 - Production: Add ability to enter End of Service Life and other data lost
          05/25/2017 - wgomero, return team roster approvers 
        03/23/2018 - buidi - Assign Lead Product Version Release to Release 
		08/16/2018 - buidi - null value for product lead release id cause product release deleted
 **************************************************************************************************/
(@ID INT) 
AS 
	SET NOCOUNT ON
    DECLARE @ProductRelease VARCHAR(max) 
    DECLARE @ProductReleaseIDs VARCHAR(max) 
	
    SET @ProductRelease = '' 
    SET @ProductReleaseIDs = '' 

    SELECT @ProductRelease = ISNULL(@ProductRelease + CASE Len(@ProductRelease 
                             ) WHEN 0 
                                    THEN '' ELSE ', ' 
                                    END, '') + NAME, 
           @ProductReleaseIDs = ISNULL(@ProductReleaseIDs + CASE Len( 
                                @ProductReleaseIDs) 
                                WHEN 0 THEN '' ELSE 
                                ', ' END, '') + Cast(pr.releaseid AS VARCHAR) + 
                                '-' 
                                + Cast(ISNULL(pr.leadproductreleaseid,0) AS VARCHAR) 
    FROM   productversion_release pr 
           INNER JOIN productversionrelease pv 
                   ON pr.releaseid = pv.id 
    WHERE  pr.productversionid = @ID 
    ORDER  BY pv.releaseyear DESC, 
              pv.releasemonth DESC 

    DECLARE @SystemBoardIDs VARCHAR(max) 

    SET @SystemBoardIDs = '' 

    SELECT @SystemBoardIDs = ISNULL(@SystemBoardIDs + CASE Len(@SystemBoardIDs 
                             ) WHEN 0 
                                    THEN '' ELSE ', ' 
                                    END, '') + systemid 
    FROM   (SELECT DISTINCT p.systemid 
            FROM dbo.platform p
			INNER JOIN dbo.productversion_platform pp
			ON p.platformid = pp.platformid
			AND pp.productversionid = @ID
            WHERE p.systemid <> '') t 

    --get Team Roster Approvers IDs 
    DECLARE @TeamRosterIDs NVARCHAR(max) 

    SELECT @TeamRosterIDs = ISNULL(@TeamRosterIDs + ',', '') 
                            + Cast(teamrosterid AS VARCHAR(2)) 
    FROM   product_teamrosterapprover WITH (nolock) 
    WHERE  productversionid = @ID; 

    SELECT v.rctosites, 
           v.rolloutp1, 
           v.rolloutp2, 
           v.rolloutp3, 
           v.baseunit, 
           v.oncommoditymatrix, 
           v.accessorypmid, 
           v.commoditylock, 
           v.currentrom, 
           v.ossupport, 
           v.imagepo, 
           v.imagechanges, 
           v.systemboardid, 
           v.machinepnpid, 
           v.commonimages, 
           v.certificationstatus, 
           v.partnerid, 
           p.NAME                    AS Partner, 
           v.regulatorymodel, 
           v.systemboardcomments, 
           v.machinepnpcomments, 
           v.swqastatus, 
           v.actionnotifylist, 
           v.platformstatus, 
           v.active, 
           v.emailactive, 
           v.approver, 
           v.sepmid, 
           v.division, 
           v.productname             AS NAME, 
           v.version, 
           v.productfamilyid, 
           e2.email                  AS SEPMEmail, 
           e2.NAME                   AS SEPMName, 
           e3.NAME                   AS SMName, 
           e3.email                  AS SMEmail, 
           allowsmr, 
           allowdeliverablereleases,
	   allowdcr,
	   AllowFollowMarketingName,
           allowimagebuilds, 
           v.fusion, 
           v.graphicscontrollerpmid, 
           v.dcrautoopen, 
           e.email                   AS PMEmail, 
           e.NAME                    AS PMName, 
           v.biosleadid, 
           v.pmid, 
           v.tdccmid, 
           v.smid, 
           v.distribution, 
           v.id, 
           v.pddreleased, 
           v.prdreleased, 
           v.dotsname, 
           v.cycle, 
           v.streetname, 
           v.description, 
           v.objectives, 
           v.typeid, 
           v.referenceid, 
           v.devcenter, 
           v.releaseteam, 
           v.sysengrprogramcoordinatorid, 
           v.productlineid, 
           productline.[description] AS ProductLineName, 
           bseg.[name]               AS BusinessSegmentName, 
           v.setestid, 
           v.wwanproduct, 
           v.toolaccesslist, 
           v.actionnotifylist, 
           v.servicelifedate, 
           ps.NAME                   AS ProductStatus, 
           v.productstatusid, 
           v.onlinereports, 
           v.sustaining, 
           v.brands, 
           ''                        AS ProductFilePath, 
           scmpath, 
           pddpath, 
           stlstatuspath, 
           accessorypath, 
           IDInformationPath, 
           programmatrixpath, 
           pdeid, 
           [ComMarketingID] = CASE 
                                WHEN Charindex('Commercial', bseg.[name]) > 0 
                                     AND Isnull(v.commarketingid, 0) > 0 THEN 
                                Isnull(v.commarketingid, 0) 
                                WHEN Charindex('Consumer', bseg.[name]) > 0 
                                     AND Isnull(v.consmarketingid, 0) > 0 THEN 
                                Isnull(v.consmarketingid, 0) 
                                ELSE 
                                  CASE 
                                    WHEN Isnull(v.commarketingid, 0) > 0 THEN 
                                    Isnull(v.commarketingid, 0) 
                                    WHEN Isnull(v.consmarketingid, 0) > 0 THEN 
                                    Isnull(v.consmarketingid, 0) 
                                    ELSE Isnull(v.smbmarketingid, 0) 
                                  END 
                              END, 
           v.consmarketingid, 
           v.smbmarketingid, 
           v.platformdevelopmentid, 
           v.supplychainid, 
           v.serviceid, 
           v.calldatalastupdated, 
           v.financeid, 
           v.currentwebrom, 
           v.preinstallteam, 
           v.sepe, 
           v.pinpm, 
           v.odmtestleadid, 
           v.wwantestleadid, 
           v.setestlead, 
           v.scfactoryengineerid, 
           v.commhwpmid, 
           v.videomemorypmid, 
           v.processorpmid, 
           v.sustainingmgrid, 
           v.preinstallcutoff, 
           v.sustainingsepmid, 
           v.pcid, 
           v.marketingopsid, 
           v.showonwhql, 
           v.dcrapproverlist, 
           isnull(v.businesssegmentid,0) as businesssegmentid, 
           v.fusionrequirements, 
           v.gplm, 
           v.spdm, 
           v.dcrdefaultowner, 
           v.svcbomanalyst, 
           v.rtmnotifications, 
           v.conveyorbuilddistribution, 
           v.conveyorreleasedistribution, 
           v.docpm, 
           v.dkcid, 
           dc.businessid, 
           dc.business, 
           dc.NAME                   AS DevCenterName, 
           v.agencyversion, 
           v.setestlead, 
           v.minrohslevel, 
           rohs.NAME                 AS MinRoHSLevelName, 
           v.affectedproduct, 
           v.bsamflag, 
           v.adddcrnotificationlist, 
           v.qualityid, 
           b.businessid              AS BrandBusinessID, 
           pb.lastpublishdt, 
           FactoryId = 0, 
           FactoryName = Stuff((SELECT ', ' + manufacturingsite.NAME 
                                FROM   manufacturingsite 
                                       INNER JOIN product_factory 
                                               ON 
                                       manufacturingsite.manufacturingsiteid = 
                                       product_factory.factoryid 
                                WHERE  product_factory.productversionid = v.id 
                                FOR xml path('')), 1, 2, ''), 
           v.autosimpleav, 
           v.programbusinessmanagerid, 
           v.isdesktop, 
           pfr.isplatformrtm, 
           v.created, 
           v.createdby, 
           v.updated, 
           v.updatedby, 
           RTPandEMDate = dbo.Ufn_producthasvalidscheduledate(@ID), 
           SharedAVMarketingPMID = v.sharedavmarketingid, 
           SharedAVPCID = v.sharedavpcid, 
           ProductRelease = @ProductRelease, 
           ProductReleaseIDs = @ProductReleaseIDs, 
           [ODMSEPMID] = Isnull(v.odmsepmid, 0), 
           [ProcurementPMID] = Isnull(v.procurementpmid, 0), 
           [PlanningPMID] = Isnull(v.planningpmid, 0), 
           [ODMPIMPMID] = Isnull(v.odmpimpmid, 0), 
           [HWPCID] = Isnull(v.hwpcid, 0), 
           [ODMHWPMID] = Isnull(v.odmhwpmid, 0), 
           [SCMOwnerId] = Isnull(v.scmownerid, 0), 
           [EngineeringDataManagementId] = 
           Isnull(v.engineeringdatamanagementid, 0), 
           SystemBoardIDs = @SystemBoardIDs, 
           v.servicelifedate, 
           TeamRosterApprovers = Isnull(@TeamRosterIDs, '') ,
		    bStableConsistent
    FROM   dbo.productversion v WITH (nolock) 
           INNER JOIN dbo.productfamily f WITH (nolock) 
                   ON v.productfamilyid = f.id 
           INNER JOIN dbo.employee e WITH (nolock) 
                   ON ( v.pmid = e.id 
                         OR v.tdccmid = e.id 
                         OR v.scmownerid = e.id ) 
           INNER JOIN employee e2 WITH (nolock) 
                   ON v.sepmid = e2.id 
           INNER JOIN employee e3 WITH (nolock) 
                   ON v.smid = e3.id 
           INNER JOIN productstatus ps WITH (nolock) 
                   ON v.productstatusid = ps.id 
           LEFT OUTER JOIN devcenter dc WITH (nolock) 
                        ON v.devcenter = dc.id 
           LEFT OUTER JOIN partner p WITH (nolock) 
                        ON v.partnerid = p.id 
           LEFT OUTER JOIN product_brand pb WITH (nolock) 
                        ON pb.productversionid = v.id 
           LEFT OUTER JOIN brand b WITH (nolock) 
                        ON b.id = pb.brandid 
           LEFT OUTER JOIN rohs WITH (nolock) 
                        ON v.minrohslevel = rohs.id 
           LEFT OUTER JOIN productline WITH (nolock) 
                        ON v.productlineid = productline.id 
           LEFT OUTER JOIN businesssegment bseg WITH (nolock) 
                        ON v.businesssegmentid = bseg.businesssegmentid 
           LEFT OUTER JOIN productversion_platformrtmstatus pfr WITH (nolock) 
                        ON v.id = pfr.productversionid 
    WHERE  v.id = @ID 
SET NOCOUNT OFF
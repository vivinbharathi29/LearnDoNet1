﻿

/****** Object:  Stored Procedure dbo.spAddNewMilestone    Script Date: 9/26/00 7:13:22 PM ******/
CREATE PROCEDURE [dbo].[spAddNewMilestone]
 (
  @Milestone varchar(255),
   @PhaseID int,
  @NewID int Output
 )
As
 declare @NewOrder int
 Select @NewOrder = Max(OrderID) From MilestoneLookup WITH (NOLOCK)
 if @NewOrder is null
  Select @NewOrder = 1
 else
  Select @NewOrder = @NewOrder + 1
 Insert MilestoneLookup(Milestone,OrderID,PhaseID)
 Values (@Milestone,@NewOrder,@PhaseID) 
 SELECT @NewID = SCOPE_IDENTITY()
 return


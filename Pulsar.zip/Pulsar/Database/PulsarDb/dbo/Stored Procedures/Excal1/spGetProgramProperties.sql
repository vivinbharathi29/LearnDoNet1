﻿

CREATE PROCEDURE [dbo].[spGetProgramProperties]
(
	@ProgramID int
)
 AS
Select ID, Name, Active, CurrentProgram,ProgramGroupID, OTSCycleName, FullName
FROM Program with (NOLOCK)
Where ID = @ProgramID


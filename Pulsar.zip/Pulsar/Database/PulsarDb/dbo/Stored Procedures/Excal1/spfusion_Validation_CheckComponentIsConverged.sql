﻿CREATE PROCEDURE [dbo].[spfusion_Validation_CheckComponentIsConverged]
    @RootID int,
	@VersionID int,
	@IsConverged bit OUTPUT
AS
BEGIN
Declare @IrsCategoryID int,
		@CdFiles bit,
		@IsoImage bit,
		@Ar bit,
		@InternalTool bit,
		@Preinstall bit,
		@Patch bit,
		@SoftPaq bit,
		@Binary bit,
		@PreinstallROM bit,
		@SwPartNumber varchar(18),
        @TransferServerId int,
        @BaseFilePath varchar(1024),
		@SkarServer int,
		@rowCount int,
		@RootComponentTypeID int,
        @HWComponentTypeID int
		

   select @IrsCategoryID = c.IrsCategoryId  
     from ComponentRoot r WITH (NOLOCK)
left join ComponentCategory c WITH (NOLOCK)
       on r.ComponentCategoryId = c.CategoryId
    where r.ComponentRootId = @RootID



select @CDFiles = CdFiles, 
       @IsoImage = IsoImage, 
	   @Ar = Ar, 
	   @InternalTool = InternalTool,
	   @Preinstall = Preinstall,
	   @Patch = Patch,
	   @SoftPaq = SoftPaq,
	   @Binary = Binary,
	   @PreinstallROM = PreinstallROM 
  from ComponentVersion WITH (NOLOCK)
 where ComponentVersionID = @VersionID

	if @CDFiles IS NULL        set @CDFiles = 0
	if @IsoImage IS NULL       set @IsoImage = 0
	if @Ar IS NULL             set @Ar = 0
	if @InternalTool IS NULL   set @InternalTool = 0
	if @Preinstall IS NULL     set @Preinstall = 0
	if @Patch IS NULL          set @Patch = 0
	if @SoftPaq IS NULL        set @SoftPaq = 0
	if @Binary IS NULL         set @Binary = 0
	if @PreinstallROM IS NULL  set @PreinstallROM = 0


if (@IrsCategoryID > 0)
begin
	Select @RootComponentTypeID = ComponentTypeID 
	  from ComponentRoot WITH (NOLOCK) where ComponentRootID = @RootID
    select @HWComponentTypeID = ComponentTypeId 
	  from ComponentType WITH (NOLOCK) where Name = 'Hardware'
	if (@RootComponentTypeID <> @HWComponentTypeID)
	begin
		select @SwPartNumber = SwPartNumber, @TransferServerId = TransferServerId, @BaseFilePath = BaseFilePath from ComponentVersion WITH (NOLOCK) where ComponentversionID = @VersionID
		if (@InternalTool = 1 And @Preinstall = 0 And @CdFiles = 0 And @IsoImage = 0 And @Ar = 0 And @Softpaq = 0 And @Patch = 0) --!Softpaq
			set @IsConverged = 0;		
		else if ((@Patch = 1 Or @SoftPaq = 1) And @Preinstall = 0 And @CdFiles = 0 And @IsoImage = 0 And @Ar = 0 And @Binary = 0 And @PreinstallROM = 0)
			set @IsConverged = 0;
		else if (((@SwPartNumber IS NOT NULL) And (LEN(LTRIM(RTRIM(@SwPartNumber))) > 0)) And (@SwPartNumber <> 'N/A' Or @SwPartNumber = 'Pending...') And @VersionID > 0)
			set @IsConverged = 1;
		else if (((LEN(LTRIM(RTRIM(@SwPartNumber))) = 0) Or (@SwPartNumber IS NULL) Or (@SwPartNumber = 'N/A')) And @VersionID > 0)
			set @IsConverged = 0;
		else if (@TransferServerID > 0)
		begin
			select @rowCount = count(*) from ComponentVersion WITH (NOLOCK) where ComponentversionId = @VersionID 
			if (@rowCount > 0)
			begin
				select @SkarServer = SkarServer from ComponentTransferServer WITH (NOLOCK) where Id = @TransferServerId
				if (@SkarServer = 0) --!@SkarServer
					set @IsConverged = 0;
				else
					set @IsConverged = 1;
			end
			else
			begin
				if((@BaseFilePath IS NULL) Or (LEN(LTRIM(RTRIM(@BaseFilePath)))) = 0)
					set @IsConverged = 0;
				else 
					set @IsConverged = 1;
			end
		end
		else if  (((@BaseFilePath IS NULL) Or ((LEN(LTRIM(RTRIM(@BaseFilePath)))) = 0)) And @VersionID > 0)
			set @IsConverged = 0;
		else
			set @IsConverged = 1;
	end
	else
		set @IsConverged = 1;
end
else
	set @IsConverged = 0;

return @IsConverged;
END
Go   
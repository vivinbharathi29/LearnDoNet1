﻿
CREATE PROCEDURE [dbo].[spgetBrandSeries4]
(
	@SeriesID int,
	@NewSeries varchar(50) = '',
	@OldBrandID as integer,
	@NewBrandID as integer
)
AS

	Select *
	from 
	(
	SELECT		  1 as ID, b.Streetname as OldStreetname, 
					  s.Name as OldSeries,
					  b.Suffix as OldSuffix,
					  case when coalesce(v.version,'') = ''  then v.dotsname else left(v.dotsname,len(v.dotsname) - len(v.version) - 1) end AS Family,
					  v.Version,
					  b.RASSegment as OldRASSegment,
					  COALESCE (b.Streetname, '') + ' ' + COALESCE (s.Name, '') + ' ' + COALESCE (b.Suffix, '') AS OldMarketingLongName,
					  case b.ShowSeriesNumberInShortName when 1 then COALESCE (b.StreetName2, '') + ' ' + COALESCE (s.Name, '') else COALESCE (b.StreetName2, '') end AS OldMarketingShortName,
					  case b.ShowSeriesNumberInLogoBadge when 1 then COALESCE (b.StreetName3, '') + ' ' + COALESCE (dbo.ufnVal(s.Name,~SplitSeriesForLogoAndBrand), '') else COALESCE (b.StreetName3, '') end AS OldLogoBadge,
					  case b.ShowSeriesNumberInBrandname when 1 then COALESCE (b.StreetName, '') + ' ' + COALESCE (dbo.ufnVal(s.Name,~SplitSeriesForLogoAndBrand), '') else COALESCE (b.StreetName, '') end AS OldBrandName
		FROM dbo.Product_Brand pb with (NOLOCK), dbo.Brand b with (NOLOCK) ,dbo.Series s with (NOLOCK), dbo.ProductFamily f with (NOLOCK), dbo.ProductVersion v with (NOLOCK)
		WHERE s.ID = @SeriesID
		and @OldBrandID = b.ID
		and pb.ID = s.ProductBrandID
		and pb.ProductVersionID = v.ID
		and v.ProductFamilyID = f.ID
		) old,
		(
		SELECT		  1 as ID, b.Streetname as NewStreetname, 
					  @NewSeries as NewSeries,
					  b.Suffix as NewSuffix,
					  b.RASSegment as NewRASSegment,
					  COALESCE (b.Streetname, '') + ' ' + COALESCE (@NewSeries, '') + ' ' + COALESCE (b.Suffix, '') AS NewMarketingLongName, 
					  case b.ShowSeriesNumberInShortName when 1 then COALESCE (b.StreetName2, '') + ' ' + COALESCE (@NewSeries, '') else COALESCE (b.StreetName2, '') end  AS NewMarketingShortName,
					  case b.ShowSeriesNumberInLogoBadge when 1 then COALESCE (b.StreetName3, '') + ' ' + COALESCE (dbo.ufnVal(@NewSeries,~SplitSeriesForLogoAndBrand), '') else COALESCE (b.StreetName3, '') end AS NewLogoBadge,
					  case b.ShowSeriesNumberInBrandname when 1 then COALESCE (b.StreetName, '') + ' ' + COALESCE (dbo.ufnVal(@NewSeries,~SplitSeriesForLogoAndBrand), '') else COALESCE (b.StreetName, '') end AS NewBrandName
		FROM dbo.Product_Brand pb with (NOLOCK), dbo.Brand b with (NOLOCK) ,dbo.Series s with (NOLOCK), dbo.ProductFamily f with (NOLOCK), dbo.ProductVersion v with (NOLOCK)
		WHERE s.ID = @SeriesID
		and @NewBrandID = b.ID
		and pb.ID = s.ProductBrandID
		and pb.ProductVersionID = v.ID
		and v.ProductFamilyID = f.ID
		) new
	where old.id = new.id




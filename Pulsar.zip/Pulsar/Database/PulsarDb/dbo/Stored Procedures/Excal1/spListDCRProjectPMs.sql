﻿

CREATE PROCEDURE [dbo].[spListDCRProjectPMs]

AS

	Select Distinct e.id, e.email, e.name
	from employee e with (NOLOCK), productversion p with (NOLOCK)
	where (p.smid = e.id )
	and p.ID in (344,347,1107)



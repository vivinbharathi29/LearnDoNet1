﻿

CREATE PROCEDURE [dbo].[spGetFirstMilestone]
	(
		@DeliverableVersionID int
	)
AS
	Select ID, Milestone
	FROM DeliverableSchedule with (NOLOCK)
	Where DeliverableVersionID = @DeliverableVersionID
	and MilestoneOrder = 1




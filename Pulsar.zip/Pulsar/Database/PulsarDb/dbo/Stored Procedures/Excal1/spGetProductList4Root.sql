﻿

CREATE PROCEDURE [dbo].[spGetProductList4Root] (@ID int)
 AS
SELECT v.ID, v.productName as name, v.Version,v.streetname, l.PostRTMStatus, v.sepmid, v.AllowSMR
FROM  ProductVersion v with (NOLOCK), Product_DelRoot l with (NOLOCK), ProductFamily f with (NOLOCK)
WHERE v.ID = l.ProductVersionID
AND v.ProductFamilyID = f.ID
AND l.DeliverableRootID = @ID
Order by v.dotsname






﻿
CREATE PROCEDURE [dbo].[spListComponentsToPutInIRSProductDrop]
/* ************************************************************************************************
 * Purpose: ExcaliburWeb - IRS Component Update List
 * Created By:	?
 * Modified By: 06/29/2016 Herb, 1.Performanced. 2.take FeatureID to find OS when Pulsar Product.
 **************************************************************************************************/

(
	@SortField int = 2,
	@lstProductId varchar(max) = ''
)

AS

select 
	PartNumber,
	DeliverableName,
	Version,
	Revision,
	Pass,
	Product,
	ProductID,
	ImageSummary,
	VersionID,
	targetnotes,
	PreviousVersionCount,
	PreviousVersionPartNumbers,
	TransferStatus,
	TransferDescription,
	dbo.ufn_ListOS4IRSComponentUpdateList(FusionRequirements,ProductID,Images)  as OSList,
	case @SortField
		when 0 then IRSPartNumber
		when 1 then CAST(VersionId AS VARCHAR(8)) 
		when 3 then CAST(displayorder AS VARCHAR(8)) 
		else deliverableName + Version + Revision + pass
	end as orderby

from 
	(
	SELECT
		COALESCE(v.IRSPartNumber, v.partnumber, '') AS PartNumber,
		v.DeliverableName,
		v.Version,
		v.Revision,
		v.Pass,
		p.DOTSName AS Product,
		p.ID AS ProductID,
		pd.ImageSummary,
		v.id AS VersionID,
		pd.targetnotes,
		CAST(pd.images AS VARCHAR(MAX)) AS Images,
		dbo.ufn_GetPreviousVersionsInImage(pd.Productversionid, pd.deliverableversionid) AS PreviousVersionCount,
		dbo.ufn_GetPreviousVersionPartNumbersInImage(pd.Productversionid, pd.deliverableversionid) AS PreviousVersionPartNumbers,
		t.ShortName AS TransferStatus,
		t.description AS TransferDescription,
		pd.id AS ProductDeliverableID,
		v.irsID AS IRSComponentPassID,
		CASE
			WHEN pd.Preinstall = 1 OR
				pd.preload = 1 THEN 1
			ELSE 0
		END AS SRP,
		CASE
			WHEN pd.arcd = 1 OR
				pd.drdvd = 1 THEN 0
			ELSE 1
		END AS NotInRCD,
		CAST(pd.SelectiveRestore AS INT) AS InAppRecovery,
		CAST(pd.dropinbox AS INT) AS DIB,
		v.DeliverableRootID,
		v.irspartnumber,
		t.displayorder,
		p.FusionRequirements
	FROM Product_Deliverable pd WITH (NOLOCK)
	JOIN ProductVersion p WITH (NOLOCK)
		ON p.ID = pd.ProductVersionID
	JOIN DeliverableVersion v WITH (NOLOCK)
		ON v.id = pd.deliverableversionid
	JOIN IRSTransferStatus t WITH (NOLOCK)
		ON t.ID = v.IRSFilesCopied

	WHERE 
	pd.ID>0
	and p.ID in (SELECT * FROM dbo.Split(@lstProductId)) 
	and PreInstallStatus = -1
	AND p.PreinstallTeam = 1
	AND inimage = 0
	AND p.Fusion = 1
	AND (pd.Preinstall = 1
	OR pd.Preload = 1
	OR pd.SelectiveRestore = 1
	OR pd.arcd = 1
	OR pd.drdvd = 1) 

	UNION 


	SELECT * 
	FROM 
		(
		SELECT
			COALESCE(v.IRSPartNumber, v.partnumber, '') AS PartNumber,
			v.DeliverableName,
			v.Version,
			v.Revision,
			v.Pass,
			p.DOTSName AS Product,
			p.ID AS ProductID,
			pd.ImageSummary,
			v.id AS VersionID,
			pd.targetnotes,
			CAST(pd.images AS VARCHAR(MAX)) AS Images,
			-1 AS PreviousVersionCount,
			'' AS PreviousVersionPartNumbers,
			t.ShortName AS TransferStatus,
			t.description AS TransferDescription,
			pd.id AS ProductDeliverableID,
			v.irsID AS IRSComponentPassID,
			CASE
				WHEN pd.Preinstall = 1 OR
					pd.preload = 1 THEN 1
				ELSE 0
			END AS SRP,
			CASE
				WHEN pd.arcd = 1 OR
					pd.drdvd = 1 THEN 0
				ELSE 1
			END AS NotInRCD,
			CAST(pd.SelectiveRestore AS INT) AS InAppRecovery,
			CAST(pd.dropinbox AS INT) AS DIB,
			v.DeliverableRootID,
			v.irspartnumber,
			t.displayorder,
			p.FusionRequirements
		FROM	
		Product_Deliverable pd WITH (NOLOCK) 
		inner join DeliverableVersion v WITH (NOLOCK) on pd.Deliverableversionid = v.id
		inner join ProductVersion p WITH (NOLOCK) on pd.ProductVersionID = p.ID
		inner join ProductFamily f WITH (NOLOCK) on f.Id = p.ProductFamilyID
		inner join IRSTransferStatus t WITH (NOLOCK) on t.ID = v.IRSFilesCopied


		WHERE 
		pd.ID>0 
		AND p.ID in (SELECT * FROM dbo.Split(@lstProductId))
		AND (pd.Targeted = 0 OR CAST(pd.images AS VARCHAR(5000)) = '0,'
			OR 
			(pd.Preinstall = 0
				AND pd.Preload = 0
				AND pd.SelectiveRestore = 0
				AND pd.drdvd = 0
				AND pd.arcd = 0)
		)
		AND (InImage = 1 OR inpinimage = 1)
		AND p.PreinstallTeam = 1
		AND p.Fusion = 1
		AND p.AllowImageBuilds = 1
		AND (pd.PreInstallStatus = -1 OR pd.PreinstallStatus = 0 
				OR 
				(inpinimage = 1 AND pd.Preinstall = 0 AND pd.Preload = 0 AND pd.SelectiveRestore = 0 AND pd.drdvd = 0 AND pd.arcd = 0)
			)
		) as Q
	WHERE dbo.[ufn_GetVersionsTargetedOnProductForRoot](DeliverableRootID, ProductID) = 0 
	) as result

ORDER BY 
orderby , Product,ProductID



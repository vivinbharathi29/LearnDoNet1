﻿

CREATE PROCEDURE  [dbo].[spGetSIWorkingNotes]
(
	@ID int
)
AS

	Select Create_Date as [Log Date], Created_By as [user name], Description as [New_Value] 
	from [$(SIO_Server)].[$(SIO_Database)].dbo.updates with (NOLOCK)
	where object_ID = @ID
	order by Create_Date desc	


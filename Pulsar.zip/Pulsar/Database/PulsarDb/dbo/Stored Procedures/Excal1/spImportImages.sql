﻿

CREATE PROCEDURE [dbo].[spImportImages] 
(
	@OldID int,
	@NewID int
)
AS
insert Images(ImageDefinitionID,Priority,RegionID,Modified,CopyID)
Select @NewID, Priority, RegionID,getDate(),ID
from Images with (NOLOCK)
Where ImageDefinitionID = @OldID






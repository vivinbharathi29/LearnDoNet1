﻿

CREATE PROCEDURE [dbo].[spLinkProductToProgram]
 (
  @Program int,
  @Product int
 )
 AS
Insert Product_program(ProgramID, ProductVersionID)
Values(@Program,@Product)




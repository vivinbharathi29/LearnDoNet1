﻿

CREATE PROCEDURE [dbo].[spGetDistributionRoot]
(
	@ProdID int,
	@RootID int
)
 AS
Select Pd.DRDVD, pd.RACD_Americas,pd.RACD_EMEA,pd.RACD_APD,pd.DocCD,pd.OSCD ,PD.Preinstall,  pd.PreinstallBrand, PD.Preload, pd.Patch, pd.MinImageRecovery,pd.PreloadBrand, PD.Web, PD.DropInBox as DIB, pd.ARCD,pd.SelectiveRestore, r.ar, PD.ImageSummary, PD.Images, pd.RestoreImages, r.typeid, r.rompaq, r.softpaq, r.scriptpaq,r.floppydisk, r.cdimage, r.preinstallrom,r.ISOImage, r.preinstall as Preinstalldev
FROM Product_DelRoot pd with (NOLOCK), DeliverableRoot r with (NOLOCK)
Where pd.ProductVersionID = @ProdID
and pd.DeliverableRootID = @RootID
and r.id = pd.DeliverableRootID


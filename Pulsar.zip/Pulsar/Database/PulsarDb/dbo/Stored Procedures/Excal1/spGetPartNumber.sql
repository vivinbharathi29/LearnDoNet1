﻿

CREATE PROCEDURE [dbo].[spGetPartNumber]
(
	@VersionID int,
	@ProductID int
)
 AS
Select PartNumber, InImage, InPINImage, PreinstallInternalRev, PreinstallInternalRevSkipped
from Product_Deliverable with (NOLOCK)
where Productversionid = @ProductID
and Deliverableversionid = @VersionID




﻿

CREATE PROCEDURE [dbo].[spGetCycleIconRule]
(
	@ProductID int = null
)
AS

	Declare @RuleCount int
	DECLARE @ProgramID int

	Select @ProgramID = max(ProgramID)
	from Product_Program with (NOLOCK)
	where productversionid = @ProductID

	Select @RuleCount = count(1)
	from iconrules ir with (NOLOCK), Program p with (NOLOCK)
	where ir.ID = p.iconruleid
	and p.ID = @ProgramID 
	
	if @RuleCount = 0
		Select distinct ir.id, ir.[Rule]
		from iconrules ir with (NOLOCK)
		where ir.active=1
		order by ir.id desc	
	else
		Select distinct ir.id, ir.[Rule]
		from iconrules ir with (NOLOCK), Program p with (NOLOCK)
		where ir.ID = p.iconruleid
		and p.ID = @ProgramID 
		order by ir.id desc


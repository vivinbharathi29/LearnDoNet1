﻿

CREATE PROCEDURE [dbo].[spGetActionRoadmapItemProperties] 
(
	@ID int
)
AS

Select ID, ProductVersionID, OwnerID, Summary,  Timeframe, OriginalTimeframe, TimeframeNotes, DisplayOrder,Notes, ActionStatusID, StatusReport, Details
from actionroadmap with (NOLOCK)
where id = @ID








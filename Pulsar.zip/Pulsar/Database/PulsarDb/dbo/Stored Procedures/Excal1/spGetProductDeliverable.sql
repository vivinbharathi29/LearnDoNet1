﻿/**************************************************************************************************
** Change History    
**************************************************************************************************
** SNo   Date        Author  Description    
** --    --------   -------   -------------------------    
**  1    14/8/2018	Aashish	  Changed to ANSI. Added SET NOCOUNT
****************************************************************************************************/
CREATE PROCEDURE [dbo].[Spgetproductdeliverable] (@ProductID     INT, 
                                                             @DeliverableID INT) 
AS 

SET NOCOUNT ON

    SELECT pd.ID, 
           p.dotsname        AS Product, 
           d.Deliverablename AS Deliverable 
    FROM   product_deliverable pd WITH (nolock) 
           INNER JOIN productversion p WITH (nolock) 
                   ON pd.productversionid = p.id 
           INNER JOIN deliverableversion d WITH (nolock) 
                   ON pd.deliverableversionid = d.id 
    WHERE  pd.productversionid = @ProductID 
           AND pd.deliverableversionid = @DeliverableID 

SET NOCOUNT OFF
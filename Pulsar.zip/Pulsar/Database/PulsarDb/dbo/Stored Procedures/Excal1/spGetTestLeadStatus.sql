﻿--Modified By: Dean Chiang 19/2/2019 - Add new item "Update DEV Test Status..." in the Product Deliverable page -PBI30309

CREATE PROCEDURE [dbo].[spGetTestLeadStatus]
(
	@ProductID int,
	@VersionID int,
	@FieldID int
)
AS

If @FieldID = 2
	Select v.dotsname as Product, ODMUnitsReceived as UnitsReceived, ODMTestNotes as TestNotes, ODMTestStatus as TestStatus
	from product_deliverable pd with (NOLOCK), productversion v with (NOLOCK)
	where v.id = pd.productversionid
	and pd.productversionid=@ProductID
	and pd.deliverableversionid=@VersionID
else if @FieldID=3
	Select v.dotsname as Product, WWANUnitsReceived as UnitsReceived, WWANTestNotes as TestNotes, WWANTestStatus as TestStatus
	from product_deliverable pd with (NOLOCK), productversion v with (NOLOCK)
	where v.id = pd.productversionid
	and pd.productversionid=@ProductID
	and pd.deliverableversionid=@VersionID
else if @FieldID=4
	Select v.dotsname as Product, DeveloperNotificationStatus as UnitsReceived, DeveloperTestNotes as TestNotes, DeveloperTestStatus as TestStatus
	from product_deliverable pd with (NOLOCK), productversion v with (NOLOCK)
	where v.id = pd.productversionid
	and pd.productversionid=@ProductID
	and pd.deliverableversionid=@VersionID
else
	Select v.dotsname as Product, IntegrationUnitsReceived as UnitsReceived, IntegrationTestNotes as TestNotes, IntegrationTestStatus as TestStatus
	from product_deliverable pd with (NOLOCK), productversion v with (NOLOCK)
	where v.id = pd.productversionid
	and pd.productversionid=@ProductID
	and pd.deliverableversionid=@VersionID


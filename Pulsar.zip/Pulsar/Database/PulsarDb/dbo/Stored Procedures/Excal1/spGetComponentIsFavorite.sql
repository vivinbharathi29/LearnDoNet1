﻿CREATE PROCEDURE [dbo].[spGetComponentIsFavorite]
(
	@EmployeeID INT,
	@RootID INT
)
AS

	SELECT 
	     CAST(COUNT(1) AS BIT) AS IsFavorite
	FROM UserFavorite
	WHERE 
	     UserId = @EmployeeID
		AND FavoriteType = 1 -- Component
		AND FavoriteItemId = @RootId
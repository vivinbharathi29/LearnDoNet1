﻿
CREATE PROCEDURE [dbo].[spGetVendorName]

(
	@ID int --VendorID
)

 AS

Select ID, Name
from vendor with (NOLOCK)
where ID = @ID


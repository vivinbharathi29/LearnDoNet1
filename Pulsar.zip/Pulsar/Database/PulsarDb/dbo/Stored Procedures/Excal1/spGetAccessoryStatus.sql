﻿
CREATE PROCEDURE [dbo].[spGetAccessoryStatus]

(
	@ProdID int,
	@VersionID int
)
 AS

Select pd.id, ps.name as pilotstatus, pd.AccessoryStatusID, pd.accessorynotes, pd.accessorydate, pd.accessoryleveraged, pd.targetNotes,  pv.devcenter, pd.PilotNotes, t.status as TestStatus, pd.TestStatusID, pd.TestDate, pd.PilotDate, r.name as DeliverableName, r.KitDescription, r.kitnumber, v.version, v.revision, v.pass, v.modelnumber, v.partnumber, vd.name as vendor, pv.dotsname as Product
from 
productfamily f with (NOLOCK)
inner join productversion pv with (NOLOCK) on f.ID = pv.ProductFamilyID
inner join product_deliverable pd with (NOLOCK) on pv.ID = pd.ProductVersionID
inner join deliverableversion v with (NOLOCK) on pd.DeliverableVersionID = v.id
inner join vendor vd with (NOLOCK) on v.VendorID = vd.ID
inner join deliverableroot r with (NOLOCK) on v.DeliverableRootID = r.ID
inner join pilotstatus ps with (NOLOCK) on pd.PilotStatusID = ps.id
left outer join TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
where 
pd.productversionid = @ProdID
and pd.deliverableversionid = @VersionID

﻿

CREATE PROCEDURE [dbo].[spAddDelRootWeb1]
 (
  @Name varchar(50),
  @NewID int OUTPUT
 )
 AS
 Insert DeliverableRoot  (Name)
 Values(@Name)
 Select @NewID = SCOPE_IDENTITY()




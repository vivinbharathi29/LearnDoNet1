﻿
CREATE PROCEDURE [dbo].[spFusion_HWCOMPONENT_UpdateSystemboardInIRS]
/* ************************************************************************************************
 * Purpose:	Adds a HW Component to IRS
--- <param name="ProductID">Product Version ID</param>
--- <param name="AvDetailProductBrandId">AvDetail_ProductBrand ID</param>
--- <param name="Updated">User ID for the person updating the record</param>
 * Created By:	Unknow
 **************************************************************************************************/
(
	@ProductID int = null,
	@AvDetailProductBrandId int = null,
	@Updater int = null
)
AS
    DECLARE @PlatformID int
    DECLARE @PlatformName as varchar(80)
    DECLARE @OwnerID int
    DECLARE @BusinessSegment int
    DECLARE @PartNumber as varchar(30)
    DECLARE @VendorID as int
    DECLARE @HWRevision as varchar(10)
    DECLARE @Version as varchar(10)
    DECLARE @UpdateBy as varchar(120)
    DECLARE @Rework as varchar(10)
    DECLARE @XMLInput as varchar(MAX)
    DECLARE @ComponentName as varchar(120)
    DECLARE @SiteID as varchar(10)
    DECLARE @SystemboardID as varchar(30)
    DECLARE @MaxMemorySize as varchar(30)
    DECLARE @CMOSID int
    DECLARE @ProcessorID int
    DECLARE @ChipSetID int
    DECLARE @NorthBridgeID int
    DECLARE @SouthBridgeID int
    DECLARE @StepID int
    DECLARE @IRSID int
    DECLARE @ExcaliburRootID int
    DECLARE @ProdDelRootID int

    SELECT @UpdateBy = Name FROM Employee WITH (NOLOCK) WHERE ID = COALESCE(@Updater,0)
    IF @UpdateBy IS NULL
        SELECT @UpdateBy = 'Excalibur'


    SET @HWRevision = '379'
    SET @Version = '1'
    SET @Rework = ''
    SET @SystemboardID = 'XXXX'
    SET @MaxMemorySize = 'N/A'

    -- Load Values from IRS
    SELECT @CMOSID = hwvalidationid FROM IRS_hwvalidation WITH (NOLOCK) WHERE attributeid = 117 AND validationvalue = 'None'
    SELECT @ProcessorID = hwvalidationid FROM IRS_hwvalidation WITH (NOLOCK) WHERE attributeid = 112 AND validationvalue = 'Not Applicable'
    SELECT @ChipSetID = hwvalidationid FROM IRS_hwvalidation WITH (NOLOCK) WHERE attributeid = 94 AND validationvalue = 'Not Applicable'
    SELECT @StepID = hwvalidationid FROM IRS_hwvalidation WITH (NOLOCK) WHERE attributeid = 104 AND validationvalue = '0'
    SELECT @NorthBridgeID = hwvalidationid FROM IRS_hwvalidation WITH (NOLOCK) WHERE attributeid = 101 AND validationvalue = 'NorthBridge'
    SELECT @SouthBridgeID = hwvalidationid FROM IRS_hwvalidation WITH (NOLOCK) WHERE attributeid = 101 AND validationvalue = 'SouthBridge'

    -- Make sure we have every thing we need to execute.
    IF (@AvDetailProductBrandId is not null or @ProductID is not null) and @NorthBridgeID is not null and @SouthBridgeID is not null and @CMOSID is not null and @ProcessorID is not null and @ChipsetID is not null and @StepID is not null
        BEGIN
		Print 'Loading Cursor'
		print @AvDetailProductBrandId
		print @ProductID
        DECLARE IRSDB_CURSOR CURSOR FOR
        SELECT LEFT(av.gpgdescription,40),
               avpb.IRSPlatformID,
               pv.DOTSName,
               CASE WHEN pv.devcenter=2 THEN 278 ELSE 269 END, e.IRSUserID,
               CASE WHEN dr.vendorid = 203 THEN 109 ELSE vd.irsid END,
               COALESCE(pdr.Subassembly,''),
               CASE WHEN pv.devcenter=2 THEN 46 ELSE 47 END,
               avpb.irshwid,
               dr.id,
               pdr.ID   --,pb.brandid, coalesce(pdr.Subassembly,''), e.IRSUserID, case when p.devcenter=2 then 278 else 269 end as Business , case when r.vendorid = 203 then 109 else vd.irsid end as VendorID
          FROM AvDetail_ProductBrand AvPb WITH (NOLOCK)
               INNER JOIN AvDetail Av WITH (NOLOCK) ON AvPb.AvDetailID = Av.AvDetailID
               INNER JOIN Product_Brand Pb WITH (NOLOCK) ON AvPb.ProductBrandID = Pb.ID
               INNER JOIN DeliverableRoot Dr WITH (NOLOCK) ON Av.DeliverableRootID = Dr.ID
               INNER JOIN Employee E WITH (NOLOCK) ON Dr.DevManagerID = e.ID
               INNER JOIN Vendor vd WITH (NOLOCK) ON Dr.VendorID = vd.ID
               INNER JOIN ProductVersion Pv WITH (NOLOCK) ON Pb.ProductVersionID = Pv.ID
               INNER JOIN Product_DelRoot Pdr WITH (NOLOCK) ON Dr.ID = Pdr.DeliverableRootID AND Pv.ID = Pdr.ProductVersionID
               INNER JOIN ProductFamily Pf WITH (NOLOCK) ON Pv.ProductFamilyID = Pf.ID
               LEFT OUTER JOIN Platform Irs WITH (NOLOCK) ON AvPb.IRSPlatformId = Irs.PlatformId
         WHERE (Av.FeatureCategoryID = 1 OR Av.FeatureCategoryID = 86)
           AND (Pv.ID >= 993)
           AND pv.id <> 100
           AND (pv.ID = COALESCE(@ProductID,-1) OR AvPb.Id = COALESCE(@AvDetailProductBrandId,-1))
           AND AvPb.IRSPlatformID <> 0
           AND COALESCE(pdr.Subassembly,'') <> ''
		ORDER BY IrsHwId DESC

        OPEN IRSDB_CURSOR

        FETCH NEXT FROM IRSDB_CURSOR Into @ComponentName,@PlatformID, @PlatformName, @BusinessSegment, @OwnerID, @VendorID, @PartNumber, @SiteID, @IRSID, @ExcaliburRootID, @ProdDelRootID
        WHILE (@@FETCH_STATUS = 0)
            BEGIN
				Print 'Building XML'
                SELECT @XMLInput = '<?xml version="1.0" encoding="ISO-8859-1"?>'
                SELECT @XMLInput = @XMLInput +  CHAR(13) + CHAR(10)  + '<Parameters'+ CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' PlatformID="' + cast(@PlatformID as varchar(30)) + '" ' + CHAR(13) + CHAR(10) --Platform ID Number ex: 905
                SELECT @XMLInput = @XMLInput +  ' Name="' + @PlatformName + '" ' + CHAR(13) + CHAR(10) --SyStem Board Name / PCA ex: Alberta-UE
                SELECT @XMLInput = @XMLInput +  ' SAPDescription="" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' OwnerID="' + cast(@OwnerID as varchar(30)) + '" ' + CHAR(13) + CHAR(10) --DeveloeprID ex: 228
                SELECT @XMLInput = @XMLInput +  ' PMID="' + cast(@OwnerID as varchar(30)) + '" ' + CHAR(13) + CHAR(10) --OwnerID ex: 228
                SELECT @XMLInput = @XMLInput +  ' ApproverID="" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' BusinessSegmentID="' + CAST(@BusinessSegment as varchar(30)) + '" ' + CHAR(13) + CHAR(10) -- 269=Commercial, 278=Consumer
                SELECT @XMLInput = @XMLInput +  ' VendorID="' + CAST(@VendorID as varchar(30)) + '" ' + CHAR(13) + CHAR(10) --Vendor ID
                SELECT @XMLInput = @XMLInput +  ' VendorPartNo="' + CAST(@PartNumber as varchar(30)) + '" ' + CHAR(13) + CHAR(10)  -- Vendor Part Number
                SELECT @XMLInput = @XMLInput +  ' VendorCodeName="" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' EOLDate="" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' KCID="" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' KCIDRequired="0" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' HWRevision="' + @HWRevision + '" ' + CHAR(13) + CHAR(10)  --Hardware Revision ID ex:1092
                SELECT @XMLInput = @XMLInput +  ' HWStatus="0" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' Shipping="3" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' HPPartNo="' + CAST(@PartNumber as varchar(30)) + '" ' + CHAR(13) + CHAR(10)  --HP Part Number ex: 141516-001
                SELECT @XMLInput = @XMLInput +  ' IncludeInStatusRpt="0" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' OTSEnabled="0" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' Integrated="0" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' SiteID="' + @SiteID + '" ' + CHAR(13) + CHAR(10)  -- 47-Commercial  46-Consumer
                SELECT @XMLInput = @XMLInput +  ' GenericFlag="0" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' Updater="' + @UpdateBy + '" ' + CHAR(13) + CHAR(10)  -- Full Name of user that created the component ex: Bui, Dien
                SELECT @XMLInput = @XMLInput +  ' StatusConstant="COMP_READY_FOR_TEST" ' + CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput +  ' Version="' + @Version + '" ' + CHAR(13) + CHAR(10)  -- Program Phase ID ex: 1276
                SELECT @XMLInput = @XMLInput +  ' Category="SYSBD" '
                SELECT @XMLInput = @XMLInput +  '>'+  CHAR(13) + CHAR(10) +  CHAR(13) + CHAR(10)

                IF @IRSID = 0
                    BEGIN
                        SELECT @XMLInput = @XMLInput   + '<EditPermission GroupID="310" /> '+ CHAR(13) + CHAR(10)
                        SELECT @XMLInput = @XMLInput   + '<EditPermission GroupID="311" /> '+ CHAR(13) + CHAR(10)
                    END

                SELECT @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                SELECT @XMLInput = @XMLInput   + ' Description="Latest Rework" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeValue="' + @Rework +'" '+ CHAR(13) + CHAR(10)  --Info Needed ex: Rework Information
                Select @XMLInput = @XMLInput   + ' AttributeOrder="0" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="1" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="ROM System ID" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeValue="' + @SystemboardID + '" '+ CHAR(13) + CHAR(10)  --Platform System BoardID ex: 2AAE
                Select @XMLInput = @XMLInput   + ' AttributeOrder="0" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="1" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="Maximum Memory Size" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeValue="' + @MaxMemorySize + '" '+ CHAR(13) + CHAR(10)  --Max Memory Size ex: 1GB
                Select @XMLInput = @XMLInput   + ' AttributeOrder="0" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="1" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="CMOS Battery" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="' + cast(@CMOSID as varchar(20)) + '" '+ CHAR(13) + CHAR(10)   --cmos id
                Select @XMLInput = @XMLInput   + ' AttributeValue="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeOrder="0" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="0" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ProcessorSupported ID="' + cast(@ProcessorID as varchar(20)) + '" />'+ CHAR(13) + CHAR(10) --Processor ID ex: 1093

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="Chip Set" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="' + cast(@ChipSetID as varchar(20)) + '" '+ CHAR(13) + CHAR(10)   --chipset id ex:365
                Select @XMLInput = @XMLInput   + ' AttributeValue="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeOrder="1" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="0" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="Component" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="' + CAST(@NorthBridgeID as varchar(20)) + '" '+ CHAR(13) + CHAR(10)   --component id
                Select @XMLInput = @XMLInput   + ' AttributeValue="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeOrder="1" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="0" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="Step" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="' + CAST(@StepID as varchar(20)) + '" '+ CHAR(13) + CHAR(10)   --step id ex: 541
                Select @XMLInput = @XMLInput   + ' AttributeValue="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeOrder="1" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="0" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="Chip Set" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="' + cast(@ChipSetID as varchar(20)) + '" '+ CHAR(13) + CHAR(10)   --chipset id ex:365
                Select @XMLInput = @XMLInput   + ' AttributeValue="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeOrder="2" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="0" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="Component" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="' + CAST(@SouthBridgeID as varchar(20)) + '" '+ CHAR(13) + CHAR(10)   --component id
                Select @XMLInput = @XMLInput   + ' AttributeValue="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeOrder="2" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="0" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput   + '<ValidationValue'+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' Description="Step" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' HWValidationID="' + CAST(@StepID as varchar(20)) + '" '+ CHAR(13) + CHAR(10)   --step id ex: 541
                Select @XMLInput = @XMLInput   + ' AttributeValue="" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' AttributeOrder="2" '+ CHAR(13) + CHAR(10)
                Select @XMLInput = @XMLInput   + ' IsFreeText="0" '
                Select @XMLInput = @XMLInput   + ' /> ' + CHAR(13) + CHAR(10)

                Select @XMLInput = @XMLInput +  '</Parameters>'
                print @XMLInput
                print 'IRSID:' + CAST(@IRSID AS VARCHAR(10))

                DECLARE @p5 int
                DECLARE @p6 int
                DECLARE @p7 int
                DECLARE @p8 varchar(8000)
                SET @p5=0
                SET @p6=0
                SET @p7=0
                SET @p8=''

                IF @IRSID = 0
                    BEGIN
						PRINT 'Sending to IRS'
                        EXEC IRS_usp_NHWC_Create
                                @p_chrParamXML=@XMLInput,
                                @p_chrParamDescription='na',
                                @p_chrParamReleaseNote='',
                                @p_intCheckExist=1,
                                @p_intVersionID=@p5 output,
                                @p_intPassID=@p6 output,
                                @p_intCategoryID=@p7 output,
                                @p_chrMessage=@p8 output

                    --Update Excalibur
                        if @p8 <> ''
							begin
								raiserror(@p8, 16, 1)
								DEALLOCATE IRSDB_CURSOR
								return 1
							end
						else
							EXEC dbo.spFusion_PROJECT_UpdateAvDetailProductBrand @AvDetailProductBrandId, NULL, NULL, @p6
                    END
                ELSE
                    BEGIN
                        EXEC IRS_usp_NHWC_Update
                                @p_chrParamXML=@XMLInput,
                                @p_chrParamDescription='na',
                                @p_chrParamReleaseNote='',
                                @p_intPassID=@IRSID,                -- ComponentPassID value is needed to update the correct hardware component.
                                @p_intCheckExist=1,
                                @p_chrMessage= output
                    
                    END

                FETCH NEXT FROM IRSDB_CURSOR Into @ComponentName, @PlatformID, @PlatformName, @BusinessSegment,@OwnerID, @VendorID, @PartNumber, @SiteID, @IRSID, @ExcaliburRootID, @ProdDelRootID
            END
        DEALLOCATE IRSDB_CURSOR

    END


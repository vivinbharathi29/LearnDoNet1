﻿
CREATE PROCEDURE [dbo].[spGetImageProperties4Sub]
(
	@ImageDefID int,
	@Dash varchar(5)
)
/** Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
**  1  20/8/18     Monica   Changed to ANSI standard
****************************************************************************************************/

 AS
 SET NOCOUNT ON
Select i.ID, r.OSLanguage, r.OtherLanguage, i.priority
from Images i with (NOLOCK)
INNER JOIN Regions r with (NOLOCK)
ON r.id = i.RegionID
INNER JOIN  imagedefinitions idef with (NOLOCK)
ON i.imagedefinitionid = idef.id
WHERE idef.id = @ImageDefID
and r.dash = @Dash
and isnumeric(i.priority )= 1

SET NOCOUNT OFF

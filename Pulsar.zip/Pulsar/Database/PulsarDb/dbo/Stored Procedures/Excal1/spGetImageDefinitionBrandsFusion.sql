﻿
CREATE PROCEDURE [dbo].[spGetImageDefinitionBrandsFusion] 
(
	@ID int
)
AS

	Select d.id, dd.DriveName,  pd.name as ProductDrop , o.id as OSID,d.StatusID, d.ImageDriveDefinitionId, o.name as OS, [is].Name as Status, d.eoldate, d.RTMDate, d.ImageTypeID, t.Name as ImageTypeName, dbo.concatenate(b.Name) as Brand,d.SKUNumber,  d.Modified, d.comments, isnull(osr.Description,'') as OSReleaseName 
	from Imagedefinitions d WITH (NOLOCK) join 
		 ImageDefinition_Brand idb WITH (NOLOCK) on idb.ImageDefinitionID = d.ID join
		 Brand b WITH (NOLOCK) on b.ID = idb.BrandID join
		 ProductDrop1 pd WITH (NOLOCK) on pd.id = d.productdropid  join
		 Productversion_productdrop pvpd WITH (NOLOCK) on pvpd.productdropid = pd.id join
		 OSLookup o WITH (NOLOCK) on o.ID = d.osid join
		 ImageStatus [is] WITH (NOLOCK) on [IS].ID = d.statusid join
		 ImageType t WITH (NOLOCK) on t.id = d.ImageTypeID LEFT OUTER JOIN 
		 ImageDriveDefinition AS dd WITH (NOLOCK) ON d.ImageDriveDefinitionID = dd.ID LEFT JOIN		 
		 OSRelease osr WITH (NOLOCK) ON d.OSReleaseId = osr.ID
	where d.ID = @ID
	group by d.id, dd.DriveName,  pd.name  , o.id, d.StatusID, d.ImageDriveDefinitionId, o.name , [is].Name , d.eoldate, d.RTMDate, d.ImageTypeID, t.Name,d.SKUNumber,  d.Modified, d.comments, osr.Description


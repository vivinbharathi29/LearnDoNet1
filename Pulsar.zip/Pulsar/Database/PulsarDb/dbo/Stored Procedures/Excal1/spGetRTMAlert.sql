﻿

CREATE PROCEDURE [dbo].[spGetRTMAlert]
(
	@ID int
)
AS

	Select r.ID, r.ProductRTMID, r.ReportSectionID, r.SignoffDate, r.comments, r.alerthtml, e.name as UserName, r.LastUpdated, p.dotsname as Product, pr.title
	from ProductRTMAlerts r with (NOLOCK)
	inner join productversion p with (NOLOCK) on p.id = r.ProductID
	inner join employee e with (NOLOCK) on r.UserID = e.ID
	left outer join ProductRTM pr with (NOLOCK) on pr.id = r.ProductRTMID
	where r.id = @ID

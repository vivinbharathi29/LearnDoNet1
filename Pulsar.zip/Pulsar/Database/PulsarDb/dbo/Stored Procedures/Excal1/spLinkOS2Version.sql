﻿

CREATE PROCEDURE [dbo].[spLinkOS2Version]
 (
  @OSID as int,
  @DeliverableID as int
 )
 AS
Insert OS_DelVer (OSid,DeliverableVersionId)
Values (@OSID,  @DeliverableID)




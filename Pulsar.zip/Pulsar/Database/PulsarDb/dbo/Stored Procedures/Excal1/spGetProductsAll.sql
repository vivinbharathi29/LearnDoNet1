﻿CREATE PROCEDURE [dbo].[spGetProductsAll]
/* *****************************************************************************************************************************************************
 * Purpose:	    Get all products by type (same as spGetProducts, but does not eliminate inactive products)
 * Created By:	
 * Modified By: Malichi, 4/13/2016, Bug 19360: Pulsar allows product to be created with duplicate name
						 Changed UserID joins to LEFT OUTER JOINs since required fields now vary by product type
				wgomero: 10/20/2016, get systemboards IDs from the platform table, if the product contains platforms.
 *******************************************************************************************************************************************************/
(
	@Type      INT = 1,
	@PartnerID INT = NULL
)
AS 

IF @Type = 0
	SELECT v.ID AS ID, f.Name AS Name, v.Version AS Version, v.dotsname as Product, v.AllowDCR, v.productstatusid, e.FullName AS PM, e.UserID as PMID, v.Distribution, v.OnCommodityMatrix, v.PRDReleased, v.PDDReleased, 
	       v.OnlineReports, v.StreetName, v.Brands, SystemBoardID = dbo.fnGetProductSystemBoardIDs(v.ID), v.PartnerID, v.PreinstallTeam, v.TypeID, e2.FullName AS SEPM, v.Division, v.Sustaining, v.DevCenter, v.ReleaseTeam,
	       v.Active, e2.Email AS SEPMMail, e2.UserID AS SEPMID, e3.UserID AS SM, e3.Email AS SMMail, e3.UserID AS SMID, v.ProductFilePath, v.PDDPath, p.Name AS Partner
	FROM   ProductFamily f with (NOLOCK) INNER JOIN
		   ProductVersion v with (NOLOCK) ON f.ID = v.ProductFamilyID INNER JOIN
		   Partner p with (NOLOCK) ON v.PartnerID = p.ID LEFT OUTER JOIN
		   UserInfo e with (NOLOCK) ON e.UserId = v.PMID LEFT OUTER JOIN
		   UserInfo e2 with (NOLOCK) ON e2.UserId = v.SEPMID LEFT OUTER JOIN
		   UserInfo e3  with (NOLOCK) on e3.UserId = v.SMID
	ORDER BY v.DOTSName
ELSE IF @Type = -1
	SELECT v.ID AS ID, f.Name AS Name, v.Version AS Version, v.dotsname as Product, v.AllowDCR, v.productstatusid, e.FullName AS PM, e.UserID as PMID, v.Distribution, v.OnCommodityMatrix, v.PRDReleased, v.PDDReleased, 
	       v.OnlineReports, v.StreetName, v.Brands, SystemBoardID = dbo.fnGetProductSystemBoardIDs(v.ID), v.PartnerID, v.PreinstallTeam, v.TypeID, e2.FullName AS SEPM, v.Division, v.Sustaining, v.DevCenter,v.ReleaseTeam,
	       v.Active, e2.Email AS SEPMMail, e2.UserID AS SEPMID, e3.FullName AS SM, e3.Email AS SMMail, e3.UserID AS SMID, v.ProductFilePath, v.PDDPath, p.Name AS Partner
	FROM   ProductFamily f with (NOLOCK) INNER JOIN
		   ProductVersion v with (NOLOCK) ON f.ID = v.ProductFamilyID INNER JOIN
		   Partner p with (NOLOCK) ON v.PartnerID = p.ID LEFT OUTER JOIN
		   UserInfo e with (NOLOCK) ON e.UserId = v.PMID LEFT OUTER JOIN
		   UserInfo e2 with (NOLOCK) ON e2.UserId = v.SEPMID LEFT OUTER JOIN
		   UserInfo e3  with (NOLOCK) on e3.UserId = v.SMID
	WHERE  TypeID <> 2
	ORDER BY v.DOTSName, v.Version
ELSE IF @Type = -2
	SELECT v.ID, f.Name, v.Version, v.dotsname as Product, v.AllowDCR, v.ProductStatusID, e.FullName AS PM, e.UserID AS PMID, v.Distribution, v.OnCommodityMatrix, v.PRDReleased, v.PDDReleased, 
           v.OnlineReports, v.StreetName, v.Brands, SystemBoardID = dbo.fnGetProductSystemBoardIDs(v.ID), v.PartnerID, v.PreinstallTeam, v.TypeID, e2.FullName AS SEPM, v.Division, v.Sustaining, v.DevCenter, dc.name as DevCenterName,
           v.ReleaseTeam, v.Active, e2.Email AS SEPMMail, e2.UserID AS SEPMID, e3.FullName AS SM, e3.Email AS SMMail, e3.UserID AS SMID, v.ProductFilePath, v.PDDPath, 
           p.Name AS Partner, CASE DevCenter WHEN 2 THEN 'Consumer' ELSE 'Commercial' END AS Business
	FROM   ProductFamily f with (NOLOCK) INNER JOIN
		   ProductVersion v with (NOLOCK) ON f.ID = v.ProductFamilyID INNER JOIN
		   DevCenter as dc with (NOLOCK) on v.DevCenter = dc.ID INNER JOIN
		   Partner p with (NOLOCK) ON v.PartnerID = p.ID LEFT OUTER JOIN
		   UserInfo e with (NOLOCK) ON e.UserId = v.PMID LEFT OUTER JOIN
		   UserInfo e2 with (NOLOCK) ON e2.UserId = v.SEPMID LEFT OUTER JOIN
		   UserInfo e3  with (NOLOCK) on e3.UserId = v.SMID
    WHERE  v.TypeID IN (1, 3)
    ORDER BY Business, f.Name, v.Version
ELSE IF @Type = -3
	SELECT v.ID, f.Name, v.Version, v.dotsname as Product, v.AllowDCR, v.ProductStatusID, e.FullName AS PM, e.UserId AS PMID, v.Distribution, v.OnCommodityMatrix, v.PRDReleased, v.PDDReleased, 
           v.OnlineReports, v.StreetName, v.Brands, SystemBoardID = dbo.fnGetProductSystemBoardIDs(v.ID), v.PartnerID, v.PreinstallTeam, v.TypeID, e2.FullName AS SEPM, v.Division, v.Sustaining, v.DevCenter, dc.name as DevCenterName,
           v.ReleaseTeam, v.Active, e2.Email AS SEPMMail, e2.UserId AS SEPMID, e3.FullName AS SM, e3.Email AS SMMail, e3.UserId AS SMID, v.ProductFilePath, v.PDDPath, 
           p.Name AS Partner, CASE DevCenter WHEN 2 THEN 'Consumer' ELSE 'Commercial' END AS Business
	FROM   ProductFamily f with (NOLOCK) INNER JOIN
		   ProductVersion v with (NOLOCK) ON f.ID = v.ProductFamilyID INNER JOIN
		   DevCenter as dc with (NOLOCK) on v.DevCenter = dc.ID INNER JOIN
		   Partner p with (NOLOCK) ON v.PartnerID = p.ID LEFT OUTER JOIN
		   UserInfo e with (NOLOCK) ON e.UserId = v.PMID LEFT OUTER JOIN
		   UserInfo e2 with (NOLOCK) ON e2.UserId = v.SEPMID LEFT OUTER JOIN
		   UserInfo e3  with (NOLOCK) on e3.UserId = v.SMID
	WHERE  v.TypeID IN (1, 3)
	ORDER BY dc.name, v.dotsname, v.Version
ELSE
	SELECT v.ID AS ID, f.Name AS Name, v.Version AS Version, v.dotsname as Product, v.AllowDCR, v.productstatusid, e.FullName AS PM, e.UserId as PMID, v.Distribution, v.OnCommodityMatrix, v.PRDReleased, v.PDDReleased, 
	       v.OnlineReports, v.StreetName, v.Brands, SystemBoardID = dbo.fnGetProductSystemBoardIDs(v.ID), v.PartnerID, v.PreinstallTeam, v.TypeID, e2.FullName AS SEPM, v.Division, v.Sustaining, v.DevCenter,v.ReleaseTeam,
	       v.Active, e2.Email AS SEPMMail, e2.UserId AS SEPMID, e3.FullName AS SM, e3.Email AS SMMail, e3.UserId AS SMID, v.ProductFilePath, v.PDDPath, p.Name AS Partner, RTRIM(LTRIM(v.ProductName + ' ' + v.Version)) AS ProductName, FusionRequirements = isnull(v.FusionRequirements,0)
	FROM   ProductFamily f with (NOLOCK) INNER JOIN
		   ProductVersion v with (NOLOCK) ON f.ID = v.ProductFamilyID INNER JOIN
		   Partner p with (NOLOCK) ON v.PartnerID = p.ID LEFT OUTER JOIN
		   UserInfo e with (NOLOCK) ON e.UserId = v.PMID LEFT OUTER JOIN
		   UserInfo e2 with (NOLOCK) ON e2.UserId = v.SEPMID LEFT OUTER JOIN
		   UserInfo e3  with (NOLOCK) on e3.UserId = v.SMID
	WHERE  TypeID = 1
	ORDER BY v.DOTSName
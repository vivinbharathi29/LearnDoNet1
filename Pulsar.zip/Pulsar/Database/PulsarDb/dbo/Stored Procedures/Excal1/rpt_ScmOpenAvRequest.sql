﻿
CREATE PROCEDURE [dbo].[rpt_ScmOpenAvRequest]
	@p_EmployeeID	INT
AS

/******************************************************************************
**		File: 
**		Name: rpt_ScmOpenAvRequest
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT     
	AvDetail.AvDetailID, 
	AvDetail.AvNo, 
	AvDetail.GPGDescription, 
	AvDetail_ProductBrand.ProductBrandID, 
	AvFeatureCategory.AvFeatureCategory, 
	AvFeatureCategory.SortOrder, 
	AvDetail_ProductBrand.Status, 
	ProductVersion.DOTSName, 
	ProductVersion.PCID, 
	Brand.Name, 
	Product_Release.PDDLocked
FROM
	AvDetail with (NOLOCK) INNER JOIN
	AvDetail_ProductBrand with (NOLOCK) ON AvDetail.AvDetailID = AvDetail_ProductBrand.AvDetailID INNER JOIN
	AvFeatureCategory with (NOLOCK) ON AvDetail.FeatureCategoryID = AvFeatureCategory.AvFeatureCategoryID INNER JOIN
	Product_Brand with (NOLOCK) ON AvDetail_ProductBrand.ProductBrandID = Product_Brand.ID INNER JOIN
	ProductVersion with (NOLOCK) ON Product_Brand.ProductVersionID = ProductVersion.ID INNER JOIN
	Brand with (NOLOCK) ON Product_Brand.BrandID = Brand.ID INNER JOIN
	Product_Release with (NOLOCK) ON Product_Brand.ProductVersionID = Product_Release.ProductversionID
WHERE
	(AvDetail.AvNo IS NULL) 
AND (AvDetail_ProductBrand.Status = 'A') 
AND (ProductVersion.PCID = @p_EmployeeID) 
AND (Product_Release.ReleaseID = 1)
AND (Product_Release.PDDLocked = 1)
AND (@p_EmployeeID <> 5016) -- Malichi, Jason
ORDER BY 
	ProductVersion.DOTSName, 
	Brand.DisplayOrder, 
	AvFeatureCategory.SortOrder, 
	AvDetail.GPGDescription





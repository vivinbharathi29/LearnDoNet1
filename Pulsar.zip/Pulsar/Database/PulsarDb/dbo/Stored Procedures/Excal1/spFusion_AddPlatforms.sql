﻿-- =============================================
-- Author:		10/28/2014	wgomero
-- Description:	add platforms to products
-- Modified By: 8/12/2015 buidi - Team A - Bug 11642:Brands selected for a Platform need to be specific to the Brands set for Product
--				8/25/2015 buidi - Team A - Once the PRL moves to POR and Post-POR status, do not allow changing the Brand and show as disabled.  Also, if Brand is changed, check if any Base Unit AVs have been set up already in the SCM and if so, if they are Active, Hidden or Obsolete.  If Obsolete, display an error “Active Base Unit AVs are already set up in the SCM for this Platform and Brand.  Must set all Base Units to Obsolete before changing the Platform’s Brand”
--				9/3/2015  buidi - Team A - Return error checking unique platform from IRS_usp_ADMIN_PlatformsandSystemBoards to UI for user
--				09/09/2015 buidi - Team A - allow to update brand when it doesn't have a brand assign to it yet
--              10/07/2015 ragishetti - Task 12241:Modify BIOS Branding and Logo Badge name on General tab
--				10/19/2015 buidi - Add PCA Graphics Type
--				10/19/2015 buidi - Add Touch
--				11/16/2015 buidi - changed the error message for unique name
--				02/22/2016 wgomero - updatde stored procedure to support add/update operations to the platform table
--				02/24/2016 wgomero - add Marketing, it needs to be different than NULL
--				03/08/2016 wgomero - If @p_chrSPQDate is blank then set it to NULL. 
--				03/29/2016, Ravi Nukala - Replaced @@IDENTITY with SCOPE_IDENTITY(), Task 18865
--				04/06/2016, wgomero, removed IRS synonym tables and replaced with stored procedure; in the update statement corrected the generic field with the correct parameter
--				06/27/2016, wgomero, remove call to IRS stored procedure usp_ADMIN_PlatformsandSystemBoardsAddOns. It's no longer needed.
--				07/07/2016 buidi - checking for uniqueness was checking the Marketing name instead of generic name
--				07/20/2016 wgomero - insert/update SOAR Description, Division and WebCyles to IRS Tables
--				07/29/2016 wgomero - Updated stored procedure to save/update SOAR description into SOAR_Mapping table on Pulsar instead of IRS 
--				08/29/2016 buidi - update system board component when platform PCA is updated.
--				10/11/2016 santodp - add new field ModelNumber 
--              10/17/2016 Sragishetti -  Add PCA Graphic type to check Base unit group uniqueness
--				11/01/2016 buidi - add 3 new fields to the query
--				1/24/2017 Ywang - bug 31232:Production: Can not save a change to Generic Name for Pavo Product.  
								--make the latest code of this sp in sync between tfs and Git. added wGomero 7/29/2016 change
--             05/25/2017 linshant - remove the comment out for IRS_usp_ADMIN_PlatformsandSystemBoardsAddOns - PBI 133773
--             07/19/2017 herb - PBI 142352: Add Comments field to Base Unit Groups for Pulsar Products
--			   04/05/2018 wgomero - PBI19338: Add a "Deployment" field to the Base Unit Group and use the Deployment field for the Base Unit Group uniqueness calculation. 
--									A Base Unit Group with the same Product Family, PCA, Chassis, Generic Name AND different Deployment Name is allowed.
--			   04/05/2018 wgomero - Made Deployment Parameter an Optional parameter (avoid making changes in IRS).
--	           05/25/2018 linshant - Add BIOS Family Name Field in Base Unit Group - PBI 181805 
--			   12/12/2018 Dean Chiang - Add SMBIOS Family Name Field in Base Unit Group - PBI 240883
--			   12/12/2018 Dean Chiang - Remove fields from Base Unit Group - PBI 240881
--			   02/11/2019 linshan - Move Brands field from Product Properties to Base Unit Groups - PBI 241541
-- =============================================
CREATE PROCEDURE [dbo].[spFusion_AddPlatforms] 
	@p_intProductVersionID int,
	@p_intPlatformID int,
	@p_intIntroYear int,
	@p_chrProductFamily varchar(64),
	@p_chrProduct varchar(64),
	@p_intChassis int,
	@p_intBrandID int,
	@p_chrGenericName varchar(40),
	@p_chrMarketingName varchar(50),
	@p_chrFullMarketingName varchar(120),
	@p_intSOARDescription int,
	@p_chrBIOSName varchar(40) = '',
	@p_chrChinaIdentifier varchar(225),
	@p_chrComments varchar(64),
	@p_chrSystemID varchar(4),
	@p_chrCycle varchar(256),
	@p_intBusinessSegmentID int,
	@p_chrSPQDate varchar(10),
	@p_intStatus int,
	@p_chrCreator varchar(64),
	@p_chrUpdater varchar(64),
	@p_chrPCAGraphicsType varchar(64) = '',
	@p_TouchId int = 0,
	@p_ModelNumber varchar(40)= '',
	@p_eMMConboard bit = 0,
	@p_chrMemoryOnboard varchar(4) = '',
	@p_chrGraphicCapacity varchar(4) = '',
	@p_SystemIdComments varchar(256) = '',
	@p_chrDeployment varchar(30) = '',
	@p_BIOSFamilyName varchar(255)= Null,
	@p_intSeriesID int = NULL,
	@p_phWebFamilyName varchar(255) = '',
	@p_matchPMS bit = 0,
	@p_intReturnID varchar(10) = '' output

AS
SET NOCOUNT ON

BEGIN
		DECLARE @Action varchar(30),@pPSID int, @Status varchar(10), @intLCMSOARProductID int, @IrsPlatformCount int, @followMKTName bit = 0, @brandID int, @platformFailed bit =0
		SET @intLCMSOARProductID = 1274; -- this ID belongs to IRS_Category table where Constant = 'products'

										
		IF @p_intBusinessSegmentID = 1
			SET @p_intBusinessSegmentID = 266
		
		ELSE IF @p_intBusinessSegmentID= 2
			SET @p_intBusinessSegmentID = 267

		ELSE IF @p_intBusinessSegmentID= 3
			SET @p_intBusinessSegmentID = 704

		ELSE IF @p_intBusinessSegmentID= 4
			SET @p_intBusinessSegmentID = 1825

		ELSE IF @p_intBusinessSegmentID= 7
			SET @p_intBusinessSegmentID = 269

		ELSE IF @p_intBusinessSegmentID= 8
			SET @p_intBusinessSegmentID = 278
				
		ELSE IF @p_intBusinessSegmentID= 9
			SET @p_intBusinessSegmentID = 268
	
	    ELSE
			SET @p_intBusinessSegmentID = 269
	
		
		IF(@p_intPlatformID = 0)
			SET @Action='create'
		ELSE
			SET @Action='update'

		IF @p_intStatus = 0
			SET @Status = ''
		ELSE
			SET @Status = CAST(@p_intStatus as varchar(20))



		IF @p_chrSPQDate = ''
			BEGIN
				SET @p_chrSPQDate = NULL
			END
	
		SET @p_chrProductFamily = RTRIM(@p_chrProductFamily)
		SET @p_chrProduct = RTRIM(@p_chrProduct)
		SET @p_chrMarketingName = RTRIM(@p_chrMarketingName)
		
		SELECT @followMKTName = AllowFollowMarketingName From ProductVersion WHERE ID = @p_intProductVersionID

		BEGIN TRANSACTION			
			BEGIN TRY
			 DECLARE @intNewPlatformID int, @intNewAliasID int
			 IF @Action='create'
				BEGIN
					SET @intNewPlatformID = 0;
						-- make sure that the Product Family, PCA, Chassis, and Generic Name don't already exist together
						-- MarketingName is Generic Name
						-- allow to save base unit group with same require fields but with different deployment information
					IF @p_chrDeployment = '' and @followMKTName = 0
						BEGIN
							IF EXISTS(SELECT * FROM Platform WHERE ProductFamily = @p_chrProductFamily AND PCA = @p_chrProduct AND CategoryID = @p_intChassis AND MarketingName = RTRIM(@p_chrGenericName) AND PCAGraphicsType =  @p_chrPCAGraphicsType)
							  BEGIN
								raiserror('A record with the same Product Family Code Name, System Board (PCA) Code Name, Chassis, PCA Graphic type, and Generic Name already exists and together they must be unique.', 16, 1)
								return 1
							  END
						END
					IF @p_chrDeployment <> '' 
						BEGIN
							IF EXISTS(SELECT * FROM Platform WHERE ProductFamily = @p_chrProductFamily AND PCA = @p_chrProduct AND CategoryID = @p_intChassis AND MarketingName = RTRIM(@p_chrGenericName) AND PCAGraphicsType =  @p_chrPCAGraphicsType AND Deployment = '')
							  BEGIN
								raiserror('A record with the same Product Family Code Name, System Board (PCA) Code Name, Chassis, PCA Graphic type, Generic Name and Deployment with no value already exists. Edit existing platform, select a deployment and Save.', 16, 1)
								return 1
							  END

							IF EXISTS(SELECT * FROM Platform WHERE ProductFamily = @p_chrProductFamily AND PCA = @p_chrProduct AND CategoryID = @p_intChassis AND MarketingName = RTRIM(@p_chrGenericName) AND PCAGraphicsType =  @p_chrPCAGraphicsType AND Deployment = @p_chrDeployment)
							  BEGIN
								raiserror('A record with the same Product Family Code Name, System Board (PCA) Code Name, Chassis, PCA Graphic type, Generic Name and Deployment already exists and together they must be unique.', 16, 1)
								return 1
							  END
						END
					
					IF @followMKTName = 1
						BEGIN
							IF EXISTS(SELECT * FROM Platform WHERE ProductFamily = @p_chrProductFamily AND PCA = @p_chrProduct AND CategoryID = @p_intChassis AND MKTNameMaster = RTRIM(@p_chrMarketingName))
							  BEGIN
								SET @platformFailed = 1
								raiserror('A record with the same Product Family Code Name, System Board (PCA) Code Name, Chassis, and Marketing Name already exists and together they must be unique.', 16, 1)
								return 1
							  END
						END
						
					 BEGIN -- insert new platform information
						INSERT INTO Platform (ProductFamily, PCA, CategoryID, MarketingName, Model, IntroYear, SystemID,SystemIdComments, Lock, Creator, Updater, TimeCreated, TimeChanged,  MktFullName, MktNameMaster, BIOSName,
											  SoftpaqNeedDate, Active, ChinaGPIdentifier, WebCycle,  ConsumerDT, Brand, TouchID, PCAGraphicsType, ModelNumber, eMMConboard, MemoryOnboard, GraphicCapacity, Deployment, BIOSFamilyName, PHWebFamilyName, MatchProductMaster)
								
								 VALUES(RTRIM(@p_chrProductFamily), RTRIM(@p_chrProduct), @p_intChassis, RTRIM(@p_chrGenericName), @p_chrComments, CAST(@p_intIntroYear as varchar(6)), @p_chrSystemID,@p_SystemIdComments, 0, @p_chrCreator, @p_chrUpdater, getdate(), getdate(), RTRIM(@p_chrFullMarketingName), RTRIM(@p_chrMarketingName), RTRIM(@p_chrBIOSName), 
											  @p_chrSPQDate, 1, RTRIM(@p_chrChinaIdentifier), RTRIM(@p_chrCycle), NULL, @p_intBrandID, @p_TouchId, @p_chrPCAGraphicsType, @p_ModelNumber, @p_eMMConboard, @p_chrMemoryOnboard, @p_chrGraphicCapacity, LTRIM(RTRIM(@p_chrDeployment)), @p_BIOSFamilyName, @p_phWebFamilyName, @p_matchPMS);
						
							      IF @@ERROR <> 0 
									 BEGIN
										raiserror('spFusion_AddPlatforms - Platform created failed.', 16, 1)
										rollback transaction
										RETURN 1
									 END

									 -- get PlatformID of record created 
									SELECT @intNewPlatformID = SCOPE_IDENTITY()
									SET @p_intPlatformID = @intNewPlatformID;

									SELECT @p_intReturnID = @intNewPlatformID;

									-- now create a blank record in the Alias table and then 
									-- Platform_Alias table using the PlatformID we just created
									INSERT Alias (Name, Creator, Updater, TimeCreated, TimeChanged, MktNameMaster)
										VALUES ('', @p_chrCreator, @p_chrUpdater, getdate(), getdate(), RTRIM(@p_chrMarketingName))


									IF @@error <> 0 
										BEGIN
											raiserror('spFusion_AddPlatforms - Creating record 3 failed.', 16, 1)
											rollback transaction
											return 1
										END 
									ELSE
										BEGIN
										-- get AliasID of record created 
										  SELECT @intNewAliasID = SCOPE_IDENTITY()
									    END

									INSERT Platform_Alias (PlatformID, AliasID)
										SELECT PlatformID = @p_intPlatformID,
											AliasID = @intNewAliasID

									IF @@error <> 0 
										BEGIN
											raiserror('spFusion_AddPlatforms - Creating record 4 failed.', 16, 1)
											rollback transaction
											return 1
									    END
									 IF @p_intSOARDescription > 0
										BEGIN
											insert SOAR_Mapping (ObjectID, ObjectTypeID, OID, CategoryID, Updater, TimeChanged)
											select @p_intPlatformID, 209, @p_intSOARDescription, @intLCMSOARProductID, @p_chrUpdater, getdate()
	
											IF @@error <> 0 
											BEGIN
												raiserror('usp_ADMIN_PlatformsandSystemBoards - Creating record 5 failed.', 16, 1)
												rollback transaction
												return 1
											END
										END
									END
					 END
			 IF @Action = 'update'
				BEGIN
				   IF @p_chrDeployment = '' and @followMKTName = 0
						BEGIN
							IF EXISTS(select * from Platform where ProductFamily = @p_chrProductFamily and PCA = @p_chrProduct and CategoryID = @p_intChassis and MarketingName = RTRIM(@p_chrGenericName) and PCAGraphicsType =  @p_chrPCAGraphicsType AND PlatformID <> @p_intPlatformID)
								BEGIN
									raiserror('A record with the same Product Family Code Name, System Board (PCA) Code Name, Chassis, PCA Graphic type and Generic Name already exists and together they must be unique.', 16, 1)
									return 1
								END
					   END
				  IF @p_chrDeployment <> ''
						BEGIN
							IF EXISTS(select * from Platform where ProductFamily = @p_chrProductFamily and PCA = @p_chrProduct and CategoryID = @p_intChassis and MarketingName = RTRIM(@p_chrGenericName) and PCAGraphicsType =  @p_chrPCAGraphicsType AND Deployment = @p_chrDeployment AND PlatformID <> @p_intPlatformID)
								BEGIN
									raiserror('A record with the same Product Family Code Name, System Board (PCA) Code Name, Chassis, PCA Graphic type, Generic Name and Deployment already exists and together they must be unique.', 16, 1)
									return 1
								END
					   END
				  IF @followMKTName = 1
						BEGIN
							IF EXISTS(SELECT * FROM Platform WHERE ProductFamily = @p_chrProductFamily AND PCA = @p_chrProduct AND CategoryID = @p_intChassis AND MKTNameMaster = RTRIM(@p_chrMarketingName) AND PlatformID <> @p_intPlatformID)
								BEGIN
									SET @platformFailed =1
									raiserror('A record with the same Product Family Code Name, System Board (PCA) Code Name, Chassis, and Marketing Name already exists and together they must be unique.', 16, 1)
									return 1
								END
						END	
					
					  BEGIN -- Update Platform Information
						Declare @OrgPCA varchar(30)
						Select @OrgPCA = PCA From Platform Where PlatformID = @p_intPlatformID
						UPDATE Platform SET ProductFamily = RTRIM(@p_chrProductFamily),
									   PCA = RTRIM(@p_chrProduct),
									   CategoryID = @p_intChassis,
									   MarketingName = RTRIM(@p_chrGenericName),
									   Model = @p_chrComments,
									   IntroYear = @p_intIntroYear,
									   SystemID = @p_chrSystemID,
									   SystemIdComments = @p_SystemIdComments,
									   Lock = @p_intStatus,
									   Updater = @p_chrUpdater,
									   TimeChanged = getdate(), 
									   MktFullName =  RTRIM(@p_chrFullMarketingName),
									   MktNameMaster = RTRIM(@p_chrMarketingName),
									   BIOSName = RTRIM(@p_chrBIOSName),
									   SoftpaqNeedDate = @p_chrSPQDate,
									   ChinaGPIdentifier = RTRIM(@p_chrChinaIdentifier),
									   WebCycle =  RTRIM(@p_chrCycle), 
									   Brand = @p_intBrandID,
									   TouchID = @p_TouchId,
									   PCAGraphicsType = @p_chrPCAGraphicsType,
									   ModelNumber = @p_ModelNumber,
									   eMMConboard = @p_eMMConboard,
									   MemoryOnboard = @p_chrMemoryOnboard,
									   GraphicCapacity = @p_chrGraphicCapacity,
									   Deployment = RTRIM(@p_chrDeployment),
									   BIOSFamilyName = @p_BIOSFamilyName,
									   PhWebFamilyName = @p_phWebFamilyName,
									   MatchProductMaster = @p_matchPMS
								WHERE PlatformID = @p_intPlatformID
					
							IF @@ERROR <> 0 
								BEGIN
									raiserror('spFusion_AddPlatforms - Platform update failed.', 16, 1)
									rollback transaction
									RETURN 1
								END
						  -- update any system boards that are the same and don't match the current System ID
						   UPDATE Platform set
								SystemID = @p_chrSystemID,
								TimeChanged= getdate(),
								Updater= @p_chrUpdater
							WHERE
								PCA = @p_chrProduct --REPLACE(@chrLCMPPCA, '"', '""')
								and SystemID <> @p_chrSystemID;
							IF @@error <> 0 
								BEGIN
									raiserror('spFusion_AddPlatforms - Updating System ID for similar platforms failed.', 16, 1)
									rollback transaction
									return 1
								END

							-- delete all ObjectIDs from SOAR_Mapping for the given CategoryID
							DELETE from SOAR_Mapping where ObjectID = @p_intPlatformID and ObjectTypeID = 209 and CategoryID = @intLCMSOARProductID
				
							IF @@error <> 0 
								BEGIN
									raiserror('spFusion_AddPlatforms- Deleting from SOAR_Mapping failed.', 16, 1)
									rollback transaction
									return 1
								END
			   
						    -- now put the SOAR mapping in if there's an OID
						    IF @p_intSOARDescription > 0 
								BEGIN
									insert SOAR_Mapping (ObjectID, ObjectTypeID, OID, CategoryID, Updater, TimeChanged)
										select @p_intPlatformID, 209, @p_intSOARDescription, @intLCMSOARProductID, @p_chrUpdater, getdate()
								 END
							IF @@error <> 0 
								BEGIN
									raiserror('spFusion_AddPlatforms - Updating record 4 failed.', 16, 1)
									rollback transaction
									return 1
								END
						--sync with system board component
							IF @OrgPCA <> @p_chrProduct
								BEGIN								
									Create table #Components(ComponentVersionID int, ComponentRootID int, IRSVersionID int, IRSRootID int)
									Insert Into #Components (ComponentVersionID, ComponentRootID, IRSVersionID, IRSRootID)
									Select V.ID, V.DeliverableRootID, V.IRSVersionID, V.IRSRootID From DeliverableVersion V
									Join DeliverableRoot R on R.ID = V.DeliverableRootID Where R.Name = @OrgPCA and R.TypeID = 1
																
									--update all component root where using Original PCA to New
									Update R
									Set	Name = @p_chrProduct,
										Name2 = @p_chrProduct
									From DeliverableRoot R
									Where R.Name = @OrgPCA and R.ID in (select distinct ComponentRootID from #Components)									
									
									--update all component version where using Original PCA to new
									Update V
									Set	DeliverableName = @p_chrProduct
									From DeliverableVersion V
									Where DeliverableName = @OrgPCA and V.ID in (select distinct ComponentVersionID from #Components)
									
									--update name to irs
									Update IRS_ComponentVersion
									Set	Name = @p_chrProduct
									Where Name = @OrgPCA and ComponentVersionID in (select distinct IRSVersionID from #Components) 									
									
									--update name to irs root
									Update IRS_DeliverableRoot
									Set	Name = @p_chrProduct
									Where Name = @OrgPCA and RootID in (select distinct IRSRootID from #Components)

									--send update to Sudden Impact
									WHILE EXISTS(Select ComponentVersionID From #Components)
									Begin
										Declare @VersionID int
										Select Top 1 @VersionID = ComponentVersionID From #Components
										Exec usp_SSSB_SendSync_Message 'MSMQLegacy', 2, @VersionID, 1, 1, 'Deliverable Version Refresh'
										Delete #Components Where ComponentVersionID = @VersionID
									End

									Drop Table #Components									
								END
					 END
				END

			END TRY
			BEGIN CATCH
	
				DECLARE @ErrorMessage NVARCHAR(4000);
				DECLARE @ErrorSeverity INT;
				DECLARE @ErrorState INT;
				select @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();

				if @ErrorMessage = 'A record with the same Product Family Code Name, System Board (PCA) Code Name, Chassis,PCA Graphic type and Generic Name already exists and together they must be unique.' 
				begin
					select @ErrorMessage = 'A base unit group with the same Product Family, System Board, Chassis,PCA Graphic type and Generic Name already exists and together they must be unique.  Cancel and select the Add Existing Platform link'
				end				

				IF (@platformFailed = 1) AND (@followMKTName = 1) 
				BEGIN
					SELECT @brandID = brandID FROM Product_Brand WHERE ID = @p_intBrandID
					if (ISNULL(@p_intSeriesID,0) > 0) AND (NOT EXISTS(SELECT 1 FROM ProductVersion_Platform pp JOIN ProductVersion pv on pp.ProductVersionID = pv.ID WHERE pp.ProductVersionID = @p_intProductVersionID AND pp.SeriesID = @p_intSeriesID))
					begin
							DELETE Series WHERE ID = @p_intSeriesID
							EXEC spUpdateSeriesSummary @p_intProductVersionID, @brandID
					end
					if (NOT EXISTS(SELECT 1 FROM ProductVersion_Platform pp JOIN ProductVersion pv on pp.ProductVersionID = pv.ID WHERE pp.ProductVersionID = @p_intProductVersionID AND pp.ProductBrandID = @p_intBrandID))
					begin
						EXEC spRemoveBrandFromProduct @p_intProductVersionID, @brandID
					end
				END

				RAISERROR (@ErrorMessage, -- Message text.
							@ErrorSeverity, -- Severity.
							@ErrorState -- State.
						  )
				rollback transaction

				RETURN 1
			End Catch
						



   IF (@p_intProductVersionID > 0 AND @p_intBrandID > 0) --If Platform was created in Pulsar then update Pulsar Tables
		BEGIN				
			IF @Action='create'
				BEGIN						 
						INSERT INTO ProductVersion_Platform (ProductVersionID, PlatformID, ProductBrandID, SeriesID) values (@p_intProductVersionID, @p_intPlatformID, @p_intBrandID, @p_intSeriesID)
						if @@error <> 0 begin
							raiserror('spFusion_AddPlatforms - Add Brand to Product Brand Base Unit Group failed.', 16, 1)
							rollback transaction
							RETURN 1
						end
				END
			ELSE
				BEGIN
					Declare @intProductBrandID int
					Select @intProductBrandID = isnull(ProductBrandID,0) From ProductVersion_Platform Where PlatformID = @p_intPlatformID and ProductVersionID = @p_intProductVersionID and ProductBrandID = @p_intBrandID
					if @intProductBrandID is null
						Select @intProductBrandID = isnull(ProductBrandID,0) From ProductVersion_Platform Where PlatformID = @p_intPlatformID and ProductVersionID = @p_intProductVersionID and isnull(ProductBrandID,0) = 0

					if @intProductBrandID > 0 begin
						if not exists(Select top 1 *
						from ProductVersion_Platform PP WITH (NOLOCK) 
						INNER JOIN  PRL_Chassis Pl WITH (NOLOCK) on Pl.PlatformID = PP.PlatformID
						INNER JOIN	PRL_Products PRLP WITH (NOLOCK) on PRLP.ProductVersionID = PP.ProductVersionID
						INNER JOIN  PRL_Revision PR WITH (NOLOCK) ON PR.PRLRevisionID = PRLP.PRLRevisionID and PR.PRLID = Pl.PRLID
						Where PP.PlatformID = @p_intPlatformID 
						and PP.ProductVersionID = @p_intProductVersionID 
						and PR.StatusID in (Select StatusID from PRLStatus where Constant in ('MOL_ENG_TEST','MOL_POST_POR')))
						begin					
							if not exists(SELECT  top 1 *
							FROM	Feature FE INNER JOIN 
									Alias A ON FE.AliasID = A.AliasID INNER JOIN 
									Platform_Alias PA ON PA.AliasID = A.AliasID INNER JOIN
									AvDetail AV ON AV.FeatureID = FE.FeatureID INNER JOIN
									AvDetail_ProductBrand AVPB ON AVPB.AvDetailID = AV.AvDetailID
							WHERE	PA.PlatformID = @p_intPlatformID AND ltrim(rtrim(A.Name)) <> '' AND AVPB.ProductBrandID = @p_intBrandID AND Status in ('A'))
							begin
								Update ProductVersion_Platform
								Set	ProductBrandID = @p_intBrandID, SeriesID = @p_intSeriesID
								Where ProductVersionID = @p_intProductVersionID 
								and PlatformID = @p_intPlatformID	
						
								if @@error <> 0 begin
									raiserror('spFusion_AddPlatforms - Update Brand to Product Brand Base Unit Group failed.', 16, 1)
									rollback transaction
									RETURN 1
								end
							end
						end
					end
					else 
					begin
						Update ProductVersion_Platform
						Set	ProductBrandID = @p_intBrandID, SeriesID = @p_intSeriesID
						Where ProductVersionID = @p_intProductVersionID 
						and PlatformID = @p_intPlatformID
						if @@error <> 0 begin
							raiserror('spFusion_AddPlatforms - Update Brand to Product Brand Base Unit Group failed.', 16, 1)
							rollback transaction
							RETURN 1
						end						
					end 
					if Not exists ( select 1 from ProductVersion_Platform where PlatformID = @p_intPlatformID and SeriesID = @p_intSeriesID)
					begin
						update ProductVersion_Platform set SeriesID = @p_intSeriesID where PlatformID = @p_intPlatformID
					end
				END	
		END	

	COMMIT TRANSACTION
				--Update IRS Tables
				     EXEC IRS_usp_ADMIN_PlatformsandSystemBoardsAddOns
							@p_intPlatformID = @p_intPlatformID,
							@p_chrWebCycle = @p_chrCycle,
							@p_chrPersonFullName = @p_chrCreator,
							@p_chrLCMPSOAROID = @p_intSOARDescription,
							@p_DivisionID = @p_intBusinessSegmentID,
							@chrLCMPGenericName = @p_chrGenericName, 
							@chrLCMPMktNameMaster = @p_chrMarketingName, 
							@chrLCMPChinaGPIdentifier = @p_chrChinaIdentifier,
							@p_chrLCMPPCA = @p_chrProduct,
							@p_charAction = @Action 
		
		RETURN 0
	END

﻿

CREATE PROCEDURE [dbo].[spAddDepend2DelRoot]
 (
  @DependID int,
  @DeliverableRootID int
 )
 AS
 Insert Depend_DelRoot (DependID,DeliverableRootID)
 Values(@DependID,@DeliverableRootID)




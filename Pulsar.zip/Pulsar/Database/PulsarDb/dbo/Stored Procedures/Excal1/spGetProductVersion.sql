﻿/* ************************************************************************************************
 * Purpose:	get the fields that display in the general tab of product property page
 * Created By:	dave
 * Modified By: Ywang, 2/6/2015, selected factory list need to be pulled differently as we store multiple factories
				santodip 9/3/2015 added - v.Created,v.CreatedBy,v.Updated,v.UpdatedBy to populate product properties
				11/20/2015 - ADao return ProductRelease Column
				buidi 11/30/2015 get new roles ODMSEPMID, ProcurementPMID, PlanningPMID, ODMPIMPMID
				ADao 02/02/2016  Link to Employee either v.PMID or v.TDCCMID or v.SCMOwnerID
				02/19/2016 - Sruthi sort releases by year and month - task 16531
				03/22/2016 - SPathak break the releases into month and year when saving the releases to the look up table and use those columns to sort
				09/23/2016 - attaching code to ManufacturingSite 
				10/27/2016 - wgomero: if product is Pulsar Product then get the system board IDs from the platform table.
				12/13/2016 - linshant: add column IsExcludeIncWkfComp for PBI 28404
				04/24/2017 - Malichi, Jason - BUG 124537 - Production: Add ability to enter End of Service Life and other data lost
				08/07/2017 wgomero - get IsDesktop value to remove Notebook DCR distribution when ONLY Desktop products are selected in the DCR PBI 92721
 **************************************************************************************************/
 /** Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
**  1	20/3/18		Monica	Removed product family join,Added where fileter to product version and joined with other tables
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spGetProductVersion]
(@ID int)
AS

SET NOCOUNT ON

declare @ProductRelease varchar(max)
set		@ProductRelease = ''

select	@ProductRelease = coalesce(@ProductRelease + case len(@ProductRelease) when 0 then '' else ', ' end, '') + Name
from	ProductVersion_Release pr WITH(NOLOCK)
		inner join ProductVersionRelease pv WITH(NOLOCK) 
		on pr.ReleaseID = pv.ID
where	pr.ProductVersionID = @ID
order by pv.ReleaseYear desc, pv.ReleaseMonth desc

SELECT
    v.rctosites, v.RolloutP1,v.RolloutP2,v.RolloutP3,v.BaseUnit, v.OnCommodityMatrix, v.AccessoryPMID, v.CommodityLock, v.CurrentROM, v.OSSupport, v.ImagePO, v.ImageChanges, v.SystemBoardID, v.MachinePNPID, v.CommonImages, v.CertificationStatus, v.PartnerID, p.name as Partner,v.RegulatoryModel,
	SystemboardComments = CASE
							WHEN (v.FusionRequirements = 1) THEN dbo.fnGetProductSystemBoardIDs(@ID)
								ELSE v.SystemBoardComments
							END, 
	v.MachinePNPComments,
	v.SWQAStatus, v.actionnotifylist, v.PlatformStatus, v.Active, v.EmailActive, v.Approver, v.SEPMID, v.Division, v.productName as name, v.Version, v.ProductFamilyID, e2.email as SEPMEmail, e2.name as SEPMName, e3.Name as SMName,e3.email as SMEmail,AllowSMR,AllowDeliverableReleases,AllowDCR,AllowImageBuilds,
	v.fusion, v.GraphicsControllerPMID, v.DCRAutoOpen,e.email as PMEmail,  e.Name AS PMName, v.BIOSLeadID, v.PMID, v.TDCCMID, v.SMID,replace(v.Distribution, '; ', ';') as Distribution, v.ID, v.PDDReleased, v.PRDReleased, v.DOTSName, v.Cycle, v.StreetName, v.Description, v.Objectives, v.TypeID, v.referenceID, v.DevCenter,v.ReleaseTeam,
	v.SysEngrProgramCoordinatorID,v.ProductLineId, ProductLine.[Description] AS ProductLineName, bseg.[Name] AS BusinessSegmentName,v.setestid, v.WWANProduct, v.ToolAccessList,v.actionnotifylist, v.ServiceLifeDate,ps.name as ProductStatus, v.productstatusid, v.OnlineReports, v.Sustaining, v.Brands,'' as ProductFilePath, SCMPath, PDDPath, STLStatusPath, AccessoryPath, ProgramMatrixPath, PDEID,v.ComMarketingID, v.ConsMarketingID, v.SMBMarketingID, v.PlatformDevelopmentID, v.SupplyChainID, v.ServiceID, 
	v.CallDataLastUpdated, v.QualityID, v.currentwebrom,v.PreinstallTeam, v.SEPE, v.PINPM, v.ODMTestLeadID, v.WWANTestLeadID, v.SETestLead, v.SCFactoryEngineerID, v.CommHWPMID, v.VideoMemoryPMID, v.ProcessorPMID, v.SustainingMgrID, v.PreinstallCutoff, v.SustainingSEPMID, 
	v.PCID, v.MarketingOpsID, v.ShowOnWhql, v.DCRApproverList,
	ISNULL(v.BusinessSegmentId,0) as BusinessSegmentId, v.FusionRequirements, v.Gplm, v.Spdm, v.DCRDefaultOwner, v.SvcBomAnalyst, v.RTMNotifications, v.ConveyorBuildDistribution, v.ConveyorReleaseDistribution, v.DocPM, v.DKCID, dc.BusinessId, dc.Business, dc.Name AS DevCenterName, v.AgencyVersion, v.SETestLead, v.MinRoHSLevel, RoHS.Name as MinRoHSLevelName, v.AffectedProduct, v.BSAMFlag, v.AddDCRNotificationList, v.QualityID, b.BusinessID AS BrandBusinessID, pb.LastPublishDt,
	FactoryId = 0, 
	FactoryName = STUFF((select ', ' + ManufacturingSite.Name + ' (' + ManufacturingSite.Code + ')'
									  from ManufacturingSite WITH(NOLOCK)
									  inner join product_Factory WITH(NOLOCK)
											 on ManufacturingSite.ManufacturingSiteId = 	product_Factory.FactoryID								
										where 	product_Factory.Productversionid = v.ID											
									  for xml path('') ), 1, 2, ''),
	v.AutoSimpleAV, v.ProgramBusinessManagerID,
	pfr.IsPlatformRTM,v.Created,v.CreatedBy,v.Updated,v.UpdatedBy,
	RTPandEMDate = dbo.ufn_ProductHasValidScheduleDate(@ID),
	ProductRelease =  @ProductRelease,
	[ODMSEPMID] = isnull(v.ODMSEPMID,0),
	[ProcurementPMID] = isnull(v.ProcurementPMID,0),
	[PlanningPMID] = isnull(v.PlanningPMID,0),
	[ODMPIMPMID] = isnull(v.ODMPIMPMID,0),
	v.IsExcludeIncWkfComp,
	v.ServiceLifeDate,
	bseg.Operation,
	AllowFollowMarketingName = ISNULL(v.AllowFollowMarketingName,0)
FROM (SELECT *
	FROM dbo.ProductVersion v  with (NOLOCK)
	where  	v.ID = @ID)v
	--INNER JOIN dbo.ProductFamily f  with (NOLOCK) ON v.ProductFamilyID = f.ID
	INNER JOIN dbo.Employee e  with (NOLOCK) 
	ON (v.PMID = e.ID or v.TDCCMID = e.ID or v.SCMOwnerID = e.ID)
	INNER JOIN employee e2 with (NOLOCK)
	 ON v.SEPMID = e2.ID
	INNER JOIN employee e3 with (NOLOCK) 
	ON v.SMID = e3.ID
	INNER JOIN productstatus ps with (NOLOCK) 
	ON v.ProductStatusID = ps.ID
	LEFT OUTER JOIN DevCenter dc with (NOLOCK) 
	ON v.DevCenter = dc.ID
	LEFT OUTER JOIN Partner p with (NOLOCK) 
	ON v.PartnerID = p.ID
	LEFT OUTER JOIN Product_Brand pb with (NOLOCK) 
	ON pb.ProductVersionID = v.ID
	LEFT OUTER JOIN Brand b with (NOLOCK) 
	ON b.ID = pb.BrandID
	LEFT OUTER JOIN RoHS with (NOLOCK) 
	ON v.MinRoHSLevel = RoHS.ID
	LEFT OUTER JOIN ProductLine with (NOLOCK) 
	ON v.ProductLineId = ProductLine.ID
	LEFT OUTER JOIN BusinessSegment bseg with (NOLOCK) 
	ON v.BusinessSegmentID = bseg.BusinessSegmentID
	LEFT OUTER JOIN ProductVersion_PlatformRTMStatus pfr with (NOLOCK) 
	ON v.ID = pfr.ProductVersionID
	
--WHERE 
--	v.ID = @ID

	SET NOCOUNT OFF
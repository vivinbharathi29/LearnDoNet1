﻿
CREATE PROCEDURE [dbo].[rpt_SelectAvMrDates]
	@p_ProductBrandID INT
AS

/******************************************************************************
**		File: 
**		Name: rpt_SelectAvMrDates
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/

SELECT
	ad.AvNo, ad.GPGDescription, amdp.*
FROM
	AvFeatureCategory afc with (NOLOCK)
	INNER JOIN AvDetail ad with (NOLOCK) ON afc.AvFeatureCategoryID = ad.FeatureCategoryID 
	RIGHT OUTER JOIN AvDetail_ProductBrand adpb with (NOLOCK) ON ad.AvDetailID = adpb.AvDetailID 
	LEFT OUTER JOIN AvMrDates_Pivot amdp with (NOLOCK) ON amdp.DatesAvDetailID = adpb.AvDetailID 
		AND amdp.DatesProductBrandID = adpb.ProductBrandID
WHERE
	adpb.ProductBrandID = @p_ProductBrandID
ORDER BY
	afc.SortOrder, adpb.SortOrder, ad.GPGDescription, ad.AvNo




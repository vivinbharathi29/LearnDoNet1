﻿

CREATE PROCEDURE [dbo].[spGetPartnerType] 
(
	@PartnerID int
)
AS

	Select partnerTypeID
	from partner with (NOLOCK)
	where id = @PartnerID

	


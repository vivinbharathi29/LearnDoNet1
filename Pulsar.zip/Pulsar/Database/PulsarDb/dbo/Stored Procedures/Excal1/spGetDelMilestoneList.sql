﻿/**************************************************************************************************
 Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
**  2	21/3/18		22/03/2018	Changed ansi standard
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spGetDelMilestoneList] 
 (
  @DeliverableRootID int,
  @DeliverableVersionID int
 )
AS
	SET NOCOUNT ON
If @DeliverableVersionID = 0

	 SELECT s.ID, v.Version, v.Revision, v.Pass,v.PartNumber,s.Milestone,s.Planned, s.Actual, ss.Status, s.ReportMilestone
	 FROM DeliverableVersion v with (NOLOCK)
	 INNER JOIN DeliverableSchedule s with (NOLOCK) ON v.id = s.DeliverableVersionID
	 INNER JOIN ScheduleStatus ss with (NOLOCK) ON ss.Id =s.StatusID
	 WHERE 
		 v.DeliverableRootID = @DeliverableRootID
	 ORDER By Version, Revision, Pass, s.MilestoneOrder
	
else
	 SELECT s.ID, v.Version, v.Revision, v.Pass,v.PartNumber,s.Milestone,s.Planned, s.Actual, ss.Status, s.ReportMilestone
	 FROM DeliverableVersion v with (NOLOCK)
	 INNER JOIN DeliverableSchedule s with (NOLOCK) ON v.id = s.DeliverableVersionID
	 INNER JOIN ScheduleStatus ss with (NOLOCK) ON ss.Id = s.StatusID
	 WHERE 
	   s.DeliverableVersionID = @DeliverableVersionID
	 ORDER By Version, Revision, Pass, s.MilestoneOrder

	SET NOCOUNT OFF
RETURN




﻿

CREATE PROCEDURE [dbo].[spCountRoadmapTasks4Product] 

(
	@ProdID int,
	@ID int =0
)

AS

	Select count(*) as TaskCount
	from DeliverableIssues a with (NOLOCK), employee e with (NOLOCK), actionstatus s with (NOLOCK)
	where s.id = a.status
	and a.status in (1,7)
	and a.ownerid = e.id
	and a.type=2
	and (ActionRoadmapID=@ID)
	and a.productversionid = @Prodid



﻿

CREATE PROCEDURE [dbo].[spGetRootProperties4Version]
 (
  @ID as int
 )
 AS
SELECT  c.fccrequired, r.ReturnCodes, r.desktops, r.developerid, r.transferserverid, r.SoftpaqCategoryID, r.deliverablespec, r.notifications, r.SWSetupCategoryID, s.name as SoftpaqCategory, r.MultiLanguage,r.categoryid as category, r.Name as Name,v.id as VendorID, v.name as Vendor, r.TypeID as Type, basePartnumber as Part, r.OtherDependencies as Depends, 1 as PNRev, null as Dash, r.DevManagerID as ManagerID, r.Description as Description, 0 as KIT, r.WorkflowID as WorkflowID
FROM DeliverableRoot r WITH (NOLOCK)
INNER JOIN Vendor v WITH (NOLOCK) ON r.VendorID = v.ID
INNER JOIN DeliverableCategory c WITh (NOLOCK) ON c.ID = r.CategoryID
LEFt OUTER JOIN SoftpaqCategory s WITH (NOLOCK) ON s.ID = r.softpaqcategoryid
WHERE r.ID = @ID

return

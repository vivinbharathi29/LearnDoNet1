﻿CREATE PROCEDURE [dbo].[spGetLeadProductRootExceptions]
(
	@ProductID int,
	@RootID int,
	@ReleaseID int = 0
)
AS
	if @ReleaseID = 0
	begin
		Select SyncDistribution, SyncImages, SyncNotes , SyncComments
		From product_delroot with (NOLOCK)
		where productversionid = @ProductID
		and deliverablerootid = @RootID
	end
	else
	begin
		Select pdrr.SyncDistribution, pdrr.SyncImages, pdrr.SyncNotes , pdrr.SyncComments
		From product_delroot pdr with (NOLOCK) inner join
		Product_DelRoot_Release pdrr with (NOLOCK) on pdr.id = pdrr.ProductDelRootID
		where productversionid = @ProductID
		and deliverablerootid = @RootID
		and ReleaseID = @ReleaseID
	end


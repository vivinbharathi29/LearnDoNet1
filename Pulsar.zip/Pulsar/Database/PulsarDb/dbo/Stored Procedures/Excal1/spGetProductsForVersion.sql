﻿-- =============================================  
-- Author:  Kenneth M. Berntsen  
-- Create date: 08/09/2011  
-- Description: Selects Agency Items that are Past Due for the Today Page  
-- =============================================  
/*** Change History      
**************************************************************************************************  
** SNo   Date        Author  Description      
** --    --------   -------   -------------------------      
** 01	3/20/2018	Aashish	Filtered the table Product_Deliverable with the input parameter before joining with the other tables.    
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spGetProductsForVersion]   
(  
 @ID as int  
) AS    
    
		SELECT  T.ID,   
		   AllowSMR,   
		   Family,   
		   Version,   
		   Active,   
		   Sustaining,   
		   SEPMMail,   
		   DevCenter,   
		   ReleaseTeam,   
		   FCS,   
		   COUNT(pr.ID) AS ReleaseCount,   
		   PreinstallTeam,   
		   dbo.ufn_GetProductIsInProgram(t.id,4) as isCMIT,   
		   systemboardid    
		FROM   
		(    
			SELECT T1.*, T2. FCS    
			FROM    
			 (SELECT     pd.ProductVersionID AS ID,  
				v.productName AS Family,   
				v.AllowSMR,   
				v.Version AS version,   
				v.Active,   
				v.Sustaining,   
				e.Email AS SEPMMail,   
				v.DevCenter,   
				v.ReleaseTeam,   
				v.PreinstallTeam,   
				v.SystemBoardID    
			 FROM         (select ProductVersionID from dbo.Product_Deliverable with (NOLOCK) where DeliverableVersionID = @ID) AS pd    
				INNER JOIN    
						 dbo.ProductVersion AS v with (NOLOCK)   
				ON pd.ProductVersionID = v.ID   
				INNER JOIN    
						 dbo.Employee AS e with (NOLOCK)   
				ON v.SEPMID = e.ID   
				INNER JOIN    
						 dbo.ProductFamily AS f with (NOLOCK)   
				ON v.ProductFamilyID = f.ID    
		--WHERE     (pd.DeliverableVersionID = @ID)  
		 ) T1    
		  LEFT OUTER JOIN    
		 (    
		 SELECT  pr.ProductVersionID,   
		   COALESCE (sd.actual_end_dt, sd.projected_end_dt) AS FCS    
		 FROM  dbo.Schedule_Data AS sd with (NOLOCK)   
		   INNER JOIN    
		   dbo.Schedule AS s with (NOLOCK)   
		   ON sd.schedule_id = s.schedule_id   
		   INNER JOIN    
		   dbo.Product_Release AS pr with (NOLOCK)   
		   ON s.product_release_id = pr.ID    
		 WHERE  (pr.ReleaseID = 1) AND (sd.schedule_definition_data_id = 60)    
		 ) T2   
		 ON T1.ID = T2.ProductVersionID  
		) T   
		   LEFT OUTER JOIN dbo.Product_Release pr   
		   ON T.ID = pr.ProductVersionID    
		GROUP BY T.ID,   
		   AllowSMR,   
		   Family,   
		   Version,   
		   Active,   
		   Sustaining,   
		   SEPMMail,   
		   DevCenter,   
		   ReleaseTeam,   
		   FCS,   
		   PreinstallTeam,   
		   SystemBoardID    
		 ORDER BY family,   
		   version 
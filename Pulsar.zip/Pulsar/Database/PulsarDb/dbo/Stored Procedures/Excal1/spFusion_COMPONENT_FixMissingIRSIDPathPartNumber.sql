﻿CREATE PROCEDURE [dbo].[spFusion_COMPONENT_FixMissingIRSIDPathPartNumber]
(
	@Versionid int
)
AS
BEGIN


Declare @ExcaliburID int
Declare @PartNumber varchar(18)
Declare @IRSRoot int
Declare @IRSPassID int
Declare @IRSVersion int
Declare @IRSRevision int
declare @IRSPath varchar(512)



	DECLARE FixIRSIDPartPass_CURSOR CURSOR FOR 	Select d.id as ExcaliburID, g.partno, p.componentpassid,  rr.revisionid,  v.componentversionid , r.rootid, g.binarylocation + g.CVASubPath
						from irs_deliverableroot r WITH (NOLOCK), irs_root_revision rr WITH (NOLOCK), irs_revision_language rl WITH (NOLOCK), irs_componentversion v WITH (NOLOCK), irs_componentpass p WITH (NOLOCK), irs_component_generalinfo g WITH (NOLOCK), deliverableversion d WITH (NOLOCK)
						where rr.rootid = r.rootid
						and rl.revisionid = rr.revisionid
						and p.componentversionid = v.componentversionid
						and v.componentversionid = rl.componentversionid
						and g.componentpassid = p.componentpassid
						and v.name = d.deliverablename
						and p.version = d.Version
						and p.pass = d.pass
						and p.revision = d.revision
						and d.id = @VersionID
			
	open FixIRSIDPartPass_CURSOR
	
	FETCH NEXT FROM FixIRSIDPartPass_CURSOR Into @ExcaliburID, @PartNumber, @IRSPassID, @IRSRevision, @IRSVersion, @IRSRoot, @IRSPath
	WHILE (@@fetch_status <> -1)
		BEGIN
			If (@@fetch_status <> -2)
				BEGIN
					
					Update deliverableversion
					set irspartnumber = case when rtrim(isnull(irspartnumber,'')) = '' or irspartnumber = 'Pending...' then @PartNumber else irspartnumber end, IRSID = @IRSPassID, IRSVersionID=@IRSVersion, IRSRootID = @IRSRoot, IRSRevisionID=@IRSRevision
					where id = @ExcaliburID
				END
			FETCH NEXT FROM FixIRSIDPartPass_CURSOR Into @ExcaliburID, @PartNumber, @IRSPassID, @IRSRevision, @IRSVersion, @IRSRoot, @IRSPath
		END
	DEALLOCATE FixIRSIDPartPass_CURSOR	

end
GO


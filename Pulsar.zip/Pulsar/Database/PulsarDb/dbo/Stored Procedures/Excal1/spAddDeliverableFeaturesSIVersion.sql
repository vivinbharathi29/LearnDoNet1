﻿CREATE PROCEDURE [dbo].[spAddDeliverableFeaturesSIVersion] 
/* ************************************************************************************************
 * Purpose:	
 * Created By:	
 * Modified By: Luhit Young (3/25/2015) Changed Sudden Impact Server and Database hardcodes.
 * Notes: As of March 25, 2015, 
 *        gvs90671.houston.hp.com is the test instance of Sudden Impact
 *        gvv41555.houston.hp.com is the production instance of Sudden Impact
 *        SQLCMD Variables to be used are: $(SuddenImpactServer) and $(SuddenImpactDatabase)
 *        for server and database, respectively.
 * Notes: As of August 4, 2015, 
 *        $(SuddenImpactServer) is no longer used. Instead a LinkedServer by name of LinkedServer_SuddenImpact is now defined as a linked server.
 *        SQLCMD Variables to be used are: $(SuddenImpactDatabase) for the database.
 **************************************************************************************************/
(
	@VersionID int,
	@FeatureID int
)
AS
	Begin
	
	Declare @ErrorCode int
	Select @ErrorCode = @@Error
	
	-- EXEC [gvv41555.houston.hp.com,2048].simpact.dbo.AddFeature 0, @VersionID, @FeatureID
	EXEC [LinkedServer_SuddenImpact].[$(SuddenImpactDatabase)].dbo.AddFeature 0, @VersionID, @FeatureID
	Select @ErrorCode = @@Error
	
	Return @ErrorCode	
	end
GO


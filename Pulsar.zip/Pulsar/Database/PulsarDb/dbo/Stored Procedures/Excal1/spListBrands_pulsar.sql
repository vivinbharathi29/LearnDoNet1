﻿CREATE PROCEDURE [dbo].[spListBrands_pulsar]


/* ************************************************************************************************
 * Purpose:	based on spListBrands, this is the pulsar version , returning more fields
 * Created By:	Ywang, 2/4/2015
 * Modified By: Ywang, 2.27/2015, sort by brand name, pbi 8503
				SPathak, 3/17/2015 - Task 8794 return brand names those don't have formula created
				ThTran,  6/03/2015 - Task 10391 return brands per BusinesSegmentID if BusinesSegmentID <> 0
				SRagishetti, 11/14/2016 - Add Model number to ProductProperties
				Dean Chiang 12/11/2018, PBI 240106 - Add a new field Screen Size in Brands in Product Properties page
				linshant	02/11/2019, Move Brands field from Product Properties to Base Unit Groups - PBI 241541
 **************************************************************************************************/
@BSegmentID int = 0

AS

if (@BSegmentID = 0) begin
	Select	ID, Name, null as SeriesSummary, Abbreviation, 
			null as ProductBrandID, active, null as Suffix,
			Generation='',
			FormFactor = '',
			SCMNumber = 0,
			LastPublishDt = null,
			BrandsWOFormula = isnull((SELECT STUFF((select BrandFormulaName.Name + ','
							from BrandFormulaName 
							where BrandFormulaNameID not in (select BrandFormula.BrandFormulaNameID from Brand b1 inner join BrandFormula on Brand.ID=BrandFormula.BrandID where Brand.ID = b1.Id)
							for xml path('') ), 1, 0, '')),''),
            ProductModelNumber='',
            ScreenSize ='',
			selectedBrand=0
	From Brand with (NOLOCK)
	Where Active = 1
	Order By Name
end

else begin
	Select	ID, Name, null as SeriesSummary, Abbreviation, 
			null as ProductBrandID, active, null as Suffix,
			Generation='',
			FormFactor = '',
			SCMNumber = 0,
			LastPublishDt = null,
			BrandsWOFormula = isnull((SELECT STUFF((select BrandFormulaName.Name + ','
							from BrandFormulaName 
							where BrandFormulaNameID not in (select BrandFormula.BrandFormulaNameID from Brand b1 inner join BrandFormula on Brand.ID=BrandFormula.BrandID where Brand.ID = b1.Id)
							for xml path('') ), 1, 0, '')),''),
			ProductModelNumber='',
            ScreenSize ='',
			selectedBrand=0
	From Brand with (NOLOCK)
	Where Active = 1 and isnull(BusinessSegmentID, 0) = @BSegmentID
	Order By Name
end

RETURN 0



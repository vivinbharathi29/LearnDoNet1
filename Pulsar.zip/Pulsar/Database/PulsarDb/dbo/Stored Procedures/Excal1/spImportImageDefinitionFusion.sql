﻿


CREATE PROCEDURE [dbo].[spImportImageDefinitionFusion]
/* ************************************************************************************************
 * Purpose:	
 * Created By:	
 * Modified By:	05/11/2016 , ywang, we reserved the productdrop table for product explorer, renamed the previous one in pulsar productdrop1			
 **************************************************************************************************/
(
	@ImageID int,
	@ProductID int,
	@NewID int output
)	
 AS

	Declare @ProductDropID int

	insert into productdrop1(Name)
	values('')
	Select @ProductDropID = SCOPE_IDENTITY()

	insert into productversion_productdrop (ProductVersionID,ProductDropID)
	values(@ProductID,@ProductDropID)



	insert ImageDefinitions(ProductVersionID,SKUNumber,BrandID, OSID , SWID, ImageType,Modified,Active, StatusID, CopyID, ProductDropID,Comments,FeatureID)
	Select -1, SkuNumber, BrandID, OSID, SWID,ImageType,GetDate(),1,1,@ImageID,@ProductDropID,Comments,FeatureID
	FROM ImageDefinitions with (NOLOCK)
	Where ID = @ImageID
	and Active=1
	Select @NewID = SCOPE_IDENTITY()

	insert into ImageDefinition_Brand(BrandID,ImageDefinitionID)
	Select BrandID,@NewID
	from ImageDefinition_Brand
	where ImageDefinitionID = @ImageID



﻿CREATE PROCEDURE [dbo].[spLinkVersion2Product]
(
  @ProductID as int,
  @DeliverableID as int,
  @ProductVersionReleaseID as int = 0,
  @Username varchar(50) = '',
  @userID int = 0
)
AS
Declare @RootID int
Declare @Prereleased bit
Declare @DelType int
Declare @PMAlert bit
Declare @ProdDelID int
Declare @HFCN tinyint
declare @Status int

Declare @DevCenter int
Declare @PINTeam int
declare @Fusion bit
declare @AutoTargeted bit = 0

set nocount on
	Select @DevCenter = DevCenter, @PINTeam = PreinstallTeam, @Fusion = Fusion
	from ProductVersion
	where ID = @ProductID

	if (@DevCenter <> 2 or @Fusion=1 or @ProductID=1145 or @ProductID=1176 or @ProductID=1164 or @ProductID=1155 or @ProductID=1147 or @ProductID=1152 or @ProductID=1197or @ProductID=1192 or @ProductID=1101 or @ProductID=1190)-- and @PINTeam <> 6 --Commercial, but not Thin Client (Alan Tran asked that we remove this filter)
		update DeliverableVersion
		set desktops=1
		where ID=@DeliverableID

set nocount off

--See if HFCN was checked for hardware.  If so, we can go ahead and flag the DCRID field to say it is an HFCN
Select @HFCN = v.HFCN from DeliverableVersion v with (NOLOCK), DeliverableRoot r with (NOLOCK) where v.deliverablerootid = r.id and r.typeid=1 and v.ID = @DeliverableID
if @HFCN=1
	Select @HFCN=2
else
	Select @HFCN=0

Select @RootID = r.ID, @Status = v.status, @Prereleased = v.Prereleased, @DelType = r.TypeID
from deliverableversion v with (NOLOCK), DeliverableRoot r with (NOLOCK)
where v.id = @DeliverableID
and r.id = v.deliverablerootID

IF EXISTS (select top 1 * from DeliverableCategory where id = (select CategoryID from deliverableroot where ID = @RootID) and DeliverableTypeID = 1 and Active = 1 and AutoTarget = 1)
BEGIN
	set @AutoTargeted = 1
END

--Notify PM a new deliverable has been added to their product
if  (@DelType = 2 or @DelType = 3) and (@Prereleased = 1 or @Status=3)
	Select @PMAlert = 1
else
	Select @PMAlert = 0

--Make sure Product_DelRoot record exists (Product has asked for this deliverable - HFCN fix)
Select @ProdDelID = ID
from Product_DelRoot with (NOLOCK)
where DeliverableRootID = @RootID
and ProductVersionID = @ProductID
Declare @PDID int
IF @ProdDelID is null
BEGIN
	Insert Product_Deliverable (Patch,SyncDistribution, SyncNotes, SyncImages, DCRID, Productversionid,DeliverableVersionId,Locked,targeted, DeveloperNotificationStatus, Preinstall,Preload,DropInBox,Web,SelectiveRestore,ARCD,DRDVD,RACD_Americas,RACD_APD,RACD_EMEA,OSCD,DocCD,ImageSummary,PMAlert,TargetNotes, Images)
	Values( 0,1,1,1,@HFCN,@ProductID,  @DeliverableID,0,@AutoTargeted,1,0,0,0, 0,0,0,0,0,0,0,0,0,'',0,'', '')
	SET @PDID = @@IDENTITY
END
ELSE
BEGIN
	IF NOT EXISTS(SELECT * FROM Product_Deliverable WHERE Productversionid=@ProductID AND   DeliverableVersionId=@DeliverableID)
	BEGIN 
			Insert Product_Deliverable (Patch,SyncDistribution, SyncNotes, SyncImages, DCRID, Productversionid,DeliverableVersionId,Locked,targeted,  DeveloperNotificationStatus, Preinstall, PreinstallBrand,Preload,PreloadBrand,DropInBox,Web,SelectiveRestore,ARCD,DRDVD,RACD_Americas,RACD_APD,RACD_EMEA,OSCD,DocCD,ImageSummary,PMAlert,TargetNotes,OOCRelease, RestoreImages, Images)
			Select Patch,SyncDistribution, SyncNotes, SyncImages, @HFCN, @ProductID,  @DeliverableID,0,@AutoTargeted,1,Preinstall,PreinstallBrand,Preload,PreloadBrand, DropInBox, Web,SelectiveRestore,ARCD,DRDVD,RACD_Americas,RACD_APD,RACD_EMEA,OSCD,DocCD,ImageSummary,@PMAlert,TargetNotes,OOCRelease, RestoreImages, Images
			from Product_DelRoot with (NOLOCK)
			where DeliverableRootID = @RootID
			and ProductVersionID = @ProductID
			SET @PDID = @@IDENTITY
	END
	ELSE 
	BEGIN
		select @PDID=ID from Product_Deliverable where Productversionid=@ProductID and   DeliverableVersionId=@DeliverableID
	END
END


if @ProductVersionReleaseID > 0 
begin
	exec usp_ComponentVersion_AddProductRelease @PDID, @DeliverableID, @ProductVersionReleaseID, @Username, @userID
end
﻿CREATE PROCEDURE [dbo].[spFusion_AddPlatformsAlias] 
-- =============================================
-- Author:		 wgomero : 
-- Create date: 02/11/2016
-- Description:	Create Alias and add to Platform_Alias Table
-- Modified By: 03/22/2016 santodip - output parameter @p_chrReturnID needs to be returned - task 18498
--				03/29/2016, Ravi Nukala - Replaced @@IDENTITY with SCOPE_IDENTITY(), Task 18865
-- =============================================

	@p_chrAliasName varchar(80),
	@p_chrCreator  varchar(64),
	@p_chrUpdater  varchar(64),
	@p_chrMktNameMaster  varchar(100),
	@p_chrChinaGPIdentifier  varchar(256),
	@p_intPlatformID int,
	@p_chrReturnID int OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @p_intAliasID int 
	BEGIN TRANSACTION	
			-- create new alias
			INSERT INTO ALIAS(Name, Creator, Updater, TimeCreated, TimeChanged, MktNameMaster, ChinaGPIdentifier)
				  VALUES(RTRIM(@p_chrAliasName), @p_chrCreator,@p_chrUpdater, GETDATE(), GETDATE(), @p_chrMktNameMaster, @p_chrChinaGPIdentifier)

				  IF @@ERROR <> 0 
						BEGIN
							raiserror('spFusion_AddPlatformsAlias - Alias created failed.', 16, 1)
							rollback transaction
							RETURN 1
						END

				 SET @p_intAliasID = SCOPE_IDENTITY() -- get alias ID
				 SELECT @p_chrReturnID =  SCOPE_IDENTITY() -- return output parameter

				 -- add new platform-Alias to the table
				 INSERT INTO Platform_Alias(PlatformID, AliasID) VALUES(@p_intPlatformID, @p_intAliasID)

				  IF @@ERROR <> 0 
						BEGIN
							raiserror('spFusion_AddPlatformsAlias - Platform_Alias created failed.', 16, 1)
							rollback transaction
							RETURN 1
						END

	COMMIT TRANSACTION
END
﻿

CREATE PROCEDURE [dbo].[spListBrands] 
/* ************************************************************************************************
 * Purpose:	 return the active brands when creating a product
 * Created By:	
 * Modified By: Ywang, 2.27/2015, sort by brand name, pbi 8503
 **************************************************************************************************/
AS
Select ID, Name, null as SeriesSummary, Abbreviation, null as ProductBrandID, active, null as Suffix
From Brand with (NOLOCK)
Where Active = 1
Order By Name



﻿/**************************************************************************************************
** Change History    
**************************************************************************************************
** SNo   Date        Author  Description    
** --    --------   -------   -------------------------    
**  1    25/7/2018	Aashish	  Added SET NOCOUNT. Changed COALESCE to ISNULL.
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spGetReportProfile] 
(
	@ID int,
	@EmployeeID int = null
)
AS
SET NOCOUNT ON
Select *
FROM ReportProfiles with (NOLOCK)
Where ID = @ID
and EmployeeID = ISNULL(@EmployeeID,EmployeeID)
SET NOCOUNT OFF

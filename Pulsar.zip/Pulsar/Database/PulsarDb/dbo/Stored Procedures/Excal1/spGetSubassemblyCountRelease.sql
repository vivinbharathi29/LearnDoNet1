﻿CREATE PROCEDURE [dbo].[spGetSubassemblyCountRelease]
/* ************************************************************************************************
 * Purpose: Get Subassembly Count
 * Created By:	
 * Modified By: Dien Bui 4/25/2017 - Combine count for lagacy product and pulsar product
 *				
 **************************************************************************************************/
(
	@ProdID int,
	@VersionID int,
	@ProductDeliverableReleaseID int = 0
)
 AS

DECLARE @ProdDelID int
Select @ProdDelID = ID from product_deliverable with (NOLOCK) where productversionid = @ProdID and deliverableversionid = @VersionID

Select Count(*) as Number
from proddel_delroot pd with (NOLOCK) 
where pd.productdeliverableid = @ProdDelID and ProductDeliverableReleaseID = @ProductDeliverableReleaseID

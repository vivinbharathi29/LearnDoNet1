﻿
-- =============================================
-- List all open or blocked Roadmap items for the
-- selected product
-- =============================================

CREATE PROCEDURE [dbo].[spListActionRoadmap]

(
	@ProdiD int
)

AS

	Select ID, Summary, Timeframe, StatusReport, DisplayOrder
	from ActionRoadmap with (NOLOCK)
	where productversionid=@ProdID
	and ActionStatusID in (1,7)
	order by displayorder



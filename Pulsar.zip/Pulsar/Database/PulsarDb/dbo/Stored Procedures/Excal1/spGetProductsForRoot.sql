﻿CREATE PROCEDURE [dbo].[spGetProductsForRoot] 
/* Puporse: Display list of products supported the root
 * Created by: ?
 * Updated by: Dien Bui - 01/22/2018 - Need to include releases
 */
 (
	@ID int
)
 AS

	SET NOCOUNT ON;



	Create Table #ProductList (ID int, Name varchar(60), productstatusid int, AllowDeliverableReleases bit, version varchar(20), active tinyint, sustaining int, SystemBoardID varchar(200), devcenter int, ReleaseTeam int, SeriesSummary varchar(1000), ReleaseID int, VersionCount int, VersionTargetedCount int)

	Insert INTO #ProductList (ID, Name, productstatusid, AllowDeliverableReleases, version, active, sustaining, SystemBoardID, devcenter, ReleaseTeam, SeriesSummary, ReleaseID)
	SELECT distinct v.ID, v.DOTSName as Name, v.productstatusid, v.AllowDeliverableReleases, v.version, v.active, v.sustaining, SystemBoardID, devcenter, ReleaseTeam, dbo.ufn_GetSeriesList(v.id) as SeriesSummary, [ReleaseID] = 0
	From Productversion v WITH (NOLOCK) inner join 
	ProductFamily f WITH (NOLOCK) on f.Id = v.ProductFamilyId inner join 
	Product_Requirement pr WITH (NOLOCK) on v.id = pr.ProductId inner join
	ProdReq_DelRoot pd WITH (NOLOCK) on pr.id = pd.ProductRequirementID
	Where pd.DeliverableRootId = @ID
	and isnull(v.FusionRequirements,0) = 0
	Union all

	SELECT distinct v.ID, v.DotsName + ' ( ' + pvr.Name + ' )' as Name, v.productstatusid, v.AllowDeliverableReleases, v.version, v.active, v.sustaining, SystemBoardID, devcenter, ReleaseTeam, dbo.ufn_GetSeriesList(v.id) as SeriesSummary, pv_r.ReleaseID
	From Productversion v WITH (NOLOCK) inner join 
	Product_DelRoot pdr WITH (NOLOCK) on pdr.ProductVersionID = v.ID inner join
	Product_DelRoot_Release pdrr WITH (NOLOCK) on pdrr.ProductDelRootID = pdr.ID inner join
	ProductVersion_Release pv_r WITH (NOLOCK) on pv_r.ProductVersionID = v.ID and pdrr.ReleaseID = pv_r.ReleaseID inner join
	ProductVersionRelease pvr WITH (NOLOCK) on pvr.ID = pv_r.ReleaseID
	Where pdr.DeliverableRootId = @ID
	and v.FusionRequirements = 1
	order by v.DOTSName, v.version

	Create Table #VersionCount (ProductVersionID int, ReleaseID int, VersionCount int)

	Insert Into #VersionCount
	Select pv.ID, 0, Count (*)
	from product_Deliverable pd with (NOLOCK) inner join
		 deliverableversion dv with (NOLOCK) on dv.ID = pd.DeliverableVersionID inner join
		 productversion pv with (NOLOCK) on pv.ID = pd.ProductVersionID inner join
		 #ProductList tmp with (NOLOCK) on tmp.ID = pv.productversionid 
	where dv.deliverablerootid = @ID and tmp.ReleaseID = 0 group by pv.ID

	Insert Into #VersionCount
	Select pv.ID, tmp.ReleaseID, Count (*)
	from product_Deliverable pd with (NOLOCK) inner join
		 product_deliverable_release pdr with (NOLOCK) on pdr.ProductDeliverableID = pd.ID inner join
		 deliverableversion dv with (NOLOCK) on dv.ID = pd.DeliverableVersionID inner join
		 productversion pv with (NOLOCK) on pv.ID = pd.ProductVersionID inner join
		 #ProductList tmp with (NOLOCK) on tmp.ID = pv.productversionid and tmp.ReleaseID = pdr.ReleaseID
	where dv.deliverablerootid = @ID and tmp.ReleaseID > 0 group by pv.ID, tmp.ReleaseID


	update tmp
	set tmp.VersionCount = isnull(tmp2.VersionCount,0)
	from #ProductList tmp left outer join
	#VersionCount tmp2 on tmp2.ProductVersionID = tmp.ID and tmp2.ReleaseID = tmp.ReleaseID


	Create Table #VersionTargetedCount (ProductVersionID int, ReleaseID int, VersionTargetedCount int)

	Insert Into #VersionTargetedCount
	Select pv.ID, 0, Count (*)
	from product_Deliverable pd with (NOLOCK) inner join
		 deliverableversion dv with (NOLOCK) on dv.ID = pd.DeliverableVersionID inner join
		 productversion pv with (NOLOCK) on pv.ID = pd.ProductVersionID inner join
		 #ProductList tmp with (NOLOCK) on tmp.ID = pv.productversionid 
	where dv.deliverablerootid = @ID and tmp.ReleaseID = 0 and pd.targeted = 1 group by pv.ID

	Insert Into #VersionTargetedCount
	Select pv.ID, tmp.ReleaseID, Count (*)
	from product_Deliverable pd with (NOLOCK) inner join
		 product_deliverable_release pdr with (NOLOCK) on pdr.ProductDeliverableID = pd.ID inner join
		 deliverableversion dv with (NOLOCK) on dv.ID = pd.DeliverableVersionID inner join
		 productversion pv with (NOLOCK) on pv.ID = pd.ProductVersionID inner join
		 #ProductList tmp with (NOLOCK) on tmp.ID = pv.productversionid and tmp.ReleaseID = pdr.ReleaseID
	where dv.deliverablerootid = @ID and tmp.ReleaseID > 0 and pdr.targeted = 1 group by pv.ID, tmp.ReleaseID


	update tmp
	set tmp.VersionTargetedCount = isnull(tmp2.VersionTargetedCount,0)
	from #ProductList tmp left outer join
	#VersionTargetedCount tmp2 on tmp2.ProductVersionID = tmp.ID and tmp2.ReleaseID = tmp.ReleaseID

	select * from #ProductList

	Drop table #VersionCount
	Drop table #VersionTargetedCount
	Drop Table #ProductList
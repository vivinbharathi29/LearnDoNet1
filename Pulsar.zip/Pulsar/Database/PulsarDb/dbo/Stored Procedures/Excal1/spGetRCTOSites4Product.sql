﻿

CREATE PROCEDURE [dbo].[spGetRCTOSites4Product]
(
	@ID int
)
AS

	Select RCTOSites
	from productVersion with (NOLOCK)
	where ID = @ID



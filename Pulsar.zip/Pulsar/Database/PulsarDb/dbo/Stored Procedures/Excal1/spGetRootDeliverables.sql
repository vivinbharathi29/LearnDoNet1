﻿

CREATE PROCEDURE [dbo].[spGetRootDeliverables] AS
Select r.ID, r.Name, c.Name as Category, t.name as Type, e.name as Manager,r.BasePartNumber, r.RootFilename, r.description
FROM DeliverableRoot r with (NOLOCK), DeliverableCategory c with (NOLOCK), DeliverableType t with (NOLOCK), Employee e with (NOLOCK)
Where r.CategoryID = c.ID
and e.id = r.devmanagerid
AND r.TypeID = t.id
and r.active = 1 
Order By r.name;




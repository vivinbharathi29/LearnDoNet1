﻿

CREATE PROCEDURE [dbo].[spGetActionType]

(
	@ActionTypeID int
)
 AS


SELECT ID, Name
FROM
	ActionType with (NOLOCK)
WHERE
	(ID = @ActionTypeID)



﻿

CREATE PROCEDURE [dbo].[spListActionAlerts]
(
	@ProdID int,
	@OwnerID int
)
 AS

if @OwnerID=0
	Select a.id, a.summary, a.type, s.name as Status, e.name as owner, a.targetdate, a.description
	 from deliverableissues a with (NOLOCK), employee e with (NOLOCK), ActionStatus s  with (NOLOCK)
	where s.id = a.status 
	and e.id = a.ownerid 
	and a.status = 1 
	and a.priority=0 
	and a.productversionid = @ProdID
else
	Select a.id, a.summary, a.type, s.name as Status, e.name as owner, a.targetdate, a.description
	 from deliverableissues a with (NOLOCK), employee e with (NOLOCK), ActionStatus s  with (NOLOCK)
	where s.id = a.status 
	and e.id = a.ownerid 
	and a.status = 1 
	and a.priority=0 
	and a.ownerid = @Ownerid
	and a.productversionid = @ProdID



﻿
CREATE PROCEDURE [dbo].[spGetProductIsFusion]
(
	@ProductID int
)
AS

	Select fusion
	from ProductVersion WITH (NOLOCK)
	where ID = @ProductID


﻿

CREATE PROCEDURE [dbo].[spGetProductLinesAll] 
AS

SELECT [ID], [Name], [Description], [Division], [BusinessId], [BrandID], BusinessSegmentID, ProductLineId 
FROM [ProductLine] (NOLOCK)
ORDER BY [Name]


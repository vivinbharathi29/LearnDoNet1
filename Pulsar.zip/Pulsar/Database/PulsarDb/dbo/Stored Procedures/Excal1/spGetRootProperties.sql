﻿

CREATE PROCEDURE [dbo].[spGetRootProperties]
(@ID int)
AS SELECT    r.appstore, r.SIOApproverID,r.KoreanCertificationRequired, c.fccrequired, ReturnCodes,Softpaq,LangSubs, r.DeliverableSpec, CertRequired, r.ID, Admin, r.AR, SysReboot, PackageType, RoyaltyBearing, TargetPartition, LoggedIn, SysComponents, Preinstall, Rompaq, CDImage, CAB, DeveloperNotification,r.active,
                      Binary, FloppyDisk, PreinstallROM, r.Name, EndUserInstructions, SilentInstructions, BlindInstructions, UninstallInstructions, MSBatchInstructions, MultiLanguage, SoftpaqCategoryID, SWSetupCategoryID,LockReleases, CoreTeamID,
                      r.desktops, NTDSInstructions, RootFilename, OSType, Install, SilentInstall, BlindInstall, ARCDInstall, Uninstall, InstallRecover, Timeout, Reboot, SWTypeID, UseRegions, r.IconDesktop, r.IconMenu, r.IconInfoCenter, r.IconTray, r.iconpanel, r.PackageForWeb, r.PropertyTabs,
                      r.developerid, c.RequiresTTS, TypeID,t.name as DeliverableType, MRIID, Subassembly, KitNumber, KitDescription, Description, VendorID, VendorContactID, 0 as OnDOTSheet, PreInstalled, MasterIDRequired, InstallationOrder, WorkflowID, r.Notes, r.Description,r.ISOImage, r.Replicater,
                      r.SoftpaqInstructions,r.transferserverid,learnmore,hppi,Notifications, BasePartNumber, CategoryID, DevManagerID, TesterID, LeadEngineerID, DropInBox, Choice, InstallationOrder AS Expr1, 0 AS Expr2, r.MUIAware, r.MUIAwareDate,r.Patch,
                      OTSFVTOrganizationID,PreInstalled AS Expr3, MasterIDRequired AS Expr4, MRIID AS Expr5, OtherDependencies, 0 as Kit, c.teamid, Notes, DefaultUI, PNPDevices, v.Name as Vendor, e.email as DevManagerEmail, e.Name as DevManager, r.PNPDevices, r.ScriptPaq, c.Name as Category, r.OEMReadyRequired, r.OEMReadyException,
                      r.NameElements, c.RequiresFormattedName, r.Name2, r.Name3, r.Name4, r.Name5, r.Name6, r.Name7, r.Name8, systemboardid, r.DpbCompliant, r.DevicesInfPath
FROM         
	DeliverableRoot r with (NOLOCK)
	INNER JOIN Vendor v with (NOLOCK) ON v.ID = r.VendorID
	INNER JOIN Employee e with (NOLOCK) ON r.DevManagerID = e.ID
	INNER JOIN  DeliverableCategory c with (NOLOCK) ON r.CategoryID = c.ID
	INNER JOIN deliverabletype t with (NOLOCK) ON t.id = r.TypeID
WHERE     (r.ID = @ID)

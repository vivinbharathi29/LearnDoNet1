﻿/******************************************************************************
**	File: 
**	Name: 
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  02/15/2018	Santhana(auth\prabhuks) View Name changed from si_observation_report to SI_Observation_Report_Simplified 
**  12/15/2018	Santhana(auth\prabhuks) Opend Query to used to improve Remote query performance
*******************************************************************************/
CREATE PROCEDURE [dbo].[spGetOTSStatus4Category]
(
	 @platform varchar(20),
	@Milestone varchar(30) = null
)
 AS

 	DECLARE @OPENQUERY nvarchar(MAX) , @TSQL1 nvarchar(MAX),@TSQL2 nvarchar(MAX),@TSQL3 nvarchar(MAX), @LinkedServer nvarchar(MAX)
	SET @Milestone = ISNULL(@Milestone,'#')

	SET @LinkedServer = 'HOUSIREPORT01'
	SET @OPENQUERY = 'SELECT * FROM OPENQUERY('+ @LinkedServer + ','''
	SET @platform = ISNULL(@platform,'')

	SET @TSQL1 = 
	 'SELECT  count(observationid) as OTSCount, SubSystem as category, 1 as Status
	 FROM [SIO].dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
	 WHERE 
	 GatingMilestone = coalesce(nullif('''''+ @Milestone+''''',''''#''''),GatingMilestone)
	 and PrimaryProduct ='''''+ @platform + '''''
	 and Priority = 1 
	 and Status <> ''''Closed''''
	 Group BY  Subsystem, status'
	 

	 SET @TSQL2 =  'SELECT  count(observationid) as OTSCount, SubSystem as category, 2 as Status
	 FROM [SIO].dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
	 WHERE 
	 GatingMilestone = coalesce(nullif('''''+ @Milestone+''''',''''#''''),GatingMilestone)
	 and PrimaryProduct = '''''+ @platform + ''''' 
	 and Priority = 1 
	 and Status=''''Closed''''
	 Group BY  Subsystem, status'


	 SET @TSQL3 = 'SELECT  count(observationid) as OTSCount, SubSystem as category, 3 as Status
	 FROM [SIO].dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
	 WHERE 
	 GatingMilestone = coalesce(nullif('''''+ @Milestone+''''',''''#''''),GatingMilestone)
	 and PrimaryProduct = '''''+ @platform + '''''  
	 and Priority = 1 
	 and state = ''''Under Investigation''''
	 and Status <> ''''Closed''''
	 Group BY  Subsystem, state
	 Order by Subsystem, Status'''+')'

	 --print @OPENQUERY+@TSQL1 + ' Union ' + @TSQL2 + ' Union ' + @TSQL3
	  
	EXEC (@OPENQUERY+@TSQL1 + ' Union ' + @TSQL2 + ' Union ' + @TSQL3 ) 
GO

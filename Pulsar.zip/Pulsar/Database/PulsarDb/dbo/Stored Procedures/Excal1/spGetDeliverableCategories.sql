﻿

CREATE PROCEDURE [dbo].[spGetDeliverableCategories] 
(
	@ProdID int = 0
)
AS
if @ProdID = 0
	SELECT c.ID,c.name, c.DeliverableTypeID,c.RequireCountries, t.Name as Type, NameFormat
	FROM DeliverableCategory c with (NOLOCK), DeliverableType t with (NOLOCK)
	WHERE t.ID = c.DeliverableTypeID
	ORDER BY c.DeliverableTypeID, c.Name
else
	SELECT Distinct c.ID,c.name, c.DeliverableTypeID,c.RequireCountries, t.Name as Type, NameFormat
	FROM DeliverableCategory c with (NOLOCK), DeliverableType t with (NOLOCK), deliverableroot r with (NOLOCK), product_delRoot pr with (NOLOCK)
	WHERE t.ID = c.DeliverableTypeID
	and r.categoryid = c.id
	and pr.deliverablerootid = r.id
	and pr.productversionid = @Prodid
	ORDER BY c.DeliverableTypeID, c.Name





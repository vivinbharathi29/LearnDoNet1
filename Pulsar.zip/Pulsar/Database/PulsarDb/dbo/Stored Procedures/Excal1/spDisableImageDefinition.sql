﻿

CREATE PROCEDURE [dbo].[spDisableImageDefinition]
(
	@ImageDefID int
)
 AS
Update ImageDefinitions
Set Active = 0
Where Id = @ImageDefID




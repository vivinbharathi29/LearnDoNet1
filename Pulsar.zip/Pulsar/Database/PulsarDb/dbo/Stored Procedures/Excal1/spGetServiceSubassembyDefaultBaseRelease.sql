﻿CREATE PROCEDURE [dbo].[spGetServiceSubassembyDefaultBaseRelease] 
/**************************************************************************
Purpose: get the base sub-assembly number for the component used in all the product
Created:
Modified: 7/24/2017 Shraddha - Subassembly numbers added to a root on a Legacy Product should show on Pulsar Product and vice-versa - Bug 148394
			7/25/2017 shraddha - remove the check for business segment when getting the list of base subassembly for pulsar product
***************************************************************************/
(
	@ProductVersionID int,
	@DeliverableRootID int
)
AS

--list of service subassembly from pulsar products
Select distinct isnull(pdr.serviceBase, '') as BaseNumber, DevCenter, TypeID=2
from product_delroot pd with (NOLOCK)
inner join productversion v with (NOLOCK) on v.id = pd.productversionid
inner join product_delroot_release pdr with (NOLOCK) on pdr.ProductDelrootID = pd.ID
where pdr.servicebase is not null
and pdr.servicebase <> ''
and DeliverableRootID = @DeliverableRootID

union --list of service subassembly from legacy products

Select distinct pd.serviceBase as BaseNumber, DevCenter, TypeID=2
from product_delroot pd with (NOLOCK), productversion v with (NOLOCK)
where v.id = pd.productversionid
and servicebase is not null
and servicebase <> ''
and DeliverableRootID = @DeliverableRootID

union --list of engg subassembly from pulsar products

Select distinct pdr.Base as BaseNumber, DevCenter, TypeID=1
from product_delroot pd with (NOLOCK)
inner join productversion v with (NOLOCK) on v.id = pd.productversionid
inner join product_delroot_release pdr with (NOLOCK) on pdr.ProductDelrootID = pd.ID
where pdr.base is not null
and pdr.base <> ''
and DeliverableRootID = @DeliverableRootID

union --list of engg subassembly from legacy products

Select distinct pd.Base as BaseNumber, DevCenter, TypeID=1
from product_delroot pd with (NOLOCK), productversion v with (NOLOCK)
where v.id = pd.productversionid
and base is not null
and base <> ''
and DeliverableRootID = @DeliverableRootID

order by typeid, DevCenter
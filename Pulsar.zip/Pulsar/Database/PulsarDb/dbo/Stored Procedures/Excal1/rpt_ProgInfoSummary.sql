﻿
CREATE PROCEDURE [dbo].[rpt_ProgInfoSummary]
	/* Param List */
AS
/******************************************************************************
**	File: dbo.rpt_ProgInfoSummary.sql
**	Name: rpt_ProgInfoSummary
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  01/20/2015	ADao				Return Generation column
*******************************************************************************/

	SELECT
		v.ID AS id,
		v.productName AS name,
		v.Version AS version,
		v.dotsname as Product,
		v.SystemBoardID,
		v.PartnerID,
		v.PreinstallTeam,
		v.TypeID,
		v.Division,
		v.Sustaining,
		v.DevCenter,
		v.Active,
		v.ProductFilePath,
		v.PDDPath,
		v.PlatformDevelopmentID,
		p.Name AS Partner,
		dbo.ufn_GetSeriesList(v.id) AS SeriesList,
		stl.Name AS STL,
		stl.ID as STLID,
		stl.email as STLEmail,
		cm.Name AS CM,
		cm.Email AS CMMail,
		cm.ID AS CMID,
		sepm.Name AS SEPM,
		sepm.Email AS SEPMMail,
		sepm.ID AS SEPMID,
		sepe.name AS SEPE,
		sepe.Email AS SEPEMail,
		sepe.ID AS SEPEID,
		pinpm.name AS PINPM,
		pinpm.Email as PINPMMail,
		pinpm.id as PINPMID,
		setl.name AS SETL,
		setl.email AS SETLMail,
		setl.id AS SETLID,
		pdm.name AS PDM,
		pdm.email AS PDMEmail,
		pdm.id AS PDMID,
		v.ProductStatusID,
		v.RegulatoryModel,
		COALESCE(pp.ProgramID, 0) AS ProgramID,
		eop.EndOfProduction,
		v.servicelifedate,
		v.servicefamilypn,
		v.dotsname,
		svc.Name AS ServiceManager,
		svc.Email as ServiceEmail,
		svc.ID as ServiceID,
		(CASE 
		WHEN v.Division=1 THEN 'Notebooks'
		WHEN v.Division=2 THEN 'Desktops'
		END)
		As DivisionType,
		dbo.ufn_GetProductGeneration(v.id) AS Generation
	FROM
		ProductFamily f with (NOLOCK) 
		INNER JOIN ProductVersion v with (NOLOCK) ON f.id = v.productfamilyid
		INNER JOIN Partner p with (NOLOCK) ON v.partnerid = p.id 
		LEFT OUTER JOIN Product_Program pp with (NOLOCK) ON pp.ProductVersionID = v.id 
		LEFT OUTER JOIN Employee stl with (NOLOCK) ON stl.id = v.smid
		LEFT OUTER JOIN Employee sepm with (NOLOCK) ON sepm.id = v.sepmid 
		LEFT OUTER JOIN Employee cm with (NOLOCK) ON cm.id = v.pmid
		LEFT OUTER JOIN Employee sepe with (NOLOCK) ON sepe.id = v.sepe
		LEFT OUTER JOIN Employee pinpm with (NOLOCK) ON pinpm.id = v.pinpm 
		LEFT OUTER JOIN Employee setl with (NOLOCK) ON setl.id = v.setestlead
		LEFT OUTER JOIN Employee svc with (NOLOCK) ON svc.ID = v.ServiceID
		LEFT OUTER JOIN Employee pdm with (NOLOCK) ON pdm.id = v.PlatformDevelopmentID LEFT OUTER JOIN
		(SELECT ProductVersionID, MAX(RasDiscontinueDt) as EndOfProduction
		FROM	AvDetail av  with (NOLOCK)
				INNER JOIN AvDetail_ProductBrand avb with (NOLOCK) on av.AvDetailId = avb.AvDetailId
				INNER JOIN Product_Brand pb with (NOLOCK) on pb.Id = avb.ProductBrandId
		WHERE 
				(FeatureCategoryId = 1 OR FeatureCategoryId = 86)-- Base Units
		GROUP BY ProductVersionID) EOP ON v.id = eop.productversionid
	WHERE
		TypeID <> 2
	ORDER BY
		v.dotsname



﻿

CREATE PROCEDURE [dbo].[spImportImageDefinition]
(
	@ImageID int,
	@ProductID int,
	@NewID int output
)	
 AS
insert ImageDefinitions(ProductVersionID,SKUNumber,BrandID, OSID , SWID, ImageType,Modified,Active, StatusID, CopyID)
Select @ProductID, '', BrandID, OSID, SWID,ImageType,GetDate(),1,1,@ImageID
FROM ImageDefinitions with (NOLOCK)
Where ID = @ImageID
and Active=1
Select @NewID = SCOPE_IDENTITY()






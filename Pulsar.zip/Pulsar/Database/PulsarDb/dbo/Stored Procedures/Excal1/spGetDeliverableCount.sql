﻿

CREATE PROCEDURE [dbo].[spGetDeliverableCount]

(
	@ID int,
	@Report int =null
)

 AS

if @Report = 1 --non-Commodity Only
	Select Count(*) as DeliverableCount
	from deliverableroot r with (NOLOCK), deliverableversion v with (NOLOCK), deliverablecategory c with (NOLOCK)
	where v.deliverablerootid = r.id
	and c.id = r.categoryid
	and r.developernotification = 1
	and (r.categoryid = 202 or c.commodity=0 )
	and (r.devmanagerid=@ID or v.developerid=@ID)
else 
	Select Count(*) as DeliverableCount
	from deliverableroot r with (NOLOCK), deliverableversion v with (NOLOCK)
	where v.deliverablerootid = r.id
	and r.developernotification = 1
	and (r.devmanagerid=@ID or v.developerid=@ID)





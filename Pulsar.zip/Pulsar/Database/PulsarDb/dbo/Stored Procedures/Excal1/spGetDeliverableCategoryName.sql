﻿
CREATE PROCEDURE [dbo].[spGetDeliverableCategoryName]

(
	@ID int --CategoryID
)
AS

Select ID, Name
from DeliverableCategory with (NOLOCK)
where id = @ID


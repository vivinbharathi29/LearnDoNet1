﻿/**************************************************************************************************    
** Author  :       
** Description :           
** Date   :    
**************************************************************************************************    
** Change History           
**************************************************************************************************    
** SNo   Date        Author                                    Description           
** --    --------   -------                                   -------------------------           
 ** 1    27/12/2018  Santhana K								  Changed the Text Data type to Varchar(max)
****************************************************************************************************/ 
CREATE Procedure [dbo].[spAddNewRequirement]
 (
  @ReqName varchar (255),
  @CategoryID int,
  @SpecTemplate Varchar(max),
  @ProcessRequirement bit,
  @NewID int output
 )
As
 Declare @DateStamp datetime
 select @DateStamp =  GETDATE() 
 INSERT Requirement(Name, CategoryID,SpecTemplate,LastUpdated, ProcessRequirement) 
 VALUES (@ReqName,@CategoryID,@SpecTemplate,@DateStamp, @ProcessRequirement)
 
 Select @NewID = SCOPE_IDENTITY()
return 


GO



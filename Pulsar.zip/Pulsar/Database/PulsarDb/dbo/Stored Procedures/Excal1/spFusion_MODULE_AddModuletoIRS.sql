﻿/**************************************************************************************************    
** SNo   Date        Author                                    Description           
** --    --------   -------                                   -------------------------           
 ** 1    09/01/2019  Santhana K								  Used the Setting table instead of hardcoding email address
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spFusion_MODULE_AddModuletoIRS]
(
	@ID int,
	@UpdateBy int --Excalibur user ID
)
AS

	Declare @ConsumerCount int
	Declare @CommercialCount int
	Declare @Divisions varchar(255)
	Declare @irsmodulecategoryid int
	Declare @DescCategoryID int
	Declare @StatusID int
	Declare @IRSID int
	Declare @GroupID int
	Declare @TypeID int
	Declare @LongDesc varchar(100)
	Declare @ShortDesc varchar(40)
	Declare @UpdateByName varchar(64)
	Declare @UpdateByID int
	Declare @tmp int
	Declare @CategoryAbbreviation varchar(10)
	
	
		Declare @recipientsMail varchar(100)
		select @recipientsMail = value from Setting
		where name = 'Pulsar.SupportEmail'


	Select @UpdateByID = userid, @UpdateByName = Lastname + ', ' + Firstname from UserInfo WITH (NOLOCK) where UserID = @UpdateBy

	Print 'AVDetailId: ' + CAST(@ID AS VARCHAR(10))

	if @UpdateByID is null or @UpdateByName is null	
	begin
		raiserror('Error: Unable to find user in IRS', 16, 1)
		return 1
	end	

	Select @ConsumerCount = coalesce(sum(case when p.DevCenter=2 then 1 else 0 end),0), @CommercialCount = coalesce(sum(case when p.DevCenter<>2 then 1 else 0 end),0), @irsmodulecategoryid = coalesce(c.irsmodulecategoryid,0), @CategoryAbbreviation = coalesce(c.IRSModuleAbbreviation,'')
	from AvDetail d WITH (NOLOCK) inner join
		 AvFeatureCategory c WITH (NOLOCK) on d.FeatureCategoryID = c.AvFeatureCategoryID inner join
		 AvDetail_ProductBrand db WITH (NOLOCK) on db.AvDetailID = d.AvDetailID inner join
		 Product_Brand pb WITH (NOLOCK) on pb.id = db.ProductBrandID inner join
		 ProductVersion p WITH (NOLOCK) on p.ID = pb.ProductVersionID
	where db.Status in ('A','O')
	--and p.ID >=993
	and c.IRSModuleAbbreviation is not null
	and coalesce(c.irsmodulecategoryid,0)  <> 0
	and d.AvNo IS NOT NULL
	and d.AvDetailID = @ID
	group by coalesce(c.irsmodulecategoryid,0), coalesce(c.IRSModuleAbbreviation,'')
	
	IF COALESCE(@CommercialCount, 0) = 0 And COALESCE(@ConsumerCount, 0) = 0
	BEGIN
		--PRINT 'Looking for count in Parent AVs'
		Select @ConsumerCount = coalesce(sum(case when p.DevCenter=2 then 1 else 0 end),0), @CommercialCount = coalesce(sum(case when p.DevCenter<>2 then 1 else 0 end),0), @irsmodulecategoryid = coalesce(c.irsmodulecategoryid,0), @CategoryAbbreviation = coalesce(c.IRSModuleAbbreviation,'')
		from AvDetail d WITH (NOLOCK) inner join
			 AvDetail dc WITH (NOLOCK) ON d.AvDetailID = dc.ParentId INNER JOIN
			 AvFeatureCategory c WITH (NOLOCK) on d.FeatureCategoryID = c.AvFeatureCategoryID inner join
			 AvDetail_ProductBrand db WITH (NOLOCK) on db.AvDetailID = dc.AvDetailID inner join
			 Product_Brand pb WITH (NOLOCK) on pb.id = db.ProductBrandID inner join
			 ProductVersion p WITH (NOLOCK) on p.ID = pb.ProductVersionID
		where db.Status in ('A','O')
		--and p.ID >=993
		and c.IRSModuleAbbreviation is not null
		and coalesce(c.irsmodulecategoryid,0)  <> 0
		and d.AvNo IS NOT NULL
		and d.AvDetailID = @ID
		group by coalesce(c.irsmodulecategoryid,0), coalesce(c.IRSModuleAbbreviation,'')
	END
	
	if @CommercialCount = 0 and @ConsumerCount > 0
			Select @GroupID = (select  GroupID  from IRS_UserGroup WITH (NOLOCK) where GroupCode in ('cNB_Mkt') )
	else
			Select @GroupID = (select  GroupID  from IRS_UserGroup WITH (NOLOCK) where GroupCode in ('bNB_Mkt') )

	if @CommercialCount > 0 and @ConsumerCount > 0
		Select @Divisions = (select dbo.concatenate(categoryid) from IRS_Category WITH (NOLOCK) where CategoryType=19 and Abbreviation in ('bNB','cNB')) --'269,278'
	else if @ConsumerCount > 0
		Select @Divisions = (select dbo.concatenate(categoryid) from IRS_Category WITH (NOLOCK) where CategoryType=19 and Abbreviation in ('cNB')) --'278'
	else
		Select @Divisions = (select dbo.concatenate(categoryid) from IRS_Category WITH (NOLOCK) where CategoryType=19 and Abbreviation in ('bNB')) --269

	DECLARE @IrsModuleId INT
	SELECT @IrsModuleId = [dbo].[ufn_GetMinIrsModuleIdByDescription](GpgDescription, @GroupId) FROM AvDetail WITH (NOLOCK) WHERE AvDetailID = @ID
	IF @IrsModuleId > 0 BEGIN
		UPDATE AvDetail SET IRSModuleID = @IrsModuleId WHERE AvDetailID = @ID
		
		print 'Module with the same name Already Exist in IRS Setting ModuleId to:' + cast(@IrsModuleId as varchar(20)) + '  Updating ID instead of adding a new one.'

		RETURN 0
	END

	Select @IRSID=coalesce(d.IRSModuleID,0),
		@LongDesc = LEFT(GPGDescription,40), --LEFT(MarketingDescriptionPMG,100),
		@ShortDesc = LEFT(GPGDescription,40), 
		@StatusID = case when db.Status='A' or db.Status='O' then (select statusid from IRS_Status WITH (NOLOCK) where StatusType=8 and constant='MOL_MODULE_ACTIVE') else (select statusid from IRS_Status WITH (NOLOCK) where StatusType=8 and constant='MOL_MODULE_DISABLED') end,
		@TypeID = case typeid when 1 then 13 when 2 then 28 else 13 end
	from AvDetail d WITH (NOLOCK) inner join
		 AvFeatureCategory c WITH (NOLOCK) on d.FeatureCategoryID = c.AvFeatureCategoryID inner join
		 AvDetail_ProductBrand db WITH (NOLOCK) on db.AvDetailID = d.AvDetailID inner join
		 Product_Brand pb WITH (NOLOCK) on pb.id = db.ProductBrandID inner join
		 ProductVersion p WITH (NOLOCK) on p.ID = pb.ProductVersionID
	where db.Status in ('A','O')
	--and p.ID >=993
	and c.IRSModuleAbbreviation is not null
	and coalesce(c.irsmodulecategoryid,0)<> 0
	and d.AvDetailID = @ID
	
	IF @IRSID IS NULL
	BEGIN
		--PRINT 'Looking for Parent Av'
		Select @IRSID=coalesce(d.IRSModuleID,0),
			@LongDesc = LEFT(d.GPGDescription,40), --LEFT(MarketingDescriptionPMG,100),
			@ShortDesc = LEFT(d.GPGDescription,40), 
			@StatusID = case when db.Status='A' or db.Status='O' then (select statusid from IRS_Status WITH (NOLOCK) where StatusType=8 and constant='MOL_MODULE_ACTIVE') else (select statusid from IRS_Status WITH (NOLOCK) where StatusType=8 and constant='MOL_MODULE_DISABLED') end,
			@TypeID = case typeid when 1 then 13 when 2 then 28 else 13 end
		from AvDetail d WITH (NOLOCK) inner join
			 AvDetail dc WITH (NOLOCK) ON d.AvDetailID = dc.ParentId INNER JOIN
			 AvFeatureCategory c WITH (NOLOCK) on d.FeatureCategoryID = c.AvFeatureCategoryID inner join
			 AvDetail_ProductBrand db WITH (NOLOCK) on db.AvDetailID = dc.AvDetailID inner join
			 Product_Brand pb WITH (NOLOCK) on pb.id = db.ProductBrandID inner join
			 ProductVersion p WITH (NOLOCK) on p.ID = pb.ProductVersionID
		where db.Status in ('A','O')
		--and p.ID >=993
		and c.IRSModuleAbbreviation is not null
		and coalesce(c.irsmodulecategoryid,0)<> 0
		and d.AvNo IS NOT NULL
		and d.AvDetailID = @ID
	END

	--PRINT 'Verify the CategoryID'
	select  @DescCategoryID=CategoryID
	from IRS_Category  WITH (NOLOCK)
	where categoryid = @irsmodulecategoryid
	and (coalesce(abbreviation,'') = coalesce(@CategoryAbbreviation,''))
	

	if @IRSID is null
		begin
		raiserror('Error: Unable to find the selected AVDetail record', 16, 1)
		--return 1
		end			
	else if @DescCategoryID is null
		begin
		declare @strError as varchar(500)
		Select @strError = 'Error: Category IDs don''t match for the selected module. ModuleCategoryID:' + cast(@irsmodulecategoryid as varchar(20))
		raiserror(@strError , 16, 1)
		--return 1
		end			
	else
		begin
		
		--PRINT 'Check to see if that module exists and if it is the right id number'
		
		Select @tmp = i.moduleid
		from IRS_module i WITH (NOLOCK)  
		where i.excaliburid = @ID
		
		if @tmp is null
			Select @IRSID = 0
		else if @tmp <> @IRSID
			select @IRSID = @tmp 
	
		

			declare @pModID int
			set @pModID=0

			exec IRS_usp_MD_CreateEdit_FromFeed
			  @p_intModuleID = @IRSID,                                      -- pass 0 if this is a Create, otherwise, pass the ModuleID
			  @p_chrMktDescription = @LongDesc,								-- Marketing Description (100 characters right now)
			  @p_chrShortDesc = @ShortDesc,				                    -- Short Description
			  @p_intStatusID = @StatusID,                                   -- Draft/Active/Disabled. select * from Status where StatusType=8
			  @p_intCategoryID = @irsmodulecategoryid,                            -- HW (13) or SW (28) category. select * from Category where CategoryType in (13,28)
			  @p_chrUserName = @UpdateByName,                               -- Last name, first name
			  @p_intUserID = @UpdateByID,                                   -- UserID of the Creator from the IRS UserInfo table
			  @p_chrDivisionIDs = @Divisions,                               -- Either Abbreviation='bNB' or 'cNB' to get correct CategoryID. select * from Category where CategoryType=19 and Abbreviation in ('bNB','cNB')
			  @p_intModuleTypeID = @TypeID,                                 -- Pass 13 for HW and 28 for SW which is CategoryType.
			  @p_intGroupID = @GroupID,                                     -- Owned By: Consumer Notebook Marketing or Commercial Notebook Marketing. select * from UserGroup where GroupCode in ('cNB_Mkt','bNB_Mkt')
			  @p_intDeliveryType = 0,                                       -- Excalibur AVDetail ID
			  @p_intExcaliburID = @ID,                                       -- 0=SRP, 3=TechAV
			  @p_intModID = @pModID output
			

			Update AvDetail
			set IRSModuleID=@pModID
			where AvDetailID = @ID
			
		

			if @IRSID <> 0 and @IRSID <> @pModID
				begin
					Declare @ErrorBody varchar(5000)
		
					Select @ErrorBody = 'The IRS Module feed attempted to update a module and was returned a different moduleID: ' + 'IRSID: ' + cast(@IRSID as varchar(10)) + ' ModuleID: ' + cast(@pModID as varchar(10))
		
					EXEC msdb.dbo.sp_send_dbmail
							@profile_name = 'Database Mail Profile',
							@recipients = @recipientsMail, 
							@body = @ErrorBody,
							@subject = 'IRS Module Duplicate Possibly Created' ;						
				end
			
			end		
GO



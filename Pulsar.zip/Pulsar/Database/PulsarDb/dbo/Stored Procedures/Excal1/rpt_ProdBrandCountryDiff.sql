﻿/******************************************************************************
**	File: dbo.rpt_ProdBrandCountryDiff.sql
**	Name: rpt_ProdBrandCountryDiff
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:						Description:
**	----------	------------------			-------------------------------------------
**  31-Jan-2018 Santhana(auth\prabhuks)		Cursor Based procedure changed to Query format
*******************************************************************************/
CREATE Procedure [dbo].[rpt_ProdBrandCountryDiff]
	@p_ProdBrandIDList VARCHAR(1000)
AS

SET NOCOUNT ON
		
		IF ISNULL(@p_ProdBrandIDList,'') = ''
			SET @p_ProdBrandIDList = '0'

		CREATE TABLE #Diff
		(
		CountryID INT,
		[Group] VARCHAR(15),
		Country VARCHAR(50)
		)

		INSERT INTO #Diff (CountryID, [Group], Country)
		SELECT ID, Region, [Language]
		FROM DBO.[Language] with (NOLOCK) 
		WHERE ID IN (
		SELECT c.ID AS CountryID
		FROM         DBO.ProdBrand_Country pbc  with (NOLOCK) 
					 INNER JOIN DBO.[Language] c with (NOLOCK) ON pbc.CountryID = c.ID 
					 INNER JOIN DBO.ufn_Split(@p_ProdBrandIDList, ',') fn ON pbc.ProductBrandID = fn.value
		WHERE     c.IsLanguage = 0 AND c.Active = 1 
					--AND pbc.ProductBrandID IN 
					--(SELECT * FROM dbo.ufn_Split(145, ','))
		GROUP BY c.ID
		HAVING COUNT(pbc.ProductBrandID) < (SELECT COUNT(*) FROM dbo.ufn_Split(@p_ProdBrandIDList, ','))
		)
		ORDER BY Region DESC, [Language] ASC


		Declare @Str varchar(max), @StrQuoted varchar(max);

		select @Str= COALESCE(@Str +', ','') 
		+ Value --QUOTENAME(Value) 
		FROM (SELECT Value FROM dbo.ufn_Split(@p_ProdBrandIDList,',')) as V;

		select @StrQuoted = COALESCE(@StrQuoted +', ','')+QUOTENAME(Value)
		FROM (SELECT Value FROM DBO.ufn_Split(@p_ProdBrandIDList,',')) as V1;


		exec(
		'with cte_Q1 AS
				 (
		select pb.ID id,
		 pv.dotsname +'' ''+ b.Name as SName
		 FROM DBO.ProductFamily f INNER JOIN DBO.ProductVersion pv ON f.id = pv.ProductFamilyID 
		INNER JOIN DBO.Product_Brand pb on pb.ProductVersionID = pv.ID INNER JOIN DBO.Brand b on pb.BrandID = b.ID WHERE pb.ID in ('+ @Str +'))
		'+
		'select ''Country'' , '+@StrQuoted +' from cte_Q1
		 pivot (max(SName) for id IN ('+@StrQuoted+') )as P') 
	
		 exec(
		'with cte_Q2 AS
				 (
		select distinct [Group], Country, pbc.ProductBrandID id, 
		case when #Diff.CountryID = pbc.countryid  then ''X'' else ''&nbsp;'' end as Name
		from #Diff  cross join DBO.ProdBrand_Country pbc where pbc.ProductBrandID in ('+ @Str +')
		)
		'+
		'select [Group], Country, '+@StrQuoted +'  from cte_Q2
		 pivot (max(Name) for id IN ('+@StrQuoted+') )as P') 
		 

		DROP TABLE #Diff

SET NOCOUNT OFF

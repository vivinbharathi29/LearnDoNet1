﻿

CREATE PROCEDURE [dbo].[spListCountries4ProductAll] 

(
	@ProdID int
)

AS

Select l.Language as Country, p.ID, P.ProductversionID as prodID, l.ID as CountryID, l.region as Region
from Language l with (NOLOCK) LEFT OUTER JOIN Product_Country p with (NOLOCK) ON l.ID = p.CountryID
where l.IsLanguage = 0
and l.active=1
and p.ProductversionID = @ProdID
order by l.region desc, l.Language asc

﻿CREATE PROCEDURE [dbo].[spListBrands4Product_Pulsar]
/* ************************************************************************************************
 * Purpose:	Based on spListBrands4Product, will be used for pulsar version of products.  An future changes
			for pulsar products will be in this sp and the legacy version will remain unchanged.
 * Created By:	Ywang, 2/4/2015
 * Modified By: SPathak, 2/20/2015 Task 8188 inner join with Series table to get the brand names
 *				02/23/2015 JCope - Task 8188 Return CombinedName field
				02/24/2015 SPathak - Task 8188 add the brand name info to the second part of the stored procedure
				02/24/2015 SPathak - Task 8188 moved the joining with the Series table to a separate stored procedure
				02/14/2015 SPathak - updated to return 1 if the BusinessID is null
				Ywang, 2.27/2015, sort by brand name, pbi 8503
				SPathak, 3/13/2015 - Task 8794 return brand names those don't have formula created
				SRagishetti , 11/14/2016 - Add ModelNumber to product properties
				linshan,      02/11/2019  - Move Brands field from Product Properties to Base Unit Groups - PBI 241541
 **************************************************************************************************/
	
(
	@ProductID int,
	@SelectedOnly tinyint = 1,
	@platformID int = 0
)
 AS

if @SelectedOnly = 1
	Select l.ID, l.Name,l.streetname,l.streetname2,l.streetname3, 
		l.suffix,l.RASSegment, l.active, p.SeriesSummary, l.abbreviation, v.version as productversion,
		v.productname as productfamily, p.ID as ProductBrandID, v.dotsname as product,
		v.id as ProductID, l.id as brandid, pn.name as Partner, p.LastPublishDt,
		l.ShowSeriesNumberInLogoBadge,l.ShowSeriesNumberInBrandname,l.SplitSeriesForLogoAndBrand,
		l.ShowSeriesNumberInShortName, BusinessID =isnull(l.BusinessID,1), p.KMAT, p.ServiceTag, p.BIOSBranding, 
		p.LogoBadge,p.LongName,p.ShortName,p.FamilyName,p.BrandName,
		--two more fields for generation and formfactor
		Generation=isnull(p.Generation, ''),
		FormFactor = isnull(p.FormFactor, ''),
		SCMNumber = isnull(p.SCMNumber,0),
		BrandsWOFormula = isnull((SELECT STUFF((select BrandFormulaName.Name + ','
						from BrandFormulaName 
						where BrandFormulaNameID not in (select BrandFormula.BrandFormulaNameID from Brand inner join BrandFormula on Brand.ID=BrandFormula.BrandID where Brand.ID = l.Id)
						for xml path('') ), 1, 0, '')),''),
		ProductModelNumber = isnull(p.ProductModelNumber, ''),
		p.ScreenSize
	from 
		Brand l with (NOLOCK)
		INNER JOIN product_brand p with (NOLOCK) ON p.BrandID = l.ID
		INNER JOIN productversion v with (NOLOCK) ON v.id = p.ProductVersionID
		INNER JOIN productfamily f with (NOLOCK) ON f.id = v.ProductFamilyID
		INNER JOIN Partner pn with (NOLOCK) ON pn.ID = v.PartnerID
	where p.productversionid = @ProductID
	order by l.Name
else
	Select l.ID, l.Name,l.streetname,l.streetname2,l.streetname3,l.RasSegment, l.suffix,l.active,
		p.SeriesSummary, p.ID as ProductBrandID, l.Abbreviation, p.LastPublishDt,l.ShowSeriesNumberInLogoBadge,
		l.ShowSeriesNumberInBrandname,l.SplitSeriesForLogoAndBrand, l.ShowSeriesNumberInShortName, 
		BusinessID =isnull(l.BusinessID,1), p.KMAT,
		--two more fields for generation and formfactor
		Generation=isnull(p.Generation, ''),
		FormFactor = isnull(p.FormFactor, ''),
		SCMNumber = isnull(p.SCMNumber,0),
		BrandsWOFormula = isnull((SELECT STUFF((select BrandFormulaName.Name + ','
						from BrandFormulaName 
						where BrandFormulaNameID not in (select BrandFormula.BrandFormulaNameID from Brand inner join BrandFormula on Brand.ID=BrandFormula.BrandID where Brand.ID = l.Id)
						for xml path('') ), 1, 0, '')),''),
		ProductModelNumber = isnull(p.ProductModelNumber, ''),
		ScreenSize = p.ScreenSize,
		selectedBrand = ISNULL((select 1 from ProductVersion_Platform pp join Product_Brand pb on pp.ProductBrandID = pb.ID where pb.ID = p.ID and p.ProductVersionID = @ProductID and  pp.PlatformID = @platformID),0)
	from 
		Brand l with (NOLOCK)
		LEFT OUTER JOIN Product_Brand p with (NOLOCK) ON p.BrandID = l.ID
		AND p.productversionid = @ProductID
	order by l.Name,l.ID
RETURN 0


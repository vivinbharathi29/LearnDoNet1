﻿
CREATE PROCEDURE [dbo].[spAddDeliverableFeature]
(
	@RootID int,
	@FeatureID int
)
AS
BEGIN
	Insert Into DeliverableRoot_Feature (DeliverableRootID, FeatureID)
	Values (@RootID,@FeatureID)

END


﻿

CREATE PROCEDURE [dbo].[spGetApproverList]
 (
	@ProdID int
)
 AS
Select ApproverList
from ProductVersion with (NOLOCK)
where ID = @ProdID




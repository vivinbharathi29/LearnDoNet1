﻿

CREATE PROCEDURE [dbo].[spGetProductByImage]
(
	@ImageID int
)
 AS
Select v.dotsname as Product, v.ID, v.preinstallteam, v.devcenter
from productFamily f with (NOLOCK), productVersion v with (NOLOCK), ImageDefinitions idef with (NOLOCK), Images i with (NOLOCK)
where i.Id = @ImageID
and i.ImageDefinitionID = idef.ID
and idef.Productversionid = v.ID
and v.productfamilyid = f.id



﻿CREATE PROCEDURE [dbo].[spCountBridgesOnOtherVersionsRelease]
/* ************************************************************************************************
 * Purpose: count number of subassembly bridged with real root
 * Created By: Dien Bui
 * Modified By: 
 **************************************************************************************************/
(
	@ProductID int,
	@VersionID int
)
AS

	DECLARE @RootID int
	DECLARE @VendorID int

	Select @RootID = DeliverableRootID, @VendorID = VendorID
	from deliverableVersion with (NOLOCK)
	where id = @VersionID


	Select Count(1) as BridgeCount, dbo.concatenate(distinct DeliverableRootID) as BridgedIDs
	from ProdDel_DelRoot with (NOLOCK)
	where bridged = 1 
	and ProductDeliverableReleaseID in (Select pdr.ID
										from Product_Deliverable pd with (NOLOCK)
										inner join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
										where pd.ProductVersionID = @ProductID
										and pd.DeliverableVersionID <> @VersionID
										and pdr.teststatusID > 1
										and DeliverableVersionID in (Select ID from DeliverableVersion with (NOLOCK) where DeliverableRootID = @RootID and VendorID = @VendorID))

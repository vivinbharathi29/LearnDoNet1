﻿CREATE PROCEDURE [dbo].[spGetProductRTMImageSCMX]
(
	@ProductRTMID int
)
AS
BEGIN
		DECLARE @SystemBIOSCount int
		DECLARE @RestoreMediaCount int
		DECLARE @PatchesCount int
		DECLARE @FWCount int
		DECLARE @ImageCount int
		DECLARE @SCMXCount int=0
		
		select @SystemBIOSCount=Count(*)  from ProductRTM_DeliverableVersion where ProductRTMID=@ProductRTMID and TypeID=1
		select @RestoreMediaCount=Count(*)  from ProductRTM_DeliverableVersion where ProductRTMID=@ProductRTMID and TypeID=2
		select @PatchesCount=Count(*)  from ProductRTM_DeliverableVersion where ProductRTMID=@ProductRTMID and TypeID=3
		select @FWCount=Count(*)  from ProductRTM_DeliverableVersion where ProductRTMID=@ProductRTMID and TypeID=4
		select @ImageCount=Count(*)  from ProductRTM_Image where ProductRTMID=@ProductRTMID 

		if(@SystemBIOSCount=0 and @RestoreMediaCount=0 and @PatchesCount=0 and @FWCount=0 and @ImageCount=0)
		    set @SCMXCount=1

		select @SystemBIOSCount as SystemBIOSCount,@RestoreMediaCount as RestoreMediaCount,
				@PatchesCount as PatchesCount,@FWCount as FWCount,@ImageCount as ImageCount,@SCMXCount as SCMXCount
END
﻿
CREATE PROCEDURE [dbo].[spListDeliverableCategoryTeams]
(
	@TypeID int
)
 AS

Select Distinct t.ID, t.name
from deliverablecategoryteam t with (NOLOCK), deliverablecategory c with (NOLOCK)
where c.teamid = t.id
and c.Deliverabletypeid = @TypeID
order by t.name


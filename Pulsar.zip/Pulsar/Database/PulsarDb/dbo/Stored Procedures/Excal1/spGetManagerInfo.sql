﻿

CREATE PROCEDURE [dbo].[spGetManagerInfo]
(
	@EmployeeID int
)
 AS
Select e2.Name, e2.ID, e2.Email
FROM Employee e with (NOLOCK), Employee e2 with (NOLOCK)
Where e.managerID = e2.ID
and e.ID = @EmployeeID




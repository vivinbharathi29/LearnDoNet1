﻿
-- ==========================================================================================
-- Author:		Patrick Ruland
-- Create date: 5/5/2011
-- Description:	Accepts a User ID 
--				Returns the Product Version (DOTSName), OSSP Name, Service Geo, and 
--				OSSP Type for ALL APPLICABLE (ACTIVE) Products, Partners, and Assignments
--				BASED UPON VERIFICATION OF THE SPECIFIED User's PERMISSIONS
--
--				NOTE: Given the sensitive nature of the data being retrieved, validation
--					  logic verifying input parameter(s) has been implemented
-- ==========================================================================================
CREATE PROCEDURE [dbo].[rpt_ServiceFamilyOSSPAssignments]
@USER_ID INT,
@STATUS_ID INT = 0,					-- ADD VALIDATION LOGIC
@DEV_CENTER INT = 0,					-- ADD VALIDATION LOGIC
@BUSINESS_TYPE INT = NULL,				-- ADD VALIDATION LOGIC
@OSSP_ID INT = NULL,					-- ADD VALIDATION LOGIC
@RETURN_CODE INT = NULL OUTPUT,			
@RETURN_DESC NVARCHAR(510)=NULL OUTPUT
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @DEVCENTERSET TABLE(DEVCENTERID INT)

	IF(@BUSINESS_TYPE=0) 
	BEGIN
		SET @BUSINESS_TYPE=NULL
		IF(@DEV_CENTER=0) INSERT INTO @DEVCENTERSET SELECT ID FROM DevCenter WITH(NOLOCK)
		ELSE INSERT INTO @DEVCENTERSET SELECT @DEV_CENTER
	END
	ELSE IF(@BUSINESS_TYPE=1) AND (@DEV_CENTER=0) INSERT INTO @DEVCENTERSET SELECT ID FROM DevCenter WITH(NOLOCK) WHERE ID<>2 -- COMMERCIAL ONLY
	ELSE IF(@BUSINESS_TYPE=1) AND (@DEV_CENTER!=0) AND (@DEV_CENTER!=2) INSERT INTO @DEVCENTERSET SELECT ID FROM DevCenter WITH(NOLOCK) WHERE ID=@DEV_CENTER -- COMMERCIAL ONLY
	ELSE IF(@BUSINESS_TYPE=2) AND (@DEV_CENTER=0) INSERT INTO @DEVCENTERSET SELECT 2 -- CONSUMER ONLY
	ELSE IF(@BUSINESS_TYPE=2) AND (@DEV_CENTER=2) INSERT INTO @DEVCENTERSET SELECT 2
	
	IF(@OSSP_ID=0) SET @OSSP_ID=NULL

	-- INITIALIZE RETURN CODE AND DESCRIPTION
	SET @RETURN_CODE=0
	SET @RETURN_DESC='Succesfully retrieved OSSP Assignments.'

	DECLARE @USER_PARTNER_NAME VARCHAR(30)
	DECLARE @DATASET TABLE(ProductVersionID INT, DOTSName VARCHAR(30), PartnerID INT, PartnerName VARCHAR(30), ServiceGeoID INT, ServiceGeoShortName VARCHAR(20), ServicePartnerTypeCode VARCHAR(20))
	DECLARE @REC_COUNT INT
	SET @REC_COUNT=0
	
	DECLARE @PROCESS BIT
	SET @PROCESS=0
	
	-- VERIFY THAT THE SPECIFIED USER EXISTS AND IS FLAGGED AS BEING [Active]
	IF(EXISTS(SELECT ID FROM Employee WITH(NOLOCK) WHERE ID=@USER_ID))
	BEGIN
		
		IF(NOT EXISTS(SELECT ID FROM Employee WITH(NOLOCK) WHERE ID=@USER_ID AND Active=1))
		BEGIN
			SET @RETURN_CODE=-1
			SET @RETURN_DESC='User account is not currently activated.'
			GOTO EXIT_PROC
		END
		
		/****************************************************************************************************************************************************************/
		/*	RETRIEVE THE APPROPRIATE DATA FOR THE SPECIFIED USER																										*/
		/****************************************************************************************************************************************************************/
		
		DECLARE @UserPartnerID INT
		DECLARE @UserPartnerTypeID INT
		
		-- RETRIEVE THE SPECIFIED USER'S PARTNER ID AND VALIDATE
		SELECT @UserPartnerID=ISNULL(PartnerID,-1) FROM Employee WITH(NOLOCK) WHERE ID=@USER_ID
		
		IF(@UserPartnerID=-1)
		BEGIN
			SET @RETURN_CODE=-1
			SET @RETURN_DESC='The User''s Partner ID is not specified.'
			GOTO EXIT_PROC
		END
		
		IF(EXISTS(SELECT ID FROM Partner WITH(NOLOCK) WHERE ID=@UserPartnerID))
		BEGIN
			-- VERIFY THAT THIS PARTNER IS CURRENTLY ACTIVE
			IF(NOT EXISTS(SELECT ID FROM Partner WITH(NOLOCK) WHERE ID=@UserPartnerID AND Active=1))
			BEGIN
				SET @RETURN_CODE=-1
				SET @RETURN_DESC='The User''s specified Partner is not currently activated.'
				GOTO EXIT_PROC
			END
		END
		ELSE
		BEGIN
			SET @RETURN_CODE=-1
			SET @RETURN_DESC='The User''s specified Partner does not exist.'
			GOTO EXIT_PROC
		END
		
		-- RETRIEVE THE SPECIFIED USER'S PARTNER TYPE AND VALIDATE
		SELECT @UserPartnerTypeID=ISNULL(PartnerTypeID,-1) FROM Partner WITH(NOLOCK) WHERE ID=@UserPartnerID
		
		IF(@UserPartnerTypeID=-1)
		BEGIN
			SET @RETURN_CODE=-1
			SET @RETURN_DESC='The User''s Partner Type is not specified.'
			GOTO EXIT_PROC
		END
		
		IF(NOT EXISTS(SELECT ID FROM PartnerType WITH(NOLOCK) WHERE ID=@UserPartnerTypeID))
		BEGIN
			SET @RETURN_CODE=-1
			SET @RETURN_DESC='The User''s Partner Type does not exist.'
			GOTO EXIT_PROC
		END
		
		IF(@UserPartnerID=1) -- INTERNAL USER
		BEGIN
			INSERT INTO @DATASET(ProductVersionID, DOTSName, PartnerID, PartnerName, ServiceGeoID, ServiceGeoShortName, ServicePartnerTypeCode)
			SELECT DISTINCT -- <--- UNNECESSARY???
			PV.ID,
			PV.DOTSName,
			ISNULL(P.ID,0), 
			COALESCE(P.Name,'(None Specified)'), 
			ISNULL(SG.ServiceGeoID,0),
			COALESCE(SG.ServiceGeoShortName,'(None Specified)'), 
			COALESCE(SF_PART.ServicePartnerTypeCode,'(None Specified)')
			FROM 
			ProductVersion PV WITH(NOLOCK)
			LEFT JOIN
			ServiceFamily_Partner SF_PART WITH(NOLOCK)
			ON
			PV.ServiceFamilyPn=SF_PART.ServiceFamilyPn
			LEFT JOIN
			Partner P WITH(NOLOCK)
			ON 
			SF_PART.PartnerID=P.ID	
			LEFT JOIN
			ServiceGeo SG WITH(NOLOCK)
			ON
			SF_PART.ServiceGeoID=SG.ServiceGeoID
			WHERE
			(SF_PART.Status='A' OR ISNULL(SF_PART.Status,'U')='U')
			AND
			PV.TypeID=1
			/*
			PV.ProductStatusID=ISNULL(@STATUS_ID,PV.ProductStatusID)
			AND
			PV.DevCenter=ISNULL(@DEV_CENTER,PV.DevCenter)
			AND
			SF_PART.PartnerID=ISNULL(@OSSP_ID,SF_PART.PartnerID) --OR ISNULL(SF_PART.PartnerID,-1)=-1
			AND
			--PV.B
			PV.Active=1
			AND
			(P.Active=1 OR ISNULL(P.Active,1)=1)
			AND
			*/
			
			--ORDER BY [Product Version], [OSSP Name] ASC
			
			SET @PROCESS=1
			
			SET @RETURN_CODE = 0
			SET @RETURN_DESC = 'Successfully retrieved data for INTERNAL USER.'	
		END
		ELSE IF(@UserPartnerID>1) -- EXTERNAL USER
		BEGIN

			IF(@UserPartnerTypeID=1) -- ODM
			BEGIN
				INSERT INTO @DATASET(ProductVersionID, DOTSName, PartnerID, PartnerName, ServiceGeoID, ServiceGeoShortName, ServicePartnerTypeCode)
				SELECT DISTINCT
				PV.ID,
				PV.DOTSName, 
				ISNULL(SFP.ID,0),
				COALESCE(SFP.Name,'(None Specified)'), 
				ISNULL(SFP.ServiceGeoID,0),
				COALESCE(SFP.ServiceGeoShortName,'(None Specified)'),
				COALESCE(SFP.ServicePartnerTypeCode,'(None Specified)')
				FROM 
				ProductVersion PV WITH(NOLOCK)
				LEFT JOIN
				ProductVer_Partner PV_PART WITH(NOLOCK)
				ON
				PV.ID=PV_PART.ProductVersionID
				LEFT JOIN
				(SELECT SF_PART.ServiceFamilyPn, PART.ID, PART.Name, SG.ServiceGeoShortName, SF_PART.ServiceGeoID, SF_PART.ServicePartnerTypeCode 
					FROM 
					Partner PART WITH(NOLOCK) 
					INNER JOIN 
					ServiceFamily_Partner SF_PART WITH(NOLOCK)	
					ON 
					PART.ID=SF_PART.PartnerID
					INNER JOIN
					ServiceGeo SG WITH(NOLOCK)
					ON
					SF_PART.ServiceGeoID=SG.ServiceGeoID
					WHERE
					SF_PART.Status='A'
					--AND
					--PART.Active=1
				) SFP
				ON
				PV.ServiceFamilyPn=SFP.ServiceFamilyPn
				WHERE
				--PV.Active=1
				--AND
				(PV_PART.Status='A' OR ISNULL(PV_PART.Status,'U')='U')
				AND
				PV.PartnerID=@UserPartnerID
				AND
				PV.TypeID=1
				--ORDER BY [Product Version], [OSSP Name] ASC
				
				SELECT @USER_PARTNER_NAME=COALESCE(Name,'') FROM Partner WITH(NOLOCK) WHERE ID=@UserPartnerID
				SET @PROCESS=1
				SET @RETURN_CODE = 0
				SET @RETURN_DESC = 'Successfully retrieved data for ['+@USER_PARTNER_NAME+'] ODM USER.'	
				
			END
			ELSE IF(@UserPartnerTypeID=2) -- OSSP
			BEGIN
				INSERT INTO @DATASET(ProductVersionID, DOTSName, PartnerID, PartnerName, ServiceGeoID, ServiceGeoShortName, ServicePartnerTypeCode)
				SELECT DISTINCT 
				PV.ID,
				PV.DOTSName, 
				SFP.ID,
				SFP.Name, 
				SFP.ServiceGeoID,
				SFP.ServiceGeoShortName, 
				SFP.ServicePartnerTypeCode
				FROM 
				ProductVersion PV WITH(NOLOCK)
				INNER JOIN
				ProductVer_Partner PV_PART WITH(NOLOCK)
				ON
				PV.ID=PV_PART.ProductVersionID
				INNER JOIN
				(SELECT SF_PART.ServiceFamilyPn, PART.ID, PART.Name, SG.ServiceGeoShortName, SF_PART.ServiceGeoID, SF_PART.ServicePartnerTypeCode 
					FROM 
					Partner PART WITH(NOLOCK) 
					INNER JOIN 
					ServiceFamily_Partner SF_PART WITH(NOLOCK)	
					ON 
					PART.ID=SF_PART.PartnerID
					INNER JOIN
					ServiceGeo SG WITH(NOLOCK)
					ON
					SF_PART.ServiceGeoID=SG.ServiceGeoID
					WHERE
					SF_PART.Status='A'
					--AND
					--PART.Active=1
				) SFP
				ON
				PV.ServiceFamilyPn=SFP.ServiceFamilyPn
				WHERE
				--PV.Active=1
				--AND
				PV.TypeID=1
				AND
				PV_PART.Status='A'
				AND
				EXISTS(SELECT PartnerID FROM ProductVer_Partner WITH(NOLOCK) WHERE PartnerID=@UserPartnerID AND ProductVersionID=PV.ID AND Status='A') --AND Active=1)
				--ORDER BY [Product Version], [OSSP Name] ASC
				
				SELECT @USER_PARTNER_NAME=COALESCE(Name,'') FROM Partner WITH(NOLOCK) WHERE ID=@UserPartnerID
				SET @PROCESS=1
				SET @RETURN_CODE = 0
				SET @RETURN_DESC = 'Successfully retrieved data for ['+@USER_PARTNER_NAME+'] OSSP USER.'	
				
			END		
			ELSE IF(@UserPartnerTypeID>=3) -- Vendor
			BEGIN
				-- SET OUTPUT PARAMETER VALUES

				SET @RETURN_CODE = -1
				SET @RETURN_DESC = 'This report is not accessible by Vendor Partners.'
			END
		END

		
		IF(@PROCESS=1) 
		BEGIN -- APPLY ANY APPLICABLE FILTERS AND RETURN RESULT SET
			IF(@STATUS_ID=0) -- ALL ACTIVE
				--SELECT DS.ProductVersionID AS 'ID', DS.DOTSName AS 'Product Version', DS.PartnerName AS 'OSSP Name', DS.ServiceGeoShortName AS 'Service Geo', DS.ServicePartnerTypeCode AS 'OSSP Type'
				SELECT DS.DOTSName AS 'Product Version', DS.PartnerName AS 'OSSP Name', DS.ServiceGeoShortName AS 'Service Geo', DS.ServicePartnerTypeCode AS 'OSSP Type'
				FROM @DATASET DS 
				INNER JOIN
				ProductVersion PV WITH(NOLOCK)
				ON
				DS.ProductVersionID=PV.ID
				INNER JOIN
				@DEVCENTERSET DCS
				ON
				PV.DevCenter=DCS.DEVCENTERID
				WHERE
				PV.ProductStatusID<5
				--AND
				--PV.DevCenter=ISNULL(@DEV_CENTER,PV.DevCenter)
				--AND
				--PV.Active=1
				AND
				DS.PartnerID=ISNULL(@OSSP_ID,DS.PartnerID)
				ORDER BY DS.DOTSName, DS.PartnerName ASC
				
			ELSE
				--SELECT DS.ProductVersionID AS 'ID', DS.DOTSName AS 'Product Version', DS.PartnerName AS 'OSSP Name', DS.ServiceGeoShortName AS 'Service Geo', DS.ServicePartnerTypeCode AS 'OSSP Type'
				SELECT DS.DOTSName AS 'Product Version', DS.PartnerName AS 'OSSP Name', DS.ServiceGeoShortName AS 'Service Geo', DS.ServicePartnerTypeCode AS 'OSSP Type'
				FROM @DATASET DS
				INNER JOIN
				ProductVersion PV WITH(NOLOCK)
				ON
				DS.ProductVersionID=PV.ID
				INNER JOIN
				@DEVCENTERSET DCS
				ON
				PV.DevCenter=DCS.DEVCENTERID				
				WHERE
				PV.ProductStatusID=ISNULL(@STATUS_ID,PV.ProductStatusID)
				--AND
				--PV.DevCenter=ISNULL(@DEV_CENTER,PV.DevCenter)
				AND
				DS.PartnerID=ISNULL(@OSSP_ID,DS.PartnerID)
				ORDER BY DS.DOTSName, DS.PartnerName ASC			
					
			SET @REC_COUNT=@@ROWCOUNT
			
			SET @RETURN_DESC=@RETURN_DESC+' '+CONVERT(VARCHAR(10),@REC_COUNT)+' Record(s).'
		END
		
		/****************************************************************************************************************************************************************/
	END
	ELSE
	BEGIN
		SET @PROCESS=0
		SET @RETURN_CODE=-1
		SET @RETURN_DESC='Specified User account does not exist.'
		GOTO EXIT_PROC
	END
	
EXIT_PROC:

	RETURN
	
END



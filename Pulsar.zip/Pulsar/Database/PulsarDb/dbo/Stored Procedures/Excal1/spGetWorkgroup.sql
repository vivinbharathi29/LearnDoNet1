﻿

CREATE PROCEDURE [dbo].[spGetWorkgroup] 
(
	@ID int
)
AS
	SELECT ID, Name
	FROM Workgroups with (NOLOCK)
	WHERE ID=@ID;



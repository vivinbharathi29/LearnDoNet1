﻿

CREATE PROCEDURE [dbo].[spGetDeliverableVersionProperties]
(
	@DelID int
)
 AS
Select v.id, r.id as RootID, v.PostRTMStatus, v.PostRTMTargetDate, v.location, r.categoryid,r.active, r.typeid,v.preinstallinternalrev,v.preinstallinternalrevTDC, v.CertificationStatus, v.PostRTMComments, r.name, vd.name as vendor, v.Version, v.Revision, v.Pass, v.PartNumber, v.ModelNumber, v.filename, v.deliverablename, v.irspartnumber
FROM DeliverableVersion v with (NOLOCK), DeliverableRoot r with (NOLOCK), vendor vd with (NOLOCK)
Where r.id = v.deliverablerootid
and vd.id = v.vendorid
and v.id = @DelID




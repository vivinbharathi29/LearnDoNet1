﻿
CREATE PROCEDURE [dbo].[spGetBrandSeries3](@SeriesID int,
@NewSeries varchar(50) = '')
AS SELECT     b.Streetname, 
			  s.Name AS Series,
			  b.Suffix,
			  case when coalesce(v.version,'') = ''  then v.dotsname else left(v.dotsname,len(v.dotsname) - len(v.version) - 1) end AS Family,
			  v.Version,
			  b.RASSegment,
			  @NewSeries AS NewSeries,
			  COALESCE (b.Streetname, '') + ' ' + COALESCE (s.Name, '') + ' ' + COALESCE (b.Suffix, '') AS MarketingLongName,
		      case b.ShowSeriesNumberInShortName when 1 then COALESCE (b.StreetName2, '') + ' ' + COALESCE (s.Name, '') else COALESCE (b.StreetName2, '') end AS MarketingShortName,
		      COALESCE (b.Streetname, '') + ' ' + COALESCE (@NewSeries, '') + ' ' + COALESCE (b.Suffix, '') AS NewMarketingLongName, 
              case b.ShowSeriesNumberInShortName when 1 then COALESCE (b.StreetName2, '') + ' ' + COALESCE (@NewSeries, '') else COALESCE (b.StreetName2, '') end AS NewMarketingShortName,
			  case b.ShowSeriesNumberInLogoBadge when 1 then COALESCE (b.StreetName3, '') + ' ' + COALESCE (dbo.ufnVal(s.Name,~SplitSeriesForLogoAndBrand), '') else COALESCE (b.StreetName3, '') end AS LogoBadge,
			  case b.ShowSeriesNumberInLogoBadge when 1 then COALESCE (b.StreetName3, '') + ' ' + COALESCE (dbo.ufnVal(@NewSeries,~SplitSeriesForLogoAndBrand), '') else COALESCE (b.StreetName3, '') end AS NewLogoBadge,
			  case b.ShowSeriesNumberInBrandname when 1 then COALESCE (b.StreetName, '') + ' ' + COALESCE (dbo.ufnVal(s.Name,~SplitSeriesForLogoAndBrand), '') else COALESCE (b.StreetName, '') end AS BrandName,
			  case b.ShowSeriesNumberInBrandname when 1 then COALESCE (b.StreetName, '') + ' ' + COALESCE (dbo.ufnVal(@NewSeries,~SplitSeriesForLogoAndBrand), '') else COALESCE (b.StreetName, '') end AS NewBrandName
FROM         dbo.Product_Brand pb with (NOLOCK) INNER JOIN
                      dbo.Brand b with (NOLOCK) ON pb.BrandID = b.ID INNER JOIN
                      dbo.Series s with (NOLOCK) ON pb.ID = s.ProductBrandID INNER JOIN
                      dbo.ProductVersion v with (NOLOCK) ON pb.ProductVersionID = v.ID INNER JOIN
                      dbo.ProductFamily f with (NOLOCK) ON v.ProductFamilyID = f.ID
WHERE     (s.ID = @SeriesID)



﻿

CREATE PROCEDURE [dbo].[spListActionItems]
/* ************************************************************************************************
 * Purpose:
 * Created By:	
 * Modified By:	08/14/2017 wgomero: PBI 93328 add AVRequired and QualificationRequired fields
  **************************************************************************************************/
(
	@ProdID int,
	@Type int,
	@Status int,
	@BiosChange bit = null,
	@SwChange bit = null
)

AS
DECLARE @v_Type INT
If (@Type != 0)
	SET @v_Type = @Type


IF ( @ProdID = 0 )
  BEGIN
	IF ( @Status = 0 )
		BEGIN
			Select  v.dotsname as Product, i.id, i.Type, i.Status, i.affectscustomers, e.name as Owner, i.Summary, i.Priority, i.AvailableNotes, i.Description, i.Created, i.LastModified, i.TargetDate,i.ECNDate, i.ActualDate,i.Availablefortest, '<Project Issue>' as Deliverable, ct.Name as CoreTeamRep,i.Submitter, i.Approvals,i.Actions, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, i.AVRequired, i.QualificationRequired
			FROM 
				DeliverableIssues i WITH (NOLOCK)
				INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
				INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
				INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
				LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where 
				Type= COALESCE(@v_Type, Type)
			and (v.active=1 or v.sustaining=1)
			and BiosChange = COALESCE(@BiosChange, BiosChange)
			and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 1 )
		BEGIN
			Select  v.dotsname as Product, i.id, i.Type, i.Status, i.affectscustomers, e.name as Owner, i.Summary, i.Priority, i.AvailableNotes, i.Description, i.Created, i.LastModified, i.TargetDate,i.ECNDate, i.ActualDate,i.Availablefortest, '<Project Issue>' as Deliverable, ct.Name as CoreTeamRep,i.Submitter, i.Approvals,i.Actions, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, i.AVRequired, i.QualificationRequired
			FROM 
				DeliverableIssues i WITH (NOLOCK)
				INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
				INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
				INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
				LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where  
				Type= COALESCE(@v_Type, Type)
	--		and (i.Status = 1 or i.Status = 3 or i.status = 6)
			and ((i.Status = 1 or i.Status = 3 or i.status = 6) or ((v.sustaining = 1 or  i.CoreTeamRep = 12) and i.status=4 and i.ecndate is null))
			and (v.active=1 or v.sustaining=1)
			and BiosChange = COALESCE(@BiosChange, BiosChange)
			and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 2 )
		BEGIN
			Select  v.dotsname as Product, i.id, i.Type, i.Status, i.affectscustomers, e.name as Owner, i.Summary, i.Priority, i.AvailableNotes, i.Description, i.Created, i.LastModified, i.TargetDate,i.ECNDate, i.ActualDate,i.Availablefortest, '<Project Issue>' as Deliverable, ct.Name as CoreTeamRep,i.Submitter, i.Approvals,i.Actions, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, i.AVRequired, i.QualificationRequired
			FROM 
				DeliverableIssues i WITH (NOLOCK)
				INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
				INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
				INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
				LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where  
				Type= COALESCE(@v_Type, Type)
	--		and (i.Status = 2 or i.Status = 4 or i.Status = 5)
			and ((i.Status = 2  or i.Status = 5) or ((v.sustaining = 1 or  i.CoreTeamRep = 12) and i.status=4 and i.ecndate is not null) or ((v.sustaining <> 1 and  i.CoreTeamRep <> 12) and  i.Status = 4)  )
			and (v.active=1 or v.sustaining=1)
			and BiosChange = COALESCE(@BiosChange, BiosChange)
			and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 3 )
		BEGIN
			Select v.dotsname as Product, i.id, i.Type, i.Status, i.affectscustomers, e.name as Owner, i.Summary, i.Priority, i.AvailableNotes, i.Description, i.Created, i.LastModified, i.TargetDate,i.ECNDate, i.ActualDate,i.Availablefortest, '<Project Issue>' as Deliverable, ct.Name as CoreTeamRep,i.Submitter, i.Approvals,i.Actions, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, i.AVRequired, i.QualificationRequired
			FROM 
				DeliverableIssues i WITH (NOLOCK)
				INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
				INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
				INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
				LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where  
				Type= COALESCE(@v_Type, Type)
			and i.OnStatusReport = 1
			and (v.active=1 or v.sustaining=1)
			and BiosChange = COALESCE(@BiosChange, BiosChange)
			and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
  END
ELSE IF ( @ProdID = -1 )
  BEGIN
	IF ( @Status = 0 )
		BEGIN
			Select  v.dotsname as Product, i.id, i.Type, i.Status, i.affectscustomers, e.name as Owner, i.Summary, i.Priority, i.AvailableNotes, i.Description, i.Created, i.LastModified, i.TargetDate,i.ECNDate, i.ActualDate,i.Availablefortest, '<Project Issue>' as Deliverable, ct.Name as CoreTeamRep,i.Submitter, i.Approvals,i.Actions, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, i.AVRequired, i.QualificationRequired
			FROM 
				DeliverableIssues i WITH (NOLOCK)
				INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
				INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
				INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
				LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where  
				Type= COALESCE(@v_Type, Type)
			and (v.sustaining = 1 or  i.CoreTeamRep = 12)
			and BiosChange = COALESCE(@BiosChange, BiosChange)
			and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 1 )
		BEGIN
			Select  v.dotsname as Product, i.id, i.Type, i.Status, i.affectscustomers, e.name as Owner, i.Summary, i.Priority, i.AvailableNotes, i.Description, i.Created, i.LastModified, i.TargetDate,i.ECNDate, i.ActualDate,i.Availablefortest, '<Project Issue>' as Deliverable, ct.Name as CoreTeamRep,i.Submitter, i.Approvals,i.Actions, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, i.AVRequired, i.QualificationRequired
			FROM 
				DeliverableIssues i WITH (NOLOCK)
				INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
				INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
				INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
				LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where  
				Type= COALESCE(@v_Type, Type)
	--		and (i.Status = 1 or i.Status = 3 or i.status = 6)
			and (i.Status = 1 or i.Status = 3 or i.status = 6 or (i.status = 4 and ecndate is null))
			and (v.sustaining = 1 or  i.CoreTeamRep = 12)
			and BiosChange = COALESCE(@BiosChange, BiosChange)
			and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 2 )
		BEGIN
			Select  v.dotsname as Product, i.id, i.Type, i.Status, i.affectscustomers, e.name as Owner, i.Summary, i.Priority, i.AvailableNotes, i.Description, i.Created, i.LastModified, i.TargetDate,i.ECNDate, i.ActualDate,i.Availablefortest, '<Project Issue>' as Deliverable, ct.Name as CoreTeamRep,i.Submitter, i.Approvals,i.Actions, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, i.AVRequired, i.QualificationRequired
			FROM 
				DeliverableIssues i WITH (NOLOCK)
				INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
				INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
				INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
				LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where  
				Type= COALESCE(@v_Type, Type)
	--		and (i.Status = 2 or i.Status = 4 or i.Status = 5)
			and (i.Status = 2 or (ecndate is not null and  i.Status = 4) or i.Status = 5)
			and (v.sustaining = 1 or  i.CoreTeamRep = 12)
			and BiosChange = COALESCE(@BiosChange, BiosChange)
			and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 3 )
		BEGIN
			Select v.dotsname as Product, i.id, i.Type, i.Status, i.affectscustomers, e.name as Owner, i.Summary, i.Priority, i.AvailableNotes, i.Description, i.Created, i.LastModified, i.TargetDate,i.ECNDate, i.ActualDate,i.Availablefortest, '<Project Issue>' as Deliverable, ct.Name as CoreTeamRep,i.Submitter, i.Approvals,i.Actions, i.ZsrpReadyTargetDt, i.ZsrpReadyActualDt, i.ZsrpRequired, i.AVRequired, i.QualificationRequired
			FROM 
				DeliverableIssues i WITH (NOLOCK)
				INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
				INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
				INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
				LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where  
				Type= COALESCE(@v_Type, Type)
			and i.OnStatusReport = 1
			and (v.sustaining = 1 or  i.CoreTeamRep = 12)
			and BiosChange = COALESCE(@BiosChange, BiosChange)
			and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	END
ELSE
  BEGIN
	IF ( @Status = 0 )
		BEGIN
			Select  v.dotsname as Product, 
					i.id, 
					i.Type, 
					i.Status, 
					i.affectscustomers, 
					e.name as Owner, 
					i.Summary, 
					i.Priority, 
					i.AvailableNotes, 
					i.Description, 
					i.Created, 
					i.LastModified, 
					i.TargetDate,
					i.ECNDate, 
					i.ActualDate,
					i.Availablefortest, 
					'<Project Issue>' as Deliverable, 
					ct.Name as CoreTeamRep,
					i.Submitter, 
					i.Approvals,
					i.Actions, 
					i.ZsrpReadyTargetDt, 
					i.ZsrpReadyActualDt, 
					i.ZsrpRequired, 
					i.AVRequired, 
					i.QualificationRequired,
					i.ProductVersionRelease
			FROM 
					DeliverableIssues i WITH (NOLOCK)
					INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
					INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
					INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
					LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where	
					i.ProductVersionID = @ProdID
					AND	Type= COALESCE(@v_Type, Type)
					and BiosChange = COALESCE(@BiosChange, BiosChange)
					and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 1 )
		BEGIN
			Select  v.dotsname as Product, 
					i.id, 
					i.Type, 
					i.Status, 
					i.affectscustomers, 
					e.name as Owner, 
					i.Summary, 
					i.Priority, 
					i.AvailableNotes, 
					i.Description, 
					i.Created, 
					i.LastModified, 
					i.TargetDate,
					i.ECNDate, 
					i.ActualDate,
					i.Availablefortest, 
					'<Project Issue>' as Deliverable, 
					ct.Name as CoreTeamRep,
					i.Submitter, 
					i.Approvals,
					i.Actions, 
					i.ZsrpReadyTargetDt, 
					i.ZsrpReadyActualDt, 
					i.ZsrpRequired, 
					i.AVRequired, 
					i.QualificationRequired,
					i.ProductVersionRelease
			FROM 
					DeliverableIssues i WITH (NOLOCK)
					INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
					INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
					INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
					LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where	
					i.ProductVersionID = @ProdID
					AND	Type= COALESCE(@v_Type, Type)
			--		and (i.Status = 1 or i.Status = 3 or i.status = 6)
					and ((i.Status = 1 or i.Status = 3 or i.status = 6) or ((v.sustaining = 1 or  i.CoreTeamRep = 12) and i.status=4 and i.ecndate is null))
					and BiosChange = COALESCE(@BiosChange, BiosChange)
					and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 2 )
		BEGIN
			Select  v.dotsname as Product,
					i.id, 
					i.Type, 
					i.Status, 
					i.affectscustomers, 
					e.name as Owner, 
					i.Summary, 
					i.Priority, 
					i.AvailableNotes, 
					i.Description, 
					i.Created, 
					i.LastModified, 
					i.TargetDate,
					i.ECNDate, 
					i.ActualDate,
					i.Availablefortest, 
					'<Project Issue>' as Deliverable, 
					ct.Name as CoreTeamRep,
					i.Submitter, 
					i.Approvals,
					i.Actions, 
					i.ZsrpReadyTargetDt, 
					i.ZsrpReadyActualDt, 
					i.ZsrpRequired, 
					i.AVRequired, 
					i.QualificationRequired,
					i.ProductVersionRelease
			FROM 
					DeliverableIssues i WITH (NOLOCK)
					INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
					INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
					INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
					LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where	
					i.ProductVersionID = @ProdID
					AND	Type= COALESCE(@v_Type, Type)
			--		and (i.Status = 2 or i.Status = 4 or i.Status = 5)
					and ((i.Status = 2  or i.Status = 5) or ((v.sustaining = 1 or  i.CoreTeamRep = 12) and i.status=4 and i.ecndate is not null) or ((v.sustaining <> 1 and  i.CoreTeamRep <> 12) and  i.Status = 4)  )
					and BiosChange = COALESCE(@BiosChange, BiosChange)
					and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
	ELSE IF ( @Status = 3 )
		BEGIN
			Select  v.dotsname as Product, 
					i.id, 
					i.Type, 
					i.Status, 
					i.affectscustomers, 
					e.name as Owner, 
					i.Summary, 
					i.Priority, 
					i.AvailableNotes, 
					i.Description, 
					i.Created, 
					i.LastModified, 
					i.TargetDate,
					i.ECNDate, 
					i.ActualDate,
					i.Availablefortest, 
					'<Project Issue>' as Deliverable, 
					ct.Name as CoreTeamRep,
					i.Submitter, 
					i.Approvals,
					i.Actions, 
					i.ZsrpReadyTargetDt, 
					i.ZsrpReadyActualDt, 
					i.ZsrpRequired, 
					i.AVRequired, 
					i.QualificationRequired,
					i.ProductVersionRelease
			FROM 
					DeliverableIssues i WITH (NOLOCK)
					INNER JOIN Employee e WITH (NOLOCK) ON i.OwnerID = e.ID
					INNER JOIN ProductVersion v WITH (NOLOCK) ON i.ProductVersionID = v.ID
					INNER JOIN ProductFamily f WITH (NOLOCK) ON v.ProductFamilyID = f.ID
					LEFT OUTER JOIN CoreTeamRep ct WITH (NOLOCK) ON i.CoreTeamRep = ct.ID
			Where	
					i.ProductVersionID = @ProdID
					AND	Type= COALESCE(@v_Type, Type)
					and i.OnStatusReport = 1
					and BiosChange = COALESCE(@BiosChange, BiosChange)
					and SwChange = COALESCE(@SwChange, SwChange)
			Order By Product, i.ID
		END
  END


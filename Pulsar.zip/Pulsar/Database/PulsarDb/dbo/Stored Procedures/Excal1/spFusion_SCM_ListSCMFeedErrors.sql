﻿
CREATE PROCEDURE [dbo].[spFusion_SCM_ListSCMFeedErrors]
@p_PBID int = 0
AS




IF @p_PBID = 0
  BEGIN
	SELECT c.DOTSName AS Product, d.Name AS Brand, b.IrsAvListId, c.ID AS ProductVersionID, b.KMAT, a.*
	FROM   LastAvIrsPublish a WITH (NOLOCK) INNER JOIN
		   Product_Brand b WITH (NOLOCK) ON a.ProductBrandId = b.ID INNER JOIN
		   ProductVersion c WITH (NOLOCK) ON b.ProductVersionID = c.ID INNER JOIN
		   Brand d WITH (NOLOCK) ON b.BrandID = d.ID
	WHERE  OutgoingMessage IS NOT NULL
	AND   (ISNULL(ErrorMessage,'') != '' OR ISNULL(ErrorCd,'') != '')
	AND    c.ID <> 100
	AND c.ProductStatusID < 4
	ORDER BY c.DOTSName
  END
ELSE
  BEGIN
	SELECT c.DOTSName AS Product, d.Name AS Brand, b.IrsAvListId, c.ID AS ProductVersionID, b.KMAT, a.*
	FROM   LastAvIrsPublish a WITH (NOLOCK) INNER JOIN
		   Product_Brand b WITH (NOLOCK) ON a.ProductBrandId = b.ID INNER JOIN
		   ProductVersion c WITH (NOLOCK) ON b.ProductVersionID = c.ID INNER JOIN
		   Brand d WITH (NOLOCK) ON b.BrandID = d.ID
	WHERE  OutgoingMessage IS NOT NULL
	AND   (ISNULL(ErrorMessage,'') != '' OR ISNULL(ErrorCd,'') != '')
	AND    c.ID <> 100
	AND    c.ProductStatusID < 4
	AND    a.ProductBrandId = @p_PBID
	ORDER BY c.DOTSName
  END
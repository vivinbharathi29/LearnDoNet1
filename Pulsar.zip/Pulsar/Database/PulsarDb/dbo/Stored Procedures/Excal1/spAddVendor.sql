﻿CREATE Procedure [dbo].[spAddVendor]
(
  @Name varchar(50),
  @NewID int Output,
  @NewSMTID int output
)
As

IF EXISTS (SELECT * FROM Vendor WHERE Name = @Name)
 BEGIN
	raiserror('The Vendor name already exists in the system.', 16, 1)
		return -1
 END

 ELSE
	BEGIN
		INSERT Vendor (Name)  Values (@Name) 

	Select @NewID = SCOPE_IDENTITY()

	INSERT INTO Partner (Name,Prefix,Active,PartnerTypeID,OTSVendorGroupID,IRSGroupID,WebSite,CreatedBy,UpdatedBy,Created,Updated,Disabled,DisabledBy)
			   VALUES (@Name, 'V' + CAST(@NewID as VARCHAR(6)), 1, 3, NULL, 0,'www.partner.com','dbo','dbo', getdate(),getdate(), NULL,NULL)

	Exec [spFusion_VENDOR_AddVendorToIRS] @NewID
  END
GO
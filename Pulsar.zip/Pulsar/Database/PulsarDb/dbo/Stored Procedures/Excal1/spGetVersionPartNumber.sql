﻿

CREATE PROCEDURE [dbo].[spGetVersionPartNumber]

(
	@ID int
)

 AS

Select d.ID, d.DeliverableName, d.Version, d.Revision, d.Pass, d.PartNumber, v.name as Vendor
from deliverableversion d with (NOLOCK), vendor v with (NOLOCK)
where d.id =@ID
and v.id = d.vendorID



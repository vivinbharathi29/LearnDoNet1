﻿

CREATE PROCEDURE [dbo].[spGetOTSNote]
(
	@OTSID varchar(15)
)
 AS
Select Notes
FROM OTSNotes with (NOLOCK)
Where observationID = @OTSID




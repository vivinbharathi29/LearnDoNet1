﻿

CREATE PROCEDURE [dbo].[spGetProducts4Web]  

(
	@Type int =1
)

as 

if @Type=0
	SELECT v.ID as ID, p.Name as Name, v.AllowDeliverableReleases,v.Version as Version, e.Name as PM, v.Distribution, v.PRDReleased, v.PDDReleased, v.OnlineReports, v.Active, v.Sustaining, v.Division
	FROM ProductFamily p WITH (NOLOCK)
	INNER JOIN ProductVersion v WITH (NOLOCK) ON p.id = v.ProductFamilyId
	LEFT OUTER JOIN Employee e WITH (NOLOCK) ON e.id = v.PMID
	Order BY Name, Version
else if @Type=-1
	SELECT v.ID as ID, p.Name as Name, v.AllowDeliverableReleases,v.Version as Version, e.Name as PM, v.Distribution, v.PRDReleased, v.PDDReleased, v.OnlineReports, v.Active, v.Sustaining, v.Division, ProductStatusID
	FROM ProductFamily p WITH (NOLOCK)
	INNER JOIN ProductVersion v WITH (NOLOCK) ON p.ID = v.ProductFamilyID
	LEFt OUTER JOIN Employee e WITH (NOLOCK) ON e.ID = v.PMID
	WHERE v.typeid in (1,3)
	Order BY Name, Version
else
	SELECT v.ID as ID, p.Name as Name, v.AllowDeliverableReleases, v.Version as Version, e.Name as PM, v.Distribution, v.PRDReleased, v.PDDReleased, v.OnlineReports, v.Active, v.Sustaining, v.Division
	FROM ProductFamily p WITH (NOLOCK)
	INNER JOIN ProductVersion v WITH (NOLOCK) ON p.ID = v.ProductFamilyID
	LEFT OUTER JOIN Employee e WITH (NOLOCK) ON e.id = v.PMID
	WHERE v.typeid=@Type
	Order BY Name, Version


﻿

CREATE PROCEDURE [dbo].[spGetLanguagesWeb]  
(
    @DelRootID int,
    @IsLanguage bit =1
)
AS
/**Temporatry fix*: it's horrible, but at the moment is the only way to quickly fix the issue with CVA generation.
A mapping table will be added on the release team db to handle CVA language code mappings
*** add BR language 20190705 by Jay
*/
Declare @tc Table(ID int ,Pulsar varchar(3),CVA varchar(3));

INSERT INTO @tc VALUES(48,'AR','AR');
INSERT INTO @tc VALUES(371,'BG','BG');
INSERT INTO @tc VALUES(16,'ZH','CH');
INSERT INTO @tc VALUES(373,'HR','HR');
INSERT INTO @tc VALUES(21,'CS','CS');
INSERT INTO @tc VALUES(9,'DA','DK');
INSERT INTO @tc VALUES(8,'NL','NL');
INSERT INTO @tc VALUES(20,'GB','UK');
INSERT INTO @tc VALUES(1,'US','US');
INSERT INTO @tc VALUES(374,'ET','EI');
INSERT INTO @tc VALUES(11,'FI','FI');
INSERT INTO @tc VALUES(2,'FR','FR');
INSERT INTO @tc VALUES(3,'DE','GR');
INSERT INTO @tc VALUES(170,'B2','B2');
INSERT INTO @tc VALUES(22,'EL','GK');
INSERT INTO @tc VALUES(49,'HE','IL');
INSERT INTO @tc VALUES(54,'HK','TZ');
INSERT INTO @tc VALUES(44,'HU','HU');
INSERT INTO @tc VALUES(5,'IT','IT');
INSERT INTO @tc VALUES(13,'JA','JP');
INSERT INTO @tc VALUES(15,'KO','KR');
INSERT INTO @tc VALUES(375,'LV','LV');
INSERT INTO @tc VALUES(376,'LT','LT');
INSERT INTO @tc VALUES(10,'NO','NO');
INSERT INTO @tc VALUES(12,'PL','PL');
INSERT INTO @tc VALUES(7,'PT','PT');
INSERT INTO @tc VALUES(372,'RO','RO');
INSERT INTO @tc VALUES(45,'RU','RU');
INSERT INTO @tc VALUES(377,'SR','SR');
INSERT INTO @tc VALUES(50,'SK','SK');
INSERT INTO @tc VALUES(47,'SL','SL');
INSERT INTO @tc VALUES(4,'ES','SP');
INSERT INTO @tc VALUES(6,'SV','SE');
INSERT INTO @tc VALUES(27,'TW','TW');
INSERT INTO @tc VALUES(14,'TH','TH');
INSERT INTO @tc VALUES(46,'TR','TR');
INSERT INTO @tc VALUES(393,'UK','UR');
INSERT INTO @tc VALUES(18,'BR','BR'); --20190705 Add by Jay


	if @IsLanguage=1
		BEGIN
			IF NOT EXISTS (SELECT 1 FROM Language_DelRoot WHERE DeliverableRootID=@DelRootID AND LanguageID=1 )
				SELECT l.ID, l.Language, t.cva Abbreviation, d.Title, d.Description, l.Translation, l.Substitute1 AS Sub1, l.Substitute2 AS Sub2, l.Active
				  FROM dbo.Language AS l LEFT OUTER JOIN
					  (SELECT DeliverableRootID, LanguageID, Title, [Description]		  
						FROM  dbo.Language_DelRoot WHERE DeliverableRootID = @DelRootID
							UNION ALL 
						SELECT @DelRootID,1,[Name],[Description] 
							FROM DeliverableRoot WHERE ID=@DelRootID
					  ) AS d  ON l.ID = d.LanguageID 
					  inner join @tc t on l.ID=t.ID
				  WHERE(l.IsLanguage = 1)
				  ORDER BY l.OrderID, l.Language;
			ELSE
				SELECT l.ID, l.Language, t.cva Abbreviation, d.Title, d.Description, l.Translation, l.Substitute1 AS Sub1, l.Substitute2 AS Sub2, l.Active
				  FROM dbo.Language AS l WITH (NOLOCK) LEFT OUTER JOIN
					  dbo.Language_DelRoot AS d WITH (NOLOCK) ON l.ID = d.LanguageID AND (d.DeliverableRootID = @DelRootID)
					  inner join @tc t on l.ID=t.ID
				  WHERE(l.IsLanguage = @IsLanguage)
				  ORDER BY l.OrderID, l.Language;
		END
	else
		  SELECT l.ID, l.Language, l.Abbreviation, d.Title, d.Description, l.Translation, l.Substitute1 AS Sub1, l.Substitute2 AS Sub2, l.Region, l.Active
		  FROM dbo.Language AS l WITH (NOLOCK) LEFT OUTER JOIN
			  dbo.Language_DelRoot AS d WITH (NOLOCK) ON l.ID = d.LanguageID AND (d.DeliverableRootID = @DelRootID)
		  WHERE  (l.IsLanguage = @IsLanguage)
		  ORDER BY l.Region, l.Language;

GO

	
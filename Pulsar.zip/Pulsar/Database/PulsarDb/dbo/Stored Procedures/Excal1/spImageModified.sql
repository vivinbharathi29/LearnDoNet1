﻿

CREATE PROCEDURE [dbo].[spImageModified]
(
	@ImageDefID int
)
 AS
Update ImageDefinitions
Set Modified=GetDate()
Where ID = @ImageDefID 




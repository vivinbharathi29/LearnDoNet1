﻿
CREATE PROCEDURE [dbo].[spGetQualificationStatus]
(
	@ID int
)
AS
	Select status
	from testStatus with (NOLOCK)
	where id=@ID




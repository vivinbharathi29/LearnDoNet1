﻿
CREATE PROCEDURE [dbo].[spGetQCompleteCount]
(
	@ID int
)

 AS

Select Count(*)  as QCompleteCount
from product_deliverable pd with (NOLOCK)
where pd.teststatusid = 5
and pd.deliverableversionid = @ID


﻿

CREATE PROCEDURE [dbo].[spAddExcelProfile]
(
	@EmployeeID int,
	@Name varchar(50),
	@Products varchar(8000),
	@Columns varchar(8000),
	@Header tinyint,
	@ActionType tinyint,
	@NewID int Output
)
AS
Insert EmployeeExcelProfiles(ProfileName,ExcelExportProjects,ExcelExportColumns,ExcelExportHeader, EmployeeID,ActionType)
Values(@Name, @Products,@Columns,@Header, @EmployeeID,@ActionType)
Select @NewID = SCOPE_IDENTITY()




﻿
CREATE PROCEDURE [dbo].[spAddDeliverableVersionPlaceHolder]
 (
  @RootID as int,
  @NewID int output
 )
 AS

	Insert DeliverableVersion(DeliverableRootID, Latest)
	Values (@RootID,1);

	Select @NewID = SCOPE_IDENTITY() 

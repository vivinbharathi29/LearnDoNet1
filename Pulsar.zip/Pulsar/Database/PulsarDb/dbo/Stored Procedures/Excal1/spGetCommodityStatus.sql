﻿

CREATE PROCEDURE [dbo].[spGetCommodityStatus]

(
	@ProdID int,
	@VersionID int
)
 AS

Select pd.id, pd.ConfigurationRestriction, pd.SupplyChainRestriction, v.TTS, pv.wwanproduct, pd.DeveloperTestStatus, pd.DeveloperTestNotes, pd.IntegrationTestStatus, pd.IntegrationTestNotes, pd.ODMTestStatus, pd.ODMTestnotes, c.requiresTTS, c.requiresodmtestfinalapproval, c.requiresWWANtestfinalapproval, c.requiresMITtestfinalapproval, c.requiresdeveloperfinalapproval ,pd.WWANTestStatus, pd.WWANTestNotes, pd.TestStatusID, pd.targetNotes, pd.TestConfidence, pv.devcenter, pd.TestDate, pd.DCRID,pd.developernotificationstatus, c.name as category, c.id as CategoryID, r.name as DeliverableName, v.version, v.revision, v.pass, v.vendorid, v.deliverablerootid, v.modelnumber, SUBSTRING(v.partnumber,0,11) as partnumber, vd.name as vendor, pv.dotsname as Product, pv.PartnerID, pd.RiskRelease
from product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), productversion pv with (NOLOCK), productfamily f with (NOLOCK), vendor vd with (NOLOCK), deliverableroot r with (NOLOCK), deliverablecategory c with (NOLOCK)
where pv.id = pd.productversionid
and pd.deliverableversionid = v.id
and f.id=pv.productfamilyid
and c.id = r.categoryid
and vd.id=v.vendorid
and r.id = v.deliverablerootid
and pd.productversionid = @ProdID
and pd.deliverableversionid = @VersionID











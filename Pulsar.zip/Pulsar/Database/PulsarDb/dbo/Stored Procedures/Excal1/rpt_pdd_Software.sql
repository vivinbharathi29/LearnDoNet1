﻿
CREATE PROCEDURE [dbo].[rpt_pdd_Software]
	@p_ProductVersionID INT
AS

/******************************************************************************
**		File: 
**		Name: rpt_pdd_Software
**		Desc: 
**
**		This template can be customized:
**              
**		Return values:
** 
**		Called by:   
**              
**		Parameters:
**		Input							Output
**     ----------							-----------
**
**		Auth: 
**		Date: 
*******************************************************************************
**		Change History
*******************************************************************************
**		Date:		Author:				Description:
**		--------		--------				-------------------------------------------
**    
*******************************************************************************/


SELECT     
	DeliverableRoot.Name AS [Deliverable Name], 
	CASE MAX(CAST(Product_Deliverable.Preinstall | Product_Deliverable.Preload AS INT)) WHEN 1 THEN 'X' WHEN 0 THEN '' END AS Preinstall, 
--	MAX(CAST(Product_Deliverable.Preinstall AS INT)) AS [Image],
--	MAX(CAST(Product_Deliverable.Preload AS INT)) AS [Pre-Load], 
	CASE MAX(CAST(Product_Deliverable.DropInBox AS INT)) WHEN 1 THEN 'X' WHEN 0 THEN '' END AS [Drop In Box], 
	CASE MAX(CAST(Product_Deliverable.Web AS INT)) WHEN 1 THEN 'X' WHEN 0 THEN '' END AS Web 
--	COUNT(DeliverableRoot.ID) AS COUNT
FROM         
	Product_Deliverable with (NOLOCK) INNER JOIN
	DeliverableVersion with (NOLOCK) ON Product_Deliverable.DeliverableVersionID = DeliverableVersion.ID INNER JOIN
	DeliverableRoot with (NOLOCK) ON DeliverableVersion.DeliverableRootID = DeliverableRoot.ID
WHERE     
	Product_Deliverable.ProductVersionID = @p_ProductVersionID
AND 	DeliverableRoot.TypeID = 2
AND	Product_Deliverable.Targeted = 1
GROUP BY 
	DeliverableRoot.ID, 
	DeliverableRoot.Name




﻿

CREATE PROCEDURE [dbo].[spGetWorkgroups]
(
	@TestGroups int = null
)
 AS
	SELECT ID, Name
	FROM Workgroups with (NOLOCK)
	WHERE TestGroup=coalesce(@TestGroups,TestGroup)
	Order By Name;


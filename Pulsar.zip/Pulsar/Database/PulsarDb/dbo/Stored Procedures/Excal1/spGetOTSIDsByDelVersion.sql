﻿

CREATE PROCEDURE [dbo].[spGetOTSIDsByDelVersion]
 (
  @DelVerID int
 )
 AS
Select OTSNumber, 'Cannot display summary because OTS is unavailable' as shortdescription, '' as Priority, '' as stepstoreproduce, '' as cycle, '' as systemboard
FROM OTS_DelVer  with (NOLOCK)
Where DeliverableVersionid = @DelVerID



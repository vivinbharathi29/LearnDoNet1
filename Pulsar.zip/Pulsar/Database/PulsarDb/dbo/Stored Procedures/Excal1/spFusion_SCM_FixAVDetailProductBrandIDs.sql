﻿-- =================================================================
-- Update: Changed to new OUTER JOIN syntax - Paul Sanchez 3/11/2014
-- =================================================================
/**************************************************************************************************    
** SNo   Date        Author                                    Description           
** --    --------   -------                                   -------------------------           
 ** 1    09/01/2019  Santhana K								  Used the Setting table instead of hardcoding email address
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spFusion_SCM_FixAVDetailProductBrandIDs]

AS


	Declare @IRSModuleID int
	Declare @IRSHWID int
	Declare @IRSPlatformAliasId int
	Declare @IRSPlatformId int
	Declare @PlatformID int
	Declare @HWID int
	Declare @AVDetailProductBrandID int
	Declare @SQL as varchar(8000)
	Declare @MailBody as varchar(MAX)

	Select @MailBody = ''

	Declare @RecipientEmail varchar(100)
	select @RecipientEmail = value from Setting
	where name = 'Pulsar.SupportEmail'


	DECLARE FixAVPBModuleIssues_CURSOR CURSOR FOR 	
	Select avpb.id,  coalesce(irs.moduleid,0)
	from 
		AvDetail_ProductBrand avpb WITH (nolock) 
		inner join AvDetail av WITH (NOLOCK) on avpb.avdetailid = av.avdetailid and av.featurecategoryid in (1,86)
		inner join Product_Brand b WITH (nolock) on avpb.ProductBrandID = b.ID 
		inner join ProductVersion pv WITH (NOLOCK) on b.ProductVersionId = pv.ID
		left outer join (SELECT l.ParentId, am.AvListId, am.CategoryId, m.ModuleId, m.AliasId, am.AvPartNo
			FROM	
				irs_avlist l
				INNER JOIN irs_avlist_module am on l.avlistid = am.avlistid and am.scmid = 1 and am.categoryid = 3067
				INNER JOIN irs_module m on am.moduleId = m.moduleid) irs ON b.IrsAvListId = irs.ParentId AND avpb.IrsPlatformAliasId = irs.AliasId
	where 
		avpb.IRSPlatformAliasId <> 0 
		and coalesce(avpb.IRSBaseUnitModuleId,0) <> coalesce(irs.moduleid,0)

	open FixAVPBModuleIssues_CURSOR
	
	FETCH NEXT FROM FixAVPBModuleIssues_CURSOR Into @AVDetailProductBrandID, @IRSModuleID
	WHILE (@@fetch_status <> -1)
		BEGIN
			If (@@fetch_status <> -2)
				BEGIN
					Select @SQL= 'Update avdetail_productbrand set IRSBaseUnitModuleId=' + cast(@IRSModuleID as varchar(30))   + ' where id= ' + cast(@AVDetailProductBrandID as varchar(30))
					Print @SQL
					Select @MailBody = @MailBody +  @SQL + Char(10)


					exec (@SQL)
				END
			FETCH NEXT FROM FixAVPBModuleIssues_CURSOR Into  @AVDetailProductBrandID,  @IRSModuleID
		END
	DEALLOCATE FixAVPBModuleIssues_CURSOR


	if @MailBody <> ''
		Begin
			EXEC msdb.dbo.sp_send_dbmail
				@profile_name = 'Database Mail Profile',
				@recipients = @RecipientEmail, 
				@body = @MailBody,
				@subject = 'AVDetail_ProductBrand IRS IDs Updated' ;	
		end
GO



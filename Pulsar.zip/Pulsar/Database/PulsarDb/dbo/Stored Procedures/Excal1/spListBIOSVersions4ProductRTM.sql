﻿CREATE PROCEDURE [dbo].[spListBIOSVersions4ProductRTM] 
(
	@ID int,
	@ReportType int = 1,
	@ProductRTMID int=0
)
AS

if @ReportType = 1
	Select v.id, v.deliverablename, v.version, v.location, v.comments, pd.targeted,pd.targetnotes
	from product_Deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK)
	where pd.deliverableversionid = v.id
	and r.id = v.deliverablerootid
	and productversionid = @ID
	and r.categoryid = 161
	and v.id not in (Select deliverableversionid
					 from dbo.ProductRTM r with (NOLOCK), dbo.ProductRTM_DeliverableVersion rd with (NOLOCK)
					 where rd.ProductRTMID = r.id
					 and productversionid = @ID
					 )	
	and (left(v.version,1) = 'b' or left(v.version,1) = 'f' or (left(v.version,1) = '0'  and substring(v.version,3,1) = '.') )
	order by v.deliverablename, targeted desc, v.id desc
else if @ReportType = 2
	Select v.id, v.deliverablename, v.version, v.location, v.comments, pd.targeted,pd.targetnotes
	from product_Deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK)
	where pd.deliverableversionid = v.id
	and r.id = v.deliverablerootid
	and productversionid = @ID
	and r.categoryid = 161
	and v.id not in (Select deliverableversionid
					 from dbo.ProductRTM r with (NOLOCK), dbo.ProductRTM_DeliverableVersion rd with (NOLOCK)
					 where rd.ProductRTMID = r.id
					 and productversionid = @ID
					 )	
	and (
			left(v.version,1) = 'f'
		or	(left(v.version,1) = '0' and substring(v.version,3,1) = '.')
		)
	order by v.deliverablename,targeted desc, v.id desc
else if @ReportType = 3 --f versions not previouly RTMed
	Select v.id, v.deliverablename, v.version, v.location, v.comments,pd.targeted,
	CASE WHEN (select Count(deliverableversionid) from ProductRTM_DeliverableVersion where ProductRTMID=@ProductRTMID and deliverableversionid=v.id)>0
          THEN 1
         WHEN ( @ProductRTMID = 0) THEN pd.targeted    
		 ELSE 0
	 END as deliverabletargeted,pd.targetnotes,
	CASE WHEN (Select Count(*)
					 from dbo.ProductRTM pr with (NOLOCK), dbo.ProductRTM_DeliverableVersion dv with (NOLOCK)
					 where dv.ProductRTMID = pr.id and v.id=dv.deliverableversionid
					 and productversionid = @ID and ISNULL(pr.IsRTMAsDraft,0)=0)>0
          THEN 1
        ELSE 0
		END as rtmed
	from product_Deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK)
	where pd.deliverableversionid = v.id
	and r.id = v.deliverablerootid
	and productversionid = @ID
	and r.categoryid = 161
	and pd.rtmdate is null
	and v.id not in (Select deliverableversionid
					 from dbo.ProductRTM r with (NOLOCK), dbo.ProductRTM_DeliverableVersion rd with (NOLOCK)
					 where rd.ProductRTMID = r.id
					 and productversionid = @ID
					 )	
	and (
			left(v.version,1) = 'f'
		or	(left(v.version,1) = '0' and substring(v.version,3,1) = '.')
		)
	
	UNION ALL
	
	Select v.id, v.deliverablename, v.version, v.location, v.comments,pd.targeted,
	CASE WHEN (select Count(deliverableversionid) from ProductRTM_DeliverableVersion where ProductRTMID=@ProductRTMID and deliverableversionid=v.id)>0
          THEN 1
         WHEN ( @ProductRTMID = 0) THEN pd.targeted    
		 ELSE 0
         END as deliverabletargeted,pd.targetnotes,
	CASE WHEN (Select Count(*)
					 from dbo.ProductRTM pr with (NOLOCK), dbo.ProductRTM_DeliverableVersion dv with (NOLOCK)
					 where dv.ProductRTMID = pr.id and v.id=dv.deliverableversionid
					 and productversionid = @ID and ISNULL(pr.IsRTMAsDraft,0)=0)>0
          THEN 1
        ELSE 0
		END as rtmed

	from product_Deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK)
	where pd.deliverableversionid = v.id
	and r.id = v.deliverablerootid
	and productversionid = @ID
	and r.categoryid = 161
	and pd.rtmdate is null
	and v.id  in (Select deliverableversionid
					 from dbo.ProductRTM r with (NOLOCK), dbo.ProductRTM_DeliverableVersion rd with (NOLOCK)
					 where rd.ProductRTMID = r.id --and r.ID=8547
					 and productversionid = @ID
					 )	
	and (
			left(v.version,1) = 'f'
		or	(left(v.version,1) = '0' and substring(v.version,3,1) = '.')
		)

	order by v.deliverablename,targeted desc, v.id desc


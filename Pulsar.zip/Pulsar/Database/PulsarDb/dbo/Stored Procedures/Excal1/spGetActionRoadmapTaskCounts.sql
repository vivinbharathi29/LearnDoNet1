﻿

CREATE PROCEDURE [dbo].[spGetActionRoadmapTaskCounts]
(
	@ID int,
	@ProductID int=0
)
 AS

Declare @TaskCount int
Declare @CompleteCount int

if @ProductID = 0
	Begin
	Select @Taskcount = Count(ID) from DeliverableIssues with (NOLOCK) where ActionRoadmapID= @ID

	Select @CompleteCount = Count(ID) from DeliverableIssues with (NOLOCK) where ActionRoadmapID= @ID and Status=2

	END
else
	Begin
	Select @Taskcount = Count(ID) from DeliverableIssues with (NOLOCK) where ActionRoadmapID= @ID and productversionid = @ProductID

	Select @CompleteCount = Count(ID) from DeliverableIssues with (NOLOCK) where ActionRoadmapID= @ID and Status=2 and productversionid  =@ProductID

	END



Select @TaskCount as TaskCount, @CompleteCount as CompleteCount



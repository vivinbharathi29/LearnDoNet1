﻿CREATE PROCEDURE [dbo].[spAddSystemBoardDelVer]
/* ************************************************************************************************
 * Purpose:save System Board Hardware Component
 * Created By:	03/30/2015 ,Sruthi Ragishetti
 * Modified By: 5/28/2015 , Sruthi - Save SystemId to new column in table and also feed systemid to IRS_Platform Synonym.
                6/29/2015 , Sruthi - Allow null values for SBName and SystemId
				8/21/2015 , Sruthi Ragishetti -  Component and Step column needs to be swapped Task 11804 and Remove some SystemBoard fields Task 11830 
				8/24/2015 , Sruthi Ragishetti - Remove some fields as required Task 11864
				9/3/2015 , Sruthi Ragishetti - Remove Processor supporeted field for system board Task 12281
				9/29/2015 , Sruthi Ragishetti - Remove Features field for SystemBoard Task 13049
				03/29/2016, Ravi Nukala - Replaced @@IDENTITY with SCOPE_IDENTITY(), Task 18865
				04/4/2016 , Sruthi Ragishetti - Add CPU Speed field for systemboard - task 19009
*************************************************************************************************/

@p_DeliverableRootId int,

@p_DeliverableVersionId int,

@p_ProgramPhaseId int,

@p_VendorPartNumber varchar(64),

@p_MaxMemorySize varchar(64)=null,

@p_MaxMemorySizeUnit varchar(18)=null,

@p_ExpansionSlotSelected varchar(5000),

@p_ConnectorSelected varchar(5000),

@p_NorthBridgeSelected varchar(100),

@p_SouthBridgeSelected varchar(100),

@p_OtherBridgeSelected varchar(100),

@p_ReworkDescription varchar(2000),

@p_CPUSpeed varchar(64)=null,

@p_CPUSpeedUnit varchar(18)=null,

@p_SystemBoardName varchar(100)=null,

@p_SystemID varchar(30)=null,

@p_strUser varchar(120),

@p_actionType varchar(100)


AS
begin
declare @p_SBHardwareComponentId int 

-- creating temp tables and inserting records into tables

	-- for Expansion slot

	create table #tmpExp (SBExpString varchar(5000))

	create table #tmpExpansionslot (id varchar(1000),quantity int)

	if (@p_ExpansionSlotSelected <> '')

	begin

	insert into #tmpExp (SBExpString)

	Select Value from dbo.ufnSplit(@p_ExpansionSlotSelected, ';')



	insert into #tmpExpansionslot (id,quantity)

	select substring(SBExpString,0, charindex(':',SBExpString) ), substring(SBExpString,charindex(':',SBExpString)+1, len(SBExpString) )

	from #tmpExp

	end



	-- for Connector

	create table #tmpConn (SBConnString varchar(5000))

	create table #tmpConnector (id varchar(1000),quantity int)

	if (@p_ConnectorSelected <> '')

	begin

	insert into #tmpConn (SBConnString)

	Select Value from dbo.ufnSplit(@p_ConnectorSelected, ';')



	insert into #tmpConnector (id,quantity)

	select substring(SBConnString,0, charindex(':',SBConnString) ), substring(SBConnString,charindex(':',SBConnString)+1, len(SBConnString) )

	from #tmpConn

	end
	
	--for sbchipsettable northbridge

	create table #tmpBridge(BridgeId int, ChipsetId int,CompId int,  StepId int)

	if (@p_NorthBridgeSelected <> '')

	begin

	set @p_NorthBridgeSelected=Replace(@p_NorthBridgeSelected,';','.')

	if(ParseName(@p_NorthBridgeSelected, 3) <> '' and ParseName(@p_NorthBridgeSelected, 2) <> '' and ParseName(@p_NorthBridgeSelected, 1) <> '' )

	begin

	insert into #tmpBridge (BridgeId,ChipsetId, CompId  , StepId)

	SELECT ParseName(@p_NorthBridgeSelected, 4),ParseName(@p_NorthBridgeSelected, 3) , ParseName(@p_NorthBridgeSelected, 2) , ParseName(@p_NorthBridgeSelected, 1) 

	end

	end
	--create table #tmpSouthBridge(SouthBridge int)

	if (@p_SouthBridgeSelected <> '')

	begin

	set @p_SouthBridgeSelected=Replace(@p_SouthBridgeSelected,';','.')

	if(ParseName(@p_SouthBridgeSelected, 3) <> '' and ParseName(@p_SouthBridgeSelected, 2) <> '' and ParseName(@p_SouthBridgeSelected, 1) <> '' )

	begin

	insert into #tmpBridge (BridgeId,ChipsetId , CompId , StepId )

	SELECT ParseName(@p_SouthBridgeSelected, 4),ParseName(@p_SouthBridgeSelected, 3) , ParseName(@p_SouthBridgeSelected, 2) , ParseName(@p_SouthBridgeSelected, 1) 

	end
	
	end
	--create table #tmpNorthBridge(NorthBridge int)
	
	if (@p_OtherBridgeSelected <> '')

	begin

	set @p_OtherBridgeSelected=Replace(@p_OtherBridgeSelected,';','.')

	if(ParseName(@p_OtherBridgeSelected, 3) <> '' and ParseName(@p_OtherBridgeSelected, 2) <> '' and ParseName(@p_OtherBridgeSelected, 1) <> '' )

	begin

	insert into #tmpBridge (BridgeId,ChipsetId , CompId  , StepId)

    SELECT ParseName(@p_OtherBridgeSelected, 4),ParseName(@p_OtherBridgeSelected, 3) , ParseName(@p_OtherBridgeSelected, 2) , ParseName(@p_OtherBridgeSelected, 1) 

	end

	end

if (@p_actionType = 'create')

 begin
 
  insert into SBHardwareComponent (DeliverableRootId,DeliverableVersionId,ProgramPhaseId,ROMSystemBoardID,VendorPartNumber,

                                   MaxMemorySize,MaxMemorySizeUnit,ReworkDescription,CPUSpeed, CPUSpeedUnit,SystemBoardNameIRSID,SystemID,Created,CreatedBy,Updated,UpdatedBy,Disabled,DisabledBy)

                            values(@p_DeliverableRootId,@p_DeliverableVersionId,@p_ProgramPhaseId,0,@p_VendorPartNumber,

                                   @p_MaxMemorySize,@p_MaxMemorySizeUnit,@p_ReworkDescription,@p_CPUSpeed, @p_CPUSpeedUnit, 0,@p_SystemID,GETDATE(),@p_strUser,GETDATE(),@p_strUser,null,null)


            select @p_SBHardwareComponentId = SCOPE_IDENTITY()	



		-- insert into  SystemBoard Features , System Board Processor, System Board Expansion slot, System board Connector, System board Chipset table 


				insert into SB_ExpansionSlot(SBHardwareComponentId,ExpansionSlotId,Quantity)

				select @p_SBHardwareComponentId, SUBSTRING(id, 16, LEN(id)), quantity

				from #tmpExpansionslot



				insert into SB_Connector(SBHardwareComponentId,ConnectorId,Quantity)

				select @p_SBHardwareComponentId, SUBSTRING(id, 12, LEN(id)), quantity

				from #tmpConnector

				

				insert into SB_ChipSetTable(SBHardwareComponentId,ChipSetTableId,ChipSetId,ChipSetComponentId, ChipSetStepId)

				select @p_SBHardwareComponentId, BridgeId,ChipsetId , CompId, StepId 

				from #tmpBridge

				-- Feed SystemId to IRS

				if(@p_SystemID != '')
				BEGIN
						Update platform
					set SystemID = @p_SystemID
					where PlatformID in (Select PlatformID from platform where PCA = @p_SystemBoardName)
				END
 end
 
 else if (@p_actionType = 'update')

 begin
 
				 Update SBHardwareComponent 

				 set 

				 ProgramPhaseId = @p_ProgramPhaseId,

				 VendorPartNumber = @p_VendorPartNumber,

				 MaxMemorySize = @p_MaxMemorySize,

				 MaxMemorySizeUnit = @p_MaxMemorySizeUnit,

                 ReworkDescription = @p_ReworkDescription,

				 CPUSpeed= @p_CPUSpeed, 

				 CPUSpeedUnit = @p_CPUSpeedUnit,

				 Updated = GETDATE(),

				 UpdatedBy = @p_strUser

				 where

				 DeliverableRootId = @p_DeliverableRootId and

				 DeliverableVersionId = @p_DeliverableVersionId



                 select @p_SBHardwareComponentId=ID from SBHardwareComponent where  DeliverableRootId = @p_DeliverableRootId and  DeliverableVersionId = @p_DeliverableVersionId



				 -- Delete existing records before updating these tables
				  
				  Delete SB_ExpansionSlot where SBHardwareComponentId = @p_SBHardwareComponentId

				  Delete SB_Connector where SBHardwareComponentId = @p_SBHardwareComponentId

				  Delete SB_ChipSetTable where SBHardwareComponentId = @p_SBHardwareComponentId


	
				insert into SB_ExpansionSlot(SBHardwareComponentId,ExpansionSlotId,Quantity)

				select @p_SBHardwareComponentId, SUBSTRING(id, 16, LEN(id)), quantity

				from #tmpExpansionslot



				insert into SB_Connector(SBHardwareComponentId,ConnectorId,Quantity)

				select @p_SBHardwareComponentId, SUBSTRING(id, 12, LEN(id)), quantity

				from #tmpConnector					



				insert into SB_ChipSetTable(SBHardwareComponentId,ChipSetTableId,ChipSetId,ChipSetComponentId, ChipSetStepId)

				select @p_SBHardwareComponentId, BridgeId,ChipsetId , CompId , StepId

				from #tmpBridge



 end



 end



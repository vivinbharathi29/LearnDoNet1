﻿
CREATE PROCEDURE [dbo].[spAddSubassemblyLink]

(
	@ProdDelID int,
	@RootID int
)
 AS


DECLARE @NativeRootID int
DECLARE @Bridged tinyint

Select @NativeRootID = v.deliverablerootid
from product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK)
where pd.deliverableversionid = v.id
and pd.id = @prodDelID

if @NativeRootID = @RootID
	Select @Bridged = 0
else
	Select @Bridged=1

Insert Into ProdDel_DelRoot(ProductDeliverableID, DeliverableRootID, Bridged)
Values(@ProdDelID,@RootID, @Bridged)


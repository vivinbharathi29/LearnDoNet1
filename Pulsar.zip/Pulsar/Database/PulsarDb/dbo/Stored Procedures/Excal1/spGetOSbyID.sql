﻿

CREATE PROCEDURE [dbo].[spGetOSbyID]
(
  @OSID int = -1
)
AS

Select ID,Name
FROM OSLookup with (NOLOCK)
where ID = @OSID



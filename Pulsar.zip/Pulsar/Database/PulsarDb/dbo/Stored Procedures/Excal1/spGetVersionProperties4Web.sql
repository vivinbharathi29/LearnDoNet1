﻿

CREATE PROCEDURE [dbo].[spGetVersionProperties4Web]-- 73559
	(
		@ID as int	
	)
 AS
SELECT     
	v.appstore, v.basefilepath, v.cvasubpath, coalesce(v.KoreanCertificationRequired,0) as KoreanCertificationRequired,v.KoreanCertificationID,c.FCCRequired,c.TeamID,v.fccid, v.IRSPartNumber, v.anatel,v.ICASA,v.SecondaryRFKill, v.ReturnCodes, r.ID AS RootID, v.MD5, r.TransferServerID, v.LearnMore, r.HPPI, c.RequiresTTS, v.ServiceActive, v.ServiceEOADate, v.WWANTestSpecRev, 
    v.WWANTestReport, v.ID AS VersionID, v.MUIAware, v.EDID, v.TTS, v.LeadFree, v.GreenSpecID, v.RoHSID, r.DeliverableSpec, v.SWSetupCategoryID, v.HFCN, 
    v.Active AS ActiveVersion, v.AR, v.SWSetupCategoryID AS Expr1, s.Name AS softpaqcategory, v.SampleDate, v.Languages, v.LevelID, v.TDCImagePath, 
    v.Path2Location, v.Path2Description, v.Path3Location, v.Path3Description, v.PMRComplete, v.AdditionalReleaseNotifications, v.SoftpaqEnhancements, 
    r.Notifications AS WorkflowNotifications, v.IntroConfidence, v.CodeName, v.DeveloperNotification, v.SamplesConfidence, v.IntroDate, v.EndOfLifeDate AS EOLDate, 
    v.Location, v.ModelNumber, v.EffectiveDate, v.MultiLanguage, r.TypeID, v.ISOImage, v.Replicater, v.Filename, v.SoftpaqFileInfo, v.SoftpaqInstructions, v.Supersedes, 
    v.SoftpaqNumber, r.Description, r.Notes, v.SoftpaqFixes, v.InstallableUpdate, r.Name, v.DeliverableName, v.Version, v.Revision, v.Pass, v.PartNumber, 
    v.VendorVersion, v.VendorID, v.Status, v.DeveloperID, v.ReleaseDoc, v.ImagePath, v.ReleaseDate, v.Comments, v.Install, v.OSType, v.SilentInstall, v.ARCDInstall, 
    v.Preinstall, v.Rompaq, v.CDImage, v.Patch,v.CAB, v.Binary, v.FloppyDisk, v.PreinstallROM, v.Admin, v.EndUserInstructions, v.SilentInstructions, v.PackageType, v.Changes, 
    r.WorkflowID, r.RootFilename, v.SWDependencies, vd.Name AS Vendor, e.Email AS DevManagerEmail, e.Name AS DevManager, v.SSMCompliant, v.Reboot, 
    v.Scriptpaq, v.Desktops, v.Notebooks, v.Workstations, v.ThinClients, v.Monitors, v.Projectors, v.Handhelds, v.Printers, v.PersonalAudio, v.ReleaseType, 
    v.PNPDevices, COALESCE (v.CDPartNumber, '') AS CDPartNumber, v.CDKitNumber, r.CertRequired AS Certification, v.CertificationStatus, v.CertificationDate, 
    v.CertificationID, v.CertificationComments, e2.Email AS DeveloperEmail, e2.Name AS Developer, r.CategoryID, c.Name AS Category, v.CATStatus, 
    vd2.Name AS VersionVendor, e.Email AS DevManagerEmail, vd2.ID AS VersionVendorID, v.IconDesktop, v.IconInfoCenter, v.IconMenu, v.IconTray, v.IconPanel, 
    v.PackageForWeb, v.PropertyTabs, v.ConsumerReleaseStatus, v.CommercialReleaseStatus, v.OEMReadyStatus, v.OEMReadyDate, v.OEMReadyId, 
    v.OEMReadyComments, r.OEMReadyRequired, v.CloneType, case when r.CategoryID = 248 then 0 else 1 end as StructureCheck, v.DpbCompliant, v.DevicesInfPath,
	v.EntryMePCR0, v.FullMePCR0, vd3.Name AS Supplier, ISNULL(vd3.ID,0) AS SupplierID, v.IRSVersionID, v.IRSID as IRSPassID, v.IRSRevisionID, v.IRSRootID, v.irsPath, v.cloneid, v.initialpath, r.DevManagerID, r.testerid
FROM         
	DeliverableVersion AS v WITH (NOLOCK) 
	INNER JOIN DeliverableRoot AS r WITH (NOLOCK) ON v.DeliverableRootID = r.ID 
	INNER JOIN Vendor AS vd WITH (NOLOCK) ON r.VendorID = vd.ID 
	LEFT OUTER JOIN SoftpaqCategory AS s WITH (NOLOCK) ON r.SoftpaqCategoryID = s.ID 
	LEFT OUTER JOIN Vendor AS vd2 WITH (NOLOCK) ON v.VendorID = vd2.ID 
	INNER JOIN Employee AS e WITH (NOLOCK) ON r.DevManagerID = e.ID 
	INNER JOIN Employee AS e2 WITH (NOLOCK) ON v.DeveloperID = e2.ID 
	INNER JOIN DeliverableCategory AS c WITH (NOLOCK) ON r.CategoryID = c.ID 
	LEFT OUTER JOIN Vendor AS vd3 WITH (NOLOCK) ON v.SupplierID = vd3.ID
WHERE     (v.ID = @ID)

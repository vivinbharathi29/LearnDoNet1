﻿CREATE PROCEDURE [dbo].[spAddSubassemblyLinkRelease]
/* ************************************************************************************************
 * Purpose: add subassembly link
 * Created By: Dien Bui
 * Modified By: 
 **************************************************************************************************/
(
	@ProdDelRelID int,
	@RootID int
)
 AS


DECLARE @NativeRootID int
DECLARE @Bridged tinyint
DECLARE @ProdDelID int

Select @NativeRootID = v.deliverablerootid, @ProdDelID = pd.ID
from product_deliverable pd with (NOLOCK) 
inner join deliverableversion v with (NOLOCK) on v.ID = pd.DeliverableVersionID
inner join product_deliverable_release pdr with (NOLOCK) on pdr.ProductDeliverableID = pd.ID
where pdr.id = @ProdDelRelID

if @NativeRootID = @RootID
	Select @Bridged = 0
else
	Select @Bridged=1

Insert Into ProdDel_DelRoot(ProductDeliverableID, DeliverableRootID, Bridged, ProductDeliverableReleaseID)
Values(@ProdDelID,@RootID, @Bridged, @ProdDelRelID)


﻿CREATE PROCEDURE [dbo].[spGetAccessoryStatusRelease]
	@ProdID int,
	@VersionID int,
	@ProductDeliverableReleaseID int
AS
	Select pdr.id, 
	   ps.name as pilotstatus, 
	   pdr.AccessoryStatusID, 
	   pdr.accessorynotes, 
	   pdr.accessorydate, 
	   pdr.accessoryleveraged, 
	   pdr.targetNotes,  
	   pv.devcenter, 
	   pdr.PilotNotes, 
	   t.status as TestStatus, 
	   pdr.TestStatusID, 
	   pdr.TestDate, 
	   pdr.PilotDate, 
	   r.name as DeliverableName, 
	   r.KitDescription, 
	   r.kitnumber, 
	   v.version, 
	   v.revision, 
	   v.pass, 
	   v.modelnumber, 
	   v.partnumber, 
	   vd.name as vendor, 
	   pv.dotsname as Product,
	   ProductDeliverableID = pdr.ProductDeliverableID
	from 
	productfamily f with (NOLOCK)
	inner join productversion pv with (NOLOCK) on f.ID = pv.ProductFamilyID
	inner join product_deliverable pd with (NOLOCK) on pv.ID = pd.ProductVersionID
	inner join product_deliverable_release pdr with (NOLOCK) on pdr.ProductDeliverableID = pd.id
	inner join deliverableversion v with (NOLOCK) on pd.DeliverableVersionID = v.id
	inner join vendor vd with (NOLOCK) on v.VendorID = vd.ID
	inner join deliverableroot r with (NOLOCK) on v.DeliverableRootID = r.ID
	inner join pilotstatus ps with (NOLOCK) on pdr.PilotStatusID = ps.id
	left outer join TestStatus t with (NOLOCK) on pdr.TestStatusID = t.ID
	where 
	pd.productversionid = @ProdID
	and pd.deliverableversionid = @VersionID
	and pdr.id = @ProductDeliverableReleaseID

RETURN 0

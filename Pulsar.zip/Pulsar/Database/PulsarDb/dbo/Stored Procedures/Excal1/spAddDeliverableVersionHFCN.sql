﻿/**************************************************************************************************    
** Author  :       
** Description :           
** Date   :    
**************************************************************************************************    
** Change History           
**************************************************************************************************    
** SNo   Date        Author                     Description           
** --    --------   -------                     -------------------------           
 ** 1    27/12/2018  Santhana K					Changed the Varchar(max) Data type to Varchar(max)
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spAddDeliverableVersionHFCN]
 (
  @RootID as int,
  @Version as varchar(20),
  @VendorID as int,
  @VendorVersion as varchar(30),
  @DeveloperID as int,
  @HFCNNotify as varchar(255),
  @HFCNLocation as varchar(1000),
  @OtherDependencies as varchar(3000),
  @Changes as Varchar(max),
  @Title as Varchar(max),
  @NewID int output
 )
 AS
DECLARE @TargetCount as int
DECLARE @ImagePath as varchar(2000)
DECLARE @DeliverableName as varchar(120)
Select @DeliverableName = Name 
from DeliverableRoot with (NOLOCK)
where id = @RootID
if left(@HFCNLocation,2) = '\\' 
	SELECT @ImagePath = @HFCNLocation
else
	SELECT @ImagePath = ''
Insert DeliverableVersion(DeliverableName, SSMCompliant,Preinstall, Rompaq, CDImage, CAB,Binary,FloppyDisk,PreinstallROM,Admin,Desktops,Notebooks,Workstations,ThinClients,Monitors,Projectors,Handhelds,Printers,PersonalAudio,Scriptpaq,HFCNLocation, HFCNNotify, latest,DeliverableRootID,Version,Revision,Pass,Status,Location,VendorVersion,VendorID,OtherDependencies,DeveloperID,ImagePath,InitialPath,Changes,Comments,ActualReleaseDate)
Values(@DeliverableName,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,@HFCNLocation,@HFCNNotify,1,@RootID,@Version,'','',2,'',@VendorVersion,@VendorID,@OtherDependencies,@DeveloperID,@ImagePath,@ImagePath, @Changes,@Title,Getdate());
Select @NewID = SCOPE_IDENTITY() 
SELECT @TargetCount = (SELECT Count(*)
 FROM DeliverableVersion dv with (NOLOCK), Product_Deliverable pd with (NOLOCK)
 WHERE dv.ID = pd.DeliverableVersionID
 AND dv.DeliverableRootID = (SELECT DeliverableRootID FROM Deliverableversion with (NOLOCK) where ID = @NewID)
 AND dv.id <> @NewID
 AND pd.Targeted = -1)
if @TargetCount > 0
	Update Product_Deliverable
	SET AlertID=3,NewDelVersionID = @NewID
	WHERE Product_Deliverable.ID IN 
	 (SELECT pd.ID
	 FROM DeliverableVersion dv with (NOLOCK), Product_Deliverable pd with (NOLOCK)
	 WHERE dv.ID = pd.DeliverableVersionID
	 AND dv.DeliverableRootID = (SELECT DeliverableRootID FROM Deliverableversion with (NOLOCK) where ID = @NewID)
	 AND dv.id <> @NewID
	 AND pd.Targeted = -1)


GO



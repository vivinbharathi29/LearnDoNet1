﻿

CREATE PROCEDURE [dbo].[spGetProdIssuesList]
(
 @ProdID int,
 @TypeID tinyint,
 @StatusID tinyint
)
 AS
if @TypeID = 0 and @StatusID = 0 
 	SELECT i.ID,e.name as Owner,i.type,i.description,i.TargetDate,i.ActualDate,i.Status,'<Product Issue>' as Deliverable,i.Created,Submitter, i.Summary
	 FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK)
	 WHERE i.ProductVersionID = @ProdID
	 AND i.OwnerID = e.id
	 ORDER By i.Created
else
	 BEGIN
	 if @TypeID = 0
		  SELECT i.ID,e.name as Owner,i.type,i.description,i.TargetDate,i.ActualDate,i.Status,'<Product Issue>' as Deliverable,i.Created,Submitter, i.Summary
		  FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK)
		  WHERE i.ProductVersionID = @ProdID
		  AND i.OwnerID = e.id
		  AND i.Status = @StatusID
		  ORDER By i.Created
	 else
		if @StatusID = 0
			SELECT i.ID,e.name as Owner,i.type,i.description,i.TargetDate,i.ActualDate,i.Status,'<Product Issue>' as Deliverable,i.Created,Submitter, i.Summary
			FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK)
			WHERE i.ProductVersionID = @ProdID
			AND i.OwnerID = e.id
			AND i.Type = @TypeID
			ORDER By i.Created
  		else
 
		  	SELECT i.ID,e.name as Owner,i.type,i.description,i.TargetDate,i.ActualDate,i.Status,'<Product Issue>' as Deliverable,i.Created,Submitter, i.Summary
			FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK)
			WHERE i.ProductVersionID = @ProdID
			AND i.OwnerID = e.id
			AND i.Type = @TypeID
			AND i.Status = @StatusID
			ORDER By i.Created
	 END
/*
ALTER PROCEDURE spGetProdIssuesList
(
 @ProdID int,
 @TypeID tinyint,
 @StatusID tinyint
)
 AS
if @TypeID = 0 and @StatusID = 0
 BEGIN
 
 SELECT Distinct i.ID, e.Name as Owner,i.type,i.description,i.TargetDate , i.ActualDate, i.Status, r.Name as Deliverable,i.Created,Submitter, '' as Summary
 FROM DeliverableIssues i WITH (NOLOCK),Employee e WITH (NOLOCK), Deliverableroot r WITH (NOLOCK), ProdReq_delroot pd WITH (NOLOCK), Product_Requirement pr WITH (NOLOCK)
 WHERE i.OwnerID = e.ID 
 AND r.ID = i.deliverablerootid
 AND pd.DeliverableRootID = i.DeliverableRootID
 AND pd.ProductRequirementID = pr.ID
 AND pr.ProductID = @Prodid
 Union
 SELECT i.ID,e.name as Owner,i.type,i.description,i.TargetDate,i.ActualDate,i.Status,'<Product Issue>' as Deliverable,i.Created,Submitter, i.Summary
 FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK)
 WHERE i.ProductVersionID = @ProdID
 AND i.OwnerID = e.id
 ORDER By i.Created
 END
else
 BEGIN
 if @TypeID = 0
  SELECT distinct i.ID, e.Name as Owner,i.type,i.description,i.TargetDate , i.ActualDate, i.Status, r.Name as Deliverable,i.Created,Submitter, '' as Summary
  FROM DeliverableIssues i WITH (NOLOCK),Employee e WITH (NOLOCK), Deliverableroot r WITH (NOLOCK),  ProdReq_delroot pd WITH (NOLOCK), Product_Requirement pr WITH (NOLOCK)
  WHERE i.OwnerID = e.ID 
  AND r.ID = i.deliverablerootid
  AND pd.DeliverableRootID = i.DeliverableRootID
 AND pr.ProductID = @Prodid
  AND pd.ProductRequirementID = pr.ID
  AND i.Status = @StatusID
 
 Union
 
  SELECT i.ID,e.name as Owner,i.type,i.description,i.TargetDate,i.ActualDate,i.Status,'<Product Issue>' as Deliverable,i.Created,Submitter, i.Summary
  FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK)
  WHERE i.ProductVersionID = @ProdID
  AND i.OwnerID = e.id
  AND i.Status = @StatusID
  ORDER By i.Created
 else
  if @StatusID = 0
   SELECT distinct i.ID, e.Name as Owner,i.type,i.description,i.TargetDate , i.ActualDate, i.Status, r.Name as Deliverable,i.Created,Submitter, '' as Summary
   FROM DeliverableIssues i WITH (NOLOCK),Employee e WITH (NOLOCK), Deliverableroot r WITH (NOLOCK),  ProdReq_delroot pd WITH (NOLOCK), Product_Requirement pr WITH (NOLOCK)
   WHERE i.OwnerID = e.ID 
   AND r.ID = i.deliverablerootid
   AND pd.DeliverableRootID = i.DeliverableRootID
   AND pr.ProductID = @Prodid
   AND pd.ProductRequirementID = pr.ID
   AND i.Type = @TypeID
   Union
 
   SELECT i.ID,e.name as Owner,i.type,i.description,i.TargetDate,i.ActualDate,i.Status,'<Product Issue>' as Deliverable,i.Created,Submitter, i.Summary
   FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK)
   WHERE i.ProductVersionID = @ProdID
   AND i.OwnerID = e.id
   AND i.Type = @TypeID
   ORDER By i.Created
  else
   SELECT distinct i.ID, e.Name as Owner,i.type,i.description,i.TargetDate , i.ActualDate, i.Status, r.Name as Deliverable,i.Created,Submitter, '' as Summary
   FROM DeliverableIssues i WITH (NOLOCK),Employee e WITH (NOLOCK), Deliverableroot r WITH (NOLOCK),  ProdReq_delroot pd WITH (NOLOCK), Product_Requirement pr WITH (NOLOCK)
   WHERE i.OwnerID = e.ID 
   AND r.ID = i.deliverablerootid
   AND pd.DeliverableRootID = i.DeliverableRootID
   AND pr.ProductID = @Prodid
   AND pd.ProductRequirementID = pr.ID
   AND i.Type = @TypeID
   AND i.Status = @StatusID
   Union
 
   SELECT i.ID,e.name as Owner,i.type,i.description,i.TargetDate,i.ActualDate,i.Status,'<Product Issue>' as Deliverable,i.Created,Submitter, i.Summary
   FROM DeliverableIssues i WITH (NOLOCK), Employee e WITH (NOLOCK)
   WHERE i.ProductVersionID = @ProdID
   AND i.OwnerID = e.id
   AND i.Type = @TypeID
   AND i.Status = @StatusID
   ORDER By i.Created
 END
*/


﻿/**************************************************************************************************
 * Purpose:	get IRS Module Information
 * Created By:	
 * Modified by: 09/26/2016 linshant, Check the GPG Description is consistent with IRS in different product brand but same kmat
				12/29/2016 linshant, make GPGDescription of Localized AV in pulsar consistent with IRS, bug 30826
 **************************************************************************************************/
CREATE PROCEDURE [dbo].[spFusion_MODULE_SyncIDNumbers]
(
    @p_PBID INT = 0
)
AS
	SET ARITHABORT ON

	--House Keeping

	--Make Sure AVs that should have parents do before we start creating modules.

	DECLARE @AvDetailId INT, @pb_Kmat varchar(10)
	SELECT @pb_Kmat = KMAT from Product_Brand where ID = @p_PBID

	IF @p_PBID = 0
	  BEGIN
		declare avcur cursor for
		select AvDetailID from avdetail WITH (NOLOCK) where charindex('#', avno) > 1 and ParentId is null
	  END
	ELSE
	  BEGIN
		declare avcur cursor for
		select avdetail.AvDetailID from avdetail WITH (NOLOCK) 
		inner join avdetail_productbrand WITH (NOLOCK) on avdetail.avdetailid = avdetail_productbrand.avdetailid
		inner join product_brand pb WITH (NOLOCK) on avdetail_productbrand.productbrandid = pb.id 
		where charindex('#', avno) > 1 and ParentId is null and pb.KMAT = @pb_Kmat
	  END

	open avcur

	fetch next from avcur into @avdetailid

	While @@FETCH_STATUS = 0 BEGIN

	EXEC	usp_AvDetailSetAvParentId @avDetailId

	fetch next from avcur into @avdetailid
	END

	close avcur
	deallocate avcur

---
--- Set IrsModuleId to 0 if we can't find it in IRS or the Description has changed
---
	IF @p_PBID = 0
	  BEGIN
		UPDATE AvDetail
		SET IRSModuleId = 0
		FROM IRS_Module m WITH (NOLOCK) INNER JOIN AvDetail av WITH (NOLOCK) ON m.ModuleId = av.IRSModuleId
		WHERE av.GPGDescription != m.Description
	  END
	ELSE
	  BEGIN
		UPDATE AvDetail
		SET IRSModuleId = 0
		FROM AvDetail av WITH (NOLOCK) INNER JOIN AvDetail_ProductBrand avpb WITH (NOLOCK) ON av.AvDetailID = avpb.AvDetailID 
		INNER JOIN Product_Brand pb WITH (NOLOCK) ON avpb.ProductBrandID = pb.ID
		LEFT OUTER JOIN IRS_Module m WITH (NOLOCK) ON av.IRSModuleId = m.ModuleId
		WHERE m.ModuleId IS NULL
		AND ISNULL(av.IRSModuleId, 0) != 0
		AND pb.KMAT = @pb_Kmat

		----for localizedAV
		UPDATE AvDetail
		SET IRSModuleId = 0
		From AvDetail parent WITH (NOLOCK)
		LEFT OUTER JOIN IRS_Module m WITH (NOLOCK) ON parent.IRSModuleId = m.ModuleId
		WHERE ((m.ModuleId IS NULL AND ISNULL(parent.IRSModuleId, 0) != 0) or (parent.GPGDescription != m.Description))
		AND parent.avdetailid in 
			(    SELECT child.parentid from AvDetail child WITH (NOLOCK) 
		     INNER JOIN AvDetail_ProductBrand avpb WITH (NOLOCK) ON child.AvDetailID = avpb.AvDetailID 
			 INNER JOIN Product_Brand pb WITH (NOLOCK) ON avpb.ProductBrandID = pb.ID
		          WHERE pb.KMAT = @pb_Kmat AND charindex('#',child.avno) > 0 and isnull(child.featurecategoryid,0) > 0 )
	  END


	--Send all AVDetail records identified as modules to IRS if they are not already there
	--If there is any id mismatch, resend it and let the add function fix it.
	Declare @ExcaliburID int
	Declare @GPGDescription varchar(100)
	IF @p_PBID = 0
	  BEGIN
		DECLARE IRSDB1_CURSOR CURSOR FOR 
		SELECT DISTINCT d.AvDetailID, GPGDescription
		FROM AvDetail d WITH (NOLOCK) 
		INNER JOIN AvFeatureCategory c WITH (NOLOCK) ON d.FeatureCategoryID = c.AvFeatureCategoryID 
		INNER JOIN AvDetail_ProductBrand db WITH (NOLOCK) ON db.AvDetailID = d.AvDetailID 
		INNER JOIN Product_Brand pb WITH (NOLOCK) ON pb.id = db.ProductBrandID 
		INNER JOIN ProductVersion p WITH (NOLOCK) ON p.ID = pb.ProductVersionID
		WHERE db.Status in ('A','O')
		AND c.AvFeatureCategoryID NOT IN (1,86)
		AND ISNULL(d.ParentId, 0) = 0
		AND ((p.Fusion = 1 OR p.ID IN (1145,1176, 1164, 1155, 1092, 1147, 1101, 1152, 1090,1197)) OR p.ProductStatusId < 4)
		AND c.IRSModuleAbbreviation is not null
		AND d.AvNo IS NOT NULL
		AND ISNULL(c.IrsModuleCategoryId,0) <> 0
		AND CHARINDEX('#', d.avno) = 0
		AND d.AvDetailID not in (
				SELECT DISTINCT e.avdetailID 
				FROM IRS_module m WITH (NOLOCK) 
				INNER JOIN IRS_SRP_Option o WITH (NOLOCK) ON o.moduleid = m.moduleid 
				INNER JOIN AVDetail e WITH (NOLOCK) ON m.moduleid = e.IRSModuleID									
				where left(coalesce(e.GPGDescription,''),40) = o.shortdescription	
				--and m.statusid = (select statusid from IRS_Status where StatusType=8 and constant='MOL_MODULE_ACTIVE')
			)
		--GROUP BY d.GPGDescription
											
		UNION ALL
									
		SELECT DISTINCT d.AvDetailID, d.GPGDescription
		FROM AvDetail d WITH (NOLOCK) 
		INNER JOIN AvDetail dc WITH (NOLOCK) ON d.AvDetailID = dc.ParentId 
		INNER JOIN AvFeatureCategory c WITH (NOLOCK) ON d.FeatureCategoryID = c.AvFeatureCategoryID 
		INNER JOIN AvDetail_ProductBrand db WITH (NOLOCK) ON db.AvDetailID = dc.AvDetailID 
		INNER JOIN Product_Brand pb WITH (NOLOCK) ON pb.id = db.ProductBrandID 
		INNER JOIN ProductVersion p WITH (NOLOCK) ON p.ID = pb.ProductVersionID
		WHERE db.Status IN ('A','O')
		AND c.AvFeatureCategoryID NOT IN (1,86)
		AND ((p.Fusion = 1 OR p.ID IN (1145,1176, 1164, 1155, 1092, 1147, 1101, 1152, 1090,1197)) OR p.ProductStatusId < 4)
		AND c.IRSModuleAbbreviation IS NOT NULL
		AND d.AvNo IS NOT NULL
		AND ISNULL(c.IrsModuleCategoryId,0) <> 0
		AND CHARINDEX('#', dc.AvNo) > 0
		AND ISNULL(d.IRSModuleID,0) = 0
		AND d.AvDetailID NOT IN (
			SELECT DISTINCT e.avdetailID 
			FROM IRS_module m WITH (NOLOCK) 
			INNER JOIN IRS_SRP_Option o WITH (NOLOCK) ON o.moduleid = m.moduleid 
			INNER JOIN AVDetail e WITH (NOLOCK) ON m.moduleid = e.IRSModuleID									
			WHERE LEFT(ISNULL(e.GPGDescription,''),40) = o.shortdescription	
			--and m.statusid = (select statusid from IRS_Status where StatusType=8 and constant='MOL_MODULE_ACTIVE')
			)
		--group by d.GPGDescription
	  END
	ELSE
	  BEGIN
	    DECLARE IRSDB1_CURSOR CURSOR FOR 
		SELECT DISTINCT d.AvDetailID, GPGDescription
		FROM AvDetail d WITH (NOLOCK) 
		INNER JOIN AvFeatureCategory c WITH (NOLOCK) ON d.FeatureCategoryID = c.AvFeatureCategoryID 
		INNER JOIN AvDetail_ProductBrand db WITH (NOLOCK) ON db.AvDetailID = d.AvDetailID 
		INNER JOIN Product_Brand pb WITH (NOLOCK) ON pb.id = db.ProductBrandID 
		INNER JOIN ProductVersion p WITH (NOLOCK) ON p.ID = pb.ProductVersionID
		WHERE db.Status in ('A','O')
		AND c.AvFeatureCategoryID NOT IN (1,86)
		AND ISNULL(d.ParentId, 0) = 0
		AND ((p.Fusion = 1 OR p.ID IN (1145,1176, 1164, 1155, 1092, 1147, 1101, 1152, 1090,1197)) OR p.ProductStatusId < 4)
		AND c.IRSModuleAbbreviation is not null
		AND d.AvNo IS NOT NULL
		AND ISNULL(c.IrsModuleCategoryId,0) <> 0
		AND CHARINDEX('#', d.avno) = 0
		AND d.AvDetailID not in (
				SELECT DISTINCT e.avdetailID 
				FROM IRS_module m WITH (NOLOCK) 
				INNER JOIN IRS_SRP_Option o WITH (NOLOCK) ON o.moduleid = m.moduleid 
				INNER JOIN AVDetail e WITH (NOLOCK) ON m.moduleid = e.IRSModuleID									
				where left(coalesce(e.GPGDescription,''),40) = o.shortdescription	
				--and m.statusid = (select statusid from IRS_Status where StatusType=8 and constant='MOL_MODULE_ACTIVE')
			)
		AND pb.KMAT = @pb_Kmat
		--GROUP BY d.GPGDescription
											
		UNION ALL
									
		SELECT DISTINCT d.AvDetailID, d.GPGDescription
		FROM AvDetail d WITH (NOLOCK) 
		INNER JOIN AvDetail dc WITH (NOLOCK) ON d.AvDetailID = dc.ParentId 
		INNER JOIN AvFeatureCategory c WITH (NOLOCK) ON d.FeatureCategoryID = c.AvFeatureCategoryID 
		INNER JOIN AvDetail_ProductBrand db WITH (NOLOCK) ON db.AvDetailID = dc.AvDetailID 
		INNER JOIN Product_Brand pb WITH (NOLOCK) ON pb.id = db.ProductBrandID 
		INNER JOIN ProductVersion p WITH (NOLOCK) ON p.ID = pb.ProductVersionID
		WHERE db.Status IN ('A','O')
		AND c.AvFeatureCategoryID NOT IN (1,86)
		AND ((p.Fusion = 1 OR p.ID IN (1145,1176, 1164, 1155, 1092, 1147, 1101, 1152, 1090,1197)) OR p.ProductStatusId < 4)
		AND c.IRSModuleAbbreviation IS NOT NULL
		AND d.AvNo IS NOT NULL
		AND ISNULL(c.IrsModuleCategoryId,0) <> 0
		AND CHARINDEX('#', dc.AvNo) > 0
		AND ISNULL(d.IRSModuleID,0) = 0
		AND d.AvDetailID NOT IN (
			SELECT DISTINCT e.avdetailID 
			FROM IRS_module m WITH (NOLOCK) 
			INNER JOIN IRS_SRP_Option o WITH (NOLOCK) ON o.moduleid = m.moduleid 
			INNER JOIN AVDetail e WITH (NOLOCK) ON m.moduleid = e.IRSModuleID									
			WHERE LEFT(ISNULL(e.GPGDescription,''),40) = o.shortdescription	
			--and m.statusid = (select statusid from IRS_Status where StatusType=8 and constant='MOL_MODULE_ACTIVE')
			)
		--group by d.GPGDescription
		AND pb.KMAT = @pb_Kmat
	  END
					
	open IRSDB1_CURSOR
					
	FETCH NEXT FROM IRSDB1_CURSOR Into @ExcaliburID, @GPGDescription
	WHILE (@@fetch_status <> -1)
		BEGIN
			If (@@fetch_status <> -2)
				BEGIN
					exec dbo.spFusion_MODULE_AddModuletoIRS @ExcaliburID ,31
				END
			FETCH NEXT FROM IRSDB1_CURSOR Into @ExcaliburID, @GPGDescription
		END
	DEALLOCATE IRSDB1_CURSOR	

GO


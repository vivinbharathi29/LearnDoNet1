﻿

CREATE PROCEDURE [dbo].[spGetSelectedDepends]
 (
  @ID as int
 )
 AS
SELECT dd.DependsID as ID,dr.Name as Name, dv.version as Version, dv.revision as Revision, dv.pass as Pass
FROM Depends_DelVer dd with (NOLOCK), DeliverableVersion dv with (NOLOCK), DeliverableRoot dr with (NOLOCK)
Where dd.DependsId = dv.id
AND dv.deliverablerootid = dr.id
AND DeliverableVersionID = @ID

Union 

SELECT dd.Deliverableversionid as ID,dr.Name as Name, dv.version as Version, dv.revision as Revision, dv.pass as Pass
FROM Depends_DelVer dd with (NOLOCK), DeliverableVersion dv with (NOLOCK), DeliverableRoot dr with (NOLOCK)
Where dd.DeliverableversionId = dv.id
AND dv.deliverablerootid = dr.id
AND DependsID = @ID

order by name,version desc, revision desc, pass desc







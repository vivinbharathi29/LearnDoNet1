﻿

CREATE PROCEDURE [dbo].[spGetTestLeadsAll]
(
	@SE bit=1,
	@WWAN bit=1,
	@ODM bit=1
)
AS

	Select Distinct e.id, e.name, e.email, 'SE Test Lead' as Role, e.partnerid
	from productversion v WITH (NOLOCK) INNER JOIN employee e  WITH (NOLOCK) ON e.ID = v.SETestLead
	where @SE=1

	Union

	Select Distinct e.id, e.name, e.email, 'ODM Test Lead' as Role, e.partnerid
	from productversion v WITH (NOLOCK) INNER JOIN employee e  WITH (NOLOCK) ON e.ID = v.ODMTestLeadID
	where @ODM=1
	
	Union

	Select Distinct e.id, e.name, e.email, 'WWAN Test Lead' as Role, e.partnerid
	from productversion v WITH (NOLOCK) INNER JOIN employee e  WITH (NOLOCK) ON e.ID = v.WWANTestLeadID
	where @WWAN=1

	order by role



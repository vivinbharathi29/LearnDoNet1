﻿

CREATE PROCEDURE [dbo].[spLinkLanguage2Version]
 (
  @LanguageID int,
  @DeliverableVersionID int,
  @MilestoneID int,
  @WorkflowComplete tinyint =0, 
  @PartNumber varchar(100),
  @CDPartNumber varchar(71),
  @CDKitNumber varchar(71),
  @SoftpaqNumber varchar(10),
  @Supersedes varchar(2048)
 )
 AS
Insert Language_DelVer (Languageid,DeliverableVersionId,MilestoneID,WorkflowComplete,PartNumber,CDPartNumber, CDKitNumber, SoftpaqNumber,Supersedes,Failed)
Values (@LanguageID,  @DeliverableVersionID, @MilestoneID, @WorkflowComplete,@PartNumber,@CDPartNumber, @CDKitNumber, @SoftpaqNumber,@Supersedes,0)



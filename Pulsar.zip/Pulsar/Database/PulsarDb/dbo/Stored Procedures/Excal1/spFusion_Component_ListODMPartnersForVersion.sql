﻿
CREATE PROCEDURE spFusion_Component_ListODMPartnersForVersion
(
	@VersionID int,
	@UserID int,
	@Result varchar(max) output
)

AS


	Declare @PartnerID int
	Declare @strOutput as varchar(max)
	Select @strOutput = ''
	DECLARE IRSGetVersionOwnerODM_CURSOR CURSOR FOR 	Select p.IRSGroupID
														from employee e WITH (NOLOCK), partner p WITH (NOLOCK)
														where e.partnerid = p.id
														and e.id = @UserID
														and p.irsgroupid <> 0

														union

														Select p.IRSGroupID
														from deliverableversion v WITH (NOLOCK), deliverableroot r WITH (NOLOCK), employee e WITH (NOLOCK), partner p WITH (NOLOCK)
														where r.id = v.deliverablerootid
														and e.id = r.devmanagerid
														and p.id = e.PartnerID
														and v.id = @VersionID
														and p.irsgroupid <> 0

														union

														Select p.IRSGroupID
														from deliverableversion v WITH (NOLOCK), deliverableroot r WITH (NOLOCK), employee e WITH (NOLOCK), partner p WITH (NOLOCK)
														where r.id = v.deliverablerootid
														and e.id = r.testerid
														and p.id = e.PartnerID
														and v.id = @VersionID
														and p.irsgroupid <> 0

														union

														Select p.IRSGroupID
														from deliverableversion v WITH (NOLOCK), employee e WITH (NOLOCK) , partner p WITH (NOLOCK)
														where e.id = v.developerid
														and p.id = e.PartnerID
														and v.id = @VersionID
														and p.irsgroupid <> 0

		
	open IRSGetVersionOwnerODM_CURSOR
	
	FETCH NEXT FROM IRSGetVersionOwnerODM_CURSOR Into @PartnerID
	WHILE (@@fetch_status <> -1)
		BEGIN
			If (@@fetch_status <> -2)
				BEGIN
					Select @strOutput = @strOutput + '<EditPermission GroupID="' + cast(@PartnerID as varchar(max)) + '" />' + CHAR(13) + CHAR(10)
				END
			FETCH NEXT FROM IRSGetVersionOwnerODM_CURSOR Into @PartnerID
		END
	DEALLOCATE IRSGetVersionOwnerODM_CURSOR

	Select @Result= @strOutput

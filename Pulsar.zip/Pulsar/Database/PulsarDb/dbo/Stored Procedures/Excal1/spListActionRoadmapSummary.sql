﻿

CREATE PROCEDURE [dbo].[spListActionRoadmapSummary]
(
	@ProductID int
)
 AS

Select r.ID, r.displayorder, s.name as Status, r.Timeframe, e.name as Owner, r.Notes, r.Summary, Count(a.ID) as Tasks
 from 
	ActionRoadmap r WITH (NOLOCK)
	INNER JOIN ActionStatus s WITH (NOLOCK) ON r.ActionStatusID = s.ID
	LEFT OUTER JOIN DeliverableIssues a WITH (NOLOCK) ON a.ActionRoadmapID = r.ID
	LEFT OUTER JOIN employee e WITH (NOLOCK) ON e.id = r.OwnerID
where r.ActionStatusID in (1,7)
and r.productversionid = @ProductID
Group By r.ID, r.Summary, r.timeframe,e.name, r.notes, r.DisplayOrder, s.name
order by r.DisplayOrder


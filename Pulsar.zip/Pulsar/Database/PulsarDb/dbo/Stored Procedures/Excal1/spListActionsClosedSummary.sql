﻿

CREATE PROCEDURE [dbo].[spListActionsClosedSummary]

(
	@ProdID int,
	@Type int,
	@StartDate datetime, 
	@EndDate datetime
)

 AS

Select Summary, Description, Resolution
from deliverableissues with (NOLOCK)
where productversionid = @ProdID
and status=2
and type=coalesce(@Type,type)
and ActualDate between @StartDate and @EndDate
order by ActualDate



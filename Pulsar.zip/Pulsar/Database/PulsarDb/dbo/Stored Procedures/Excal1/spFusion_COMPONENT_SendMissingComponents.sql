﻿-- ===============================================================
-- Update: Added WITH keyword to (NOLOCK) - Paul Sanchez 3/11/2014
-- ===============================================================
CREATE PROCEDURE [dbo].[spFusion_COMPONENT_SendMissingComponents]
(
	@ProductID int,
	@SingleVersionID int = null
)
AS


	Declare @VersionID int
	
	DECLARE IRSCompSync_CURSOR CURSOR LOCAL FAST_FORWARD
			FOR Select v.id
				from DeliverableVersion v WITH (nolock) inner join
						Product_Deliverable pd WITH (nolock) on pd.DeliverableVersionID = v.ID inner join
						DeliverableRoot r WITH (nolock) on r.ID = v.DeliverableRootID inner join
						ProductVersion p WITH (nolock) on p.id = pd.productversionid
				where coalesce(v.irsid,0)=0 --Not already sent to IRS
				and (p.fusion=1 or p.id=1145 or p.id=1176 or p.id=1164 or p.id=1155 or p.id=1092 or p.id=1147 or p.id=1101 or p.id=1152 or p.id=1090 or p.id=1197) --converged product
				and pd.ProductVersionID = @ProductID -- Version is supported on selected product
				and (pd.PreInstall=1 or pd.Preload=1 or pd.selectiverestore=1) -- version is set to Preistall, Preload, or Selective restore for selected product
				and r.CategoryID not in(168,169,170,171,143,179, 137, 235) -- don't send these categories
				and targeted=1  --Targeted on this product or the "Always Transfer" bit is checked in the root or not in Developement
				and r.IRSTransfers <> 0 -- Transfer to IRS enable in Root
				and v.Status not in (1, 5) --not failed in a workflow step
				and r.TypeID <> 1 -- Not hardware

				union

				Select v.id
				from DeliverableVersion v WITH (nolock) inner join
						Product_Deliverable pd WITH (nolock) on pd.DeliverableVersionID = v.ID inner join
						DeliverableRoot r WITH (nolock) on r.ID = v.DeliverableRootID inner join
						ProductVersion p WITH (nolock) on p.id = pd.productversionid
				where coalesce(v.irsid,0)=0 --Not already sent to IRS
				and (p.fusion=1 or p.id=1145 or p.id=1176 or p.id=1164 or p.id=1155 or p.id=1092 or p.id=1147 or p.id=1101 or p.id=1152 or p.id=1090 or p.id=1197) --converged product
				and pd.ProductVersionID = @ProductID -- Version is supported on selected product
				and r.IRSTransfers=1  --"Always Transfer" bit is checked in the root
				and r.TypeID <> 1 -- Not hardware
				and v.Status not in (1, 5) --not failed in a workflow step
												
												
				union 
												
				-- Include versions with "Supports Desktops" box checked
				Select v.ID
				from DeliverableVersion v WITH (nolock) join
						DeliverableRoot r WITH (nolock) on r.ID = v.DeliverableRootID
				where coalesce(v.irsid,0)=0 --Not already sent to IRS
				and r.IRSTransfers <> 0 --Transfer to IRS enable in Root
				and v.Status not in (1,5)  -- Version not in Development and not Failed in a workflow step
				and (v.Desktops=1 or r.CategoryID = 248 or v.irsfilescopied=7) --Desktop bit is checked in version or Transfer Requested
				and r.TypeID <> 1 -- Not hardware
				and r.CategoryID not in(168,169,170,171,143,179, 137,235) -- don't send these categories
				and (v.preinstall = 1 or v.preinstallrom=1 )
				and v.id = coalesce(@SingleVersionID,v.id)
				order by v.id
	
		
	open IRSCompSync_CURSOR
	
	FETCH NEXT FROM IRSCompSync_CURSOR Into @VersionID
	WHILE (@@fetch_status <> -1)
		BEGIN
			If (@@fetch_status <> -2)
				BEGIN
					exec dbo.spFusion_COMPONENT_AddComponent @Versionid
				END
			FETCH NEXT FROM IRSCompSync_CURSOR Into @VersionID
		END
	DEALLOCATE IRSCompSync_CURSOR


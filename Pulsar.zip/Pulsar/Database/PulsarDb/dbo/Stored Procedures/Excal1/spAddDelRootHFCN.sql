﻿

CREATE PROCEDURE [dbo].[spAddDelRootHFCN]
 (
  @Name varchar(120),
  @CategoryID int,
  @DevManagerID int,
  @NewID int OUTPUT
 )
 AS
DECLARE @TypeID int
Select @TypeID = DeliverableTypeID FROM DeliverableCategory with (NOLOCK) Where Id = @CategoryID

 Insert DeliverableRoot  (MultiLanguage,Softpaq,DefaultUI,LangSubs, CertRequired,MasterIDRequired,Preinstalled,LeadEngineerID,InstallationOrder,Install, SilentInstall, BlindInstall, ARCDInstall, Uninstall, InstallRecover, Timeout, Reboot, Preinstall, Rompaq, CDImage, CAB,ScriptPaq, Binary, FloppyDisk, PreinstallROM, LoggedIn, SysComponents, RootFilename, TargetPartition, PackageType, OSType, EnduserInstructions, SilentInstructions, BlindInstructions, UninstallInstructions, MSBatchInstructions, NTDSInstructions,SWTypeID,Name, Description, BasePartNumber, TypeID, VendorID, WorkflowID, CategoryID, DevManagerID,TesterID,Notes,OtherDependencies,PNPDevices,Admin,SysReboot)
 Values(1,0,'N/A', 0, 0,0,0,0,0,'', '', '', '', '', '', '', 0, 0, 0, 0, 0,0,0, 0, 0, 0, 0,'HFCN', '', '', '', '', '', '', '','', '',0,@Name, 'HFCN Deliverable', '', @TypeID, 203,7, @CategoryID,@DevManagerID,0,'', '','',0,0)
 Select @NewID = SCOPE_IDENTITY()

/*
 Insert DeliverableRoot  (MultiLanguage,Softpaq,DefaultUI,Kit,LangSubs, CertRequired,NextPNRev,OnDOTSheet,MasterIDRequired,Preinstalled,LeadEngineerID,InstallationOrder,Install, SilentInstall, BlindInstall, ARCDInstall, Uninstall, InstallRecover, Timeout, Reboot, Preinstall, Rompaq, CDImage, CAB,ScriptPaq, Binary, FloppyDisk, PreinstallROM, LoggedIn, SysComponents, RootFilename, TargetPartition, PackageType, OSType, EnduserInstructions, SilentInstructions, BlindInstructions, UninstallInstructions, MSBatchInstructions, NTDSInstructions,SWTypeID,Name, Description, BasePartNumber, TypeID, VendorID, WorkflowID, CategoryID, DevManagerID,TesterID,Notes,OtherDependencies,PNPDevices,Admin,SysReboot)
 Values(1,0,'N/A',1, 0, 0,1,0,0,0,0,0,'', '', '', '', '', '', '', 0, 0, 0, 0, 0,0,0, 0, 0, 0, 0,'HFCN', '', '', '', '', '', '', '','', '',0,@Name, 'HFCN Deliverable', '', @TypeID, 203,7, @CategoryID,@DevManagerID,0,'', '','',0,0)
 Select @NewID = SCOPE_IDENTITY()
 */



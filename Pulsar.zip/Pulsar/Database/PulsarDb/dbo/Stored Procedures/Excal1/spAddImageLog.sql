﻿

CREATE PROCEDURE [dbo].[spAddImageLog]
(
	@EmployeeID int,
	@DCRID int,
	@ImageID int,
	@Details varchar(7500)
)
AS
Insert ImageChanges (EmployeeID,DCRID,ImageID,Details)
Values(@EmployeeID,@DCRID,@ImageID,@Details)




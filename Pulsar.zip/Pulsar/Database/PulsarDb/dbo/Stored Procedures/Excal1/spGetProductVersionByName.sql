﻿



CREATE PROCEDURE [dbo].[spGetProductVersionByName]
(@Product varchar(255))
AS SELECT     v.ID,v.BaseUnit, v.CurrentROM, v.OSSupport, v.ImagePO, v.ImageChanges, v.SystemBoardID, v.MachinePNPID, v.CommonImages, v.CertificationStatus, v.PartnerID,
                      v.SWQAStatus, v.PlatformStatus, v.Active, v.EmailActive, v.Approver, v.SEPMID, v.Division, v.productName as name, v.Version, v.ProductFamilyID, 
                      e.Name AS PMName, v.PMID, v.Distribution, v.ID, v.PDDReleased, v.PRDReleased, v.DOTSName, v.Cycle, v.StreetName, v.devcenter, v.Description, v.Objectives, 
                      v.OnlineReports, v.Sustaining, v.Brands,ProductFilePath, PDDPath, v.SEPE, v.PINPM, v.SETestLead, v.SustainingMgrID, v.PreinstallCutoff
FROM         dbo.ProductVersion v with (NOLOCK) INNER JOIN
                      dbo.ProductFamily f with (NOLOCK) ON v.ProductFamilyID = f.ID INNER JOIN
                      dbo.Employee e with (NOLOCK) ON v.PMID = e.ID
WHERE     (v.dotsname = @Product)






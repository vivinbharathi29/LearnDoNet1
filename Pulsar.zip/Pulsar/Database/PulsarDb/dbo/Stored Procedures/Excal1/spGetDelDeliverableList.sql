﻿

CREATE PROCEDURE [dbo].[spGetDelDeliverableList] (@ID int) AS
SELECT r.description,r.Name,v.Version,v.Revision,v.Pass,v.Location,v.VendorVersion,v.PartNumber,v.Languages,e.name as Developer,status, v.ID as ID, '' as Alert, dt.Name as Type, dc.Name as Category, r.ID as delRootID, vd.Name as vendor, v.Active, v.ModelNumber
 FROM DeliverableType dt with (NOLOCK),DeliverableCategory dc with (NOLOCK), DeliverableVersion v with (NOLOCK),DeliverableRoot r with (NOLOCK),Employee e  with (NOLOCK), Vendor vd with (NOLOCK)
WHERE v.DeliverableRootID = r.ID
and vd.ID = v.VendorID
AND e.ID =v.Developerid
AND r.TypeID = dt.ID 
AND r.CategoryID = dc.ID
AND r.ID = @ID
ORDER By r.name,v.releasedate desc, v.version desc, v.revision desc, v.pass desc;




﻿

CREATE PROCEDURE [dbo].[spCorrectImageSummary]
(
	@ProductID int,
	@DeliverableID int, 
	@Scope tinyint
)
AS

	DECLARE @Preinstall bit
	DECLARE @Preload bit
	DECLARE @SelectiveRestore bit
	DECLARE @ARCD bit
	DECLARE @DRDVD bit
	DECLARE @ImageSummary varchar(80)
	DECLARE @Images varchar(8000)
	DECLARE @RootID int

	if @Scope=3 --Root Only
		Begin
			Select @RootID = @DeliverableID 

			Select	@ARCD=ARCD,@DRDVD=DRDVD,@SelectiveRestore=SelectiveRestore,@Preinstall=Preinstall,@Preload=Preload,@ImageSummary=ImageSummary,@Images=Images
			FROM Product_DelRoot with (NOLOCK)
			Where ProductVersionID = @ProductID
			and Deliverablerootid = @RootID

			if (@SelectiveRestore=1 or @ARCD=1 or @DRDVD=1 or @Preinstall=1or @Preload=1)and @ImageSummary='Not Preinstalled' and @Images='0,'
				Update Product_DelRoot
				set ImageSummary = 'ALL', Images=''
				Where ProductVersionID = @ProductID
				and Deliverablerootid = @RootID
			else if (@SelectiveRestore=0 and @ARCD=0 and @DRDVD=0 and @Preinstall=0 and @Preload=0) and (@ImageSummary='ALL' or @ImageSummary='' or @ImageSummary is null) and (@Images='' or @Images is null)
				Update Product_DelRoot
				set ImageSummary = 'Not Preinstalled', Images='0,'
				Where ProductVersionID = @ProductID
				and Deliverablerootid = @RootID

		end
	else
		Begin
		--Update Version if scope = 1 or 2
			Select	@ARCD=ARCD,@DRDVD=DRDVD,@SelectiveRestore=SelectiveRestore,@Preinstall=Preinstall,@Preload=Preload,@ImageSummary=ImageSummary,@Images=Images
			FROM Product_Deliverable with (NOLOCK)
			Where ProductVersionID = @ProductID
			and DeliverableVersionid = @DeliverableID

			if (@SelectiveRestore=1 or @ARCD=1 or @DRDVD=1 or @Preinstall=1 or @Preload=1) and @ImageSummary='Not Preinstalled' and @Images='0,'
				Update Product_Deliverable
				set ImageSummary = 'ALL', Images=''
				Where ProductVersionID = @ProductID
				and DeliverableVersionid = @DeliverableID
			else if (@SelectiveRestore=0 and @ARCD=0 and @DRDVD=0 and @Preinstall=0 and @Preload=0) and (@ImageSummary='ALL' or @ImageSummary='' or @ImageSummary is null) and (@Images='' or @Images is null)
				Update Product_Deliverable
				set ImageSummary = 'Not Preinstalled', Images='0,'
				Where ProductVersionID = @ProductID
				and DeliverableVersionid = @DeliverableID

			if @Scope=2 -- update root for scope 2 only
				Begin
					Select @RootID = DeliverableRootID
					FROM DeliverableVersion with (NOLOCK)
					Where Id = @DeliverableID 

					Select	@ARCD=ARCD,@DRDVD=DRDVD,@SelectiveRestore=SelectiveRestore,@Preinstall=Preinstall,@Preload=Preload,@ImageSummary=ImageSummary,@Images=Images
					FROM Product_DelRoot with (NOLOCK)
					Where ProductVersionID = @ProductID
					and Deliverablerootid = @RootID

					if (@SelectiveRestore=1 or @ARCD=1 or @DRDVD=1 or @Preinstall=1or @Preload=1) and @ImageSummary='Not Preinstalled' and @Images='0,'
						Update Product_DelRoot
						set ImageSummary = 'ALL', Images=''
						Where ProductVersionID = @ProductID
						and Deliverablerootid = @RootID
					else if (@SelectiveRestore=0 and @ARCD=0 and @DRDVD=0 and @Preinstall=0 and @Preload=0) and (@ImageSummary='ALL' or @ImageSummary='' or @ImageSummary is null) and (@Images='' or @Images is null)
						Update Product_DelRoot
						set ImageSummary = 'Not Preinstalled', Images='0,'
						Where ProductVersionID = @ProductID
						and Deliverablerootid = @RootID
				end
			

		end






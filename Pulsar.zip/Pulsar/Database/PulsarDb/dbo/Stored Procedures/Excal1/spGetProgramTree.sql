﻿/*************************************************************************************************
*     Purpose:  spGetProgramTree            
*  Created By:  ?????????? ??????
* Modified By:  Herb Lin 2015/12/10 : 1. display inactive program   2. reverse DisplayOrder  3. add 1 select column: p.active  
**************************************************************************************************/

CREATE PROCEDURE [dbo].[spGetProgramTree]
	@p_ProductGroupIDs VARCHAR(5000) = NULL
AS 

IF (@p_ProductGroupIDs is NOT NULL)
	BEGIN
		Select distinct p.name as Program, v.dotsname as Product, v.id, p.id as programid, p.orderid, p.currentprogram, v.id as ProdID, p.OTSCycleName, g.shortName as ProgramGroup, g.displayorder, g.ID as programGroupID, p.active
		from program p WITH (NOLOCK), productfamily f WITH (NOLOCK), productversion v WITH (NOLOCK), product_program pp WITH (NOLOCK), ProgramGroup g WITH (NOLOCK)
		where v.productfamilyid = f.id
		and g.ID = p.programgroupid
		and pp.productversionid = v.id
		and pp.programid = p.id
		--and p.active=1
		and p.id in (select * from dbo.ufn_Split(@p_ProductGroupIDs, ','))

		Union

		Select p.name as program, '' as Product, id=0, p.id as programid, p.orderid, p.currentprogram,0 as ProdID, p.OTSCycleName,g.shortName as ProgramGroup, g.displayorder, g.ID as programGroupID, p.active
		from Program p WITH (NOLOCK), ProgramGroup g WITH (NOLOCK)
		where p.id not in (Select ProgramID from product_program pp, productversion v where v.id = pp.productversionid)
		and g.ID = p.programgroupid
		--and p.active=1
		and p.id in (select * from dbo.ufn_Split(@p_ProductGroupIDs, ','))

		order by g.displayorder --desc
		, Program
		, Product
	END
ELSE
	BEGIN
		Select distinct p.name as Program, v.dotsname as Product, v.id, p.id as programid, p.orderid, p.currentprogram, v.id as ProdID, p.OTSCycleName, g.shortName as ProgramGroup, g.displayorder, g.ID as programGroupID, p.active
		from program p WITH (NOLOCK), productfamily f WITH (NOLOCK), productversion v WITH (NOLOCK), product_program pp WITH (NOLOCK), ProgramGroup g WITH (NOLOCK)
		where v.productfamilyid = f.id
		and g.ID = p.programgroupid
		and pp.productversionid = v.id
		and pp.programid = p.id
		--and p.active=1

		Union

		Select p.name as program, '' as Product, id=0, p.id as programid, p.orderid, p.currentprogram,0 as ProdID, p.OTSCycleName,g.shortName as ProgramGroup, g.displayorder, g.ID as programGroupID, p.active
		from Program p WITH (NOLOCK), ProgramGroup g WITH (NOLOCK)
		where p.id not in (Select ProgramID from product_program pp, productversion v where v.id = pp.productversionid)
		and g.ID = p.programgroupid
		--and p.active=1

		order by 
		g.displayorder --desc
		, Program
		, Product
	END

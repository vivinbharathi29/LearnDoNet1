﻿
CREATE PROCEDURE [dbo].[spListCommodityPMsAll]
	(
		@Report int = 1
	)
 AS

if @Report=1
	Select ID, Name, Email
	from employee with (NOLOCK)
	where commoditypm=1 or servicepm=1
	order by name
else if @Report=2
	Select ID, Name, Email
	from employee with (NOLOCK)
	where commoditypm=1
	order by name
else if @Report=3

	Select distinct e.id, e.name, e.email
	from ProductVersion v with (NOLOCK) LEFT OUTER JOIN Employee e with (NOLOCK) ON v.ServiceID = e.ID
	where v.productstatusid < 5
	and v.serviceid <> 0
	order by name

--	Select ID, Name, Email
--	from employee
--	where servicepm=1
--	order by name

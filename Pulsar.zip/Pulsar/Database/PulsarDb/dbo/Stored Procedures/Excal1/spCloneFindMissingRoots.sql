﻿
CREATE PROCEDURE [dbo].[spCloneFindMissingRoots]
(
	@SourceID int,
	@TargetID int

)
 AS

Select r.name, pdr.productversionid as ProductID, r.id as ID, max(pr.requirementid) as RequirementID, rq.name as Requirement
from product_delRoot pdr WITH (NOLOCK), deliverableroot r WITH (NOLOCK), product_requirement pr WITH (NOLOCK), prodreq_delRoot prdr WITH (NOLOCK), requirement rq WITH (NOLOCK)
where pdr.productversionid = @SourceID
and r.id = pdr.deliverablerootid
and r.typeid <> 1
--and r.categoryid not in (73,95,107,163,86,134,136,177)
--and r.name not like 'HP 1.x%'
--and r.name not like 'Romeo 1.x%'
--and r.name not like 'Romeo 1x%'
--and r.name not like 'Ronaldo 1.x%'
--and r.name not like 'TG 1.x%'
and rq.id = pr.requirementid
and pr.productid = pdr.productversionid
and pr.id = prdr.productrequirementid
and prdr.deliverablerootid = r.id
and pdr.deliverablerootid not in (Select DeliverableRootID
				from product_delRoot pdr WITH (NOLOCK)
				where pdr.productversionid = @TargetID
				)
and pdr.deliverablerootid in (
	Select v.deliverablerootid
	from product_deliverable pd WITH (NOLOCK), deliverableversion v WITH (NOLOCK)
	where v.id = pd.deliverableversionid
	and pd.targeted=1
	and pd.productversionid = @SourceID
)				
group by rq.name, r.name, pdr.productversionid, r.id
order by rq.name, r.name

/*
Select r.name, pdr.productversionid as ProductID, r.id as ID
from product_delRoot pdr WITH (NOLOCK), deliverableroot r WITH (NOLOCK)
where pdr.productversionid = @SourceID
and r.id = pdr.deliverablerootid
and r.typeid = 2
and pdr.deliverablerootid not in (Select DeliverableRootID
				from product_delRoot pdr WITH (NOLOCK)
				where pdr.productversionid = @TargetID
				)
order by r.name
*/


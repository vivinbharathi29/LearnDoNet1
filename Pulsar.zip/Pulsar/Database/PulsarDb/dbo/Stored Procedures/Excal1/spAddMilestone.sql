﻿

/****** Object:  Stored Procedure dbo.spAddMilestone    Script Date: 9/26/00 7:13:22 PM ******/
CREATE PROCEDURE [dbo].[spAddMilestone]
 (
  @MilestoneID int,
  @ProductID int
 )
As
 Insert Milestone(MilestoneID,ProductVersionID, Active)
 Values (@MilestoneID,@ProductID,1) 
 return 




﻿

CREATE PROCEDURE [dbo].[spGetDeliverableRootName]
 (
  @ID int
 )
 AS
SELECT dr.Name, dr.Typeid, dr.active, dr.Categoryid, dr.DevManagerID, e.Name AS DevManagerName, ShowOnStatus
FROM DeliverableRoot dr with (NOLOCK) LEFT OUTER JOIN Employee e with (NOLOCK) ON e.ID = dr.DevManagerID
Where dr.ID = @ID


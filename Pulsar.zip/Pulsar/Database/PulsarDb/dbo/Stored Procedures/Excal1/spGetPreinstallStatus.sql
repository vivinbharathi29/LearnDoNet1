﻿

CREATE PROCEDURE [dbo].[spGetPreinstallStatus]
(
	@ProdID int,
	@VersionID int
)
AS
Select pd.ID, pd.PreinstallStatus, pd.Urgent, pd.PreinstallNotes, pd.PartNumber
FROM Product_Deliverable pd with (NOLOCK)
Where pd.ProductVersionID = @ProdID
and pd.DeliverableVersionID = @VersionID




﻿

CREATE PROCEDURE [dbo].[spGetActionProductType]

(
	@ActionID int
)
 AS


SELECT v.TypeID, v.ID AS ProdID, a.ID, a.Type AS ActionType, v.PartnerID, t.Name AS ActionTypeName
FROM
	ProductVersion AS v with (NOLOCK) INNER JOIN
	DeliverableIssues AS a with (NOLOCK) ON v.ID = a.ProductVersionID INNER JOIN
	ActionType AS t with (NOLOCK) ON a.Type = t.ID
WHERE
	(a.ID = @ActionID)




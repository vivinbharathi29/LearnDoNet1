﻿

CREATE PROCEDURE [dbo].[spGetRootID]
 (
  @ID as int
 )
 AS
Select DeliverableRootID as ID
FROM DeliverableVersion with (NOLOCK)
Where id = @ID




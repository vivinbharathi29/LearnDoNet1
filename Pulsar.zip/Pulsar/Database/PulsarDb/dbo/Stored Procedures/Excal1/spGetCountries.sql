﻿

CREATE PROCEDURE [dbo].[spGetCountries] AS
Select ID, Language, Abbreviation, Region, Active, REPLACE(REPLACE(Region,'>',''),'<','') AS Region2
From Language with (NOLOCK)
WHERE IsLanguage = 0
Order By Region2,Language




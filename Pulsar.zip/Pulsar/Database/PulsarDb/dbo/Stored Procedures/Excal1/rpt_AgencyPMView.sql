﻿/******************************************************************************
**		File: dbo.rpt_AgencyPMView.sql
**		Name: dbo.rpt_AgencyPMView
**		Desc: 
**
*******************************************************************************
**		Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**	05/14/2004	Kenneth Berntsen	Created Original Procedure
**  09/06/2016  santodip			Display Notes - PBI 24492  
**  05/16/2017  Herb			    fix error { call rpt_AgencyPMView(?) } Error.Description:String or binary data would be truncated.
**  06/07/2017  Herb                Performance
**	10/01/2018  Swami				Removed CURSOR and used the PIVOT 
**  22/02/2018	Santhana			#tmpRootList2 table dropped
**  19/Apr/2018 Monica				Removed DISTINCT in final Select ,Order by In temp Tables insertion,Coalesce to ISNULL
**10/5/2018     Monica				Added Distinct to #tmpRootList
*******************************************************************************/
CREATE PROCEDURE [dbo].[rpt_AgencyPMView]
	 @p_ProductVersionID INT,
	 @p_ModifiedBy		 VARCHAR(15) = NULL			
AS
BEGIN
SET NOCOUNT ON
--DECLARE @p_ProductVersionID INT=83
	declare @ReleaseCount Int = 0

	IF OBJECT_ID('Tempdb..#AgencyStatus') IS NOT NULL DROP TABLE #AgencyStatus;
	IF OBJECT_ID('Tempdb..#tmpAgencySummary') IS NOT NULL  DROP TABLE #tmpAgencySummary;
	IF OBJECT_ID('Tempdb..#tmpRootList') IS NOT NULL  DROP TABLE #tmpRootList;

	CREATE TABLE #AgencyStatus
	(
	CountryID INT,
	Country VARCHAR(50),
	Region VARCHAR(15),
	ProductVersionID INT
	)
	CREATE TABLE #tmpAgencySummary 
	(
		CountryID INT,
		RootID INT,
		Summary VARCHAR(MAX)
	)
	CREATE TABLE #tmpRootList(
		ID INT,
		Name VARCHAR(120),
		ReleaseYear INT DEFAULT 0,
		ReleaseMonth INT DEFAULT 0,
		SortOrder INT DEFAULT 1
	)
	INSERT INTO #AgencyStatus (CountryID, Country, Region, ProductVersionID)
		SELECT DISTINCT l.id, l.[language], l.region, pc.ProductVersionID
		FROM [language] l WITH(NOLOCK)
		LEFT JOIN Product_Country pc WITH(NOLOCK)
		on pc.CountryID = l.ID 
		AND pc.ProductVersionID = @p_ProductVersionID
		WHERE l.IsLanguage = 0
			AND l.Active = 1
	--	ORDER BY l.Region DESC, l.[Language]

	INSERT INTO #tmpRootList (ID, [Name], ReleaseYear, ReleaseMonth, SortOrder)
		select ID,[Name], ReleaseYear, ReleaseMonth,1 as SortOrder from [dbo].[ProductVersionRelease] 
			where ID in 
			(
				select distinct ReleaseID from [dbo].[AVDetail_ProductBrand_Release] where productBrandid = (
					select top 1 ID from product_brand where ProductVersionID = @p_ProductVersionID
				)
			)	
	select @ReleaseCount = count(*) from #tmpRootList

	INSERT INTO #tmpRootList (ID, [Name], SortOrder)
		SELECT DISTINCT dr.id, dr.name,ac.sort_order
		FROM
			agency_status ags WITH(NOLOCK)
			INNER JOIN deliverableroot dr WITH(NOLOCK) ON ags.deliverable_root_id = dr.id
			INNER JOIN productversion pv WITH(NOLOCK) ON ags.product_version_id = pv.id
			INNER JOIN productfamily pf WITH(NOLOCK) ON pv.productfamilyid = pf.id
			INNER JOIN product_delroot pdr WITH(NOLOCK) ON pdr.productversionid = pv.id AND pdr.deliverablerootid = dr.id
			INNER JOIN agency_category ac WITH(NOLOCK) ON dr.categoryid = ac.deliverable_category_id
		WHERE
			ags.product_version_id = ISNULL(@p_ProductVersionID, ags.product_version_id)
		--	ORDER BY ac.sort_order, dr.name


		DECLARE @Str VARCHAR(1000)
		DECLARE @Str2 VARCHAR(1000)
		SELECT 	@Str= COALESCE(@Str +', ', '')+ QUOTENAME(ID), 
			    @Str2 = COALESCE(@Str2 + ', ', '') + case when ReleaseYear > 0 then 'ReleaseTable.' else 'P.' end + QUOTENAME(ID) 
		FROM (SELECT DISTINCT ID,Name,ReleaseYear,ReleaseMonth,SortOrder FROM #tmpRootList)R 
		ORDER BY ReleaseYear desc, ReleaseMonth desc;

	IF EXISTS(SELECT 'x' FROM #tmpRootList)
	  BEGIN
		SELECT ID,Name INTO #tmpRootList2 FROM #tmpRootList ORDER BY ReleaseYear desc, ReleaseMonth desc;
		EXEC ('SELECT ''Country'' as Country, '+@Str +' from #tmpRootList2
		PIVOT (max(NAME) for ID IN (' +@Str +')
		) as p')

		  DROP TABLE #tmpRootList2;

	  END
	
	ELSE
	  BEGIN
		SELECT 'Country' AS Country
	  END;

	select regulatorymodel, @ReleaseCount as ReleaseCount, DOTSName from productversion where id=@p_ProductVersionID

	INSERT INTO #tmpAgencySummary (CountryID,RootID,Summary)
		SELECT DISTINCT 
			CountryID = a2.country_id, 
			RootID = a2.DeliverableRootID, 
			Summary = 
					  ISNULL(CAST(a2.StatusID AS Varchar(10)), '') + '|' + 
					  ISNULL(a2.AgencyType,'') + '|' + 
					  ISNULL(a2.AgencyName,'') + '|' + 
					  ISNULL(RTRIM(case when asm.Status_Cd != '' then asm.Status_Cd else a2.StatusCd end),'') + '|' + 
					  ISNULL(CONVERT(VARCHAR(10), case when asm.Projected_Date is not null then asm.Projected_Date else a2.ProjectedDt end, 101),'') + '|' + 
					  ISNULL(RTRIM(case when Leveraged_Status.Status_Cd != '' then Leveraged_Status.Status_Cd else a2.LevStatusCd end),'') + '|' + 
					  ISNULL(CONVERT(VARCHAR(10), case when Leveraged_Status.Projected_Date is not null then Leveraged_Status.Projected_Date else a2.LevProjectedDt end, 101),'') + '|' + 
					  ISNULL(CAST(a2.ldrid AS VARCHAR(10)),'') + '|' + 
					  ISNULL((RTRIM(case when asm.Notes is not null then asm.Notes else a2.StatusNote end)),'') + '|' + 
					  ISNULL(RTRIM(case when asm.POR_DCR is not null then asm.POR_DCR else a2.PorDcr end),'') + '|' + 
					  ISNULL(CAST(a2.pcid AS VARCHAR(10)), '') + '|' +
					  ISNULL(asm.ModifiedBy, '')
		FROM #AgencyStatus a1 
		INNER JOIN vAgency_Status a2 WITH(NOLOCK) ON a1.CountryID = a2.country_id
		LEFT JOIN Agency_Status_Modify asm WITH(NOLOCK) ON a2.StatusID = asm.Agency_Status_Id and asm.ModifiedBy = @p_ModifiedBy
		LEFT OUTER JOIN Agency_Status AS Leveraged_Status WITH (NOLOCK) ON asm.Leveraged_Id = Leveraged_Status.Agency_Status_Id
		WHERE a2.ProductVersionID = @p_ProductVersionID 

		
	 IF EXISTS(SELECT 'x' FROM #tmpRootList)
		BEGIN
			 EXEC (
			 'WITH PIVOT_DATA AS
			 (
			 SELECT  agSts.CountryID, agSts.Country, agSts.Region,agSts.ProductVersionID,
				r.ID RootID,s.summary as SName 
				, cr.ReleaseID
				, convert(varchar,cr.[Type]) + ''-'' + 
				case when cr.[Date] is not null then 
				          convert(varchar, cr.[Date], 101) else '''' 
			    end as RType
			 FROM #AgencyStatus agSts 
			 LEFT JOIN #tmpAgencySummary s ON agSts.CountryID=s.CountryID 
			 LEFT JOIN #tmpRootList R ON s.Rootid=R.id 
			 LEFT JOIN CertificationsForRelease cr on 
			           cr.ProductVersionID = agSts.ProductVersionID 
			       and cr.CountryID = agSts.CountryID
			 )'
			 +	 
			 'SELECT distinct P.CountryID, P.Country, P.Region, P.ProductVersionID, ' + @Str2 +
			 'FROM PIVOT_DATA
			  pivot (max(SName) FOR RootID IN (' + @Str +')) AS P
			  CROSS APPLY 
			  ( 
				SELECT * FROM PIVOT_DATA 
			    pivot (max(RType) FOR ReleaseID IN (' + @Str + ')) AS P2
				where P.CountryID = P2.CountryID 
			  ) ReleaseTable ORDER BY region DESC, Country')
		END

	 ELSE
		 BEGIN
			 SELECT  --DISTINCT
			 agSts.CountryID, agSts.Country, agSts.Region,agSts.ProductVersionID 
			 FROM #AgencyStatus agSts 
			 LEFT JOIN #tmpAgencySummary s ON agSts.CountryID=s.CountryID
			 LEFT JOIN #tmpRootList R ON s.Rootid=R.id 
			 ORDER BY region DESC, Country
		 END;

	
SET NOCOUNT OFF
END
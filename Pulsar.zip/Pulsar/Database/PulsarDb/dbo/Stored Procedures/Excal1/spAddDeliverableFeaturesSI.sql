﻿CREATE PROCEDURE [dbo].[spAddDeliverableFeaturesSI] 
/* ************************************************************************************************
 * Purpose:	
 * Created By:	
 * Modified By: Luhit Young (3/25/2015) Changed Sudden Impact Server and Database hardcodes.
 * Notes: As of March 25, 2015, 
 *        gvs90671.houston.hp.com is the test instance of Sudden Impact
 *        gvv41555.houston.hp.com is the production instance of Sudden Impact
 *        SQLCMD Variables to be used are: $(SuddenImpactServer) and $(SuddenImpactDatabase)
 *        for server and database, respectively.
 * Notes: As of August 4, 2015, 
 *        $(SuddenImpactServer) is no longer used. Instead a LinkedServer by name of LinkedServer_SuddenImpact is now defined as a linked server.
 *        SQLCMD Variables to be used are: $(SuddenImpactDatabase) for the database.
 **************************************************************************************************/
(
	@RootID int,
	@FeatureID int
)
AS
	Begin
	
	Declare @VersionID int
	Declare @ErrorCode int
	Select @ErrorCode = @@Error
	
	DECLARE Version_CURSOR CURSOR LOCAL FAST_FORWARD
			FOR Select v.ID from deliverableversion v with (NOLOCK) where v.deliverablerootid =  @RootID

	OPEN Version_Cursor
	FETCH NEXT FROM Version_Cursor Into @VersionID
		WHILE (@@fetch_status <> -1)
			BEGIN
				If (@@fetch_status <> -2)
					BEGIN
					If @ErrorCode = 0
						Begin
						EXEC [LinkedServer_SuddenImpact].[$(SuddenImpactDatabase)].dbo.AddFeature 0, @VersionID, @FeatureID
						Select @ErrorCode = @@Error
						End
					END
				FETCH NEXT FROM Version_Cursor Into  @VersionID
			END
	CLOSE Version_Cursor
	DEALLOCATE Version_Cursor
	
	Return @ErrorCode	
	end
GO


﻿

CREATE PROCEDURE [dbo].[spListActionOwners] AS
Select Distinct e.ID, e.Name as Owner
FROM DeliverableIssues a WITH (NOLOCK), Employee e WITH (NOLOCK)
Where a.OwnerID = e.ID
--and e.Division <> 2
Order By e.Name
/*
Select Count(*), e.Name as Owner
FROM DeliverableIssues a WITH (NOLOCK), Employee e WITH (NOLOCK)
Where a.OwnerID = e.ID
and e.Division <> 2
Group By e.Name
*/


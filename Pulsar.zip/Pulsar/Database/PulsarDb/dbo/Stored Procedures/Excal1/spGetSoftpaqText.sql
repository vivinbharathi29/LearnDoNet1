﻿

CREATE PROCEDURE [dbo].[spGetSoftpaqText]
(
	@VersionID int
)
 AS
Select r.ID as RootID, v.filename, r.Name as Title, v.Version + ' REV ' + v.Revision as Version,v.version as DelVersion, v.revision as revision, v.pass, r.Description, v.CVAVersion, v.ARCDInstall,v.SilentInstall, v.PnPDevices, v.ReleaseType as Purpose, v.softpaqtype, v.SoftpaqNumber,v.EffectiveDate, v.SoftpaqFileInfo as DetailedFileInfo, v.Supersedes, 'N/A' as PartNumber,v.SoftpaqFixes as Fixes, c.Name as SoftpaqCategory, r.MultiLanguage, v.SSMCompliant as SSM,v.SoftpaqInstructions as HowToUse,v.OtherDependencies as Prerequisites, v.Changes as Enhancements
FROM 
	DeliverableRoot r with (NOLOCK)
	INNER JOIN DeliverableVersion v with (NOLOCK) ON r.id = v.DeliverableRootID
	LEFT OUTER JOIN SoftpaqCategory c with (NOLOCK) ON c.ID = r.SoftpaqCategoryID
Where v.ID = @VersionID

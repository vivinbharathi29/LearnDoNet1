﻿
CREATE PROCEDURE [dbo].[spGetConveyorPartNumber] 
-- ==========================================================================================
-- Author:		?
-- Create date: ?
-- Description:	31/03/2016 Ravi Nukala - SR0015 - Deterministic function call (function) might cause an unnecessary table scan. Task 18941
-- ==========================================================================================
(
      @Delivname varchar(240),
      @DelivVersion varchar(120),
      @DelivOSCode varchar(120),
      @DelivLangCode varchar(120),
      @DelivRevision  varchar(120),
      @DelivExtPass varchar(120),
      @DelivIntPass varchar(120)
)
AS

      declare @vDelivname varchar(240), @vDelivVersion varchar(120), @vDelivLangCode varchar(120)
      SET @vDelivname = @Delivname
      SET @vDelivVersion = @DelivVersion
      SET @vDelivLangCode = @DelivLangCode
      
      SELECT *
      FROM HOUBNBCVR01.conveyor.dbo.[Deliv] with (nolock)
      WHERE [DelivDivCode] = 'PORT'
      AND [SiteCode] = 'HOU'
      AND [DelivName] = @vDelivname
      AND [DelivVersion] = @vDelivVersion 
      AND [DelivOSCode] = coalesce(@DelivOSCode ,[DelivOSCode])
      AND [DelivLangCode] = coalesce(@vDelivLangCode,[DelivLangCode])
      AND [DelivRevision] = @DelivRevision 
      AND [DelivExtPass] = @DelivExtPass 
      AND [DelivIntPass] = COALESCE(@DelivIntPass,[DelivIntPass])

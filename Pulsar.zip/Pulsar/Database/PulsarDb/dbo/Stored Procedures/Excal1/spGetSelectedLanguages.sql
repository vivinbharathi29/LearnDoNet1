﻿CREATE PROCEDURE [dbo].[spGetSelectedLanguages] (@ID as int) 
AS
/** Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
**  1  6/8/2018     Monica   Changed from ANSI Join and changed coalesce to ISNULL 
****************************************************************************************************/

Select Language_DelVer.LanguageID as ID, 
L.language as Name,
L.Abbreviation as Abbreviation, 
PartNumber, 
CDPartNumber,
CDKitNumber, 
SoftpaqNumber, 
Supersedes, 
ISNULL(l.CvrCode, L.Abbreviation) as CVRCode
FROM Language_DelVer with (NOLOCK)
INNER JOIN  Language L with (NOLOCK)
ON  L.ID = Language_DelVer.LanguageID
WHERE Deliverableversionid = @ID
order by l.orderid


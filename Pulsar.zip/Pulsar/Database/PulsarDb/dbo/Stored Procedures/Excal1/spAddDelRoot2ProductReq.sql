﻿
CREATE PROCEDURE [dbo].[spAddDelRoot2ProductReq]
 (
  @ProductReqID int,
  @ProductID int,
  @DeliverableRootID int,
  @Preinstall bit = 0,
  @Preload bit = 0,
  @DropInBox bit = 0,
  @Web bit = 0,
  @SelectiveRestore bit = 0,
  @ARCD bit = 0,
  @DRDVD bit = 0,
  @RACD_Americas bit = 0,
  @RACD_APD bit = 0,
  @RACD_EMEA bit = 0,
  @OSCD bit = 0,
  @DocCD bit = 0
 )
 AS
begin transaction
DECLARE @RootCount int
DECLARE @RootActive tinyint
Declare @TBDID int
Declare @Commodity bit
DECLARE @TypeID int
Declare @Accessory bit
DECLARE @CurrentDate datetime
Select @CurrentDate = getdate()

Select @Commodity=c.Commodity, @TypeID=r.typeid
from deliverableroot r WITH (NOLOCK), deliverablecategory c WITH (NOLOCK)
where c.id = r.categoryid
and r.id = @DeliverableRootID

Select @Accessory=c.Accessory
from deliverableroot r WITH (NOLOCK), deliverablecategory c WITH (NOLOCK)
where c.id = r.categoryid
and r.id = @DeliverableRootID

Select @RootActive = Active
from deliverableroot WITH (NOLOCK)
where id=@DeliverableRootID

Select @RootCount = Count(ID)
from product_DelRoot WITH (NOLOCK)
where ProductVersionId = @ProductID 
and DeliverableRootID = @DeliverableRootID

Select @TBDID = ID
from Product_requirement WITH (NOLOCK)
where ProductID = @ProductID
and RequirementID = 1960

Insert ProdReq_DelRoot (ProductRequirementID,DeliverableRootID)
Values(@ProductReqID,@DeliverableRootID)
--remove from TBD if it is there
if @TBDID is not null and @ProductReqID <> @TBDID
	Delete prodReq_DelRoot
	Where ProductRequirementid = @TBDID
	and DeliverableRootID = @DeliverableRootID	
--Add Root
if @RootCount = 0 --skip if already added
	Insert Product_DelRoot (ProductVersionID,DeliverableRootID,DRDVD,RACD_Americas,RACD_EMEA,RACD_APD,OSCD,DocCD,Preinstall,preload,dropinbox,web,SelectiveRestore,ARCD,ImageSummary,Images)
	Values(@ProductID,@DeliverableRootID,@DRDVD,@RACD_Americas,@RACD_EMEA,@RACD_APD,@OSCD,@DocCD,@Preinstall,@Preload,@DropInBox,@Web, @SelectiveRestore, @ARCD,'','')
--Copy versions that aren't already there
/*
if @RootActive=1 and @TypeID<> 1 and @RootCount=0
	Insert Product_Deliverable (ProductVersionID,DeliverableVersionID,Locked,Targeted,AlertID,InImage,Preinstallstatus,PMAlert,DRDVD,RACD_Americas,RACD_EMEA,RACD_APD,OSCD,DocCD,Preinstall,preload,dropinbox,web,SelectiveRestore,ARCD)
	Select @ProductID, v.id,0, 0,0,0,0,0,@DRDVD,@RACD_Americas,@RACD_EMEA,@RACD_APD,@OSCD,@DocCD,@Preinstall,@Preload,@DropInBox,@Web, @SelectiveRestore, @ARCD
	from DeliverableVersion v WITH (NOLOCK)
	Where v.deliverablerootid=@DeliverableRootID
	and v.active=1
	and v.Id not in (	Select pd.DeliverableVersionID
			 from product_deliverable pd WITH (NOLOCK), deliverableversion v WITH (NOLOCK)
			 where ProductVersionID = @ProductID
			 and v.id = pd.DeliverableVersionID
			and v.deliverablerootid = @Deliverablerootid)
	and v.Id in (	Select distinct pd.DeliverableVersionID
			 from product_deliverable pd WITH (NOLOCK), deliverableversion v WITH (NOLOCK), productversion pv WITH (NOLOCK)
			 where pv.id = pd.productversionid
			and v.id = pd.DeliverableVersionID
			and (pd.targeted = 1 or pd.inimage=1)
			and pv.active=1
			and v.deliverablerootid = @Deliverablerootid)

*/

/*if @RootCount > 0 
	--Log
	INSERT INTO AppError (Category, ErrFile, ErrLine, AspDescription, ErrDescription, ErrorDateTime, AuthUser)
	VALUES ('User error', @ProductID,@DeliverableRootID, '', 'user tried to add duplicate rocord in Product_DelRoot and Product_Requirement table', @CurrentDate, 'Dien Bui')
*/
/*	from DeliverableVersion v WITH (NOLOCK)
	Where v.deliverablerootid=@DeliverableRootID
	and v.active=1
	and v.Id not in (	Select pd.DeliverableVersionID
			 from product_deliverable pd WITH (NOLOCK), deliverableversion v WITH (NOLOCK)
			 where ProductVersionID = @ProductID
			 and v.id = pd.DeliverableVersionID
			and v.deliverablerootid = @Deliverablerootid)
*/
commit transaction


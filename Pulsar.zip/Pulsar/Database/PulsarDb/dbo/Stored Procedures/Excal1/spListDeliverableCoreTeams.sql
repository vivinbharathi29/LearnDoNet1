﻿

CREATE PROCEDURE [dbo].[spListDeliverableCoreTeams]

AS

	Select ID, Name
	from DeliverableCoreTeam with (NOLOCK)
	where active=1
	order by displayorder



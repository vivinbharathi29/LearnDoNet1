﻿
CREATE PROCEDURE [dbo].[spGetReportProfileGroups]
(
	@ID int
)
as
/*
	Select s.id, Setting, CanEdit, CanDelete
	from  employee_usersettings s, ReportProfilesShared r
	where r.ReportProfileID = @ID
	and s.usersettingsid=4
	and r.groupid = s.id
*/

SELECT     
	s.ID, s.Setting, r.CanEdit, r.CanDelete, e.Name AS PrimaryOwner
FROM         
	ReportProfiles AS p with (NOLOCK) INNER JOIN
    Employee AS e with (NOLOCK) ON p.EmployeeID = e.ID INNER JOIN
    ReportProfilesShared AS r with (NOLOCK) ON p.ID = r.ReportProfileID INNER JOIN
    Employee_UserSettings AS s with (NOLOCK) ON s.ID = r.GroupID  
WHERE     
	(r.ReportProfileID = @ID) 
AND (s.UserSettingsID = 4)


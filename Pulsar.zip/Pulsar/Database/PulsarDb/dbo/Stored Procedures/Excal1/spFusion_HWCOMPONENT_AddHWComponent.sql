﻿CREATE PROCEDURE [dbo].[spFusion_HWCOMPONENT_AddHWComponent] 
/* ************************************************************************************************
 * Purpose:		pushing data to IRS
 * Created By:	Unknown
 * Modified By:	3/25/2016 wgomero: push firmware version to IRS for SOLIDSTATE Category
 * Modified By: 13 Oct 2016 poletto: call the SPs to sync users with IRS if necessary, as in spFusion_COMPONENT_AddComponent
 **************************************************************************************************/
(
	@VersionID int
)
AS
	Declare @RootID int
	Declare @XMLInput as varchar(MAX)

	
		begin
		Declare @Name varchar(120) --DeliverableVersion.DeliverableName
		Declare @SAPDescription varchar(3) --Dropped...
		Declare @OwnerID int --DeliverableVersion.Developer
		Declare @PMID int --DeliverableRoot.DevManagerID
		Declare @ApproverID int --DeliverableRoot.SIOApproverId field
		Declare @BusinessSegmentID int --Unknown dataType
		Declare @VendorID int
		Declare @VendorPartNo varchar(30) --Unknown dataType
		Declare @VendorCodeName varchar(3) --DeliverableVersion.CodeName???
		Declare @EOLDate date --DeliverableVersion.EndOfLifeDate field
		Declare @KCID as varchar(29) --DeliverableVersion.KoreanCertificationID
		Declare @KCIDRequired as bit --DeliverableRoot.KoreanCertificationRequired
		Declare @HWRevision varchar(20) --DeliverableVersion.Version field
		Declare @HWStatus varchar(3) --DeliverableVersion.Status field or one of the other many Status fields in the Version and Root tables???
		Declare @Shipping varchar(10) --Dropped...
		Declare @HPPartNo varchar(100) --DeliverableVersion.PartNumber field
		Declare @IncludeInStatusRpt varchar(3) --Unknown dataType
		Declare @OTSEnabled varchar(3) --Unknown dataType
		Declare @Integrated varchar(3) --Unknown dataType
		Declare @SiteID int --Unknown dataType
		Declare @GenericFlag varchar(3) --Give this a value of False
		Declare @Updater varchar(9) --UpdatedBy - Just hardcode this to 'Excalibur'
		Declare @StatusConstant varchar(80) --Unknown dataType
		Declare @Category varchar(30) --DeliverableRoot.CategoryID field...
		Declare @PNPID varchar(3) --DeliverableVersion.PNPDevices field or the DeliverableRoot.PNPDevices field???
		Declare @Revision varchar(30)
		
		Declare @intPassID int
		Declare @NewVersionID int
		Declare @intCategoryID int
		Declare @Message varchar(2000)
		Declare @ValValue_bit bit
		
		Set @SAPDescription = ''
		Set @VendorPartNo = ''
		Set @VendorCodeName = ''
		Set @HWStatus = '0'
		Set @Shipping = '0'
		Set @IncludeInStatusRpt = '0'
		Set @OTSEnabled = '1'
		Set @Integrated = '0'
		Set @GenericFlag = '0'
		Set @Updater = 'Excalibur'
		Set @StatusConstant = 'COMP_READY_FOR_TEST'
		Set @PNPID = ''
		Set @ValValue_bit = 0

		--
		-- Pull the SiteId and BusinessSegmentId from IRS
		--
		--SET @SiteID = 52
		select @SiteID = ODMID from IRS_ODM where Name like '%Pulsar Hardware%' and Name like 'HP%'
		SET @BusinessSegmentID = 3475

		Select @Name = dv.DeliverableName,
			   @OwnerID = dv.DeveloperID,--
			   @KCID = Coalesce(dv.KoreanCertificationID, 0),
			   @VendorID = Coalesce(dv.VendorID, 0),
			   @EOLDate = Coalesce(dv.EndOfLifeDate, ''),
			   @HWRevision = dv.Version,
			   @HPPartNo = Coalesce(dv.PartNumber, ''),
			   @VendorPartNo = Coalesce(dv.ModelNumber, ''),
--			   @RootID = dv.DeliverableRootID,
			   @ApproverID = Coalesce(dr.SIOApproverId, 0),--
			   @KCIDRequired = Coalesce(dr.KoreanCertificationRequired, 0),
			   @Category = Coalesce(IRSC.Abbreviation, ''),
			   @PMID = dr.DevManagerID,--
			   @Revision = Coalesce(dv.Revision, '')
		From dbo.DeliverableVersion dv Join DeliverableRoot dr on dv.DeliverableRootID = dr.ID
									   Join DeliverableCategory dc on dr.CategoryID = dc.ID
									   Join IRS_Category IRSC on dc.IRSCategoryID = IRSC.CategoryID
		Where dv.ID = @VersionID
		
		Print 'ExcalID - OwnerID: ' + Cast(@OwnerID AS Varchar(10))
		Print 'ExcalID - VendorID: ' + Cast(@VendorID AS Varchar(10))
		Print 'ExcalID - ApproverID: ' + Cast(@ApproverID AS Varchar(10))
		Print 'ExcalID - PMID: ' + Cast(@PMID AS Varchar(10))
		Print ''

		--temp vars to check if users needs to be synced with IRS
		DECLARE @tmpOwnerID int, 
						@tmpApproverID int=0, 
						@tmpPMID int

		--DeliverableVersion Parameters
		Select @Name = dv.DeliverableName,
			   @tmpOwnerID = dv.DeveloperID,
			   @KCID = Coalesce(dv.KoreanCertificationID, 0),
			   @VendorID = Coalesce(dbo.ufn_GetIRSVendorID(dv.VendorID), 0),
			   @EOLDate = Coalesce(dv.EndOfLifeDate, ''),
			   @HWRevision = dv.Version,
			   @HPPartNo = Coalesce(dv.PartNumber, ''),
			   @VendorPartNo = Coalesce(dv.ModelNumber, ''),
			   @tmpApproverID = Coalesce(dr.SIOApproverId, 0),
			   @KCIDRequired = Coalesce(dr.KoreanCertificationRequired, 0),
			   @Category = Coalesce(IRSC.Abbreviation, ''),
			   @tmpPMID = dr.DevManagerID,
			   @Revision = Coalesce(dv.Revision, ''),
			   @intPassID = Coalesce(dv.irsid, 0)
		From dbo.DeliverableVersion dv Join DeliverableRoot dr on dv.DeliverableRootID = dr.ID
									   Join DeliverableCategory dc on dr.CategoryID = dc.ID
									   Join IRS_Category IRSC on dc.IRSCategoryID = IRSC.CategoryID
		Where dv.ID = @VersionID



			SELECT @OwnerID = ISNULL(IRSUserID,0) FROM UserInfo WHERE UserId=@tmpOwnerID
			SELECT @PMID = ISNULL(IRSUserID,0) FROM UserInfo WHERE UserId=@tmpPMID

			IF(@tmpApproverID!=0) --this is optional
				SELECT @ApproverID = ISNULL(IRSUserID,0) FROM UserInfo WHERE UserId=@tmpApproverID

			IF(@OwnerID=0 OR @PMID=0 OR (@tmpApproverID!=0 AND @ApproverID=0)) --check approverId only if it was there
				BEGIN
					--call the same SPs as in [spFusion_COMPONENT_AddComponent]


					--RE-read the IRS user IDs, now users should have been synced. If not later on the prosecure will throw the usual error.
					SELECT @OwnerID = ISNULL(IRSUserID,0) FROM UserInfo WHERE UserId=@tmpOwnerID
					SELECT @PMID = ISNULL(IRSUserID,0) FROM UserInfo WHERE UserId=@tmpPMID

					IF(@tmpApproverID!=0) --this is optional
						SELECT @ApproverID = ISNULL(IRSUserID,0) FROM UserInfo WHERE UserId=@tmpApproverID
				END


		Print 'IRSID - OwnerID: ' + Cast(@OwnerID AS Varchar(10))
		Print 'IRSID - VendorID: ' + Cast(@VendorID AS Varchar(10))
		Print 'IRSID - ApproverID: ' + Cast(@ApproverID AS Varchar(10))
		Print 'IRSID - PMID: ' + Cast(@PMID AS Varchar(10))
		Print ''

		Declare @PlaformID int
		set @PlaformID = 0
		if @Category = 'SYSBD'
		begin
			select	@PlaformID = DesktopPlatformID from DesktopPlatform_Deliverable where ID = @VersionID
			/* Defaulting to some static value - task 13258 */
			set @HWRevision = 346
			/*
			select @HWRevision = IrsHWValidationID from DeliverableVersion dv 
									INNER JOIN SBHardwareComponent SBC on dv.DeliverableRootID = SBC.DeliverableRootID and dv.ID = SBC.DeliverableVersionID
									INNER JOIN SBHardwareRevision SBR on SBC.HardwareRevisionID = SBR.ID
										Where dv.ID = @VersionID */
		end

		IF @Category <> ''
			BEGIN

		Select @XMLInput = '<?xml version="1.0" encoding="ISO-8859-1"?>'
		Select @XMLInput = @XMLInput +  CHAR(13) + CHAR(10)  + '<Parameters '+ CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'Name="' + ISNULL(@Name, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'SAPDescription="' + ISNULL(@SAPDescription, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'OwnerID="' + ISNULL(Cast(@OwnerID AS Varchar(10)), '') + '" ' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'PMID="' + ISNULL(Cast(@PMID AS Varchar(10)), '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'ApproverID="' + ISNULL(Cast(@ApproverID AS Varchar(10)), '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'BusinessSegmentID="' + ISNULL(CAST(@BusinessSegmentID AS VARCHAR), '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'VendorID="' + ISNULL(Cast(@VendorID AS Varchar(10)), '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'VendorPartNo="' + ISNULL(@VendorPartNo, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'VendorCodeName="' + ISNULL(@VendorCodeName, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'EOLDate="' + ISNULL(Convert(Varchar(20), @EOLDate), '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'KCID="' + ISNULL(@KCID, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'KCIDRequired="' + ISNULL(Convert(Varchar(5), @KCIDRequired), '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'HWRevision="' + ISNULL(@HWRevision, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'HWStatus="' + ISNULL(@HWStatus, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'Shipping="' + ISNULL(@Shipping, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'HPPartNo="' + ISNULL(@HPPartNo, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'IncludeInStatusRpt="' + ISNULL(@IncludeInStatusRpt, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'OTSEnabled="' + ISNULL(@OTSEnabled, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'Integrated="' + ISNULL(@Integrated, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'SiteID="'+ ISNULL(CAST(@SiteID AS VARCHAR), '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'GenericFlag="' + ISNULL(Convert(varchar(10), @GenericFlag), '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'Updater="' + ISNULL(@Updater, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'StatusConstant="' + ISNULL(@StatusConstant, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'Category="' + ISNULL(@Category, '') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'PlatformID="' + ISNULL(Convert(varchar(10),@PlaformID), '0') + '"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'Generic="0"' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + 'PNPID="' + ISNULL(@PNPID, '') + '">' + CHAR(13) + CHAR(10)
		Select @XMLInput = @XMLInput + '<EditPermission GroupID="7" />' + CHAR(13) + CHAR(10)

		If @Category = 'AADPT'
			Set @ValValue_bit = 1 --Audio Adapter
		Else If @Category = 'DCTRL'
			Set @ValValue_bit = 1 --Disk Controller
		Else If @Category = 'GADPT'
			Set @ValValue_bit = 1 --Graphics Adapter
		Else If @Category = 'HDD'
			Set @ValValue_bit = 1 --Hard Drive
		Else If @Category = 'HDDRV'
			Set @ValValue_bit = 1 --Hard Drive
		Else If @Category = 'MODEM'
			Set @ValValue_bit = 1 --Modem
		Else If @Category = 'Modem'
			Set @ValValue_bit = 1 --Modem
		Else If @Category = 'MDM'
			Set @ValValue_bit = 1 --Modem
		Else If @Category = 'NADPT'
			Set @ValValue_bit = 1 --Network Adapter
		Else If @Category = 'RSTRG'
			Set @ValValue_bit = 1 --Removable Storage
		Else If @Category = 'SOLIDSTATE'
			Set @ValValue_bit = 1 --Solid State Module

		if @ValValue_bit = 1
			Select @XMLInput = @XMLInput + '<ValidationValue Description="Firmware Version" HWValidationID="" AttributeValue="' + @Revision + '" AttributeOrder="0" IsFreeText="1" />' + CHAR(13) + CHAR(10)

		Select @XMLInput = @XMLInput + '</Parameters>' + CHAR(13) + CHAR(10)

		print ' xml: ' + @XMLInput

		--Insert the XMLInput into the SIExcalSyncLog first.
		  insert into SIExcalSyncLog (Message,TypeID, ObjectID,Success,Updated,Arg)
		  Select 'Sending:' + @XMLInput,13, @VersionID,1,GetDate(),0
		  from deliverableversion WITH (NOLOCK)
		  where id = @VersionID

		Declare @CatID int
		Declare @chrMess varchar(2000)
		
		--Set @intPassID = 0
		Set @NewVersionID = 0
		Set @intCategoryID = 0
		Set @Message = ''

		if (@intPassID = 0)
			begin
				exec IRS_usp_NHWC_Create
					@p_chrParamXML = @XMLInput, 
					@p_chrParamDescription = '', 
					@p_chrParamReleaseNote = '', 
					@p_intCheckExist = 1, 
					@p_intVersionID = @NewVersionID output, 
					@p_intPassID = @intPassID output, 
					@p_intCategoryID = @CatID output, 
					@p_chrMessage = @chrMess output
			end
		else
			begin
				exec IRS_usp_NHWC_Update
					@p_chrParamXML=@XMLInput,
					@p_chrParamDescription='',
					@p_chrParamReleaseNote='',
					@p_intPassID=@intPassID,                -- ComponentPassID value is needed to update the correct hardware component.
					@p_intCheckExist=1,
					@p_chrMessage = @chrMess output

					select @NewVersionID = ComponentVersionId from irs_componentpass where ComponentPassId = @intPassID
			end

		Print '@NewVersionID: ' + CAST(@NewVersionID AS Varchar(10)) + CHAR(13) + CHAR(10)
		Print '@intPassID: ' + CAST(@intPassID AS Varchar(10)) + CHAR(13) + CHAR(10)
		Print '@CatID: ' + CAST(@CatID AS Varchar(10)) + CHAR(13) + CHAR(10)
		Print '@chrMess: ' + CAST(@chrMess AS Varchar(255)) + CHAR(13) + CHAR(10)
		

		--Insert the parameters that Walter Gemero's stored procedure returns
		  insert into SIExcalSyncLog (Message,TypeID, ObjectID,Success,Updated,Arg)
		  values ('Pass ID: ' + cast(@intPassID as varchar(200)) + 
				  ' Version ID: ' + cast(@NewVersionID as varchar(200)) +
				  ' Category ID: ' + CAST(@intCategoryID as varchar(200)) +
				  ' XML: ' + @XMLInput,10, @VersionID,1,GetDate(),0)

		--IRSID in the Excalibur DeliverableVersion table is equal to the PassID from IRS
		update DeliverableVersion
		set IRSVersionID = @NewVersionID, IRSID = @intPassID
		where id = @VersionID
	 end
	END
	
	--Excalibur Category IRSCategoryID

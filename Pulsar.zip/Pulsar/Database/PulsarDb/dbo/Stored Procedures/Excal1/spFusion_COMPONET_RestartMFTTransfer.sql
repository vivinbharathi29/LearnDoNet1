﻿
CREATE PROCEDURE [dbo].[spFusion_COMPONET_RestartMFTTransfer]
(
	@VersionID int,
	@ImagePath varchar(256)
)
AS

	declare @MFTJobID int
	declare @MFTCommand varchar(8000)
	declare @ZipFileName varchar(300)
	declare @SubmitterEmail varchar(256)
	declare @IRSPath varchar(256)
	declare @NotifySubmitter bit

	Select @IRSPath = v.IRSPath, @NotifySubmitter = v.MFTNotifySubmitter, @SubmitterEmail = e.Email
	from deliverableversion v, employee e
	where v.id = @VersionID
	and e.id = v.submitterid

	--Call walter's procedure to transfer the files (get the jobid)
	
	set @MFTJobID = 0
	Select @MFTCommand = 'java -jar seefx-client.jar get "irs_service_acct:9m9GlYVYJtdz5z2d@https://mftp.b2b.americas.hp.com/portal-seefx:/My Subscriptions/' + replace(@ImagePath,'SoftwareComponents/','SoftwareComponents#ppspcrd/') + '"  "\\16.102.80.48\fusion\DownloadZipFiles" -d -s=10 -v'
	Select @ZipFileName = RIGHT('\'+@ImagePath, CHARINDEX('\', REVERSE('\'+@ImagePath))-1)
	exec IRS_usp_LCMLang_ComponentDownload 
			@p_chrCommandPath=@MFTCommand,
			@p_chrEmail = @SubmitterEmail,
			@p_chrFileName = @ZipFileName,
			@p_chrTargetPath = @IRSPath ,
			@p_intEmail= @NotifySubmitter,--: 0 = Do not sent email. 1: send email when done
			@p_intJobID = @MFTJobID output
			
	--Update the deliverable version with the jobid, set IRSFileCopied = 8, and change the imagepath = irspath
	Update DeliverableVersion
	set mftjobid = @MFTJobID, IRSFilesCopied = 8--, imagepath=irspath, Initialpath=irspath
	where id = @versionID
	



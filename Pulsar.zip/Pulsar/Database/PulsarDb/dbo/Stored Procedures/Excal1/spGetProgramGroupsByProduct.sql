﻿
CREATE PROCEDURE [dbo].[spGetProgramGroupsByProduct] 
(
	@ID int
)
AS

	Select p.fullname
	from Product_Program pp with (NOLOCK), Program p with (NOLOCK), ProgramGroup pg with (NOLOCK)
	where p.ID = pp.ProgramID
	and p.programgroupid = pg.id
	and pp.ProductVersionID = @ID
	order by pg.DisplayOrder

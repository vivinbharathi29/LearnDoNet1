﻿
CREATE PROCEDURE [dbo].[spGetProfileReportDefinition]
(
	@ID int
)
AS

	Select ID, ProfileName as Name,PageLayout as ReportSections,SelectedFilters as SectionParameters
	from ReportProfiles with (NOLOCK)
	where ID = @ID
	


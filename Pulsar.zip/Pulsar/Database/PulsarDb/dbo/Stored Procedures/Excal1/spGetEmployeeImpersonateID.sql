﻿/**************************************************************************************************
** Author  :   
** Description :  
** Date   :     
**************************************************************************************************
** Change History     
**************************************************************************************************
** SNo   Date        Author  Description     
** --    --------   -------   -------------------------     
**  2	 201-02-2018 Swami	  Optimized the sp   
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spGetEmployeeImpersonateID]
(
	@NTName varchar(50),
	@Domain varchar(50)
)

AS
BEGIN
SET NOCOUNT ON
	SELECT ImpersonateID, ID as EmployeeID
	FROM dbo.employee with (NOLOCK)
	WHERE NTName = @NTName
	and Domain = @Domain
SET NOCOUNT OFF
END
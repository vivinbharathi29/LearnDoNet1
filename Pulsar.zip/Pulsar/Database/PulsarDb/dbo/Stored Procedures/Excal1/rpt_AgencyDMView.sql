﻿/******************************************************************************
**		File: dbo.rpt_AgencyDMView.sql
**		Name: dbo.rpt_AgencyDMView
**		Desc: 
**
*******************************************************************************
**		Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**	05/14/2004	Kenneth Berntsen	Created Original Procedure
**  06/07/2017  Herb                Performance
**	08/01/2018	Santhana K			Cursor removed and introduced PIVOT query
*******************************************************************************/
CREATE PROCEDURE [dbo].[rpt_AgencyDMView] 
	@p_DeliverableRootID INT,
	@p_ModifiedBy		 VARCHAR(15) = NULL
AS
BEGIN
SET NOCOUNT ON;

	CREATE TABLE #AgencyStatus(
							CountryID INT,
							Country VARCHAR(50),
							Region VARCHAR(15),
							DeliverableRootID INT)	

	CREATE TABLE #tmpAgencySummary(
							CountryID INT,
							PVID INT,
							Summary VARCHAR(MAX))

	CREATE TABLE #tmpPVList(
							PVID INT,
							PVName VARCHAR(120),
							SortOrder INT)
								
	CREATE TABLE #pivot_data (CountryID INT,
							Country VARCHAR(50),
							Region VARCHAR(15),
							DeliverableRootID INT,
							PVID INT,
							PVName VARCHAR(MAX))

   CREATE CLUSTERED INDEX IX_AgencyStatusCountryID ON #AgencyStatus(CountryID)
	
	INSERT INTO #AgencyStatus (CountryID, Country, Region,DeliverableRootID)
	SELECT CountryID=l.id, Country=l.[language], l.Region,DeliverableRootID = lr.DeliverableRootID
	FROM DBO.[language] l WITH(NOLOCK)
	left join DBO.Language_DelRoot lr WITH(NOLOCK)
	on l.id=lr.LanguageID 
	and lr.DeliverableRootID = @p_DeliverableRootID
	WHERE l.IsLanguage = 0
	AND l.Active = 1
	ORDER BY l.Region DESC, l.[Language]

	INSERT INTO #tmpPVList (PVID,PVName,SortOrder)
	SELECT DISTINCT ags.product_version_id, pv.dotsname as product_name, ac.sort_order
	FROM DBO.agency_status ags with (NOLOCK)
	INNER JOIN DBO.productversion pv with (NOLOCK) 
	ON ags.product_version_id = pv.id 
	AND pv.productstatusId <= 3
	INNER JOIN DBO.productfamily pf with (NOLOCK) 
	ON pv.productfamilyid = pf.id
	INNER JOIN DBO.product_delroot pdr with (NOLOCK) 
	ON pdr.productversionid = pv.id
	INNER JOIN DBO.deliverableroot dr with (NOLOCK) 
	ON pdr.deliverablerootid = dr.id and ags.deliverable_root_id = dr.id
	INNER JOIN DBO.agency_category ac with (NOLOCK) 
	ON dr.categoryid = ac.deliverable_category_id
	WHERE ags.deliverable_root_id = ISNULL(@p_DeliverableRootID, ags.deliverable_root_id)
	ORDER BY
	ac.sort_order,
	product_name
			
	/* New Code for #AgencyCols */
	DECLARE @Str varchar(MAX)
	SELECT @Str =  ISNULL(@STr +', ', '') 
			+ QUOTENAME(PVID) 
	FROM (select distinct PVID, PVName,SortOrder from #tmpPVList)d 
	order by SortOrder;

	IF EXISTS(select 'x' from #tmpPVList)
	BEGIN
		EXEC ('SELECT ''Country'' as Country, ' + @Str +' from #tmpPVList
					PIVOT (max(PVName) for PVID IN (' + @Str +')
							) as PV' 
					)			   
	END
	ELSE
	BEGIN
		SELECT 'Country' as Country
	END;
		/* New Code for #AgencyCols */

	INSERT INTO #tmpAgencySummary (CountryID,PVID,Summary)
	SELECT DISTINCT 
			CountryID = a2.country_id, 
			PVID = a2.ProductVersionID, 
			Summary = 
					ISNULL(CAST(a2.StatusID AS Varchar(10)), '') + '|' + 
					ISNULL(a2.AgencyType,'') + '|' + 
					ISNULL(a2.AgencyName,'') + '|' + 
					ISNULL(RTRIM(case when asm.Status_Cd != '' then asm.Status_Cd else a2.StatusCd end),'') + '|' + 
					ISNULL(CONVERT(VARCHAR(10), case when asm.Projected_Date is not null then asm.Projected_Date else a2.ProjectedDt end, 101),'') + '|' + 
					ISNULL(RTRIM(case when Leveraged_Status.Status_Cd != '' then Leveraged_Status.Status_Cd else a2.LevStatusCd end),'') + '|' + 
					ISNULL(CONVERT(VARCHAR(10), case when Leveraged_Status.Projected_Date is not null then Leveraged_Status.Projected_Date else a2.LevProjectedDt end, 101),'') + '|' + 
					ISNULL(CAST(a2.ldrid AS VARCHAR(10)),'') + '|' + 
					ISNULL((RTRIM(case when asm.Notes is not null then asm.Notes else a2.StatusNote end)),'') + '|' + 
					ISNULL(RTRIM(case when asm.POR_DCR is not null then asm.POR_DCR else a2.PorDcr end),'') + '|' + 
					ISNULL(CAST(a2.pcid AS VARCHAR(10)), '') + '|' +
					ISNULL(asm.ModifiedBy, '')
		FROM #AgencyStatus a1 
		INNER JOIN vAgency_Status a2  WITH(NOLOCK)
		ON a1.CountryID = a2.country_id
		LEFT JOIN Agency_Status_Modify asm WITH(NOLOCK) 
		ON a2.StatusID = asm.Agency_Status_Id 
		and asm.ModifiedBy = @p_ModifiedBy
		LEFT OUTER JOIN Agency_Status AS Leveraged_Status WITH (NOLOCK) 
		ON asm.Leveraged_Id = Leveraged_Status.Agency_Status_Id
		WHERE a2.DeliverableRootID = @p_DeliverableRootID

		/* New Code for #AgencyStatus*/
	IF EXISTS(select 'x' from #tmpPVList)
	BEGIN
		EXEC ('INSERT INTO #Pivot_Data(CountryID ,Country ,Region ,DeliverableRootID,PVID ,PVName) 
				select agStatus.CountryID,	agStatus.Country,	agStatus.Region,	agStatus.DeliverableRootID ,c.PVID PVID, b.summary as PVName
				from  #AgencyStatus agStatus left join #tmpAgencySummary b on agStatus.CountryID = b.CountryID 
						left join #tmpPVList c on  c.pvid = b.pvid' )
		EXEC ('SELECT CountryID ,Country ,Region ,DeliverableRootID , '+ @STr +'
		FROM #Pivot_Data
		pivot ( max(PVName) for PVID IN ('+ @STr +')
						) as PV' )
						  
	END
	ELSE
	BEGIN
		select agStatus.CountryID,	agStatus.Country,	agStatus.Region,	agStatus.DeliverableRootID 
		FROM  #AgencyStatus agStatus 
		LEFT JOIN #tmpAgencySummary b 
		ON agStatus.CountryID = b.CountryID 
		LEFT JOIN #tmpPVList c on  c.pvid = b.pvid 
	END;
		/* New Code #AgencyStatus*/
	DROP TABLE #AgencyStatus
	DROP TABLE #tmpAgencySummary
	DROP TABLE #tmpPVList
	DROP TABLE #Pivot_Data

SET NOCOUNT OFF
END
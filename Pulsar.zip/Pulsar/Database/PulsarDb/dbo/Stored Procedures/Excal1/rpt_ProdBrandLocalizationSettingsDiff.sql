﻿
CREATE PROCEDURE [dbo].[rpt_ProdBrandLocalizationSettingsDiff]
	@p_ProdBrandIDList VARCHAR(1000)
AS

/******************************************************************************
**	File: dbo.rpt_ProdBrandLocalizationSettingsDiff.sql
**	Name: rpt_ProdBrandLocalizationSettingsDiff
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  
*******************************************************************************/

SET NOCOUNT ON

CREATE TABLE #Diff
(
RegionID INT,
RegionCd VARCHAR(50)
)

INSERT INTO #Diff (RegionID, RegionCd)
SELECT LocalizationID, OptionConfig + ' (' + b.Abbreviation + ')'
FROM ProdBrandCountry_Localization pbcl with (NOLOCK) 
	INNER JOIN ProdBrand_Country pbc with (NOLOCK) ON pbc.ID = pbcl.ProdBrandCountryID
	INNER JOIN Regions r with (NOLOCK) ON pbcl.LocalizationID = r.ID
	INNER JOIN Business b with (NOLOCK) ON b.ID = pbc.BusinessID
WHERE 
	pbc.ProductBrandID IN (SELECT * FROM dbo.ufn_Split(@p_ProdBrandIdList, ','))
AND	COALESCE(pbcl.Keyboard, pbcl.KWL, pbcl.PowerCord, pbcl.DocKits, pbcl.RestoreMedia) IS NOT NULL
GROUP BY r.DisplayOrder, LocalizationID, OptionConfig, Abbreviation

CREATE TABLE #COLUMNS
( ID INT )

INSERT INTO #COLUMNS (ID)
VALUES (1)

DECLARE @v_ProdBrandID INT

DECLARE curProducts CURSOR FOR
SELECT * FROM dbo.ufn_Split(@p_ProdBrandIdList, ',')

OPEN curProducts

FETCH NEXT FROM curProducts
INTO @v_ProdBrandID

WHILE @@FETCH_STATUS = 0
BEGIN

    EXEC('ALTER TABLE #Diff ADD [' + @v_ProdBrandID + '] VARCHAR(6)')
    EXEC('UPDATE #Diff SET [' + @v_ProdBrandID + '] = dbo.ufn_GetBrandLocalizationCustomStatus(' + @v_ProdBrandID + ', RegionID)')

    EXEC('ALTER TABLE #COLUMNS ADD [' + @v_ProdBrandID + '] VARCHAR(100)')
    EXEC('UPDATE #COLUMNS SET [' + @v_ProdBrandID + '] = pv.dotsname + '' '' + b.Name FROM ProductFamily f INNER JOIN ProductVersion pv ON f.id = pv.ProductFamilyID INNER JOIN Product_Brand pb on pb.ProductVersionID = pv.ID INNER JOIN Brand b on pb.BrandID = b.ID WHERE pb.ID = ' + @v_ProdBrandID)
	
    FETCH NEXT FROM curProducts
    INTO @v_ProdBrandID

END

CLOSE curProducts
DEALLOCATE curProducts

EXEC('ALTER TABLE #Diff DROP COLUMN RegionID')
EXEC('ALTER TABLE #COLUMNS DROP COLUMN ID')

EXEC('SELECT ''RegionCD'' AS RegionCD, * FROM #COLUMNS')
EXEC('SELECT * FROM #Diff')

DROP TABLE #COLUMNS
DROP TABLE #Diff

SET NOCOUNT OFF





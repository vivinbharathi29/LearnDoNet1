﻿

/****** Object:  Stored Procedure dbo.spGetVersionsByVersionID    Script Date: 9/26/00 7:13:23 PM ******/
CREATE PROCEDURE [dbo].[spGetVersionsByVersionID]
 (
  @VersionID int
 )
As
 declare @RootID int 
 Select @RootID = DeliverableRootID from DeliverableVersion Where ID  = @VersionID
 SELECT Name, dr.id as RootID, version, revision,pass,status, location, vendorversion, latest, Targeted, Alert
 FROM DeliverableRoot dr with (NOLOCK), DeliverableVersion dv with (NOLOCK), Product_deliverable pd with (NOLOCK)  LEFT OUTER JOIN Alert a with (NOLOCK) ON pd.AlertID = a.ID
 WHERE dr.id = dv.deliverablerootid  
 AND pd.DeliverableVersionID = dv.ID
 AND dr.id = @RootID
 ORDER BY dv.version desc, dv.revision desc, dv.pass desc
 return 




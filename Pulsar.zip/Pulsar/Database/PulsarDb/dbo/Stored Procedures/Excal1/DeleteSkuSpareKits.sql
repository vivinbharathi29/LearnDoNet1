﻿-- =============================================
-- Author:		<Ron Foreman>
-- Create date: <5/16/2012>
-- Description:	<Return list of sku/spare kits to give option to delete>
-- =============================================
CREATE PROCEDURE [dbo].[DeleteSkuSpareKits]
	-- Add the parameters for the stored procedure here
@p_ProductBrandId int = 0,
@avno CHAR(50) = NULL	
AS

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
SET @avno = RTRIM(@avno)  
             SELECT     a.categoryname, a.SSKMapID, ServiceSpareKit_1.ID AS SSK_ID, ServiceSpareKit_1.SpareKitNo, ServiceSpareKit_1.Description, ServiceSpareKitMapAV_1.AvNo, 
                      ServiceSpareKitMapAV_1.ID AS SSKMAV_ID
FROM         ServiceSpareKitMapAV AS ServiceSpareKitMapAV_1 RIGHT OUTER JOIN
                          (SELECT     ServiceSpareCategory.categoryname, ServiceSpareKitMap.KMAT, ServiceSpareKitMapAV.AvNo, ServiceSpareKitMapAV.AvCategoryId, ServiceSpareKit.SpareKitNo, 
                                                   ServiceSpareKit.Description, ServiceSpareKitMap.ID AS SSKMapID
                            FROM          ServiceSpareKitMapAV RIGHT OUTER JOIN
                                                   ServiceSpareKitMap INNER JOIN
                                                   ServiceSpareKit ON ServiceSpareKitMap.SpareKitId = ServiceSpareKit.ID ON 
                                                   ServiceSpareKitMapAV.ServiceSpareKitMapId = ServiceSpareKitMap.ID
                                                   inner join ServiceSpareCategory on ServiceSpareCategory.id = ServiceSpareKit.SpareCategoryId
                             WHERE      (ServiceSpareKitMapAV.Status = 'A') AND (ServiceSpareKitMapAV.AvNo LIKE rtrim(@avno) + '%')) AS a ON 
                      ServiceSpareKitMapAV_1.ServiceSpareKitMapId = a.SSKMapID LEFT OUTER JOIN
                      ServiceSpareKit AS ServiceSpareKit_1 INNER JOIN
                      ServiceSpareKitMap AS ServiceSpareKitMap_1 ON ServiceSpareKit_1.ID = ServiceSpareKitMap_1.SpareKitId ON 
                      a.SSKMapID = ServiceSpareKitMap_1.ID


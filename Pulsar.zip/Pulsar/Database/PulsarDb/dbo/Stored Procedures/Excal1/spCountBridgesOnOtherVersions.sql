﻿

CREATE PROCEDURE [dbo].[spCountBridgesOnOtherVersions]
(
	@ProductID int,
	@VersionID int
)
AS

	DECLARE @RootID int
	DECLARE @VendorID int

	Select @RootID = DeliverableRootID, @VendorID = VendorID
	from deliverableVersion with (NOLOCK)
	where id = @VersionID


	Select Count(1) as BridgeCount, dbo.concatenate(distinct DeliverableRootID) as BridgedIDs
	from ProdDel_DelRoot with (NOLOCK)
	where bridged = 1 
	and ProductDeliverableID in (
								Select ID
								from Product_Deliverable with (NOLOCK)
								where ProductVersionID = @ProductID
								and DeliverableVersionID <> @VersionID
								and teststatusID > 1
								and DeliverableVersionID in (Select ID from DeliverableVersion with (NOLOCK) where DeliverableRootID = @RootID and VendorID = @VendorID)
								)


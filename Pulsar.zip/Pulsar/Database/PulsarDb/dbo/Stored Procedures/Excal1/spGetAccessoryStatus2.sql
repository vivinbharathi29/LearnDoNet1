﻿

CREATE PROCEDURE [dbo].[spGetAccessoryStatus2] 
	(
	@ID int
	)
AS
	Select Name
	from AccessoryStatus with (NOLOCK)
	where id = @ID



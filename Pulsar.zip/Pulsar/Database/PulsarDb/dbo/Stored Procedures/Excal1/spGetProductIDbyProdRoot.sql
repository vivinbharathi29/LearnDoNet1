﻿CREATE PROCEDURE [dbo].[spGetProductIDbyProdRoot]
/*
	Purpose: get product and release
	Created By:
	Modified By: Dien Bui 7/14/2017
				 Dien Bui 8/22/2017 - when pdr.id is null and @ProductDeliverableReleaseID is 0 query return nothing so wrap around it isnull
*/
(
	@ID int,
	@ProductDeliverableReleaseID int = 0
)
AS

Select pd.productversionid as ID, ReleaseID = isnull(releaseid, 0)
from product_delRoot pd with (NOLOCK) left outer join
Product_DelRoot_Release pdr with (NOLOCK) on pd.id = pdr.ProductDelRootID
where pd.id = @ID and isnull(pdr.ID,0) = @ProductDeliverableReleaseID
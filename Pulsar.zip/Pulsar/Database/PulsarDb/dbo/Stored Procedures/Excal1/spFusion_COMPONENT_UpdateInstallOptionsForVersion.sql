﻿
CREATE PROCEDURE spFusion_COMPONENT_UpdateInstallOptionsForVersion
(
	@VersionID int,
	@Updater varchar(64)=''
)
AS
BEGIN

	if @Updater = ''
		set @Updater = 'Excalibur'

	Declare @InstallType int
	Declare @InstallID int
	Declare @IRSPassID int
	Declare @TypeList varchar(max)
	Declare @IDList varchar(max)
	set @TypeList =''
	set @IDList =''
	
	DECLARE IRSFeedInstallOption_CURSOR CURSOR FOR Select cast (i.combination as int) + 1 as InstallOptionType, i.irsid as InstallOptionID, c.irsid as IRSPassID 
												from ComponentVersion_InstallOption ci join 
													CommonInstallOption i on ci.installoptionid = i.id join
													deliverableversion c on c.id = ci.componentversionid
												where c.id = @VersionID

		
	open IRSFeedInstallOption_CURSOR
	
	FETCH NEXT FROM IRSFeedInstallOption_CURSOR Into @InstallType,@InstallID,@IRSPassID
	WHILE (@@fetch_status <> -1)
		BEGIN
			If (@@fetch_status <> -2)
				BEGIN
					if @TypeList = ''
						begin
							set @TypeList = cast(@InstallType as varchar(2))
							set @IDList = cast(@InstallID as varchar(20))
						end
					else
						begin
							set @TypeList = @TypeList + ',' + cast(@InstallType as varchar(2))
							set @IDList = @IDList + ',' + cast(@InstallID as varchar(20))
						end
				END
			FETCH NEXT FROM IRSFeedInstallOption_CURSOR Into @InstallType,@InstallID,@IRSPassID
		END
	DEALLOCATE IRSFeedInstallOption_CURSOR

	/*
	print @Typelist
	print @IDlist
	print @VersionID
	print @IRSPassID
	*/
	

	IF (@IRSPassID IS NULL)
		Select @IRSPassID =  IRSID From deliverableversion Where id = @VersionID

	exec IRS_usp_LCM_SaveCompInstallOption_PreInstall @p_intComponentPassID=@IRSPassID,@p_NewIOList=@IDlist,@p_IOTypeList=@Typelist,@p_chrUpdater=@Updater

--exec usp_LCM_SaveCompInstallOption_PreInstall @p_intComponentPassID=313599,@p_NewIOList=N'297,259,260,225,226,399,422',@p_IOTypeList=N'1,1,1,2,2,1,1',@p_chrUpdater=N'wgomero'
end

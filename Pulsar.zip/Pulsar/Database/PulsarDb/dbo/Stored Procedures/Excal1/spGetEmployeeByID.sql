﻿

CREATE PROCEDURE [dbo].[spGetEmployeeByID]
(
 @ID as int
)
As
Select e.id, e.Name as Name, e.Email as Email, Division, Phone, NTName, WorkgroupID, Partnerid, SystemAdmin, Domain, PreinstallPM
From Employee e with (NOLOCK)
Where ID = @ID
 
return





﻿

CREATE PROCEDURE [dbo].[spAddServer]
(
	@Name varchar(255)
)
 AS
DECLARE @ServerCount int 
Select @ServerCount = Count(ID)  from server with (NOLOCK) where Name = @Name
if @ServerCount = 0 and @Name <> ''
     Begin
	Insert Server(Name)
	Values (@Name)
    End




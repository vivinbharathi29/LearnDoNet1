﻿
CREATE PROCEDURE [dbo].[spListActionItems4Status]
(
	@ProdID		int,
	@Type		int,
	@StartDt	Datetime	= NULL,
	@EndDt		Datetime	= NULL,
	@BiosChange	BIT			= NULL
)
 AS
	
/******************************************************************************
**	File: dbo.spListActionItems4Status.sql
**	Name: spListActionItems4Status
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  
*******************************************************************************/

SELECT     
	v.dotsname AS Product, i.Submitter, i.ID, i.Type, i.LastModified AS Updated, i.Status, e.Name AS Owner, i.Summary, i.Description, i.Created, 
	i.TargetDate, i.ActualDate, '<Project Issue>' AS Deliverable, ct.Name AS CoreTeamRep, i.Approvals, i.Justification, i.Actions, i.Resolution
FROM         
	CoreTeamRep AS ct with (NOLOCK) RIGHT OUTER JOIN
	DeliverableIssues AS i with (NOLOCK) INNER JOIN
	ProductVersion AS v with (NOLOCK) INNER JOIN
	ProductFamily AS f with (NOLOCK) ON v.ProductFamilyID = f.ID ON i.ProductVersionID = v.ID INNER JOIN
	Employee AS e with (NOLOCK) ON i.OwnerID = e.ID ON ct.ID = i.CoreTeamRep
WHERE     
	(i.ProductVersionID = @ProdID) AND (i.Type = @Type) 
	AND (i.OnStatusReport <> 1) 
	AND (i.Status IN (1, 3, 6)
	AND (@BiosChange IS NULL 
	 OR (@BiosChange = 1 AND i.BiosChange = @BiosChange) 
	 OR (@BiosChange = 0 AND 
		(i.BiosChange = 0 OR ((COALESCE(i.ImageChange, 0) | COALESCE(i.SkuChange, 0) | COALESCE(i.ReqChange, 0) | COALESCE(i.DocChange,0) | COALESCE(i.CommodityChange, 0) | COALESCE(i.OtherChange, 0) = 1 AND i.BiosChange = 1)))))
	) 
	OR 
	((i.ProductVersionID = @ProdID)
	AND (i.Type = @Type) 
	AND (i.OnStatusReport <> 1) 
	AND (i.ActualDate BETWEEN COALESCE (@StartDt, GETDATE() - 14) 
	AND COALESCE (@EndDt + 1, GETDATE()))
	AND (@BiosChange IS NULL 
	 OR (@BiosChange = 1 AND i.BiosChange = @BiosChange) 
	 OR (@BiosChange = 0 AND 
		(i.BiosChange = 0 OR ((COALESCE(i.ImageChange, 0) | COALESCE(i.SkuChange, 0) | COALESCE(i.ReqChange, 0) | COALESCE(i.DocChange,0) | COALESCE(i.CommodityChange, 0) | COALESCE(i.OtherChange, 0) = 1 AND i.BiosChange = 1))))))
ORDER BY i.ActualDate, i.ID




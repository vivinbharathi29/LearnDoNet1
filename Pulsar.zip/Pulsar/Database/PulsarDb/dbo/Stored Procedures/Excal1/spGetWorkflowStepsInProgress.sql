﻿

CREATE PROCEDURE [dbo].[spGetWorkflowStepsInProgress]
(
 @DelID int
)
 AS
SELECT distinct ds.ID, ds.Milestone, ds.MilestoneOrder, dw.Notify, dw.ReportMilestone,dw.NotifyConsumerSpecific, dw.NotifyCommercialSpecific
FROM 
	DeliverableSchedule ds with (NOLOCK)
	inner join Language_DelVer ld with (NOLOCK) on ds.ID = ld.MilestoneID
	left outer join DeliverableWorkflowDefinitions dw with (NOLOCK) on dw.ID = ds.DefinitionID
WHERE ds.DeliverableVersionID = @DelID
And  (ds.StatusID = 1 or ds.StatusID = 4)
Order By ds.MilestoneOrder

﻿

CREATE PROCEDURE [dbo].[spGetLanguages] AS
Select ID, Language, Abbreviation
From Language with (NOLOCK)
WHERE IsLanguage = 1
Order By OrderID, Language




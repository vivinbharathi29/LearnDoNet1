﻿/** Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
	1	 2/12/2016 - Harris, Valerie - BUG 15660/ Task 16234 - If Type 3, Add Release section email to capture Product's selected Releases for DCR    
	2	 3/20/2018 - Aashish     Removes table Product Family from Join  
****************************************************************************************************/
CREATE PROCEDURE [dbo].[Spgetaction4mail]     
      (@ID int)      
AS       
      
SELECT       
    pv.EmailActive,    
    i.ID,     
    i.Summary,     
    i.Created,     
    c.Name AS Category,     
    ct.Name AS CoreTeamRep,     
    i.OnStatusReport,     
    i.Submitter,     
    i.Notify,     
    i.BTODate,       
    i.CTODate,    
    i.Distribution,     
    i.Priority,     
    i.AffectsCustomers,     
    pv.dotsname AS Program,     
    i.ProductVersionRelease,     
    i.Type,     
    i.Status,     
    e.Name AS Owner,     
    i.TargetDate,       
    i.ActualDate,     
    i.Description,     
    i.Actions,     
    i.Resolution,     
    e.Email,     
    i.Consumer,     
    i.Commercial,     
    i.SMB,     
    i.AvailableNotes,     
    i.Approvals,     
    i.Justification,       
    dr.Name AS DeliverableRoot      
FROM       -- ProductFamily AS pf with (NOLOCK) INNER JOIN      
           (SELECT * FROM DeliverableIssues AS i with (NOLOCK)  
     WHERE      i.ID = @ID) i --ON pf.ID = pv.ProductFamilyID     
   INNER JOIN   ProductVersion AS pv with (NOLOCK)   
   ON pv.ID = i.ProductVersionID    
   LEFT OUTER JOIN ActionCategory AS c with (NOLOCK)     
   ON i.CategoryID = c.ID     
   LEFT OUTER JOIN CoreTeamRep AS ct with (NOLOCK)     
   ON i.CoreTeamRep = ct.ID     
   LEFT OUTER JOIN Employee AS e with (NOLOCK)     
   ON i.OwnerID = e.ID     
   LEFT OUTER JOIN DeliverableRoot AS dr with (NOLOCK)     
   ON i.DeliverableRootID = dr.ID      
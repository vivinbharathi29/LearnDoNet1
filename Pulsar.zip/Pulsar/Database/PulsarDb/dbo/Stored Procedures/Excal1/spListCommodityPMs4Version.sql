﻿/* ************************************************************************************************
 * Purpose:	get the email addresses of the PMs for a specific version (used to decode the tag [PM] in the 'Notify' field in the workflow definitions)
 * Created By:	
 * Modified by: 06 Apr 2016 poletto replaced employee view with userinfo table, excluded inactive users
 *
  **************************************************************************************************/

CREATE PROCEDURE [dbo].[spListCommodityPMs4Version]

(
	@ID int
)

AS
BEGIN
	
DECLARE @FieldName as varchar(200),
	@sql as varchar(8000)

Select @FieldName = ct.PMFieldName 
from deliverableversion v 
INNER JOIN deliverableroot r ON r.id = v.deliverablerootid
INNER JOIN deliverablecategory c ON c.id = r.categoryid
INNER JOIN DeliverableCategoryTeam ct ON ct.id = c.teamid
where v.id = @ID

SET @sql = 'Select Distinct e.UserId as id, e.FullName as name, e.email 
			from product_deliverable pd 
			inner join productversion v ON v.id = pd.productversionid
			inner join userinfo e ON e.UserId = v.[' + @FieldName + ']
			where ((e.IsHp=1 AND e.IsActiveInGAL=1) OR (e.IsHp=0 AND e.[Disabled] IS NULL)) AND pd.deliverableversionid=' + cast(@ID as varchar(20))
exec (@sql)

END


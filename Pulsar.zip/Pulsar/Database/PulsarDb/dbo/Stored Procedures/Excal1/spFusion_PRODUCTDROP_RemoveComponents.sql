﻿/**************************************************************************************************    
/* ************************************************************************************************
 * Purpose:		Remove components from an IRS product drop
 * Created By:	07/29/2013 JCope
 * Modified By:	
 **************************************************************************************************/
**************************************************************************************************    
** Change History           
**************************************************************************************************    
** SNo   Date        Author             Description           
** --    --------   -------             -------------------------           
 ** 1    27/12/2018  Santhana K			Changed the Text Data type to Varchar(max)
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spFusion_PRODUCTDROP_RemoveComponents]

	@p_intPDID int,
	@p_xmlComponentPassID Varchar(max),
	@p_chrHTChangeReason varchar(255),
	@p_chrUpdater varchar(18),
	@p_bitDeleteFromOtherDrop bit,
	@p_Error int output
AS
	exec IRSTest_usp_IRS2_PD_RemoveComponents @p_intPDID, @p_xmlComponentPassID, @p_chrHTChangeReason, @p_chrUpdater, @p_bitDeleteFromOtherDrop

	if @@error <> 0 begin
		raiserror('Error:spFusion_PRODUCTDROP_RemoveComponents - Error returned from IRSTest_usp_IRS2_PD_RemoveComponents.', 16, 1)
		set @p_Error = 1
		return 1
	end

	set @p_Error = 0
	return 0

GO



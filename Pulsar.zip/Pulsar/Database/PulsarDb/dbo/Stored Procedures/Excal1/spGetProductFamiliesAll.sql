﻿

CREATE PROCEDURE [dbo].[spGetProductFamiliesAll] AS
SELECT Name, ID, active
FROM ProductFamily with (NOLOCK)
Order By Name





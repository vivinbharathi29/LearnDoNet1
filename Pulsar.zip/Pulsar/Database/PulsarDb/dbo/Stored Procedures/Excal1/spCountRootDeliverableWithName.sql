﻿

CREATE PROCEDURE [dbo].[spCountRootDeliverableWithName]
(
	@Name varchar(120),
	@ID int
)
AS

	Select Count(1) as RootCount
	from DeliverableRoot with (NOLOCK)
	Where Name = @Name
	and id <> @ID


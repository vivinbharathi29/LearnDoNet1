﻿

CREATE PROCEDURE [dbo].[spListActionSponsor]

AS

Select ID, Name
from ActionSponsor with (NOLOCK)
where Active=1
order by Name




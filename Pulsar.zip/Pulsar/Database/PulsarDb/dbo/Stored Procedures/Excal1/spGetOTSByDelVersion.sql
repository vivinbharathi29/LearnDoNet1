﻿/**************************************************************************************************
** Author  : Vignesh(auth\thangarv)      
** Description : TO get the lit of OTS Deliverables Versions.   
** Date   :12/12/2017      
**************************************************************************************************
** Change History      
**************************************************************************************************
** SNo   Date        Author  Description      
** --    --------   -------   -------------------------      
**  01	02/15/2018	Santhana(auth\prabhuks) View Name changed from si_observation_report to SI_Observation_Report_Simplified 
**	02	04/05/2018	Aashish		Changed the code to ANSI and added SET NOCOUNT
**  03  24/7/2018   Monica		Filtered table before joining
**  04	11/12/2018	Santhana	OTSNumber is stored in local variable to improve remote query performance
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spGetOTSByDelVersion]
(
  @DelVerID int
)
AS
	/*
	 SET NOCOUNT ON
     Select od.OTSNumber, 
	 o.shortdescription, 
	 o.[Priority], 
	 o.stepstoreproduce, 
	 o.ProductFamily as cycle, 
	 o.PrimaryProduct as systemboard, 
	 o.PrimaryProduct as [platform]
     FROM (SELECT od.OTSNumber FROM 
		 OTS_DelVer od WITH (NOLOCK)
		  Where od.DeliverableVersionid = @DelVerID)od
	 INNER JOIN HOUSIREPORT01.SIO.dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
	 ON o.observationID = od.OTSNumber    
	 SET NOCOUNT OFF
	 */
  
	DECLARE @OTSNumber varchar(MAX) 
	SELECT 
	@OTSNumber = COALESCE(@OTSNumber + ', ', '') +   CAST(od.OTSNumber AS varchar(10))  
	FROM 
	OTS_DelVer od WITH (NOLOCK)
	Where od.DeliverableVersionid = @DelVerID

	  IF  ISNULL(@OTSNumber,'') <>''
	  SELECT @OTSNumber=SUBSTRING(@OTSNumber,1,LEN(@OTSNumber))  

	  Declare @varDelVerID varchar(100)

	  SET @OTSNumber= ISNULL(@OTSNumber,'''''')
	  SET @varDelVerID = ISNULL(CAST(@DelVerID AS varchar(100)),'''''')


	  DECLARE @Query varchar(max) 

	  set @Query ='Select od.OTSNumber, 
		 o.shortdescription, 
		 o.[Priority], 
		 o.stepstoreproduce, 
		 o.ProductFamily as cycle, 
		 o.PrimaryProduct as systemboard, 
		 o.PrimaryProduct as [platform]
		 FROM (SELECT od.OTSNumber FROM 
			 OTS_DelVer od WITH (NOLOCK)
			  Where od.DeliverableVersionid ='+ @varDelVerID  + ') od
		 INNER JOIN HOUSIREPORT01.SIO.dbo.SI_Observation_Report_Simplified o WITH (NOLOCK) ON o.observationID = od.OTSNumber 
		 where o.observationID  in (' + @OTSNumber + ')'
		
		 EXEC(@Query)
GO



﻿/**************************************************************************************************
** Change History    
**************************************************************************************************
** SNo   Date        Author  Description    
** --    --------   -------   -------------------------    
**  1    01/08/2018	Aashish	  Added SET NOCOUNT. Changed COALESCE to ISNULL.
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spDeleteProfile]
(
	@ID int,
	@EmployeeID int=null
)
 AS

--SET NOCOUNT ON

Delete ReportProfiles
Where ID = @ID
and EmployeeID = ISNULL(@EmployeeID,EmployeeID)

--SET NOCOUNT OFF

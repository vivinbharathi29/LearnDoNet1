﻿CREATE PROCEDURE [dbo].[spGetSubassemblyBridgeRelease]
/* ************************************************************************************************
 * Purpose: Get Subassembly Bridge
 * Created By: Dien Bui
 * Modified By: 
 **************************************************************************************************/
(
	@ProdDelRelID int,
	@RootID int
)
AS

select pddr.bridged, p.dotsname as Product, v.deliverablename, v.partnumber, s.name as SubassemblyName, pdrr.subassembly
from  deliverableversion v with (NOLOCK)
inner join product_deliverable pd with (NOLOCK) on pd.deliverableversionid = v.id
inner join ProdDel_DelRoot pddr with (NOLOCK) on pd.id = pddr.productdeliverableid
inner join deliverableroot as s with (NOLOCK) on s.id = pddr.deliverablerootid
inner join product_delroot pdr with (NOLOCK) on pd.productversionid = pdr.productversionid and s.id = pdr.deliverablerootid
inner join productversion p with (NOLOCK) on p.id = pd.productversionid
inner join Product_Deliverable_Release pdrel with (NOLOCK) on pdrel.ProductDeliverableID = pd.id 
inner join Product_DelRoot_Release pdrr with (NOLOCK) on pdrr.ProductDelRootID = pdr.ID and pdrr.ReleaseID = pdrel.ReleaseID
where pdrel.ID = @ProdDelRelID
and pddr.DeliverableRootID = @RootID




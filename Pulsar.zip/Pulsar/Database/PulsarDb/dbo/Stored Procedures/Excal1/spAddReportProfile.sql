﻿

CREATE PROCEDURE [dbo].[spAddReportProfile] 
(
	@EmployeeID int,
	@ProfileName varchar(120),
	@ProfileType int,
	@PageLayout varchar(max),
	@SelectedFilters varchar(max),
	@TodayPageLink int = 0,
	@DefaultReport int = 0,
	@NewID int Output
)
AS

	Insert Into ReportProfiles(EmployeeID,ProfileName,ProfileType,PageLayout,SelectedFilters, TodayPageLink, DefaultReport)
	values(@EmployeeID,@ProfileName,@ProfileType,@PageLayout,@SelectedFilters, @TodayPageLink, @DefaultReport) 
	
	SELECT @NewID = SCOPE_IDENTITY()



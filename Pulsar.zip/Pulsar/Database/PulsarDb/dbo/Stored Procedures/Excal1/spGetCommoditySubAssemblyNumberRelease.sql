﻿CREATE PROCEDURE [dbo].[spGetCommoditySubAssemblyNumberRelease]
(
	@ProductID int,
	@RootID int,
	@ReleaseID int = 0
)
 AS

if @ProductID=0 and @ReleaseID = 0
	Select 0 as ID, '' as Product, 0 as ProductID, r.id as RootID, r.name as Deliverable, '' as Spin, '' as subassembly
	from Deliverableroot r WITH (NOLOCK)
	where r.id=@RootID
else
	Select pd.id, 
	v.dotsname as Product, 
	v.id as ProductID, 
	r.id as RootID, 
	r.name as Deliverable, 
	pdrr.Spin, 
	pdrr.base as subassembly, 
	isnull(pdrr.ServiceSpin,'') as Servicespin, 
	isnull(pdrr.Servicebase,'') as Servicesubassembly
	from product_delroot pd WITH (NOLOCK) 
	inner join product_delroot_release pdrr WITH (NOLOCK) on pdrr.ProductDelRootID = pd.ID
	inner join productversion v WITH (NOLOCK) on v.id = pd.productversionid
	inner join productfamily f WITH (NOLOCK) on f.id=v.productfamilyid
	inner join Deliverableroot r WITH (NOLOCK) on r.id = pd.deliverablerootid
	where pd.DeliverableRootid=@RootID
	and pd.ProductVersionid=@ProductID
	and pdrr.ReleaseID = @ReleaseID
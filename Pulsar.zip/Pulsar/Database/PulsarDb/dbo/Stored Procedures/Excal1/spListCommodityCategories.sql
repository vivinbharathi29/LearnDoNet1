﻿
CREATE PROCEDURE [dbo].[spListCommodityCategories] 

AS

Select ID, Name,DeliverableTypeID
from DeliverableCategory with (NOLOCK)
where commodity=1
order by name



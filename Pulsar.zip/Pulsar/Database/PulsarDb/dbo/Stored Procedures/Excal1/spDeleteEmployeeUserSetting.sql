﻿
CREATE PROCEDURE [dbo].[spDeleteEmployeeUserSetting]
(
	@ID int
)

 AS

	Delete Employee_UserSettings 
	where ID=@ID



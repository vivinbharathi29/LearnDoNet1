﻿

CREATE PROCEDURE [dbo].[spAddRequirement2ProductWeb]
(
 @ReqID int,
 @ProdID int
)
 AS
INSERT Product_Requirement (ProductID,RequirementID, DeliverablesSaved,CopyProductID,Deliverables,Specification)
Values(@ProdID,@ReqID,0,0,'','')




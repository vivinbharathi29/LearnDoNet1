﻿

CREATE PROCEDURE [dbo].[spListActionApprovers] AS
Select Distinct  e.ID, e.Name as Approver
FROM ActionApproval a with (NOLOCK), Employee e with (NOLOCK)
Where a.ApproverID = e.ID
Order By e.Name asc




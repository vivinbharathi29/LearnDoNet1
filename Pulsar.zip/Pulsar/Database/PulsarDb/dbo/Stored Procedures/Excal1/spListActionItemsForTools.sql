﻿

CREATE PROCEDURE [dbo].[spListActionItemsForTools]
(
	@ProductID int,
	@TypeID int,
	@OwnerID int
)
 AS

if @TypeID=0 --working list
	Begin
	if @OwnerID = 0 -- all
		Select a.displayorder, a.id, a.summary, a.type, a.priority, r.summary as Roadmap, s.name as Status, e.name as owner, a.targetdate, r.timeframe, a.description
		 FROM 
			deliverableissues a WITH (NOLOCK)
			INNER JOIN employee e WITH (NOLOCK) ON e.id = a.ownerid 
			INNER JOIN ActionStatus s WITH (NOLOCK) ON s.id = a.status 
			LEFT OUTER JOIN actionroadmap r WITH (NOLOCK) ON r.id = a.actionroadmapid
		where a.status in (1,7) 
		and a.type in (1,2)
		and a.PendingImplementation=1
		and a.productversionid =@ProductID
		order by a.displayorder,a.priority
	else --mine
		Select a.displayorder,a.id, a.summary, a.type, a.priority, r.summary as Roadmap, s.name as Status, e.name as owner, a.targetdate,r.timeframe , a.description
		FROM 
			deliverableissues a WITH (NOLOCK)
			INNER JOIN employee e WITH (NOLOCK) ON e.id = a.ownerid 
			INNER JOIN ActionStatus s WITH (NOLOCK) ON s.id = a.status 
			LEFT OUTER JOIN actionroadmap r WITH (NOLOCK) ON r.id = a.actionroadmapid
		where a.status in (1,7)
		and a.ownerid  = @OwnerID
		and a.type in (1,2)
		and a.PendingImplementation=1
		and a.productversionid =@ProductID
		order by a.displayorder,a.priority
	end

else --specific type
	Begin
	if @OwnerID = 0 --all
		Select a.displayorder,a.id, a.summary, a.type, a.priority, r.summary as Roadmap, s.name as Status, e.name as owner, a.targetdate, r.timeframe, a.description
		FROM 
			deliverableissues a WITH (NOLOCK)
			INNER JOIN employee e WITH (NOLOCK) ON e.id = a.ownerid 
			INNER JOIN ActionStatus s WITH (NOLOCK) ON s.id = a.status 
			LEFT OUTER JOIN actionroadmap r WITH (NOLOCK) ON r.id = a.actionroadmapid
		where a.status in (1,7)
		and a.type=@TypeID 
		and a.productversionid =@ProductID
		order by a.displayorder,a.priority
	else --mine
		Select a.displayorder,a.id, a.summary, a.type, a.priority, r.summary as Roadmap, s.name as Status, e.name as owner, a.targetdate, r.timeframe, a.description
		FROM 
			deliverableissues a WITH (NOLOCK)
			INNER JOIN employee e WITH (NOLOCK) ON e.id = a.ownerid 
			INNER JOIN ActionStatus s WITH (NOLOCK) ON s.id = a.status 
			LEFT OUTER JOIN actionroadmap r WITH (NOLOCK) ON r.id = a.actionroadmapid
		where a.status in (1,7)
		and a.ownerid  = @OwnerID
		and a.type=@TypeID 
		and a.productversionid =@ProductID
		order by a.displayorder,a.priority
	End


﻿/**************************************************************************************************    
** Author  :       
** Description :           
** Date   :    
**************************************************************************************************    
** Change History           
**************************************************************************************************    
** SNo   Date        Author            Description           
** --    --------   -------            -------------------------           
 ** 1    27/12/2018  Santhana K		Changed the Text Data type to Varchar(max) for @Actions and @Resolution
****************************************************************************************************/ 
CREATE PROCEDURE [dbo].[spAddDeliverableActionWeb]
(
 @ProductID int,
 @Type tinyint,
 @Status tinyint,
 @Submitter varchar(50),
 @SubmitterID int,
 @CategoryID int,
 @OwnerID int,
 @PreinstallOwner int,
 @AffectsCustomers tinyint,
 @CoreTeamID int,
 @RoadmapID int,
 @SponsorID int,
 @Duration int,
 @DisplayOrder int,
 @TargetDate datetime,
 @TestDate datetime,
 @TestNote varchar(35),
 @BTODate datetime,
 @CTODate datetime,
 @Distribution varchar(4),
 @Notify varchar(8000),
 @OnStatus tinyint,
 @Priority tinyint,
 @Commercial bit,
 @Consumer bit,
 @SMB bit,
 @APD bit,
 @CKK bit,
 @EMEA bit,
 @LA bit,
 @NA bit,
 @GCD bit,
 @AddChange bit,
 @ModifyChange bit,
 @RemoveChange bit,
 @ImageChange bit,
 @CommodityChange bit,
 @DocChange bit,
 @SKUChange bit,
 @ReqChange bit,
 @OtherChange bit,
 @PendingImplementation bit,
 @Summary varchar(120),
 @Description varchar(8000),
 @Justification varchar(8000),
 @Actions Varchar(max),
 @Resolution Varchar(max),
 @StatusNotes varchar(5000) = null,
 @NewID int Output
)
 AS

Declare @MaxDisplayOrder as integer
Declare @NewDisplayOrder as integer

--Update Display Order for all issues moving down in the order

Select @MaxDisplayOrder = coalesce(max(coalesce(DisplayOrder,0)),0)
from deliverableissues with (NOLOCK)
where PendingImplementation=1
--and productversionid = @ProductID
and status <> 2
and ownerid = @Ownerid

if @DisplayOrder =0 or @DisplayOrder > @MaxDisplayOrder
	Select @NewDisplayOrder= @MaxDisplayOrder+1
else
	Begin
	
	Select @NewDisplayOrder= @DisplayOrder


	Update DeliverableIssues
	set DisplayOrder = DisplayOrder + 1
	where status <> 2
	and ownerid = @Ownerid
	and PendingImplementation=1
	and DisplayOrder >= @NewDisplayOrder

	end


-- Add The Record
Declare @ActualDate datetime

if @Status=2 or @Status=4 or @Status=5 
	Select @ActualDate = getdate()
else
	Select @ActualDate = null

---------------------------------------------------
Declare @StatusNotesUpdatedDt datetime
Declare @OriginalTargetDt     datetime

If (RTRIM(LTRIM(@StatusNotes)) <> '' and @StatusNotes is not null)
  Begin
    Set @StatusNotesUpdatedDt = GETDATE()
  End
Else
  Begin
    Set @StatusNotesUpdatedDt = NULL
  End

If @TargetDate > ''
  Begin
    Set @OriginalTargetDt = @TargetDate
  End 
Else
  Begin
    Set @OriginalTargetDt = NULL
  End
--------------------------------------------------  

INSERT DeliverableIssues(SubmitterID,DisplayOrder,Duration, SponsorID,ActionRoadmapID,ActualDate,AvailableForTest,AvailableNotes,Commercial, Consumer, SMB, ImageChange, CommodityChange, DocChange, SKUChange,ReqChange,OtherChange,PendingImplementation,PreinstallOwnerID,AffectsCustomers,Priority, AddChange, ModifyChange, RemoveChange, APD, CKK, EMEA, LA, NA,GCD,Justification, CTODate,BTODate, Distribution, Summary, CoreTeamRep,CategoryID, Submitter, DeliverableRootID, Productversionid,Type,Status, OwnerID,TargetDate,Description,Notify,OnStatusReport,Actions,Resolution,Created, BiosChange,SwChange,StatusNotesUpdatedDt, OriginalTargetDt, StatusNotes)
VALUES(@SubmitterID,@NewDisplayOrder,@Duration, @SponsorID,@RoadmapID,@ActualDate,@TestDate,@TestNote,@Commercial, @Consumer, @SMB, @ImageChange, @CommodityChange,@DocChange, @SKUChange,@ReqChange,@OtherChange,@PendingImplementation,@PreinstallOwner,@AffectsCustomers, @Priority, @AddChange, @ModifyChange, @RemoveChange, @APD, @CKK, @EMEA, @LA, @NA,@GCD,@Justification, @CTODate,@BTODate, @Distribution,@Summary, @CoreTeamID,@CategoryID,@Submitter, 0, @ProductID,@Type,@Status, @OwnerID,@TargetDate,@Description,@Notify,@OnStatus,@Actions,@Resolution, getdate(),0,0,@StatusNotesUpdatedDt, @OriginalTargetDt, @StatusNotes)
SELECT @NewID = SCOPE_IDENTITY()

GO



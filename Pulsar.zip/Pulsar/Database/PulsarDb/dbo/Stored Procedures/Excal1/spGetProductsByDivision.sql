﻿

CREATE PROCEDURE [dbo].[spGetProductsByDivision]
	(
		@Div tinyint
	)
 AS
 -- =============================================
-- Author:		
-- Description:	get the list of products
-- Modified By: 05/06/2016	wgomero add extra column to return if the product is legacy or Pulsar product; in addition, sort the query by DOTSName
-- =============================================
	SELECT v.ID as ID, p.Name as Name, v.partnerid, v.Version as Version, e.Name as PM, v.Distribution, v.PRDReleased, v.PDDReleased, v.OnlineReports, e2.Name as SEPM, v.typeid
		, p.Name + '' + v.Version as FullName,v.dotsname
		,(p.name + ' - ' + v.dotsname ) as ProductName
		, IsPulsarProduct = CASE
								 WHEN v.FusionRequirements IS NULL then 0
								 ELSE 1
								 END
	FROM ProductFamily p with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) ON p.id = v.ProductFamilyID
		left outer join Employee e with (NOLOCK) on e.id = v.pmid
		left outer join Employee e2 with (NOLOCK) on e2.ID = v.SEPMID
	WHERE 
		v.productstatusid< 5
		--And (v.Active = 1 or v.sustaining = 1)
		and (v.Division is null or v.division=@Div)
		Order BY DOTSName, Version

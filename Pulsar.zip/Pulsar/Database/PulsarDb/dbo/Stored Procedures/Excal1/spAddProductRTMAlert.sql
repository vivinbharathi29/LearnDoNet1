﻿

CREATE PROCEDURE [dbo].[spAddProductRTMAlert]
(
	@ReportSectionID int,
	@UserID int,
	@ProductID int,
	@AlertHTML varchar(max),
	@RTMID int=0,
	@NewID int output
)
AS

	DECLARE @ID int
	if @RTMID=0
		begin
			Select @ID= ID
			from ProductRTMAlerts with (NOLOCK)
			where ReportSectionID = @ReportSectionID
			and UserID = @UserID
			and ProductID = @ProductID
			and (ProductRTMID is null or ProductRTMID=0)
		end
	else
		begin
			Select @ID= ID
			from ProductRTMAlerts with (NOLOCK)
			where ReportSectionID = @ReportSectionID
			and UserID = @UserID
			and ProductID = @ProductID
			and ProductRTMID=@RTMID
		end
	if @ID is null
		begin
	
		insert into ProductRTMAlerts(ProductRTMID,ReportSectionID,AlertHTML, UserID, productID)
		values(0,@ReportSectionID,@AlertHTML, @UserID, @productID)
		
		Select @NewID = SCOPE_IDENTITY()
		
		end
	else
		begin
		
		update  productRTMAlerts
		set LastUpdated=getDate(),ReportSectionID=@ReportSectionID,AlertHTML=@AlertHTML, UserID=@UserID, productID=@ProductID
		where id = @ID
		
		Select @NewID = @ID
		end 
	
		


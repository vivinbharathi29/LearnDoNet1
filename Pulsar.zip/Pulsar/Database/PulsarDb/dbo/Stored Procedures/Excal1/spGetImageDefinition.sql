﻿

CREATE PROCEDURE [dbo].[spGetImageDefinition]
(
	@ID int
)
 AS
SELECT     
	i.ID, i.SKUNumber, i.BrandID, b.Name AS Brand, 
	i.OSID, o.Name AS OS, i.SWID, s.Name AS SWType, 
	s.Name AS SW, i.ImageType, i.Modified, i.StatusID, 
	ss.Name AS Status, i.RTMDate, i.Comments,i.imagetypeid,
	i.ImageDriveDefinitionId, d.DriveName, t.ID as ImageTypeID, t.name as ImageTypeName
FROM         
	ImageDefinitions AS i with (NOLOCK) 
    INNER JOIN ImageType AS t with (NOLOCK) ON i.ImageTypeID = t.ID 
    INNER JOIN Brand AS b with (NOLOCK) ON i.BrandID = b.ID 
    INNER JOIN OSLookup AS o with (NOLOCK) ON i.OSID = o.ID 
    INNER JOIN ImageSWType AS s with (NOLOCK) ON i.SWID = s.ID 
    INNER JOIN ImageStatus AS ss with (NOLOCK) ON i.StatusID = ss.ID 
    LEFT OUTER JOIN ImageDriveDefinition AS d with (NOLOCK) ON i.ImageDriveDefinitionID = d.ID
WHERE     
	(i.ID = @ID)


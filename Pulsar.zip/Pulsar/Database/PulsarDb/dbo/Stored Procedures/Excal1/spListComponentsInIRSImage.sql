﻿CREATE PROCEDURE [dbo].[spListComponentsInIRSImage]
/* ************************************************************************************************
 * Purpose:		
 * Created By:	Unknown
 * Modified By:	10/18/2016 linshant, PBI 26488 - get the install option of every components
				11/28/2016 linshant, PBI 29943 - update sort order depend on user selection
				05/08/2018 Santhana Removed the DBName prefix from ProductDrop 
				06/20/2018 linshant - Sync Images with IRS to consider Component Version's Destination Country/Region and Image Locale settings - PBI 208895
				08/28/2018 linshant - Improve Sync Image with IRS and Add to Product Explorer UI - PBI 140346
 **************************************************************************************************/
	(
		@p_chrPDName as varchar(128)
	)
AS
	SET NOCOUNT ON
	DECLARE @intPDID int, @pvid int, @dotsname varchar(100)

	SELECT TOP 1 @pvid = pv.ID, @dotsname = pv.DotsName FROM ProductVersion_ProductDrop pvpd 
	INNER JOIN ProductDrop1 pd1 WITH (NOLOCK) ON pvpd.ProductDropID = pd1.ID
	INNER JOIN ProductVersion pv WITH (NOLOCK) ON pvpd.ProductVersionID = pv.ID
	WHERE pd1.Name = @p_chrPDName ORDER BY pv.ID

	SELECT	@intPDID = ProductDropID FROM IRS_ProductDrop WITH (NOLOCK) WHERE Name = @p_chrPDName
	
	CREATE TABLE #Comp (ComponentPassID int, ComponentTypeID int, Name varchar(80), Partno varchar(18), Version varchar(20), Revision varchar(10), 
	Pass varchar(5), creator varchar(64), ProductDropID int, DMIStr varchar(max), SortOrder int, SupportedRegions varchar(max), ImageLocale varchar(max))

	
	
	INSERT INTO #Comp
	EXEC IRS_listComponentsInImageForPulsar @p_chrPDName
	
	
	SELECT @pvid as PVID, @dotsname as DOTSName, r.id as RootID, v.ID as CompID, irs.Name as CompName, irs.Partno, irs.Version, irs.Revision, irs.Pass, irs.ComponentPassID as IRSCompPassID, irs.DMIStr, irs.SortOrder, irs.SupportedRegions as Regions
			, irs.ImageLocale as Locales, cast(isnull(v.MultiLanguage,0) as bit) as GlobalComp, isnull(ldv.LanguageID,0) as LanguageID
	FROM	#Comp as irs
			INNER JOIN deliverableversion v WITH (NOLOCK) ON irs.partno = v.irspartnumber
			INNER JOIN deliverableroot r WITH (NOLOCK) ON r.id = v.deliverablerootid
			LEFT JOIN Language_DelVer ldv on v.MultiLanguage = 0 AND v.ID = ldv.DeliverableVersionID  
	ORDER BY irs.Name, irs.Version, irs.Revision, irs.Pass

	SET NOCOUNT OFF

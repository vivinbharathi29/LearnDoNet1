﻿

CREATE PROCEDURE [dbo].[spGetDevProductionReleaseEmailInfo]
(
	@ID int
)
AS
	Select p.id as ProductID, r.name as Deliverable, ct.pmfieldname, p.platformdevelopmentid, p.VideoMemoryPMID, p.GraphicsControllerPMID, p.ProcessorPMID, p.SEPMID, p.PINPM, p.AccessoryPMID, p.CommHWPMID, p.pdeid, pd.developerteststatus, pd.developertestnotes, v.id as VersionID, p.dotsname as Product, v.revision, v.version, v.pass, v.partnumber, v.modelnumber, vd.name as Vendor
	from product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), productversion p with (NOLOCK), deliverableroot r with (NOLOCK), vendor vd with (NOLOCK), deliverablecategory c with (NOLOCK), deliverablecategoryteam ct with (NOLOCK)
	where p.id = pd.productversionid
	and c.id = r.categoryid
	and ct.id = c.teamid
	and v.vendorid = vd.id
	and v.id = pd.deliverableversionid
	and pd.id = @ID
	and r.id = v.deliverablerootid



﻿
CREATE PROCEDURE [dbo].[spCloneFindMissingVersions]
(
	@SourceID int,
	@TargetID int
)
 AS

Select v.id, v.deliverablename as Name, v.version, v.revision, v.pass
from product_deliverable pd with (NOLOCK), deliverableroot r with (NOLOCK), deliverableversion v with (NOLOCK)
where pd.productversionid = @SourceID
and r.id = v.deliverablerootid
and v.id = pd.deliverableversionid
and pd.targeted = 1
and r.typeid <> 1
and v.id not in (Select v.id
				from product_deliverable pd with (NOLOCK), deliverableroot r with (NOLOCK), deliverableversion v with (NOLOCK)
				where pd.productversionid = @TargetID
				and r.id = v.deliverablerootid
				and v.id = pd.deliverableversionid
				and pd.targeted = 1
				and r.typeid <> 1
				)
--and r.categoryid not in (73,95,107,163,86,134,136,177)	
--and r.Name not like 'stla%'			
order by r.name, v.id desc


﻿CREATE PROCEDURE spFusion_AddComponentSchedule
	@DeliverableVersionId INT,
	@WorkflowDefinitionId INT
AS

SET NOCOUNT ON

INSERT DeliverableSchedule(DeliverableVersionID,Milestone, MilestoneOrder,Planned,Actual,StatusID,ReportMilestone, DefinitionID)
SELECT @DeliverableVersionId, Milestone, MilestoneOrder, DATEADD(d, RANK() OVER(ORDER BY MilestoneOrder) - 1, GETDATE()) AS Planned, NULL AS Actual, CASE WHEN RANK() OVER(ORDER BY MilestoneOrder) = 1 THEN 1 ELSE 2 END AS StatusId, ReportMilestone, ID --CASE WHEN RANK() OVER(ORDER BY MilestoneOrder) = 1 THEN GETDATE() ELSE NULL END 
from deliverableworkflowdefinitions where WorkflowId = @WorkflowDefinitionId

DECLARE @CurrentMilestoneId INT
SELECT TOP (1) @CurrentMilestoneId = ID FROM DeliverableSchedule WHERE DeliverableVersionID = @DeliverableVersionId AND StatusID = 1

UPDATE Language_DelVer
SET MilestoneID = @CurrentMilestoneId
WHERE DeliverableVersionID = @DeliverableVersionId

--SELECT * FROM DeliverableSchedule

EXEC spUpdateDeliverableLocation @DeliverableVersionId

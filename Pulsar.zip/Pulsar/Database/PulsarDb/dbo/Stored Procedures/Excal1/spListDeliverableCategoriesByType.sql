﻿

CREATE PROCEDURE [dbo].[spListDeliverableCategoriesByType]
(
	@TypeID int = null
)

 AS
	SELECT DeliverableCategory.ID,DeliverableCategory.name as Category, DeliverableTypeID,RequireCountries, DeliverableType.Name as Type, DeliverableCategory.NameFormat, DeliverableCategory.active as ActiveCategory
	FROM DeliverableCategory with (NOLOCK), DeliverableType  with (NOLOCK)
	Where  DeliverableType.id = DeliverableCategory.DeliverableTypeID
	and DeliverableType.ID = coalesce(@TypeID,DeliverableType.ID)
	ORDER BY DeliverableType.ID, DeliverableCategory.Name


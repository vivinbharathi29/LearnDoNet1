﻿CREATE PROCEDURE [dbo].[spGetSelectedOS]
 (@ID as int)
 /** Change History     
**************************************************************************************************  
** SNo   Date        Author  Description    
** -    --------   -------   -------------------------  
**  1  24/7/2018     Monica   Changed to ANSI standard
****************************************************************************************************/

  AS

 SET NOCOUNT ON 
Select dv.OSID as ID, lu.Name, lu.OfficialName , lu.CVAKey, lu.Shortname
FROM OS_DelVer dv with (NOLOCK)
INNER JOIN osLookup lu with (NOLOCK)
ON dv.OSID = lu.ID
WHERE Deliverableversionid = @ID
order by lu.cvakey
 SET NOCOUNT OFF



﻿
CREATE PROCEDURE [dbo].[spGetInternalRev]
(
	@ID int,
	@TeamID int
)
AS
	if @TeamID=1
		Select PreinstallInternalRev, PreinstallPNRev
		from deliverableversion with (NOLOCK)
		where id = @ID
	else
		Select PreinstallInternalRevTDC as PreinstallInternalRev, PreinstallPNRevTDC as PreinstallPNRev
		from deliverableversion with (NOLOCK)
		where id = @ID



﻿CREATE PROCEDURE [dbo].[spGetTargetedProductsForVersion] 
(
	@ID as int
) 

AS

Select pd.productVersionID as ID, pd.Targeted,  v.DOTSName as Family, v.version as version, pd.teststatusid,v.active, v.sustaining, e.email as SEPMMail,DevCenter, ReleaseTeam, t.FontColor as BGColor, t.status as testStatus
FROM 
	ProductFamily f with (NOLOCK)
	INNER JOIN ProductVersion v with (NOLOCK) ON v.productfamilyid = f.id
	INNER JOIN Product_Deliverable pd with (NOLOCK) ON pd.productversionid = v.id
	INNER JOIN employee e with (NOLOCK) ON e.id = v.sepmid
	LEFT OUTER JOIN teststatus t with (NOLOCK) ON t.id = pd.teststatusid
Where (v.active=1 or v.sustaining=1)
and Deliverableversionid = @ID
and v.FusionRequirements <> 1
union
Select pd.productVersionID as ID, pdr.Targeted,  v.DOTSName + ' (' + pvr.Name + ')' as Family, v.version as version, pdr.teststatusid, v.active, v.sustaining, e.email as SEPMMail,DevCenter, ReleaseTeam, t.FontColor as BGColor, t.status as testStatus
FROM 
	ProductFamily f with (NOLOCK)
	INNER JOIN ProductVersion v with (NOLOCK) ON v.productfamilyid = f.id
	INNER JOIN Product_Deliverable pd with (NOLOCK) ON pd.productversionid = v.id 
	INNER JOIN Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
	INNER JOIN ProductVersionRelease pvr with (NOLOCK) on  pvr.id = pdr.ReleaseID
	INNER JOIN employee e with (NOLOCK) ON e.id = v.sepmid
	LEFT OUTER JOIN teststatus t with (NOLOCK) ON t.id = pdr.teststatusid
Where (v.active=1 or v.sustaining=1)
and Deliverableversionid = @ID
and v.FusionRequirements = 1
order by v.dotsname

﻿
-- =============================================
-- Author:		Kenneth M. Berntsen
-- Create date: 09/07/2006
-- Description:	Pulls the data for the Microsoft WHQL MDA Compliance Report
-- =============================================
CREATE PROCEDURE [dbo].[rpt_MDACompliance] 
(
	@p_ProductVersionID INT = NULL,
	@p_OSFamilyID INT = NULL
)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

	SELECT * FROM
	(SELECT DISTINCT 
		ProductWHQL.SubmissionID, 
		dbo.ufn_GetMDAModelList(ProductWHQL.ID) AS SkuModel,
		ProductWHQL.WhqlDt, 
		ProductWHQL.Location, 
		ProductWHQL.DateReleased, 
		ProductWHQL.LogoDisplayed, 
		ProductWHQL.Milestone3,
		dbo.ufn_GetMSTech(ProductWHQL.ProductVersionID) AS MSTech,
		ProductWHQL.CriticalUpdates
	FROM         
		ProductWHQL with (NOLOCK)
		INNER JOIN ImageDefinitions ImgDef  with (NOLOCK) ON ProductWhql.ProductVersionID = ImgDef.ProductVersionID
		INNER JOIN OSLookup os  with (NOLOCK) ON ImgDef.OSID = OS.ID
		INNER JOIN ProductVersion  with (NOLOCK) on ProductVersion.ID = ProductWhql.ProductVersionID
	WHERE
		(OS.OSFamilyID = @p_OSFamilyID OR @p_OSFamilyID IS NULL)
	AND	(ProductWHQL.ProductVersionID = @p_ProductVersionID OR (@p_ProductVersionID IS NULL AND ShowOnWhql = 1))
	) T1 LEFT OUTER JOIN

	(
	SELECT DISTINCT 
		ProductWHQL.SubmissionID, 
		ImageSigverifyResults.DllName AS UnsignedDriver, 
		MDAUnsigned.Notes AS ContingencyNo 
	FROM         
		MDAUnsigned with (NOLOCK) RIGHT OUTER JOIN
		ImageSigverifyResults with (NOLOCK) ON MDAUnsigned.FileName = ImageSigverifyResults.DllName RIGHT OUTER JOIN
		ProductWHQL with (NOLOCK) INNER JOIN
		WHQL_AvDetail with (NOLOCK) ON ProductWHQL.ID = WHQL_AvDetail.WHQLID INNER JOIN
		ProductSKUComponent with (NOLOCK) ON WHQL_AvDetail.BUID = ProductSKUComponent.BaseUnitAvID AND 
		WHQL_AvDetail.CPUID = ProductSKUComponent.CpuAvID INNER JOIN
		ProductSKU with (NOLOCK) ON ProductSKUComponent.SkuID = ProductSKU.ID ON ImageSigverifyResults.ImageNo = ProductSKUComponent.ImagePN
		INNER JOIN ProductVersion with (NOLOCK) ON ProductVersion.ID = ProductWHQL.ProductVersionID
	WHERE ImageSigverifyResults.DllName IS NOT NULL
	AND (WHQL_AvDetail.OSFamilyID = @p_OSFamilyID OR @p_OSFamilyID IS NULL)
	AND	(ProductWHQL.ProductVersionID = @p_ProductVersionID OR (@p_ProductVersionID IS NULL AND ShowOnWhql = 1))
	) T2 on t1.submissionid = t2.submissionid

END




﻿
CREATE PROCEDURE [dbo].[spListAccessoryPMs4Version]

(
	@ID int
)

 AS

Select Distinct e.id, e.name, e.email
from product_deliverable pd with (NOLOCK), employee e with (NOLOCK), productversion v with (NOLOCK)
where v.id = pd.productversionid
and e.id = v.accessorypmID
and v.oncommoditymatrix = 1
and pd.deliverableversionid = @ID


﻿

CREATE PROCEDURE [dbo].[spLinkDepends2Version]
 (
  @DependsID as int,
  @DeliverableID as int
 )
 AS
Insert Depends_DelVer (DependsID,DeliverableVersionId)
Values (@DependsID,  @DeliverableID)




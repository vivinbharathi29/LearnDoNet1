﻿
CREATE PROCEDURE [dbo].[spGetEmployeeUserSettings]
(
	@EmployeeID int,
	@UserSettingsID int
)

 AS

	Select ID, Setting
	from Employee_UserSettings with (NOLOCK)
	Where EmployeeID = @EmployeeID
	and UserSettingsID = @UserSettingsID


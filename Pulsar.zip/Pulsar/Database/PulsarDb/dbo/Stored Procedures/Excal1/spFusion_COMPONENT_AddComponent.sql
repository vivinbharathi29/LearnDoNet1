﻿CREATE PROCEDURE [dbo].[spFusion_COMPONENT_AddComponent]
/* ************************************************************************************************
 * Purpose:		pushing data to IRS
 * Created By:	Unknown
 * Modified By:	7/1/2015 buidi - need to push cert status to irs
				8/18/2015 buidi - get siteid from table instead of hard code the id
				Sruthi Rgaishetti ( 9/9/2015) Consider version ComponentPMId for feed instead of Root
				10/12/2015 buidi - we should not update component in pulsar if there is error executing irs
				10/13/2015 buidi - we are fixing component if we found component already created in irs
				11/05/2015 buidi - need to get devManagerID from root if null in componentversion
				31/03/2016 Ravi Nukala - SR0015 - Deterministic function call (function) might cause an unnecessary table scan. Task 18941
				06/07/2016 wgomero - If the component is ML component do not truncate the part number
				08/05/2016 wgomero - if component is ML component then there is no need to generate IRS part number
				08/18/2016 wgomero - rolled back changes to changeset 16155, issue: dash code of localized part number is set to XX
				08/22/2016 linshant- generate component part number only for PreInstall components
				03/23/2018 wgomero - remove partnumber generation and delieverableRoot and DeliverableVersion table updates from this stored procedure.
				06/27/2018 wgomero: Generate part numbers for Component Type = Firmware
 **************************************************************************************************/
/**************************************************************************************************    
** SNo   Date        Author                                    Description           
** --    --------   -------                                   -------------------------           
 ** 1    09/01/2019  Santhana K								  Used the EmailGroup table instead of hardcoding email address
****************************************************************************************************/ 
(
	@VersionID int,
	@UserID int = 0
)
AS

print '--' + cast (@VersionID as varchar(100))
	DECLARE @UpdateBy varchar(64)
	Declare @Name varchar(80)
	Declare @SilentInstall varchar(300)
	declare @Description varchar(3000)
	Declare @DeveloperID int
	Declare @DevManagerID int
	Declare @VersionDevManagerID int
	Declare @TesterID int
	Declare @Tester varchar(10)
	Declare @VendorID int
	declare @Version varchar(20)
	declare @Revision varchar(10)
	declare @Pass varchar(5)
	declare @MultiLanguage bit
	declare @Comments varchar(max)
	declare @Devices varchar(max)
	declare @Partition varchar(20)
	declare @Qualification varchar(2048)
	declare @Enhancement varchar(2048)
	declare @DetailFile varchar(6000)
	declare @LanguagesFound bit
	declare @SelectiveRestore int
	declare @InAppRecovery varchar(3)
	declare @ExcalCategory varchar(35)
	declare @Abbr as varchar(5)
	declare @TempPart varchar(30)
	declare @IRSVersionCount int
	declare @IRSCategoryID int
	declare @SWSetup int
	declare @PlatformIDList varchar(max)
	declare @DBName as varchar(256)
	declare @SubmitterEmail as varchar(80)
	Declare @NotifySubmitter as int
	Declare @IRSPath as varchar(512)
	Declare @NewIRSID int
	Declare @NewRootID int
	Declare @NewRevisionID int
	Declare @NewVersionID int
	Declare @ExcalRootID int	
	Declare @NewIRSPartNumber varchar(18)
	Declare @ImagePath varchar(256)
	declare @IRSFilesCopied int
	Declare @IRSTransferPath varchar(256)
	Declare @ODMPermissions varchar(max)
	declare @MFTJobID int
	declare @MFTCommand varchar(8000)
	declare @ZipFileName varchar(300)
	declare @OSArchitecture_INFPath varchar(max)
	declare @EntryME_PCR0 varchar(256)
	declare @FullME_PCR0 varchar(256)
	declare @CVASubpath varchar(255)
	declare @BaseFilePath varchar(1024)
	declare @LangCount int
	Declare @Errormsg varchar(max)
	declare @NotebookProductCount int
	declare @AddLanagugeOnly bit
	declare @IrsLocalizedVersionID int
	declare @IRSRevisionID int
	declare @NewDashCode varchar(10)
	declare @CDImage bit
	declare @IrsComponentCloneId int
	declare @BuildLevel int
	Declare @PreviousBasePart varchar(6)
	Declare @PrismSWType int
	Declare @CertStatus varchar(50)
	Declare @SiteID int
	DECLARE @MLID int
	DECLARE @MLPartNumber varchar(25)
	DECLARE @IsPreInstall bit = 0, @IsBinary bit = 0, @IsPreInstallROM bit = 0

	select @SiteID = ODMID from IRS_ODM where Name like '%Pulsar Software%' and Name like 'HP%' and Name like '%-%'

	Declare @RecipientEmail varchar(200)
	select @RecipientEmail =  value from Setting
	where name = 'Pulsar.SupportEmail'


	set @IrsLocalizedVersionID = 0
	set @BuildLevel = 0

	Select @LangCount = 0
	set @AddLanagugeOnly=0
	set @NotebookProductCount = 0

	Select @NotebookProductCount=count(1)
	from product_deliverable
	where deliverableversionid = @VersionID

	Declare @ExcDeveloperID int
	Declare @ExcDevmanagerID int
	
	--Select @Partition = '488'
	Select @LanguagesFound = 0

	SELECT @DBName = DB_NAME() 

	if @UserID = -1 
		begin
		Select @UpdateBy = 'Pulsar'
		Select @UserID = 1183
		end
	else	
		begin
		Select @UpdateBy = 'Excalibur'
		Select @UserID = 1183
		end

	Select @ODMPermissions = ''

	exec spFusion_Component_ListODMPartnersForVersion 
		@VersionID = @VersionID,
		@UserID = @UserID,
		@Result =  @ODMPermissions output

	Select @CVASubpath=coalesce(CVASubPath,''), @BaseFilePath=BaseFilePath,@SWSetup = coalesce(SWSetupCategoryID,0),@ImagePath = coalesce(imagepath,''), @MLID = ML, @MLPartNumber = IRSPartNumber,
		   @IRSFilesCopied = IRSFilesCopied, @CDImage = case when cdimage =1 or isoimage =1 or ar =1 then 1 else 0 end, @IsPreInstall = PreInstall, @IsBinary = [Binary], @IsPreInstallROM = PreInstallROM
	from DeliverableVersion WITH (NOLOCK)
	where ID = @VersionID


	Select @IRSTransferPath = Transferpath
	from [ComponentTransferServer]
	where id = (Select transferserverid from deliverableversion where id = @VersionID)

	if @IRSTransferPath is null
		begin
			if CHARINDEX('\\tpopsg',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.159.131.85\FN' --'\\16.159.129.100\fn'--\\16.159.131.85\FN
			else if CHARINDEX('\\16.159.144.32',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.159.131.85\FN' --'\\16.159.129.100\fn'--\\16.159.131.85\FN
			else if CHARINDEX('\\16.159.144.33',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.159.131.85\FN' --'\\16.159.129.100\fn'--\\16.159.131.85\FN
			else if CHARINDEX('\\cdc-buildsrv',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.159.131.85\FN' --'\\16.159.129.100\fn'--\\16.159.131.85\FN
			else if CHARINDEX('\\16.159.131.16',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.159.131.85\FN' --'\\16.159.129.100\fn'--\\16.159.131.85\FN
			else if CHARINDEX('\\16.159.131.17',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.159.131.85\FN' --'\\16.159.129.100\fn'--\\16.159.131.85\FN
			else if CHARINDEX('\\16.159.131.85',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.159.131.85\FN' --'\\16.159.129.100\fn'--\\16.159.131.85\FN
			else if CHARINDEX('\\16.159.131.18',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.159.131.85\FN' --'\\16.159.129.100\fn'--\\16.159.131.85\FN
			else if CHARINDEX('\\hpdblocks',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.75.55.30\blocks\usersubmissions'--'\\16.75.55.30\excalstage$'
			else if CHARINDEX('\\16.75.55.30',@ImagePath) > 0
				Select @IRSTransferPath = '\\16.75.55.30\blocks\usersubmissions'--'\\16.75.55.30\excalstage$'
			else
				Select @IRSTransferPath = '\\16.102.82.200\LCM'--'\\16.102.80.48\f'
		end

	Select @SelectiveRestore = max(coalesce(SelectiveRestore,0))
	from Product_Deliverable WITH (NOLOCK)
	where ProductVersionID >= 993
	and DeliverableVersionID = @VersionID
	
	if @SWSetup>1
		Select @InAppRecovery = '1'
	else
		Select @InAppRecovery = '0'	
	
	--Assumptions
	--SAPDescription = ""
	--SilentInstallTitle = Name
	--Approver = Developer if no approver defined	
	--Tester  = Developer if no tester defined
	--Don't send os or language if not mapped to IRS
	--Need to lookup target partition
	--Send Qualification as Softpaq Fixes
	--Send Enhancements as Softpaq Enhancements
	
	
	Declare @chrPartno varchar(18)
	Declare @p_intOldComponentVersionID int

	

	Select @PlatformIDList = Left([Platforms].PlatformID,Len([Platforms].PlatformID)-1)
	from (select (select cast(p.PlatformID as varchar) + ',' as [text()]
					From	[Platform] p
					join	DesktopPlatform_Deliverable pd on pd.desktopplatformid = p.PlatformID
					Where	DeliverableVersionID = @VersionID and pd.Deleted is NULL
					For XML PATH ('')) [PlatformID]) [Platforms]
	
   IF @PlatformIDList IS NULL
	 BEGIN
	  SET @PlatformIDList =''
	 END
	 	

	Select @ExcalRootID = DeliverableRootID from DeliverableVersion WITH (NOLOCK) where ID = @VersionID
	if @ExcalRootID is null
		select @ExcalRootID = 0


	select @PreviousBasePart = max(LEFT(coalesce(IRSPartNumber,''), 6)) 
	from deliverableversion WITH (NOLOCK)
	where DeliverableRootID =  @ExcalRootID
	and IRSPartNumber NOT LIKE 'Pending%'
	and IRSPartNumber <> 'N/A'
	and IRSPartNumber <> ''

	--PRINT 'PreviousBasePart: ' + ISNULL(@PreviousBasePart, 'NADA')

	if LEN(ISNULL(@PreviousBasePart,''))=6 
	BEGIN
		Select @p_intOldComponentVersionID = max(coalesce(id,0))
		from DeliverableVersion WITH (NOLOCK)
		where deliverablerootID = @ExcalRootID
		and coalesce(LEFT(IRSPartNumber, 6),'') = @PreviousBasePart
	END

	--Print @p_intOldComponentVersionID

	if ISNULL(@p_intOldComponentVersionID, 0) = 0
		begin
			-- If this root was made by cloning a version from IRS and this is the first version
			-- created for this root, we need to use the clone ID so the part numbers will be the same.

			Select @IrsComponentCloneId = IrsComponentCloneId
			from DeliverableRoot r WITH (NOLOCK) inner join
				 DeliverableVersion v with (NOLOCK) on r.id = v.DeliverableRootID
			where v.ID = @VersionID


			if coalesce(@IrsComponentCloneId,0) <> 0
				select @p_intOldComponentVersionID = @IrsComponentCloneId
			else	
				select @p_intOldComponentVersionID = 0
	
		end 
	
	set @chrPartno = ''

  -- IF component is a ML component there is no needed to generate part number
  IF @MLID > 0
		BEGIN
			SELECT @chrPartno = @MLPartNumber 
		END
  ELSE IF(@IsPreInstall = 1 OR @IsBinary = 1 OR @IsPreInstallROM = 1) --generate part number only for PreInstall Components
	   BEGIN
	    SELECT @chrPartno = IRSPartNumber FROM DeliverableVersion WHERE ID = @VersionID;
     END

	Select @SubmitterEmail = e.Email, @NotifySubmitter = cast(v.MFTNotifySubmitter as int)
	from UserInfo e WITH (NOLOCK), deliverableversion v WITH (NOLOCK)
	where v.submitterid = e.UserId
	and v.id = @VersionID

	if @SubmitterEmail is null
		select @SubmitterEmail = value from setting
		where name = 'Pulsar.SupportEmail'

  /*
    BEGIN OF CHANGE ***********************************************************
    Change 2014-08-04
  */
  Declare @AttemptNumber int = 0
TryAgain:
  /*
    END OF CHANGE *************************************************************
  */

	Select 
		@IRSCategoryID=c.IRSCategoryID,
		@ExcalCategory=c.OTSCategory ,
		@DetailFile=replace(replace(replace(replace(replace(cast(v.SoftpaqFileInfo as varchar(max)),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'),
		@SilentInstall=replace(replace(replace(replace(replace(cast(v.SilentInstall as varchar(max)),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'),
		@Enhancement=replace(replace(replace(replace(replace(cast(v.SoftpaqEnhancements as varchar(max)),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'),
		@Qualification=replace(replace(replace(replace(replace(cast(v.SoftpaqFixes as varchar(max)),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'),
		@Devices=replace(replace(replace(replace(replace(cast(v.PNPDevices as varchar(max)),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'),
		@Comments=replace(replace(replace(replace(replace(left(cast(v.[changes] as varchar(max)),2000),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'), 
		@MultiLanguage=v.multilanguage, 
		@Version = left(v.version,20), 
		@Revision = left(v.revision,10), 
		@Pass = left(v.pass,5),
		@VendorID = vd.IRSID,
		@Partition=coalesce(r.targetpartition,''),
		@TesterID = coalesce(v.testleadid,0), 
		@DevManagerID= coalesce(pm.IRSUserID,0),
		@DeveloperID=coalesce(dev.irsuserid,0),
		@BuildLevel = coalesce(v.levelid,0),
		@PrismSWType = v.PrismSWType,
		@Name =  replace(replace(replace(replace(replace(left(deliverablename,80),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'), 
		@Description = replace(replace(replace(replace(replace(LEFT(r.Description,3000),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'), 
		@OSArchitecture_INFPath=replace(replace(replace(replace(replace(v.DevicesInfPath,'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'),
		@EntryME_PCR0 = replace(replace(replace(replace(replace(LEFT(v.EntryMePCR0,256),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'),
		@FullME_PCR0 = replace(replace(replace(replace(replace(LEFT(v.FullMePCR0,256),'&','&amp;'),'"','&quot;'),'''','&apos;'),'<','&lt;'),'>','&gt;'),
		@CertStatus = coalesce(v.CATStatus, '')
	from DeliverableVersion v WITH (NOLOCK) inner join
	     DeliverableRoot r WITH (NOLOCK) on r.ID = v.deliverablerootid inner join
	     UserInfo dev WITH (NOLOCK) on v.DeveloperID = dev.UserId inner join
	     UserInfo pm WITH (NOLOCK) on pm.UserId = isnull(v.DevManagerID, r.DevManagerID) inner join
	     Vendor vd WITH (NOLOCK) on vd.ID = v.VendorID inner join
	     DeliverableCategory c WITH (NOLOCK) on c.ID = r.CategoryID
	where v.ID = @VersionID

  /*
    BEGIN OF CHANGE ***********************************************************
    Change 2014-08-04
    LY If any of the required user IDs comes back as 0, call the user synchronization with IRS and Pulsar 
  */
  If ((@TesterID = 0) Or (@DevManagerID = 0) Or (@DeveloperID = 0)) Begin
    Set @AttemptNumber += 1
    If (@AttemptNumber <= 2) Begin

      Goto TryAgain
    End
    Else Begin
      Declare @Message varchar(100)
      Set @Message = 'invalid '
      If (@TesterID = 0) Begin
        Set @Message += 'TesterID '
      End
      If (@DevManagerID = 0) Begin
        Set @Message += '@DevManagerID '
      End
      If (@DeveloperID = 0) Begin
        Set @Message += '@DeveloperID '
      End
      Insert Into AppError (
        Category, 
        ErrFile, 
        ErrLine, 
        AspDescription, 
        ErrDescription, 
        ErrorDateTime, 
        AuthUser)
      Values (
        /* Category */       'Sync error', 
        /* ErrFile */        'spFusion_COMPONENT_AddComponent', 
        /* ErrLine */        0,
        /* AspDescription */ '', 
        /* ErrDescription */ 'Deliverable Version ID: [' + Cast(@VersionID As varchar(10)) + '] cannot add component because of an ' + @Message, 
        /* ErrorDateTime */  GetDate(), 
        /* AuthUser */       'Luhit Young')
    End
  End
  /*
    END OF CHANGE *************************************************************
  */
	
	Select @Partition = cast(IRSID as varchar(20))
	from targetpartition
	where name=@Partition

	if coalesce(@Partition,'') = ''
		set @Partition = '488'
		
	if @IRSCategoryID = 0 or @IRSCategoryID is null
		Select @IRSCategoryID = 253
	
	if @Testerid is null or @TesterID = 0
		Select @Tester = cast(@DeveloperID as varchar(10))
	else
		Select @Tester = CAST(irsuserid as varchar(10))
		from UserInfo WITH (NOLOCK)
		where UserId = @TesterID


	if @DevManagerID = 0 
		begin
		Select @VersionDevManagerID = v.devmanagerid 
		from DeliverableVersion v WITH (NOLOCK)
		where  v.ID = @VersionID
		
		 if coalesce(@VersionDevManagerID,'') <> ''
			 Begin
			     select @ExcDevmanagerID = @VersionDevManagerID 				 
			 End
		 Else
			 Begin
			    select @ExcDevmanagerID = r.devmanagerid 
				from DeliverableVersion v WITH (NOLOCK), DeliverableRoot r WITH (NOLOCK)
				where v.deliverablerootid = r.id 
				and v.ID = @VersionID						
			 End							
		

		Select @DevManagerID = IRSUserID
		from UserInfo  WITH (NOLOCK)
		where UserId = @ExcDevmanagerID
	
		end
		
	if @DeveloperID = 0
		begin
		select @ExcDeveloperID = developerid from DeliverableVersion  WITH (NOLOCK) where ID = @VersionID
	

		Select @DeveloperID = IRSUserID
		from UserInfo WITH (NOLOCK)
		where UserId = @ExcDeveloperID
		
		end
		
	if coalesce(@Tester,0) = 0
		Select @Tester = cast(@DeveloperID as varchar(10))
	
	Select @IRSVersionCount = COUNT(1)
	from irs_componentpass p WITH (NOLOCK) inner join 
		irs_componentversion v WITH (NOLOCK) on p.componentversionid = v.componentversionid
	where v.name = @Name
	and p.Version = @Version
	and p.Revision = @Revision
	and p.Pass = @Pass	
	


	if @IRSVersionCount is not null and @IRSVersionCount <> 0 
		begin
			exec spFusion_COMPONENT_UpdateComponent @VersionID, @UserID
			if exists (select 1 from componentversion where swpartnumber = 'Pending...' and componentversionid = @VersionID)
			begin 
				print 'Dup:' + @Name + ':' + @Version + ':' + @Revision  + ':' + @Pass
				Declare @ErrorBody varchar(5000)
	
				Select @ErrorBody = 'The IRS Component feed could not send this deliverable because a duplicate already exists: ' + @Name + ' ' + @Version + ' ' + @Revision + ' ' + @Pass + ' VersionCount: ' + cast(@IRSVersionCount as varchar(10))
				
				EXEC msdb.dbo.sp_send_dbmail
						@profile_name = 'Database Mail Profile',
						@recipients = @RecipientEmail, 
						@body = @ErrorBody,
						@subject = 'Duplicate Component Found in IRS' ;	
			  /*
				BEGIN OF CHANGE ***********************************************************
				Change 2014-08-04
				LY Add error to AppError in addition to sending email.
			  */
			  Insert Into AppError (
				Category, 
				ErrFile, 
				ErrLine, 
				AspDescription, 
				ErrDescription, 
				ErrorDateTime, 
				AuthUser)
			  Values (
				/* Category */       'Add component error', 
				/* ErrFile */        'spFusion_COMPONENT_AddComponent', 
				/* ErrLine */        0,
				/* AspDescription */ 'Deliverable Version ID: [' + Cast(@VersionID As varchar(10)) + ']', 
				/* ErrDescription */  @ErrorBody, 
				/* ErrorDateTime */  GetDate(), 
				/* AuthUser */       'Luhit Young')
			  /*
				END OF CHANGE *************************************************************
			  */
			end
		end
	else
		begin
		Declare @XMLInput as varchar(MAX)

		Declare @OSList varchar(max)
		Declare @OSElements varchar(max)
		Declare @IRSOSID varchar(10)
		Declare @OSFound bit

		Select @OSList = ''
		Select  @OSElements = ''

		DECLARE IRSCompOS_CURSOR CURSOR FOR Select distinct(cast(o.irsid as varchar(10)))
												from oslookup o WITH (NOLOCK) inner join
													OS_DelVer od WITH (NOLOCK) on od.osid = o.Id inner join
													DeliverableVersion d WITH (NOLOCK) on d.id = od.DeliverableVersionid
												where d.ID = @VersionID
												and o.irsid <> 0

												
												union 

												Select distinct '115' --Generic win7 64
												from oslookup o WITH (NOLOCK) inner join
  													 OS_DelVer od WITH (NOLOCK) on od.osid = o.Id inner join
													 DeliverableVersion d WITH (NOLOCK) on d.id = od.DeliverableVersionid
												where d.ID = @VersionID
												and o.id in (43, 45, 47, 49, 51)

												union 

												Select distinct '114' --Generic win7 32
												from oslookup o WITH (NOLOCK) inner join
  													 OS_DelVer od WITH (NOLOCK) on od.osid = o.Id inner join
													 DeliverableVersion d WITH (NOLOCK) on d.id = od.DeliverableVersionid
												where d.ID = @VersionID
												and o.id in (42,44,46,48,50,52)											
											 
		open IRSCompOS_CURSOR

		FETCH NEXT FROM IRSCompOS_CURSOR Into @IRSOSID
		WHILE (@@fetch_status <> -1)
			BEGIN
				If (@@fetch_status <> -2)
					BEGIN
						Select @OSElements = @OSElements + '<OS OSID="' + @IRSOSID + '" CategoryID="460" /> ' + CHAR(13) + CHAR(10)
						Select @OSList = @OSList + ',' + @IRSOSID + '|460'
					END
				FETCH NEXT FROM IRSCompOS_CURSOR Into @IRSOSID
			END
		DEALLOCATE IRSCompOS_CURSOR		

		if @OSList = ''
			begin
				Select @OSList = '17|460'
				Select @OSElements = '<OS OSID="17" CategoryID="460" /> ' + CHAR(13) + CHAR(10)
			end
		else
			Select @OSList = SUBSTRING(@OSList,2,LEN(@OSList))


		Declare @IRSLanguageID varchar(10)
		Declare @ExcaliburComponentLanguageID int
		Declare @LanguageList varchar(4000)

		/*
			
			*/

		if @MultiLanguage =1
			begin
			 set @AddLanagugeOnly=0
			 set @IRSLanguageID = '43'
			 set @IRSRevisionID = 0
			end
		else
			begin
				Select @IRSLanguageID = cast(l.irsid as varchar(10)), @NewDashCode = cast(l.dash as varchar(10))
				from language l WITH (NOLOCK) inner join
							Language_DelVer ld WITH (NOLOCK) on ld.Languageid = l.Id inner join
							DeliverableVersion d WITH (NOLOCK) on d.id = ld.DeliverableVersionid
				where d.ID = @VersionID
				and coalesce(l.irsid,0) <> 0
				and coalesce(l.irsid,0) <> 99999

				-- Ravi Nukala Code modified for SR0015 SQL Warning
				declare @tempVersion varchar(20)
				SET @tempVersion = left(@Version + '-',charindex('-',@Version + '-')-1)

				Select @IrsLocalizedVersionID = max(v.componentversionid)
				from irs_componentpass p WITH (NOLOCK) inner join 
					irs_componentversion v WITH (NOLOCK) on p.componentversionid = v.componentversionid
				where v.name = @Name
				and left(p.Version + '-',charindex('-',p.Version + '-')-1) = @tempVersion
				and p.Revision = @Revision
				and p.Pass = @Pass

				if @IrsLocalizedVersionID is not null
					begin
					set @AddLanagugeOnly=1
					
					Select @IRSRevisionID = RevisionID
					from [dbo].[IRS_Revision_Language]
					where componentversionid = @IrsLocalizedVersionID

					set @IRSRevisionID = coalesce(@IRSRevisionID,0)

					end
				else
					begin
					set @AddLanagugeOnly=0
					set @IRSRevisionID = 0
					end
			
			end

		if @AddLanagugeOnly <> 0 -- --@MultiLanguage =1
			begin
			Select @XMLInput = '<?xml version="1.0" encoding="ISO-8859-1"?>'+ CHAR(13) + CHAR(10) 
			select @XMLInput = @XMLInput + '<Parameters'+ CHAR(13) + CHAR(10) 
			select @XMLInput = @XMLInput + 'RevisionID="' + cast(@IRSRevisionID as varchar(100)) + '"'+ CHAR(13) + CHAR(10) 
			select @XMLInput = @XMLInput + 'DeliveryType="1"'+ CHAR(13) + CHAR(10) 
			select @XMLInput = @XMLInput + 'Updater="Pulsar">'+ CHAR(13) + CHAR(10) 
			--select @XMLInput = @XMLInput + 'DeliveryType=1'+ CHAR(13) + CHAR(10) 
			select @XMLInput = @XMLInput + '<Language LanguageID="' + @IRSLanguageID  + '" />'+ CHAR(13) + CHAR(10) 
			select @XMLInput = @XMLInput + '</Parameters>'
			print @XMLInput
			end
		else
			begin
			
			Select @LanguageList = dbo.concatenate(l.irsid)
			from [language] l WITH (NOLOCK) inner join
				 language_delver ld WITH (NOLOCK) on ld.languageid = l.id
				 where ld.deliverableversionid = @Versionid
				 and l.irsid <> 99999

			if coalesce(@LanguageList,'') = ''
				Select @LanguageList = '43'
			else 
				Select @LanguagesFound = 1
			print '-----' + @Name
			Select @XMLInput = '<?xml version="1.0" encoding="ISO-8859-1"?>'
			Select @XMLInput = @XMLInput +  CHAR(13) + CHAR(10)  + '<Parameters'+ CHAR(13) + CHAR(10) 
			Select @XMLInput = @XMLInput + 'Name="' + @Name + '"' + CHAR(13) + CHAR(10) -- This is the preinstall component name (80 chars)
			Select @XMLInput = @XMLInput + 'Description="' + @Description + '"' + CHAR(13) + CHAR(10) -- Component Description (3000 chars)
			if @CDImage <> 1
				Select @XMLInput = @XMLInput + 'SilentInstallTitle="' + @Name + '"' + CHAR(13) + CHAR(10) 
			Select @XMLInput = @XMLInput + 'SAPDescription=""' + CHAR(13) + CHAR(10) 
			Select @XMLInput = @XMLInput + 'ApproverID="' + cast(@DeveloperID as varchar(10)) + '"' + CHAR(13) + CHAR(10)  -- Approver UserID
			Select @XMLInput = @XMLInput + 'DeveloperID="' + cast(@DeveloperID as varchar(10)) + '"' + CHAR(13) + CHAR(10)  -- Developer UserID
			Select @XMLInput = @XMLInput + 'ModulePMID="' + cast(@DevManagerID as varchar(10)) + '"' + CHAR(13) + CHAR(10)  -- Deliverable Owner UserID
			Select @XMLInput = @XMLInput + 'TesterID="' + @Tester + '"' + CHAR(13) + CHAR(10)  -- Tester UserID
			if @CDImage <> 1
				Select @XMLInput = @XMLInput + 'BusinessSegmentID="0"' + CHAR(13) + CHAR(10)  -- Pass value Zero (0)
			Select @XMLInput = @XMLInput + 'Updater="' + @UpdateBy + '"' + CHAR(13) + CHAR(10)  -- Name of Updater or 'Excalibur'

			if @CDImage <> 1
				begin
				--if lower(@DBName) = 'prs'
					Select @XMLInput = @XMLInput + 'PreinBinaryLoc="' + @IRSTransferPath + '"' + CHAR(13) + CHAR(10)  --HouComFile02.cca.cpqcorp.net
				--else
				--	Select @XMLInput = @XMLInput + 'PreinBinaryLoc="\\HOUBPCDIV2.americas.cpqcorp.net\Fusion"' + CHAR(13) + CHAR(10)  
				end
			Select @XMLInput = @XMLInput + 'VendorID="' + CAST(@VendorID as varchar(10)) + '"' + CHAR(13) + CHAR(10)  -- VendorID
			Select @XMLInput = @XMLInput + 'Copyright="Copyright (c) ' + cast(year(getdate()) as varchar(10)) + ' Hewlett-Packard Development Company, L.P."' + CHAR(13) + CHAR(10)  -- The year will change every new year
			if @CDImage <> 1
				Select @XMLInput = @XMLInput + 'SPOwnerID="0"' + CHAR(13) + CHAR(10)  -- Pass value Zero (0)
			Select @XMLInput = @XMLInput + 'IPv6Compliant="2"' + CHAR(13) + CHAR(10)  -- the value 2 if for IPv6Compliant = NA
			Select @XMLInput = @XMLInput + 'IPv6CompliantDate=""' + CHAR(13) + CHAR(10) 
			Select @XMLInput = @XMLInput + 'Version="' + @Version + '"' + CHAR(13) + CHAR(10)  -- Version
			Select @XMLInput = @XMLInput + 'Revision="' + @Revision + '"' + CHAR(13) + CHAR(10)  -- Revision
			Select @XMLInput = @XMLInput + 'Pass="' + @Pass + '"' + CHAR(13) + CHAR(10)  -- Pass
			Select @XMLInput = @XMLInput + 'ReleaseNote="' + coalesce(@Comments,'') + '"' + CHAR(13) + CHAR(10)  -- Release Notes is not require but is good to provide some information
			Select @XMLInput = @XMLInput + 'Devices="' + @Devices + '"' + CHAR(13) + CHAR(10)  -- This field for PNP DeviceIDs
			Select @XMLInput = @XMLInput + 'OSIDCategoryIDs="' + @OSList + '"' + CHAR(13) + CHAR(10)  -- Example: 104|460,104|466,131|460  -- Operating System IDs, OEMs and ServicePacks (ex: Windows 7 32 bit Enterprise | OEM, Windows 7 32 bit Enterprise | SP1, Windows 8 64 bit | OEM)  
			Select @XMLInput = @XMLInput + 'PlatformIDs="' + @PlatformIDList + '"' + CHAR(13) + CHAR(10)  -- Platforms IDs if any
			if @CDImage <> 1
				Select @XMLInput = @XMLInput + 'PreinstallCategoryID="' + CAST(@IRSCategoryID as varchar(10)) + '"' + CHAR(13) + CHAR(10)  -- CategoryID 253
			
			
			if @CDImage <> 1
				begin
--				if @ExcalCategory = 'Driver' 
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="3"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
--				else if @ExcalCategory = 'Operating System'
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="2"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
--				else if @ExcalCategory = 'System BIOS'
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="9"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
--				else if @ExcalCategory = 'Preinstall Tool - MSC'
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="1"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
--				else if @ExcalCategory = 'Preinstall Tool - DIAGS'
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="9"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
--				else if @ExcalCategory = 'ROMPAQ'
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="5"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
--				else if @ExcalCategory = 'Preinstall Tool - CGFile'
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="12"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
--				else if @ExcalCategory = 'Preinstall Tool - GBUHOOK'
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="11"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
--				else
--					Select @XMLInput = @XMLInput + 'PRISMTypeID="4"' + CHAR(13) + CHAR(10)  -- Deliverable TypeID
					Select @XMLInput = @XMLInput + 'PRISMTypeID="' + cast(@PrismSWType as varchar(100)) + '"' + CHAR(13) + CHAR(10)
				end 
												
			if @CDImage <> 1
				Select @XMLInput = @XMLInput + 'TargetPartitionID="' + @Partition + '"' + CHAR(13) + CHAR(10)  --PartitionID (Primary partition)
	
			Select @XMLInput = @XMLInput + 'Enhancement="' + left(@Enhancement,2048) + '"' + CHAR(13) + CHAR(10)  
			if @CDImage <> 1
				Select @XMLInput = @XMLInput + 'Qualification="' + left(@Qualification,2048) + '"' + CHAR(13) + CHAR(10)  
			Select @XMLInput = @XMLInput + 'LanguageIDs="' + @LanguageList + '"' + CHAR(13) + CHAR(10) -- LanguageIDs (ex: 1,34 for English(EN) and Spanish (SP)) 
			Select @XMLInput = @XMLInput + 'CountryIDs="241"' + CHAR(13) + CHAR(10) -- Country ID (Global)
            Select @XMLInput = @XMLInput + dbo.ufn_GetComponentVersion_ExportCompliance(@VersionID, 0) + CHAR(13) + CHAR(10) -- All
--			Select @XMLInput = @XMLInput + 'ExportCompliantIDs="All"' + CHAR(13) + CHAR(10) -- All
			if @CDImage <> 1
				begin
				Select @XMLInput = @XMLInput + 'SilentInstall="' + @SilentInstall + '"' + CHAR(13) + CHAR(10) 
				Select @XMLInput = @XMLInput + 'InAppRecovery="' + @InAppRecovery + '"' + CHAR(13) + CHAR(10) -- Send a 4
				Select @XMLInput = @XMLInput + 'DetailFileInfo="' + coalesce(@DetailFile,'') + '"' + CHAR(13) + CHAR(10) 
				Select @XMLInput = @XMLInput + 'BinaryLocation="' + coalesce(@BaseFilePath,'') +'"' + CHAR(13) + CHAR(10) -- will be generated by IRS
				Select @XMLInput = @XMLInput + 'Partno="' + @chrPartno + '"' + CHAR(13) + CHAR(10) -- will be generated by IRS
				
				if @BuildLevel = 19
					Select @XMLInput = @XMLInput + 'StatusValidationIDs="6"' + CHAR(13) + CHAR(10) 
				else	
				Begin		
					if @CertStatus = 'Test'
					begin
						Select @XMLInput = @XMLInput + 'StatusValidationIDs="14"' + CHAR(13) + CHAR(10) --Logo - Test Signed						
					end
					else  if @CertStatus = 'Dummy'
					begin
						Select @XMLInput = @XMLInput + 'StatusValidationIDs="1"' + CHAR(13) + CHAR(10) --Logo - N/A						
					end
					else if @CertStatus = 'WHQL'
					begin
						Select @XMLInput = @XMLInput + 'StatusValidationIDs="3"' + CHAR(13) + CHAR(10) --Logo - Microsoft Signed						 
					end
					else 
					begin 
						Select @XMLInput = @XMLInput + 'StatusValidationIDs=""' + CHAR(13) + CHAR(10)
					end
				End
				Select @XMLInput = @XMLInput + 'CVADefaultSourcePath=""' + CHAR(13) + CHAR(10) 
				Select @XMLInput = @XMLInput + 'CVASubPath="' + @CVASubpath + '"' + CHAR(13) + CHAR(10) -- will be generated by IRS
				end
			Select @XMLInput = @XMLInput + 'UserID="' + cast(@UserID as varchar(10)) + '"' + CHAR(13) + CHAR(10) -- UserID, this ID is from the person who creates the preinstall component
			Select @XMLInput = @XMLInput + 'SiteID="' + cast(@SiteID as varchar(10)) + '"' + CHAR(13) + CHAR(10) --HP - Pulsar Software siteID
			if @CDImage = 1
				begin
				Select @XMLInput = @XMLInput + 'MediaID="156"' + CHAR(13) + CHAR(10) 
				Select @XMLInput = @XMLInput + 'CDCategoryID="248"' + CHAR(13) + CHAR(10) 
				end
			if @CDImage <> 1
				begin
				Select @XMLInput = @XMLInput + 'ComponentTypeID="10"' + CHAR(13) + CHAR(10) -- Component Type = preinstall ALWAYS pass 10
				Select @XMLInput = @XMLInput + 'Generic="0"' + CHAR(13) + CHAR(10) -- Pass Zero (0) this value is used by Sudden Impact
				Select @XMLInput = @XMLInput + 'OSArchitecture_INFPath="' + coalesce(@OSArchitecture_INFPath,'') + '"' + CHAR(13) + CHAR(10) 
				Select @XMLInput = @XMLInput + 'EntryME_PCR0="' + coalesce(@EntryME_PCR0,'') + '"' + CHAR(13) + CHAR(10) 
				Select @XMLInput = @XMLInput + 'FullME_PCR0="' + coalesce(@FullME_PCR0,'') + '"' + CHAR(13) + CHAR(10) 
				end
			Select @XMLInput = @XMLInput + 'LanguageID="' + @IRSLanguageID + '"' + CHAR(13) + CHAR(10) -- Deliverable Language (43=Global)

			
			Select @XMLInput = @XMLInput + '>' + CHAR(13) + CHAR(10)
			


			DECLARE IRSCompLang_CURSOR CURSOR FOR Select cast(l.irsid as varchar(10))
													from language l WITH (NOLOCK) inner join
														Language_DelVer ld WITH (NOLOCK) on ld.Languageid = l.Id inner join
														DeliverableVersion d WITH (NOLOCK) on d.id = ld.DeliverableVersionid
													where d.ID = @VersionID
													and coalesce(l.irsid,0) <> 0
													and coalesce(l.irsid,0) <> 99999
												 
			open IRSCompLang_CURSOR
		
			FETCH NEXT FROM IRSCompLang_CURSOR Into @IRSLanguageID
			WHILE (@@fetch_status <> -1)
				BEGIN
					If (@@fetch_status <> -2)
						BEGIN
							Select @XMLInput = @XMLInput + '<Language LanguageID="' + @IRSLanguageID  + '" /> ' + CHAR(13) + CHAR(10)
						END
					FETCH NEXT FROM IRSCompLang_CURSOR Into @IRSLanguageID
				END
			DEALLOCATE IRSCompLang_CURSOR		

			if @LanguagesFound =0
				Select @XMLInput = @XMLInput + '<Language LanguageID="43" /> ' + CHAR(13) + CHAR(10)


			Select @XMLInput = @XMLInput + '<Country CountryID="241" />' + CHAR(13) + CHAR(10)					-- Supported Countries: Global
			if @CDImage <> 1
				Select @XMLInput = @XMLInput + dbo.ufn_GetComponentVersion_ExportCompliance(@VersionID, 1) + CHAR(13) + CHAR(10)	
--			Select @XMLInput = @XMLInput + '<ExportCompliance ExportCompliantID="All" />' + CHAR(13) + CHAR(10)
			Select @XMLInput = @XMLInput + @OSElements
			if 	@NotebookProductCount > 0
			begin
				Select @XMLInput = @XMLInput + '<EditPermission GroupID="315" />' + CHAR(13) + CHAR(10)             -- Commercial notebook Software Life Management GroupID
				Select @XMLInput = @XMLInput + '<EditPermission GroupID="314" />' + CHAR(13) + CHAR(10)				-- Consumer notebook Software Life Management GroupID
			end 
			if @ODMPermissions <> ''
				Select @XMLInput = @XMLInput + @ODMPermissions

			Select @XMLInput = @XMLInput + '</Parameters>' + CHAR(13) + CHAR(10)


			print ISNULL(@XMLInput, 'XMLInput IS NULL')

		end

			
		insert into SIExcalSyncLog (Message,TypeID, ObjectID,Success,Updated,Arg)
		values( 'Sending:' + ISNULL(@XMLInput,''),13, @VersionID,1,GetDate(),0)
				  
		Set @IRSPath = ''
		Set @NewIRSPartNumber = ''
		set @NewIRSID = 0
		set @NewRootID = 0
		set @NewRevisionID = 0
		set @NewVersionID = 0

		begin try
	
		IF @AddLanagugeOnly <> 0
			BEGIN
				PRINT 'Adding Language'
				set @Version = left(@Version,18)
				exec IRS_usp_NLCM_AddLanguages 
						@chr_paramXML=@XMLInput,
						@p_chrVersion = @Version,
						@p_intRootID = @NewRootID output,
						@p_intRevisionID= @NewRevisionID output,
						@p_intVersionID = @NewVersionID output,
						@p_intPassID = @NewIRSID output,
						@p_chrBinaryLocation = @IRSPath output,
						@p_chrPartNo = @NewIRSPartNumber output
			END
		else IF @CDImage = 1
			BEGIN
				PRINT 'Adding CD'
				exec IRS_usp_NLCM_CreateLangCDProperties  
						@p_chrParamXML=@XMLInput,
						@p_intRootID = @NewRootID output,
						@p_intRevisionID= @NewRevisionID output,
						@p_intVersionID = @NewVersionID output,
						@p_intPassID = @NewIRSID output,
						@p_chrCDSetNumber = @NewIRSPartNumber output
			END
		ELSE
			BEGIN
				PRINT 'Adding Component'
				exec IRS_usp_NLCM_CreateLangPIProperties 
						@p_chrParamXML=@XMLInput,
						@p_intRootID = @NewRootID output,
						@p_intRevisionID= @NewRevisionID output,
						@p_intVersionID = @NewVersionID output,
						@p_intPassID = @NewIRSID output,
						@p_chrBinaryLocation = @IRSPath output,
						@p_chrPartNo = @NewIRSPartNumber output
			END
				
			insert into SIExcalSyncLog (Message,TypeID, ObjectID,Success,Updated,Arg)
		values (coalesce(
				'PassID: ' + cast(@NewIRSID as varchar(200)) + 
				' RootID: ' + cast(@NewRootID as varchar(200)) +
				' VersionID: ' + cast(@NewVersionID as varchar(200)) +
				' RevisionID: ' + cast(@NewRevisionID as varchar(200)) +
				' Path: ' + cast(@IRSPath as varchar(200)) +
				' Part: ' + cast(@NewIRSPartNumber as varchar(200)) +
				' XML: ' + @XMLInput,'One of the values returned was null'),10, @VersionID,1,GetDate(),0)

										
		--Select @CVASubpath = coalesce(CVASubPath,''), @BaseFilePath=coalesce(BinaryLocation,'')
		--from irs_component_generalinfo
	--	where componentpassid=@NewIRSID
		IF @CDImage = 1
			BEGIN
				DECLARE @NewCDSetPartNumber varchar(18)
				SELECT @NewCDSetPartNumber = IRSPartNumber FROM DeliverableVersion WHERE ID = @VersionID;   --'IRS'+ replicate('P', 12 - len(convert(varchar, @VersionID))) + CAST(@VersionID AS varchar(10))

				UPDATE DeliverableVersion
					SET irsid = @NewIRSID, 
								   irsrevisionid = @NewRevisionID, 
								   IRSVersionID = @NewVersionID, 
				                   IRSRootID = @NewRootID --CVASubpath=@CVASubpath,BaseFilePath=@BaseFilePath,--CDPartnumber=coalesce(@NewIRSPartNumber,''),
				WHERE id = @VersionID

				UPDATE IRS_Component_GeneralInfo SET Partno = @NewCDSetPartNumber WHERE ComponentPassID = @NewIRSID AND DeliveryType=2
                UPDATE IRS_ComponentVersion SET Partno = @NewCDSetPartNumber WHERE Partno = @NewIRSPartNumber AND ComponentTypeID = 15
				UPDATE IRS_CDSetComponent SET Partno = @NewCDSetPartNumber WHERE Partno = @NewIRSPartNumber AND ComponentTypeID = 15
			END
		else
			update DeliverableVersion
			set irsid = @NewIRSID, irsrevisionid = @NewRevisionID, IRSVersionID = @NewVersionID, IRSRootID = @NewRootID --CVASubpath=@CVASubpath,BaseFilePath=@BaseFilePath,
			where id = @VersionID

		insert into SIExcalSyncLog (Message,TypeID, ObjectID,Success,Updated,Arg)
		Select cast(irsid as varchar(20)),12, @VersionID,1,GetDate(),0
		from deliverableversion WITH (NOLOCK)
		where id =@VersionID

		--Send Install Options
		exec spFusion_COMPONENT_UpdateInstallOptionsForVersion @VersionID
				 
		if @IRSFilesCopied = 7
		begin
			--Call walter's procedure to transfer the files (get the jobid)
			set @MFTJobID = 0
			Select @MFTCommand = 'java -jar seefx-client.jar get "irs_service_acct:9m9GlYVYJtdz5z2d@https://mftp.b2b.americas.hp.com/portal-seefx:/My Subscriptions/' + replace(@ImagePath,'SoftwareComponents/','SoftwareComponents#ppspcrd/') + '"  "\\16.102.80.48\fusion\DownloadZipFiles" -d -s=10 -v'
			Select @ZipFileName = RIGHT('\'+@ImagePath, CHARINDEX('\', REVERSE('\'+@ImagePath))-1)
			exec IRS_usp_LCMLang_ComponentDownload 
					@p_chrCommandPath=@MFTCommand,
					@p_chrEmail = @SubmitterEmail,
					@p_chrFileName = @ZipFileName,
					@p_chrTargetPath = @IRSPath ,
					@p_intEmail= @NotifySubmitter,--: 0 = Do not sent email. 1: send email when done
					@p_intJobID = @MFTJobID output

			--Update the deliverable version with the jobid, set IRSFileCopied = 8, and change the imagepath = irspath
			Update DeliverableVersion
			set mftjobid = @MFTJobID, IRSFilesCopied = 8--, imagepath=irspath, Initialpath=irspath
			where id = @versionID
		end

		end try
		begin catch

			SELECT @Errormsg = ERROR_MESSAGE()
			print 'Error Occurred: ' + @Errormsg

			insert into SIExcalSyncLog (Message,TypeID, ObjectID,Success,Updated,Arg)
			values ('Error Occurred Inserting into IRS: ' + coalesce(@Errormsg,''),10,@VersionID,1,GetDate(),0)



		end catch

		--waitfor delay '00:00:30'
				
		
	end
GO



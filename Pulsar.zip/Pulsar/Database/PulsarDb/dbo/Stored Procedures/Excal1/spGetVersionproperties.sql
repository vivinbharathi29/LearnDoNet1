﻿

CREATE PROCEDURE [dbo].[spGetVersionproperties] (@ID as int) AS
SELECT  v.deliverablename as Name, v.Version, v.Revision, v.Pass, v.PartNumber, v.ar, v.replicater, v.VendorVersion,v.VendorID, v.OtherDependencies, v.Status, v.DeveloperID, e.name as Developer, e.email as DeveloperEmail, v.ReleaseDoc, v.DeliverableSpec,v.SpecType, v.ImagePath, v.TDCImagePath, v.Path2Location, v.Path2Description, v.Path3Location, v.Path3Description, v.Archived, v.ArchivedPath2, v.ArchivedPath3, v.ArchivedTDC, v.ReleaseDate,v.IntroDate,v.EndOfLifeDate,  v.Comments, v.Changes
FROM 
	DeliverableVersion v with (NOLOCK)
	LEFT OUTER JOIN employee e with (NOLOCK) ON v.DeveloperID = e.ID
WHERE v.id = @ID

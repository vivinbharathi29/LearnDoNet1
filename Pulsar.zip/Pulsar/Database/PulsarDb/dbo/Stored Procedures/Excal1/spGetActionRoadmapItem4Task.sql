﻿

CREATE PROCEDURE [dbo].[spGetActionRoadmapItem4Task] 
(
	@ID int
)
AS

Select r.ID, r.ProductVersionID, r.Summary, r.Timeframe,r.DisplayOrder,r.Notes,r.ActionStatusID,r.Details
from actionroadmap r with (NOLOCK), deliverableissues a with (NOLOCK)
where a.id = @ID
and a.actionroadmapid = r.id



﻿
CREATE PROCEDURE [dbo].[spGetProductAndDeliverableInfoForIRSFeed]
(
	@ProductID int,
	@PartNumber varchar(18)
)
AS
-- =============================================
-- Author:		Excalibur Developers
-- Description:	Gets Components from IRS Product Drops
-- Modified By: 02/18/2016 wgomero: BUG 16743 (Images/Sync Images with IRS/Send Selected changes to IRS dispaly error at the end of the page.). The issue is a data issue, some component Names
--									have double quotes and this special char generates the error. The fix was to replace double quotes for blank chars to bypass the error during the feed. The solution
--									for this issue is not to allow components to be created with special chars that generates issues on other areas of the system.
--									Changed the Alter to CREATE in order for the build to run
--              11/23/2016 linshant: NotInRCD = 0 if RCDOnly is 1 for PBI 29199
--				12/07/2016 linshant: add DevlierableversionID for PBI 30357
--				03/20/2017 linshant: replace null with 0 for irscomponentpass column, InAppRecovery and DIB column - ticket 11305
-- =============================================
	declare @PDID int
	Declare @ProductName varchar(200)
	Declare @DeliverableName varchar(200)
	Declare @DeliverableID int
	Declare @Version varchar(200)
	Declare @Revision varchar(200)
	Declare @Pass varchar(200)
	declare @IRSComponentPassID int

	Select @PDID = pd.ID
	from product_deliverable pd WITH (NOLOCK), deliverableversion v WITH (NOLOCK)
	where  pd.deliverableversionid = v.id
	and pd.productversionid = @ProductID
	and v.irspartnumber = @PartNumber

	if @PDID is null
		begin
		
		Select @ProductName = DotsName
		from productversion
		where id = @ProductID

		Select @Deliverablename = deliverablename, @Version = version, @Revision = Revision, @Pass = Pass, @DeliverableID = ID, @IRSComponentPassID = IRSID
		from deliverableversion
		where irspartnumber = @PartNUmber

		Select @PartNumber as PartNumber, REPLACE(@Deliverablename,'"',' ') as DeliverableName, @Version as Version, @Revision as Revision, @Pass as Pass, @ProductID as ProductID, '' as ImageSummary,@DeliverableID as VersionID, '' as targetnotes,  '' as Images, null as PreviousVersionCount,null as PreviousVersionPartNumbers, @pdid as ProductDeliverableID, @IRSComponentPassID as IRSComponentPassID, null as SRP, null as NotInRCD, null as InAppRecovery, null as DIB, @ProductName as ProductName


		end
	else
		Select coalesce(v.IRSPartNumber, v.partnumber, '') as PartNumber, DeliverableName = REPLACE(v.DeliverableName,'"',' '), v.Version, v.Revision, v.Pass,pd.ProductversionID as ProductID, pd.ImageSummary,v.id as VersionID, pd.targetnotes,  cast(pd.images as varchar(max)) as Images, dbo.ufn_GetPreviousVersionsInImage(pd.Productversionid,pd.deliverableversionid) as PreviousVersionCount,dbo.ufn_GetPreviousVersionPartNumbersInImage(pd.Productversionid,pd.deliverableversionid) as PreviousVersionPartNumbers, pd.id as ProductDeliverableID, isnull(v.irsID,0) as IRSComponentPassID, case when pd.Preinstall=1 or pd.preload=1 then 1 else 0 end as SRP
		, case when pd.RCDOnly = 1 then 0 when pd.arcd=1 or pd.drdvd=1 then 0 else 1 end as NotInRCD
		, isnull(cast(pd.SelectiveRestore as int),0) as InAppRecovery, isnull(cast(pd.dropinbox as int),0) as DIB, p.dotsname as ProductName, v.ID as DevlierableversionID
		from product_deliverable pd WITH (NOLOCK), deliverableversion v WITH (NOLOCK), productversion p WITH (NOLOCK)
		where v.id = pd.DeliverableVersionID
		and p.id = pd.ProductVersionID
		and p.productversionid = @ProductID
		and v.irspartnumber = @PartNumber


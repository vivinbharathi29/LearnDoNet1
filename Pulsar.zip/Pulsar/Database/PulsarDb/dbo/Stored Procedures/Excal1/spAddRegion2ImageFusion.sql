﻿

CREATE PROCEDURE [dbo].[spAddRegion2ImageFusion]
(
	@ImageDefID int,
	@RegionID int,
	@Priority varchar(50),
	@Published bit,
	@ProductDrop varchar(30)
)
 AS
	DECLARE @OptionConfig as varchar(15)
	
	set nocount on
		Select @OptionConfig = optionconfig
		from Regions
		where ID = @RegionID
		
		if @OptionConfig is null
			Select @OptionConfig = ''

			
	set nocount off
	
	if @ProductDrop = ''
		Insert Images (ImageDefinitionID,Priority, RegionID, Modified, skunumber, Published )
		Values (@ImageDefID, @Priority, @RegionID, GetDate(),'',@Published)
	else
		Insert Images (ImageDefinitionID,Priority, RegionID, Modified, skunumber,Published )
		Values (@ImageDefID, @Priority, @RegionID, GetDate(),LEFT(@ProductDrop + @OptionConfig  ,45),@Published)
	
	
	
/*
set nocount on
If (RIGHT(RTRIM(@Priority),1) = 'x')
BEGIN
update images
set skunumber = left(d.skunumber, 6) + left(LTRIM(@priority), 3) + right(d.skunumber, 1)
from imagedefinitions d WITH (NOLOCK) inner join
	images i  WITH (NOLOCK) on d.id = i.imagedefinitionid inner join
	regions r  WITH (NOLOCK) on i.regionid = r.id
where i.id = scope_identity()
END
ELSE
BEGIN
update images
set skunumber = left(d.skunumber, 6) + left(r.dash, 3) + right(d.skunumber, 1)
from imagedefinitions d WITH (NOLOCK) inner join
	images i WITH (NOLOCK) on d.id = i.imagedefinitionid inner join
	regions r WITH (NOLOCK) on i.regionid = r.id
where i.id = scope_identity()
END
set nocount off
*/


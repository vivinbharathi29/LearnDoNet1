﻿CREATE PROCEDURE [dbo].[spListAllActionOwners]
/* ************************************************************************************************
 * Purpose:  List users who can be Approver
 * Created By:	?
 * Modified By:	09/13/2016, Herb, Only list Active user, to avoid unavailable approver.
 *															
************************************************************************************************** 
**	Change History
**********************************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  9/5/2018	Aashish				Removed the distinct from main query. Chnaged to ANSI.Added SET NOCOUNT.
**********************************************************************************************/
AS
SET NOCOUNT ON
SELECT 
	ID,
	Name
FROM 
(
	SELECT DISTINCT
		e.UserId AS ID,
		e.FullName AS Name
	FROM deliverableissues i WITH (NOLOCK)
	INNER JOIN UserInfo e WITH (NOLOCK)
		ON e.UserId = i.OwnerID
	WHERE e.Active = 1

	UNION

	SELECT DISTINCT
		e.UserId AS ID,
		e.FullName AS Name
	FROM actionapproval a WITH (NOLOCK) 
	INNER JOIN UserInfo e WITH (NOLOCK)
		ON e.UserId = a.approverid
	WHERE e.Active = 1
) a
ORDER BY NAME

SET NOCOUNT OFF
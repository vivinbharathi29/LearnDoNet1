﻿
CREATE PROCEDURE [dbo].[spGetCategoryPM]
(
	@VersionID int
)
AS

	DECLARE @FieldName as varchar(200)
	DECLARE @sql as varchar(8000)


	Select @FieldName = ct.PMFieldName 
	from deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK), deliverablecategory c with (NOLOCK), DeliverableCategoryTeam ct with (NOLOCK)
	where c.id = r.categoryid
	and ct.id = c.teamid
	and r.id = v.deliverablerootid
	and v.id = @VersionID


	select @sql = 'Select e.email from productversion v, employee e where v.[' + @FieldName + '] = e.id and v.id=433'
	exec (@sql)





﻿
CREATE PROCEDURE [dbo].[spGetPINPMList4MyDevCenter]
(
	@PINPMID int
)
AS

 Declare @DevCenter int

 Select @DevCenter = Min(devcenter)
					from productversion with (NOLOCK)
					where PINPM=@PINPMID

if @DevCenter=2
	Select distinct e.ID, e.Email, e.Name, e.domain, e.ntname
	from employee e with (NOLOCK), productversion v with (NOLOCK)
	where e.id = v.PINPM
	and v.active=1
	and v.devcenter=2
	and typeid=1
	and v.id <> 100
	order by e.Name

else
	Select distinct e.ID, e.Email, e.Name, e.domain, e.ntname
	from employee e with (NOLOCK), productversion v with (NOLOCK)
	where e.id = v.PINPM
	and v.active=1
	and v.devcenter<>2
	and typeid=1
	and v.id <> 100
	order by e.Name



﻿/**************************************************************************************************        
** Author  :            
** Description :                
** Date   :         
**************************************************************************************************        
** Change History                
**************************************************************************************************        
** SNo   Date        Author                                    Description                
** --    --------   -------                                   -------------------------                
 ** 1    27/12/2018  Santhana K          Changed the Text Data type to Varchar(max) for @Action and @Resolution    
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spAddDeliverableActionWeb2] 
/* ************************************************************************************************    
 * Purpose:     
 * Created By:      
 * Modified By: 01/07/2016, SPathak - do not save the justification for ODM user     
 *    02/08/2016, Harris, Valerie - PBI 15660/ Task 16234 - Add ProductVersionRelease and ChangeRequestID fields    
 *    08/11/2017 wgomero: PBI 93328 add AVRequired and QualificationRequired fields     
    08/15/2017 buidi: PBI91714 change americas param to NA and LA     
    08/18/2017 shraddha: add the target approval date to DCR PBI 93230     
    08/22/2017 buidi PBI93229 add attachment to dcr     
    10/16/2017 buidi make changerequestid unique when new dcr is added     
  **************************************************************************************************/
(@ProductID             INT, 
 @DeliverableRootId     INT, 
 @Type                  TINYINT, 
 @Status                TINYINT, 
 @Submitter             VARCHAR(50), 
 @SubmitterID           INT, 
 @CategoryID            INT, 
 @OwnerID               INT, 
 @PreinstallOwner       INT, 
 @AffectsCustomers      TINYINT, 
 @CoreTeamID            INT, 
 @RoadmapID             INT, 
 @TargetDate            DATETIME, 
 @TestDate              DATETIME, 
 @TestNote              VARCHAR(35), 
 @BTODate               DATETIME, 
 @CTODate               DATETIME, 

 --@Distribution varchar(4),     
 @Notify                VARCHAR(8000), 
 @OnStatus              TINYINT, 
 @Priority              TINYINT, 
 @Commercial            BIT, 
 @Consumer              BIT, 
 @SMB                   BIT, 
 @NA                    BIT, 
 @LA                    BIT, 
 @APJ                   BIT, 
 @EMEA                  BIT, 
 @AddChange             BIT, 
 @ModifyChange          BIT, 
 @RemoveChange          BIT, 
 @ImageChange           BIT, 
 @CategoryBiosChange    BIT, 
 @CommodityChange       BIT, 
 @DocChange             BIT, 
 @SKUChange             BIT, 
 @ReqChange             BIT, 
 @BiosChange            BIT, 
 @SwChange              BIT, 
 @IDChange              BIT, 
 @OtherChange           BIT, 
 @PendingImplementation BIT, 
 @Summary               VARCHAR(120), 
 @Description           VARCHAR(8000), 
 @Justification         VARCHAR(8000), 
 @Details               VARCHAR(8000), 
 @LastUpdUser           VARCHAR(200), 
 @Actions               VARCHAR(max), 
 @Resolution            VARCHAR(max), 
 @ZsrpReadyTargetDt     DATETIME, 
 @ZsrpReadyActualDt     DATETIME, 
 @ZsrpRequired          BIT, 
 @RTPDate               DATETIME, 
 @RASDiscoDate          DATETIME, 
 @ProductVersionRelease VARCHAR(max), 
 @ChangeRequestID       BIGINT, 
 @AVRequired            BIT, 
 @QualificationRequired BIT, 
 @TargetApprovalDate    DATETIME, 
 @Important             BIT, 
 @NewID                 INT output, 
 @Attachment1           VARCHAR(500) = '', 
 @Attachment2           VARCHAR(500) = '', 
 @Attachment3           VARCHAR(500) = '', 
 @Attachment4           VARCHAR(500) = '', 
 @Attachment5           VARCHAR(500) = '',
 @DeliverableIssueID    INT = 0) 
AS 
    DECLARE @ActualDate DATETIME 

    IF @Status = 2 
        OR @Status = 4 
        OR @Status = 5 
      SELECT @ActualDate = Getdate() 
    ELSE 
      SELECT @ActualDate = NULL 

    IF @DeliverableIssueID = 0 
      BEGIN 
          WHILE (SELECT Count(1) 
                 FROM   DeliverableIssues 
                 WHERE  ChangeRequestID = @ChangeRequestID) > 0 
            BEGIN 
                SET @ChangeRequestID = (SELECT Max(ChangeRequestID) 
                                        FROM   DeliverableIssues) 
                                       + 1 
            END; 
      END 
    ELSE 
      BEGIN 
          SELECT @ChangeRequestID = ChangeRequestID 
          FROM   DeliverableIssues 
          WHERE  ID = @DeliverableIssueID 
      END 

    INSERT DeliverableIssues 
           (ActionRoadmapID, 
            ActualDate, 
            AvailableForTest, 
            AvailableNotes, 
            Commercial, 
            Consumer, 
            SMB, 
            ImageChange, 
            CategoryBiosChange, 
            CommodityChange, 
            DocChange, 
            SKUChange, 
            ReqChange, 
            OtherChange, 
            PendingImplementation, 
            PreinstallOwnerID, 
            AffectsCustomers, 
            Priority, 
            AddChange, 
            ModifyChange, 
            RemoveChange, 
            NA, 
            LA, 
            APJ, 
            EMEA, 
            Justification, 
            CTODate, 
            BTODate, 
            --Distribution,      
            Summary, 
            CoreTeamRep, 
            CategoryID, 
            Submitter, 
            Submitterid, 
            DeliverableRootID, 
            Productversionid, 
            Type, 
            Status, 
            OwnerID, 
            TargetDate, 
            Description, 
            Notify, 
            OnStatusReport, 
            Details, 
            Actions, 
            Resolution, 
            Created, 
            BiosChange, 
            SwChange, 
            IDChange, 
            LastUpdUser, 
            ZsrpReadyTargetDt, 
            ZsrpReadyActualDt, 
            ZsrpRequired, 
            RTPDate, 
            RASDiscoDate, 
            ProductVersionRelease, 
            ChangeRequestID, 
            AVRequired, 
            QualificationRequired, 
            TargetApprovalDate, 
            Important, 
            Attachment1, 
            Attachment2, 
            Attachment3, 
            Attachment4, 
            Attachment5) 
    VALUES( @RoadmapID, 
            @ActualDate, 
            @TestDate, 
            @TestNote, 
            @Commercial, 
            @Consumer, 
            @SMB, 
            @ImageChange, 
            @CategoryBiosChange, 
            @CommodityChange, 
            @DocChange, 
            @SKUChange, 
            @ReqChange, 
            @OtherChange, 
            @PendingImplementation, 
            @PreinstallOwner, 
            @AffectsCustomers, 
            @Priority, 
            @AddChange, 
            @ModifyChange, 
            @RemoveChange, 
            @NA, 
            @LA, 
            @APJ, 
            @EMEA, 
            @Justification, 
            @CTODate, 
            @BTODate, 
            --@Distribution,     
            @Summary, 
            @CoreTeamID, 
            @CategoryID, 
            @Submitter, 
            @SubmitterID, 
            @DeliverableRootID, 
            @ProductID, 
            @Type, 
            @Status, 
            @OwnerID, 
            @TargetDate, 
            @Description, 
            @Notify, 
            @OnStatus, 
            @Details, 
            @Actions, 
            @Resolution, 
            Getdate(), 
            @BiosChange, 
            @SwChange, 
            @IDChange, 
            @LastUpdUser, 
            @ZsrpReadyTargetDt, 
            @ZsrpReadyActualDt, 
            @ZsrpRequired, 
            @RTPDate, 
            @RASDiscoDate, 
            @ProductVersionRelease, 
            @ChangeRequestID, 
            @AVRequired, 
            @QualificationRequired, 
            @TargetApprovalDate, 
            @Important, 
            @Attachment1, 
            @Attachment2, 
            @Attachment3, 
            @Attachment4, 
            @Attachment5 ) 

    SELECT @NewID = Scope_identity() 

go 
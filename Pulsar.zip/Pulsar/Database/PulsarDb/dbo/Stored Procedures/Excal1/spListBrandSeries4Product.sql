﻿
--spListBrandSeries4Product 1204

CREATE PROCEDURE [dbo].[spListBrandSeries4Product]

(
	@ProductID int
)
 AS

	Select l.ID, l.Name,l.streetname,l.streetname2,l.streetname3, l.suffix,l.RASSegment, l.active,s.name, l.abbreviation, v.version as productversion, v.productname as productfamily, p.ID as ProductBrandID, v.dotsname as product, v.id as ProductID, l.id as brandid, pn.name as Partner,
	l.streetname + ' ' + s.name + ' ' + l.suffix as Series, l.streetname2 + ' ' + s.name as ShortName, l.streetname3 + ' ' + s.name as LogoBadge
	from Series s with (NOLOCK),Brand l with (NOLOCK), product_brand p with (NOLOCK), productversion v with (NOLOCK), productfamily f with (NOLOCK), Partner pn with (NOLOCK)
	where p.productversionid = @ProductID
	and v.id = p.productversionid
	and p.BrandID =  l.id
	and v.partnerid = pn.id
	and f.id = v.productfamilyid
	and s.productbrandid = p.id
	order by displayorder





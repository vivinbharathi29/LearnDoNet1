﻿

CREATE PROCEDURE [dbo].[spGetPartnerName]
(
	@ID int
)
AS

Select Name, OTSVendorGroupID, PartnerTypeID
from Partner with (NOLOCK)
where Id = @ID



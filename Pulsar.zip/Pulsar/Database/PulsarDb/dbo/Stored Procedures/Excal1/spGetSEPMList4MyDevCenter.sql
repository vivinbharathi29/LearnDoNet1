﻿
CREATE PROCEDURE [dbo].[spGetSEPMList4MyDevCenter]
(
	@SEPMID int
)
AS

 Declare @DevCenter int

 Select @DevCenter = Min(devcenter)
					from productversion
					where sepmid=@SEPMID

if @DevCenter=2
	Select distinct e.ID, e.Email, e.Name, e.domain, e.ntname
	from employee e with (NOLOCK), productversion v with (NOLOCK)
	where e.id = v.sepmid
	and v.productstatusid < 4
	and v.devcenter=2
	and typeid=1
	and v.id <> 100
	order by e.Name
else
	Select distinct e.ID, e.Email, e.Name, e.domain, e.ntname
	from employee e with (NOLOCK), productversion v with (NOLOCK)
	where e.id = v.sepmid
	and v.productstatusid < 4
	and v.devcenter<>2
	and typeid=1
	and v.id <> 100
	order by e.Name



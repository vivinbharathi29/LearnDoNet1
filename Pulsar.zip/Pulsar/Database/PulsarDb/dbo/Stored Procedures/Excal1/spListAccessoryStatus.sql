﻿

CREATE PROCEDURE [dbo].[spListAccessoryStatus]

 AS

Select ID, Name, DateField, CommentsRequired
from Accessorystatus with (NOLOCK)
order by id




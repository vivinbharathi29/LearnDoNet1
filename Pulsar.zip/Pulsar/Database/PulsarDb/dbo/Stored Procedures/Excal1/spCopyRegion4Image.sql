﻿

CREATE PROCEDURE [dbo].[spCopyRegion4Image]
(
	@CopyID int,
	@NewImageDefID int,
	@NewID int output
)
 AS
Insert Images (ImageDefinitionID,Priority, RegionID, Modified )
(Select @NewImageDefID as ImageDefinitionID,Priority, RegionID, GetDate()
FROM Images with (NOLOCK)
where ID = @CopyID
)
Select @NewID = SCOPE_IDENTITY()




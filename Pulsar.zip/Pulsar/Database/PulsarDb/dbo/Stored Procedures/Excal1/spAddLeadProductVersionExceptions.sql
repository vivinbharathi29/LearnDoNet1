﻿CREATE PROCEDURE [dbo].[spAddLeadProductVersionExceptions]
(
	@ProductID int,
	@VersionID int,
	@SyncDistribution bit,
	@SyncImages bit,
	@SyncNotes bit,
	@ReleaseID int = 0
)
AS

	DECLARE @RootCount int
	DECLARE @VersionCount int
	DECLARE @RootID int

	SELECT @RootID=deliverablerootid
	from deliverableversion with (NOLOCK)
	where id = @VersionID 

	if @ReleaseID = 0 
	begin 
		Select @RootCount  = count(1)
		from product_delroot with (NOLOCK)
		where ProductVersionID = @ProductID
		and DeliverableRootID = @RootID 

		Select @VersionCount  = count(1)
		from product_deliverable with (NOLOCK)
		where ProductVersionID = @ProductID
		and DeliverableVersionID = @VersionID 

		begin transaction

		if @RootCount=0
			exec spAddDelRoot2Product @ProductID,@RootID

		if @VersionCount=0
			exec spLinkVersion2Product @ProductID, @VersionID		

		update product_deliverable
		set SyncImages = @SyncImages, SyncNotes=@SyncNotes, SyncDistribution=@SyncDistribution
		where productversionid = @ProductID
		and deliverableversionid = @VersionID
	
		commit transaction
	end
	else
	begin
		Select @RootCount  = count(1)
		from product_delroot pdr with (NOLOCK) inner join
		Product_DelRoot_Release pdrr with (NOLOCK) ON pdr.id = pdrr.ProductDelRootID
		where ProductVersionID = @ProductID
		and DeliverableRootID = @RootID 
		and pdrr.ReleaseID = @ReleaseID

		Select @VersionCount  = count(1)
		from product_deliverable pd with (NOLOCK) inner join
		Product_Deliverable_Release pdr with (NOLOCK) ON pd.id = pdr.ProductDeliverableID
		where ProductVersionID = @ProductID
		and DeliverableVersionID = @VersionID 
		and pdr.ReleaseID = @ReleaseID

		begin transaction
		
		Declare @ProductVersionReleaseID int 
		Select @ProductVersionReleaseID = ID From ProductVersion_Release Where ProductVersionID = @ProductID and ReleaseID = @ReleaseID 

		if @RootCount=0
			exec spAddDelRoot2Product @ProductID,@RootID,0,0,0,0,0,0,@ProductVersionReleaseID,0,''

		if @VersionCount=0
			exec spLinkVersion2Product @ProductID, @VersionID, @ProductVersionReleaseID	

		update pdr
		set SyncImages = @SyncImages, SyncNotes=@SyncNotes, SyncDistribution=@SyncDistribution
		from Product_Deliverable_Release pdr inner join
		Product_Deliverable pd on pdr.ProductDeliverableID = pd.id 
		where pd.ProductVersionID = @ProductID and pd.DeliverableVersionID = @VersionID and pdr.ReleaseID = @ReleaseID
	
		commit transaction
	end
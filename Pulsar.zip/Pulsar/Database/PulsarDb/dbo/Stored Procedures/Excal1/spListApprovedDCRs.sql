﻿


CREATE PROCEDURE [dbo].[spListApprovedDCRs]
(
	@ProdID int,
	@ShowAll int = 0
)
 AS
if @Showall = 0
	Select i.ID, s.name as Status, i.ActualDate as ApprovalDate,
	Summary = ISNULL(i.Summary, ''), Submitter
	FROM DeliverableIssues i with (NOLOCK), ActionStatus s with (NOLOCK)
	Where i.type=3
	and s.id = i.status
	and i.status = 4
	and i.Productversionid = @Prodid
	order by i.id
else
	Select i.ID, s.name as Status, i.ActualDate as ApprovalDate, 
	Summary =ISNULL(i.Summary, ''), Submitter
	FROM DeliverableIssues i with (NOLOCK), ActionStatus s with (NOLOCK)
	Where i.type=3
	and s.id = i.status
	and i.Productversionid = @Prodid
	order by i.id




﻿CREATE PROCEDURE [dbo].[spAddProductRTMDeliverable]
(
	@ProductRTMID int,
	@DeliverableVersionID int,
	@TypeID int,
	@Details Varchar(300),
	@RTMDraftDeliverableRemove int=0
)
AS

IF(@RTMDraftDeliverableRemove=1)
	  BEGIN
	  SET NOCOUNT ON
		delete  from ProductRTM_DeliverableVersion where ProductRTMID=@ProductRTMID and TypeID=@TypeID
	  SET NOCOUNT OFF
	  END
	Insert into ProductRTM_DeliverableVersion (ProductRTMID,DeliverableVersionID,TypeID,Details)
	Values(@ProductRTMID,@DeliverableVersionID,@TypeID,@Details)
﻿

/****** Object:  Stored Procedure dbo.spAddNewProductFamily    Script Date: 9/26/00 7:13:22 PM ******/
CREATE PROCEDURE [dbo].[spAddNewProductFamily]
 (
  @FamilyName varchar(100),
  @ID int=NULL OUTPUT
 )
As
 INSERT ProductFamily(Name,Active)
 Values (@FamilyName,1) 
 SELECT @ID = SCOPE_IDENTITY()
 return 




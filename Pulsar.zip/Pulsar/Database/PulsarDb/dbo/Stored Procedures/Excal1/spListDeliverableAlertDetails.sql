﻿

CREATE PROCEDURE [dbo].[spListDeliverableAlertDetails]
(
	@ProdID int,
	@VersionID int
)
AS

SELECT        
	l.Name AS Buildlevel, l.ID AS LevelID, pd.DeveloperNotificationStatus, v.Location, r.CertRequired, v.CertificationStatus, v.EndOfLifeDate AS EOLDate, 
    pd.Targeted, pd.Preinstall, pd.Preload, pd.DropInBox, pd.Patch, pd.Web, pd.SelectiveRestore, pd.ARCD, pd.DRDVD, pd.RACD_EMEA, pd.RACD_APD, 
    pd.RACD_Americas, pd.DocCD, pd.OSCD, v.ID, r.ID AS RootID, v.PostRTMStatus, v.PostRTMTargetDate, r.CategoryID, r.Active, r.TypeID, 
    v.PreinstallInternalRev, v.CertificationStatus AS Expr1, v.PostRTMComments, r.Name, vd.Name AS vendor, v.Version, v.Revision, v.Pass, v.PartNumber, 
    v.ModelNumber, v.Filename, v.DeliverableName, p.ProductStatusID
FROM            
	ProductVersion AS p WITH (NOLOCK) INNER JOIN
    Product_Deliverable AS pd WITH (NOLOCK) ON p.ID = pd.ProductVersionID INNER JOIN
    DeliverableVersion AS v WITH (NOLOCK) INNER JOIN
    DeliverableRoot AS r WITH (NOLOCK) ON v.DeliverableRootID = r.ID INNER JOIN
    Vendor AS vd WITH (NOLOCK) ON v.VendorID = vd.ID LEFT OUTER JOIN
    DeliverableLevel AS l WITH (NOLOCK) ON v.LevelID = l.ID ON pd.DeliverableVersionID = v.ID
WHERE
	v.id = @VersionID
	and p.id = @ProdID

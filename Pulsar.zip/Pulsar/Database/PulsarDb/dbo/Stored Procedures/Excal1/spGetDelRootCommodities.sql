﻿
CREATE PROCEDURE [dbo].[spGetDelRootCommodities]

 AS

Select r.id, r.name
from deliverablecategory c with (NOLOCK), deliverableroot r with (NOLOCK)
where r.categoryid = c.id
and r.typeid=1
and r.rootfilename <> 'HFCN'
order by r.name


﻿
CREATE PROCEDURE [dbo].[spGetMUILanguages]
(
	@OSID int,
	@RegionID int
)
AS

	Select ofr.MUILanguages
	from OSFamily_Regions ofr with (NOLOCK), oslookup o with (NOLOCK)
	where o.osfamilyid = ofr.osfamilyid
	and regionid = @RegionID
	and o.id = @OSID


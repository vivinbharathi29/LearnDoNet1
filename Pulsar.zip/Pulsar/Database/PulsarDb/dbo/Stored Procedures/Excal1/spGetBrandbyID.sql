﻿

CREATE PROCEDURE [dbo].[spGetBrandbyID]
(
  @BrandID int = -1
)
AS
Select ID, Name, null as SeriesSummary, Abbreviation, null as ProductBrandID, active
From Brand with (NOLOCK)
Where Active = 1
and id=@BrandID


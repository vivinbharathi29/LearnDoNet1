﻿

CREATE PROCEDURE [dbo].[spListCountriesWithLocalizations]

(
	@RegionID int = 0
)

AS

if @RegionID=0
	Select distinct l.Language as Country, l.region as Region , r.optionconfig, l.export, r.id as RegionID,r.consumer, r.commercial, r.tablet
	from Language l with (NOLOCK), Country_localization  cl with (NOLOCK), regions r with (NOLOCK)
	where l.IsLanguage = 0
	and cl.countryid = l.id
	and r.id = cl.localizationid
	and l.active=1
	and r.active=1


Union

	Select l.Language as Country, l.region as Region, null, l.export, null,null,null,null
	from Language l with (NOLOCK)
	where l.IsLanguage = 0
	and l.active=1
	and id not in (
		Select Distinct CountryID
		from Language l with (NOLOCK), Country_localization cl with (NOLOCK)
		where l.IsLanguage = 0
		and cl.countryid = l.id
		and l.active=1)
	
	order by l.region desc, l.Language asc
else
	Select distinct l.Language as Country, l.region as Region , r.optionconfig, l.export, r.id as RegionID,r.consumer, r.commercial, r.tablet
	from Language l with (NOLOCK), Country_localization  cl with (NOLOCK), regions r with (NOLOCK), ( Select CountryID
								from country_localization with (NOLOCK)
								where localizationid = @RegionID
								) as c
	where l.IsLanguage = 0
	and cl.countryid = l.id
	and r.id = cl.localizationid
	and l.active=1
	and r.active=1
	and c.CountryID = cl.CountryID
	order by l.region desc, l.Language asc


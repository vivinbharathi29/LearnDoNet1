﻿CREATE PROCEDURE [dbo].[spGetDevProductionReleaseEmailInfoPulsar]
/*
	Puropose: get Dev Production Release Email from Release
*/
(
	@ID int
)
AS
	Select	p.id as ProductID, r.name as Deliverable, ct.pmfieldname, p.platformdevelopmentid, p.VideoMemoryPMID, p.GraphicsControllerPMID, p.ProcessorPMID, p.SEPMID, p.PINPM, p.AccessoryPMID, p.CommHWPMID, p.pdeid, 
			pdr.developerteststatus, pdr.developertestnotes, v.id as VersionID, p.dotsname as Product, v.revision, v.version, v.pass, v.partnumber, v.modelnumber, vd.name as Vendor
	from	product_deliverable pd with (NOLOCK) inner join
			deliverableversion v with (NOLOCK) on v.id = pd.deliverableversionid inner join
			productversion p with (NOLOCK) on p.id = pd.productversionid inner join
			deliverableroot r with (NOLOCK) on r.id = v.deliverablerootid inner join
			vendor vd with (NOLOCK) on v.vendorid = vd.id inner join
			deliverablecategory c with (NOLOCK) on c.id = r.categoryid inner join
			deliverablecategoryteam ct with (NOLOCK) on ct.id = c.teamid inner join
			Product_Deliverable_Release pdr with (NOLOCK) on pdr.ProductDeliverableID = pd.ID
	where pdr.id = @ID
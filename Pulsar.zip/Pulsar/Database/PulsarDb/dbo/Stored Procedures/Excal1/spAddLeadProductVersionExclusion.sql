﻿CREATE PROCEDURE [dbo].[spAddLeadProductVersionExclusion] 
/* ************************************************************************************************
 * Purpose:	"Add Lead Product Version Exclusions" section in TodayPage
 * Created By:	?
 * Modified By: 03/23/2018 - buidi - Assign Lead Product Version Release to Release
 **************************************************************************************************/
(
	@ProductVersionID int, --Follower Product
	@DeliverableVersionID int,
	@Comments varchar(8000) = '',
	@ReleaseID int = 0
)
AS
	Insert Into ProductLeadRootExceptions(ProductVersionID, DeliverableVersionID,Comments,ReleaseID)
	Values(@ProductVersionID, @DeliverableVersionID,@Comments, @ReleaseID)
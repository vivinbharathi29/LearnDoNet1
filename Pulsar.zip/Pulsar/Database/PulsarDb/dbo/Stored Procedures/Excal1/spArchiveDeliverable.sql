﻿
CREATE PROCEDURE [dbo].[spArchiveDeliverable]
(
	@ID int,
	@Contact tinyint,
	@PathFlag int = 1
)
 AS
if @PathFlag = 1 
	Update DeliverableVersion
	set Archived=@Contact
	where ID = @ID
if @PathFlag = 2 
	Update DeliverableVersion
	set ArchivedPath2 =  @Contact
	where ID = @ID
if @PathFlag = 3 
	Update DeliverableVersion
	set ArchivedPath3 =  @Contact
	where ID = @ID
if @PathFlag = 4
	Update DeliverableVersion
	set ArchivedTDC =  @Contact
	where ID = @ID



﻿
CREATE PROCEDURE [dbo].[spListDeliverableHWByStatus]
(
	@Status int,
	@Report int = 1,
	@DateStart datetime = null,
	@DateEnd datetime = null
)
AS

if @DateEnd = ''
	Select @DateEnd = null
if @DateStart = ''
	Select @DateStart = null

if @Report=1 and @Status = 19 --QualStatus - Risk Release
	Select pd.PilotDate, pd.TestDate, pt.name as partner, pd.TestStatusID_Last_Upd_Dt as StatusUpdatedDate, pd.ID as ProdDelID, p.ID as ProdID, v.ID as DelID, p.dotsname as Product, e.name as PM, r.name as Deliverable, v.version, v.revision, v.pass, v.partnumber, v.modelnumber, vd.Name as Vendor, pd.targetnotes as QualComments, pd.pilotNotes as PilotComments, v.comments as devComments
	from product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK), productversion p with (NOLOCK), partner pt with (NOLOCK), deliverablecategory c with (NOLOCK), employee e with (NOLOCK), Vendor vd with (NOLOCK)
	where p.id = pd.productversionid
	and v.id = pd.deliverableversionid
	and r.id = v.deliverableRootID
	and pt.id = p.partnerid
	and c.id = r.categoryid
	and vd.id = v.vendorid
	and e.id = p.pdeid
	--and c.commodity=1
	and r.typeid = 1
	and pd.teststatusid=5
	and pd.riskrelease=1
	and p.oncommoditymatrix = 1
	and (pd.teststatusid <> 3
		 or 
			(
			pd.teststatusid = 3 and 
			testdate between coalesce(@DateStart,'1/1/1753') and coalesce(@DateEnd,'1/1/3000') 
			)
		)	
	order by Product, Vendor, Deliverable

else if @Report=1 --Qual Status - Other

	Select pd.PilotDate, pd.TestDate, pt.name as partner, pd.TestStatusID_Last_Upd_Dt as StatusUpdatedDate, pd.ID as ProdDelID, p.ID as ProdID, v.ID as DelID, p.dotsname as Product, e.name as PM, r.name as Deliverable, v.version, v.revision, v.pass, v.partnumber, v.modelnumber, vd.Name as Vendor, pd.targetnotes as QualComments, pd.pilotNotes as PilotComments, v.comments as devComments
	from product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK), productversion p with (NOLOCK), partner pt with (NOLOCK), deliverablecategory c with (NOLOCK), employee e with (NOLOCK), Vendor vd with (NOLOCK)
	where p.id = pd.productversionid
	and v.id = pd.deliverableversionid
	and r.id = v.deliverableRootID
	and pt.id = p.partnerid
	and c.id = r.categoryid
	and vd.id = v.vendorid
	and e.id = p.pdeid
	--and c.commodity=1
	and r.typeid = 1
	and pd.teststatusid=@Status
	and p.oncommoditymatrix = 1
	and (pd.teststatusid <> 3
		 or 
			(
			pd.teststatusid = 3 and 
			testdate between coalesce(@DateStart,'1/1/1753') and coalesce(@DateEnd,'1/1/3000') 
			)
		)	
	order by Product, Vendor, Deliverable

else if @Report=2 --PilotStatus

SELECT        
	pd.PilotDate, pd.TestDate, pt.Name AS partner, pd.ID AS ProdDelID, p.ID AS ProdID, v.ID AS DelID, p.DOTSName AS Product, e.Name AS PM, 
    r.Name AS Deliverable, v.Version, v.Revision, v.Pass, v.PartNumber, v.ModelNumber, vd.Name AS Vendor, pd.TargetNotes AS QualComments, 
    pd.PilotNotes AS PilotComments, v.Comments AS DevComments
FROM            
	Product_Deliverable AS pd WITH (NOLOCK) INNER JOIN
    ProductVersion AS p WITH (NOLOCK) ON pd.ProductVersionID = p.ID INNER JOIN
    DeliverableVersion AS v WITH (NOLOCK) ON pd.DeliverableVersionID = v.ID INNER JOIN
    DeliverableRoot AS r WITH (NOLOCK) ON v.DeliverableRootID = r.ID INNER JOIN
    Partner AS pt WITH (NOLOCK) ON p.PartnerID = pt.ID INNER JOIN
    DeliverableCategory AS c WITH (NOLOCK) ON r.CategoryID = c.ID INNER JOIN
    Vendor AS vd WITH (NOLOCK) ON v.VendorID = vd.ID LEFT OUTER JOIN
    Employee AS e WITH (NOLOCK) ON p.SCFactoryEngineerID = e.ID
WHERE
	r.typeid = 1
	--	and c.commodity=1
	and pd.pilotstatusid=@Status
	and p.oncommoditymatrix = 1
	and (pd.pilotstatusid <> 2
		 or 
			(
			pd.pilotstatusid = 2 and 
			pilotdate between coalesce(@DateStart,'1/1/1753') and coalesce(@DateEnd,'1/1/3000') 
			)
	 )	
	and (pd.pilotstatusid <> 6
		 or 
			(
			pd.pilotstatusid = 6 and 
			pilotdate between coalesce(@DateStart,'1/1/1753') and coalesce(@DateEnd,'1/1/3000') 
			)
	 )	

	order by Product, Vendor, Deliverable
else  --AccessoryStatus

	Select pd.AccessoryDate, pd.TestDate, pt.name as partner, pd.ID as ProdDelID, p.ID as ProdID, v.ID as DelID, p.dotsname as Product, e.name as PM, r.name as Deliverable, v.version, v.revision, v.pass, v.partnumber, v.modelnumber, vd.Name as Vendor, pd.targetnotes as QualComments, pd.Accessorynotes as AccessoryComments, v.comments as DevComments
	from product_deliverable pd with (NOLOCK), deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK), productversion p with (NOLOCK), partner pt with (NOLOCK), deliverablecategory c with (NOLOCK), employee e with (NOLOCK), Vendor vd with (NOLOCK)
	where p.id = pd.productversionid
	and v.id = pd.deliverableversionid
	and r.id = v.deliverableRootID
	and pt.id = p.partnerid
	and c.id = r.categoryid
	and vd.id = v.vendorid
	and e.id = p.accessorypmid
	and c.accessory=1
	and pd.accessorystatusid=@Status
	and p.oncommoditymatrix = 1
	and (pd.accessorystatusid <> 2
		 or 
			(
			pd.accessorystatusid = 2 and 
			accessorydate between coalesce(@DateStart,'1/1/1753') and coalesce(@DateEnd,'1/1/3000') 
			)
	 )	
	and (pd.accessorystatusid <> 6
		 or 
			(
			pd.accessorystatusid = 6 and 
			accessorydate between coalesce(@DateStart,'1/1/1753') and coalesce(@DateEnd,'1/1/3000') 
			)
	 )	

	order by Product, Vendor, Deliverable

﻿

CREATE PROCEDURE [dbo].[spAddActionGroup]

(
	@ID int,
	@GroupID int
)

AS

Insert DeliverableIssue_FunctionalGroup(DeliverableIssueID,FunctionalGroupID)
values (@ID,@GroupID)



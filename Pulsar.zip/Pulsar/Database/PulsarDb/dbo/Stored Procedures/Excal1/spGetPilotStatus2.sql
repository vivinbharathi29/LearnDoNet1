﻿

CREATE PROCEDURE [dbo].[spGetPilotStatus2] 
	(
	@ID int
	)
AS
	Select Name
	from PilotStatus with (NOLOCK)
	where id = @ID



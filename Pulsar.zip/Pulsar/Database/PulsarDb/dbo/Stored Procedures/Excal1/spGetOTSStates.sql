﻿
/******************************************************************************
**	File: 
**	Name: 
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  02/15/2018	Santhana(auth\prabhuks) View Name changed from si_observation_report to SI_Observation_Report_Simplified 
**	30/11/2018	Santhana(auth\prabhuks) Open Query used to handle remote query 
*******************************************************************************/
CREATE PROCEDURE [dbo].[spGetOTSStates]
(
	@Product varchar(20),
	@Milestone varchar(30) = null
)
 AS
	/*
	SELECT state,Count(*) as StateCount
	FROM HOUSIREPORT01.SIO.dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
	WHERE PrimaryProduct = @Product
	and Priority = 1 
	and status <> 'Closed'
	and GatingMilestone = coalesce(@Milestone,GatingMilestone)
	Group By State
	GO 
	*/
	DECLARE @OPENQUERY nvarchar(MAX), @TSQL nvarchar(MAX), @LinkedServer nvarchar(MAX)
	SET @Milestone = ISNULL(@Milestone,'#')

	SET @LinkedServer = 'HOUSIREPORT01'
	SET @OPENQUERY = 'SELECT * FROM OPENQUERY('+ @LinkedServer + ','''
	SET @Product = ISNULL(@Product,'')

	SET @TSQL =  'SELECT state,Count(*) as StateCount
	FROM SIO.dbo.SI_Observation_Report_Simplified o WITH (NOLOCK)
	WHERE PrimaryProduct ='''''+ @Product + '''''
	and Priority = 1 
	 and status <> ''''Closed''''
	and GatingMilestone = ' 
	+ 'coalesce(nullif('''''+ @Milestone+''''',''''#''''),GatingMilestone)'
	+' Group By State'''+')'

	EXEC (@OPENQUERY+@TSQL) 
GO



﻿-- =================================================================
-- Update: Changed to new OUTER JOIN syntax - Paul Sanchez 3/11/2014
-- =================================================================
CREATE PROCEDURE [dbo].[spGetProducts_Pulsar]
	@Type int = -1
AS

/******************************************************************************
**	File: dbo.spGetProducts_Pulsar.sql
**	Name: spGetProducts_Pulsar
**	Desc: 
**
**	Auth: 
**	Date: 
*******************************************************************************
**	Change History copied from spGetProducts
*******************************************************************************
**	Date:		Author:				Description:
**	----------	------------------	-------------------------------------------
**  
*******************************************************************************/


IF @Type=0
	SELECT
		v.ID AS ID,
		v.productName AS Name,
		v.Version AS Version,
		e.Name AS PM,
		e.ID as PMID,
		v.Distribution,
		v.OnCommodityMatrix,
		v.PRDReleased,
		v.PDDReleased,
		v.OnlineReports,
		v.ProductStatusID,
		v.AllowDCR,
		v.StreetName,
		v.Brands,
		v.SystemBoardID,
		v.PartnerID,
		v.PreinstallTeam,
		v.TypeID,
		e2.Name AS SEPM,
		v.Division,
		v.Sustaining,
		v.DevCenter,
		c.name as DevCenterName,
		v.ReleaseTeam,
		v.Active,
		e2.Email AS SEPMMail,
		e2.ID AS SEPMID,
		e3.Name AS SM,
		e3.Email AS SMMail,
		e3.ID AS SMID,
		v.ProductFilePath,
		v.PDDPath,
		v.SCMPath,
		v.ProgramMatrixPath,
		v.STLStatusPath,
		p.Name AS Partner,
		sepe.name AS SEPE,
		sepe.Email AS SEPEMail,
		sepe.ID AS SEPEID,
		pinpm.name AS PINPM,
		pinpm.Email as PINPMMail,
		pinpm.id as PINPMID,
		setl.name AS SETL,
		setl.email AS SETLMail,
		setl.id AS SETLID
	FROM
		ProductFamily f with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) ON f.id = v.productfamilyid
		INNER JOIN Partner p with (NOLOCK) ON v.partnerid = p.id
		LEFT OUTER JOIN DevCenter c with (NOLOCK) ON c.ID = v.devcenter
		INNER JOIN Employee e with (NOLOCK) ON e.id = v.pmid
		INNER JOIN Employee e2 with (NOLOCK) ON e2.id = v.sepmid
		INNER JOIN Employee e3 with (NOLOCK) ON e3.id = v.smid
		LEFT OUTER JOIN Employee sepe with (NOLOCK) ON sepe.id = v.sepe
		LEFT OUTER JOIN Employee pinpm with (NOLOCK) ON pinpm.id = v.pinpm
		LEFT OUTER JOIN Employee setl with (NOLOCK) ON setl.id = v.setestlead
	WHERE (v.Active = 1 OR v.Sustaining = 1) AND v.FusionRequirements = 1
	ORDER BY
		v.dotsname

ELSE IF @Type = -1
	SELECT
		v.ID AS ID,
		v.productName AS Name,
		v.Version AS Version,
		e.Name AS PM,
		e.ID as PMID,
		v.Distribution,
		v.OnCommodityMatrix,
		v.PRDReleased,
		v.PDDReleased,
		v.OnlineReports,
		v.ProductStatusID,
		v.AllowDCR,
		v.StreetName,
		v.Brands,
		v.SystemBoardID,
		v.PartnerID,
		v.PreinstallTeam,
		v.TypeID,
		e2.Name AS SEPM,
		v.Division,
		v.Sustaining,
		v.DevCenter,
		c.name as DevCenterName,
		v.Active,
		e2.Email AS SEPMMail,
		e2.ID AS SEPMID,
		e3.Name AS SM,
		e3.Email AS SMMail,
		e3.ID AS SMID,
		v.ProductFilePath,
		v.PDDPath,
		v.SCMPath,
		v.ProgramMatrixPath,
		v.STLStatusPath,
		p.Name AS Partner,
		sepe.name AS SEPE,
		sepe.Email AS SEPEMail,
		sepe.ID AS SEPEID,
		pinpm.name AS PINPM,
		pinpm.Email as PINPMMail,
		pinpm.id as PINPMID,
		setl.name AS SETL,
		setl.email AS SETLMail,
		setl.id AS SETLID
	FROM
		ProductFamily f with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) ON f.id = v.productfamilyid
		INNER JOIN Partner p with (NOLOCK) ON v.partnerid = p.id
		LEFT OUTER JOIN DevCenter c with (NOLOCK) ON c.ID = v.devcenter
		INNER JOIN Employee e with (NOLOCK) ON e.id = v.pmid
		INNER JOIN Employee e2 with (NOLOCK) ON e2.id = v.sepmid
		INNER JOIN Employee e3 with (NOLOCK) ON e3.id = v.smid
		LEFT OUTER JOIN Employee sepe with (NOLOCK) ON sepe.id = v.sepe
		LEFT OUTER JOIN Employee pinpm with (NOLOCK) ON pinpm.id = v.pinpm
		LEFT OUTER JOIN Employee setl with (NOLOCK) ON setl.id = v.setestlead
	WHERE (v.Active = 1 OR v.Sustaining = 1) AND v.FusionRequirements = 1
	and TypeID <> 2
	ORDER BY
		v.dotsname
else
	SELECT
		v.ID AS ID,
		v.productName AS Name,
		v.Version AS Version,
		e.Name AS PM,
		e.ID as PMID,
		v.Distribution,
		v.OnCommodityMatrix,
		v.PRDReleased,
		v.PDDReleased,
		v.OnlineReports,
		v.ProductStatusID,
		v.AllowDCR,
		v.StreetName,
		v.Brands,
		v.SystemBoardID,
		v.PartnerID,
		v.PreinstallTeam,
		v.TypeID,
		e2.Name AS SEPM,
		v.Division,
		v.Sustaining,
		v.DevCenter,
		c.name as DevCenterName,
		v.Active,
		e2.Email AS SEPMMail,
		e2.ID AS SEPMID,
		e3.Name AS SM,
		e3.Email AS SMMail,
		e3.ID AS SMID,
		v.ProductFilePath,
		v.PDDPath,
		p.Name AS Partner,
		sepe.name AS SEPE,
		sepe.Email AS SEPEMail,
		sepe.ID AS SEPEID,
		pinpm.name AS PINPM,
		pinpm.Email as PINPMMail,
		pinpm.id as PINPMID,
		setl.name AS SETL,
		setl.email AS SETLMail,
		setl.id AS SETLID
	FROM
		ProductFamily f with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) ON f.id = v.productfamilyid
		INNER JOIN Partner p with (NOLOCK) ON v.partnerid = p.id
		LEFT OUTER JOIN DevCenter c with (NOLOCK) ON c.ID = v.devcenter
		INNER JOIN Employee e with (NOLOCK) ON e.id = v.pmid
		INNER JOIN Employee e2 with (NOLOCK) ON e2.id = v.sepmid
		INNER JOIN Employee e3 with (NOLOCK) ON e3.id = v.smid
		LEFT OUTER JOIN Employee sepe with (NOLOCK) ON sepe.id = v.sepe
		LEFT OUTER JOIN Employee pinpm with (NOLOCK) ON pinpm.id = v.pinpm
		LEFT OUTER JOIN Employee setl with (NOLOCK) ON setl.id = v.setestlead
	WHERE (v.Active = 1 OR v.Sustaining = 1) AND v.FusionRequirements = 1
	and TypeID=@Type
	ORDER BY
		v.dotsname


/*
if @Type=0
	SELECT     v.ID AS ID, p.Name AS Name, v.Version AS Version, e.Name AS PM, e.ID as PMID, v.Distribution, v.OnCommodityMatrix, v.PRDReleased, v.PDDReleased,
	                      v.OnlineReports, v.StreetName, v.Brands, v.SystemBoardID, v.PartnerID, v.PreinstallTeam, v.TypeID, e2.Name AS SEPM, v.Division, v.Sustaining, v.DevCenter,
	                      v.Active, e2.Email AS SEPMMail, e2.ID AS SEPMID, v.ProductFilePath, v.PDDPath, dbo.Partner.Name AS Partner
	FROM         dbo.ProductFamily p INNER JOIN
	                      dbo.ProductVersion v ON p.ID = v.ProductFamilyID INNER JOIN
	                      dbo.Partner ON v.PartnerID = dbo.Partner.ID LEFT OUTER JOIN
	                      dbo.Employee e ON v.PMID = e.ID LEFT OUTER JOIN
	                      dbo.Employee e2 ON v.SEPMID = e2.ID
	WHERE     (v.Active = 1) OR
	                      (v.Sustaining = 1)
	ORDER BY p.Name, v.Version
else if @Type=-1
	SELECT     v.ID AS ID, p.Name AS Name, v.Version AS Version, e.Name AS PM, e.ID as PMID, v.Distribution, v.OnCommodityMatrix, v.PRDReleased, v.PDDReleased,
	                      v.OnlineReports, v.StreetName, v.Brands, v.SystemBoardID, v.PartnerID, v.PreinstallTeam, v.TypeID, e2.Name AS SEPM, v.Division, v.Sustaining,  v.DevCenter,
	                      v.Active, e2.Email AS SEPMMail, e2.ID AS SEPMID, v.ProductFilePath, v.PDDPath, dbo.Partner.Name AS Partner
	FROM         dbo.ProductFamily p INNER JOIN
	                      dbo.ProductVersion v ON p.ID = v.ProductFamilyID INNER JOIN
	                      dbo.Partner ON v.PartnerID = dbo.Partner.ID LEFT OUTER JOIN
	                      dbo.Employee e ON v.PMID = e.ID LEFT OUTER JOIN
	                      dbo.Employee e2 ON v.SEPMID = e2.ID
	WHERE     (v.Active = 1 OR v.Sustaining = 1)
	and TypeID<> 2
	ORDER BY p.Name, v.Version
else
	SELECT     v.ID AS ID, p.Name AS Name, v.Version AS Version, e.Name AS PM, e.ID as PMID, v.Distribution, v.OnCommodityMatrix, v.PRDReleased, v.PDDReleased,
	                      v.OnlineReports, v.StreetName, v.Brands, v.SystemBoardID, v.PartnerID, v.PreinstallTeam, v.TypeID, e2.Name AS SEPM, v.Division, v.Sustaining,  v.DevCenter,
	                      v.Active, e2.Email AS SEPMMail, e2.ID AS SEPMID, v.ProductFilePath, v.PDDPath, dbo.Partner.Name AS Partner
	FROM         dbo.ProductFamily p INNER JOIN
	                      dbo.ProductVersion v ON p.ID = v.ProductFamilyID INNER JOIN
	                      dbo.Partner ON v.PartnerID = dbo.Partner.ID LEFT OUTER JOIN
	                      dbo.Employee e ON v.PMID = e.ID LEFT OUTER JOIN
	                      dbo.Employee e2 ON v.SEPMID = e2.ID
	WHERE     (v.Active = 1 OR v.Sustaining = 1)
	and TypeID=@Type
	ORDER BY p.Name, v.Version
*/




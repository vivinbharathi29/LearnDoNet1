﻿CREATE PROCEDURE [dbo].[spGetProductStatus4Commodity]
(
	@VersionID int
)
-- =================================================================
-- Update: Changed to new OUTER JOIN syntax - Paul Sanchez 3/11/2014
--		  05/19/2016 wgomero: If product is legacy add (Legacy) else (Pulsar)
--		  06/08/2017 buidi: add release to pulsar product
-- =================================================================
AS

DECLARE @FieldName as varchar(200)
DECLARE @DeveloperNotification as tinyint


Select @FieldName = ct.PMFieldName, @DeveloperNotification = r.DeveloperNotification 
from deliverableversion v with (NOLOCK), deliverableroot r with (NOLOCK), deliverablecategory c with (NOLOCK), DeliverableCategoryTeam ct with (NOLOCK)
where c.id = r.categoryid
and ct.id = c.teamid
and r.id = v.deliverablerootid
and v.id = @VersionID

if @FieldName = 'PDEID'
	Select	Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End, 
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
			Product_Deliverable pd with (NOLOCK)
			INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
			INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
			INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
			LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
			RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.pdeid
			LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
			left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
			LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
			LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
			LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where	DeliverableVersionID = @VersionID
	Order By Product
else if @FieldName = 'CommHWPMID'
	Select Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End,
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
		Product_Deliverable pd with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
		INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
		INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
		LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
		RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.CommHWPMID
		LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
		left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
		LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
		LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
		LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where DeliverableVersionID = @VersionID
	Order By Product
else if @FieldName = 'AccessoryPMID'
	Select Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End, 
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
		Product_Deliverable pd with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
		INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
		INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
		LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
		RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.AccessoryPMID
		LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
		left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
		LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
		LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
		LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where DeliverableVersionID = @VersionID
	Order By Product
else if @FieldName = 'PINPM'
	Select Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End,
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
		Product_Deliverable pd with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
		INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
		INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
		LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
		RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.PINPM
		LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
		left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
		LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
		LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
		LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where DeliverableVersionID = @VersionID
	Order By Product
else if @FieldName = 'SEPMID'
	Select Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End,
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
		Product_Deliverable pd with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
		INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
		INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
		LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
		RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.SEPMID
		LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
		left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
		LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
		LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
		LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where DeliverableVersionID = @VersionID
	Order By Product
else if @FieldName = 'ProcessorPMID'
	Select Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End,
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
		Product_Deliverable pd with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
		INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
		INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
		LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
		RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.ProcessorPMID
		LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
		left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
		LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
		LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
		LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where DeliverableVersionID = @VersionID
	Order By Product
else if @FieldName = 'VideoMemoryPMID'
	Select Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End, 
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
		Product_Deliverable pd with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
		INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
		INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
		LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
		RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.VideoMemoryPMID
		LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
		left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
		LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
		LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
		LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where DeliverableVersionID = @VersionID
	Order By Product
else if @FieldName = 'GraphicsControllerPMID'
	Select Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End, 
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
		Product_Deliverable pd with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
		INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
		INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
		LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
		RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.GraphicsControllerPMID
		LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
		left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
		LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
		LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
		LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where DeliverableVersionID = @VersionID
	Order By Product
else if @FieldName = 'PlatformDevelopmentID'
	Select Product =  CASE 
						WHEN v.FusionRequirements = 1 THEN v.dotsname + ' (' + Isnull(rl.Name, 'Pulsar') + ')'
							ELSE v.dotsname + ' (Legacy)'
						END,
			SupplyChainRestriction = Case When v.FusionRequirements = 1 Then pdr.SupplyChainRestriction Else pd.SupplyChainRestriction End, 
			ConfigurationRestriction = Case When v.FusionRequirements = 1 Then pdr.ConfigurationRestriction Else pd.ConfigurationRestriction End, 
			@DeveloperNotification as DeveloperNotification, dv.prereleased, dv.DeveloperId, pd.InImage, 
			DeveloperNotificationStatus = Case When v.FusionRequirements = 1 Then pdr.DeveloperNotificationStatus Else pd.DeveloperNotificationStatus End, 
			developerteststatus = Case When v.FusionRequirements = 1 Then pdr.developerteststatus Else pd.developerteststatus End,
			pd.ID as pdid, pd.Preinstall, 
			targeted = Case When v.FusionRequirements = 1 Then pdr.targeted Else pd.targeted End, 
			pd.PMAlert, v.partnerid, 
			pd.PreinstallStatus, e.name as CommodityPM, 
			PilotDate = Case When v.FusionRequirements = 1 Then pdr.PilotDate Else pd.PilotDate End, 
			PilotStatus = Case When v.FusionRequirements = 1 Then pr.name Else p.name End, 
			testDate = Case When v.FusionRequirements = 1 Then pdr.testDate Else pd.testDate End, 
			riskrelease = Case When v.FusionRequirements = 1 Then pdr.riskrelease Else pd.riskrelease End, 
			TestStatus = Case When v.FusionRequirements = 1 then case when pdr.riskrelease=1 and tr.status = 'QComplete' then 'Risk Release' else tr.status end
								else case when pd.riskrelease = 1 and t.status = 'QComplete' then 'Risk Release' else t.status end end, 
			TargetNotes = Case When v.FusionRequirements = 1 Then pdr.TargetNotes Else pd.TargetNotes End, 
			v.Version,
			ProductDeliverableReleaseID = isnull(pdr.Id, 0)
	FROM 
		Product_Deliverable pd with (NOLOCK)
		INNER JOIN ProductVersion v with (NOLOCK) on v.Id = pd.ProductVersionID
		INNER JOIN ProductFamily f with (NOLOCK) on f.Id = v.ProductFamilyID
		INNER JOIN deliverableversion dv with (NOLOCK) on dv.id = pd.deliverableversionid
		LEFT OUTER JOIN PilotStatus p with (NOLOCK) on pd.pilotstatusid = p.id
		RIGHT OUTER JOIN employee e with (NOLOCK) on e.id = v.PlatformDevelopmentID
		LEFT OUTER JOIN TestStatus t with (NOLOCK) on pd.TestStatusID = t.ID
		left outer join Product_Deliverable_Release pdr with (NOLOCK) on pd.id = pdr.ProductDeliverableID
		LEFT OUTER JOIN PilotStatus pr with (NOLOCK) on pdr.pilotstatusid = pr.id
		LEFT OUTER JOIN TestStatus tr with (NOLOCK) on pdr.TestStatusID = tr.ID
		LEFT OUTER JOIN ProductVersionRelease rl with (NOLOCK) on rl.ID = pdr.ReleaseID
	Where DeliverableVersionID = @VersionID
	Order By Product
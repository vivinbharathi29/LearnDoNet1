﻿

CREATE PROCEDURE [dbo].[spGetVendorList]
As
 --Select ID,Name
 --FROM Vendor with (NOLOCK)
 --Order By Name;

SELECT ID, Name 
FROM Vendor WITH (NOLOCK)
WHERE ID not in (
	SELECT ID
	  FROM (
			SELECT ID, DupCount =  ROW_NUMBER() OVER (PARTITION BY Name order by ID)
			FROM Vendor WITH (NOLOCK)
			) d
	 WHERE DupCount > 1 
)
ORDER BY Name

return 




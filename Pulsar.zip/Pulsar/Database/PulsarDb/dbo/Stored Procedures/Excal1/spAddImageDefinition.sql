﻿

CREATE PROCEDURE [dbo].[spAddImageDefinition]
(
	@ProdID int,
	@SKU varchar(20),
	@BrandID int,
	@OSID int,
	@SWID int,
	@ImageType varchar(10),
	@ImageTypeID int,
	@StatusID tinyint,
	@RTMDate datetime,
	@Comments varchar(50),
	@ImageDriveDefinitionId int,
	@OSReleaseId int,
	@NewID int output
)	
 AS
insert ImageDefinitions(ProductVersionID,SKUNumber,BrandID, OSID , SWID, ImageType,Modified,Active, StatusID,RTMDate,Comments,ImageDriveDefinitionId, ImageTypeID, OSReleaseId)
values(@ProdID,LTrim(RTrim(@Sku)),@BrandID,@OSID,@SWID,@ImageType,GetDate(),1,@StatusID,@RTMDate,@Comments,@ImageDriveDefinitionId,@ImageTypeID, @OSReleaseId)
Select @NewID = SCOPE_IDENTITY()



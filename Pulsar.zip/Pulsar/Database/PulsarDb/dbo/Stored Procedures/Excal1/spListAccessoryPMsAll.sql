﻿
CREATE PROCEDURE [dbo].[spListAccessoryPMsAll]
AS

Select e.id, e.name
from Employee e with (NOLOCK)
where AccessoryPM = 1
order by e.name




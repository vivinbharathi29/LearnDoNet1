﻿/*** Change History      
**************************************************************************************************  
** SNo   Date        Author  Description      
** --    --------   -------   -------------------------      
** 01	10/5/2018	Aashish	Filtered the table 'deliverableissues' before joining with other tables. Changed to ANSI. Added SET NOCOUNT.    
****************************************************************************************************/
CREATE PROCEDURE [dbo].[spListActionItemWorkingList]
(
	@OwnerID int
)
 AS
SET NOCOUNT ON
	if @OwnerID = 0 -- all
		Select p.dotsname as Product,
			   a.displayorder, 
			   a.id, 
			   a.summary, 
			   a.type, 
			   a.priority, 
			   r.summary as Roadmap, 
			   s.name as Status, 
			   e.name as owner, 
			   a.targetdate, 
			   r.timeframe, 
			   a.description
		FROM 
			(SELECT displayorder,
					id,
					summary,
					[type],
					[priority],
					targetdate,
					[description],
					ownerid,
					[status],
					productversionid,
					actionroadmapid  FROM deliverableissues WITH (NOLOCK)
					WHERE [status] in (1,7) 
					and [type] in (1,2)
					and PendingImplementation=1
					and productversionid in (Select ID from productversion WITH (NOLOCK) WHERE [type]=2) ) a
			INNER JOIN employee e WITH (NOLOCK) ON e.id = a.ownerid 
			INNER JOIN ActionStatus s WITH (NOLOCK) ON s.id = a.status 
			INNER JOIN productversion p WITH (NOLOCK) ON p.id = a.productversionid
			LEFT OUTER JOIN actionroadmap r WITH (NOLOCK) ON r.id = a.actionroadmapid
		where 
			p.typeid=2
		order by a.displayorder,a.priority
	else --mine
		Select p.dotsname as Product,
			   a.displayorder,
			   a.id, 
			   a.summary, 
			   a.type, 
			   a.priority, 
			   r.summary as Roadmap, 
			   s.name as Status, 
			   e.name as owner, 
			   a.targetdate,
			   r.timeframe , 
			   a.description
		FROM 
			(SELECT displayorder,
					id,
					summary,
					[type],
					[priority],
					targetdate,
					[description],
					ownerid,
					[status],
					productversionid,
					actionroadmapid  FROM deliverableissues WITH (NOLOCK)
					WHERE [status] in (1,7)
					and ownerid  = @OwnerID 
					and [type] in (1,2)
					and PendingImplementation=1 ) a
			INNER JOIN employee e WITH (NOLOCK) ON e.id = a.ownerid 
			INNER JOIN ActionStatus s WITH (NOLOCK) ON s.id = a.status 
			INNER JOIN productversion p WITH (NOLOCK) ON p.id = a.productversionid
			LEFT OUTER JOIN actionroadmap r WITH (NOLOCK) ON r.id = a.actionroadmapid
		where  p.typeid=2
		order by a.displayorder,a.priority
SET NOCOUNT OFF
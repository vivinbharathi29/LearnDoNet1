﻿namespace HP.Pulsar.Infrastructure.Constants
{
    // Email Constants Here
    public static class EmailConstants
    {
        public static string CompleteListHP => "TWNPDCNBCommodityTechnology@hp.com;GPS.Taiwan.NB.Buy-Sell@hp.com;APJ-RCTO.SC@hp.com;claire.lin@hp.com";

        public static string DefaultSenderEmail => "pulsar.noreply@hp.com";

        public static string DefaultSenderName => "Pulsar automated email";

        public static string EdmFunction => "tdcdtoedmfunction@hp.com";

        public static string HDRecipients2DevCenter => "TWNPDCNBCommodityTechnology@hp.com;APJ-RCTO.SC@hp.com;GPS.Taiwan.NB.Buy-Sell@hp.com;tdcesmail@hp.com;twnpdccnbcommoditypm@hp.com;claire.lin@hp.com;kidwell.proceng@hp.com";

        public static string HDRecipients3DevCenter => "TWNPDCNBCommodityTechnology@hp.com;APJ-RCTO.SC@hp.com;GPS.Taiwan.NB.Buy-Sell@hp.com;claire.lin@hp.com;kidwell.proceng@hp.com;tdcesmail@hp.com;gbsnbedm@hp.com;twinkle.k.s@hp.com;sridevi.s@hp.com;rajendran.m@hp.com";

        public static string HDRecipientsDevCenter => "TWNPDCNBCommodityTechnology@hp.com;APJ-RCTO.SC@hp.com;GPS.Taiwan.NB.Buy-Sell@hp.com;claire.lin@hp.com;kidwell.proceng@hp.com";
        
        public static string HoudcrDocsEmail => "houdcrdocs@hp.com";

        public static string HoudskhfcnmobileEmail => "houdskhfcnmobile@hp.com";

        public static string HouprtDcrNotifyEmail => "houprtdcrnotify@hp.com";

        public static string IscEmail => "isc.sj@hp.com";

        public static string NBSCSWEngrsEmail => "NBSCSWEngrs@hp.com";

        public static string NotebookDcrNotificationEmail => "NotebookDCRNotification@hp.com";

        public static string PartnerId2CompleteListOdm => "IPC-ED1@inventec.com;IPCHP-Excalibur@inventec.com";

        public static string PartnerId2FailedListOdm => "IPC-ED1@inventec.com;IPCHP-Excalibur@inventec.com";

        public static string PartnerId3CompleteListOdm => "A32KeyCommodity@compal.com";

        public static string PartnerId3FailedListOdm => "A32KeyCommodity@compal.com";

        public static string PartnerId4CompleteListOdm => "TOPCommodityTeam@quantacn.com";

        public static string PartnerId4FailedListOdm => "TOPCommodityTeam@quantacn.com";

        public static string PartnerId7CompleteListOdm => "key_commodity@wistron.com";

        public static string PartnerId7FailedListOdm => "key_commodity@wistron.com";

        public static string PulsarNoReplyEmail => "pulsar.noreply@hp.com";

        public static string PulsarPMEmail => "max.yu@hp.com";

        public static string PulsarSupportAdminEmail => "max.yu@hp.com";

        public static string PulsarSupportEmail => "pulsar.support@hp.com";

        public static string PulsarSupportSenderName => "Pulsar Support";

        public static string RajendranEmail => "rajendran.m@hp.com";

        public static string SrideviEmail => "sridevi.s@hp.com";

        public static string SupplyRestrictionEmail => "TWNPDCNBCommodityTechnology@hp.com;APJ-RCTO.SC@hp.com;kidwell.proceng@hp.com";

        public static string TdcesEmail => "tdcesmail@hp.com";

        public static string TwinkleEmail => "twinkle.k@hp.com";

        public static string TwnPdCommodityEmail => "twnpdccnbcommoditypm@hp.com";

        public static string DCRBiosChangeEmail => "cmitfwdcr.hepm@hp.com;";
    }
}

﻿using HP.Pulsar.Infrastructure.Json;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridRowSelection
    {
        private string _rowSelectionChangingEvent;

        public IgGridRowSelection(string rowSelectionChangingEvent = "")
        {
            Name = "Selection";
            Mode = "row";
            MultipleSelection = true;
            _rowSelectionChangingEvent = rowSelectionChangingEvent;
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "mode")]
        public string Mode { get; }

        [JsonProperty(PropertyName = "multipleSelection")]
        public bool MultipleSelection { get; }

        [JsonProperty(PropertyName = "rowSelectionChanging")]
        [JsonConverter(typeof(PlainJsonStringConverter))]
        //This property represents RowSelectionChanging event of iggGrid. As the javasript does not support delegates, it is defined as string property.
        public string RowSelectionChanging
        {
            get
            {
                // The global variable, isGridCheckboxClicked is reset to false
                // The RowSelectionChanging event is fired after the CheckBoxStateChanging is fired.
                // When the user clicks the row selector checkbox, both CheckBoxStateChanging and RowSelectionChanging events are fired.
                // When the user clicks anywhere in the grid row, RowSelectionChanging event is alone fired.
                // So, RowSelectionChanging event is required to know whether the user clicked checkbox or the gird row. 
                // Hence, the global variable isGridCheckboxClicked can be used in RowSelectionChanging event to find out whether user clicked the rowselector checkbox or clicked the row itself. 
                if (string.IsNullOrWhiteSpace(_rowSelectionChangingEvent))
                {
                    return $"function(evt, uv) {{ isGridCheckboxClicked = false; return; }}";
                }
                else
                {
                    return $"function(evt, uv) {{ var result =  eval({_rowSelectionChangingEvent}); isGridCheckboxClicked = false; return result; }}";
                }
            }
        }
    }
}
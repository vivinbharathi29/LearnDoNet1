﻿using System.Collections.Generic;
using System.Linq;
using HP.Pulsar.Infrastructure.Json;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridFilterColumnSettings
    {
        public IgGridFilterColumnSettings(string columnKey, bool allowFiltering)
        {
            ColumnKey = columnKey;
            AllowFiltering = allowFiltering;            
        } 

        public IgGridFilterColumnSettings(string columnKey, EditorType editorType, IDictionary<string, string> editorOptions)
        {
            ColumnKey = columnKey;            
            EditorType = editorType;
            EditorOptions = GetEditorOptionsFromDictionary(editorOptions);
            AllowFiltering = true;
        }

        [JsonProperty(PropertyName = "columnKey", NullValueHandling = NullValueHandling.Ignore)]
        public string ColumnKey { get; }

        [JsonProperty(PropertyName = "allowFiltering", NullValueHandling = NullValueHandling.Ignore)]
        public bool AllowFiltering { get; }

        [JsonProperty(PropertyName = "editorType", NullValueHandling = NullValueHandling.Ignore)]
        public EditorType EditorType { get; }

        [JsonProperty(PropertyName = "editorOptions", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(PlainJsonStringConverter))]
        public string EditorOptions { get; }

        static string GetEditorOptionsFromDictionary(IDictionary<string, string> editorOptions)
        {
            IEnumerable<string> options = editorOptions.Select(x => string.Concat(x.Key, ":", x.Value));

            return string.Concat("{", string.Join(",", options), "}");            
        }
    }
}

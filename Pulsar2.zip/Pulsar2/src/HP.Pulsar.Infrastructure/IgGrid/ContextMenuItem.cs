﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class ContextMenuItem
    {
        public ContextMenuItem(string displayName, string commandName)
        {
            Title = displayName;
            Command = commandName;
        }

        [JsonProperty(PropertyName = "cmd")]
        public string Command { get; }

        [JsonProperty(PropertyName = "title")]
        public string Title { get; }
    }
}

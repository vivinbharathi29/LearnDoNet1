﻿namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridColumnTemplate
    {
        public IgGridColumnTemplate(string columnName, string template)
        {
            ColumnName = columnName;
            Template = template;
        }

        public string ColumnName { get; }

        public string Template { get; }
    }
}

﻿using HP.Pulsar.Infrastructure.Json;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridRowSelector
    {
        private string _checkBoxStateChangingEvent;

        public IgGridRowSelector(string checkBoxStateChangingEvent = "")
        {
            Name = "RowSelectors";
            EnableCheckBoxes = true;
            EnableRowNumbering = false;
            _checkBoxStateChangingEvent = checkBoxStateChangingEvent;
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "enableCheckBoxes")]
        public bool EnableCheckBoxes { get; }

        [JsonProperty(PropertyName = "enableRowNumbering")]
        public bool EnableRowNumbering { get; }

        [JsonProperty(PropertyName = "checkBoxStateChanging")]
        [JsonConverter(typeof(PlainJsonStringConverter))]
        //This property represents CheckBoxStateChanging event of iggGrid. As the javasript does not support delegates, it is defined as string property.
        // The event, CheckBoxStateChanging is fired whenever user clicks the row selector checkbox in the grid.
        public string CheckBoxStateChanging
        {
            get
            {
                // The global variable, isGridCheckboxClicked is set to true, so that it can be used in RowSelectionChanging event.
                // The RowSelectionChanging event is fired after the CheckBoxStateChanging is fired.
                // When the user clicks the row selector checkbox, both CheckBoxStateChanging and RowSelectionChanging events are fired.
                // When the user clicks anywhere in the grid row, RowSelectionChanging event is alone fired.
                // So, RowSelectionChanging event is required to know whether the user clicked checkbox or the gird row. 
                // Hence, the global variable isGridCheckboxClicked can be used in RowSelectionChanging event to find out whether user clicked the rowselector checkbox or clicked the row itself. 
                if (string.IsNullOrWhiteSpace(_checkBoxStateChangingEvent))
                {
                    return $"function(evt, uv) {{ isGridCheckboxClicked = true; return; }}";
                }
                else
                {
                    return $"function(evt, uv) {{ isGridCheckboxClicked = true; return eval({_checkBoxStateChangingEvent}) }}";
                }
            }
        }
    }
}
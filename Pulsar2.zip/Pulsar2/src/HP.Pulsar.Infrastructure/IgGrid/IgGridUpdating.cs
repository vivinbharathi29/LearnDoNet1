﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridUpdating
    {
        public IgGridUpdating()
        {
            Name = "Updating";
            EnableAddRow = false;
            EnableDeleteRow = false;
            EditMode = "cell";
            EditorType = "text";
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "enableAddRow")]
        public bool EnableAddRow { get; }

        [JsonProperty(PropertyName = "enableDeleteRow")]
        public bool EnableDeleteRow { get; }

        [JsonProperty(PropertyName = "editMode")]
        public string EditMode { get; }

        [JsonProperty(PropertyName = "editorType")]
        public string EditorType { get; }

        [JsonProperty(PropertyName = "columnSettings")]
        public IList<IgGridUpdateColumnSettings> ColumnSettings { get; set; }
    }
}

﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridGroupByColumnSettings
    {
        public IgGridGroupByColumnSettings(string columnKey)
        {
            ColumnKey = columnKey;
            IsGroupBy = true;
            Direction = "asc";
        }

        [JsonProperty(PropertyName = "columnKey", NullValueHandling = NullValueHandling.Ignore)]
        public string ColumnKey { get; }

        [JsonProperty(PropertyName = "isGroupBy", NullValueHandling = NullValueHandling.Ignore)]
        public bool IsGroupBy { get; }

        [JsonProperty(PropertyName = "dir", NullValueHandling = NullValueHandling.Ignore)]
        public string Direction { get; }
    }
}
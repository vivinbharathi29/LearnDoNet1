﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridPaging
    {
        //JsontProperty Attribute was used to align the IgGrid feature names in camel case.
        //https://www.igniteui.com/help/iggrid-paging
        public IgGridPaging()
        {
            Name = "Paging";
            RecordCountKey = "TotalRecordsCount";
            PageIndexUrlKey = "page";
            PageSizeUrlKey = "pageSize";
            PageSizeDropDownLocation = "inpager";
            PageSizeList = "50, 100, 200, 400, 800";
            Persist = true;
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "recordCountKey")]
        public string RecordCountKey { get; }

        [JsonProperty(PropertyName = "pageIndexUrlKey")]
        public string PageIndexUrlKey { get; }

        [JsonProperty(PropertyName = "pageSizeUrlKey")]
        public string PageSizeUrlKey { get; }

        [JsonProperty(PropertyName = "pageSizeDropDownLocation")]
        public string PageSizeDropDownLocation { get; }

        [JsonProperty(PropertyName = "pageSize")]
        public int PageSize { get; } = 50;

        [JsonProperty(PropertyName = "pageSizeList")]
        public string PageSizeList { get; }

        [JsonProperty(PropertyName = "persist")]
        public bool Persist { get; }
    }
}

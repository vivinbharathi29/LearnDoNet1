﻿namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridFeatures
    {
        public IgGridFiltering Filtering { get; set; }

        public IgGridGroupBy GroupBy { get; set; }

        public IgGridPaging Paging { get; set; }

        public IgGridRowSelector RowSelector { get; set; }

        public IgGridRowSelection RowSelection { get; set; }

        public IgGridSorting Sorting { get; set; }

        public IgGridToolTips ToolTips { get; set; }

        public IgGridUpdating Updating { get; set; }
    }
}
﻿using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridUpdateColumnSettings
    {
        public IgGridUpdateColumnSettings(string columnKey)
        {
            ColumnKey = columnKey;
            ReadOnly = true;
        }

        [JsonProperty(PropertyName = "columnKey", NullValueHandling = NullValueHandling.Ignore)]
        public string ColumnKey { get; }

        [JsonProperty(PropertyName = "readOnly", NullValueHandling = NullValueHandling.Ignore)]
        public bool ReadOnly { get; }
    }
}

﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public class IgGridGroupBy
    {
        public IgGridGroupBy()
        {
            // This is the keyword used by iggrid and hence it cannot be changed.
            Name = "GroupBy";
            GroupByAreaVisibility = "hidden";
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "groupByAreaVisibility")]
        public string GroupByAreaVisibility { get; }

        [JsonProperty(PropertyName = "columnSettings")]
        public IList<IgGridGroupByColumnSettings> ColumnSettings { get; set; }
    }
}
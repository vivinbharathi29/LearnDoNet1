﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    //JsontProperty Attribute was used to align the IgGrid feature names in camel case.
    //https://www.igniteui.com/help/iggrid-filtering
    public class IgGridFiltering
    {
        public IgGridFiltering()
        {
            Name = "Filtering";
            Type = "remote";
            FilterExprUrlKey = "filter";
            Persist = true;
        }

        [JsonProperty(PropertyName = "name")]
        public string Name { get; }

        [JsonProperty(PropertyName = "type")]
        public string Type { get; }

        [JsonProperty(PropertyName = "filterExprUrlKey")]
        public string FilterExprUrlKey { get; }

        [JsonProperty(PropertyName = "persist")]
        public bool Persist { get; }

        [JsonProperty(PropertyName = "columnSettings")]
        public IList<IgGridFilterColumnSettings> ColumnSettings { get; set; }
    }
}

﻿namespace HP.Pulsar.Infrastructure.IgGrid
{
    public enum EditorType
    {
        Checkbox,
        Currency,
        DateEditor,
        DatePicker,
        Mask,
        Numeric,
        Percent,
        Text,
        TimePicker
    }
}

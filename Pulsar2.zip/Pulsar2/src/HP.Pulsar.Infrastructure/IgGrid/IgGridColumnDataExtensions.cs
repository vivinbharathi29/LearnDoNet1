﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Infrastructure.IgGrid
{
    public static class IgGridColumnDataExtensions
    {
        public static IList<IgGridColumnData> AddColumnsData(this IList<IgGridColumnData> columns, Type modelType)
        {
            if (columns == null)
            {
                return null;
            }

            IEnumerable<PropertyInfo> properties = modelType.GetProperties(BindingFlags.Instance | BindingFlags.Public)
                                                            .Where(x => x.GetCustomAttribute<IgGridColumnAttributes>() != null);

            foreach (PropertyInfo propertyInfo in properties)
            {
                IgGridColumnAttributes igGridAttrs = propertyInfo.GetCustomAttribute<IgGridColumnAttributes>();
                string columnKey = propertyInfo.Name;
                string columnHeaderText = string.IsNullOrWhiteSpace(igGridAttrs.HeaderText) ? propertyInfo.Name : igGridAttrs.HeaderText;
                string columnDataType = IgGridHelper.GetFilterColumnType(propertyInfo.PropertyType.ToString());
                string columnWidth = string.IsNullOrWhiteSpace(igGridAttrs.ColumnWidth) ? string.Empty : igGridAttrs.ColumnWidth;
                string columnFormat = string.IsNullOrWhiteSpace(igGridAttrs.Format) && columnDataType.IndexOf("date", StringComparison.OrdinalIgnoreCase) < 0
                                      ? string.Empty
                                      : igGridAttrs.Format;
                string columnCssClass = string.IsNullOrWhiteSpace(igGridAttrs.ColumnCssClass) ? string.Empty : igGridAttrs.ColumnCssClass;
                string columnTemplate = string.IsNullOrWhiteSpace(igGridAttrs.Template) ? string.Empty : igGridAttrs.Template;

                columns.Add(new IgGridColumnData(columnKey,
                                                 columnHeaderText,
                                                 columnDataType,
                                                 columnWidth,
                                                 igGridAttrs.IsHidden,
                                                 columnFormat,
                                                 columnCssClass,
                                                 columnTemplate));

            }

            return columns;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using HP.Pulsar.CommonContracts.ProductPage;

namespace HP.Pulsar.Infrastructure.ProductPage
{
    public sealed class ProductPageTab : IPageTab
    {
        private const int _actionItemsTabId = 1;
        private const int _certificationsTabId = 2;
        private const int _changeRequestsTabId = 3;
        private const int _deliverablesTabId = 4;
        private const int _documentTabId = 5;
        private const int _generalTabId = 6;
        private const int _imagesTabId = 7;
        private const int _localizationTabId = 8;
        private const int _observationsTabId = 9;
        private const int _requirementsTabId = 10;
        private const int _scheduleTabId = 11;
        private const int _serviceTabId = 12;
        private const int _smrTabId = 13;
        private const int _supplyChainTabId = 14;
        private const string _actionItemsTabName = "Action Items";
        private const string _certificationsTabName = "Certifications";
        private const string _changeRequestTabName = "Change Request";
        private const string _deliverableTabName = "Deliverables";
        private const string _documentTabName = "Document";
        private const string _generalTabName = "General";
        private const string _imagesTabName = "Images";
        private const string _localizationTabName = "Localization";
        private const string _observationsTabName = "Observations";
        private const string _requirementsTabName = "Requirements";
        private const string _scheduleTabName = "Schedule";
        private const string _serviceTabName = "Service";
        private const string _smrTabName = "SMR";
        private const string _supplyChainTabName = "Supply Chain";
        private static readonly Dictionary<int, ProductPageTab> _tabsWithIdKey = GetPageTabs();
        private static readonly Dictionary<string, ProductPageTab> _tabsWithNameKey = GetPageTabsByName();
        private const int _pageCount = 14;

        private static Dictionary<int, ProductPageTab> GetPageTabs()
        {
            Dictionary<int, ProductPageTab> tabs = new Dictionary<int, ProductPageTab>(_pageCount);
            tabs[_actionItemsTabId] = new ProductPageTab(_actionItemsTabId);
            tabs[_certificationsTabId] = new ProductPageTab(_certificationsTabId);
            tabs[_changeRequestsTabId] = new ProductPageTab(_changeRequestsTabId);
            tabs[_deliverablesTabId] = new ProductPageTab(_deliverablesTabId);
            tabs[_documentTabId] = new ProductPageTab(_documentTabId);
            tabs[_generalTabId] = new ProductPageTab(_generalTabId);
            tabs[_imagesTabId] = new ProductPageTab(_imagesTabId);
            tabs[_localizationTabId] = new ProductPageTab(_localizationTabId);
            tabs[_observationsTabId] = new ProductPageTab(_observationsTabId);
            tabs[_requirementsTabId] = new ProductPageTab(_requirementsTabId);
            tabs[_scheduleTabId] = new ProductPageTab(_scheduleTabId);
            tabs[_serviceTabId] = new ProductPageTab(_serviceTabId);
            tabs[_smrTabId] = new ProductPageTab(_smrTabId);
            tabs[_supplyChainTabId] = new ProductPageTab(_supplyChainTabId);

            return tabs;
        }

        private static Dictionary<string, ProductPageTab> GetPageTabsByName()
        {
            Dictionary<string, ProductPageTab> tabs = new Dictionary<string, ProductPageTab>(_pageCount, StringComparer.OrdinalIgnoreCase);
            tabs[_actionItemsTabName] = _tabsWithIdKey[_actionItemsTabId];
            tabs[_certificationsTabName] = _tabsWithIdKey[_certificationsTabId];
            tabs[_changeRequestTabName] = _tabsWithIdKey[_changeRequestsTabId];
            tabs[_deliverableTabName] = _tabsWithIdKey[_deliverablesTabId];
            tabs[_documentTabName] = _tabsWithIdKey[_documentTabId];
            tabs[_generalTabName] = _tabsWithIdKey[_generalTabId];
            tabs[_imagesTabName] = _tabsWithIdKey[_imagesTabId];
            tabs[_localizationTabName] = _tabsWithIdKey[_localizationTabId];
            tabs[_requirementsTabName] = _tabsWithIdKey[_requirementsTabId];
            tabs[_scheduleTabName] = _tabsWithIdKey[_scheduleTabId];
            tabs[_serviceTabName] = _tabsWithIdKey[_serviceTabId];
            tabs[_smrTabName] = _tabsWithIdKey[_smrTabId];
            tabs[_supplyChainTabName] = _tabsWithIdKey[_supplyChainTabId];

            return tabs;
        }


        private ProductPageTab(int tabId)
        {
            Id = tabId;
        }

        public static bool TryGetPageTab(int tabId, out ProductPageTab tab)
        {
            if (_tabsWithIdKey.TryGetValue(tabId, out ProductPageTab value))
            {
                tab = value;
                return true;
            }

            tab = null;
            return false;
        }

        public static bool TryGetPageTab(string tabName, out ProductPageTab tab)
        {
            if (_tabsWithNameKey.TryGetValue(tabName, out ProductPageTab value))
            {
                tab = value;
                return true;
            }

            tab = null;
            return false;
        }

        public int Id { get; }

        public string Name
        {
            get
            {
                switch (Id)
                {
                    case _actionItemsTabId:
                        return _actionItemsTabName;
                    case _certificationsTabId:
                        return _certificationsTabName;
                    case _changeRequestsTabId:
                        return _changeRequestTabName;
                    case _deliverablesTabId:
                        return _deliverableTabName;
                    case _documentTabId:
                        return _documentTabName;
                    case _generalTabId:
                        return _generalTabName;
                    case _imagesTabId:
                        return _imagesTabName;
                    case _localizationTabId:
                        return _localizationTabName;
                    case _observationsTabId:
                        return _observationsTabName;
                    case _requirementsTabId:
                        return _requirementsTabName;
                    case _scheduleTabId:
                        return _scheduleTabName;
                    case _serviceTabId:
                        return _serviceTabName;
                    case _smrTabId:
                        return _smrTabName;
                    case _supplyChainTabId:
                        return _supplyChainTabName;
                }

                return string.Empty;
            }
        }

        public static ProductPageTab ActionItems => _tabsWithIdKey[_actionItemsTabId];

        public static ProductPageTab Certification => _tabsWithIdKey[_certificationsTabId];

        public static ProductPageTab ChangeRequest => _tabsWithIdKey[_changeRequestsTabId];

        public static ProductPageTab Deliverables => _tabsWithIdKey[_deliverablesTabId];

        public static ProductPageTab Documents => _tabsWithIdKey[_documentTabId];

        public static ProductPageTab General => _tabsWithIdKey[_generalTabId];

        public static ProductPageTab Images => _tabsWithIdKey[_imagesTabId];

        public static ProductPageTab Localization => _tabsWithIdKey[_imagesTabId];

        public static ProductPageTab Observations => _tabsWithIdKey[_observationsTabId];

        public static ProductPageTab Requirements => _tabsWithIdKey[_requirementsTabId];

        public static ProductPageTab Schedule => _tabsWithIdKey[_scheduleTabId];

        public static ProductPageTab Service => _tabsWithIdKey[_serviceTabId];

        public static ProductPageTab SMR => _tabsWithIdKey[_smrTabId];

        public static ProductPageTab SupplyChain => _tabsWithIdKey[_supplyChainTabId];
    }
}

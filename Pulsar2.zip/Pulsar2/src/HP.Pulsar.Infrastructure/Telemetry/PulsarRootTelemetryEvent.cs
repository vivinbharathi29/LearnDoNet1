﻿using System;
using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry
{
    public abstract class PulsarRootTelemetryEvent : ITelemetryEvent
    {
        private IDictionary<string, string> _telemetryProperties;
        private readonly List<string> _prefixSegments;
        private readonly string _eventName;

        protected PulsarRootTelemetryEvent(string eventName, TelemetryType telemetryType, int telemetryEventId)
        {
            Id = telemetryEventId;
            Type = telemetryType;
            _prefixSegments = new List<string> { "HP.Pulsar" };
            _eventName = eventName;
        }

        private string EventNamePrefix => string.Concat(string.Join(".", _prefixSegments), ".");

        public int Id { get; }

        public string Name => string.Concat(EventNamePrefix, _eventName);

        public TelemetryType Type { get; }

        protected void AddPrefixSegment(string segmentName)
        {
            if (!string.IsNullOrWhiteSpace(segmentName))
            {
                _prefixSegments.Add(segmentName);
            }
        }

        public void SetProperty<T>(string name, T value)
        {
            if (string.IsNullOrWhiteSpace(name) || value == null)
            {
                return;
            }

            if (_telemetryProperties == null)
            {
                _telemetryProperties = new Dictionary<string, string>();
            }

            if (value is Exception ex)
            {
                _telemetryProperties["ExceptionMessage"] = ex.Message;
                _telemetryProperties["ExceptionStackTrace"] = ex.StackTrace;

                if (ex.InnerException != null)
                {
                    _telemetryProperties["InnerExceptionMessage"] = ex.InnerException.Message;
                    _telemetryProperties["InnerExceptionStackTrace"] = ex.InnerException.StackTrace;
                }

                return;
            }

            _telemetryProperties[name] = value.ToString();
        }

        public IDictionary<string, string> Properties => _telemetryProperties ?? new Dictionary<string, string>();
    }
}

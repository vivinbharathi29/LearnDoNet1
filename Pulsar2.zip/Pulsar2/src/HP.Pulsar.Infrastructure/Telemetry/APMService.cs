﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Elastic.Apm;
using Elastic.Apm.Api;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry
{
    public class APMService : ITelemetryService
    {
        public void Send(ITelemetryEvent telemetryEvent)
        {
            if (telemetryEvent == null)
            {
                return;
            }

            Task.Run(() => Log(telemetryEvent));
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private void Log(ITelemetryEvent telemetryEvent)
        {
            ITransaction transaction = Agent.Tracer.StartTransaction(telemetryEvent.Name, ApiConstants.TypeRequest);

            try
            {
                // TODO Bruce - potential bug on list elements changed here - due to different thread ? bug#38376
                foreach (KeyValuePair<string, string> item in telemetryEvent.Properties)
                {
                    transaction.Labels[item.Key] = item.Value;
                }

                if (telemetryEvent.Type == TelemetryType.Fault && telemetryEvent is ITelemetryFaultEvent faultEvent)
                {
                    transaction.CaptureException(faultEvent.Exception);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
            finally
            {
                transaction.End();
            }
        }
    }
}
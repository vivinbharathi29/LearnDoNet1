﻿using System.Diagnostics;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class ControllerFaultTelemetryEvent : PulsarRootFaultTelemetryEvent
    {
        public ControllerFaultTelemetryEvent()
            : base(TelemetryEventIdConstants.ControllerErrorEventId, "Fault-Controller")
        {
        }

        public static new int Id => TelemetryEventIdConstants.ControllerErrorEventId;
    }
}

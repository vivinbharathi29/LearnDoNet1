﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class CannotReadUserInfoInDatabaseTelemetryEvent : MVCProjectRootTelemetryEvent
    {
        public CannotReadUserInfoInDatabaseTelemetryEvent()
            : base("FailRead-UserInfo",
                   TelemetryType.Event,
                   TelemetryEventIdConstants.CannotReadUserInfoInDatabaseEventId)
        {
        }

        // BUG#41852
        // Need to think about a new design later. 
        // This static id will help startup.cs when we inject telemetry event to DI.
        // But we cannot force all childs to have Id from ITelemetry.
        // Need to find a good way that we can force all events with Id and also be static.
        public static new int Id => TelemetryEventIdConstants.CannotReadUserInfoInDatabaseEventId;
    }
}

﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.MVC
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class UserDeleteFavoriteTelemetryEvent : MVCProjectRootTelemetryEvent
    {
        public UserDeleteFavoriteTelemetryEvent()
            : base("Delete-UserFavorite",
                   TelemetryType.Event,
                   TelemetryEventIdConstants.UserDeleteFavoriteEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.UserDeleteFavoriteEventId;
    }
}

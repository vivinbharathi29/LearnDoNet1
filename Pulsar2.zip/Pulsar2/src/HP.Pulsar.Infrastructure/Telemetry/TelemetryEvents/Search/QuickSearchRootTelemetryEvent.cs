﻿using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    public abstract class QuickSearchRootTelemetryEvent : PulsarRootTelemetryEvent
    {
        protected QuickSearchRootTelemetryEvent(string leafEventName, TelemetryType telemetryType, int telemetryEventId)
            : base(leafEventName, telemetryType, telemetryEventId)
        {
            AddPrefixSegment("QuickSearch");
        }
    }
}

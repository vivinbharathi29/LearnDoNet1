﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class QuickSearchComponentVersionTelemetryEvent : QuickSearchRootTelemetryEvent
    {
        public QuickSearchComponentVersionTelemetryEvent()
            : base("Search-ComponentVersion", TelemetryType.Event, TelemetryEventIdConstants.SearchComponentVersionEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.SearchComponentVersionEventId;
    }
}

﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class QuickSearchProductTelemetryEvent : QuickSearchRootTelemetryEvent
    {
        public QuickSearchProductTelemetryEvent()
            : base("Search-Product", TelemetryType.Event, TelemetryEventIdConstants.SearchProductEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.SearchProductEventId;
    }
}

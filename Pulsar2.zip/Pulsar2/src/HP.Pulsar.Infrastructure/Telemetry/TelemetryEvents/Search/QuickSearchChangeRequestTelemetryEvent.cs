﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class QuickSearchChangeRequestTelemetryEvent : QuickSearchRootTelemetryEvent
    {
        public QuickSearchChangeRequestTelemetryEvent()
            : base("Search-ChangeRequest", TelemetryType.Event, TelemetryEventIdConstants.SearchChangeRequestEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.SearchChangeRequestEventId;
    }
}

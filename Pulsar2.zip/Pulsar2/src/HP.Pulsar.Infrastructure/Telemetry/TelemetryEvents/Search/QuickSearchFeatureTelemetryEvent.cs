﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class QuickSearchFeatureTelemetryEvent : QuickSearchRootTelemetryEvent
    {
        public QuickSearchFeatureTelemetryEvent()
            : base("Search-Feature", TelemetryType.Event, TelemetryEventIdConstants.SearchFeatureEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.SearchFeatureEventId;
    }
}

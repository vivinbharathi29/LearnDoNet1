﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class QuickSearchSuddenImpactTelemetryEvent : QuickSearchRootTelemetryEvent
    {
        public QuickSearchSuddenImpactTelemetryEvent()
           : base("Search-SuddenImpact", TelemetryType.Event, TelemetryEventIdConstants.SearchSuddenImpactEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.SearchSuddenImpactEventId;
    }
}

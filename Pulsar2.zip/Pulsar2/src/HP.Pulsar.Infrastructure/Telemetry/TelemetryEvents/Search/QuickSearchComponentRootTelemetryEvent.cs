﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class QuickSearchComponentRootTelemetryEvent : QuickSearchRootTelemetryEvent
    {
        public QuickSearchComponentRootTelemetryEvent()
            : base("Search-ComponentRoot", TelemetryType.Event, TelemetryEventIdConstants.SearchComponentRootEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.SearchComponentRootEventId;
    }
}

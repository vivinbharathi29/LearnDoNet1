﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class SearchPartNumberTelemetryEvent : QuickSearchRootTelemetryEvent
    {
        public SearchPartNumberTelemetryEvent()
            : base("Search-PartNumber", TelemetryType.Event, TelemetryEventIdConstants.SearchPartNumberEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.SearchPartNumberEventId;
    }
}

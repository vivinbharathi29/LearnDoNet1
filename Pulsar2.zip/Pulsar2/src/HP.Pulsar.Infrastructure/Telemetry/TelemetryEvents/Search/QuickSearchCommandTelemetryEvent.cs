﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Search
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class QuickSearchCommandTelemetryEvent : QuickSearchRootTelemetryEvent
    {
        public QuickSearchCommandTelemetryEvent()
           : base("Search-Command", TelemetryType.Event, TelemetryEventIdConstants.SearchCommandEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.SearchCommandEventId;
    }
}

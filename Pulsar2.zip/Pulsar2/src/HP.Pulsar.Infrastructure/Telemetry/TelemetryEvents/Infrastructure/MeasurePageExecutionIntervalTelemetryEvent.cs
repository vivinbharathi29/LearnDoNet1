﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Infrastructure
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class MeasurePageExecutionIntervalTelemetryEvent : PerfMonitorRootTelemetryEvent
    {
        public MeasurePageExecutionIntervalTelemetryEvent()
            : base("Measure-PageExecutionInterval",
                   TelemetryType.Event,
                   TelemetryEventIdConstants.MeasurePageExecutionIntervalEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.MeasurePageExecutionIntervalEventId;
    }
}

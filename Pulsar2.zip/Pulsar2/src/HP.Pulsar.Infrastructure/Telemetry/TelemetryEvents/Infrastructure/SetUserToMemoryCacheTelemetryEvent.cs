﻿using System.Diagnostics;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Infrastructure
{
    [DebuggerDisplay("Id={Id} EventName={Name}")]
    public class SetUserToMemoryCacheTelemetryEvent : UserMemoryCacheRootTelemetryEvent
    {
        public SetUserToMemoryCacheTelemetryEvent()
            : base("Set-User", TelemetryType.Event, TelemetryEventIdConstants.UserMemoryCacheSetUserEventId)
        {
        }

        public static new int Id => TelemetryEventIdConstants.UserMemoryCacheSetUserEventId;
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry.TelemetryEvents.Infrastructure
{
    public abstract class UserMemoryCacheRootTelemetryEvent : PulsarRootTelemetryEvent
    {
        protected UserMemoryCacheRootTelemetryEvent(string leafEventName, TelemetryType telemetryType, int telemetryEventId)
            : base(leafEventName, telemetryType, telemetryEventId)
        {
            AddPrefixSegment("MemoryCache");
        }
    }
}

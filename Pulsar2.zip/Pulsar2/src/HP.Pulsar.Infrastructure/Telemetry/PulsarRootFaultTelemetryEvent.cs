﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Telemetry
{
    public abstract class PulsarRootFaultTelemetryEvent : PulsarRootTelemetryEvent, ITelemetryFaultEvent
    {
        protected PulsarRootFaultTelemetryEvent(int telemetryEventId, string leafEventName)
            : base(leafEventName, TelemetryType.Fault, telemetryEventId)
        {
        }

        public Exception Exception { get; set; }
    }
}

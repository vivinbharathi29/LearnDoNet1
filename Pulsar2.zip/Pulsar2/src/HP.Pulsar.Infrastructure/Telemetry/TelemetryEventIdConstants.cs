﻿namespace HP.Pulsar.Infrastructure.Telemetry
{
    public static class TelemetryEventIdConstants
    {
        // Memroy cache
        public static readonly int UserMemoryCacheFetchUserEventId = 1;
        public static readonly int UserMemoryCacheSetUserEventId = 2;
        public static readonly int UserNotAuthenticatedEventId = 3;

        // MVC project
        public static readonly int CannotReadUserInfoInDatabaseEventId = 100;
        public static readonly int PageOrActionArrivalEventId = 101;
        public static readonly int StartImpersonationEventId = 102;
        public static readonly int StopImpersonationEventId = 103;
        public static readonly int ControllerErrorEventId = 104;
        public static readonly int UserFeedbackEventId = 105;

        // Performance monitor
        public static readonly int MeasurePageExecutionIntervalEventId = 200;

        // Quick search
        public static readonly int SearchChangeRequestEventId = 300;
        public static readonly int SearchCommandEventId = 301;
        public static readonly int SearchComponentRootEventId = 302;
        public static readonly int SearchComponentVersionEventId = 303;
        public static readonly int SearchFeatureEventId = 304;
        public static readonly int SearchProductEventId = 305;
        public static readonly int SearchSuddenImpactEventId = 306;

        // Pulsar User
        public static readonly int MenuItemWithNoRootEventId = 400;
        public static readonly int UserAddFavoriteEventId = 401;
        public static readonly int UserDeleteFavoriteEventId = 402;
        public static readonly int UserHasInvalidLoginNameEventId = 403;

        // PartNumber search
        public static readonly int SearchPartNumberEventId = 500;
    }
}

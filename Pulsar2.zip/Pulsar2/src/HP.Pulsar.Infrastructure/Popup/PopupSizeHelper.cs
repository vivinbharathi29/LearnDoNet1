﻿using HP.Pulsar.CommonContracts.Infrastructure.Popup;

namespace HP.Pulsar.Infrastructure.Popup
{
    public static class PopupSizeHelper
    {
        public static int GetHeightPercentage(this PopupSize size)
        {
            if (size == PopupSize.Medium)
            {
                return 65;
            }

            if (size == PopupSize.Small)
            {
                return 50;
            }

            return 80;
        }

        public static int GetWidthPercentage(this PopupSize size)
        {
            if (size == PopupSize.Medium)
            {
                return 75;
            }

            if (size == PopupSize.Small)
            {
                return 60;
            }

            return 90;
        }
    }
}

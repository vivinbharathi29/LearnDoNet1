﻿namespace HP.Pulsar.Infrastructure.Abstractions.Popups
{
    public interface IPopupService
    {
        /// <summary>
        /// Get popup by id
        /// </summary>
        /// <param name="popupId"></param>
        /// <returns></returns>
        IPopup GetPopup(int popupId);
    }
}

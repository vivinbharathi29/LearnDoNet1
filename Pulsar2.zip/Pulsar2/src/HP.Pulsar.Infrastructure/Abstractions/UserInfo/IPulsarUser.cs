using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.TodayPage.Favorites;
using HP.Pulsar.Infrastructure.CommonModels.QuickSearch;
using HP.Pulsar.Infrastructure.CommonModels.UserInfo;

namespace HP.Pulsar.Infrastructure.Abstractions.UserInfo
{
    public interface IPulsarUser : IUserInfoModel
    {
        CurrentFocusedMenuItem CurrentFocusedMenuItem { get; set; }

        bool IsReloadImpersonationUserRequired { get; set; }

        string UserAliasWithDomainName { get; }

        bool IsUnderImpersonation { get; }

        Task AddUserFavoriteAsync(UserFavorite userFavorite);

        Task CancelImpersonationAsync();

        Task DeleteUserFavoriteAsync(UserFavorite userFavorite);

        Task<(ImpersonationArea ImpersonationArea, IPulsarUser ImpersonatedUser)> GetImpersonatedUserAsync();

        /// <summary>
        /// Gets a set of recent searched histories.
        /// </summary>
        /// <returns></returns>
        Task<IReadOnlyList<string>> GetRecentSearchHistoryAsync();

        /// <summary>
        /// Gets a set of recent search items
        /// </summary>
        /// <returns></returns>
        Task<IReadOnlyList<QuickSearchItem>> GetRecentSearchItemsAsync();

        /// <summary>
        /// Gets all favorite items
        /// </summary>
        /// <returns></returns>
        Task<IList<UserFavorite>> GetUserFavoritesAsync(string searchText = "", bool isTileIncluded = false);

        /// <summary>
        /// Gets favorite items based on favorite type
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        Task<IList<UserFavorite>> GetUserFavoritesAsync(UserFavoriteType type);

        Task SetImpersonatedUserAsync(ImpersonationArea area, int impersonatedUserId);

        /// <summary>
        /// Gets menu items to display on UI in All Tile menu
        /// </summary>
        /// <returns></returns>
        Task<IReadOnlyList<UIMenuItem>> GetTileMenuItemsAsync();

        /// <summary>
        /// Gets menu items to disyplay on UI in All Service menu
        /// </summary>
        /// <returns></returns>
        Task<IReadOnlyList<UIMenuItem>> GetServiceMenuItemsAsync();

        Task SaveRecentSearchHistoryToCacheAsync();

        Task SaveRecentSearchItemsToCacheAsync();

        /// <summary>
        /// Sets a recent searched history.
        /// </summary>
        void SetRecentSearchHistory(string item);

        Task ReadRecentSearchHistoryFromCacheAsync();

        /// <summary>
        /// Sets a recent search item
        /// </summary>
        /// <param name="item"></param>
        void SetRecentSearchItem(QuickSearchItem item);

        Task ReadRecentSearchItemsFromCacheAsync();

        Task UpdateUserFavoritesAsync(IReadOnlyList<UserFavorite> userFavorites);
    }
}
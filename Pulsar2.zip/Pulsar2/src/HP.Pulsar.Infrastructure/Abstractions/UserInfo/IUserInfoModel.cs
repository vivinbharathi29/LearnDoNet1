﻿using HP.Pulsar.CommonContracts.ProductPage;
using HP.Pulsar.CommonContracts.Repository.Models;
using HP.Pulsar.Infrastructure.CommonModels.UserInfo;

namespace HP.Pulsar.Infrastructure.Abstractions.UserInfo
{
    public interface IUserInfoModel : IUserRootInfoModel
    {
        bool CanShowSwitchCm { get; }

        bool CanShowSwitchMarketing { get; }

        bool CanShowSwitchPc { get; }

        bool CanShowSwitchPhWeb { get; }

        bool CanShowSwitchPm { get; }

        IPageTab DefaultProductPageTab { get; }

        UserDivision Division { get; }

        int EmployeeNumber { get; }

        string FullName { get; }

        int? ImpersonatedUserIdInSwitchCM { get; }

        int? ImpersonatedUserIdInSwitchMarketing { get; }

        int? ImpersonatedUserIdInSwitchPC { get; }

        int? ImpersonatedUserIdInSwitchPhWeb { get; }

        int? ImpersonatedUserIdInSwitchPM { get; }

        int? ImpersonatedUserIdInSystemLevel { get; }

        bool IsAccessoryPM { get; }

        bool IsActive { get; }

        bool IsActiveInPMRole { get; }

        bool IsAVsMissingCommMarketingData { get; }

        bool IsAVsMissingConsMarketingData { get; }

        bool IsAVsMissingSMBMarketingData { get; }

        bool IsCMEditAccess { get; }

        bool IsCommodityPM { get; }

        bool IsComponentsAvailable { get; }

        bool IsDcrPM { get; }

        bool IsEngCoordinator { get; }

        bool IsFTBIOSSection { get; }

        bool IsHardwarePM { get; }

        bool IsHPEmployee { get; }

        bool IsMITTestLead { get; }

        bool IsOTSDeliverableSection { get; }

        bool IsPDMUser { get; }

        bool IsPreinstallPM { get; }

        bool IsPulsarAdmin { get; }

        bool IsRequestingFeature { get; }

        bool IsSCFactoryEngineer { get; }

        bool IsSEPMEditAccess { get; set; }

        bool IsServicePM { get; }

        bool IsSMEditAccess { get; set; }

        bool IsSvcBomAnalystOrGPLM { get; }

        bool IsTestLeadAssignment { get; }

        bool IsUserHasAccessRequest { get; }

        bool IsWHQLTestTeam { get; }

        int PartnerId { get; }
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Repository.Models;
using HP.Pulsar.CommonContracts.TodayPage.Favorites;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;
using HP.Pulsar.Infrastructure.CommonModels.UserInfo;

namespace HP.Pulsar.Infrastructure.Abstractions.UserInfo
{
    public interface IUserInfoRepository
    {
        Task AddOrUpdateUserDataCacheAsync(int userId, string key, string value);

        Task AddUserFavoriteAsync(int userId, UserFavorite userFavorite);

        Task ClearImpersonationAsync(int userId);

        Task DeleteUserFavoriteAsync(int userId, UserFavorite userFavorite);

        Task<IReadOnlyList<UserDetailsWithProductDataModel>> GetPMsAsync(int productId);

        Task<string> GetUserCachedDataAsync(int userId, string key);

        Task<IUserInfoModel> GetUserInfoModelAsync(string userAlias, string domainName, bool isActive = true);

        Task<IUserInfoModel> GetUserInfoModelAsync(int userId, bool isActive = true);

        Task<IUserInfoModel> GetUserInfoModelAsync(string userEmail, bool isActive = true);

        Task<IReadOnlyList<UserFavorite>> GetUserFavoritesAsync(int userId, string searchText = "");

        Task<IReadOnlyList<IUserRootInfoModel>> GetUsersRootInfoAsync(string searchText, bool isActive = true);

        Task<IReadOnlyList<IUserRootInfoModel>> GetUsersForSwitchCMAsync(string searchText);

        Task<IReadOnlyList<IUserRootInfoModel>> GetUsersForSwitchMarketingAsync(string searchText);

        Task<IReadOnlyList<IUserRootInfoModel>> GetUsersForSwitchPCAsync(string searchText);

        Task<IReadOnlyList<IUserRootInfoModel>> GetUsersForSwitchPhWebAsync(string searchText);

        Task<IReadOnlyList<IUserRootInfoModel>> GetUsersForSwitchPMAsync(string searchText);

        Task<bool> IsUserInRoleAsync(int userId, int roleId);

        Task<bool> IsUserInRoleWithPermissionAsync(int userId, string permissionName);

        Task SetImpersonationAsync(ImpersonationArea area, int userId, int impersonatedUserId);

        Task UpdateUserFavoritesAsync(int Id, string userFavoritesJson);
    }
}
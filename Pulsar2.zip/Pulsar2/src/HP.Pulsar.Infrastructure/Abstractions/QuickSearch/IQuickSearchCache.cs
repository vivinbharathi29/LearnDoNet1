﻿using System.Collections.Generic;
using HP.Pulsar.Infrastructure.CommonModels.QuickSearch;

namespace HP.Pulsar.Infrastructure.Abstractions.QuickSearch
{
    public interface IQuickSearchCache
    {
        void SetItems(string searchText, QuickSearchType type, IReadOnlyList<QuickSearchItem> items);

        bool TryGetItems(string searchText, QuickSearchType type, out IReadOnlyList<QuickSearchItem> items);
    }
}

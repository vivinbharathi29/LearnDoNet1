﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.Infrastructure.Abstractions.Application.Grid;
using HP.Pulsar.Infrastructure.CommonModels.QuickSearch;
using Newtonsoft.Json.Serialization;

namespace HP.Pulsar.Infrastructure.Abstractions.QuickSearch
{
    public interface IQuickSearchMoreResultDataProvider
    {
        string ContentUrlRelativePath { get; }

        //TODO: This is an a temporary solution. In future, it will get off.
        string ShowContentUrlRelativePath { get; }

        QuickSearchType Type { get; }

        string GetColumnsDataJsonString();

        string GetColumnTemplatesJsonString();

        string GetFeaturesDataJsonString();

        IContractResolver GetJsonContractResolver();

        Task<IQuickSearchMoreResultContentModel> GetSearchResultContentModelAsync(IGridGeneralInput inputModel);

        Task<(IReadOnlyList<IGridGeneralOutput> DataList, int DataCount)> GetSearchResultDataAsync(IGridGeneralInput inputModel);
    }
}

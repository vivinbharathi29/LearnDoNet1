﻿using HP.Pulsar.Infrastructure.CommonModels.QuickSearch;

namespace HP.Pulsar.Infrastructure.Abstractions.QuickSearch
{
    public interface IQuickSearchMoreResultService
    {
        IQuickSearchMoreResultDataProvider GetDataProvider(QuickSearchType type);
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Infrastructure.CommonModels.QuickSearch;

namespace HP.Pulsar.Infrastructure.Abstractions.QuickSearch
{
    public interface IQuickSearchEngine
    {
        Task<IReadOnlyList<QuickSearchItem>> SearchBluePartNumbersAsync(string bluePartNumber, string userAliasWithDomain, int totalCount = 20);

        Task<IReadOnlyList<QuickSearchItem>> SearchChangeRequestsAsync(string searchText, string userAliasWithDomain, int totalCount = 20);

        Task<IReadOnlyList<QuickSearchItem>> SearchCommandsAsync(string searchText, string userAliasWithDomain, bool isHPEmployee);

        Task<IReadOnlyList<QuickSearchItem>> SearchComponentRootsAsync(string searchText, string userAliasWithDomain, int totalCount = 20);

        Task<IReadOnlyList<QuickSearchItem>> SearchComponentVersionsAsync(string searchText, string userAliasWithDomain, int totalCount = 20);

        Task<IReadOnlyList<QuickSearchItem>> SearchFeaturesAsync(string searchText, string userAliasWithDomain, int totalCount = 20);

        Task<IReadOnlyList<QuickSearchItem>> SearchProductsAsync(string searchText, string userAliasWithDomain, int totalCount = 20);

        Task<IReadOnlyList<QuickSearchItem>> SearchSuddenImpactsAsync(string searchText, string userAliasWithDomain);
    }
}

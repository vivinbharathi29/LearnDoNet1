﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Search;
using HP.Pulsar.CommonContracts.TodayPage.Search;
using HP.Pulsar.Infrastructure.CommonModels.QuickSearch;

namespace HP.Pulsar.Infrastructure.Abstractions.QuickSearch.Repository
{
    public interface IQuickSearchMoreResultsRepository
    {
        Task<(IReadOnlyList<ProductMoreResultsModel> DataList, int DataCount)> GetProductMoreResultsAsync(string searchText, IPaginationModel pagination);

        Task<(IReadOnlyList<ChangeRequestMoreResultsModel> DataList, int DataCount)> GetChangeRequestMoreResultsAsync(string searchText, IPaginationModel pagination);

        Task<(IReadOnlyList<FeatureMoreResultsModel> DataList, int DataCount)> GetFeatureMoreResultsAsync(string searchText, IPaginationModel pagination);

        Task<(IReadOnlyList<ComponentVersionMoreResultDataFromRepo> DataList, int DataCount)> GetComponentVersionMoreResultsAsync(string searchText, IPaginationModel pagination);

        Task<(IReadOnlyList<ComponentRootMoreResultDataFromRepo> DataList, int DataCount)> GetComponentRootMoreResultsAsync(string searchText, IPaginationModel pagination);
    }
}

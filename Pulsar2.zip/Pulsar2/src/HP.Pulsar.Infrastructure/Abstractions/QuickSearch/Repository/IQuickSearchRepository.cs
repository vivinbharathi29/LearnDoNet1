﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace HP.Pulsar.Infrastructure.Abstractions.QuickSearch.Repository
{
    public interface IQuickSearchRepository
    {
        Task<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)?> GetChangeRequestAsync(int id);

        Task<IReadOnlyList<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)>> GetChangeRequestsAsync(string searchText, int totalDataCount);

        Task<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)?> GetCompoentRootAsync(int id);

        Task<IReadOnlyList<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)>> GetCompoentRootsAsync(string searchText, int totalDataCount);

        Task<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)?> GetCompoentVersionAsync(int id);

        Task<IReadOnlyList<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)>> GetCompoentVersionsAsync(string searchText, int totalDataCount);

        Task<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)?> GetFeatureAsync(int id);

        Task<IReadOnlyList<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)>> GetFeaturesAsync(string searchText, int totalDataCount);

        Task<IReadOnlyList<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)>> GetBluePartNumberFeaturesAsync(string bluePartNumber, int totalDataCount);

        Task<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)?> GetProductAsync(int id);

        Task<IReadOnlyList<(int Id, string Name, IQuickSearchAdditionalOne AdditionalOne)>> GetProductsAsync(string searchText, int totalDataCount);

        Task<(long Id, string Name, IQuickSearchAdditionalOne AdditionalOne)?> GetSuddenImpactAsync(long id);
    }
}

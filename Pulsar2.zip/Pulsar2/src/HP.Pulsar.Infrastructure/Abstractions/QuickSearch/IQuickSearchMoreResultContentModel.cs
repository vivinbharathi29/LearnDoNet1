﻿using HP.Pulsar.Infrastructure.CommonModels.QuickSearch;

namespace HP.Pulsar.Infrastructure.Abstractions.QuickSearch
{
    public interface IQuickSearchMoreResultContentModel
    {
        string ColumnsData { get; }

        string GridDataUrlRelativePath { get; }

        string GridFeatures { get; }

        string HeaderText { get; }

        public QuickSearchType SearchType { get; }

        //TODO: This is an a temporary solution. In future, it will get off.
        string ShowContentUrlRelativePath { get; }
    }
}

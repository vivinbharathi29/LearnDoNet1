﻿namespace HP.Pulsar.Infrastructure.Abstractions.QuickSearch
{
    // This interface is for quick search result. 
    // Each search type may have different concrete model with different properties, so we 
    // use a common interface to host them in quick search repository.
    public interface IQuickSearchAdditionalOne
    {
    }
}

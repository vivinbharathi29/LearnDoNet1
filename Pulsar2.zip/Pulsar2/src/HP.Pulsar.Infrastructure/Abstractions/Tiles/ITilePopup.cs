﻿namespace HP.Pulsar.Infrastructure.Abstractions.Tiles
{
    public interface ITilePopup
    {
        bool TryGetTile(int popupId, out ITile tile);
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.TodayPage.Tiles;
using HP.Pulsar.Infrastructure.Abstractions.Application.Grid;
using Newtonsoft.Json.Serialization;

namespace HP.Pulsar.Infrastructure.Abstractions.Tiles
{
    public interface ITile
    {
        string ContentCountUrlRelativePath { get; }

        string ContentUrlRelativePath { get; }

        string ExcelExportUrlRelativePath { get; }

        string ShowContentUrlRelativePath { get; }

        int Id { get; }

        string Name { get; }

        TileArea TileArea { get; }

        TileGroup TileGroup { get; }

        string GetColumnsDataJsonString();

        string GetColumnTemplatesJsonString();

        string GetContextMenuItemsJsonString();

        Task<int> GetCountAsync(IGridGeneralInputRoot inputModel);

        string GetFeaturesDataJsonString();

        IContractResolver GetJsonContractResolver();

        ITileContentModel GetTileContentModel(IGridGeneralInput inputModel);

        Task<(IReadOnlyList<IGridGeneralOutput> DataList, int DataCount)> GetTileDataAsync(IGridGeneralInput inputModel);

        Task<bool> PostData(IGridGeneralInputRoot inputModel);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;
using HP.Pulsar.CommonContracts.Repository.Models.Tiles;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;
using HP.Pulsar.CommonContracts.TodayPage.Tiles.Models;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IMyItemRepository
    {
        Task<bool> CreateSimpleAvAsync(int userId, string avCreateIds, int actionableValue);

        Task<bool> CreateSimpleAvPulsarAsync(int userId, string avCreateIds, int actionableValue);

        Task<(IReadOnlyList<AllOpenItemsIOwnTileDataFromTile> DataList, int DataCount)> GetAllOpenItemsIOwnAsync(int userId, IPaginationModel pagination);

        Task<int> GetAllOpenItemsIOwnCountAsync(int userId);

        Task<(IReadOnlyList<AllOpenItemsISubmittedDataFromTile> DataList, int DataCount)> GetAllOpenItemsISubmittedAsync(int userId, IPaginationModel pagination);

        Task<int> GetAllOpenItemsISubmittedCountAsync(int userId);

        Task<PhWebActionItemsModel> GetAvActionItemsDataAsync(int avActionItemId, int productBrandId);

        Task<IDictionary<string, string>> GetAvNumberDescriptionsAsync(int productVersionId, int productBrandId, int scmCategoryId);

        Task<(IReadOnlyList<DCRWorkflowMilestonesTileDataFromTile> DataList, int DataCount)> GetDcrWorkflowMilestonesAsync(int userId, IPaginationModel pagination);

        Task<int> GetDcrWorkflowMilestonesCountAsync(int userId);

        Task<(IReadOnlyList<DueThisWeekTileDataFromTile> DataList, int DataCount)> GetDueThisWeekAsync(int userId, IPaginationModel pagination);

        Task<int> GetDueThisWeekCountAsync(int userId);

        Task<(IReadOnlyList<FeatureNamingOverrideRequestTileDataFromTile> DataList, int DataCount)> GetFeatureNamingOverrideRequestAsync(int userId, IPaginationModel pagination);

        Task<int> GetFeatureNamingOverrideRequestCountAsync(int userId);

        Task<(IReadOnlyList<FeatureRemovedFromPostPRLLockTileDataFromTile> DataList, int DataCount)> GetFeatureRemovedFromPostPRLLockAsync(int userId, IPaginationModel pagination);

        Task<int> GetFeatureRemovedFromPostPRLLockCountAsync(int userId);

        Task<(IReadOnlyList<ImageTabChangeToLocalizationForPulsarProductTileDataFromTile> DataList, int DataCount)> GetImageTabChangeToLocalizationForPulsarProductAsync(int userId, IPaginationModel pagination);

        Task<int> GetImageTabChangeToLocalizationForPulsarProductCountAsync(int userId);

        Task<(IReadOnlyList<InitialOfferingDeactiveSimpleAvsTileDataFromTile> DataList, int DataCount)> GetInitialOfferingDeactivateSimpleAvsAsync(int userId, IPaginationModel pagination);

        Task<int> GetInitialOfferingDeactivateSimpleAvsCountAsync(int? userId);

        Task<(IReadOnlyList<ItemsAwaitingMyApprovalTileDataFromTile> DataList, int DataCount)> GetItemsAwaitingMyApprovalAsync(int userId, IPaginationModel pagination);

        Task<int> GetItemsAwaitingMyApprovalCountAsync(int userId);

        Task<(IReadOnlyList<MissingAVMarketingTileDataFromTile> DataList, int DataCount)> GetMissingAVMarketingDataAsync(int userId, IPaginationModel pagination);

        Task<int> GetMissingAVMarketingDataCountAsync(int userId);

        Task<(IReadOnlyList<MyOpenTicketsTileDataFromTile> DataList, int DataCount)> GetMyOpenTicketsAsync(int userId, IPaginationModel pagination);

        Task<int> GetMyOpenTicketsCountAsync(int? userId);

        Task<(IReadOnlyList<MyWorkingListTileDataFromTile> DataList, int DataCount)> GetMyWorkingListAsync(int userId, IPaginationModel pagination);

        Task<int> GetMyWorkingListCountAsync(int userId);

        Task<(IReadOnlyList<OpenObservationsAssignedToMeTileDataFromRepo> DataList, int DataCount)> GetOpenObservationsAssignedToMeAsync(string email, IPaginationModel pagination);

        Task<int> GetOpenObservationsAssignedToMeCountAsync(int userId);

        Task<(IReadOnlyList<OpenObservationsISubmittedTileDataFromRepo> DataList, int DataCount)> GetOpenObservationsISubmittedAsync(string email, IPaginationModel pagination);

        Task<int> GetOpenObservationsISubmittedCountAsync(int userId);

        Task<(IReadOnlyList<OpenObservationsOnMyComponentsTileDataFromRepo> DataList, int DataCount)> GetOpenObservationsOnMyComponentsAsync(int userId, IPaginationModel pagination);

        Task<int> GetOpenObservationsOnMyComponentsCountAsync(int userId);

        Task<(IReadOnlyList<PendingZsrpReadyDatesTileDataFromTile> DataList, int DataCount)> GetPendingZsrpReadyDatesAsync(int userId, IPaginationModel pagination);

        Task<int> GetPendingZsrpReadyDatesCountAsync(int userId);

        Task<(IReadOnlyList<PhWebAvActionItemsLegacyProductTileDataFromTile> DataList, int DataCount)> GetPhWebAvActionItemLegacyProductAsync(int userId, IPaginationModel pagination);

        Task<int> GetPhWebAvActionItemLegacyProductCountAsync(int userId);

        Task<(IReadOnlyList<PhWebAvActionItemsPulsarProductTileDataFromTile> DataList, int DataCount)> GetPhWebAvActionItemsPulsarProductAsync(int userId, IPaginationModel pagination);

        Task<int> GetPhWebAvActionItemsPulsarProductCountAsync(int userId);

        Task<(IReadOnlyList<RejectedAvsPulsarProductTileDataFromTile> DataList, int DataCount)> GetRejectedAvsPulsarProductAsync(int userId, IPaginationModel pagination);

        Task<int> GetRejectedAvsPulsarProductCountAsync(int userId);

        Task<(IReadOnlyList<SharedAVActionsTileDataFromTile> DataList, int DataCount)> GetSharedAVActionsAsync(int userId, IPaginationModel pagination);

        Task<int> GetSharedAVActionsCountAsync(int userId);

        Task<(IReadOnlyList<CreateSimpleAVLegacyTileDataFromTile> DataList, int DataCount)> GetSimpleAVsCreatedForLegacyProductAsync(int userId, IPaginationModel pagination);

        Task<int> GetSimpleAVsCreatedForLegacyProductCountAsync(int userId);

        Task<(IReadOnlyList<CreateSimpleAVPulsarDataFromTile> DataList, int DataCount)> GetSimpleAVsCreatedForPulsarProductAsync(int userId, IPaginationModel pagination);

        Task<int> GetSimpleAVsCreatedForPulsarProductCountAsync(int userId);

        Task<IReadOnlyList<IUserInfoModel>> GetSupportAdmins();

        Task<IDictionary<int, string>> GetSupportCategories(int projectId);

        Task<IDictionary<int, string>> GetSupportProjects();

        Task<TicketDataFromRepo> GetTicketDataAsync(int ticketId);

        Task<TicketPreviewDataFromRepo> GetTicketPreviewDataAsync(int productId);

        Task<(IReadOnlyList<UsersAndRolesRequestsTileDataFromTile> DataList, int DataCount)> GetUsersAndRolesRequestsAsync(int userId, IPaginationModel pagination);

        Task<int> GetUsersAndRolesRequestsCountAsync(int? userId);

        Task<bool> UpdateAvDetailsAsync(int avCreateId, int componentRootId, int productBrandId, string avNumber, int updateDescription, int userId);

        Task<bool> UpdateAvDetailFeatureIdAsync(int avCreateId, int featureId, string avNumber, int userId);

        Task<bool> UpdateFeatureRemovedFromPRLLock(int featureId, int actionId, string userName);

        Task<bool> UpdateImageTabLocalizationAVsAsync(string imageActionItemIds, string productVersionIds, string productBrandIds, string userName);

        Task<bool> UpdateImageTabLocalizationAVsNotActionableAsync(string imageActionItemIds, string userName);

        Task<bool> UpdateImageTabLocalizationAVsObsoleteAsync(string imageActionItemIds, string productVersionIds, string userName);
        
        Task<bool> UpdateMutliActualZsrpReadyDataAsync(string ids, DateTime actualDate, int userId);

        Task<bool> UpdateMutliDcrInfoAsync(string ids, string summary, string description, string justification, int userId);

        Task<bool> UpdateMultZsrpReadyTargetDateAsync(string ids, DateTime targetDate, int userId);

        Task<bool> UpdateOverrideRequestedFeatureFeedbackAsync(int featureId, int actionType, int userId);

        Task<bool> UpdateRejectedAvsForPulsarProduct(IReadOnlyList<int> rejectedItemIds, string userName);

        Task<bool> UpdateTicketDataAsync(TicketForPostData ticketForPostData);

        Task<bool> TryUpdatePhWebCplBlindDateAsync(int avDetailId, string currentUserName, DateTime? cplBlindDate);

        Task<bool> TryUpdatePDMFeedbackAsync(int avActionItemId, string pdmFeedback, string userName);

        Task<bool> TryUpdatePhWebEntryCompleteAsync(int avActionItemId, int phWebActionTypeId, bool notActionable);
    }
}
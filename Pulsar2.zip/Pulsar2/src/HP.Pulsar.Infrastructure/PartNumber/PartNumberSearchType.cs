﻿using System.Collections.Generic;

namespace HP.Pulsar.Infrastructure.PartNumber
{
    public sealed class PartNumberSearchType
    {
        private const int _bomStructure = 2;
        private const int _materialDescription = 1;
        private const int _odmPartInformation = 5;
        private const int _subassemblies = 6;
        private const int _whereUsedInformation = 3;
        private const int _whereUsedInSpareKits = 4;

        private PartNumberSearchType(int id)
        {
            Id = id;
        }

        public string Name
        {
            get
            {
                if (Id == 1)
                {
                    return "Material Description";
                }
                if (Id == 2)
                {
                    return "BOM Structure";
                }
                if (Id == 3)
                {
                    return "Where Used Information";
                }
                if (Id == 4)
                {
                    return "Where Used In SpareKits";
                }
                if (Id == 5)
                {
                    return "ODM Part";
                }
                if (Id == 6)
                {
                    return "Subassemblies";
                }

                return "";
            }
        }

        public int Id { get; }

        public static PartNumberSearchType BOMStructure => new PartNumberSearchType(_bomStructure);

        public static PartNumberSearchType MaterialDescription => new PartNumberSearchType(_materialDescription);

        public static PartNumberSearchType ODMPartInformation => new PartNumberSearchType(_odmPartInformation);

        public static PartNumberSearchType Subassemblies => new PartNumberSearchType(_subassemblies);

        public static PartNumberSearchType WhereUsedInformation => new PartNumberSearchType(_whereUsedInformation);

        public static PartNumberSearchType WhereUsedInSpareKits => new PartNumberSearchType(_whereUsedInSpareKits);

        public static bool TryParse(int id, out PartNumberSearchType value)
        {
            if (id == 1)
            {
                value = MaterialDescription;
                return true;
            }
            if (id == 2)
            {
                value = BOMStructure;
                return true;
            }
            if (id == 3)
            {
                value = WhereUsedInformation;
                return true;
            }
            if (id == 4)
            {
                value = WhereUsedInSpareKits;
                return true;
            }
            if (id == 5)
            {
                value = ODMPartInformation;
                return true;
            }
            if (id == 6)
            {
                value = Subassemblies;
                return true;
            }

            value = null;
            return false;
        }

        public static IReadOnlyList<(int, string)> GetPartNumberSearchTabs()
        {
            return new List<(int, string)>()
            {
                (_materialDescription,"Material Description"),
                (_bomStructure,"BOM Structure"),
                (_whereUsedInformation,"Where Used Information"),
                (_whereUsedInSpareKits,"Where Used In SpareKits"),
                (_odmPartInformation,"ODM Part"),
                (_subassemblies,"Subassemblies")
            };
        }
    }
}

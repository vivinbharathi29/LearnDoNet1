﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class HttpContextExtensions
    {
        public static bool TryGetCurrentUser(this HttpContext httpContext, IUserMemoryCache userCache, out IPulsarUser currentUser)
        {
            currentUser = null;

            if (userCache == null)
            {
                return false;
            }

            // #BUG#41261
            string userAliasOrEmail = httpContext.User?.Identity?.Name;

            if (httpContext.Request.Headers.TryGetValue("HPPF_AUTH_UID", out StringValues value))
            {
                userAliasOrEmail = value.ToString();
            }

            if (string.IsNullOrWhiteSpace(userAliasOrEmail))
            {
                return false;
            }

            return userCache.TryGetUser(userAliasOrEmail, out currentUser);
        }

        public static bool TryGetRequestFormValue(this HttpContext httpContext, string key, out string value)
        {
            value = string.Empty;

            if (string.IsNullOrWhiteSpace(key))
            {
                return false;
            }

            KeyValuePair<string, StringValues> keyValue = httpContext.Request.Form.FirstOrDefault(x => string.Equals(x.Key, key, StringComparison.OrdinalIgnoreCase));

            if (!keyValue.Equals(default(KeyValuePair<string, StringValues>)))
            {
                value = keyValue.Value.ToString();
                return true;
            }

            return false;
        }

        public static string JoinQueryStringValueWthFilter(this HttpContext httpContext, string queryStringName, string queryStringValue)
        {
            if (httpContext.Request.QueryString == default)
            {
                return string.Empty;
            }

            string urlQueryStrings = httpContext.Request.QueryString.ToString();
            NameValueCollection queryStringNameValues = HttpUtility.ParseQueryString(urlQueryStrings);
            queryStringNameValues.Set(queryStringName, queryStringValue);

            return queryStringNameValues.ToString();
        }
    }
}

﻿using System.Globalization;
using System.Text;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class StringBuilderExtensions
    {
        public static int LastIndexOf(this StringBuilder stringBuilder, char target, bool ignoreCase = true, CultureInfo culture = null)
        {
            if (stringBuilder == null)
            {
                return -1;
            }

            if (culture == null)
            {
                culture = CultureInfo.InvariantCulture;
            }

            if (ignoreCase)
            {
                target = char.ToUpper(target, culture);
            }

            // start from the end
            int startIndex = stringBuilder.Length - 1;

            for (int i = startIndex; i >= 0; i--)
            {
                char currentChar = ignoreCase ? char.ToUpper(stringBuilder[i], culture) : stringBuilder[i];
                 
                if (target == currentChar)
                {
                    return i;
                }
            }

            return -1;
        }
    }
}

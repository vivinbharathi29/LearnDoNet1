﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;
using HP.Pulsar.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class TelemetryFactoryExtensions
    {
        public static void SendFaultTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                   string reason,
                                                   Exception ex,
                                                   string controllerName,
                                                   string userAliasWithDomainName = "",
                                                   string note = "")
        {
            if (telemetryFactory.TryGet(TelemetryEventIdConstants.ControllerErrorEventId, out ITelemetryEvent telemetryEvent))
            {
                telemetryEvent.SetProperty("Controller", controllerName);
                telemetryEvent.SetProperty("ErrorReason", reason);
                telemetryEvent.SetProperty("Note", note);
                telemetryFactory.Send(telemetryEvent, userAliasWithDomainName, ex);
            }
        }

        public static void SendPageOrActionArrivalTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                 string userAliasWithDomainName,
                                                                 string pageOrActionName,
                                                                 string note = "")
        {
            if (telemetryFactory.TryGet(TelemetryEventIdConstants.PageOrActionArrivalEventId, out ITelemetryEvent telemetryEvent))
            {
                telemetryEvent.SetProperty("PageOrActionName", pageOrActionName);
                telemetryEvent.SetProperty("Note", note);
                telemetryFactory.Send(telemetryEvent, userAliasWithDomainName);
            }
        }

        public static void SendTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                              int telemetryEventId,
                                              string controllerName,
                                              string userAliasWithDomainName = "",
                                              string note = "")
        {
            if (telemetryFactory.TryGet(telemetryEventId, out ITelemetryEvent telemetryEvent))
            {
                telemetryEvent.SetProperty("Controller", controllerName);
                telemetryEvent.SetProperty("Note", note);
                telemetryFactory.Send(telemetryEvent, userAliasWithDomainName);
            }
        }

        public static void SendStartImpersonationTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                string userAliasWithDomainName,
                                                                string impersonationArea,
                                                                int impersonatedUserId)
        {
            if (telemetryFactory.TryGet(TelemetryEventIdConstants.StartImpersonationEventId, out ITelemetryEvent telemetryEvent))
            {
                telemetryEvent.SetProperty("ImpersonationArea", impersonationArea);
                telemetryEvent.SetProperty("ImpersonatedUserId", impersonatedUserId);
                telemetryFactory.Send(telemetryEvent, userAliasWithDomainName);
            }
        }

        public static void SendStopImpersonationTelemetryEvent(this ITelemetryFactory telemetryFactory, string userAliasWithDomainName)
        {
            if (telemetryFactory.TryGet(TelemetryEventIdConstants.StopImpersonationEventId, out ITelemetryEvent telemetryEvent))
            {
                telemetryFactory.Send(telemetryEvent, userAliasWithDomainName);
            }
        }

        public static void SendQuickSearchOnChangeRequestTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                        string searchType,
                                                                        string searchText,
                                                                        string userAliasWithDomain,
                                                                        int resultSetCount,
                                                                        int? pageIndex = null,
                                                                        int? dataCountInPage = null)
        {
            SendQuickSearchTelemetryEventInternal(telemetryFactory,
                                                  TelemetryEventIdConstants.SearchChangeRequestEventId,
                                                  searchType,
                                                  searchText,
                                                  userAliasWithDomain,
                                                  resultSetCount,
                                                  pageIndex,
                                                  dataCountInPage);
        }

        public static void SendQuickSearchOnComponentRootTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                        string searchType,
                                                                        string searchText,
                                                                        string userAliasWithDomain,
                                                                        int resultSetCount,
                                                                        int? pageIndex = null,
                                                                        int? dataCountInPage = null)
        {
            SendQuickSearchTelemetryEventInternal(telemetryFactory,
                                                  TelemetryEventIdConstants.SearchComponentRootEventId,
                                                  searchType,
                                                  searchText,
                                                  userAliasWithDomain,
                                                  resultSetCount,
                                                  pageIndex,
                                                  dataCountInPage);
        }

        public static void SendQuickSearchOnComponentVersionTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                          string searchType,
                                                                          string searchText,
                                                                          string userAliasWithDomain,
                                                                          int resultSetCount,
                                                                          int? pageIndex = null,
                                                                          int? dataCountInPage = null)
        {
            SendQuickSearchTelemetryEventInternal(telemetryFactory,
                                                  TelemetryEventIdConstants.SearchComponentVersionEventId,
                                                  searchType,
                                                  searchText,
                                                  userAliasWithDomain,
                                                  resultSetCount,
                                                  pageIndex,
                                                  dataCountInPage);
        }

        public static void SendQuickSearchOnFeatureTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                  string searchType,
                                                                  string searchText,
                                                                  string userAliasWithDomain,
                                                                  int resultSetCount,
                                                                  int? pageIndex = null,
                                                                  int? dataCountInPage = null)
        {
            SendQuickSearchTelemetryEventInternal(telemetryFactory,
                                                  TelemetryEventIdConstants.SearchFeatureEventId,
                                                  searchType,
                                                  searchText,
                                                  userAliasWithDomain,
                                                  resultSetCount,
                                                  pageIndex,
                                                  dataCountInPage);
        }

        public static void SendQuickSearchOnProductTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                  string searchType,
                                                                  string searchText,
                                                                  string userAliasWithDomain,
                                                                  int resultSetCount,
                                                                  int? pageIndex = null,
                                                                  int? dataCountInPage = null)
        {
            SendQuickSearchTelemetryEventInternal(telemetryFactory,
                                                  TelemetryEventIdConstants.SearchProductEventId,
                                                  searchType,
                                                  searchText,
                                                  userAliasWithDomain,
                                                  resultSetCount,
                                                  pageIndex,
                                                  dataCountInPage);
        }

        public static void SendQuickSearchOnSuddenImpactTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                       string searchType,
                                                                       string searchText,
                                                                       string userAliasWithDomain)

        {
            SendQuickSearchTelemetryEventInternal(telemetryFactory,
                                                  TelemetryEventIdConstants.SearchSuddenImpactEventId,
                                                  searchType,
                                                  searchText,
                                                  userAliasWithDomain,
                                                  null,
                                                  null,
                                                  null);
        }

        public static void SendQuickSearchOnCommandTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                                  string searchType,
                                                                  string searchText,
                                                                  string userAliasWithDomain,
                                                                  int resultSetCount,
                                                                  int? pageIndex = null,
                                                                  int? dataCountInPage = null)
        {
            SendQuickSearchTelemetryEventInternal(telemetryFactory,
                                                  TelemetryEventIdConstants.SearchCommandEventId,
                                                  searchType,
                                                  searchText,
                                                  userAliasWithDomain,
                                                  resultSetCount,
                                                  pageIndex,
                                                  dataCountInPage);
        }

        public static void SendPartNumberTelemetryEvent(this ITelemetryFactory telemetryFactory,
                                                        string searchType,
                                                        string searchText,
                                                        string userAliasWithDomain,
                                                        int resultSetCount)
        {
            if (telemetryFactory.TryGet(TelemetryEventIdConstants.SearchPartNumberEventId, out ITelemetryEvent telemetryEvent))
            {
                telemetryEvent.SetProperty("SearchType", searchType);
                telemetryEvent.SetProperty("SearchText", searchText);
                telemetryEvent.SetProperty("ResultSetCount", resultSetCount);

                telemetryFactory.Send(telemetryEvent, userAliasWithDomain);
            }
        }

        private static void SendQuickSearchTelemetryEventInternal(ITelemetryFactory telemetryFactory,
                                                                  int telemetryEventId,
                                                                  string searchType,
                                                                  string searchText,
                                                                  string userAliasWithDomain,
                                                                  int? resultSetCount,
                                                                  int? pageIndex,
                                                                  int? dataCountInPage)
        {
            if (telemetryFactory.TryGet(telemetryEventId, out ITelemetryEvent telemetryEvent))
            {
                telemetryEvent.SetProperty("SearchType", searchType);
                telemetryEvent.SetProperty("SearchText", searchText);
                telemetryEvent.SetProperty("ResultSetCount", resultSetCount);

                if (pageIndex.HasValue)
                {
                    telemetryEvent.SetProperty("PageIndex", pageIndex.Value);
                }

                if (dataCountInPage.HasValue)
                {
                    telemetryEvent.SetProperty("DataCountInPage", dataCountInPage.Value);
                }

                telemetryFactory.Send(telemetryEvent, userAliasWithDomain);
            }
        }
    }
}

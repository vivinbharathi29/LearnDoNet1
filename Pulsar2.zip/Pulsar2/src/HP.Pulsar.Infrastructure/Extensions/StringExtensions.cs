﻿using System;
using System.Collections.Generic;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class StringExtensions
    {
        public static bool ContainsAll(this string input, string[] targets, bool canIgnoreCase = true)
        {
            if (input == null)
            {
                return false;
            }

            for (int i = 0; i < targets.Length; i++)
            {
                if (canIgnoreCase && input.IndexOf(targets[i], StringComparison.OrdinalIgnoreCase) == -1)
                {
                    return false;
                }

                if (!canIgnoreCase && input.IndexOf(targets[i]) == -1)
                {
                    return false;
                }
            }

            return true;
        }

        public static bool Contains(this IReadOnlyList<string> input, string target, bool canIgoreCase = true)
        {
            if (input == null || input.Count == 0)
            {
                return false;
            }

            for (int i = 0; i < input.Count; i++)
            {
                if ((canIgoreCase && string.Equals(input[i], target, StringComparison.OrdinalIgnoreCase))
                    || (!canIgoreCase && string.Equals(input[i], target)))
                {
                    return true;
                }
            }

            return false;
        }

        public static string RemoveEmptyEntries(this string input, char separator)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return string.Empty;
            }

            string[] splits = input.Split(new char[] { separator }, StringSplitOptions.RemoveEmptyEntries);

            if (splits.Length == 1)
            {
                return input;
            }

            List<string> results = new List<string>();

            for(int index = 0; index < splits.Length; index++)
            {
                if (!string.IsNullOrWhiteSpace(splits[index]))
                {
                    results.Add(splits[index].Trim());
                }
            }

            return string.Join(separator.ToString(), results);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class DictionaryExtensions
    {
        private const string _tileIdKeyName = "tileId";
        private const string _statusIdKeyName = "StatusId";
        private const string _typeIdKeyName = "TypeId";
        private const string _UserIdKeyName = "UserId";
        private const string _tileCountRefreshKeyName = "TileCountRefresh";
        private const string _productPageTabIdKeyName = "ProductPageTabId";
        private const string _productIdKeyName = "ProductId";
        private const string _ascmTabIdKeyName = "ascmTabId";
        private const string _stateMachineIdKeyName = "stateMachineId";
        private const string _wizardIdKeyName = "wizardId";
        private const string _cacheKeyName = "cacheKey";
        private const string _isNextStepKeyName = "isNextStep";
        private const string _postBodyKeyName = "PostBody";

        public static bool TryGetBooleanValue(this IDictionary<string, string> dictionary, string keyName, out bool value)
        {
            return TryGetBooleanInternal(dictionary, keyName, out value);
        }

        public static bool TryGetDateTimeValue(this IDictionary<string, string> dictionary, string keyName, out DateTime value)
        {
            return TryGetDateTimeInternal(dictionary, keyName, out value);
        }

        public static bool TryGetNullableDateTimeValue(this IDictionary<string, string> dictionary, string keyName, out DateTime? value)
        {
            return TryGetNullableDateTimeInternal(dictionary, keyName, out value);
        }

        public static bool TryGetIntValue(this IDictionary<string, string> dictionary, string keyName, out int value)
        {
            return TryGetIntegerInternal(dictionary, keyName, out value);
        }

        public static bool TryGetShortValue(this IDictionary<string, string> dictionary, string keyName, out short value)
        {
            return TryGetShortInternal(dictionary, keyName, out value);
        }

        public static bool TryGetStatusId(this IDictionary<string, string> dictionary, out int statusId)
        {
            return TryGetIntegerInternal(dictionary, _statusIdKeyName, out statusId);
        }

        public static bool TryGetStringValue(this IDictionary<string, string> dictionary, string keyName, out string value)
        {
            return TryGetStringValueInternal(dictionary, keyName, out value);
        }

        public static bool TryGetTileId(this Dictionary<string, string> dictionary, out int tileId)
        {
            return TryGetIntegerInternal(dictionary, _tileIdKeyName, out tileId);
        }

        public static bool TryGetTypeId(this IDictionary<string, string> dictionary, out int typeId)
        {
            return TryGetIntegerInternal(dictionary, _typeIdKeyName, out typeId);
        }

        public static bool TryGetTileRefresh(this IDictionary<string, string> dictionary, out bool value)
        {
            return TryGetBooleanInternal(dictionary, _tileCountRefreshKeyName, out value);
        }

        public static bool TryGetProductPageTabId(this IDictionary<string, string> dictionary, out int tabId)
        {
            return TryGetIntegerInternal(dictionary, _productPageTabIdKeyName, out tabId);
        }

        public static bool TryGetProductId(this IDictionary<string, string> dictionary, out int productId)
        {
            return TryGetIntegerInternal(dictionary, _productIdKeyName, out productId);
        }

        public static bool TryGetUserId(this IDictionary<string, string> dictionary, out int userId)
        {
            return TryGetIntegerInternal(dictionary, _UserIdKeyName, out userId);
        }

        private static bool TryGetBooleanInternal(this IDictionary<string, string> dictionary, string keyName, out bool value)
        {
            if (TryGetStringValueInternal(dictionary, keyName, out string idValue))
            {
                // 0 is false
                if (int.TryParse(idValue, out int intValue1) && intValue1 == 0)
                {
                    value = false;
                    return true;
                }

                // 1 or greater are true
                if (int.TryParse(idValue, out int intValue2) && intValue2 >= 1)
                {
                    value = true;
                    return true;
                }

                // anything else will be handled by bool TryParse()
                if (bool.TryParse(idValue, out bool boolValue))
                {
                    value = boolValue;
                    return true;
                }
            }

            value = false;
            return false;
        }

        private static bool TryGetDateTimeInternal(this IDictionary<string, string> dictionary, string keyName, out DateTime date)
        {
            date = default;

            if (TryGetStringValueInternal(dictionary, keyName, out string idValue)
                 && DateTime.TryParse(idValue, out DateTime value))
            {
                date = value;
                return true;
            }

            return false;
        }

        private static bool TryGetNullableDateTimeInternal(this IDictionary<string, string> dictionary, string keyName, out DateTime? date)
        {
            if (TryGetStringValueInternal(dictionary, keyName, out string idValue)
                 && DateTime.TryParse(idValue, out DateTime value))
            {
                date = value;
                return true;
            }

            date = null;
            return false;
        }

        private static bool TryGetShortInternal(this IDictionary<string, string> dictionary, string keyName, out short value)
        {
            if (TryGetStringValueInternal(dictionary, keyName, out string tempValue)
                && short.TryParse(tempValue, out short result))
            {
                value = result;
                return true;
            }

            value = -1;
            return false;
        }

        private static bool TryGetIntegerInternal(this IDictionary<string, string> dictionary, string keyName, out int value)
        {
            if (TryGetStringValueInternal(dictionary, keyName, out string tempValue)
                && int.TryParse(tempValue, out int result))
            {
                value = result;
                return true;
            }

            value = -1;
            return false;
        }

        private static bool TryGetStringValueInternal(IDictionary<string, string> dictionary, string keyName, out string value)
        {
            value = string.Empty;

            if (dictionary == null || dictionary.Count == 0)
            {
                return false;
            }

            KeyValuePair<string, string> pair = dictionary.FirstOrDefault(x => string.Equals(x.Key, keyName, StringComparison.OrdinalIgnoreCase));

            if (pair.Equals(default(KeyValuePair<string, string>)))
            {
                return false;
            }

            value = pair.Value;
            return true;
        }

        public static bool TryGetAscmTabId(this IDictionary<string, string> dictionary, out int tabId)
        {
            return TryGetIntegerInternal(dictionary, _ascmTabIdKeyName, out tabId);
        }

        public static bool TryGetStateMachineId(this IDictionary<string, string> dictionary, out int machineId)
        {
            return TryGetIntegerInternal(dictionary, _stateMachineIdKeyName, out machineId);
        }

        public static bool TryGetWizardId(this IDictionary<string, string> dictionary, out int wizardId)
        {
            return TryGetIntegerInternal(dictionary, _wizardIdKeyName, out wizardId);
        }

        public static bool TryGetCacheKey(this IDictionary<string, string> dictionary, out string cacheKey)
        {
            return TryGetStringValue(dictionary, _cacheKeyName, out cacheKey);
        }

        public static bool TryGetIsNextStep(this IDictionary<string, string> dictionary, out bool isNextStep)
        {
            return TryGetBooleanInternal(dictionary, _isNextStepKeyName, out isNextStep);
        }

        public static bool TryGetPostBody(this IDictionary<string, string> input, out string postBody)
        {
            return TryGetStringValue(input, _postBodyKeyName, out postBody);
        }
    }
}
﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.Infrastructure.Popup;

namespace HP.Pulsar.Infrastructure.Extensions
{
    public static class GridContentViewOperationExtension
    {
        public static string RenderGridRowOperation(this IGridContentModelOperation gridRowOperation)
        {
            if (gridRowOperation == null)
            {
                return string.Empty;
            }

            return RenderOperation(gridRowOperation);
        }

        public static string RenderTopLinkOperation(this IGridContentModelOperation topLinkOperation)
        {
            if (topLinkOperation == null)
            {
                return string.Empty;
            }

            return $"<button type=\"button\" class=\"btn Btn-dialog\" onClick=\"{RenderOperation(topLinkOperation, true)}\">{topLinkOperation.OperationName} </a>";
        }

        public static string RenderContextMenuOperations(this IReadOnlyList<IGridContentModelOperation> contextMenuoperations)
        {
            if (contextMenuoperations == null)
            {
                return string.Empty;
            }

            StringBuilder contextMenuOperationBuilder = new StringBuilder();

            contextMenuOperationBuilder.AppendLine("function(event, ui) ");
            contextMenuOperationBuilder.AppendLine("{");
            contextMenuOperationBuilder.AppendLine("switch(ui.cmd)");
            contextMenuOperationBuilder.AppendLine("{");

            foreach (IGridContentModelOperation contextMenuOperation in contextMenuoperations)
            {
                contextMenuOperationBuilder.Append("case ");
                contextMenuOperationBuilder.Append("'");
                contextMenuOperationBuilder.Append(contextMenuOperation.OperationName.Replace(" ", "").Replace(".", ""));
                contextMenuOperationBuilder.Append("' ");
                contextMenuOperationBuilder.AppendLine(":");
                contextMenuOperationBuilder.AppendLine(RenderOperation(contextMenuOperation));
                contextMenuOperationBuilder.AppendLine("break;");
            }

            contextMenuOperationBuilder.AppendLine("}");
            contextMenuOperationBuilder.AppendLine("}");

            return contextMenuOperationBuilder.ToString();
        }

        public static string RenderContextMenu(this IReadOnlyList<IGridContentModelOperation> contextMenuOperations)
        {
            if (contextMenuOperations == null)
            {
                return string.Empty;
            }

            StringBuilder contextMenuBuilder = new StringBuilder();

            contextMenuBuilder.AppendLine("[");
            contextMenuBuilder.Append(string.Join(", ", contextMenuOperations.Select(x => string.Concat("{", "title:", "'", x.OperationName, "'", ",", "cmd:", "'", x.OperationName.Replace(" ", "").Replace(".", ""), "'", ",", x.GetContextMenuItemDisabledAttribute(), "}"))));
            contextMenuBuilder.AppendLine();
            contextMenuBuilder.AppendLine("]");

            return contextMenuBuilder.ToString();
        }

        private static string GetContextMenuItemDisabledAttribute(this IGridContentModelOperation contextMenuOperation)
        {
            if (string.IsNullOrWhiteSpace(contextMenuOperation.OnRenderJavascriptionFunctionName))
            {
                return "disabled: false";
            }

            return string.Concat("disabled: function(event, ui) {return onContextMenuItemRender(", contextMenuOperation.OnRenderJavascriptionFunctionName, ");}");
        }

        private static string RenderOperation(IGridContentModelOperation operation, bool handleMultipleRows = false)
        {
            // Bind the customized javascript to the Grid's rowclick event
            if (operation.Type.Equals(GridContentModelOperationType.BindCustomJavascript) && !string.IsNullOrWhiteSpace(operation.JavascriptFunctionName))
            {
                return $"{operation.JavascriptFunctionName};";
            }

            // Open the URL in a new Browser Tab
            if (operation.Type.Equals(GridContentModelOperationType.ShowURLInNewBrowserTabWithNoQueryString))
            {
                return $"window.open('{operation.OperationUrlRelativePath}', '_blank');";
            }

            // Open the URL in a popup
            if (operation.Type.Equals(GridContentModelOperationType.ShowURLInPopupWithNoQueryString))
            {
                string popupHeight = operation.PopupSize.GetHeightPercentage().ToString();
                string popupWidth = operation.PopupSize.GetWidthPercentage().ToString();
                string operationUrlRelativePath = string.Empty;
                //Use ? to detect any Query string exists
                if (operation.OperationUrlRelativePath.Contains("?"))
                {
                    operationUrlRelativePath = operation.OperationUrlRelativePath + "&isGridRefreshRequired=" + operation.IsGridRefreshRequired;
                }
                else
                {
                    operationUrlRelativePath = operation.OperationUrlRelativePath + "?isGridRefreshRequired=" + operation.IsGridRefreshRequired;
                }
                return $"OpenPopUp('{operationUrlRelativePath}', '{operation.PopupTitle}', {popupHeight}, {popupWidth});";
            }

            StringBuilder operationBuilder = new StringBuilder();

            // Bind the javascript that reads data from the grid and pass the data to a popup url as query string
            if (operation.Type.Equals(GridContentModelOperationType.ShowURLInPopupWithQueryString))
            {
                if (handleMultipleRows)
                {
                    operationBuilder.Append("showPopupOnTopLinkClick");
                }
                else
                {
                    operationBuilder.Append("showPopupOnGridRowClick");
                }

                string popupHeight = operation.PopupSize.GetHeightPercentage().ToString();
                string popupWidth = operation.PopupSize.GetWidthPercentage().ToString();

                operationBuilder.Append("('#tileGrid','")
                                .Append(operation.OperationUrlRelativePath)
                                .Append("','")
                                .Append(operation.PopupTitle)
                                .Append("',")
                                .Append(popupHeight)
                                .Append(',')
                                .Append(popupWidth)
                                .Append(',');

                if (handleMultipleRows)
                {
                    operationBuilder.Append('\'')
                                    .Append(operation.GridColumnValueSeparator)
                                    .Append("',");
                }
                else
                {
                    operationBuilder.Append("selectedRowIndex,");
                }

                if (operation.GridColumnNames?.Count() > 0)
                {
                    string columnNames = string.Join(",", operation.GridColumnNames.Select(x => string.Concat("'", x, "'")));
                    operationBuilder.Append('[')
                                    .Append(columnNames)
                                    .Append("],")
                                    .Append(operation.IsSeparateQueryStringRequiredForGridColumns.ToString().ToLower())
                                    .Append(',')
                                    .Append(operation.IsGridRefreshRequired.ToString().ToLower())
                                    .Append(");");
                }
                else
                {
                    operationBuilder.Append('[')
                                    .Append(string.Empty)
                                    .Append("],")
                                    .Append(operation.IsSeparateQueryStringRequiredForGridColumns.ToString().ToLower())
                                    .Append(',')
                                    .Append(operation.IsGridRefreshRequired.ToString().ToLower())
                                    .Append(");");
                }

                return operationBuilder.ToString();
            }

            // Bind the javascript that reads data from the grid and pass the data to a url as query string. 
            // The Url is opened in a new Browser tab
            if (operation.Type.Equals(GridContentModelOperationType.ShowURLInNewBrowserTabWithQueryString) && operation.GridColumnNames?.Count > 0)
            {
                if (handleMultipleRows)
                {
                    operationBuilder.Append("showNewBrowserTabOnTopLinkClick");
                }
                else
                {
                    operationBuilder.Append("showNewBrowserTabOnGridRowClick");
                }

                operationBuilder.Append("('#tileGrid','")
                                .Append(operation.OperationUrlRelativePath)
                                .Append("',");

                if (handleMultipleRows)
                {
                    operationBuilder.Append('\'')
                                    .Append(operation.GridColumnValueSeparator)
                                    .Append("',");
                }
                else
                {
                    operationBuilder.Append("selectedRowIndex,");
                }

                string columnNames = string.Join(",", operation.GridColumnNames.Select(x => string.Concat("'", x, "'")));
                operationBuilder.Append('[')
                                .Append(columnNames)
                                .Append("], ")
                                .Append(operation.IsSeparateQueryStringRequiredForGridColumns.ToString().ToLower())
                                .Append(");");

                return operationBuilder.ToString();
            }

            // Bind the javascript that reads data from the grid and pass the data to a url as query string. 
            // The Url is opened in a new Window 
            if (operation.Type.Equals(GridContentModelOperationType.ShowURLInNewBrowserWindowWithQueryString) && operation.GridColumnNames?.Count > 0)
            {
                if (handleMultipleRows)
                {
                    operationBuilder.Append("showNewBrowserWindowOnTopLinkClick");
                }
                else
                {
                    operationBuilder.Append("showNewBrowserWindowOnGridRowClick");
                }

                operationBuilder.Append("('#tileGrid','")
                                .Append(operation.OperationUrlRelativePath)
                                .Append("',");

                if (handleMultipleRows)
                {
                    operationBuilder.Append('\'')
                                    .Append(operation.GridColumnValueSeparator)
                                    .Append("',");
                }
                else
                {
                    operationBuilder.Append("selectedRowIndex,");
                }

                string columnNames = string.Join(",", operation.GridColumnNames.Select(x => string.Concat("'", x, "'")));
                operationBuilder.Append('[').Append(columnNames).Append("],");

                if (handleMultipleRows)
                {
                    operationBuilder.Append(operation.IsSeparateQueryStringRequiredForGridColumns.ToString().ToLower()).Append(", ");
                }

                operationBuilder.Append(operation.PopupSize.GetWidthPercentage())
                                .Append(", ")
                                .Append(operation.PopupSize.GetHeightPercentage())
                                .Append("); ");

                return operationBuilder.ToString();
            }

            if (operation.Type.Equals(GridContentModelOperationType.PostJsonDataToURL) && operation.GridColumnNames?.Count > 0)
            {
                if (handleMultipleRows)
                {
                    operationBuilder.Append("postJsonDataOnTopLinkClick");
                }
                else
                {
                    operationBuilder.Append("postDataOnGridRowClick");
                }

                operationBuilder.Append("('#tileGrid','")
                                .Append(operation.OperationUrlRelativePath)
                                .Append("',");

                if (!handleMultipleRows)
                {
                    operationBuilder.Append("selectedRowIndex,");
                }

                string columnNames = string.Join(",", operation.GridColumnNames.Select(x => string.Concat("'", x, "'")));
                operationBuilder.Append('[')
                                .Append(columnNames)
                                .Append("],")
                                .Append(operation.IsGridRefreshRequired.ToString().ToLower())
                                .Append(",'")
                                .Append(operation.ConfirmationMessageBeforePost)
                                .Append("');");

                return operationBuilder.ToString();
            }

            if (operation.Type.Equals(GridContentModelOperationType.PostCsvDataToURL) && operation.GridColumnNames?.Count > 0 && handleMultipleRows)
            {
                operationBuilder.Append("postCsvDataOnTopLinkClick");
                operationBuilder.Append("('#tileGrid','")
                                .Append(operation.OperationUrlRelativePath)
                                .Append("',");

                string columnNames = string.Join(",", operation.GridColumnNames.Select(x => string.Concat("'", x, "'")));

                operationBuilder.Append('\'')
                                .Append(operation.GridColumnValueSeparator)
                                .Append("', [")
                                .Append(columnNames)
                                .Append("],")
                                .Append(operation.IsGridRefreshRequired.ToString().ToLower())
                                .Append(",'")
                                .Append(operation.ConfirmationMessageBeforePost)
                                .Append("');");

                return operationBuilder.ToString();
            }

            return string.Empty;
        }
    }
}
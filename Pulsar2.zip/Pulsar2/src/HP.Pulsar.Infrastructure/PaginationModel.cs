﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;

namespace HP.Pulsar.Infrastructure
{
    public class PaginationModel : IPaginationModel
    {
        public PaginationModel()
        {
            PageNo = 1;
            PageSize = 100;
            PageSizeOptions = new List<int> { 50, 100, 200, 400, 800 };
        }

        public IList<FilterModel> Filters { get; set; }

        public int PageNo { get; set; }

        public int PageSize { get; set; }

        public IReadOnlyList<int> PageSizeOptions { get; set; }

        public string SortBy { get; set; }

        public SortDirection SortDirection { get; set; }
    }
}

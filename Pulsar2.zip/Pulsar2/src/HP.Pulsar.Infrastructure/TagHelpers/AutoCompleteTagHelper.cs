﻿using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Repository.Models;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace HP.Pulsar.Infrastructure.TagHelpers
{
    [HtmlTargetElement("auto-complete")]
    public class AutoCompleteTagHelper : TagHelper
    {
        private const string IdAttributeName = "id";
        private const string DefaultBinding = "default";
        private const string SourceAttributeName = "items-source";
        private const string SelectCustomFunction = "select-function";
        private const string MinimumLengthAttributeName = "min-length";
        private readonly IUserInfoRepository _repository;
        private readonly ISimpleDataCache _dataCache;
        private readonly int _itemExpirationDuration = 30;

        [HtmlAttributeName(IdAttributeName)]
        public string Id { get; set; }

        [HtmlAttributeName(DefaultBinding)]
        public bool IsAllUsers { get; set; }

        [HtmlAttributeName(SourceAttributeName)]
        public IReadOnlyDictionary<int, string> ItemsSource { get; set; } = null;

        [HtmlAttributeName(MinimumLengthAttributeName)]
        public int MinimumLength { get; set; } = 0;

        [HtmlAttributeName(SelectCustomFunction)]
        public string CustomFunction { get; set; } = null;

        public AutoCompleteTagHelper(IUserInfoRepository repository, ISimpleDataCache dataCache)
        {
            _repository = repository;
            _dataCache = dataCache;
        }

        private async Task<Dictionary<int, string>> GetActiveUserInfos()
        {
            Dictionary<int, string> allUsers = new Dictionary<int, string>();

            if (!TryGetUserCache(out IReadOnlyList<IUserRootInfoModel> users))
            {
                users = await _repository.GetUsersRootInfoAsync(" ").ConfigureAwait(false);
                _dataCache.Set("Users", users, _itemExpirationDuration);
            }

            if (users == null || users.Count == 0)
            {
                return allUsers;
            }

            foreach (IUserRootInfoModel userInfo in users)
            {
                allUsers[userInfo.Id] = string.Concat($"{ userInfo.FirstName} { userInfo.LastName} ({ userInfo.Email})");
            }

            return allUsers;
        }

        public bool TryGetUserCache(out IReadOnlyList<IUserRootInfoModel> users)
        {
            bool isSuccess = false;
            users = null;

            if (_dataCache.TryGet("Users", out object userObject)
                && userObject is IReadOnlyList<IUserRootInfoModel> userObj)
            {
                users = userObj;
                isSuccess = true;
            }

            return isSuccess;
        }

        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "script";
            StringBuilder autoComplete = new StringBuilder();
            autoComplete.AppendLine("")
                        .AppendLine("$(function() { ")
                        .Append("$('#")
                        .Append(Id)
                        .Append("').autocomplete({")
                        .AppendLine("");

            if (IsAllUsers)
            {
                Dictionary<int, string> activeUsers = await GetActiveUserInfos().ConfigureAwait(false);
                GetAutoCompleteSource(autoComplete, activeUsers);
            }

            if (ItemsSource?.Count > 0)
            {
                GetAutoCompleteSource(autoComplete, ItemsSource);
            }

            if (CustomFunction?.Length > 0)
            {
                autoComplete.Append(", select: function (event, ui) {")
                            .Append(CustomFunction)
                            .Append("(ui.item.id,ui.item.label);}");
            }

            autoComplete.AppendFormat(", minLength: {0}", MinimumLength)
                        .AppendLine("});")
                        .AppendLine("});");

            output.Content.AppendHtml(autoComplete.ToString());
        }

        private static void GetAutoCompleteSource(StringBuilder autoComplete, IReadOnlyDictionary<int, string> activeUsers)
        {
            autoComplete.AppendLine("source: ")
                        .Append("[");

            List<string> users = new List<string>();

            foreach (KeyValuePair<int, string> user in activeUsers)
            {
                users.Add($"{{'id':'{user.Key}','label':'{user.Value.Replace('\'', ' ')}'}}");
            }

            autoComplete.Append(string.Join(",", users))
                        .Append("]");
        }
    }
}

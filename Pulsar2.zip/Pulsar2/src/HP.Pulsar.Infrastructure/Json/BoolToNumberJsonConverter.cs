﻿using System;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.Json
{
    public class BoolToNumberJsonConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(bool);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            return string.Equals(reader.Value.ToString(), "true", StringComparison.OrdinalIgnoreCase)
                   || string.Equals(reader.Value.ToString(), "yes", StringComparison.OrdinalIgnoreCase)
                   || string.Equals(reader.Value.ToString(), "y", StringComparison.OrdinalIgnoreCase)
                   || string.Equals(reader.Value.ToString(), "1");
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value is bool result)
            {
                writer.WriteValue(result ? "1" : "0");
                return;
            }

            // when value is not bool, let's write 0 as default value.
            writer.WriteValue("0");
        }
    }
}

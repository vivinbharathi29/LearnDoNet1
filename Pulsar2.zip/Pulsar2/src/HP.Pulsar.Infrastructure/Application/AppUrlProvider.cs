﻿using HP.Pulsar.CommonContracts.Infrastructure.Application;
using Microsoft.Extensions.Configuration;

namespace HP.Pulsar.Infrastructure.Application
{
    public class AppUrlProvider : IAppUrlProvider
    {
        //All paths should go to appsettings.json
        private const string _appUrlPath = "AppUrls:";
        private const string _addComonentRootUrlPathKey = _appUrlPath + "AddComponentRootUrlPath";
        private const string _addUserFavoritesUrlPathKey = _appUrlPath + "AddUserFavoritesUrlPath";
        private const string _cloneComponentVersionUrlPathKey = _appUrlPath + "CloneComponentVersionUrlPath";
        private const string _componentReleaseUrlPathKey = _appUrlPath + "ComponentReleaseUrlPath";
        private const string _createComponentVersionUrlPathKey = _appUrlPath + "CreateComponentVersionUrlPath";
        private const string _editComponentVersionUrlPathKey = _appUrlPath + "EditComponentVersionUrlPath";
        private const string _qucikSearchChangeRequestUrPathKey = _appUrlPath + "QucikSearchChangeRequestUrPath";
        private const string _quickSearchComponentRootUrlPathKey = _appUrlPath + "QuickSearchComponentRootUrlPath";
        private const string _quickSearchComponentVersionUrlPathKey = _appUrlPath + "QuickSearchComponentVersionUrlPath";
        private const string _quickSearchFeatureUrlPathKey = _appUrlPath + "QuickSearchFeatureUrlPath";
        private const string _quickSearchAMOFeatureUrlPathKey = _appUrlPath + "QuickSearchAMOFeatureUrlPath";
        private const string _quickSearchProductUrlPathKey = _appUrlPath + "QuickSearchProductUrlPath";
        private const string _removeUserFavoritesUrlPathKey = _appUrlPath + "RemoveUserFavoritesUrlPath";
        private const string _suddenImpactOnNebulaUrlPathkey = _appUrlPath + "SuddenImpactOnNebulaUrlPath";

        private readonly IConfiguration _configuration;

        public AppUrlProvider(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string NebulaUrl => _configuration["NebulaUrl"];

        public string GetComponentRootCreationUrlPath() => _configuration[_addComonentRootUrlPathKey];

        public string GetChangeRequestOnQuickSearchUrlPath(int changeRequestId) => string.Format(_configuration[_qucikSearchChangeRequestUrPathKey], changeRequestId);

        public string GetCloneComponentVersionPropertiesUrlPath() => _configuration[_cloneComponentVersionUrlPathKey];

        public string GetComponentReleaseUrlPathValue() => _configuration[_componentReleaseUrlPathKey];

        public string GetComponentRootOnQuickSearchUrlPath(int componentRootId) => string.Format(_configuration[_quickSearchComponentRootUrlPathKey], componentRootId);

        public string GetComponentVersionOnQuickSearchUrlPath(int componentVersionId) => string.Format(_configuration[_quickSearchComponentVersionUrlPathKey], componentVersionId);

        public string GetComponentVersionPropertyCreationUrlPathValue() => _configuration[_createComponentVersionUrlPathKey];

        public string GetComponentVersionPropertiesEditingUrlPathValue() => _configuration[_editComponentVersionUrlPathKey];

        public string GetFeatureOnQuickSearchUrlPath(int featureId) => string.Format(_configuration[_quickSearchFeatureUrlPathKey], featureId);

        public string GetAmoFeatureOnQuickSearchUrlPath(int featureId) => string.Format(_configuration[_quickSearchAMOFeatureUrlPathKey], featureId);

        public string GetSuddentImpactOnNebulaUrlPathValue() => string.Concat(NebulaUrl, _configuration[_suddenImpactOnNebulaUrlPathkey]);

        public string GetProductOnQuickSearchUrlPath(int productId) => string.Format(_configuration[_quickSearchProductUrlPathKey], productId);

        public string GetSuddenImpactOnNebualUrlPath(long observationId) => string.Format(GetSuddentImpactOnNebulaUrlPathValue(), observationId);

        public string GetUserFavoritesAddUrl() => _configuration[_addUserFavoritesUrlPathKey];

        public string GetUserFavoritesRemoveUrl() => _configuration[_removeUserFavoritesUrlPathKey];

        public string GetComponentVersionDetailsUrl(int componentVersionId) => GetComponentVersionOnQuickSearchUrlPath(componentVersionId);

        public string GetComponentRootUrlPathValue() => _configuration[_quickSearchComponentRootUrlPathKey];
    }
}
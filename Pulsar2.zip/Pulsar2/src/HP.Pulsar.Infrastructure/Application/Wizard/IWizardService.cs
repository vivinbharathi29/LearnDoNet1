﻿namespace HP.Pulsar.Infrastructure.Application.Wizard
{
    public interface IWizardService
    {
        IWizardStateMachine GetWizardStateMachine(int wizardId);
    }
}
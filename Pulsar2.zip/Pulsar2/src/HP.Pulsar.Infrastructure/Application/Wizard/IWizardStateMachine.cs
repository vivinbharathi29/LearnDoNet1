﻿namespace HP.Pulsar.Infrastructure.Application.Wizard
{
    public interface IWizardStateMachine
    {
        int Id { get; }

        bool TryGetNextWizard(int currentWizardId, string cacheKey, out IWizard nextWizard);

        bool TryGetPreviousWizard(int currentWizardId, string cacheKey, out IWizard previousWizard);

        bool TryGetCurrentWizard(int currentWizardId, string cacheKey, out IWizard currentWizard);
    }
}
﻿namespace HP.Pulsar.Infrastructure.Email
{
    public static class EmailTemplateIds
    {
        public static readonly int AccessoryStatus = 211;

        public static readonly int DcrWorkflowComplete = 215;

        public static readonly int QualStatusBridgeRelease = 212;

        public static readonly int QualStatusDeveloperAndHwPm = 213;

        public static readonly int QualStatusSupplyChain = 214;
    }
}

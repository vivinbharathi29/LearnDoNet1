﻿namespace HP.Pulsar.Infrastructure
{
    public static class ActionName
    {
        public static readonly string GetTileCount = "GetTileCount";

        public static readonly string GetTileData = "GetTileData";

        public static readonly string PostData = "PostData";

        public static readonly string ShowContent = "ShowContent";
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.Infrastructure.Extensions;

namespace HP.Pulsar.Infrastructure.Helpers
{
    public static class PaginationHelper
    {
        private const string _pageNumberKey = "page";
        private const string _pageSizeKey = "pageSize";
        private const string _sortKey = "sort";
        private const string _filterKey = "filter";

        public static IPaginationModel ToPagination(this IDictionary<string, string> input)
        {
            PaginationModel pagination = new PaginationModel();

            if (input == null || input.Count == 0)
            {
                // TODO : return default values may cause potential bugs 
                // TODO : e2e test from controller
                return pagination;
            }

            // get page number
            if (TryGetPageNo(input, out int pageNo))
            {
                pagination.PageNo = pageNo;
            }

            // get page size
            if (TryGetPageSize(input, out int pageSize))
            {
                pagination.PageSize = pageSize;
            }

            // get page size. To handle no pagination grids. To get all pages data.
            if (!TryGetPageSize(input, out int noPaginationPageSize))
            {
                pagination.PageSize = -1;
            }

            // get sort
            if (TryGetSortByAndDirection(input, out (string SortColumn, SortDirection SortDirection) result))
            {
                pagination.SortBy = result.SortColumn;
                pagination.SortDirection = result.SortDirection;
            }

            // get filter
            if (TryGetFilters(input, out IList<FilterModel> filters))
            {
                pagination.Filters = filters;
            }

            // IgGrid is passing page numbers from 0. To increment the pageNo value adding +1
            pagination.PageNo++;

            return pagination;
        }

        // TODO : internal is for unit test
        internal static bool TryGetPageNo(IDictionary<string, string> input, out int pageNo)
        {
            KeyValuePair<string, string> content = input.FirstOrDefault(x => x.Key.StartsWith(_pageNumberKey, StringComparison.OrdinalIgnoreCase));

            if (content.Equals(default(KeyValuePair<string, string>))
               || string.IsNullOrWhiteSpace(content.Value))
            {
                pageNo = 0;

                return false;
            }

            if (int.TryParse(content.Value, out int value))
            {
                pageNo = value;

                return true;
            }

            pageNo = 0;

            return false;
        }

        // TODO : internal is for unit test
        internal static bool TryGetPageSize(IDictionary<string, string> input, out int pageSize)
        {
            KeyValuePair<string, string> content = input.FirstOrDefault(x => x.Key.StartsWith(_pageSizeKey, StringComparison.OrdinalIgnoreCase));

            if (content.Equals(default(KeyValuePair<string, string>))
                || string.IsNullOrWhiteSpace(content.Value))
            {
                pageSize = 0;

                return false;
            }

            // set page size
            if (int.TryParse(content.Value, out int value))
            {
                pageSize = value;

                return true;
            }

            pageSize = 0;

            return false;
        }

        // TODO : internal is for unit test
        internal static bool TryGetSortByAndDirection(IDictionary<string, string> input, out (string, SortDirection) result)
        {
            KeyValuePair<string, string> content = input.FirstOrDefault(x => x.Key.StartsWith(_sortKey, StringComparison.OrdinalIgnoreCase));

            if (content.Equals(default(KeyValuePair<string, string>))
                || string.IsNullOrWhiteSpace(content.Value))
            {
                // default to asc if no sort in query string
                result = (string.Empty, SortDirection.Ascending);

                return false;
            }

            string[] keySplits = content.Key.Split('(', ')');

            if (keySplits.Length < 2)
            {
                // default to asc if no sort in query string
                result = (string.Empty, SortDirection.Ascending);

                return false;
            }

            string sortColumn = keySplits[1];

            if (string.Equals("asc", content.Value, StringComparison.OrdinalIgnoreCase))
            {
                result = (sortColumn, SortDirection.Ascending);

                return true;
            }

            result = (sortColumn, SortDirection.Descending);

            return true;
        }

        // TODO : internal is for unit test
        internal static bool TryGetFilters(IDictionary<string, string> input, out IList<FilterModel> filters)
        {
            IEnumerable<KeyValuePair<string, string>> filterList = input.Where(x => x.Key.StartsWith(_filterKey, StringComparison.OrdinalIgnoreCase));

            if (filterList?.Any() != true)
            {
                filters = null;

                return false;
            }

            List<FilterModel> resultList = new List<FilterModel>();

            foreach (KeyValuePair<string, string> item in filterList)
            {
                string[] keySplits = item.Key.Split('(', ')');
                string[] valueSplits = item.Value.Split('(', ')');

                if (keySplits.Length < 2 || valueSplits.Length < 2)
                {
                    continue;
                }

                FilterModel filter = new FilterModel
                {
                    ColumnName = keySplits[1],
                    ColumnType = GetFilterColumnType(valueSplits[1]),
                    Value = valueSplits[1]
                };

                // get filter operator
                if (Enum.TryParse(valueSplits[0], true, out FilterOperator result))
                {
                    filter.Operator = result;
                }
                else if (TryGetExtraFilterTextAndOperator(valueSplits.ToList(), out (string FilterText, FilterOperator FilterOperator) textOpResult))
                {
                    // get extra filterText and operator
                    filter.Value = textOpResult.FilterText;
                    filter.Operator = textOpResult.FilterOperator;
                }
                else
                {
                    // default to EqualTo
                    filter.Operator = FilterOperator.Equal;
                }

                resultList.Add(filter);
            }

            filters = resultList;

            return true;
        }

        internal static FilterColumnType GetFilterColumnType(string inputValue)
        {
            if (DateTime.TryParse(inputValue, out _))
            {
                return FilterColumnType.Date;
            }

            if (long.TryParse(inputValue, out _) || double.TryParse(inputValue, out _))
            {
                return FilterColumnType.Number;
            }

            if (bool.TryParse(inputValue, out _))
            {
                return FilterColumnType.Boolean;
            }

            // default to string
            return FilterColumnType.String;
        }

        // TODO : internal is for unit test
        internal static bool TryGetExtraFilterTextAndOperator(IReadOnlyList<string> values, out (string FilterText, FilterOperator FilterOperator) result)
        {
            // default case
            result.FilterText = string.Empty;
            result.FilterOperator = FilterOperator.Equal;

            if (values == null || values.Count == 0)
            {
                return false;
            }

            string value = values[0];

            if (string.Equals(value, "on", StringComparison.OrdinalIgnoreCase)
                && long.TryParse(value, out long onResult))
            {
                result.FilterText = DateTimeOffset.FromUnixTimeMilliseconds(onResult).AddDays(1).UtcDateTime.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Equal;
                return true;
            }
            else if (string.Equals(value, "notOn", StringComparison.OrdinalIgnoreCase)
                     && long.TryParse(value, out long notOnResult))
            {
                result.FilterText = DateTimeOffset.FromUnixTimeMilliseconds(notOnResult).AddDays(1).UtcDateTime.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.NotEqual;
                return true;
            }
            else if (string.Equals(value, "after", StringComparison.OrdinalIgnoreCase)
                     && long.TryParse(value, out long afterResult))
            {
                result.FilterText = DateTimeOffset.FromUnixTimeMilliseconds(afterResult).AddDays(1).UtcDateTime.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.GreaterThan;
                return true;
            }
            else if (string.Equals(value, "before", StringComparison.OrdinalIgnoreCase)
                     && long.TryParse(value, out long beforeResult))
            {
                result.FilterText = DateTimeOffset.FromUnixTimeMilliseconds(beforeResult).AddDays(1).UtcDateTime.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.LessThan;
                return true;
            }
            else if (string.Equals(value, "today", StringComparison.OrdinalIgnoreCase))
            {
                result.FilterText = DateTime.Now.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Equal;
                return true;
            }
            else if (string.Equals(value, "yesterday", StringComparison.OrdinalIgnoreCase))
            {
                result.FilterText = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Equal;
                return true;
            }
            else if (string.Equals(value, "thisMonth", StringComparison.OrdinalIgnoreCase))
            {
                DateTime startDate = DateTime.Now.GetFirstDateOfMonth();
                DateTime endDate = DateTime.Now.GetLastDateOfMonth();
                result.FilterText = startDate.ToString("yyyy-MM-dd") + "' AND '" + endDate.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Between;
                return true;
            }
            else if (string.Equals(value, "lastMonth", StringComparison.OrdinalIgnoreCase))
            {
                DateTime startDate = DateTime.Now.AddMonths(-1).GetFirstDateOfMonth();
                DateTime endDate = DateTime.Now.AddMonths(-1).GetLastDateOfMonth();
                result.FilterText = startDate.ToString("yyyy-MM-dd") + "' AND '" + endDate.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Between;
                return true;
            }
            else if (string.Equals(value, "nextMonth", StringComparison.OrdinalIgnoreCase))
            {
                DateTime startDate = DateTime.Now.AddMonths(1).GetFirstDateOfMonth();
                DateTime endDate = DateTime.Now.AddMonths(1).GetLastDateOfMonth();
                result.FilterText = startDate.ToString("yyyy-MM-dd") + "' AND '" + endDate.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Between;
                return true;
            }
            else if (string.Equals(value, "nextMonth", StringComparison.OrdinalIgnoreCase))
            {
                DateTime startDate = DateTime.Now.AddMonths(1).GetFirstDateOfMonth();
                DateTime endDate = DateTime.Now.AddMonths(1).GetLastDateOfMonth();
                result.FilterText = startDate.ToString("yyyy-MM-dd") + "' AND '" + endDate.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Between;
                return true;
            }
            else if (string.Equals(value, "thisYear", StringComparison.OrdinalIgnoreCase))
            {
                DateTime startDate = DateTime.Now.GetFirstDateOfCurrentYear();
                DateTime endDate = DateTime.Now.GetLastDateOfMonth();
                result.FilterText = startDate.ToString("yyyy-MM-dd") + "' AND '" + endDate.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Between;
                return true;
            }
            else if (string.Equals(value, "lastYear", StringComparison.OrdinalIgnoreCase))
            {
                DateTime startDate = DateTime.Now.GetFirstDateOfLastYear();
                DateTime endDate = DateTime.Now.GetLastDateOfLastYear();
                result.FilterText = startDate.ToString("yyyy-MM-dd") + "' AND '" + endDate.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Between;
                return true;
            }
            else if (string.Equals(value, "nextYear", StringComparison.OrdinalIgnoreCase))
            {
                DateTime startDate = DateTime.Now.GetFirstDateOfNextYear();
                DateTime endDate = DateTime.Now.GetLastDateOfNextYear();
                result.FilterText = startDate.ToString("yyyy-MM-dd") + "' AND '" + endDate.ToString("yyyy-MM-dd");
                result.FilterOperator = FilterOperator.Between;
                return true;
            }
            else if (string.Equals(value, "doesNotEqual", StringComparison.OrdinalIgnoreCase) && values.Count >= 2)
            {
                result.FilterText = values[1];
                result.FilterOperator = FilterOperator.NotEqual;
                return true;
            }
            else if (string.Equals(value, "doesNotContain", StringComparison.OrdinalIgnoreCase) && values.Count >= 2)
            {
                result.FilterText = values[1];
                result.FilterOperator = FilterOperator.NotContains;
                return true;
            }

            return false;
        }

        public static IList<FilterModel> ConvertEnumToFilter<T>(IList<FilterModel> filters, string columnName, bool isToString = true) where T : Enum
        {
            List<FilterModel> tileFilter = new List<FilterModel>();

            if (filters == null)
            {
                return new List<FilterModel>();
            }

            foreach (FilterModel filterModel in filters)
            {
                bool isEnumFound = false;
                List<string> filterVlaues = new List<string>();
                filterModel.ColumnName = filterModel.ColumnName.Replace(":string", string.Empty);
                filterModel.ColumnName = filterModel.ColumnName.Replace(":number", string.Empty);
                filterModel.ColumnName = filterModel.ColumnName.Replace(":date", string.Empty);

                if (string.Equals(filterModel.ColumnName, columnName, StringComparison.OrdinalIgnoreCase))
                {
                    foreach (T item in Enum.GetValues(typeof(T)))
                    {
                        if (item.ToString().IndexOf(filterModel.Value, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            Enum value = Enum.Parse(typeof(T), item.ToString(), true) as Enum;
                            filterVlaues.Add(isToString ? value.ToString() : ((int)(object)value).ToString());
                            isEnumFound = true;
                        }
                    }

                    if (filterVlaues.Count > 0)
                    {
                        FilterModel newModel = new FilterModel();
                        newModel.ColumnName = filterModel.ColumnName;
                        newModel.ColumnType = isToString ? FilterColumnType.String : newModel.ColumnType = FilterColumnType.Number;
                        newModel.Value = string.Join(",", filterVlaues);
                        newModel.Operator = FilterOperator.IN;
                        tileFilter.Add(newModel);
                    }
                }

                if (!isEnumFound)
                {
                    tileFilter.Add(filterModel);
                }
            }

            return tileFilter;
        }

        public static string ToSqlOrderBy(this IPaginationModel pagination)
        {
            if (pagination == null || string.IsNullOrWhiteSpace(pagination.SortBy))
            {
                return string.Empty;
            }

            StringBuilder orderByBuilder = new StringBuilder();

            if (pagination.SortDirection == SortDirection.Ascending)
            {
                orderByBuilder.Append(pagination.SortBy).Append(" ASC");
            }
            else if (pagination.SortDirection == SortDirection.Descending)
            {
                orderByBuilder.Append(pagination.SortBy).Append(" DESC");
            }

            orderByBuilder.Replace(":string", string.Empty);
            orderByBuilder.Replace(":number", string.Empty);
            orderByBuilder.Replace(":date", string.Empty);

            return orderByBuilder.ToString();
        }

        public static string ToSqlWhere(this IList<FilterModel> filters)
        {
            if (filters == null || filters.Count == 0)
            {
                return string.Empty;
            }

            List<string> whereClauseList = new List<string>();

            foreach (FilterModel item in filters)
            {
                if (item.Operator == FilterOperator.Null
                    || item.Operator == FilterOperator.NotNull
                    || item.Operator == FilterOperator.Empty
                    || item.Operator == FilterOperator.NotEmpty)
                {
                    whereClauseList.Add($"{item.ColumnName} {FilterOperatorSQLOperatorMapping[item.Operator]}");
                }
                else
                {
                    whereClauseList.Add($"{item.ColumnName} {FilterOperatorSQLOperatorMapping[item.Operator]} {GetWhereClauseItemValue(item)}");
                }
            }

            StringBuilder whereClauseBuilder = new StringBuilder();

            if (whereClauseList.Count > 0)
            {
                whereClauseBuilder.Append(string.Join(" AND ", whereClauseList))
                                  .Replace(":string", string.Empty)
                                  .Replace(":number", string.Empty)
                                  .Replace(":date", string.Empty);
            }

            return whereClauseBuilder.ToString();
        }

        private static IDictionary<FilterOperator, string> _filterOperatorSQLOperatorMapping;

        private static IDictionary<FilterOperator, string> FilterOperatorSQLOperatorMapping => _filterOperatorSQLOperatorMapping ?? (_filterOperatorSQLOperatorMapping = new Dictionary<FilterOperator, string>()
                                                                                                                                    {
                                                                                                                                        { FilterOperator.Equal, " = " },
                                                                                                                                        { FilterOperator.NotEqual, " <> " },
                                                                                                                                        { FilterOperator.GreaterThan, " > " },
                                                                                                                                        { FilterOperator.LessThan, " < " },
                                                                                                                                        { FilterOperator.GreaterThanOrEqual, " >= " },
                                                                                                                                        { FilterOperator.LessThanOrEqual, " <= " },
                                                                                                                                        { FilterOperator.Contains, " LIKE " },
                                                                                                                                        { FilterOperator.NotContains, " NOT LIKE " },
                                                                                                                                        { FilterOperator.StartsWith, " LIKE " },
                                                                                                                                        { FilterOperator.EndsWith, " LIKE " },
                                                                                                                                        { FilterOperator.Null," IS NULL  "},
                                                                                                                                        { FilterOperator.NotNull," IS NOT NULL  "},
                                                                                                                                        { FilterOperator.Between, " BETWEEN " },
                                                                                                                                        { FilterOperator.Empty, " = ' ' " },
                                                                                                                                        { FilterOperator.NotEmpty, " <> ' ' " },
                                                                                                                                        { FilterOperator.IN, " IN " }
                                                                                                                                    });

        private static string GetWhereClauseItemValue(FilterModel filter)
        {
            if (filter == null)
            {
                return string.Empty;
            }

            StringBuilder itemValueBuilder = new StringBuilder();

            if (filter.ColumnType == FilterColumnType.String || filter.ColumnType == FilterColumnType.Date)
            {
                itemValueBuilder.Append("'")
                                .Append(HttpUtility.UrlDecode(filter.Value))
                                .Append("'");
            }
            else if (filter.ColumnType == FilterColumnType.Boolean)
            {
                itemValueBuilder.Append(bool.TryParse(HttpUtility.UrlDecode(filter.Value), out _) ? "1" : "0");
            }
            else
            {
                itemValueBuilder.Append(HttpUtility.UrlDecode(filter.Value));
            }

            switch (filter.Operator)
            {
                case FilterOperator.StartsWith:
                    itemValueBuilder.Append("%")
                                    .Replace("'%", "%'")
                                    .Insert(0, "'")
                                    .Append("'");
                    break;
                case FilterOperator.EndsWith:
                    itemValueBuilder.Insert(0, "%")
                                    .Replace("%'", "'%")
                                    .Insert(0, "'")
                                    .Append("'");
                    break;
                case FilterOperator.Contains:
                case FilterOperator.NotContains:
                    itemValueBuilder.Insert(0, "%")
                                    .Append("%")
                                    .Replace("'", "")
                                    .Insert(0, "'");
                    int lastIndex = itemValueBuilder.LastIndexOf('%');

                    if (lastIndex >= 0)
                    {
                        itemValueBuilder.Insert(lastIndex + 1, "'");
                    }
                    break;
                case FilterOperator.Equal:
                case FilterOperator.NotEqual:
                    itemValueBuilder.Insert(0, "'").Append("'");
                    break;
                case FilterOperator.IN:
                    itemValueBuilder.Append(")").Insert(0, "(");
                    break;
            }

            return itemValueBuilder.ToString();
        }

        public static IList<FilterModel> ConvertJavascriptUTCDateTimeTicksToSQLServerDate(IList<FilterModel> filters, string sqlColumnName)
        {
            if (filters == null)
            {
                return null;
            }

            FilterModel filterModel = filters.FirstOrDefault(x => x.ColumnName.Replace(":date", string.Empty).Equals(sqlColumnName, StringComparison.OrdinalIgnoreCase));

            if (filterModel != null && long.TryParse(filterModel.Value, out long result))
            {
                // Convert the value in javascript utc ticks to a long type
                // Javascript tick starts from 1/1/1970 whereas C# tick starts from 1/1/0001
                // 1000 ticks = 1 second
                // Convert javascript ticks to C# tick
                // ToLocalTime() is called to convert UTC Datetime to local/ Server time zone
                DateTime unixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, 0).AddSeconds(result / 1000);
                // Convert the date to yyyy-MM-dd format
                filterModel.Value = unixEpoch.ToString("yyyy-MM-dd");
                // Apply SQL Server CONVERT function to the column name to compare in yyyy-MM-dd format at the SQL Server end
                filterModel.ColumnName = $"CONVERT(VARCHAR(10), {sqlColumnName}, 121)";
            }

            return filters;
        }

        public static IList<FilterModel> ConvertJavascriptUTCDateTimeTicksToSQLServerDate(IList<FilterModel> filters, IReadOnlyList<string> sqlColumnNames)
        {
            foreach (string name in sqlColumnNames)
            {
                filters = ConvertJavascriptUTCDateTimeTicksToSQLServerDate(filters, name);
            }

            return filters;
        }
    }
}

﻿namespace HP.Pulsar.Infrastructure.Helpers
{
    public static class QualificationStatusHelper
    {
        public static string GetQCompleteText(bool isPulsarProduct)
        {
            if (!isPulsarProduct)
            {
                return "QComplete/Risk Release";
            }

            return "Risk Release";
        }
    }
}

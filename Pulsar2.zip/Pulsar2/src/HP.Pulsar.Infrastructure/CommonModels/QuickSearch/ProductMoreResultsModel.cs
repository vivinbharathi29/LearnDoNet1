﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Infrastructure.CommonModels.QuickSearch
{
    public class ProductMoreResultsModel : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product ID")]
        public int ProductId { get; set; }

        [IgGridColumnAttributes()]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product Family")]
        public string ProductFamily { get; set; }

        [IgGridColumnAttributes(HeaderText = "Release(s)")]
        public string Releases { get; set; }

        [IgGridColumnAttributes(HeaderText = "Status")]
        public string Status { get; set; }

        [IgGridColumnAttributes()]
        public string ODM { get; set; }

        [IgGridColumnAttributes(HeaderText = "Dev Center")]
        public string DevCenter { get; set; }

        [IgGridColumnAttributes()]
        public string Requirements { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product Group")]
        public string ProductGroup { get; set; }

        [IgGridColumnAttributes(HeaderText = "System Board ID")]
        public string SystemBoardId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product Series")]
        public string ProductSeries { get; set; }

        [IgGridColumnAttributes(HeaderText = "Open In New Tab")]
        public string Url { get; set; }
    }
}

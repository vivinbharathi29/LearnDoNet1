﻿namespace HP.Pulsar.Infrastructure.CommonModels.QuickSearch
{
    public enum QuickSearchType
    {
        ChangeRequest = 0,
        Command,
        ComponentRoot,
        ComponentVersion,
        Feature,
        Product,
        UserFavorite,
        SuddenImpact
    }
}

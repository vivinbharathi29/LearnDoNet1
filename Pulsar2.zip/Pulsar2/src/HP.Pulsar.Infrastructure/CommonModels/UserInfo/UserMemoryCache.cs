﻿using System;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.Constants;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;

namespace HP.Pulsar.Infrastructure.CommonModels.UserInfo
{
    // This class lives in DI. Singleton type.
    public class UserMemoryCache : IUserMemoryCache
    {
        private readonly MemoryCache _cache;
        private const string _scanFrequenceKeyName = "UserMemoryCacheExpirationScanFrequency";
        private const string _itemExpirationKeyName = "UserMemoryCacheItemExpiration";
        private const string _cacheSizeKeyName = "UserMemoryCacheSize";
        private readonly TimeSpan _cacheItemExpiration;

        public UserMemoryCache(IConfiguration configuration)
        {
            int scanFrequency = configuration.GetValue(_scanFrequenceKeyName, CacheConstants.DefaultScanFrequence);
            int itemExpirationDuration = configuration.GetValue(_itemExpirationKeyName, CacheConstants.DefaultExpirationDuration);

#if DEBUG
            // Let PuslarUser object expire in 1 minute in debug build
            itemExpirationDuration = 1;
#endif

            _cacheItemExpiration = TimeSpan.FromMinutes(itemExpirationDuration);

            MemoryCacheOptions options = new MemoryCacheOptions
            {
                ExpirationScanFrequency = TimeSpan.FromMinutes(scanFrequency),
                SizeLimit = configuration.GetValue(_cacheSizeKeyName, CacheConstants.DefaultSize)
            };

            _cache = new MemoryCache(options);
        }

        public void SetUser(IPulsarUser pulsarUser, string userEmail = "")
        {
            if (pulsarUser == null)
            {
                return;
            }

            // each user object will be cached in memory at least for 30 minute by default. (1 minute in Debug build)
            // when a user object is fetched, its expiration time will be reset and restart from now.
            // one user has only one user object in memory cache
            MemoryCacheEntryOptions options = new MemoryCacheEntryOptions();
            options.SetSlidingExpiration(_cacheItemExpiration);
            options.SetSize(1);
            options.RegisterPostEvictionCallback(PostEvictionCallback);

            if (string.IsNullOrWhiteSpace(userEmail))
            {
                _cache.Set(pulsarUser.UserAliasWithDomainName, pulsarUser, options);
            }
            else
            {
                _cache.Set(userEmail, pulsarUser, options);
            }
        }

        public bool TryGetUser(string userAliasOrEmail, out IPulsarUser pulsarUser)
        {
            bool isSuccess = false;
            pulsarUser = null;

            // Memory cache is string case sensitive. 
            // We don't change character casing for user alias and domain from Windows Auth.
            if (_cache.TryGetValue(userAliasOrEmail, out object userObject)
                && userObject is IPulsarUser pulsarUserObj)
            {
                pulsarUser = pulsarUserObj;
                isSuccess = true;
            }

            return isSuccess;
        }

        private void PostEvictionCallback(object key, object value, EvictionReason reason, object state)
        {
            if (value is IPulsarUser pulsarUser)
            {
                pulsarUser.SaveRecentSearchHistoryToCacheAsync();
                pulsarUser.SaveRecentSearchItemsToCacheAsync();
            }
        }
    }
}
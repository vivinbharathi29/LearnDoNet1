﻿using HP.Pulsar.CommonContracts.TodayPage.Favorites;

namespace HP.Pulsar.Infrastructure.CommonModels.UserInfo
{
    public static class UserFavoriteTypeConverter
    {
        public static object ToUserFavorite(object input)
        {
            if (input != null && int.TryParse(input.ToString(), out int value))
            {
                if (value == 0)
                {
                    return UserFavoriteType.Product;
                }
                else if (value == 1)
                {
                    return UserFavoriteType.ComponentRoot;
                }
                else if (value == 2)
                {
                    return UserFavoriteType.Service;
                }
                else if (value == 3)
                {
                    return UserFavoriteType.Tile;
                }
            }

            return UserFavoriteType.None;
        }
    }
}

﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;
using HP.Pulsar.CommonContracts.TodayPage.Favorites;
using HP.Pulsar.Infrastructure.Abstractions.Application;
using HP.Pulsar.Infrastructure.Abstractions.Tiles;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.CommonModels.Application;
using HP.Pulsar.Infrastructure.Telemetry;

namespace HP.Pulsar.Infrastructure.CommonModels.UserInfo
{
    internal class UserMenu
    {
        private readonly IPulsarUser _user;
        private readonly IAppMenuProvider _appMenuProvider;
        private readonly IReadOnlyDictionary<int, ITile> _allTilesInDict;
        private readonly ITelemetryFactory _telemetryFactory;

        // searching root menu item, we allow 4 levels at most.
        private const int _levelSafetyFactor = 4;

        public UserMenu(IPulsarUser user,
                        IAppMenuProvider appMenuProvider,
                        IReadOnlyDictionary<int, ITile> allTiles,
                        ITelemetryFactory telemetryFactory)
        {
            _user = user;
            _appMenuProvider = appMenuProvider;
            _telemetryFactory = telemetryFactory;
            _allTilesInDict = allTiles;
        }

        public IReadOnlyList<UIMenuItem> GetTileMenuItems(IReadOnlyList<UserFavorite> userFavorites)
        {
            List<UIMenuItem> uiMenuItems = new List<UIMenuItem>();

            // Get tile items which are associated with current user
            foreach (TileMenuItem item in _appMenuProvider.GetTileMenuItems(_user))
            {
                if (_allTilesInDict.TryGetValue(item.TileId, out ITile tile))
                {
                    UIMenuItem uiItem = new UIMenuItem
                    {
                        DisplayName = item.DisplayName,
                        GroupName = item.GroupName,
                        IsUserFavorite = userFavorites?.Any(x => x.ItemId == item.TileId && x.FavoriteType == UserFavoriteType.Tile) ?? false,
                        ItemId = item.TileId,
                        Link = tile.ShowContentUrlRelativePath,
                        MenuItemDisplayMode = MenuItemDisplayMode.None,
                        Sequence = item.Sequence
                    };

                    uiMenuItems.Add(uiItem);
                }
            }

            return uiMenuItems;
        }

        public async Task<IReadOnlyList<UIMenuItem>> GetServiceMenuItemsAsync(IEnumerable<UserFavorite> userFavorites)
        {
            IReadOnlyList<GeneralMenuItem> menuItemInAllServices = await _appMenuProvider.GetServiceMenuItemsAsync().ConfigureAwait(false);
            IEnumerable<GeneralMenuItem> menuItems = _user.IsHPEmployee
                                                     ? menuItemInAllServices
                                                     : menuItemInAllServices.Where(x => !x.IsOnlyForHPEmployee);

            Dictionary<int, int> menuChildIdParentIdMap = new Dictionary<int, int>();
            Dictionary<int, GeneralMenuItem> menuIdItemMap = new Dictionary<int, GeneralMenuItem>();
            HashSet<int> leafItems = new HashSet<int>();

            foreach (GeneralMenuItem item in menuItems)
            {
                menuChildIdParentIdMap[item.Id] = item.ParentId ?? -1;
                menuIdItemMap[item.Id] = item;
            }

            // Find the menu items which are leaf nodes - the ones which dont have any children
            IEnumerable<GeneralMenuItem> leafMenuItems = GetLeafMenuItems(menuItems);
            List<UIMenuItem> uiMenuItems = new List<UIMenuItem>();

            foreach (GeneralMenuItem item in leafMenuItems)
            {
                if (TryGetRootMenuItemName(item.Id, menuChildIdParentIdMap, menuIdItemMap, out string rootName))
                {
                    UIMenuItem uiItem = new UIMenuItem();
                    uiItem.DisplayName = item.DisplayName;
                    uiItem.GroupName = rootName;
                    uiItem.IsUserFavorite = userFavorites?.Any(x => x.ItemId == item.Id) == true;
                    uiItem.ItemId = item.Id;
                    uiItem.Link = item.Link;
                    uiItem.MenuItemDisplayMode = item.DisplayMode;
                    uiItem.Sequence = item.Sequence;
                    uiItem.SubgroupName = GetParentMenuItemName(item.Id, menuChildIdParentIdMap, menuIdItemMap);

                    uiMenuItems.Add(uiItem);
                }
            }

            return uiMenuItems;
        }

        internal bool TryGetRootMenuItemName(int menuItemId, Dictionary<int, int> menuChildIdParentIdMap, Dictionary<int, GeneralMenuItem> menuIdItemMap, out string rootMenuItemName)
        {
            int id = menuItemId;
            int parentId = 0;
            int level = 0;

            while (parentId >= 0)
            {
                level++;

                if (menuChildIdParentIdMap.TryGetValue(id, out parentId) && parentId >= 0)
                {
                    id = parentId;
                }

                if (level > _levelSafetyFactor)
                {
                    SendTelemetryEvent(menuItemId);
                    rootMenuItemName = string.Empty;
                    return false;
                }
            }

            rootMenuItemName = menuIdItemMap[id].DisplayName;
            return true;
        }

        private string GetParentMenuItemName(int menuId, Dictionary<int, int> menuChildIdParentIdMap, Dictionary<int, GeneralMenuItem> menuIdItemMap)
        {
            if (menuChildIdParentIdMap.TryGetValue(menuId, out int parentId)
                && parentId >= 0
                && menuIdItemMap.TryGetValue(parentId, out GeneralMenuItem target))
            {
                return target.DisplayName;
            }

            return string.Empty;
        }

        private void SendTelemetryEvent(int menuItemId)
        {
            if (_telemetryFactory.TryGet(TelemetryEventIdConstants.MenuItemWithNoRootEventId, out ITelemetryEvent telemetryEvent))
            {
                telemetryEvent.SetProperty("MenuItemIdWithNoRoot", menuItemId);
                telemetryEvent.SetProperty("IsHPEmployee", _user.IsHPEmployee);
                _telemetryFactory.Send(telemetryEvent, _user.UserAliasWithDomainName);
            }
        }

        private static IEnumerable<GeneralMenuItem> GetLeafMenuItems(IEnumerable<GeneralMenuItem> allMenuItems)
        {
            List<GeneralMenuItem> leafItems = new List<GeneralMenuItem>();
            IEnumerable<GeneralMenuItem> allSubMenuItems = allMenuItems.Where(x => x.ParentId != null);

            foreach (GeneralMenuItem item in allSubMenuItems)
            {
                if (allSubMenuItems.Where(x => x.Id == item.ParentId).Count() > 0)
                {
                    leafItems.Add(item);
                }
            }

            return leafItems;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;
using HP.Pulsar.CommonContracts.ProductPage;
using HP.Pulsar.CommonContracts.TodayPage.Favorites;
using HP.Pulsar.CommonContracts.TodayPage.Tiles;
using HP.Pulsar.Infrastructure.Abstractions.Application;
using HP.Pulsar.Infrastructure.Abstractions.Tiles;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.CommonModels.Application;
using HP.Pulsar.Infrastructure.CommonModels.QuickSearch;
using HP.Pulsar.Infrastructure.ProductPage;
using Newtonsoft.Json;

namespace HP.Pulsar.Infrastructure.CommonModels.UserInfo
{
    public class PulsarUser : IPulsarUser
    {
        private readonly IUserInfoModel _userModel;
        private readonly IUserInfoRepository _userInfoRepository;
        private readonly IAppMenuProvider _appMenuProvider;
        private readonly IAppUrlProvider _appUrlProvider;
        private readonly ITelemetryFactory _telemetryFactory;
        private IPulsarUser _impersonatedUser;
        private RecentItemQueue<QuickSearchItem> _recentSearchItems;
        private RecentItemQueue<string> _recentSearchHistory;
        private IList<UserFavorite> _userFavorites;
        private const string _recentSearchHistoryCacheKey = "RecentSearchHistory";
        private const string _recentSearchItemsCacheKey = "RecentSearchItems";
        private const int _recentSearchHistoryMaxSize = 5;
        private const int _recentSearchItemsMaxSize = 10;
        private readonly IReadOnlyDictionary<int, ITile> _allTilesInDict;
        private readonly UserMenu _userMenu;
        private readonly ITileService _tileService;

        private readonly Task _readRecentSearchHistoryFromCacheTask;
        private readonly Task _readRecentSearchItemsFromCacheTask;

        public PulsarUser(IUserInfoModel userModel,
                          IUserInfoRepository userInfoRepository,
                          IAppMenuProvider appMenuProvider,
                          IAppUrlProvider appUrlProvider,
                          ITelemetryFactory telemetryFactory,
                          ITileService tileService)
        {
            _userModel = userModel;
            _userInfoRepository = userInfoRepository;
            _appMenuProvider = appMenuProvider;
            _appUrlProvider = appUrlProvider;
            _telemetryFactory = telemetryFactory;
            _readRecentSearchHistoryFromCacheTask = ReadRecentSearchHistoryFromCacheAsync();
            _readRecentSearchItemsFromCacheTask = ReadRecentSearchItemsFromCacheAsync();
            _tileService = tileService;

            ImpersonatedUserIdInSwitchCM = userModel.ImpersonatedUserIdInSwitchCM;
            ImpersonatedUserIdInSwitchMarketing = userModel.ImpersonatedUserIdInSwitchMarketing;
            ImpersonatedUserIdInSwitchPC = userModel.ImpersonatedUserIdInSwitchPC;
            ImpersonatedUserIdInSwitchPhWeb = userModel.ImpersonatedUserIdInSwitchPhWeb;
            ImpersonatedUserIdInSwitchPM = userModel.ImpersonatedUserIdInSwitchPM;
            ImpersonatedUserIdInSystemLevel = userModel.ImpersonatedUserIdInSystemLevel;
            IsReloadImpersonationUserRequired = true;

            _allTilesInDict = tileService.GetTiles().ToDictionary(x => x.Id);
            _userMenu = new UserMenu(this, appMenuProvider, _allTilesInDict, telemetryFactory);
        }

        public bool CanShowSwitchCm => _userModel.CanShowSwitchCm;

        public bool CanShowSwitchMarketing => _userModel.CanShowSwitchMarketing;

        public bool CanShowSwitchPc => _userModel.CanShowSwitchPc;

        public bool CanShowSwitchPhWeb => _userModel.CanShowSwitchPhWeb;

        public bool CanShowSwitchPm => _userModel.CanShowSwitchPm;

        public CurrentFocusedMenuItem CurrentFocusedMenuItem { get; set; }

        public IPageTab DefaultProductPageTab => _userModel.DefaultProductPageTab ?? ProductPageTab.General;

        public UserDivision Division => _userModel.Division;

        public string DomainName => _userModel.DomainName;

        public string Email => _userModel.Email;

        public int EmployeeNumber => _userModel.EmployeeNumber;

        public string FirstName => _userModel.FirstName;

        public string FullName => _userModel.FullName;

        public int Id => _userModel.Id;

        // Switch CM user id 
        public int? ImpersonatedUserIdInSwitchCM { get; private set; }

        // Switch Marketing user id
        public int? ImpersonatedUserIdInSwitchMarketing { get; private set; }

        // Switch PC user id
        public int? ImpersonatedUserIdInSwitchPC { get; private set; }

        // Switch PhWeb user id
        public int? ImpersonatedUserIdInSwitchPhWeb { get; private set; }

        // Switch PM user id
        public int? ImpersonatedUserIdInSwitchPM { get; private set; }

        // Switch to a user in system-level
        public int? ImpersonatedUserIdInSystemLevel { get; private set; }

        public bool IsAccessoryPM => _userModel.IsAccessoryPM;

        public bool IsActive => _userModel.IsActive;

        public bool IsActiveInPMRole => _userModel.IsActiveInPMRole;

        public bool IsAVsMissingCommMarketingData => _userModel.IsAVsMissingCommMarketingData;

        public bool IsAVsMissingConsMarketingData => _userModel.IsAVsMissingConsMarketingData;

        public bool IsAVsMissingSMBMarketingData => _userModel.IsAVsMissingSMBMarketingData;

        public bool IsCMEditAccess => _userModel.IsCMEditAccess;

        public bool IsCommodityPM => _userModel.IsCommodityPM;

        public bool IsComponentsAvailable => _userModel.IsComponentsAvailable;

        public bool IsDcrPM => _userModel.IsDcrPM;

        public bool IsEngCoordinator => _userModel.IsEngCoordinator;

        public bool IsFTBIOSSection => _userModel.IsFTBIOSSection;

        public bool IsHardwarePM => _userModel.IsHardwarePM;

        public bool IsHPEmployee => _userModel.IsHPEmployee;

        public bool IsMITTestLead => _userModel.IsMITTestLead;

        public bool IsOTSDeliverableSection => _userModel.IsOTSDeliverableSection;

        public bool IsPDMUser => _userModel.IsPDMUser;

        public bool IsPreinstallPM => _userModel.IsPreinstallPM;

        public bool IsPulsarAdmin => _userModel.IsPulsarAdmin;

        public bool IsReloadImpersonationUserRequired { get; set; }

        public bool IsRequestingFeature => _userModel.IsRequestingFeature;

        public bool IsSCFactoryEngineer => _userModel.IsSCFactoryEngineer;

        public bool IsSEPMEditAccess
        {
            get { return _userModel.IsSEPMEditAccess; }
            set { _userModel.IsSEPMEditAccess = value; }
        }

        public bool IsServicePM => _userModel.IsServicePM;

        public bool IsSMEditAccess
        {
            get { return _userModel.IsSMEditAccess; }
            set { _userModel.IsSMEditAccess = value; }
        }

        public bool IsSvcBomAnalystOrGPLM => _userModel.IsSvcBomAnalystOrGPLM;

        public bool IsTestLeadAssignment => _userModel.IsTestLeadAssignment;

        public bool IsUnderImpersonation => ImpersonatedUserIdInSwitchCM.HasValue && ImpersonatedUserIdInSwitchCM.Value > 0
                                            || ImpersonatedUserIdInSwitchMarketing.HasValue && ImpersonatedUserIdInSwitchMarketing.Value > 0
                                            || ImpersonatedUserIdInSwitchPC.HasValue && ImpersonatedUserIdInSwitchPC.Value > 0
                                            || ImpersonatedUserIdInSwitchPhWeb.HasValue && ImpersonatedUserIdInSwitchPhWeb.Value > 0
                                            || ImpersonatedUserIdInSwitchPM.HasValue && ImpersonatedUserIdInSwitchPhWeb.Value > 0
                                            || ImpersonatedUserIdInSystemLevel.HasValue && ImpersonatedUserIdInSwitchPhWeb.Value > 0;

        public bool IsUserHasAccessRequest => _userModel.IsUserHasAccessRequest;

        public bool IsWHQLTestTeam => _userModel.IsWHQLTestTeam;

        public string LastName => _userModel.LastName;

        public int PartnerId => _userModel.PartnerId;

        public string UserAlias => _userModel.UserAlias;

        public string UserAliasWithDomainName => $"{DomainName}\\{UserAlias}";

        UserDivision IUserInfoModel.Division { get; }

        #region UserFavrotie
        public async Task AddUserFavoriteAsync(UserFavorite userFavorite)
        {
            if (userFavorite == null)
            {
                return;
            }

            // load user favorites
            await GetUserFavoritesAsync().ConfigureAwait(false);

            if (!_userFavorites.Contains(userFavorite))
            {
                userFavorite.Sequence = GetLastFavoriteSequenceNumber(userFavorite.FavoriteType);
                _userFavorites.Add(userFavorite);
                // run database operation in another thread. Do not block here.
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                Task.Run(() => _userInfoRepository.AddUserFavoriteAsync(Id, userFavorite));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            }
        }

        private int GetLastFavoriteSequenceNumber(UserFavoriteType userFavoriteType)
        {
            int lastSequenceNumber = 0;

            foreach (UserFavorite userFavorite in _userFavorites)
            {
                if (userFavorite.FavoriteType == userFavoriteType && userFavorite.Sequence > lastSequenceNumber)
                {
                    lastSequenceNumber = userFavorite.Sequence;
                }
            }

            return lastSequenceNumber == int.MaxValue ? int.MaxValue : lastSequenceNumber + 1;
        }

        public async Task DeleteUserFavoriteAsync(UserFavorite userFavorite)
        {
            if (userFavorite == null)
            {
                return;
            }

            // load user favorites
            await GetUserFavoritesAsync().ConfigureAwait(false);

            if (_userFavorites.Remove(userFavorite))
            {
                // run database operation in another thread. Do not block here.
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                Task.Run(() => _userInfoRepository.DeleteUserFavoriteAsync(Id, userFavorite));
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
            }
        }

        public async Task<IList<UserFavorite>> GetUserFavoritesAsync(string searchText = "", bool isTileIncluded = false)
        {
            if (_userFavorites == null)
            {
                IReadOnlyList<GeneralMenuItem> serviceMenuItems = await _appMenuProvider.GetServiceMenuItemsAsync().ConfigureAwait(false);
                IReadOnlyList<UserFavorite> favorites = await _userInfoRepository.GetUserFavoritesAsync(Id).ConfigureAwait(false);

                if (favorites == null)
                {
                    _userFavorites = new List<UserFavorite>();
                    return _userFavorites;
                }

                // update display method of 'Service' favorite items
                foreach (UserFavorite favorite in favorites.Where(fav => fav.FavoriteType == UserFavoriteType.Service))
                {
                    GeneralMenuItem menuItem = serviceMenuItems.FirstOrDefault(item => item.Id == favorite.ItemId);

                    if (menuItem != null)
                    {
                        favorite.MenuItemDisplayMode = menuItem.DisplayMode;
                    }
                }

                // update link of 'Product' items
                foreach (UserFavorite favorite in favorites.Where(fav => fav.FavoriteType == UserFavoriteType.Product))
                {
                    favorite.ItemLink = string.Format(_appUrlProvider.GetProductOnQuickSearchUrlPath(favorite.ItemId));
                }

                // update link of 'Component Root' items
                foreach (UserFavorite favorite in favorites.Where(fav => fav.FavoriteType == UserFavoriteType.ComponentRoot))
                {
                    favorite.ItemLink = string.Format(_appUrlProvider.GetComponentRootOnQuickSearchUrlPath(favorite.ItemId));
                }

                // update name and link of Tile items
                foreach (UserFavorite uf in favorites.Where(x => x.FavoriteType == UserFavoriteType.Tile))
                {
                    if (_allTilesInDict.TryGetValue(uf.ItemId, out ITile tile))
                    {
                        uf.ItemName = tile.Name;
                        uf.ItemLink = tile.ShowContentUrlRelativePath;
                    }
                }

                _userFavorites = favorites as IList<UserFavorite>;
            }

            if (string.IsNullOrWhiteSpace(searchText) && isTileIncluded)
            {
                return _userFavorites.OrderBy(x => x.Sequence).ToList();
            }

            IEnumerable<UserFavorite> tempUserFavorites = _userFavorites;

            if (!string.IsNullOrWhiteSpace(searchText))
            {
                tempUserFavorites = tempUserFavorites.Where(x => x.ItemName.IndexOf(searchText.Trim(), StringComparison.OrdinalIgnoreCase) >= 0);
            }

            if (!isTileIncluded)
            {
                tempUserFavorites = tempUserFavorites.Where(x => x.FavoriteType != UserFavoriteType.Tile);
            }

            return tempUserFavorites.OrderBy(x => x.Sequence).ToList();
        }

        public async Task<IList<UserFavorite>> GetUserFavoritesAsync(UserFavoriteType type)
        {
            IList<UserFavorite> favorites = type == UserFavoriteType.Tile
                                            ? await GetUserFavoritesAsync(isTileIncluded: true).ConfigureAwait(false)
                                            : await GetUserFavoritesAsync().ConfigureAwait(false);

            return favorites.Where(x => x.FavoriteType == type).ToList();
        }

        public async Task UpdateUserFavoritesAsync(IReadOnlyList<UserFavorite> userFavorites)
        {
            if (userFavorites == null)
            {
                return;
            }

            // load user favorites
            await GetUserFavoritesAsync().ConfigureAwait(false);

            //userFavorites parameter would have only Favorite Services, Reports, Products and Components. 
            //It is neccessary to preserve the favorite tiles. So, take a copy of it and merge it with other favorites.
            IEnumerable<UserFavorite> userFavoriteTiles = _userFavorites.Where(f => f.FavoriteType == UserFavoriteType.Tile);
            IEnumerable<UserFavorite> userFavoriteWithTiles = userFavoriteTiles.Union(userFavorites);

            _userFavorites = userFavoriteWithTiles.ToList();
            string userFavoritesJson = JsonConvert.SerializeObject(userFavoriteWithTiles);

            // Let's wait for database operation completes.
            await _userInfoRepository.UpdateUserFavoritesAsync(Id, userFavoritesJson).ConfigureAwait(false);
        }
        #endregion

        #region Impersonation
        public async Task CancelImpersonationAsync()
        {
            await _userInfoRepository.ClearImpersonationAsync(Id).ConfigureAwait(false);
            ClearImpersonationUserIds();
        }

        private void ClearImpersonationUserIds()
        {
            ImpersonatedUserIdInSwitchCM = null;
            ImpersonatedUserIdInSwitchMarketing = null;
            ImpersonatedUserIdInSwitchPC = null;
            ImpersonatedUserIdInSwitchPhWeb = null;
            ImpersonatedUserIdInSwitchPM = null;
            ImpersonatedUserIdInSystemLevel = null;
        }

        private (ImpersonationArea ImpersonationArea, int ImpersonationUserId) GetCurrentImpersonationUserInfo()
        {
            if (ImpersonatedUserIdInSwitchCM.HasValue && ImpersonatedUserIdInSwitchCM.Value > 0)
            {
                return (ImpersonationArea.ConfigurationManager, ImpersonatedUserIdInSwitchCM.Value);
            }
            else if (ImpersonatedUserIdInSwitchMarketing.HasValue && ImpersonatedUserIdInSwitchMarketing.Value > 0)
            {
                return (ImpersonationArea.Marketing, ImpersonatedUserIdInSwitchMarketing.Value);
            }
            else if (ImpersonatedUserIdInSwitchPC.HasValue && ImpersonatedUserIdInSwitchPC.Value > 0)
            {
                return (ImpersonationArea.ProgramCoordinator, ImpersonatedUserIdInSwitchPC.Value);
            }
            else if (ImpersonatedUserIdInSwitchPhWeb.HasValue && ImpersonatedUserIdInSwitchPhWeb.Value > 0)
            {
                return (ImpersonationArea.PhWeb, ImpersonatedUserIdInSwitchPhWeb.Value);
            }
            else if (ImpersonatedUserIdInSwitchPM.HasValue && ImpersonatedUserIdInSwitchPM.Value > 0)
            {
                return (ImpersonationArea.PM, ImpersonatedUserIdInSwitchPM.Value);
            }
            else if (IsPulsarAdmin && ImpersonatedUserIdInSystemLevel.HasValue && ImpersonatedUserIdInSystemLevel.Value > 0)
            {
                return (ImpersonationArea.SystemLevel, ImpersonatedUserIdInSystemLevel.Value);
            }

            return (ImpersonationArea.None, -1);
        }

        public async Task<(ImpersonationArea ImpersonationArea, IPulsarUser ImpersonatedUser)> GetImpersonatedUserAsync()
        {
            (ImpersonationArea Area, int ImpersonatedUserId) = GetCurrentImpersonationUserInfo();

            if (Area == ImpersonationArea.None || ImpersonatedUserId <= 0)
            {
                return (Area, null);
            }

            if (IsReloadImpersonationUserRequired)
            {
                IUserInfoModel userModel = await _userInfoRepository.GetUserInfoModelAsync(ImpersonatedUserId).ConfigureAwait(false);

                if (userModel != null)
                {
                    IsReloadImpersonationUserRequired = false;
                    _impersonatedUser = new PulsarUser(userModel,
                                                       _userInfoRepository,
                                                       _appMenuProvider,
                                                       _appUrlProvider,
                                                       _telemetryFactory,
                                                       _tileService);

                    return (Area, _impersonatedUser);
                }
            }

            if (_impersonatedUser != null)
            {
                return (Area, _impersonatedUser);
            }

            return (ImpersonationArea.None, null);
        }

        public async Task SetImpersonatedUserAsync(ImpersonationArea area, int impersonatedUserId)
        {
            await CancelImpersonationAsync().ConfigureAwait(false);
            await _userInfoRepository.SetImpersonationAsync(area, Id, impersonatedUserId).ConfigureAwait(false);
            SetImpersonateUserId(area, impersonatedUserId);
            IsReloadImpersonationUserRequired = true;
        }

        private void SetImpersonateUserId(ImpersonationArea area, int impersonatedUserId)
        {
            if (area == ImpersonationArea.ConfigurationManager)
            {
                ImpersonatedUserIdInSwitchCM = impersonatedUserId;
            }
            else if (area == ImpersonationArea.Marketing)
            {
                ImpersonatedUserIdInSwitchMarketing = impersonatedUserId;
            }
            else if (area == ImpersonationArea.PhWeb)
            {
                ImpersonatedUserIdInSwitchPhWeb = impersonatedUserId;
            }
            else if (area == ImpersonationArea.PM)
            {
                ImpersonatedUserIdInSwitchPM = impersonatedUserId;
            }
            else if (area == ImpersonationArea.ProgramCoordinator)
            {
                ImpersonatedUserIdInSwitchPC = impersonatedUserId;
            }
            else if (area == ImpersonationArea.SystemLevel)
            {
                ImpersonatedUserIdInSystemLevel = impersonatedUserId;
            }
        }
        #endregion

        public async Task<IReadOnlyList<UIMenuItem>> GetTileMenuItemsAsync()
        {
            // make sure user favorites list is loaded
            IList<UserFavorite> userFavorites = await GetUserFavoritesAsync(isTileIncluded: true).ConfigureAwait(false);

            return _userMenu.GetTileMenuItems(userFavorites as IReadOnlyList<UserFavorite>);
        }

        public async Task<IReadOnlyList<UIMenuItem>> GetServiceMenuItemsAsync()
        {
            // make sure user favorites list is loaded
            await GetUserFavoritesAsync().ConfigureAwait(false);
            IEnumerable<UserFavorite> userFavoritesInService = _userFavorites.Where(x => x.FavoriteType == UserFavoriteType.Service);

            return await _userMenu.GetServiceMenuItemsAsync(userFavoritesInService).ConfigureAwait(false);
        }

        #region Recent Search Item / History
        public async Task<IReadOnlyList<string>> GetRecentSearchHistoryAsync()
        {
            await _readRecentSearchHistoryFromCacheTask;
            return _recentSearchHistory.GetItems();
        }

        public async Task<IReadOnlyList<QuickSearchItem>> GetRecentSearchItemsAsync()
        {
            await _readRecentSearchItemsFromCacheTask;
            return _recentSearchItems.GetItems();
        }

        public void SetRecentSearchHistory(string item)
        {
            if (!string.IsNullOrWhiteSpace(item))
            {
                _recentSearchHistory.SetItem(item);
            }
        }

        public void SetRecentSearchItem(QuickSearchItem item)
        {
            if (item != null)
            {
                _recentSearchItems.SetItem(item);
            }
        }

        public async Task ReadRecentSearchHistoryFromCacheAsync()
        {
            string recentSearchHistoryJson = await _userInfoRepository.GetUserCachedDataAsync(Id, _recentSearchHistoryCacheKey).ConfigureAwait(false);
            IReadOnlyList<string> recentSearchHistory = JsonConvert.DeserializeObject<IReadOnlyList<string>>(recentSearchHistoryJson);

            _recentSearchHistory = new RecentItemQueue<string>(_recentSearchHistoryMaxSize);

            if (recentSearchHistory != null && recentSearchHistory.Count != 0)
            {
                _recentSearchHistory.SetItems(recentSearchHistory);
            }
        }

        public async Task ReadRecentSearchItemsFromCacheAsync()
        {
            string recentSearchItemsJson = await _userInfoRepository.GetUserCachedDataAsync(Id, _recentSearchItemsCacheKey).ConfigureAwait(false);
            IReadOnlyList<QuickSearchItem> recentSearchItems = JsonConvert.DeserializeObject<IReadOnlyList<QuickSearchItem>>(recentSearchItemsJson);

            _recentSearchItems = new RecentItemQueue<QuickSearchItem>(_recentSearchItemsMaxSize);

            if (recentSearchItems != null && recentSearchItems.Count != 0)
            {
                _recentSearchItems.SetItems(recentSearchItems);
            }
        }

        public async Task SaveRecentSearchHistoryToCacheAsync()
        {
            await _readRecentSearchHistoryFromCacheTask;
            string recentSearchHistoryJson = JsonConvert.SerializeObject(_recentSearchHistory.GetItems());
            await _userInfoRepository.AddOrUpdateUserDataCacheAsync(Id, _recentSearchHistoryCacheKey, recentSearchHistoryJson).ConfigureAwait(false);
        }

        public async Task SaveRecentSearchItemsToCacheAsync()
        {
            await _readRecentSearchItemsFromCacheTask;
            string recentSearchItemsJson = JsonConvert.SerializeObject(_recentSearchItems.GetItems());
            await _userInfoRepository.AddOrUpdateUserDataCacheAsync(Id, _recentSearchItemsCacheKey, recentSearchItemsJson).ConfigureAwait(false);
        }
        #endregion
    }
}
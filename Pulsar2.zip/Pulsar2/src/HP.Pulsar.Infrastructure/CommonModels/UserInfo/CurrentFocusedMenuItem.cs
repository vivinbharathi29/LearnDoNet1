﻿namespace HP.Pulsar.Infrastructure.CommonModels.UserInfo
{
    public enum CurrentFocusedMenuItem
    {
        None = 0,
        Home,
        Services,
        Tiles,
        PulsarAdmin,
        Support,
        QuickSearch
    }
}
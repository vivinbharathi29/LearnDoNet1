﻿using HP.Pulsar.Infrastructure.Abstractions.QuickSearch;

namespace HP.Pulsar.Infrastructure.CommonModels.Enums
{
    // This enum data is from DeliveryType table in PRS database.
    public sealed class FeatureDeliveryType : IQuickSearchAdditionalOne
    {
        public static readonly FeatureDeliveryType SRP = new FeatureDeliveryType(1, "SRP");
        public static readonly FeatureDeliveryType TechAV = new FeatureDeliveryType(2, "Tech AV");
        public static readonly FeatureDeliveryType AMO = new FeatureDeliveryType(3, "AMO");
        public static readonly FeatureDeliveryType NewAMO = new FeatureDeliveryType(4, "New AMO");

        public FeatureDeliveryType(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public int Id { get; }

        public string Name { get; }

        public static bool TryParse(int id, out FeatureDeliveryType type)
        {
            if (id == 1)
            {
                type = SRP;
                return true;
            }

            if (id == 2)
            {
                type = TechAV;
                return true;
            }

            if (id == 3)
            {
                type = AMO;
                return true;
            }

            if (id == 4)
            {
                type = NewAMO;
                return true;
            }

            type = null;
            return true;
        }

        public static object Convert(object input)
        {
            if (input != null
                && int.TryParse(input.ToString(), out int value)
                && TryParse(value, out FeatureDeliveryType type))
            {
                return type;
            }

            return null;
        }
    }
}

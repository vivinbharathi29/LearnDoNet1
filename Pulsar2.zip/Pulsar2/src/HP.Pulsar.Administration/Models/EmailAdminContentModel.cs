﻿namespace HP.Pulsar.Administration.Models
{
    public class EmailAdminContentModel
    {
        public string GetMailsUrlPath { get; set; }
        public string ResendMailUrlPath { get; set; }
    }
}

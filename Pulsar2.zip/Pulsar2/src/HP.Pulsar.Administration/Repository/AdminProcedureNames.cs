﻿namespace HP.Pulsar.Administration.Repository
{
    public static class AdminProcedureNames
    {
        public const string GetMessageQueuedEmails = "spListMessageQueuedEmail";
        public const string ResendMessageQueuedEmails = "spUpdateMessageQueuedEmailSendTries";
    }
}

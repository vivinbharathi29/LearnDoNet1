﻿namespace HP.Pulsar.Administration
{
    public static class ViewPathConstants
    {
        public static readonly string ErrorViewUrlRelativePath = "~/Views/Home/Error.cshtml";
    }
}

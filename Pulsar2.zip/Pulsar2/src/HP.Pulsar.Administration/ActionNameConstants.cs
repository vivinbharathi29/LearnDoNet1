﻿namespace HP.Pulsar.Administration
{
    public static class ActionNameConstants
    {
        public static readonly string GetMailQueued = "GetMailQueued";
        public static readonly string GetMails = "GetMails";
        public static readonly string ResendEmails = "ResendEmails";
    }
}

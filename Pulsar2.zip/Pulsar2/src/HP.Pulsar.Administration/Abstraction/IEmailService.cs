﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Administration.Models;

namespace HP.Pulsar.Administration.Abstraction
{
    public interface IEmailService
    {
        Task SendEmailsAsync(IReadOnlyList<int> Ids);

        Task<IReadOnlyList<EmailModel>> GetEmailsAsync(int dataLimitCount, bool isNotSent);
    }
}

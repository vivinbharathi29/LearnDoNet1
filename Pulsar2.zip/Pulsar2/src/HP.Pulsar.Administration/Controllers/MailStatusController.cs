﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Administration.Abstraction;
using HP.Pulsar.Administration.Helper;
using HP.Pulsar.Administration.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.Extensions;
using Microsoft.AspNetCore.Mvc;

namespace HP.Pulsar.Administration.Controllers
{
    public class MailStatusController : Controller
    {
        private IEmailService _emailService;
        private ITelemetryFactory _telemetryFactory;
        private IUserMemoryCache _userCache;
        private const int _queryNumber = 1000;

        public MailStatusController(IEmailService emailService,
                                    ITelemetryFactory telemetryFactory,
                                    IUserMemoryCache userCache)

        {
            _emailService = emailService;
            _telemetryFactory = telemetryFactory;
            _userCache = userCache;
        }

        [HttpGet]
        public IActionResult GetMailQueued()
        {
            if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
            {
                string reason = "EmailAdminError - current user not found";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(MailStatusController));
                return View(ViewPathConstants.ErrorViewUrlRelativePath, reason);
            }

            if (!currentUser.IsPulsarAdmin)
            {
                string reason = string.Concat("EmailAdminError - current user doesn't have permission -", currentUser.FullName);
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(MailStatusController));
                return View(ViewPathConstants.ErrorViewUrlRelativePath, reason);
            }

            EmailAdminContentModel ajaxModel = new EmailAdminContentModel {
                                      GetMailsUrlPath = UrlPathHelper.GetPageUrlPath(ControllerNameConstants.MailStatus, ActionNameConstants.GetMails),
                                      ResendMailUrlPath = UrlPathHelper.GetPageUrlPath(ControllerNameConstants.MailStatus, ActionNameConstants.ResendEmails)
                                      };

            return View(ajaxModel);
        }

        [HttpGet]
        public async Task<IActionResult> GetMails(bool isNotSent)
        {
            if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
            {
                string reason = "EmailAdminError - current user not found";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(MailStatusController));
                return Json("Permission denied. Please contact Pulsar support");
            }

            if (!currentUser.IsPulsarAdmin)
            {
                string reason = string.Concat("EmailAdminError - current user doesn't have permission -", currentUser.FullName);
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(MailStatusController));
                return Json("Permission denied. Please contact Pulsar support");
            }

            IReadOnlyList<EmailModel> emails = await _emailService.GetEmailsAsync(_queryNumber, isNotSent);
            MailContentModel model = new MailContentModel();
            model.MessageQueuedEmailList = emails;

            return Json(model);
        }
                
        public async Task<IActionResult> ResendEmails(IReadOnlyList<int> Ids)
        {
            if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
            {
                string reason = "EmailAdminError - current user not found";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(MailStatusController));
                
                return Json("Permission denied. Please contact Pulsar support");
            }

            if (!currentUser.IsPulsarAdmin)
            {
                string reason = string.Concat("EmailAdminError - current user doesn't have permission -", currentUser.FullName);
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(MailStatusController));
                
                return Json("Permission denied. Please contact Pulsar support");
            }

            await _emailService.SendEmailsAsync(Ids);

            return Json(string.Empty);
        }
    }
}

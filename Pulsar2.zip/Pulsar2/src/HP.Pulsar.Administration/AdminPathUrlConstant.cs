﻿using HP.Pulsar.Administration.Helper;

namespace HP.Pulsar.Administration
{
    public static class AdminPathUrlConstant
    {
        public static string EmailAdminViewUrlPath => UrlPathHelper.GetPageUrlPath(ControllerNameConstants.MailStatus, ActionNameConstants.GetMailQueued);
    }
}

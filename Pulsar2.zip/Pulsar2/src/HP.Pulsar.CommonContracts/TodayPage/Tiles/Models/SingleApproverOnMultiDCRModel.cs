﻿namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class SingleApproverOnMultiDCRModel
    {
        public int ApproverUserId { get; set; }

        public string DcrIds { get; set; }                        
    }
}

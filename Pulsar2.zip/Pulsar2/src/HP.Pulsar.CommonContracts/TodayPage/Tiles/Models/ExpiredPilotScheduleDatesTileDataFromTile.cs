﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ExpiredPilotScheduleDatesTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Days Late", ColumnWidth = "10%")]
        public int DaysLate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "15%")]
        public string DotsName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Release", ColumnWidth = "15%")]
        public string Release { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "20%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(HeaderText = "Version", ColumnWidth = "15%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "15%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "PartNumber", ColumnWidth = "10%")]
        public string PartNumber { get; set; }

        //Used in OnRowClick event to pass the value of this property as the querystring to the popup Url
        [IgGridColumnAttributes(IsHidden = true)]
        public int Id { get; set; }

        //Used in OnRowClick event to pass the value of this property as the querystring to the popup Url
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        //Used in OnRowClick event to pass the value of this property as the querystring to the popup Url
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableReleaseId { get; set; }

        //Used in OnRowClick event to pass the value of this property as the querystring to the popup Url
        [IgGridColumnAttributes(IsHidden = true)]
        public int DeliverableId { get; set; }

        //Used in OnRowClick event to pass the value of this property as the querystring to the popup Url
        [IgGridColumnAttributes(IsHidden = true)]
        public bool IsPulsarProduct { get; set; }
    }
}
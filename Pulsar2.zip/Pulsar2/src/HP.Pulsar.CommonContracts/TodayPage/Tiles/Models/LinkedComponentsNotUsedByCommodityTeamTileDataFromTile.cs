﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class LinkedComponentsNotUsedByCommodityTeamTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int DeliverableId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Release { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "15%")]
        public string DotsName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "23%")]
        public string DeliverableName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "15%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part Number", ColumnWidth = "12%")]
        public string PartNumber { get; set; }
        
        // Below columns are hidden, because the values are needed for Context menu
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableReleaseId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class OpenObservationsOnMyComponentsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "7%")]
        public long ObservationId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "14%")]
        public string State { get; set; }

        [IgGridColumnAttributes(HeaderText = "Pr", ColumnWidth = "5%")]
        public string Priority { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "8%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "25%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(HeaderText = "Owner", ColumnWidth = "8%")]
        public string OwnerName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Summary", ColumnWidth = "33%")]
        public string ShortDescription { get; set; }
    }
}

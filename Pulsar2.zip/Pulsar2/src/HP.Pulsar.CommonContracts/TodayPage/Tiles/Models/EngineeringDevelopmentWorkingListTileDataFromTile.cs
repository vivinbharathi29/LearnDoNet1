﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class EngineeringDevelopmentWorkingListTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "40%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Vendor { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "10%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part", ColumnWidth = "10%")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Test Progress", ColumnWidth = "10%")]
        public string Progress { get; set; }

        //Columns are hidden to use the data for Popup window
        [IgGridColumnAttributes(IsHidden = true)]
        public int? CategoryId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int RootId { get; set; }
    }
}

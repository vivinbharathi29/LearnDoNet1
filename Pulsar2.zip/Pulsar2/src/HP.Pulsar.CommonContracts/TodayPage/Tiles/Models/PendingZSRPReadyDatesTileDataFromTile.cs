﻿using System;
using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class PendingZsrpReadyDatesTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Status { get; set; }

        [IgGridColumnAttributes(HeaderText = "ZSRP Target Date", ColumnWidth = "10%", Format = "MM/dd/yyyy")]
        public DateTime? ZsrpTargetDate { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Submitter { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "35%")]
        public string Summary { get; set; }

        // Used to show the ZsrpDate grid cell in Red color when this property is true
        [IgGridColumnAttributes(IsHidden = true)]
        public bool IsExpired { get; set; }
    }
}
﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class MissingSubassemblyNumbersTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int RootId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "20%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "35%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(HeaderText = "Business Segment", ColumnWidth = "15%")]
        public string BusinessSegment { get; set; }

        [IgGridColumnAttributes(HeaderText = "Tagged Date", ColumnWidth = "10%", Format = "MM/dd/yyyy")]
        public DateTime CreationDate { get; set; }

        // Product Id property is passed as the query string to a popup which is called when the grid row is clicked
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        // Release Id property is passed as the query string to a popup which is called when the grid row is clicked
        [IgGridColumnAttributes(IsHidden = true)]
        public int ReleaseId { get; set; }

        // ComponentRootId property is passed as the query string to a popup which is called when the grid row is clicked
        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }
    }
}
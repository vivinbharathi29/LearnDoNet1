﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class PhWebAvActionItemsLegacyProductTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product Name", ColumnWidth = "10%")]
        public string ProductBrandName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Days Until", ColumnWidth = "5%")]
        public string DaysUntil { get; set; }

        [IgGridColumnAttributes(HeaderText = "Action Start Date", ColumnWidth = "5%")]
        public DateTime? ActionStartDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "PhWeb Action", ColumnWidth = "10%")]
        public string ActionName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Auto Input", ColumnWidth = "10%")]
        public bool IsAutoInput { get; set; }

        [IgGridColumnAttributes(HeaderText = "Av No.", ColumnWidth = "5%")]
        public string AvNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "GPG Description", ColumnWidth = "10%")]
        public string GPGDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Avail. Dt.", ColumnWidth = "5%")]
        public DateTime? AvailabilityDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "CPL Blind Dt.", ColumnWidth = "5%")]
        public DateTime? CPLBlindDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "End of Manufacturing", ColumnWidth = "5%")]
        public DateTime? RASDiscontinueDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "SDF Flag", ColumnWidth = "10%")]
        public bool IsSDF { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Instructions { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feedback", ColumnWidth = "10%")]
        public string PDMFeedback { get; set; }

        // Hidden field are used to populate the data in Popup
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductBrandId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int AvDetailId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int AvActionItemId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int PhWebActionTypeId { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class PhWebAvActionItemsPulsarProductTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product Name", ColumnWidth = "80%")]
        public string ProductBrandName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Days Until", ColumnWidth = "20%")]
        public string DaysUntil { get; set; }

        // Hidden field was used to populate the data in Popup
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductBrandId { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class FeaturesRequestingRootComponentsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Marketing/Supply Chain Feature Name", ColumnWidth = "25%")]
        public string FeatureName { get; set; }

        [IgGridColumnAttributes(HeaderText = "R&D Component Name", ColumnWidth = "25%")]
        public string RootNamingSuggestion { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Category", ColumnWidth = "10%")]
        public string FeatureCategory { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component Category", ColumnWidth = "10%")]
        public string Category { get; set; }

        [IgGridColumnAttributes(HeaderText = "Requested By", ColumnWidth = "10%")]
        public string UpdatedBy { get; set; }

        [IgGridColumnAttributes(HeaderText = "Date Requested", ColumnWidth = "10%", Format = "MM/dd/yyyy")]
        public DateTime UpdatedDate { get; set; }
    }
}

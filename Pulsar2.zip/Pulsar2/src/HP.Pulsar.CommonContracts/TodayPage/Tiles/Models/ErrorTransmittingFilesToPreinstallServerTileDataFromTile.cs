﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ErrorTransmittingFilesToPreinstallServerTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "40%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(HeaderText = "Version", ColumnWidth = "15%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Issue", ColumnWidth = "35%")]
        public string Status { get; set; }

        // Root Id is passed as the query string parameter to a popup that is invoked from Tile Grid's Context menu
        [IgGridColumnAttributes(IsHidden = true)]
        public int RootId { get; set; }

        // The Tile grid's context menu items are enabled/ disabled based on the WorkflowStatus property value
        [IgGridColumnAttributes(IsHidden = true)]
        public int WorkflowStatus { get; set; }
    }
}
﻿namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public enum ChangeType
    {
        LocalizationRemoved = 0,
        LocalizationAdded = 1
    }
}
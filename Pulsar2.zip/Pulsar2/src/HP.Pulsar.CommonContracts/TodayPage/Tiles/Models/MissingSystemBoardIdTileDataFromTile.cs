﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class MissingSystemBoardIdTileData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "40%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "60%")]
        public string DOTSName { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class LeadProductSynchronizationTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Lead Product", ColumnWidth = "15%")]
        public string LeadProduct { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "15%")]
        public string ComponentName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Actions", ColumnWidth = "55%")]
        public string LeadProductSynchronizationsSummary { get; set; }

        //Columns are hidden to use the data to invoke Popup pages
        [IgGridColumnAttributes(IsHidden = true)]
        public int LeadProductSynchronizationId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int FollowerId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool IsFusionRequirement { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string VersionIds { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int IsFusion => IsFusionRequirement ? 1 : 0;
    }
}

using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ImageTabChangeToLocalizationForPulsarProductTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Operating System", ColumnWidth = "35%")]
        public string OperatingSystem { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Localization { get; set; }

        [IgGridColumnAttributes(HeaderText = "Change Type", ColumnWidth = "35%")]
        public string ChangeType { get; set; }

        [IgGridColumnAttributes(HeaderText = "Created Date", Format = "MM/dd/yyyy", ColumnWidth = "15%")]
        public DateTime? Created { get; set; }

        //Passed as an input parameter for the context menu.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductVersionId { get; set; }

        //Passed as an input parameter for the context menu.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ImageActionItemId { get; set; }

        //Passed as an input parameter for the context menu.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductBrandId { get; set; }
    }
}
﻿namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class QualificationConfidenceType
    {
        public static readonly QualificationConfidenceType None = new QualificationConfidenceType(0, "None");
        public static readonly QualificationConfidenceType High = new QualificationConfidenceType(1, "High");
        public static readonly QualificationConfidenceType Medium = new QualificationConfidenceType(2, "Medium");
        public static readonly QualificationConfidenceType Low = new QualificationConfidenceType(3, "Low");

        private QualificationConfidenceType(int id, string name)
        {
            Name = name;
            Id = id;
        }

        public string Name { get; set; }

        public int Id { get; set; }

        public static QualificationConfidenceType GetModel(int confidenceId)
        {
            if (confidenceId == High.Id)
            {
                return High;
            }

            if (confidenceId == Medium.Id)
            {
                return Medium;
            }

            if (confidenceId == Low.Id)
            {
                return Low;
            }

            return None;
        }
    }
}
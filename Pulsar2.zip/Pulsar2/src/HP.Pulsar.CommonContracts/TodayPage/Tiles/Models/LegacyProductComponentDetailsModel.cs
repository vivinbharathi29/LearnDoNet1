﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class LegacyProductComponentDetailsModel
    {
        public int ComponentId { get; set; }

        public string ComponentName { get; set; }

        public ComponentType ComponentType { get; set; }

        public string EmailReceipent { get; set; }

        public string ProductName { get; set; }

        public IReadOnlyList<string> SystemTeamEmails { get; set; }
    }
}

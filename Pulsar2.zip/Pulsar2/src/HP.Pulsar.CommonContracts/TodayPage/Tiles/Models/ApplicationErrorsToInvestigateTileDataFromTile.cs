﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ApplicationErrorsToInvestigateTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string User { get; set; }

        [IgGridColumnAttributes(HeaderText = "When", ColumnWidth = "15%", Format = "MM/dd/yyyy")]
        public DateTime ErrorDateTime { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Page { get; set; }

        [IgGridColumnAttributes(HeaderText = "Line", ColumnWidth = "10%")]
        public int? ErrorLine { get; set; }

        [IgGridColumnAttributes(HeaderText = "Error Description", ColumnWidth = "40%")]
        public string ErrorDescription { get; set; }

        // Passed as an input parameter for the context menu.
        [IgGridColumnAttributes(IsHidden = true)]
        public string Email { get; set; }
    }
}
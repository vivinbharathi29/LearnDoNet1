﻿namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public enum ComponentIssueActionStatus
    {
        None = 0,
        Open = 1,
        Closed = 2,
        NeedMoreInformation = 3,
        Approved = 4,
        Disapproved = 5,
        Investigating = 6,
        Blocked = 7,
        Pass = 8,
        Fail = 9
    }
}
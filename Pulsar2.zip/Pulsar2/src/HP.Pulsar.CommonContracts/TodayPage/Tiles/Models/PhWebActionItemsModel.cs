﻿using System;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class PhWebActionItemsModel
    {
        public string ActionName { get; set; }

        public DateTime ActionStartDate { get; set; }

        public int AvDetailId { get; set; }

        public string AvNumber { get; set; }

        public string Email { get; set; }

        public string GpgDescription { get; set; }

        public string PdmFeedback { get; set; }

        public int ProductBrandId { get; set; }

        public int ProductId { get; set; }

        public string ProductName { get; set; }
    }
}

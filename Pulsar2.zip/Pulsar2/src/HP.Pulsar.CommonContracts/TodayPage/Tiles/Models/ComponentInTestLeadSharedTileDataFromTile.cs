﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    // This model is reused in three tiles named (Component In Test ODM Lead ,Component In Test SE Lead , 
    // Component In Test WWAN Lead).
    public class ComponentInTestLeadSharedTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "11%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Target", ColumnWidth = "10%")]
        public string TestDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "32%")]
        public string Deliverable { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "17%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "15%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string PartNumber { get; set; }

        //Passed as an input paramter for the rowclick event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableId { get; set; }

        //Passed as an input paramter for the rowclick event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableReleaseId { get; set; }

        //Passed as an input paramter for the rowclick event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        //Passed as an input paramter for the rowclick event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int RootId { get; set; }

        //Passed as an input paramter for the rowclick event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int VersionId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int PopupId { get; set; }
    }
}
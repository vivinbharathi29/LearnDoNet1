﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class DCRWorkflowMilestonesTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "15%")]
        public string DotsName { get; set; }

        [IgGridColumnAttributes(HeaderText = "DCR Number", ColumnWidth = "10%")]
        public int DCRId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Milestone { get; set; }

        [IgGridColumnAttributes(HeaderText = "Workflow Type", ColumnWidth = "15%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(HeaderText = "Workflow Created Date", ColumnWidth = "10%")]
        public DateTime CreatedDate { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Step { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "20%")]
        public string Comments { get; set; }

        // The Grid Row cells are shown in a different color based on the Reassign property
        [IgGridColumnAttributes(IsHidden = true)]
        public bool CanReassign { get; set; }

        // PvId value is passed as the query string to an another popup page which is fired from the context menu
        [IgGridColumnAttributes(IsHidden = true)]
        public int PvId { get; set; }

        // History Id value is passed as the query string to an another popup page which is fired from the context menu
        [IgGridColumnAttributes(IsHidden = true)]
        public int HistoryId { get; set; }
    }
}
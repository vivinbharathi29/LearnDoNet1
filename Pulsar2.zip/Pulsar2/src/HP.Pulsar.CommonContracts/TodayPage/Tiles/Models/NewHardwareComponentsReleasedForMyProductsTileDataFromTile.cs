﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class NewHardwareComponentsReleasedForMyProductsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "8%")]
        public int ComponentVersionId { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "7%")]
        public string Release { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "7%")]
        public string HFCN { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "9%")]
        public string Vendor { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "25%")]
        public string ComponentName { get; set; }

        [IgGridColumnAttributes(HeaderText = "HW", ColumnWidth = "8%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "FW", ColumnWidth = "8%")]
        public string Revision { get; set; }

        [IgGridColumnAttributes(HeaderText = "Rev", ColumnWidth = "13%")]
        public string Pass { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model No.", ColumnWidth = "14%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part No.", ColumnWidth = "9%")]
        public string PartNumber { get; set; }

        //Below are used for grid row click events
        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentReleaseId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool IsPulsarProduct { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int Id { get; set; }
    }
}
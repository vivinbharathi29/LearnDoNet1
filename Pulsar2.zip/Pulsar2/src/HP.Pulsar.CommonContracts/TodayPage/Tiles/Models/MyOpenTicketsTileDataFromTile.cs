﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class MyOpenTicketsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "8%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Project", ColumnWidth = "8%")]
        public string ProjectName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Category", ColumnWidth = "12%")]
        public string Category { get; set; }

        [IgGridColumnAttributes(HeaderText = "Submitter", ColumnWidth = "12%")]
        public string SubmitterName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Owner", ColumnWidth = "10%")]
        public string OwnerName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Status", ColumnWidth = "9%")]
        public string Status { get; set; }

        [IgGridColumnAttributes(HeaderText = "Age", ColumnWidth = "8%")]
        public int Age { get; set; }

        [IgGridColumnAttributes(HeaderText = "Summary", ColumnWidth = "35%")]
        public string Summary { get; set; }
    }
}
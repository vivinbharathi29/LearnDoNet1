﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class AvsNotMappedToSpareKitsTileData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "15%", HeaderText = "Program")]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%", HeaderText = "Brand")]
        public string BrandName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%", HeaderText = "Feature Category")]
        public string AvFeatureCategory { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "40%", HeaderText = "GPG Description")]
        public string GpgDescription { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%", HeaderText = "AV")]
        public string AvNo { get; set; }

        //Hidden filed value was used to update the IgnoreAv in context menu
        [IgGridColumnAttributes(IsHidden = true)]
        public string Kmat { get; set; }
    }
}

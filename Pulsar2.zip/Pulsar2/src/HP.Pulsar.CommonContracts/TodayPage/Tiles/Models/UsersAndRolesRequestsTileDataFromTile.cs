﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class UsersAndRolesRequestsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Team Name", ColumnWidth = "35%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(HeaderText = "User Name", ColumnWidth = "35%")]
        public string CreatedBy { get; set; }

        [IgGridColumnAttributes(HeaderText = "Data Requested", ColumnWidth = "30%")]
        public DateTime Created { get; set; }
    }
}

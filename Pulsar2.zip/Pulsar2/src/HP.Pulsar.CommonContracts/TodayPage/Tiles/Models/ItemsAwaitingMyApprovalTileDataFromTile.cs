﻿using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ItemsAwaitingMyApprovalTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Type", ColumnWidth = "15%")]
        public ComponentIssueActionType ComponentIssueActionType { get; set; }

        [IgGridColumnAttributes(HeaderText = "Status", ColumnWidth = "15%")]
        public ComponentIssueActionStatus ComponentIssueActionStatus { get; set; }

        [IgGridColumnAttributes(HeaderText = "Owner", ColumnWidth = "15%")]
        public string Owner { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "15%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Summary", ColumnWidth = "15%")]
        public string Summary { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Comments { get; set; }

        // The Type property value is passed as query string to a page.
        // The page is invoked from the Context Menu of the Tile grid.
        [IgGridColumnAttributes(IsHidden = true)]
        public ComponentIssueActionType Type { get; set; }
    }
}
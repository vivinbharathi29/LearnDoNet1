﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class PastDueScheduleItemsTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "12%")]
        public string ProductName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Schedule", ColumnWidth = "18%")]
        public string ScheduleName { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "18%")]
        public string Milestone { get; set; }

        [IgGridColumnAttributes(HeaderText = "Owner", ColumnWidth = "12%")]
        public string OwnerName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Current Start", Format = "MM/dd/yyyy", ColumnWidth = "10%")]
        public DateTime? ProjectedStartDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Current End", Format = "MM/dd/yyyy", ColumnWidth = "10%")]
        public DateTime? ProjectedEndDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Actual Start", Format = "MM/dd/yyyy", ColumnWidth = "10%")]
        public DateTime? ActualStartDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Actual End", Format = "MM/dd/yyyy", ColumnWidth = "10%")]
        public DateTime? ActualEndDate { get; set; }

        //To check whether its pulsar or legacy application.
        [IgGridColumnAttributes(IsHidden = true)]
        public bool? IsFusionRequired { get; set; }

        //Passed as an input parameter to the row click event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ScheduleDataId { get; set; }
    }
}
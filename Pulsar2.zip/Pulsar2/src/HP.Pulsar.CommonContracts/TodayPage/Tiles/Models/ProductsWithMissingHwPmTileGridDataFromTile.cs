﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class ProductsWithMissingHwPmTileGridDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "20%")]
        public string Product { get; set; }
        [IgGridColumnAttributes(HeaderText ="Dev Center", ColumnWidth = "20%")]
        public string DevCenter { get; set; }
        [IgGridColumnAttributes(HeaderText = "ODM", ColumnWidth = "20%")]
        public string Partner { get; set; }
        [IgGridColumnAttributes(HeaderText = "Description", ColumnWidth = "40%")]
        public string Description { get; set; }
        //Hidden filed was used to show the content in the popup
        [IgGridColumnAttributes(IsHidden = true)]
        public int Id { get; set; }
    }
}
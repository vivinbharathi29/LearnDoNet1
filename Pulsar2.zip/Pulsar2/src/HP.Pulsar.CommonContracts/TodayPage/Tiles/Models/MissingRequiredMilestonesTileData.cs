﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class MissingRequiredMilestonesTileData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "10%")]
        public string DotsName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Schedule", ColumnWidth = "10%")]
        public string ScheduleName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Item Description", ColumnWidth = "20%")]
        public string ItemDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Item Definition", ColumnWidth = "60%")]
        public string ItemDefinition { get; set; }

        //Passed as an input parameter for the row click event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductVersionId { get; set; }
    }
}
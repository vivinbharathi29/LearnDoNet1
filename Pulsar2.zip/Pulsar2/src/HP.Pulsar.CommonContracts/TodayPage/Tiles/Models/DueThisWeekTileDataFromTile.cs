﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class DueThisWeekTileDataFromTile : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID", ColumnWidth = "10%")]
        public int Id { get; set; }

        [IgGridColumnAttributes(HeaderText = "Owner", ColumnWidth = "15%")]
        public string Owner { get; set; }

        [IgGridColumnAttributes(HeaderText = "Type", ColumnWidth = "10%")]
        public string ActionType { get; set; }

        [IgGridColumnAttributes(HeaderText = "Status", ColumnWidth = "15%")]
        public string StatusName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Due Date", ColumnWidth = "15%", Format = "MM/dd/yyyy")]
        public DateTime? DueDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "15%")]
        public string Project { get; set; }

        [IgGridColumnAttributes(HeaderText = "Summary", ColumnWidth = "20%")]
        public string Summary { get; set; }

        // Type property is used in OnRow click event of the Tile Grid to pass its value to popup page as query string
        [IgGridColumnAttributes(IsHidden = true)]
        public byte? Type { get; set; }
    }
}

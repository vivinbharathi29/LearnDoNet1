﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles
{
    public interface ITileContentModel : IGridContentModel
    {
        bool CanShowCommentTextBox { get; }

        bool CanShowDateBox { get; }

        string ColumnToDisableGridCellClicking { get; }

        public string CommentTextCaption { get; }

        int CommentTextMaxLength { get; }

        string ExcelExportUrlRelativePath { get; }

        string HeaderText { get; }

        /// <summary>
        /// Returns a user full name when impersonation is started 
        /// </summary>
        string ImpersonationUserFullName { get; }

        string Note { get; }

        string PartialViewPath { get; }

        string PrimaryKeyForGridUpdate { get; }
        
        string RowsRenderedOperation { get; }
        
        TileArea TileArea { get; }

        int TileId { get; }
    }
}
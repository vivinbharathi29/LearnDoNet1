﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search
{
    public class ComponentRootMoreResultsModel : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID")]
        public int ComponentRootId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Name")]
        public string ComponentRootName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Description")]
        public string ComponentRootDescription { get; set; }

        //Iggrid bool is true or false, so to display 'Yes' or 'No' changed data type as string
        [IgGridColumnAttributes(HeaderText = "Deactivated")]
        public string IsDeactivated { get; set; }

        [IgGridColumnAttributes(HeaderText = "Open In New Tab")]
        public string Url { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Search
{
    public class ChangeRequestMoreResultsModel : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "ID")]
        public int Id { get; set; }

        [IgGridColumnAttributes]
        public string Program { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public ChangeRequestType Type { get; set; }

        [IgGridColumnAttributes()]
        public ChangeRequestStatus Status { get; set; }

        [IgGridColumnAttributes(HeaderText = "Target Date", Format = "MM/dd/yyyy")]
        public DateTime? TargetDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Actual Date", Format = "MM/dd/yyyy")]
        public DateTime ActualDate { get; set; }

        [IgGridColumnAttributes()]
        public string Summary { get; set; }

        [IgGridColumnAttributes(HeaderText = "Open In New Tab")]
        public string Url { get; set; }
    }
}

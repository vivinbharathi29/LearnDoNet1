﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search
{
    public class EmptyMoreResultsModel : IGridGeneralOutput
    {
    }
}

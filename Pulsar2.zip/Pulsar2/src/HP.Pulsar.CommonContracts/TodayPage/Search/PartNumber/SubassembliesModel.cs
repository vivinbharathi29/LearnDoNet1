﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber
{
    public class SubassembliesModel : IPartNumberType
    {
        [IgGridColumnAttributes(HeaderText = "ID")]
        public int DeliverableRootID { get; set; }

        [IgGridColumnAttributes()]
        public string Name { get; set; }

        [IgGridColumnAttributes()]
        public string Product { get; set; }

        [IgGridColumnAttributes(HeaderText = "Base")]
        public string BaseSubassembly { get; set; }

        [IgGridColumnAttributes()]
        public string Subassembly { get; set; }
    }
}

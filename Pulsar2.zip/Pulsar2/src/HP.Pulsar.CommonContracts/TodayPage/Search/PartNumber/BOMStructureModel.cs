﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber
{
    public class BOMStructureModel : IPartNumberType
    {
        [IgGridColumnAttributes(HeaderText = "Number")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Child Number", Template = "<a href='#' onclick='searchAsKeyword(\"${ChildPartNumber}\")'/>${ChildPartNumber}</a>")]
        public string ChildPartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "GPG Description")]
        public string GPGDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Rev")]
        public string RevisionLevel { get; set; }

        [IgGridColumnAttributes(HeaderText = "Cross Plant Status")]
        public string CrossPlantStatus { get; set; }

        [IgGridColumnAttributes(HeaderText = "Qty")]
        public string QtyPer { get; set; }

        [IgGridColumnAttributes(HeaderText = "Sort String")]
        public string SortString { get; set; }
    }
}

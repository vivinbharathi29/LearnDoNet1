﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber
{
    public class WhereUsedInformationModel : IPartNumberType
    {
        [IgGridColumnAttributes(HeaderText = "Number")]
        public string ChildPartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Parent Number",Template = "<a href='#' onclick='searchAsKeyword(\"${PartNumber}\")'/>${PartNumber}</a>")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "GPG Description")]
        public string GPGDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Start Date Type")]
        public string StartDt { get; set; }

        [IgGridColumnAttributes(HeaderText = "End Date")]
        public string EndDt { get; set; }

        [IgGridColumnAttributes(HeaderText = "Qty")]
        public string QtyPer { get; set; }

        [IgGridColumnAttributes(HeaderText = "Usage")]
        public string Usage { get; set; }

        [IgGridColumnAttributes(HeaderText = "Sort String")]
        public string SortString { get; set; }
    }
}

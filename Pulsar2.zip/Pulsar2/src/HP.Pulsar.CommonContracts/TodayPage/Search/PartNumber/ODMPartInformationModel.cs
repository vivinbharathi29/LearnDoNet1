﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search.PartNumber
{
    public class ODMPartInformationModel : IPartNumberType
    {
        [IgGridColumnAttributes(HeaderText = "HP Part No", Template = "<a href='#' onclick='searchAsKeyword(\"${HpPartNumber}\")'/>${HpPartNumber}</a>")]
        public string HpPartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "ODM Part No")]
        public string OdmPartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "ODM Description")]
        public string OdmPartDesctiption { get; set; }

        [IgGridColumnAttributes(HeaderText = "ODM")]
        public string OdmName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Spare Category")]
        public string CategoryName { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Search
{
    public class FeatureMoreResultsModel : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Feature Name")]
        public string FeatureName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Id")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Class")]
        public string FeatureClass { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Category")]
        public string FeatureCategory { get; set; }

        [IgGridColumnAttributes(HeaderText = "Naming Standard")]
        public string NamingStandard { get; set; }

        [IgGridColumnAttributes(HeaderText = "Code Name")]
        public string CodeName { get; set; }

        [IgGridColumnAttributes]
        public string Creator { get; set; }

        [IgGridColumnAttributes(HeaderText = "Delivery Type")]
        public string DeliveryType { get; set; }

        [IgGridColumnAttributes]
        public FeatureStatus Status { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component Linkage")]
        public FeatureMoreResultComponentLinkage ComponentLinkage { get; set; }

        [IgGridColumnAttributes]
        public FeatureMoreResultVisibility Visibility { get; set; }

        [IgGridColumnAttributes]
        public string Override { get; set; }

        [IgGridColumnAttributes(HeaderText = "Open In New Tab")]
        public string Url { get; set; }
    }
}

﻿namespace HP.Pulsar.CommonContracts.TodayPage.Search
{
    public enum FeatureMoreResultVisibility
    {
        Limited = 1,
        All = 2
    }
}

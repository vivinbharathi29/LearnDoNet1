﻿namespace HP.Pulsar.CommonContracts.TodayPage.Favorites
{
    // In current Pulsar, only Component root can be added to user favorite.
    public enum UserFavoriteType
    {
        None = -1,
        Product = 0,
        ComponentRoot = 1,
        Service = 2,
        Tile = 3
    }
}
﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum CommodityRiskRelease
    {
        Off = 0,
        On
    }
}
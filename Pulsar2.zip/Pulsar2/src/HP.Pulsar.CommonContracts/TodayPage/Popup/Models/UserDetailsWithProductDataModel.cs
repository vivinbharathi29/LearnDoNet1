﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Infrastructure.UserInfo;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class UserDetailsWithProductDataModel : IGridGeneralOutput
    {
        public HardwarePmType HardwarePMCategory { get; set; }

        public PmAccessToHardwareCondition PmAccessToHardwareTypes { get; set; }

        public HardwareTypePmUsersModel HardwareTypePMs { get; set; }

        public bool IsPM { get; set; }

        public int ProductCount { get; set; }

        public ProductHardwarePmDataModel ProductHardwarePmModel { get; set; }

        public int ProductId { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }
    }
}
﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class AccessoryStatusData
    {
        public AccessoryStatus AccessoryStatus { get; set; }

        public byte DateField { get; set; }

        public bool IsCommentRequired { get; set; }

        public bool IsSelected { get; set; }

        public string Name { get; set; }
    }
}
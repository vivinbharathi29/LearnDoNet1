﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ProductComponentPostDataModel
    {
        public int Id { get; set; }
        public int StatusId { get; set; }
        public string DeveloperTestNotes { get; set; }
        public int ProductComponentReleaseId { get; set; }
    }
}

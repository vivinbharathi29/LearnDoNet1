﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ProductComponentReleaseData
    {
        public int ProductComponentId { get; set; }
        public int ReleaseId { get; set; }
        public string ProductVersionReleaseName { get; set; }
        public int ProductComponentReleaseId { get; set; }
    }
}
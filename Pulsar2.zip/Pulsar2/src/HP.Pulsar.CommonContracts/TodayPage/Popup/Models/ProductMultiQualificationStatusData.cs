﻿using System;
using System.Collections.Generic;
using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    // Used in the poupup ProductMultiQualificationStatus to Fill Form Control values
    public class ProductMultiQualificationStatusData : IGridGeneralOutput
    {
        public bool IsSpecificProduct { get; set; }

        public bool IsStatusAllSame { get; set; }

        public DateTime QualificationDate { get; set; }

        public IReadOnlyDictionary<int, string> QualificationStatus { get; set; }

        public QualificationStatusType QualificationStatusType { get; set; }
    }
}

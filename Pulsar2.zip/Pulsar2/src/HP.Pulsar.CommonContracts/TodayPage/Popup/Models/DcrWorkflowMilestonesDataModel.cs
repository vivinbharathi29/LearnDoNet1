﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class DcrWorkflowMilestonesDataModel : IGridGeneralOutput
    {
        public int DcrId { get; set; }

        public int HistoryId { get; set; }

        public int ProductId { get; set; }

        public string Name { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreateDate { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    //This model is used in View Usage Exception Popup and the tile is Lead Product Synchronization Tile 
    public class ViewUsageExceptionsData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "17%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "24%")]
        public string Deliverable { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "12%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "10%")]
        public string Distribution { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "7%")]
        public string Notes { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "7%")]
        public string Images { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "24%")]
        public string Comments { get; set; }

        // Below are hidden to use it for popup update functionality
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int TypeId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool CanConsiderDistribution { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool CanConsiderNotes { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool CanConsiderImages { get; set; }
    }
}

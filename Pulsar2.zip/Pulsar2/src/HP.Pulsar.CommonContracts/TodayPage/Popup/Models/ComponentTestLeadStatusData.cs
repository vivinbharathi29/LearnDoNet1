﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    // Used in the pop TestLeadStatus to Fill Form Control values.
    public class ComponentTestLeadStatusData : IGridGeneralOutput
    {
        public int ComponentVersionId { get; set; }
        public string ComponentVersionName { get; set; }
        public ComponentVersionField FieldId { get; set; }
        public string FirmwareVersion { get; set; }
        public string HardwareVersion { get; set; }
        public string ModelNumber { get; set; }
        public string OdmTestNotes { get; set; }
        public string PartNumber { get; set; }
        public string ProductName { get; set; }
        public int ProudctId { get; set; }
        public string Revision { get; set; }
        public int RootId { get; set; }
        public ComponentVersionTestStatus Status { get; set; }
        public int? UnitsReceived { get; set; }
        public string VendorName { get; set; }
        public int VersionId { get; set; }
    }
}
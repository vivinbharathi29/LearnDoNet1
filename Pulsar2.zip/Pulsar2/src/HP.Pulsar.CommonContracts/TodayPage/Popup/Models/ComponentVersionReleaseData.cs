﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ComponentVersionReleaseData
    {
        public int ReleaseId { get; set; }

        public string ReleaseName { get; set; }
    }
}
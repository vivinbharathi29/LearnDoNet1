using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    // Used in the poupup ComponentRootVersionReleasePopup to Save User Inputs to DB
    public class ComponentVersionReleaseModelForPostData
    {
        public string Comment { get; set; }

        public int ComponentVersionId { get; set; }

        public ComponentVersionPropertiesExDataFromRepo ComponentVersionProperties { get; set; }

        public int ExecutionEngineerId { get; set; }

        public string ExecutionEngineerName { get; set; }

        public string FromMilestone { get; set; }

        public int FromMilestoneId { get; set; }

        public string ImagePath { get; set; }

        public IReadOnlyList<ComponentVersionLanguageDataFromRepo> Languages { get; set; }

        public List<string> NotificationEmails { get; set; }

        public int ToMilestoneId { get; set; }
    }
}

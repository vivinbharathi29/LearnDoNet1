﻿using System;
using HP.Pulsar.CommonContracts.EntityStatus;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class QualificationStatusModelForPostData
    {
        public string AddedSubassemly { get; set; }

        public int BatchCode { get; set; }

        public string Category { get; set; }

        public int? ChangeRequestId { get; set; }

        public string Comment { get; set; }

        public string ComponentRoomName { get; set; }

        public int ComponentVersionId { get; set; }

        public DevCenter DevCenter { get; set; }

        public CommodityTestStatus DeveloperTestStatusName { get; set; }

        public string FailedListOdmMail { get; set; }

        public int HfcnDcr { get; set; }

        public CommodityTestStatus IntegrationTestStatusName { get; set; }

        public bool IsConfigurationRestricted { get; set; }

        public bool IsOldConfigurationRestricted { get; set; }

        public bool IsOldSupplyRestricted { get; set; }

        public bool IsPulsarProduct { get; set; }

        public bool IsRemoveCompleteSupport { get; set; }

        public bool IsSupplyRestricted { get; set; }

        public string ModelNumber { get; set; }

        public CommodityTestStatus OdmTestStatusName { get; set; }        

        public int OldSelectedStatusId { get; set; }

        public CommodityQualificationStatus OldSelectedStatusText { get; set; }

        public int? PartnerId { get; set; }

        public string PartNumber { get; set; }
     
        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public string QCompleteListHpMail { get; set; }

        public string QCompleteListOdmMail { get; set; }

        public DateTime? QualificationDate { get; set; }

        public int QualificationStatusId { get; set; }

        public int ReleaseId { get; set; }

        public string RemovedSubAssembly { get; set; }
       
        public CommodityRiskRelease RiskRelease { get; set; }

        public int SelectedStatusId { get; set; }

        public CommodityQualificationStatus SelectedStatusText { get; set; }

        public string SelectedSubAssemblyIds { get; set; }

        public bool Status { get; set; }

        public int TestConfidence { get; set; }           

        public string TTStestStatusName { get; set; }

        public string UserEmail { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }

        public string Vendor { get; set; }               

        public string Version { get; set; }

        public CommodityTestStatus WwanTestStatusName { get; set; }
    }
}
﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class PendingZsrpReadyTargetDateModel : IGridGeneralOutput
    {
        // The Ids is multiple id, need to split(',') 
        public string Ids { get; set; }

        public string postUrl { get; set; }
    }
}

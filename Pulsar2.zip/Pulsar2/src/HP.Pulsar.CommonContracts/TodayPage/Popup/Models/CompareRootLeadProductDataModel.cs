﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    //This model is used in compare root lead proudct popup & popup id is 23. 
    //The tile name is Lead Product - Synchronization Issues. Tile Id 8.
    public class CompareRootLeadProductDataModel : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "17%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "17%")]
        public string Name { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "17%")]
        public string Targeted { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "17%")]
        public string Distribution { get; set; }

        [IgGridColumnAttributes(HeaderText = "Target Notes", ColumnWidth = "17%")]
        public string TargetNotes { get; set; }

        [IgGridColumnAttributes(HeaderText = "Image Summary", ColumnWidth = "17%")]
        public string ImageSummary { get; set; }

        //The below hidden items are used in popup for comparing purpose. 
        [IgGridColumnAttributes(IsHidden = true)]
        public bool DistributionCompare { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool ImageSummaryCompare { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool TargetedCompare { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public bool TargetNotesCompare { get; set; }
    }
}

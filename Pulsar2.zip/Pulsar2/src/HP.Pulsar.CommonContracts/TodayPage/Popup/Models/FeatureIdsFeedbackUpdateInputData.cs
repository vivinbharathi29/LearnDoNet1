﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class FeatureIdsFeedbackUpdateInputData : IGridGeneralOutput
    {
        public string InputData { get; set; }
    }
}

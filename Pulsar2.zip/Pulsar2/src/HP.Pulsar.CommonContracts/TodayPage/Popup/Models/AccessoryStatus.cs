﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum AccessoryStatus
    {
        Invalid = -2,
        // TODO: Bruce: LinkToCommodityStatus is added to the dropdown for UI. It is not present in the database.
        LinkToCommodityStatus = -1,
        NotUsed = 0,
        Planning = 1,
        Scheduled = 2,
        OnHold = 3,
        Canceled = 4,
        Failed = 5,
        Complete = 6,
        Leveraged = 7
    }
}
﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ActionItemDataModel : IGridGeneralOutput
    {
        public int ActionItemId { get; set; }

        public int ApplicationErrorId { get; set; }

        public ComponentIssueModel ComponentIssue { get; set; }

        public bool IsCopyMe { get; set; }

        public bool IsCopySubmitter { get; set; }

        public bool IsReviewInput { get; set; }

        public bool IsWorking { get; set; }

        public IReadOnlyDictionary<int, string> ProjectDetails { get; set; }

        public IReadOnlyDictionary<int, string> StatusDetails { get; set; }

        public int ItemStatusSelectedValue { get; set; }

        public string Title { get; set; }
    }
}

﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class LeadProductComponentsData
    {
        public bool HasProductExceptions { get; set; }

        public string WarningMessage { get; set; }

        public string SyncImagesCheckedCss { get; set; }

        public string SyncDistributionCheckedCss { get; set; }

        public string SyncNotesCheckedCss { get; set; }

        public string Version { get; set; }

        public int ComponentVersionId { get; set; }
    }
}
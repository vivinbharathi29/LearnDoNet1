﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum HardwareIntegrationTestStatus
    {
        TBD = 0,
        Passed = 1,
        Failed = 2,
        Blocked = 3
    }
}
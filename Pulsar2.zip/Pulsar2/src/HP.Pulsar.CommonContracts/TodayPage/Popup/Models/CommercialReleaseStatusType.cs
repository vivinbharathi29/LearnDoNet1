﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum CommercialReleaseStatusType
    {
        None = 0,
        Released = 1,
        Completed = 2
    }
}

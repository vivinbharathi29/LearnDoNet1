﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum ComponentPilotStatus
    {
        NotRequired = 0,
        P_Planning = 1,
        P_Scheduled = 2,
        P_Hold = 3,
        P_Canceled = 4,
        P_Failed = 5,
        P_Complete = 6,
        F_Hold = 7,
        Date = 8
    }
}
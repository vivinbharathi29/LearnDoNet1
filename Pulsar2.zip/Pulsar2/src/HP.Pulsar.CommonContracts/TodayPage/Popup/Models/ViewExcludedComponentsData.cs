﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ViewExcludedComponentsData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Product { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "25%")]
        public string Component { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component Version", ColumnWidth = "25%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "35%")]
        public string Comment { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductLeadRootExceptionId { get; set; }
    }
}

﻿using System;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ComponentRootDetailsWWANStatusGridData : IGridGeneralOutput
    {
        [IgGridColumnAttributes(HeaderText = "Product", ColumnWidth = "10%")]
        public string DotsName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Component", ColumnWidth = "20%")]
        public string ComponentName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Available Until", Format = "MM/dd/yyyy", ColumnWidth = "10%")]
        public DateTime? AvailableUntil { get; set; }

        [IgGridColumnAttributes(ColumnWidth = "15%")]
        public string Version { get; set; }

        [IgGridColumnAttributes(HeaderText = "Vendor", ColumnWidth = "10%")]
        public string VendorName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Model", ColumnWidth = "15%")]
        public string ModelNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Part Number", ColumnWidth = "10%")]
        public string PartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "WWAN Status", ColumnWidth = "10%")]
        public string WwanTestStatus { get; set; }

        //Passed as Input paramter for the top link and row click event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int VersionId { get; set; }

        //Passed as Input paramter for the top link and row click event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductDeliverableReleaseId { get; set; }

        //Passed as Input paramter for the top link and row click event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductId { get; set; }

        //Passed as Input paramter for the top link and row click event.
        [IgGridColumnAttributes(IsHidden = true)]
        public int ComponentRootId { get; set; }
    }
}
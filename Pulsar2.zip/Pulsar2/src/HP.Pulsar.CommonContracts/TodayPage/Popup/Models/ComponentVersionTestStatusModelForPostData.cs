﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ComponentVersionTestStatusModelForPostData
    {
        public int DeliverableId { get; set; }

        public int FieldId { get; set; }

        public string OdmNotes { get; set; }

        public int ProductId { get; set; }

        public int ReleaseId { get; set; }

        public int StatusId { get; set; }

        public int UnitsReceived { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }
    }
}
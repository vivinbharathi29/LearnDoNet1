﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Repository.Models.Tiles;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class DeveloperApproval : IGridGeneralOutput
    {
        public string Status { get; set; }
        public DeveloperNotificationStatus StatusType { get; set; }
        public string CacheKey { get; set; }
    }
}

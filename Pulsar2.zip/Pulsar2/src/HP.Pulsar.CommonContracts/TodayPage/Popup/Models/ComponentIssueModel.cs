﻿using System;
using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ComponentIssueModel
    {
        public int ActionItemId { get; set; }

        public int ActionRoadmapId { get; set; }

        public ComponentIssueStatusType ComponentIssueStatus { get; set; }

        public ComponentIssueActionType ComponentIssueType { get; set; }

        public string Details { get; set; }

        public int DisplayId { get; set; }

        public int DisplayOrder { get; set; }

        public string Distribution { get; set; }

        public int Duration { get; set; }

        public bool IsAffectsCustomers { get; set; }

        public bool IsOnStatus { get; set; }

        public bool IsPreinstallOwner { get; set; }

        public string Notify { get; set; }

        public DateTime? OriginalTargetDate { get; set; }

        public string OwnerEmail { get; set; }

        public int OwnerId { get; set; }

        public string OwnerName { get; set; }

        public bool IsPendingImplementation { get; set; }

        public int Priority { get; set; }

        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public ComponentType ComponentType { get; set; }

        public string Resolution { get; set; }

        public int SponsorId { get; set; }

        public string StatusNotes { get; set; }

        public string StatusNotesUpdatedDate { get; set; }

        public string SubmitterEmail { get; set; }

        public int SubmitterId { get; set; }

        public string SubmitterName { get; set; }

        public string Summary { get; set; }

        public DateTime? TargetDate { get; set; }
    }
}

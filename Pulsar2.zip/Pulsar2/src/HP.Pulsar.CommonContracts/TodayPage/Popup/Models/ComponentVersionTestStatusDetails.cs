﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ComponentTestStatusDetails
    {
        public string DisplayNotesRequired { get; set; }

        public string OdmTestNotes { get; set; }

        public string ProductName { get; set; }

        public ComponentVersionTestStatus Status { get; set; }

        public int? UnitsReceived { get; set; }
    }
}
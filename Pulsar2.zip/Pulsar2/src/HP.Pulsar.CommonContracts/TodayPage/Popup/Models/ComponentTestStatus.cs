﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public enum ComponentTestStatus
    {
        Invalid = -1,
        None = 0,
        Investigating = 1,
        Date = 3,
        Leverage = 4,
        QComplete = 5,
        Dropped = 6,
        QHold = 7,
        ValidateOnly = 8,
        Fail = 10,
        OOC = 11,
        Planning = 15,
        FCS = 16,
        Validated = 17,
        ServiceOnly = 18
    }
}
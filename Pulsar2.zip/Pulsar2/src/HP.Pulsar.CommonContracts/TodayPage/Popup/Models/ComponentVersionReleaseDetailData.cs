﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    // Used in the poupup ComponentRootReleasePopup to Fill Form Control values
    public class ComponentVersionReleaseDetailData
    {
        public string EmailsToNotify { get; set; }
        public int ExecutionEngineerId { get; set; }
        public string ExecutionEngineerName { get; set; }
        public string FromMilestone { get; set; }
        public int FromMilestoneId { get; set; }
        public int Id { get; set; }
        public string ImagePath { get; set; }
        public string Message { get; set; }
        public string ModelNumber { get; set; }
        public string Name { get; set; }
        public string PartNumber { get; set; }
        public string ToMilestone { get; set; }
        public int ToMilestoneId { get; set; }
        public string VendorName { get; set; }
        public string Version { get; set; }
    }
}

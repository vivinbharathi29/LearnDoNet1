﻿using System;
namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class ProductAccessoryStatusForPostData
    {
        public DateTime? AccessoryDate { get; set; }

        public int BatchMode { get; set; }

        public string Comment { get; set; }

        public string KitDescription { get; set; }

        public string KitNumber { get; set; }

        public int ProductDeliverableId { get; set; }

        public AccessoryStatus Status { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }
    }
}
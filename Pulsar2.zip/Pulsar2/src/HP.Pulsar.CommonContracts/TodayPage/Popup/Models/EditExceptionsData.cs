﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class EditExceptionsData : IGridGeneralOutput
    {
        public string CheckedAllVersionsCss { get; set; }
        public string CheckedReleaseCss { get; set; }
        public string CheckedThisVersionCss { get; set; }
        public string ComponentName { get; set; }
        public int ComponentVersionId { get; set; }
        public string Exceptions { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Scope { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using HP.Pulsar.CommonContracts.EntityStatus;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class QualificationStatusData : IGridGeneralOutput
    {
        public string Category { get; set; }

        public int CategoryId { get; set; }

        public int? ChangeRequestId { get; set; }

        public IReadOnlyDictionary<string, string> ChangeRequestNumbers { get; set; } 

        public string Comment { get; set; }

        public int? ComponentRootId { get; set; }

        public string ComponentRootName { get; set; }

        public CommodityDeveloperNotificationStatus DeveloperNotificationStatus { get; set; }

        public DevCenter DevCenter { get; set; }

        public string DeveloperTestNotes { get; set; }

        public CommodityDeveloperTestStatus DeveloperTestStatus { get; set; }

        public CommodityTestStatus DeveloperTestStatusName { get; set; }

        public CommodityDevelopmentStatus DevStatus { get; set; }

        public string IntegrationTestNotes { get; set; }

        public CommodityIntegrationTestStatus IntegrationTestStatus { get; set; }

        public CommodityTestStatus IntegrationTestStatusName { get; set; }

        public bool? IsAdmin { get; set; }

        public bool IsConfigurationRestriction { get; set; }

        public bool? IsDeveloperFinalApprovalRequired { get; set; }

        public bool IsDeveloperSignoffRequired { get; set; }

        public bool IsMitSignoffRequired { get; set; }

        public bool? IsMitTestFinalApprovalRequired { get; set; }

        public bool IsOdmSignoffRequired { get; set; }

        public bool? IsOdmTestFinalApprovalRequired { get; set; }

        public bool IsPulsarProduct { get; set; }

        public bool IsSupplyChainRestriction { get; set; }

        public bool IsWwanSignOffRequired { get; set; }

        public bool? IsWwanTestFinalApprovalRequired { get; set; }

        public bool IsServicePM { get; set; }

        public bool? IsWwanProduct { get; set; }

        public string ModelNumber { get; set; }

        public string OdmTestNotes { get; set; }

        public CommodityOdmTestStatus OdmTestStatus { get; set; }

        public CommodityTestStatus OdmTestStatusName { get; set; }

        public int? PartnerId { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public int ProductId { get; set; }

        public string ProductName { get; set; }        

        public IReadOnlyDictionary<int, string> QualificationStatus { get; set; }

        public int QualificationStatusId { get; set; }

        public string ReleaseDetails { get; set; }

        public int ReleaseId { get; set; }

        public string Revision { get; set; }

        public CommodityRiskRelease RiskRelease { get; set; }

        public int? StatusId { get; set; }       

        public DateTime? TestDate { get; set; }

        public CommodityTestingComplete TestingComplete { get; set; }

        public string TTS { get; set; }

        public string TTStestStatusName { get; set; }

        public string Vendor { get; set; }

        public int? VendorId { get; set; }

        public string Version { get; set; }

        public int ComponentVersionId { get; set; }

        public string WwanTestNotes { get; set; }

        public CommodityWwanTestStatus WwanTestStatus { get; set; }

        public CommodityTestStatus WwanTestStatusName { get; set; }       
        
        public int ConfidenceId { get; set; }
    }
}

﻿namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    public class PmAccessToHardwareCondition
    {
        public bool IsCommercialPM { get; set; }

        public bool IsGraphicsControllerPM { get; set; }

        public bool IsProcessorPM { get; set; }

        public bool IsVideoMemoryPM { get; set; }
    }
}

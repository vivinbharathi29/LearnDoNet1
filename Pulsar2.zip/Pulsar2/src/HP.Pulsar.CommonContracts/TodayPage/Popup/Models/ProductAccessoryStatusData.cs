﻿using System;
using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup.Models
{
    // Used in the popup Accessory Status to Fill Form Control values.
    public class ProductAccessoryStatusData : IGridGeneralOutput
    {
        public DateTime? AccessoryDate { get; set; }
        public string AccessoryNote { get; set; }
        public IReadOnlyList<AccessoryStatusData> AccessoryStatuses { get; set; }
        public AccessoryStatus AccessoryStatus { get; set; }
        public string ComponentRootName { get; set; }
        public int Id { get; set; }
        public bool IsAccessoryDateRequired { get; set; }
        public bool IsAccessoryLeveraged { get; set; }
        public bool IsCommentRequired { get; set; }
        public bool CanShowDate { get; set; }
        public string KitDescription { get; set; }
        public string KitNumber { get; set; }
        public string ModelNumber { get; set; }
        public string PartNumber { get; set; }
        public string Pass { get; set; }
        public ComponentPilotStatus ComponentPilotStatus { get; set; }
        public DateTime? PilotDate { get; set; }
        public string Product { get; set; }
        public IReadOnlyList<ProductComponentReleaseData> ProductComponentReleases { get; set; }
        public string Revision { get; set; }
        public AccessoryStatus SelectedAccesoryStatus { get; set; }
        public DateTime? TestDate { get; set; }
        public ComponentTestStatus ComponentTestStatus { get; set; }
        public string Vendor { get; set; }
        public string Version { get; set; }
        public string VersionName { get; set; }

        public int ProductComponentReleaseId { get; set; }
        public int ReleaseId { get; set; }
        public int ProductId { get; set; }
        public int VersionId { get; set; }
    }
}
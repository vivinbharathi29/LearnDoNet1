﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup
{
    public interface IPopupGridContentModel : IPopupRootContentModel, IGridContentModel
    {
    }
}
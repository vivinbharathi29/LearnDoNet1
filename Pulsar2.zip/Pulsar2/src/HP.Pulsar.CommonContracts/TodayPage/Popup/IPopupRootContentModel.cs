﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.TodayPage.Popup
{
    public interface IPopupRootContentModel
    {
        string HeaderText { get; }

        IGridGeneralOutput PopupGeneralOutput { get; }

        int? PopupId { get; }

        string ViewName { get; }

        string RowsRenderedOperation { get; }
    }
}
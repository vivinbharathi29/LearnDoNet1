﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum CommodityIntegrationTestStatus
    {
        None = 0,
        Passed,
        Failed,
        Blocked,
        Watch,
        NA
    }
}
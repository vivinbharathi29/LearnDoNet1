﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum FeatureStatus
    {
        ActiveNoNewUsage = 0,
        Active = 1,
        Disabled = 2,
        Draft = 3,
        N = 164,
        A = 165,
        O = 166,
        NotApplicable = 167,
        New = 170,
        RASReview = 171,
        Complete = 172,
        Obsolete = 173,
        Reject = 177,
        AMODisabled = 178,
        Reenabled = 179,
        RASUpdate = 180,
        InProcess = 181,
        Added = 182,
        Changed = 183,
        Removed = 185
    }
}

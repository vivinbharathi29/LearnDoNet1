﻿using System.Collections.Generic;
using System.Linq;

namespace HP.Pulsar.CommonContracts.EntityStatus
{
    // TODO : During TodayPage to RCL, DevelopmentCenter should be moved to Infra project EnumClass folder

#pragma warning disable CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
#pragma warning disable CS0661 // Type defines operator == or operator != but does not override Object.GetHashCode()
    public sealed class DevCenter
#pragma warning restore CS0661 // Type defines operator == or operator != but does not override Object.GetHashCode()
#pragma warning restore CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    {
        public static readonly DevCenter None = new DevCenter(0, "", "", 0, -1);
        public static readonly DevCenter Houston = new DevCenter(1, "Houston", "Houston (BNB)", 1, 1);
        public static readonly DevCenter TaiwanConsumer = new DevCenter(2, "Taiwan - Consumer", "Taiwan (Consumer)", 2, 2);
        public static readonly DevCenter TaiwanCommercial = new DevCenter(3, "Taiwan - Commercial", "Taiwan (BNB)", 3, 1);
        public static readonly DevCenter Singapore = new DevCenter(4, "Singapore", "Singapore (BNB)", 4, 1);
        public static readonly DevCenter Brazil = new DevCenter(5, "Brazil", "Brazil (BNB)", 5, 1);
        // Mobility should go away because it doesn't exist in PRS database (DevCenter table)
        public static readonly DevCenter SanDiego = new DevCenter(7, "San Diego", "San Diego", 7, 1);
        public static readonly DevCenter NoDevCenter = new DevCenter(8, "No Dev. Center", "No Dev. Center", 8, 0);

        public static readonly IReadOnlyList<DevCenter> Items = new List<DevCenter>
            (new DevCenter[] {
                None,
                Houston,
                TaiwanConsumer,
                TaiwanCommercial,
                Singapore,
                Brazil,
                SanDiego,
                NoDevCenter
            });

        private DevCenter(int id, string displayName, string alias, int sequence, int businessId, bool isEnabled = true)
        {
            Id = id;
            Name = displayName;
            Alias = alias;
            Sequence = sequence;
            BusinessId = businessId;
            IsEnabled = isEnabled;
        }

        public string Name { get; }

        public string Alias { get; }

        public int Id { get; }

        public bool IsEnabled { get; }

        public int Sequence { get; }

        public int BusinessId { get; }

        public override bool Equals(object obj)
        {
            if (obj is null || !(obj is DevCenter area))
            {
                return false;
            }

            return Id == area.Id;
        }

        public static bool operator ==(DevCenter a, DevCenter b)
        {
            if (a is null || b is null)
            {
                return false;
            }

            return a.Id == b.Id;
        }

        public static bool operator !=(DevCenter a, DevCenter b)
        {
            return !(a == b);
        }

        public override string ToString()
        {
            return Name;
        }

        // This is for database conversion function
        public static object Convert(object input)
        {
            if (input != null && int.TryParse(input.ToString(), out int value))
            {
                object foundValue = Items.FirstOrDefault(d => d.Id == value);

                if (foundValue != null)
                {
                    return foundValue;
                }
            }

            return None;
        }

        public static bool TryGet(int devCenterId, out DevCenter center)
        {
            if (devCenterId == 1)
            {
                center = Houston;
                return true;
            }

            if (devCenterId == 2)
            {
                center = TaiwanConsumer;
                return true;
            }

            if (devCenterId == 3)
            {
                center = TaiwanCommercial;
                return true;
            }

            if (devCenterId == 4)
            {
                center = Singapore;
                return true;
            }

            if (devCenterId == 5)
            {
                center = Brazil;
                return true;
            }

            if (devCenterId == 7)
            {
                center = SanDiego;
                return true;
            }

            if (devCenterId == 8)
            {
                center = NoDevCenter;
                return true;
            }

            center = null;
            return false;
        }
    }
}
﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum CommodityTestStatus
    {
        TBD = 0,
        Passed,
        Failed,
        Blocked,
        Watch,
        NotApplicable
    }
}
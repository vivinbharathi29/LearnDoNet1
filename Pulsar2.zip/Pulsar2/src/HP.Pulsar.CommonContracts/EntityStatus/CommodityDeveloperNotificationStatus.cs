﻿namespace HP.Pulsar.CommonContracts.EntityStatus
{
    public enum CommodityDeveloperNotificationStatus
    {
        Waiting = 0,
        Approved,
        NotApproved
    }
}
﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.EntityStatus
{
    //TODO This Class to be added to Infra Project Later
    //This Enum is from the table teststatus
    public class QualificationStatusType
    {
        public static readonly QualificationStatusType None = new QualificationStatusType(-1, string.Empty);
        public static readonly QualificationStatusType NotUsedNow = new QualificationStatusType(0, "Not Used Now");
        public static readonly QualificationStatusType Investigating = new QualificationStatusType(1, "Investigating");
        public static readonly QualificationStatusType Date = new QualificationStatusType(3, "Date");
        public static readonly QualificationStatusType Leverage = new QualificationStatusType(4, "Leverage");
        public static readonly QualificationStatusType QComplete = new QualificationStatusType(5, "QComplete");
        public static readonly QualificationStatusType Dropped = new QualificationStatusType(6, "Dropped");
        public static readonly QualificationStatusType QHold = new QualificationStatusType(7, "QHold");
        public static readonly QualificationStatusType ValidateOnly = new QualificationStatusType(8, "Validate Only");
        public static readonly QualificationStatusType Fail = new QualificationStatusType(10, "Fail");
        public static readonly QualificationStatusType OOC = new QualificationStatusType(11, "OOC");
        public static readonly QualificationStatusType Planning = new QualificationStatusType(15, "Planning");
        public static readonly QualificationStatusType FCS = new QualificationStatusType(16, "FCS");
        public static readonly QualificationStatusType Validated = new QualificationStatusType(17, "Validated");
        public static readonly QualificationStatusType ServiceOnly = new QualificationStatusType(18, "Service Only");

        private QualificationStatusType(int id, string name)
        {
            Name = name;
            Id = id;
        }

        public string Name { get; set; }

        public int Id { get; set; }

        public static IReadOnlyDictionary<int, string> GetItems()
        {
            return new Dictionary<int, string>
            {
                [Date.Id] = Date.Name,
                [Dropped.Id] = Dropped.Name,
                [Fail.Id] = Fail.Name,
                [FCS.Id] = FCS.Name,
                [Investigating.Id] = Investigating.Name,
                [Leverage.Id] = Leverage.Name,
                [NotUsedNow.Id] = NotUsedNow.Name,
                [OOC.Id] = OOC.Name,
                [Planning.Id] = Planning.Name,
                [QComplete.Id] = QComplete.Name,
                [QHold.Id] = QHold.Name,
                [ServiceOnly.Id] = ServiceOnly.Name,
                [ValidateOnly.Id] = ValidateOnly.Name,
                [Validated.Id] = Validated.Name,
            };
        }

        public static QualificationStatusType GetModel(int statusTypeId)
        {
            if (statusTypeId == NotUsedNow.Id)
            {
                return NotUsedNow;
            }

            if (statusTypeId == Investigating.Id)
            {
                return Investigating;
            }

            if (statusTypeId == Date.Id)
            {
                return Date;
            }

            if (statusTypeId == Leverage.Id)
            {
                return Leverage;
            }

            if (statusTypeId == QComplete.Id)
            {
                return QComplete;
            }

            if (statusTypeId == Dropped.Id)
            {
                return Dropped;
            }

            if (statusTypeId == QHold.Id)
            {
                return QHold;
            }

            if (statusTypeId == ValidateOnly.Id)
            {
                return ValidateOnly;
            }

            if (statusTypeId == Fail.Id)
            {
                return Fail;
            }

            if (statusTypeId == OOC.Id)
            {
                return OOC;
            }

            if (statusTypeId == Planning.Id)
            {
                return Planning;
            }

            if (statusTypeId == FCS.Id)
            {
                return FCS;
            }

            if (statusTypeId == Validated.Id)
            {
                return Validated;
            }

            if (statusTypeId == ServiceOnly.Id)
            {
                return ServiceOnly;
            }

            return None;
        }
    }
}

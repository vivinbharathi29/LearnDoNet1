﻿using System;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IPulsarDataReader
    {
        int RowCount { get; }

        bool HasRecord { get; }

        bool TryGetBoolValue(int columnIndex, int rowIndex, out bool? value);

        bool TryGetBoolValue(string columnName, int rowIndex, out bool? value);

        bool TryGetDateTimeValue(int columnIndex, int rowIndex, out DateTime? vallue);

        bool TryGetDateTimeValue(string columnName, int rowIndex, out DateTime? value);

        bool TryGetInt64Value(int columnIndex, int rowIndex, out long? value);

        bool TryGetInt64Value(string columnName, int rowIndex, out long? value);

        bool TryGetIntValue(int columnIndex, int rowIndex, out int? value);

        bool TryGetIntValue(string columnName, int rowIndex, out int? value);

        bool TryGetStringValue(int columnIndex, int rowIndex, out string value);

        bool TryGetStringValue(string columnName, int rowIndex, out string value);
    }
}

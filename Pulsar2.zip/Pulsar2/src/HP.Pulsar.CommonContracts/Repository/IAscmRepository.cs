﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.TodayPage.Tiles.Models;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IAscmRepository
    {
        Task<(IReadOnlyList<AddAMOFeaturesToASCMTileDataFromTile> DataList, int DataCount)> GetAddAMOFeaturesToASCMAsync(int userId, IPaginationModel pagination);

        Task<int> GetAddAMOFeaturesToASCMCountAsync(int userId);

        Task<bool> UpdateNewAMORequestedNotActionable(string featureId);

        Task<bool> UpdateNewAMOFeatureToASCMDataAsync(int featureId, string amoSkuTypes, string productLines, string localizations, int userId);
    }
}
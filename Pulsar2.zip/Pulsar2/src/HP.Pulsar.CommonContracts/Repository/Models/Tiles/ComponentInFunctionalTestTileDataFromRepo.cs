﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class ComponentInFunctionalTestTileDataFromRepo
    {
        public string BuildLevel { get; set; }

        public int ComponentRootId { get; set; }

        public string DeliverableRootName { get; set; }

        public int ComponentVersionId { get; set; }

        public string Developer { get; set; }

        public string Pass { get; set; }

        public DateTime PlannedCompletion { get; set; }

        public string Revision { get; set; }

        public string Team { get; set; }

        public string TransferPath { get; set; }

        public string Version { get; set; }
    }
}
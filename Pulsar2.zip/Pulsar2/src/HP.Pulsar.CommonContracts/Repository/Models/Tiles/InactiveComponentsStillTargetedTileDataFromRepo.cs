﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class InactiveComponentsStillTargetedTileDataFromRepo
    {
        public DateTime? EOLDate { get; set; }

        public int ComponentVersionId { get; set; }

        public string ModelNumber { get; set; }

        public string Name { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public string Product { get; set; }

        public int ProductId { get; set; }

        public string Release { get; set; }

        public string Revision { get; set; }

        public int RootId { get; set; }

        public string Version { get; set; }
    }
}

﻿using System;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ApprovalRequestedReleaseToProductionTileDataFromRepo
    {
        public int Id { get; set; }
        public string Product { get; set; }
        public string Vendor { get; set; }
        public string ModelNumber { get; set; }
        public string PartNumber { get; set; }
        public int ProductDeliverableReleaseId { get; set; }
        public ComponentsTestStatus IntegrationTestStatus { get; set; }
        public ComponentsTestStatus OdmTestStatus { get; set; }
        public string Pass { get; set; }
        public int ComponentId { get; set; }
        public string ComponentName { get; set; }
        public int ProductId { get; set; }
        public string Revision { get; set; }
        public int RootId { get; set; }
        public DateTime? TestDate { get; set; }
        public ComponentsTestStatus TestStatusId { get; set; }
        public string Version { get; set; }
        public ComponentsTestStatus WwanTestStatus { get; set; }
    }
}

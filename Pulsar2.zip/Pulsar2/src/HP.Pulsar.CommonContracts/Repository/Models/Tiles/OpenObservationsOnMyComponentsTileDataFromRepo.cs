﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class OpenObservationsOnMyComponentsTileDataFromRepo
    {
        public string Component { get; set; }

        public string ComponentVersion { get; set; }

        public long ObservationId { get; set; }

        public string OwnerName { get; set; }

        public string Priority { get; set; }

        public string Product { get; set; }

        public string ShortDescription { get; set; }

        public string State { get; set; }
    }
}

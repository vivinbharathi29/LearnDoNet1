﻿using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.TodayPage.Tiles.Models
{
    public class ChangeRequestTilesDataFromRepo
    {
        public int Id { get; set; }

        public ComponentIssueType IssueType { get; set; }

        public string Owner { get; set; }

        public string ProductName { get; set; }

        public ChangeRequestStatus Status { get; set; }

        public string Submitter { get; set; }

        public string Summary { get; set; }
    }
}

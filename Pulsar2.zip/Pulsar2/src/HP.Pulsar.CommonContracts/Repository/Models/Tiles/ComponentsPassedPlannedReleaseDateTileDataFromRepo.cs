﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class ComponentsPassedPlannedReleaseDateTileDataFromRepo
    {
        public string Developer { get; set; }

        public int Id { get; set; }

        public string IrsPartNumber { get; set; }

        public string Location { get; set; }

        public string ModelNumber { get; set; }

        public string Name { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public DateTime? PlannedDate { get; set; }

        public string Revision { get; set; }

        public int RootId { get; set; }

        public int? TypeId { get; set; }

        public string Vendor { get; set; }

        public string Version { get; set; }
    }
}

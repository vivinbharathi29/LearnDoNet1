﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class EngineeringDevelopmentWorkingListTileDataFromRepo
    {
        public int? CategoryId { get; set; }

        public int Id { get; set; }

        public string ModelNumber { get; set; }

        public string Name { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public string Revision { get; set; }

        public int RootId { get; set; }

        public string Vendor { get; set; }

        public string Version { get; set; }
    }
}

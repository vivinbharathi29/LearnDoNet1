﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class PastDueScheduleItemsTileDataFromRepo
    {
        public DateTime? ActualEndDate { get; set; }

        public DateTime? ActualStartDate { get; set; }

        public bool? IsFusionRequired { get; set; }

        public string Milestone { get; set; }

        public string MilestoneStatus { get; set; }

        public string OwnerName { get; set; }

        public string ProductName { get; set; }

        public DateTime? ProjectedEndDate { get; set; }

        public DateTime? ProjectedStartDate { get; set; }

        public int ScheduleDataId { get; set; }

        public string ScheduleName { get; set; }
    }
}
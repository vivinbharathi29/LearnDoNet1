﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Tiles
{
    public class DeveloperRequestsRemovalFromProductTileDataFromRepo
    {
        public string Component { get; set; }

        public string DeveloperName { get; set; }

        public string DeveloperNotes { get; set; }

        public string Pass { get; set; }

        public string ProductName { get; set; }

        public int ProductId { get; set; }

        public string Release { get; set; }

        public string Revision { get; set; }

        public int RootId { get; set; }

        public string Version { get; set; }

        public int VersionId { get; set; }
    }
}

﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentVersionPropertiesDataFromRepo
    {
        public int ComponentRootId { get; set; }

        public int? ComponentRootTypeId { get; set; }

        public int ComponentVersionId { get; set; }

        public string ComponentVersionName { get; set; }

        public string ModelNumber { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public string Revision { get; set; }

        public string VendorName { get; set; }

        public string Version { get; set; }

        public string VersionVendor { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class IRSComponentUpdateListDataFromRepo
    {
        public string ComponentName { get; set; }
        public string ImageSummary { get; set; }
        public IReadOnlyList<string> OperatingSystems { get; set; }
        public string PartNumber { get; set; }
        public string Pass { get; set; }
        public int? PreviousVersionCount { get; set; }
        public string PreviousVersionPartNumber { get; set; }
        public string Product { get; set; }
        public string Revision { get; set; }
        public string TargetNote { get; set; }
        public string TransferStatus { get; set; }
        public string ComponentVersionName { get; set; }
        public int ComponentVersionId { get; set; }
    }
}
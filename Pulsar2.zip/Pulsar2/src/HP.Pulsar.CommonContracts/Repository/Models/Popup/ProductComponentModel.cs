﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ProductComponentModel
    {
        public bool IsBridged { get; set; }

        public string PartNumber { get; set; }

        public string ComponentName { get; set; }

        public string ProductName { get; set; }

        public string Subassembly { get; set; }

        public string ComponentRootName { get; set; }
    }
}

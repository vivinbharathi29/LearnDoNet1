﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public enum ChangeRequestStatus
    {
        NewRequest = 0,
        Open,
        Closed,
        NeedMoreInfo,
        Approved,
        Disapproved,
        Investigating,
        NotApplicable
    }
}
﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentVersionFamilyDataFromRepo
    {
        public string ProductFamily { get; set; }

        public string ProductVersion { get; set; }
    }
}
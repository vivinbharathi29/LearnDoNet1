﻿using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentPartNumberDataFromRepo : IGridGeneralOutput
    {
        public int ComponentVersionId { get; set; }

        public string ComponentName { get; set; }

        public string PartNumber { get; set; }

        public string Revision { get; set; }

        public string Version { get; set; }        

        public string Vendor { get; set; }
    }
}

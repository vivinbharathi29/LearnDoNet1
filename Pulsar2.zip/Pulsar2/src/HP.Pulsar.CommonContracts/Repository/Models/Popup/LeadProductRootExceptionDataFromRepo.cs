﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class LeadProductRootExceptionDataFromRepo
    {
        public string Comments { get; set; }

        public bool IsDistributionSynced { get; set; }

        public bool IsImageSynced { get; set; }

        public bool IsNoteSynced { get; set; }
    }
}
﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class NextMilestoneDataFromRepo
    {
        public string Milestone { get; set; }

        public int MilestoneId { get; set; }
    }
}

﻿using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class AccessoryStatusDataFromRepo
    {
        public byte? DateField { get; set; }
        public AccessoryStatus AccessoryStatus { get; set; }
        public bool IsCommentRequired { get; set; }
        public string Name { get; set; }
    }
}
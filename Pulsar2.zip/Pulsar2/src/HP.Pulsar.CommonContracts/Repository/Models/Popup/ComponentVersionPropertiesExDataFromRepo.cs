﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentVersionPropertiesExDataFromRepo
    {
        public string CDPartNumber { get; set; }
        public string Changes { get; set; }
        public string Comment { get; set; }
        public int? ComponentRootTypeId { get; set; }
        public string DeliverableName { get; set; }
        public string Description { get; set; }
        public string Developer { get; set; }
        public string DevManager { get; set; }
        public string FileName { get; set; }
        public string ImagePath { get; set; }
        public string ModelNumber { get; set; }
        public string Note { get; set; }
        public string PartNumber { get; set; }
        public string Pass { get; set; }
        public string Revision { get; set; }
        public int RootId { get; set; }
        public DateTime? SampleAvailableDate { get; set; }
        public string VendorName { get; set; }
        public string Version { get; set; }
        public int VersionId { get; set; }
        public string VersionVendor { get; set; }
    }
}
﻿using System;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ProductAccessoryStatusDataFromRepo
    {
        public DateTime? AccessoryDate { get; set; }
        public string AccessoryNotes { get; set; }
        public AccessoryStatus AccessoryStatus { get; set; }
        public string ComponentName { get; set; }
        public int Id { get; set; }
        public bool IsAccessoryLeveraged { get; set; }
        public string KitDescription { get; set; }
        public string KitNumber { get; set; }
        public string ModelNumber { get; set; }
        public string PartNumber { get; set; }
        public string Pass { get; set; }
        public DateTime? PilotDate { get; set; }
        public ComponentPilotStatus PilotStatus { get; set; }
        public string Product { get; set; }
        public string Revision { get; set; }
        public DateTime? TestDate { get; set; }
        public ComponentTestStatus TestStatus { get; set; }
        public string Vendor { get; set; }
        public string Version { get; set; }
    }
}
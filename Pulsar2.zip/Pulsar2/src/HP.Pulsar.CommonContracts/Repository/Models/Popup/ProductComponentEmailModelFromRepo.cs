﻿using HP.Pulsar.CommonContracts.EntityStatus;


namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ProductComponentEmailModelFromRepo
    {
        public string ComponentName { get; set; }
        public string DeveloperTestNotes { get; set; }
        public DeveloperTestStatus DeveloperTestStatus { get; set; }
        public string ModelNumber { get; set; }
        public string PartNumber { get; set; }
        public string Pass { get; set; }
        public string PMFieldName { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Revision { get; set; }
        public string Vendor { get; set; }
        public string Version { get; set; }
        public int ComponentVersionId { get; set; }
    }
}

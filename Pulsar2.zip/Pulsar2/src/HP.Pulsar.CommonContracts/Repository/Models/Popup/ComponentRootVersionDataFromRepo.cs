﻿using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentRootVersionDataFromRepo
    {
        public string ComponentRootName { get; set; }

        public int ComponentVersionId { get; set; }

        public ConsumerReleaseStatusType ConsumerReleaseStatus { get; set; }

        public CommercialReleaseStatusType CommercialReleaseStatus { get; set; }

        public int ComponentRootTypeId { get; set; }

        public string DeveloperEmail { get; set; }

        public string DevManagerEmail { get; set; }

        public string ImagePath { get; set; }

        public bool IsHFCN { get; set; }

        public bool IsWwanFailureConfirmed { get; set; }

        public bool IsTTSRequires { get; set; }

        public string ModelNumber { get; set; }

        public string Notifications { get; set; }

        public string PartNumber { get; set; }

        public string Pass { get; set; }

        public string Revision { get; set; }

        public int TesterId { get; set; }

        public string TTS { get; set; }

        public string Version { get; set; }

        public string VendorName { get; set; }
    }
}

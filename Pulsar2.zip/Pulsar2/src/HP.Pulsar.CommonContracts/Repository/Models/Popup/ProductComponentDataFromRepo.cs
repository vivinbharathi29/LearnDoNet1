﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    //This repository model is used in compare root lead proudct popup & popup id is 23. 
    //The tile name is Lead Product - Synchronization Issues. Tile Id 8.
    public class ProductComponentDataFromRepo
    {
        public int ComponentVersionId { get; set; }

        public string Distribution { get; set; }

        public string ImageSummary { get; set; }

        public bool IsLeadOrProduct { get; set; }

        public bool? IsTargeted { get; set; }

        public string TargetNotes { get; set; }

        public string Version { get; set; }
    }
}

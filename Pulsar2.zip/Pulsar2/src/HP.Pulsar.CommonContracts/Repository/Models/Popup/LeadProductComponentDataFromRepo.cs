﻿namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class LeadProductComponentDataFromRepo
    {
        public bool IsDistributionSynchronized { get; set; }

        public bool IsImageSynchronized { get; set; }

        public bool IsNotesSynchronized { get; set; }

        public bool IsNeedSupport { get; set; }

        public string Pass { get; set; }

        public string Revision { get; set; }

        public string Version { get; set; }

        public int ComponentVersionId { get; set; }
    }
}
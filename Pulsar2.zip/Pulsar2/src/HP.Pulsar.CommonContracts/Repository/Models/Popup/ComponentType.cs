﻿using System;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    // TODO - replace this enum by HP.Pulsar.Infrastructure.CommonModels.Application.ComponentType
    [Obsolete("Do not use this enum. New class is at HP.Pulsar.Infrastructure.CommonModels.Application")]
    public enum ComponentType
    {
        None = 0,
        Hardware = 1,
        Software = 2,
        Firmware = 3,
        Documentation = 4,
    }
}
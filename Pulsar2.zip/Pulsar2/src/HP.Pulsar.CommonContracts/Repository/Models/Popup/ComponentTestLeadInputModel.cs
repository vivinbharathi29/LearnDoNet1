﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.Repository.Models.Popup
{
    public class ComponentTestLeadInputModel
    {
        public IReadOnlyList<int> ComponentIds { get; set; }

        public int? ProductId { get; set; }

        public IReadOnlyList<int> ReleaseIds { get; set; }

        public IReadOnlyList<int> VersionIds { get; set; }
    }
}
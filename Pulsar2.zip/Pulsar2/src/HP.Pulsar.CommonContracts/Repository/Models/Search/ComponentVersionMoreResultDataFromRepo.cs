﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HP.Pulsar.CommonContracts.Repository.Models.Search
{
    public class ComponentVersionMoreResultDataFromRepo
    {
        public int ComponentVersionId { get; set; }

        public string ComponentVersionName { get; set; }

        public string Version { get; set; }

        public string Revision { get; set; }

        public string Pass { get; set; }

        public string PartNumber { get; set; }

        public string ModelNumber { get; set; }

        public string Workflow { get; set; }

        public bool IsDeactivated { get; set; }

        public string Url { get; set; }

        public int ComponentRootId { get; set; }

        public DateTime? DisabledDate { get; set; }
    }
}

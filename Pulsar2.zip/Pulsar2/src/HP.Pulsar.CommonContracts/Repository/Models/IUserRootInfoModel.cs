﻿namespace HP.Pulsar.CommonContracts.Repository.Models
{
    public interface IUserRootInfoModel
    {
        string DomainName { get; }

        string Email { get; }

        string FirstName { get; }

        int Id { get; }

        string LastName { get; }

        string UserAlias { get; }
    }
}

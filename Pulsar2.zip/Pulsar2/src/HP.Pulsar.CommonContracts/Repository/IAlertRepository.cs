﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;
using HP.Pulsar.CommonContracts.Repository.Models.Tiles;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;
using HP.Pulsar.CommonContracts.TodayPage.Tiles.Models;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IAlertRepository
    {
        // The method is called in Accessory Status Popup
        Task<IReadOnlyList<AccessoryStatusDataFromRepo>> GetAccessoryStatusesAsync();

        Task<IReadOnlyList<(int UserId, string Role)>> GetAllTestLeadsAsync();

        Task<(IReadOnlyList<AvsNotMappedToSpareKitsTileData> DataList, int DataCount)> GetAvsNotMappedToSpareKitsAsync(int userId, IPaginationModel pagination);

        Task<int> GetAvsNotMappedToSpareKitsCountAsync(int userId);

        Task<IReadOnlyList<string>> GetComponentCommodityPMEmailsAsync(int componentRootId);

        Task<string> GetComponentForMultiQualificationStatusName(int componentRootId, int productId);

        Task<(IReadOnlyList<ComponentInTestLeadSharedTileDataFromTile> DataList, int DataCount)> GetComponentInTestLeadAsync(int userId, string componentName, IPaginationModel pagination);

        Task<int> GetComponentInTestLeadCountAsync(int userId, string componentName);

        Task<(int MilestoneId, string Milestone)> GetComponentNextMilestonesAsync(int componentRootId, int milestoneId);

        Task<IReadOnlyList<ComponentRootVersionDataFromRepo>> GetComponentReleaseVersionsAsync(string versionId);

        Task<(IReadOnlyList<ComponentRootDetailsDataFromRepo> DataList, int DataCount)> GetComponentRootInfoForTestLeadAsync(ComponentTestLeadInputModel componentTestLead, IPaginationModel pagination);

        Task<IReadOnlyList<ComponentVersionFamilyDataFromRepo>> GetComponentRootProductFamilyVersionAsync(int componentVersionId);

        Task<IReadOnlyList<ComponentVersionLanguageDataFromRepo>> GetComponentRootProductLanguagesAsync(int componentVersionId);

        Task<(IReadOnlyList<ComponentsAwaitingFinalApprovalTileGridDataFromTile> DataList, int DataCount)> GetComponentsAwaitingFinalApprovalAsync(int userId, IPaginationModel pagination);

        Task<int> GetComponentsAwaitingFinalApprovalCountAsync(int userId);

        Task<IReadOnlyList<string>> GetComponentSelectedOSNamesAsync(int componentVersionId);

        Task<IReadOnlyList<string>> GetComponentTestLeadsAsync(int componentRootId);

        Task<(int UserId, string UserEmail, string FullName)> GetComponentVersionExecutionEngineersAsync(int componentVersionId);

        Task<IReadOnlyList<string>> GetComponentVersionOTSNumbersAsync(int componentVersionId);

        Task<ComponentVersionPropertiesExDataFromRepo> GetComponentVersionPropertiesAsync(int componentVersionId);

        Task<int> GetComponentVersionReleaseId(int productId);

        Task<TestLeadStatusDataFromRepo> GetComponentVersionTestStatusForPulsarProductAsync(int productDeliverableReleaseId, int fieldId);

        Task<IReadOnlyList<ComponentVersionReleaseDetailsDataFromRepo>> GetComponentVersionTestStatusReleaseDetailsAsync(int productId, int versionId, int releaseId);

        Task<(IReadOnlyList<CoreTeamWorkingListTileDataFromTile> DataList, int DataCount)> GetCoreTeamWorkingListAsync(int userId, IPaginationModel pagination);

        Task<int> GetCoreTeamWorkingListCountAsync(int userId);

        Task<ComponentVersionDataFromRepo> GetDeliverableVersionPropertiesAsync(int componentVersionID);

        Task<(IReadOnlyList<EngineeringDevelopmentWorkingListTileDataFromRepo> DataList, int DataCount)> GetEngineeringDevelopmentWorkingListAsync(string state, int userId, IPaginationModel pagination);

        Task<int> GetEngineeringDevelopmentWorkingListCountAsync(string state, int devManId);

        Task<(IReadOnlyList<ErrorTransmittingFilesToPreinstallServerTileDataFromTile> DataList, int DataCount)> GetErrorTransmittingFilesToPreinstallServerAsync(int userId, IPaginationModel pagination);

        Task<int> GetErrorTransmittingFilesToPreinstallServerCountAsync(int userId);

        Task<(IReadOnlyList<ExpiredPilotScheduleDatesTileDataFromTile> DataList, int DataCount)> GetExpiredPilotScheduleDatesAsync(int userId, IPaginationModel pagination);

        Task<int> GetExpiredPilotScheduleDatesCountAsync(int userId);

        Task<(IReadOnlyList<FeatureRootRequestsRejectedTileDataFromTile> DataList, int DataCount)> GetFeatureRootRequestsRejectedAsync(int userId, IPaginationModel pagination);

        Task<int> GetFeatureRootRequestsRejectedCountAsync(int userId);

        Task<ProductsWithMissingHwPmTileGridDataFromRepo> GetHardwarePMProductSummaryAsync(int userId);

        Task<(IReadOnlyList<HelpAndSupportUpcomingReleasesTileDataFromTile> DataList, int DataCount)> GetHelpAndSupportUpcomingReleasesAsync(int reportId, IPaginationModel pagination);

        Task<int> GetHelpAndSupportUpcomingReleasesCountAsync(int reportId);

        Task<(IReadOnlyList<InactiveComponentsStillTargetedTileDataFromRepo> DataList, int DataCount)> GetInactiveComponentsStillTargetedAsync(int userId, IPaginationModel pagination);

        Task<int> GetInactiveComponentsStillTargetedCountAsync(int userId);

        Task<(IReadOnlyList<LinkedComponentsNotUsedByCommodityTeamTileDataFromTile> DataList, int DataCount)> GetLinkedComponentsNotUsedByCommodityTeamAsync(int userId, IPaginationModel pagination);

        Task<int> GetLinkedComponentsNotUsedByCommodityTeamCountAsync(int userId);

        Task<(IReadOnlyList<MissingBaseUnitSubAssemblyNumbersTileData> DataList, int DataCount)> GetMissingBaseUnitSubAssemblyNumbersAsync(int userId, IPaginationModel pagination);

        Task<int> GetMissingBaseUnitSubAssemblyNumbersCountAsync(int userId);

        Task<(IReadOnlyList<MissingSubassemblyNumbersTileDataFromTile> DataList, int DataCount)> GetMissingSubassemblyNumbersAsync(int userId, IPaginationModel pagination);

        Task<int> GetMissingSubassemblyNumbersCountAsync(int userId);

        Task<int> GetMissingSupplierCodesCountAsync(int userId);

        Task<(IReadOnlyList<MissingSupplierCodesTileDataFromTile> DataList, int DataCount)> GetMissingSupplierCodesdAsync(int userId, IPaginationModel pagination);

        Task<(IReadOnlyList<NewComponentRequestsTileDataFromRepo> DataList, int DataCount)> GetNewComponentRequestsAsync(int userId, IPaginationModel pagination);

        Task<int> GetNewComponentRequestsCountAsync(int userId);

        Task<(IReadOnlyList<NewHardwareComponentsReleasedForMyProductsTileDataFromTile>, int)> GetNewHardwareComponentsReleasedForMyProductsAsync(int userId, IPaginationModel pagination);

        Task<int> GetNewHardwareComponentsReleasedForMyProductsCountAsync(int userId);

        Task<(IReadOnlyList<ObservationsTileDataFromTile> DataList, int DataCount)> GetObservationsTransferRequestedAsync(int userId, string type, IPaginationModel pagination);

        Task<int> GetObservationsTransferRequestedCountAsync(int userId, string type);

        Task<(IReadOnlyList<ObservationsTileDataFromTile> DataList, int DataCount)> GetObservationsUnassignedAsync(int userId, string type, IPaginationModel pagination);

        Task<int> GetObservationsUnassignedCountAsync(int userId, string type);

        Task<AccessoryStatus> GetProductAccessoryStatusAsync(int productComponentId);

        Task<IReadOnlyList<ProductComponentReleaseData>> GetProductComponentReleasesAsync(int productId, int versionId, int productComponentReleaseId, int releaseId, string todayPageSection);

        Task<int> GetProductDefaultReleaseIdAsync(int productId);

        Task<(IReadOnlyList<ProductMultiQualificationStatusDataFromRepo> DataList, int DataCount)> GetProductMultiTestStatusForMultiProductProductAsync(string productDeliverableIds, string productIds, IPaginationModel pagination);

        Task<(IReadOnlyList<ProductMultiQualificationStatusDataFromRepo> DataList, int DataCount)> GetProductMultiTestStatusForPulsarProductAsync(int rootId, int productVersionId, IPaginationModel pagination);

        Task<(IReadOnlyList<ProductsWithMissingHwPmTileGridDataFromRepo> DataList, int DataCount)> GetProductsWithMissingHwPmAsync(int userId, bool isConsumer, bool isCommericial, IPaginationModel pagination);

        Task<string> GetProductVersionDetailsAsync(int productId);

        Task<string> GetProductVersionNameAsync(int productId, int releaseId = 0);

        Task<(IReadOnlyList<SparekitsNotMappedtoAvsTileDataFromTile> DataList, int DataCount)> GetSpareKitsNotMappedtoAvsAsync(int userId, IPaginationModel pagination);

        Task<int> GetSpareKitsNotMappedtoAvsCountAsync(int userId);

        Task<(IReadOnlyList<SpareKitsNotStructuredToFamilyTileDataFromTile> DataList, int DataCount)> GetSpareKitsNotStructuredToFamilyAsync(int userId, IPaginationModel pagination);

        Task<int> GetSpareKitsNotStructuredToFamilyCountAsync(int userId);

        Task<TestLeadStatusDataFromRepo> GetTestLeadStatusAsync(int productId, int versionId, int fieldId);

        Task<(IReadOnlyList<ComponentsPassedPlannedReleaseDateTileDataFromRepo> DataList, int DataCount)> GetComponentsPassedPlannedReleaseDateAsync(int userId, IPaginationModel pagination);

        Task<int> GetComponentsPassedPlannedReleaseDateCountAsync(int userId);

        Task<IReadOnlyList<ComponentWorkflowStepsInProgressDataFromRepo>> GetComponentWorkflowStepsInProgressAsync(int componentRootId);

        Task<IReadOnlyList<MilestonePlanScheduleUpdateDataFromRepo>> GetMilestoneplanscheduleupdateDataAsync(int componentRootId, int componentVersionId);

        Task<ProductAccessoryStatusDataFromRepo> GetProductAccessoryStatusAsync(int productId, int versionId);

        Task<ProductAccessoryStatusDataFromRepo> GetProductAccessoryStatusForPulsarProductAsync(int productId, int versionId, int productComponentReleaseId);

        Task<int> GetProductsWithMissingHwPmCountAsync(int userId, bool isConsumer, bool isCommericial);

        Task<IReadOnlyList<ComponentVersionPropertiesDataFromRepo>> GetVersionPropertiesForWebAsync(int versionId);

        Task<bool> HasRowsInAddIgnoreAvAsync(string kmat, string avNo);

        Task<bool> UnlinkComponentVersionFromProduct(int productId, int componentVersionId);

        Task<bool> UnlinkComponentVersionFromProductRelease(int productId, int componentId, int productComponentReleaseId);

        Task UpdateComponentRootLanguageLocationAsync(int componentRootId, int languageId, int milestoneId, bool isWorkflowCompleted, bool isFailed);

        Task UpdateComponentRootSchedule(int componentRootId, int milestoneId);

        Task<bool> UpdateComponentVersionTestStatusForLegacyProductAsync(ComponentVersionTestStatusModelForPostData componentTestStatusModel);

        Task<bool> UpdateComponentVersionTestStatusForPulsarProductAsync(ComponentVersionTestStatusModelForPostData componentTestStatusModel);

        Task<bool> UpdateProductAccessoryStatusAsync(ProductAccessoryStatusForPostData productAccessoryStatus);

        Task<bool> UpdateProductAccessoryStatusForPulsarProductAsync(ProductAccessoryStatusForPostData productAccessoryStatus);

        Task<bool> UpdateQualificationStatusReleaseAsync(ProductMultiQualificationStatusForPostData qualificationStatus);

        Task UpdateComponentRootMilestoneRelease(int componentRootId, int milestoneId);

        Task UpdateComponentRootMilestoneFailure(int componentRootId, int milestoneId);

        Task UpdateComponentRootReleaseLog(int componentRootId, int userId);

        Task UpdateComponentRootReassignDeveloper(int componentRootId, int developerId);

        Task UpdateComponentRootLocation(int componentRootId);

        Task UpdateComponentRootForRelease(int componentRootId, int nextMilestoneId, string fileName, string transferPath, string comments);

        Task<bool> UpdateComponentRootDetails(IReadOnlyList<ComponentVersionReleaseModelForPostData> componentRootVersionData, int userId, ComponentVersionOperation action);

        Task<bool> UpdatetMilestonePlanScheduleAsync(int Id, DateTime? plannedDate);

        Task<bool> UpdateTestLeadStatusForLegacyProductAsync(int productId, int componentId, int fieldId, int userId, string userName, int statusId, string developerTestNotes);

        Task<(IReadOnlyList<ApprovalRequestedReleaseToProductionTileDataFromRepo> DataList, int DataCount)> GetApprovalRequestedReleaseToProductionAsync(int userId, IPaginationModel pagination);

        Task<int> GetApprovalRequestedReleaseToProductionCountAsync(int userId);

        Task<(IReadOnlyList<FeaturesRequestingRootComponentsTileDataFromTile> DataList, int DataCount)> GetFeaturesRequestingRootComponentsAsync(int userId, IPaginationModel pagination);

        Task<int> GetFeaturesRequestingRootComponentsCountAsync(int userId);

        Task<bool> UpdateRejectFeatureRequestAsync(int featureId, string rejectReason, int userId);

        Task<bool> UpdateTestLeadStatusForPulsarProductAsync(int productDeliverableReleaseId, int productId, int componentId, int fieldId, int userId, string userName, int statusId, string developerTestNotes);

        Task<bool> UpdateTestLeadStatusLegacyAndPulsarAsync(TestLeadStatusLegacyAndPulsarPostData testLeadStatusLegacyAndPulsar);

        Task<int> GetHardwareComponentsWithNoPartNumberCountAsync(int userId);

        Task<(IReadOnlyList<HardwareComponentsWithNoPartNumberTileGridDataFromTile> DataList, int DataCount)> GetHardwareComponentsWithNoPartNumberAsync(int userId, IPaginationModel pagination);

        Task<bool> TryUpdateNewComponentRequestForLegacyProductWithMultipleItemAsync(NewComponentRequestDetailsModel componentRequest);

        Task<bool> TryUpdateNewComponentRequestForPulsarProductWithMultipleItemAsync(NewComponentRequestDetailsModel componentRequest);

        Task<IReadOnlyList<LegacyProductComponentDetailsModel>> GetComponentDetailsForLegacyProductWithMultiItemAsync(IReadOnlyList<int> componentRootIds);

        Task<IReadOnlyList<PulsarProductComponentDetailsModel>> GetComponentDetailsForPulsarProductWithMultiItemAsync(IReadOnlyList<int> componentVersionIds);

        Task<bool> TryUpdateQualificationStatusForLegacyComponentAsync(ComponentQualificationStatusUpdateModel qualificationStatusModel);

        Task<bool> TryUpdateQualificationStatusForPulsarComponentAsync(ComponentQualificationStatusUpdateModel qualificationStatusModel);
    }
}
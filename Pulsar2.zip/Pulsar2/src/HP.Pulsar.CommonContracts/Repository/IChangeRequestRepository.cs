﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.TodayPage.Tiles.Models;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IChangeRequestRepository
    {
        Task<(IReadOnlyList<ChangeRequestClosedIn7DaysTileDataFromTile> DataList, int DataCount)> GetChangeRequestClosedIn7DaysAsync(int userId, IPaginationModel pagination);

        Task<int> GetChangeRequestClosedIn7DaysCountAsync(int userId);

        Task<(IReadOnlyList<ChangeRequestTilesDataFromRepo> DataList, int DataCount)> GetChangeRequestProposedAsync(int userId, IPaginationModel pagination);

        Task<int> GetChangeRequestProposedCountAsync(int userId);

        Task<bool> TryAddApproverAsync(IReadOnlyList<string> dcrIds, int approverUserId);
    }
}

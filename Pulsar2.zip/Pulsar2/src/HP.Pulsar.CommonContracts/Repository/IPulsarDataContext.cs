﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IPulsarDataContext
    {
        Task<int> ExecuteNonQueryAsync(string storedProcedureName, IReadOnlyList<IDbDataParameter> parameters);

        Task<object> ExecuteScalarAsync(string storedProcedureName, IReadOnlyList<IDbDataParameter> parameters);

        Task<T> GetDataModelAsync<T>(string storedProcedureName,
                                     IReadOnlyList<IDbDataParameter> parameters,
                                     IReadOnlyList<(string ModelPropertyName, string ColumnName, Type ModelPropertyType)> columnMappings,
                                     IReadOnlyDictionary<string, Func<object, object>> valueConversions = null) where T : class;

        Task<(IReadOnlyList<T> DataRows, int? TotalDataCount)> GetDataModelsAsync<T>(string storedProcedureName,
                                                                                     IReadOnlyList<IDbDataParameter> parameters,
                                                                                     IReadOnlyList<(string ModelPropertyName, string ColumnName, Type ModelPropertyType)> columnMappings,
                                                                                     IReadOnlyDictionary<string, Func<object, object>> valueConversions = null) where T : class;

        Task<IPulsarDataReader> GetDataReaderAsync(string storedProcedureName, IReadOnlyList<IDbDataParameter> parameters);
    }
}

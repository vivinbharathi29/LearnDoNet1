﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface INewComponentsReleasedRepository
    {
        Task<(IReadOnlyList<IRSComponentUpdateListDataFromRepo> DataList, int DataCount)> GetIRSProductDropComponentsAsync(IReadOnlyList<int> productIds, IPaginationModel pagination);
        Task<(string ComponentName, string Version, string Revision, string Pass)> GetComponentVersionPropertiesAsync(int componentVersionId);
        Task<IReadOnlyList<string>> GetOSFamilyDetailsAsync();
        Task<IReadOnlyList<(int ProductId, string ProductName)>> GetProductDropsAsync();
        Task<string> GetProductNameAsync(int productId, int releaseId = 0);
        Task<(string TargetNotes, bool OutOfCycleRelease)> GetTargetNotesAsync(int productId, int componentVersionId);
        Task<bool> TryUpdateExceptionsAsync(int productId, int componentVersionId, string targetNotes, bool cycle, int type);
    }
}
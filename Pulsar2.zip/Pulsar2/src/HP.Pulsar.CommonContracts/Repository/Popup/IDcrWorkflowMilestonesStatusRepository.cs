﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface IDcrWorkflowMilestonesStatusRepository
    {
        Task<DcrWorkflowEmailsDataModel> GetWorkflowEmailsAsync(int dcrId, int productId);

        Task<IReadOnlyList<DcrWorkflowMilestonesStatusDataModel>> GetWorkflowMilestonesStatusAsync(int dcrId);

        Task<bool> UpdateWorkflowMilestonesCommentAsync(int historyId, string comment);

        Task<bool> UpdateWorkflowMilestonesCompleteAsync(int historyId, int dcrId, int productId);
    }
}

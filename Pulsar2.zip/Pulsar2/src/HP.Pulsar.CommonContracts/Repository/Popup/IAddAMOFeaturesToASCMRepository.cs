﻿using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HP.Pulsar.CommonContracts.Repository
{
    public interface IAddAMOFeaturesToASCMRepository
    {
        Task<IReadOnlyList<ASCMSelectOptionModel>> GetAllAmoSkuTypes();

        Task<IReadOnlyList<ASCMSelectOptionModel>> GetAllProductLines();

        Task<IReadOnlyList<ASCMSelectOptionModel>> GetAllLocalizations();
    }
}

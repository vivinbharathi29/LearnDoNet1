﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface IDeveloperApprovalRepository
    {
        Task<(IReadOnlyList<ProductComponentModelFromRepo> DataList, int DataCount)> GetProductComponentsAsync(IReadOnlyList<string> productComponentIds, IReadOnlyList<string> productComponentReleaseIds, int partnerId, IPaginationModel pagination);

        Task<bool> UpdateDeveloperApprovalAsync(ProductComponentPostDataModel productComponentData, int userId);

        Task<ProductComponentEmailModelFromRepo> GetDeveloperProductionReleaseEmailInfoAndPulsarAsync(string productComponentIds);
    }
}

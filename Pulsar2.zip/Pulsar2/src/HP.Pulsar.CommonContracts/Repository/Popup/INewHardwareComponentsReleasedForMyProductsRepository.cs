﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository.Models.Popup;
using HP.Pulsar.CommonContracts.TodayPage.Popup.Models;

namespace HP.Pulsar.CommonContracts.Repository.Popup
{
    public interface INewHardwareComponentsReleasedForMyProductsRepository
    {
        Task<(IReadOnlyList<SubassemblyListDataModelFromRepo> DataList, int DataCount)> GetQualificationStatusContentAsync(int productId, int componentVersionId, int releaseId, IPaginationModel pagination, bool isPulsarProduct);

        Task<IReadOnlyDictionary<int, string>> GetAvailableQualificationStatusAsync();

        Task<IReadOnlyList<(int ChangeRequestId, string Status, string Summary)>> GetChangeRequestAsync(int productId, int showAll);

        Task<(string Vendor, string ComponentRootName, string ProductName)> GetProductComponentDetailsAsync(int productId, int componentVersionId, int productComponentReleaseId);

        Task<(int ReleaseId, string ReleaseName)> GetProductReleaseDetailsAsync(int productId,
                                                                                int productComponentReleaseId,
                                                                                int componentVersionId,
                                                                                string todayPageSection,
                                                                                int releaseId);

        Task<QualificationStatusDataModelFromRepo> GetCommodityStatusReleaseAsync(int productId, int componentVersionId, int releaseId, bool isPulsarProduct);

        Task<IReadOnlyList<(int ProductCount, string HardwareTeam)>> GetHardwareTeamAccessListAsync(int userId, int productId);

        Task<int> GetSubassemblyReleaseCountAsync(int productId, int componentVersionId, int productComponentReleaseId, bool isPulsarProduct);

        Task<bool> TryUnLinkComponentVersionFromProductAsync(int productId, int componentVersionId, int releaseId, bool isPulsarProduct);

        Task<bool> TryUpdateCommodityStatusAsync(QualificationStatusModelForPostData postQualificationData);

        Task<bool> TryAddSubassemblyLinkAsync(int productDeliverableId, int productRootId, bool isPulsarProduct);

        Task<ProductComponentModel> GetSubassemblyBridgeReleaseAsync(int productDeliverableId, int productRootId, bool isPulsarProduct);

        Task<bool> TryRemoveSubassemblyLinkAsync(int productDeliverableId, int productRootId, bool isPulsarProduct);

        Task<IReadOnlyList<string>> GetEngineeringCoorginatorsAsync();

        Task<IReadOnlyList<string>> GetDeliverableDeveloper(int componentVersionId);

        Task<IReadOnlyList<string>> GetAllHardwarePMsForVersionAsync(int componentVersionId);

        Task<IReadOnlyList<(string Role, string Email)>> GetProductSystemTeamAsync(int productId, byte allEmployees, byte addBios);
    }
}

﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Pagination
{
    public enum FilterColumnType
    {
        Boolean,
        Date,
        Number,
        String
    }
}

﻿using System;

namespace HP.Pulsar.CommonContracts.Infrastructure.Pagination
{
    public class FilterModel
    {
        public string ColumnName { get; set; }

        public FilterColumnType ColumnType { get; set; }

        public string Condition { get; set; }

        public FilterOperator Operator { get; set; }

        public string Value { get; set; }
    }
}

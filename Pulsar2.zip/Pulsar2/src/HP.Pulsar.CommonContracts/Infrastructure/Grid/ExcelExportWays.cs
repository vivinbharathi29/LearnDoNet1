﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Grid
{
    public enum ExcelExportWays
    {
        None = 0,
        ServerSide = 1,
        ClientSide = 2
    }
}

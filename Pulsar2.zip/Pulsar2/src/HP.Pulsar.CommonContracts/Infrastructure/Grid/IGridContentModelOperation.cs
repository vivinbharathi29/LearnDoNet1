﻿using System.Collections.Generic;
using HP.Pulsar.CommonContracts.Infrastructure.Popup;

namespace HP.Pulsar.CommonContracts.Infrastructure.Grid
{
    public interface IGridContentModelOperation
    {
        // This is the name displayed on UI
        string OperationName { get; }

        // What the operation should do?
        GridContentModelOperationType Type { get; }

        // This is the url to MVC controller or webapi
        string OperationUrlRelativePath { get; }

        // the list of field names (should match with the names of Grid Columns) that needs to be posted
        //  or passed as the query string to the popup url.
        IReadOnlyList<string> GridColumnNames { get; }

        // This is the javascript which would be run when top link is clicked 
        string JavascriptFunctionName { get; }

        // Should we refresh the Grid or not
        bool IsGridRefreshRequired { get; }

        // Should the value of each grid column passed as a separate querystring parameter to the popup url
        // or each value separated by hyphen and passed as one querystring
        bool IsSeparateQueryStringRequiredForGridColumns { get; }

        // Title to be displayed at the top of the popup
        string PopupTitle { get; }

        // Popup size
        PopupSize PopupSize { get; }

        // The confirmation message which has to be displayed before posting the data
        string ConfirmationMessageBeforePost { get; }

        // The character that separates the individual column values when passed to the URL
        ColumnValueSeparator GridColumnValueSeparator { get; }

        // this javascript function would be called when the context menu item/operation is rendered.
        // this javascript function would be used to hide or disable the context menu item/operation.
        string OnRenderJavascriptionFunctionName { get; }
    }
}
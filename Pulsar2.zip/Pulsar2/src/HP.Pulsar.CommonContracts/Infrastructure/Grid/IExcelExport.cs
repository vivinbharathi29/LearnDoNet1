﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.Infrastructure.Grid
{
    public interface IExcelExport
    {
        byte[] GetContent<T>(IReadOnlyList<T> dataModel, string sheetName);
    }
}

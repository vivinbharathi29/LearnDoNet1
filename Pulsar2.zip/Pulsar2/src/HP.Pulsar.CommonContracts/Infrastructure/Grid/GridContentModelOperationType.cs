﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Grid
{
    public enum GridContentModelOperationType
    {
        BindCustomJavascript = 1,

        ShowURLInPopupWithNoQueryString,

        ShowURLInPopupWithQueryString,

        ShowURLInNewBrowserTabWithNoQueryString,

        ShowURLInNewBrowserTabWithQueryString,

        ShowURLInNewBrowserWindowWithQueryString,

        PostJsonDataToURL,

        PostCsvDataToURL
    }
}
﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.Infrastructure.Grid
{
    public interface IGridContentModel
    {
        /// <summary>
        /// True means grid will display checkbox in rows; otherwise false.
        /// </summary>
        bool CanShowGridCheckBox { get; }

        /// <summary>
        /// This is json string to define what column types are
        /// </summary>
        string ColumnsData { get; }

        /// <summary>
        /// This is json string to define what column templates are
        /// </summary>
        string ColumnTemplateDefinition { get; }

        /// <summary>
        /// This defines what context menu items are in grid
        /// </summary>
        IReadOnlyList<IGridContentModelOperation> ContextMenuOperations { get; }

        /// <summary>
        /// Get the way how to export excel, like server-side, client-side.
        /// None means no support for excel export.
        /// </summary>
        ExcelExportWays ExcelExport { get; }

        /// <summary>
        /// This url path is used to get grid content data.
        /// It is also used by Excel Export functionality to get grid content data.
        /// </summary>
        string GridDataUrlRelativePath { get; }

        /// <summary>
        /// This defines what features are in grid - like sorting, filtering and so on.
        /// </summary>
        string GridFeatures { get; }

        /// <summary>
        /// This defines what row-clicking event is
        /// </summary>
        IGridContentModelOperation GridRowOperation { get; }

        /// <summary>
        /// This defines what top link operations (buttons) are in top of grid
        /// </summary>
        IReadOnlyList<IGridContentModelOperation> TopLinkOperations { get; }
    }
}
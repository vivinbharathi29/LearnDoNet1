﻿using System;

namespace HP.Pulsar.CommonContracts.Infrastructure.Telemetry
{
    public interface ITelemetryFaultEvent : ITelemetryEvent
    {
        Exception Exception { get; set; }
    }
}

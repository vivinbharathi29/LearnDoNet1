﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Telemetry
{
    public interface ITelemetryService
    {
        void Send(ITelemetryEvent telemetryEvent);
    }
}

﻿using System;

namespace HP.Pulsar.CommonContracts.Infrastructure.Telemetry
{
    public interface ITelemetryFactory
    {
        void AddTelemetryEvent(Type telemetryType);

        void Send(ITelemetryEvent telemetryEvent, string userNameWithDomainName, Exception ex = null);

        bool TryGet(int telemetryEventId, out ITelemetryEvent telemetryEvent);
    }
}

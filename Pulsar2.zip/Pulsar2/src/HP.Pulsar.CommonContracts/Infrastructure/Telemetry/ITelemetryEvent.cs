﻿using System.Collections.Generic;

namespace HP.Pulsar.CommonContracts.Infrastructure.Telemetry
{
    public interface ITelemetryEvent
    {
        int Id { get; }

        string Name { get; }

        IDictionary<string, string> Properties { get; }

        TelemetryType Type { get; }

        void SetProperty<T>(string name, T value);
    }
}

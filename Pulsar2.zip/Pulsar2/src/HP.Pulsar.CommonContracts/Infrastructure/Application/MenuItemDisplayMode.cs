﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Application
{
    // TFS#55269 - move to infra prj
    public class MenuItemDisplayMode
    {
        public static readonly MenuItemDisplayMode None = new MenuItemDisplayMode(0, "None");
        public static readonly MenuItemDisplayMode Popup = new MenuItemDisplayMode(1, "Popup");
        public static readonly MenuItemDisplayMode NewTab = new MenuItemDisplayMode(2, "NewTab");

        private MenuItemDisplayMode(int id, string displayMode)
        {
            Name = displayMode;
            Id = id;
        }

        public string Name { get; set; }

        public int Id { get; set; }

        public static bool TryGet(int id, out MenuItemDisplayMode mode)
        {
            if (id == 2)
            {
                mode = NewTab;
                return true;
            }
            else if (id == 1)
            {
                mode = Popup;
                return true;
            }
            else if (id == 0)
            {
                mode = None;
                return true;
            }

            mode = null;
            return false;
        }
    }
}

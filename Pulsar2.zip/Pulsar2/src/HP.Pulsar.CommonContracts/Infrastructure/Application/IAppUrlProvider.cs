﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Application
{
    public interface IAppUrlProvider
    {
        string NebulaUrl { get; }

        /// <summary>
        /// Gets URL path of creating component root
        /// </summary>
        /// <returns></returns>
        string GetComponentRootCreationUrlPath();

        /// <summary>
        /// Get URL path of change request for Quick Search
        /// </summary>
        /// <param name="changeRequestId"></param>
        /// <returns></returns>
        string GetChangeRequestOnQuickSearchUrlPath(int changeRequestId);

        /// <summary>
        /// Gets URL path of pulsar application clone component version properties in some tiles
        /// </summary>
        /// <returns></returns>
        string GetCloneComponentVersionPropertiesUrlPath();

        /// <summary>
        /// Get URL path of Pulsar release widget which is invoked in some tiles. 
        /// This will have parameter variable in the value string.
        /// </summary>
        /// <returns></returns>
        string GetComponentReleaseUrlPathValue();

        /// <summary>
        /// Get URL path of displaying component root in Quick Search
        /// </summary>
        /// <param name="componentRootId"></param>
        /// <returns></returns>
        string GetComponentRootOnQuickSearchUrlPath(int componentRootId);

        /// <summary>
        /// Get URL path of displacing component version in Quick Search
        /// </summary>
        /// <param name="componentVersionId"></param>
        /// <returns></returns>
        string GetComponentVersionOnQuickSearchUrlPath(int componentVersionId);

        /// <summary>
        /// Get URL path of creating component version properties (Used by some tiles).
        /// </summary>
        /// <returns></returns>
        string GetComponentVersionPropertyCreationUrlPathValue();

        /// <summary>
        /// Get URL path of editing component version properties (Used by some tiles).
        /// </summary>
        /// <returns></returns>
        string GetComponentVersionPropertiesEditingUrlPathValue();

        /// <summary>
        /// Get URL path of displaying feature in Quick Search
        /// </summary>
        /// <param name="featureId"></param>
        /// <returns></returns>
        string GetFeatureOnQuickSearchUrlPath(int featureId);

        /// <summary>
        /// Get URL path of displaying AMO feature in Quick Search
        /// </summary>
        /// <param name="featureId"></param>
        /// <returns></returns>
        string GetAmoFeatureOnQuickSearchUrlPath(int featureId);

        /// <summary>
        /// Get URL path of Nebula. Ex: http://host/Nebula
        /// </summary>
        /// <returns></returns>
        string GetSuddentImpactOnNebulaUrlPathValue();

        /// <summary>
        /// Get URL path of displacing product in Quick Search
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        string GetProductOnQuickSearchUrlPath(int productId);

        /// <summary>
        /// Get URL path of displacing sudden impact in Quick Search
        /// </summary>
        /// <param name="observationId"></param>
        /// <returns></returns>
        string GetSuddenImpactOnNebualUrlPath(long observationId);

        /// <summary>
        /// Get URL of adding user favorites
        /// </summary>
        /// <returns></returns>
        string GetUserFavoritesAddUrl();

        /// <summary>
        /// Get URL of removing user favorites
        /// </summary>
        /// <returns></returns>
        string GetUserFavoritesRemoveUrl();

        /// <summary>
        /// Get URL of displacing component version details
        /// </summary>
        /// <param name="componentVersionId"></param>
        /// <returns></returns>
        string GetComponentVersionDetailsUrl(int componentVersionId);

        /// <summary>
        /// Get URL path value of displaying component root.
        /// This will have parameter variable in the value string.
        /// </summary>
        /// <returns></returns>
        string GetComponentRootUrlPathValue();
    }
}
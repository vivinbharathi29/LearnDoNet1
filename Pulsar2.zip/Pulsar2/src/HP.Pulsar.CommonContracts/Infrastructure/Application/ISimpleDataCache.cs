﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Application
{
    public interface ISimpleDataCache
    {
        void Set(string key, object value, int minutesToBeExpired = 30);

        bool TryGet(string key, out object value);
    }
}

﻿using System;
using Newtonsoft.Json;

namespace HP.Pulsar.CommonContracts.Infrastructure.Application
{
    // TFS#55269 : move to Infra prj
    public class MenuItemDisplayModeConverter : JsonConverter
    {
        public MenuItemDisplayModeConverter()
        {
        }

        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(MenuItemDisplayMode);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (objectType == typeof(MenuItemDisplayMode)
                && reader.Value != null
                && int.TryParse(reader.Value.ToString(), out int value)
                && MenuItemDisplayMode.TryGet(value, out MenuItemDisplayMode mode))
            {
                return mode;
            }

            return null;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value is MenuItemDisplayMode mode)
            {
                writer.WriteValue(mode.Id);
            }
        }

        public override bool CanWrite => true;

        public override bool CanRead => true;
    }
}

﻿using System.Threading.Tasks;

namespace HP.Pulsar.CommonContracts.Infrastructure.Email
{
    public interface IEmailManager
    {
        Task SendAsync(EmailMessage emailMessage);
        Task<(string subject, string body)> GetEmailTemplateAsync(int emailTemplateId);
    }
}
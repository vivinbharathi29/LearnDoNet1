﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace HP.Pulsar.CommonContracts.Infrastructure.Configuration
{
    public interface ISettingRepository
    {
        Task<IReadOnlyList<ISetting>> GetSettingsAsync();

        Task<ISetting> GetSettingAsync(string name);
    }
}
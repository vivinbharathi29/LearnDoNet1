﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Configuration
{
    public interface IAppConfiguration
    {
        string AppName { get; }

        string Environment { get; }

        string IrsUrl { get; }

        string IrsUrlFromDatabase { get; }

        string IrsUrlReplacementSearch { get; }

        string PRSDatabaseConnectionString { get; }

        string ElasticApmServerSideUrl { get; }

        string ElasticApmInternalClientSideUrl { get; }

        string ElasticApmPRPClientSideUrl { get; }

        string ElasticApmInternalClientSideServiceName { get; }

        string ElasticApmEnableApmClientSideTelemetryKey { get; }

        string ElasticApmPRPClientSideServiceName { get; }

        string ElasticApmServerSideServiceName { get; }

        string ElasticApmLogLevel { get; }

        string OdmServerNameEmailLink { get; }

        //The below are for Ticketsupport legacy code from pulsarplus
        string SupportEmailLink { get; }

        //The below are for Ticketsupport legacy code from pulsarplus
        string PulsarServerName { get; }

        //The below are for Ticketsupport legacy code from pulsarplus
        string PulsarFileStorePath { get; }

        string PulsarServerNameEmailLink { get; }

        //The below are for to get the Nebula Url path for Legacy Quick search
        string NebulaUrl { get; }

        string DcrUrlForEmail { get; }
    }
}
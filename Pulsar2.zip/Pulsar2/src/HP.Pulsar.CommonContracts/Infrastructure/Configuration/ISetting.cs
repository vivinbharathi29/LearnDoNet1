﻿namespace HP.Pulsar.CommonContracts.Infrastructure.Configuration
{
    // TODO Bring data out from database in preview 2 or 3
    public interface ISetting
    {
        int SettingId { get; }

        string Name { get; }

        string Value { get; }

        string Description { get; }
    }
}
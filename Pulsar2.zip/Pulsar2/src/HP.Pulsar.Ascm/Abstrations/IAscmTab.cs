﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IAscmTab
    {
        int Id { get; }

        string Name { get; }

        string PartialViewUrlPath { get; }

        JsonSerializerSettings GetJsonSerializerSettings();

        Task<ITabContentModel> GetTabContentModelAsync();

        Task<(IReadOnlyList<IGridDataModel> DataList, int? DataCount)> GetGridDataAsync(IPaginationModel pagination);
    }
}

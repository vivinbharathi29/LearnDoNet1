﻿using System.Collections.Generic;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IAscmShortcutService
    {
        bool TryGetAscmTab(int tabId, out IEnumerable<IAscmShortcut> ascmShortcuts);
    }
}
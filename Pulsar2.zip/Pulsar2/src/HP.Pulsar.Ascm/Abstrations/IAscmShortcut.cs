﻿using HP.Pulsar.Ascm.Models;

namespace HP.Pulsar.Ascm.Abstrations
{
    public interface IAscmShortcut
    {
        string Name { get; }

        int TabId { get; }

        string GetUrlPath();

        public ShortcutOperationType Type { get; }

        public string JavaScriptFunctionName { get; set; }
    }
}
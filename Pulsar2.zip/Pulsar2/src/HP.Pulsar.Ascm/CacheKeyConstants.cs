﻿namespace HP.Pulsar.Ascm
{
    public static class CacheKeyConstants
    {
        public static readonly string SearchFeaturesQueryStringCacheKey = "SearchAmoFeaturesCacheKey";
    }
}

﻿namespace HP.Pulsar.Ascm.Repository
{
    internal static class StoredProcedureNames
    {
        public const string AscmHpPartNumbers = "usp_AscmAdmin_HpPartNumbers_Pagination";
        public const string ProductLines = "spGetProductLinesAll";
        public const string ScmCategories = "usp_ADMIN_GetAllSCMCategories";
        public const string GetHpPartNumber = "usp_AscmAdmin_GetHpPartNumber";
        public const string SaveHpPartNumber = "usp_AscmAdmin_UpdateHpPartNumber";
        public const string BatchUpdateHpPartNumbers = "usp_AscmAdmin_BatchUpdateHpPartNumbers";
        public const string DeleteHpPartNumber = "usp_AscmAdmin_DeleteHpPartNumber";
        public const string AmoFeatureClasses = "usp_AscmAdmin_GetFeatureClasses";
        public const string AmoFeatureCategories = "usp_AscmAdmin_GetFeatureCategories";
        public const string AmoFeatureNamingStandards = "usp_AscmAdmin_GetFeatureNamingStandards";
        public const string AmoFeatureSearchResult = "usp_AscmAdmin_FeatureSearchResult_Pagination";
        public const string SkuTypes = "usp_GetAllAmoSkuTypes";
        public const string Regions = "usp_AscmAdmin_GetRegions";
        public const string AddAMOFeaturesToASCM = "usp_AscmAdmin_AddAMOFeaturesToASCM";
    }
}
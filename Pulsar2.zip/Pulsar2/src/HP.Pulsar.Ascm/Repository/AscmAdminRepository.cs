﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Repository;
using HP.Pulsar.Infrastructure.Helpers;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Repository
{
    public class AscmAdminRepository : IAscmAdminRepository
    {
        private readonly IPulsarDataContext _dbContext;

        public AscmAdminRepository(IPulsarDataContext pulsarDataContext)
        {
            _dbContext = pulsarDataContext;
        }

        public async Task<(IReadOnlyList<IGridDataModel> DataList, int? DataCount)> GetHpPartNumbersAsync(IPaginationModel pagination)
        {
            if (pagination == null)
            {
                return (new List<AllOptionsGridDataModel>(), 0);
            }

            List<(string, string, Type)> modelMappings = new List<(string, string, Type)>
            {
                (nameof(AllOptionsGridDataModel.FeatureId), "FeatureId", typeof(int)),
                (nameof(AllOptionsGridDataModel.ProductLineId), "ProductLineId", typeof(int)),
                (nameof(AllOptionsGridDataModel.SkuTypeId), "SkuTypeId", typeof(int)),
                (nameof(AllOptionsGridDataModel.LocalizationId), "LocalizationId", typeof(int)),
                (nameof(AllOptionsGridDataModel.HpPartNumber), "HpPartNo", typeof(string)),
                (nameof(AllOptionsGridDataModel.PMG100DTDescription), "PMG100_DT", typeof(string)),
                (nameof(AllOptionsGridDataModel.BusinessSegment), "BusinessSegment", typeof(string)),
                (nameof(AllOptionsGridDataModel.AscmCategoryName), "AscmCategoryName", typeof(string)),
                (nameof(AllOptionsGridDataModel.ProductLineName), "ProductLineName", typeof(string)),
                (nameof(AllOptionsGridDataModel.RTPDate), "RTPDate", typeof(DateTime?)),
                (nameof(AllOptionsGridDataModel.SaDate), "SaDate", typeof(DateTime?)),
                (nameof(AllOptionsGridDataModel.GaDate), "GaDate", typeof(DateTime?)),
                (nameof(AllOptionsGridDataModel.EmDate), "EmDate", typeof(DateTime?)),
                (nameof(AllOptionsGridDataModel.GsEolDate), "GsEolDate", typeof(DateTime?)),
                (nameof(AllOptionsGridDataModel.PreviousProduct), "PreviousProduct", typeof(string)),
                (nameof(AllOptionsGridDataModel.Comment), "Comments", typeof(string)),
                (nameof(AllOptionsGridDataModel.SkuType), "SkuType", typeof(string)),
                (nameof(AllOptionsGridDataModel.Creator), "Creator", typeof(string)),
                (nameof(AllOptionsGridDataModel.Updater), "Updater", typeof(string)),
            };

            IReadOnlyList<string> sqlColumnNames = new List<string>{
                nameof(AllOptionsGridDataModel.RTPDate),
                nameof(AllOptionsGridDataModel.SaDate),
                nameof(AllOptionsGridDataModel.GaDate),
                nameof(AllOptionsGridDataModel.EmDate),
                nameof(AllOptionsGridDataModel.GsEolDate)
            };

            IList<FilterModel> filters = PaginationHelper.ConvertJavascriptUTCDateTimeTicksToSQLServerDate(pagination.Filters, sqlColumnNames);

            string orderByClause = pagination.ToSqlOrderBy();
            string whereClause = filters.ToSqlWhere();

            List<SqlParameter> parameters = new List<SqlParameter> {
                new SqlParameter("PageNo",pagination.PageNo),
                new SqlParameter("PageSize", pagination.PageSize),
                new SqlParameter("OrderByClause", orderByClause.Replace(nameof(AllOptionsGridDataModel.HpPartNumber), "HpPartNo")
                                                               .Replace(nameof(AllOptionsGridDataModel.PMG100DTDescription), "PMG100_DT")
                                                               .Replace(nameof(AllOptionsGridDataModel.Comment), "Comments")),
                new SqlParameter("WhereClause", whereClause.Replace(nameof(AllOptionsGridDataModel.HpPartNumber), "HpPartNo")
                                                           .Replace(nameof(AllOptionsGridDataModel.PMG100DTDescription), "PMG100_DT")
                                                           .Replace(nameof(AllOptionsGridDataModel.Comment), "Comments"))
            };

            IReadOnlyList<AllOptionsGridDataModel> dataRows;
            int? dataCount;
            (dataRows, dataCount) = await _dbContext.GetDataModelsAsync<AllOptionsGridDataModel>(StoredProcedureNames.AscmHpPartNumbers,
                                                                                                 parameters,
                                                                                                 modelMappings).ConfigureAwait(false);

            return (dataRows, dataCount);
        }

        public async Task<IReadOnlyList<(int ProductLineId, string ProductLineName)>> GetProductLinesAsync()
        {
            IPulsarDataReader reader = await _dbContext.GetDataReaderAsync(StoredProcedureNames.ProductLines, null).ConfigureAwait(false);
            List<(int ProductLine, string ProductLineName)> productLines = new List<(int ProductLine, string ProductLineName)>();

            for (int i = 0; i < reader.RowCount; i++)
            {
                if (reader.TryGetIntValue("Id", i, out int? productLineId)
                    && productLineId.HasValue
                    && reader.TryGetStringValue("Name", i, out string productLienName)
                    && reader.TryGetStringValue("Description", i, out string productLineDescription))  // TODO: remove disabled pl
                {
                    productLines.Add((productLineId.Value, $"{productLienName}-{productLineDescription}"));
                }
            }

            return productLines;
        }

        public async Task<IReadOnlyList<(int AscmCategoryId, string AscmCategoryName)>> GetAscmCategoriesAsync()
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("@onlySCMCategories", false)
            };

            IPulsarDataReader reader = await _dbContext.GetDataReaderAsync(StoredProcedureNames.ScmCategories, parameters).ConfigureAwait(false);
            List<(int AscmCategoryId, string AscmCategoryName)> categories = new List<(int AscmCategoryId, string AscmCategoryName)>();

            for (int i = 0; i < reader.RowCount; i++)
            {
                if (reader.TryGetIntValue("SCMCategoryId", i, out int? categoryId)
                    && categoryId.HasValue
                    && reader.TryGetStringValue("Name", i, out string categoryName)
                    && reader.TryGetBoolValue("IsAscmCategory", i, out bool? isAscmCategory)
                    && isAscmCategory.HasValue
                    && isAscmCategory.Value)
                {
                    categories.Add((categoryId.Value, categoryName));
                }
            }

            return categories;
        }

        public async Task<HpPartNumberOutputDataModel> GetHpPartNumberAsync(int featureId, int productLineId, int skuTypeId, int localizationId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter(nameof(featureId), featureId),
                new SqlParameter(nameof(productLineId), productLineId),
                new SqlParameter(nameof(skuTypeId), skuTypeId),
                new SqlParameter(nameof(localizationId), localizationId)
            };

            List<(string, string, Type)> modelMappings = new List<(string, string, Type)>
            {
                (nameof(HpPartNumberOutputDataModel.FeatureId), "FeatureId", typeof(int)),
                (nameof(HpPartNumberOutputDataModel.SkuTypeId), "SkuTypeId", typeof(int)),
                (nameof(HpPartNumberOutputDataModel.LocalizationId), "LocalizationId", typeof(int)),
                (nameof(HpPartNumberOutputDataModel.HpPartNo), "HpPartNo", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.SkuType), "SkuType", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.FeatureName), "FeatureName", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.GpgDescription), "GpgDescription", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.Pmg100Description),"Pmg100Description", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.Pmg250Description), "Pmg250Description",typeof(string)),
                (nameof(HpPartNumberOutputDataModel.CountryCode), "CountryCode",typeof(string)),
                (nameof(HpPartNumberOutputDataModel.AscmCategoryId), "AscmCategoryId", typeof(int?)),
                (nameof(HpPartNumberOutputDataModel.AscmCategoryName),"AscmCategoryName", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.ProductLineId), "ProductLineId", typeof(int)),
                (nameof(HpPartNumberOutputDataModel.ProductLineName), "ProductLineName", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.RTPDate),"RTPDate", typeof(DateTime?)),
                (nameof(HpPartNumberOutputDataModel.SaDate),"SaDate", typeof(DateTime?)),
                (nameof(HpPartNumberOutputDataModel.PaadDate), "PaadDate", typeof(DateTime?)),
                (nameof(HpPartNumberOutputDataModel.GaDate), "GaDate", typeof(DateTime?)),
                (nameof(HpPartNumberOutputDataModel.EmDate),"EmDate", typeof(DateTime?)),
                (nameof(HpPartNumberOutputDataModel.GsEolDate),"GsEolDate", typeof(DateTime?)),
                (nameof(HpPartNumberOutputDataModel.PreviousProduct),"PreviousProduct", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.Comments),"Comments", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.CreatorId), "CreatorId", typeof(int)),
                (nameof(HpPartNumberOutputDataModel.Creator), "Creator", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.Created), "Created", typeof(DateTime)),
                (nameof(HpPartNumberOutputDataModel.Updater), "Updater", typeof(string)),
                (nameof(HpPartNumberOutputDataModel.Updated), "Updated", typeof(DateTime?))
            };

            return await _dbContext.GetDataModelAsync<HpPartNumberOutputDataModel>(StoredProcedureNames.GetHpPartNumber, parameters, modelMappings).ConfigureAwait(false);
        }

        public async Task<string> SaveHpPartNumberAsync(HpPartNumberInputDataModel hpPartNumberModel, int updaterUserId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("featureId", hpPartNumberModel.FeatureId),
                new SqlParameter("productLineId", hpPartNumberModel.ProductLineId),
                new SqlParameter("skuTypeId", hpPartNumberModel.SkuTypeId),
                new SqlParameter("localizationId", hpPartNumberModel.LocalizationId),
                new SqlParameter("hpPartNo", hpPartNumberModel.HpPartNo),
                new SqlParameter("ascmCategoryId", hpPartNumberModel.AscmCategoryId),
                new SqlParameter("rtpDate", hpPartNumberModel.RTPDate),
                new SqlParameter("saDate", hpPartNumberModel.SaDate),
                new SqlParameter("paadDate", hpPartNumberModel.PaadDate),
                new SqlParameter("gaDate", hpPartNumberModel.GaDate),
                new SqlParameter("emDate", hpPartNumberModel.EmDate),
                new SqlParameter("gsEolDate", hpPartNumberModel.GsEolDate),
                new SqlParameter("comments", hpPartNumberModel.Comments),
                new SqlParameter("updater", updaterUserId),
                new SqlParameter("result",string.Empty){Direction=System.Data.ParameterDirection.Output}
            };

            if (hpPartNumberModel.OldFeatureId.HasValue)
            {
                parameters.Add(new SqlParameter("oldFeatureId", hpPartNumberModel.OldFeatureId.Value));
            }
            else
            {
                parameters.Add(new SqlParameter("oldFeatureId", DBNull.Value));
            }

            if (hpPartNumberModel.OldProdcutLineId.HasValue)
            {
                parameters.Add(new SqlParameter("oldProductLineId", hpPartNumberModel.OldProdcutLineId.Value));
            }
            else
            {
                parameters.Add(new SqlParameter("oldProductLineId", DBNull.Value));
            }

            object result = await _dbContext.ExecuteScalarAsync(StoredProcedureNames.SaveHpPartNumber, parameters).ConfigureAwait(false);

            if (result != null)
            {
                return result.ToString();
            }

            return string.Empty;
        }

        public async Task<string> BatchUpdateHpPartNumbersAsync(BatchUpdateHpPartNumbersModel batchUpdateHpPartNumbers, int updaterUserId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("selectedIds", JsonConvert.SerializeObject(batchUpdateHpPartNumbers.SelectedIds)),
                new SqlParameter("batchUpdateColumnName", batchUpdateHpPartNumbers.ColumnName),
                new SqlParameter("updater", updaterUserId),
                new SqlParameter("result",string.Empty){Direction=System.Data.ParameterDirection.Output}
            };

            if (batchUpdateHpPartNumbers.UpdateValue.HasValue)
            {
                parameters.Add(new SqlParameter("updateValue", batchUpdateHpPartNumbers.UpdateValue.Value));
            }
            else
            {
                parameters.Add(new SqlParameter("updateValue", DBNull.Value));
            }

            if (batchUpdateHpPartNumbers.UpdateDates == null || batchUpdateHpPartNumbers.UpdateDates.Count == 0)
            {
                parameters.Add(new SqlParameter("updateDate", DBNull.Value));
            }
            else
            {
                parameters.Add(new SqlParameter("updateDate", JsonConvert.SerializeObject(batchUpdateHpPartNumbers.UpdateDates)));
            }

            object result = await _dbContext.ExecuteScalarAsync(StoredProcedureNames.BatchUpdateHpPartNumbers, parameters).ConfigureAwait(false);

            if (result != null)
            {
                return result.ToString();
            }

            return string.Empty;
        }

        public async Task DeleteHpPartNumberDateAsync(HpPartNumberIdsModel hpPartNumberModel, int updaterUserId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter("featureId", hpPartNumberModel.FeatureId),
                new SqlParameter("productLineId", hpPartNumberModel.ProductLineId),
                new SqlParameter("skuTypeId", hpPartNumberModel.SkuTypeId),
                new SqlParameter("localizationId", hpPartNumberModel.LocalizationId),
            };
            await _dbContext.ExecuteNonQueryAsync(StoredProcedureNames.DeleteHpPartNumber, parameters).ConfigureAwait(false);
        }

        public async Task<IReadOnlyList<(int FeatureClassId, string FeatureClassName)>> GetFeatureClassesAsync()
        {
            IPulsarDataReader reader = await _dbContext.GetDataReaderAsync(StoredProcedureNames.AmoFeatureClasses, null).ConfigureAwait(false);
            List<(int FeatureClassId, string FeatureClassName)> featureClasses = new List<(int FeatureClassId, string FeatureClassName)>();

            for (int i = 0; i < reader.RowCount; i++)
            {
                if (reader.TryGetIntValue("FeatureClassId", i, out int? featureClassId)
                    && featureClassId.HasValue
                    && reader.TryGetStringValue("Name", i, out string featureClassName))
                {
                    featureClasses.Add((featureClassId.Value, featureClassName));
                }
            }

            return featureClasses;
        }

        public async Task<IReadOnlyList<(int FeatureCategoryId, string FeatureCategoryName)>> GetFeatureCategoriesAsync(int featureClassId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter(nameof(featureClassId), featureClassId)
            };

            IPulsarDataReader reader = await _dbContext.GetDataReaderAsync(StoredProcedureNames.AmoFeatureCategories, parameters).ConfigureAwait(false);
            List<(int FeatureCategoryId, string FeatureCategoryName)> featureCategoryies = new List<(int FeatureCategoryId, string FeatureCategoryName)>();

            for (int i = 0; i < reader.RowCount; i++)
            {
                if (reader.TryGetIntValue("FeatureCategoryId", i, out int? featureCategoryId)
                    && featureCategoryId.HasValue
                    && reader.TryGetStringValue("Name", i, out string featureCategoryName))
                {
                    featureCategoryies.Add((featureCategoryId.Value, featureCategoryName));
                }
            }

            return featureCategoryies;
        }

        public async Task<IReadOnlyList<(int NamingStandardId, string NamingStandardName)>> GetFeatureNamingStandardsAsync(int featureCategoryId)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
            {
                new SqlParameter(nameof(featureCategoryId), featureCategoryId)
            };
            IPulsarDataReader reader = await _dbContext.GetDataReaderAsync(StoredProcedureNames.AmoFeatureNamingStandards, parameters).ConfigureAwait(false);
            List<(int FeatureCategoryId, string FeatureCategoryName)> featureNamingStandards = new List<(int FeatureCategoryId, string FeatureCategoryName)>();

            for (int i = 0; i < reader.RowCount; i++)
            {
                if (reader.TryGetIntValue("NamingStandardId", i, out int? namingStandardId)
                    && namingStandardId.HasValue
                    && reader.TryGetStringValue("Name", i, out string namingStandardName))
                {
                    featureNamingStandards.Add((namingStandardId.Value, namingStandardName));
                }
            }

            return featureNamingStandards;
        }

        public async Task<(IReadOnlyList<SearchAmoFeaturesGridDataModel> DataList, int? DataCount)> GetFeatureSearchResultAsync(IPaginationModel pagination, int featureCategoryId, string namingStandardIds, string searchText)
        {
            if (pagination == null)
            {
                return (new List<SearchAmoFeaturesGridDataModel>(), 0);
            }

            List<(string, string, Type)> modelMappings = new List<(string, string, Type)>
            {
                (nameof(SearchAmoFeaturesGridDataModel.FeatureId), "FeatureId", typeof(int)),
                (nameof(SearchAmoFeaturesGridDataModel.FeatureFullName), "FeatureFullName", typeof(string)),
                (nameof(SearchAmoFeaturesGridDataModel.PMG100DTDescription), "PMG100_DT", typeof(string)),
                (nameof(SearchAmoFeaturesGridDataModel.FeatureCategoryId), "FeatureCategoryId", typeof(int)),
                (nameof(SearchAmoFeaturesGridDataModel.FeatureCategoryName), "FeatureCategoryName", typeof(string)),
                (nameof(SearchAmoFeaturesGridDataModel.DeliveryType), "DeliveryType", typeof(string)),
                (nameof(SearchAmoFeaturesGridDataModel.AscmCategoryId), "AscmCategoryId", typeof(int)),
                (nameof(SearchAmoFeaturesGridDataModel.AscmCategoryName), "AscmCategoryName", typeof(string)),
                (nameof(SearchAmoFeaturesGridDataModel.NamingStandardId), "NamingStandardId", typeof(int))
            };

            string orderByClause = pagination.ToSqlOrderBy();
            string whereClause = pagination.Filters.ToSqlWhere();
            List<SqlParameter> parameters = new List<SqlParameter> {
                                                                    new SqlParameter("FeatureCategoryId", featureCategoryId),
                                                                    new SqlParameter("NamingStandardIds", namingStandardIds),
                                                                    new SqlParameter("SearchTxt", searchText),
                                                                    new SqlParameter("PageNo",pagination.PageNo),
                                                                    new SqlParameter("PageSize", pagination.PageSize),
                                                                    new SqlParameter("OrderByClause", orderByClause.Replace(nameof(SearchAmoFeaturesGridDataModel.PMG100DTDescription), "PMG100_DT")),
                                                                    new SqlParameter("WhereClause", whereClause.Replace(nameof(SearchAmoFeaturesGridDataModel.PMG100DTDescription), "PMG100_DT"))};

            IReadOnlyList<SearchAmoFeaturesGridDataModel> dataRows;
            int? dataCount;
            (dataRows, dataCount) = await _dbContext.GetDataModelsAsync<SearchAmoFeaturesGridDataModel>(StoredProcedureNames.AmoFeatureSearchResult,
                                                                                                        parameters,
                                                                                                        modelMappings).ConfigureAwait(false);
            return (dataRows, dataCount);
        }

        public async Task<IReadOnlyList<(int SkuTypeId, string SkuTypeName)>> GetSkuTypesAsync()
        {
            IPulsarDataReader reader = await _dbContext.GetDataReaderAsync(StoredProcedureNames.SkuTypes, null).ConfigureAwait(false);
            List<(int SkuTypeId, string SkuTypeName)> skuTypes = new List<(int SkuTypeId, string SkuTypeName)>();

            for (int i = 0; i < reader.RowCount; i++)
            {
                if (reader.TryGetIntValue("Id", i, out int? skuTypeId)
                    && skuTypeId.HasValue
                    && reader.TryGetStringValue("Text", i, out string skuTypeName))
                {
                    skuTypes.Add((skuTypeId.Value, skuTypeName));
                }
            }

            return skuTypes;
        }

        public async Task<IReadOnlyList<(int RegionId, string RegionName)>> GetRegionsAsync()
        {
            IPulsarDataReader reader = await _dbContext.GetDataReaderAsync(StoredProcedureNames.Regions, null).ConfigureAwait(false);
            List<(int RegionId, string RegionName)> regions = new List<(int RegionId, string RegionName)>();

            for (int i = 0; i < reader.RowCount; i++)
            {
                if (reader.TryGetIntValue("Id", i, out int? regionId)
                    && regionId.HasValue
                    && reader.TryGetStringValue("Name", i, out string regionName)
                    && reader.TryGetStringValue("OptionConfig", i, out string regionOptionConfig))
                {
                    regions.Add((regionId.Value, $"{regionName}({regionOptionConfig})"));
                }
            }

            return regions;
        }

        public async Task<string> AddFeaturesToAscmAsync(IReadOnlyList<AddAmoFeaturesToAscmInputModel> featuresToAscmInputModels, int updaterUserId)
        {
            List<string> returnResult = new List<string>();

            foreach (var features in featuresToAscmInputModels)
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("featureID", features.FeatureId));
                parameters.Add(new SqlParameter("skuTypeIds", features.SkuTypeIds));
                parameters.Add(new SqlParameter("productLineIds", features.ProductLineIds));
                parameters.Add(new SqlParameter("regionIds", features.RegionIds));
                parameters.Add(new SqlParameter("updater", updaterUserId));
                parameters.Add(new SqlParameter("result", string.Empty) { Direction = System.Data.ParameterDirection.Output });

                if (features.AscmCategoryId.HasValue)
                {
                    parameters.Add(new SqlParameter("ascmCategoryId", features.AscmCategoryId.Value));
                }
                else
                {
                    parameters.Add(new SqlParameter("ascmCategoryId", DBNull.Value));
                }

                object result = await _dbContext.ExecuteScalarAsync(StoredProcedureNames.AddAMOFeaturesToASCM, parameters).ConfigureAwait(false);

                if (result != null && !string.IsNullOrWhiteSpace(result.ToString()))
                {
                    returnResult.Add($"FeatureId {features.FeatureId} : {result}");
                }
            }

            if (returnResult.Count > 0)
            {
                return string.Join("; ", returnResult);
            }

            return string.Empty;
        }
    }
}
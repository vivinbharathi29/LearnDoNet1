﻿using System.Collections.Generic;
using HP.Pulsar.Infrastructure.IgGrid;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Helper
{
    public static class AscmGridHelper
    {
        public static string GetColumnsDataJsonString(IReadOnlyList<IgGridColumnData> gridColumnsData)
        {
            return JsonConvert.SerializeObject(gridColumnsData);
        }

        public static string GetFeaturesDataJsonString(bool gridCheckboxStatus,
                                                       IgGridFeatures gridFeatures,
                                                       bool isGridUpdatingActive = false,
                                                       bool isGridFilteringActive = true,
                                                       bool isGridPagingActive = true)
        {
            if (gridFeatures == null)
            {
                gridFeatures = IgGridHelper.GetDefaultGridFeatures();
            }

            List<string> results = new List<string>();

            if (gridCheckboxStatus)
            {
                results.Add(JsonConvert.SerializeObject(gridFeatures.RowSelector));
                results.Add(JsonConvert.SerializeObject(gridFeatures.RowSelection));
            }

            if (isGridFilteringActive)
            {
                results.Add(JsonConvert.SerializeObject(gridFeatures.Filtering));
            }

            if (isGridPagingActive)
            {
                results.Add(JsonConvert.SerializeObject(gridFeatures.Paging));
            }

            results.Add(JsonConvert.SerializeObject(gridFeatures.Sorting));
            results.Add(JsonConvert.SerializeObject(gridFeatures.ToolTips));

            if (isGridUpdatingActive)
            {
                results.Add(JsonConvert.SerializeObject(gridFeatures.Updating));
            }

            return string.Join(",", results);
        }
    }
}
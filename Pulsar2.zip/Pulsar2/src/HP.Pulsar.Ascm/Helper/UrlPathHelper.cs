﻿using System;
using System.Collections.Generic;
using HP.Pulsar.Ascm.Infrastructure;

namespace HP.Pulsar.Ascm.Helper
{
    public static class UrlPathHelper
    {
        public static UrlPathModel GetGridDataUrllPath(int tabId, IReadOnlyDictionary<string, string> parameters = null)
        {
            IDictionary<string, string> dict = parameters == null ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) : new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase);
            dict.Add(QueryStringKeyNames.AscmTabId, tabId.ToString());
            return new UrlPathModel(ControllerNameConstants.Ascm, ActionNameConstants.GetGridData, dict);
        }

        public static UrlPathModel GetShortcutUrlPath(string controllerName, string actionName, IReadOnlyDictionary<string, string> parameters = null)
        {
            IReadOnlyDictionary<string, string> dict = parameters == null ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) : new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase);
            return new UrlPathModel(controllerName, actionName, dict);
        }

        public static UrlPathModel GetWizardControllerUrl(IReadOnlyDictionary<string, string> parameters = null)
        {
            IReadOnlyDictionary<string, string> dict = parameters == null ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) : new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase);
            return new UrlPathModel(ControllerNameConstants.Wizard, ActionNameConstants.Index, dict);
        }

        public static UrlPathModel GetDataCacheUrl(IReadOnlyDictionary<string, string> parameters = null)
        {
            return new UrlPathModel(ControllerNameConstants.Ascm, ActionNameConstants.SetDataCache, parameters);
        }

        public static UrlPathModel GetWizardGridDataUrllPath(int wizardId, IReadOnlyDictionary<string, string> parameters = null)
        {
            IDictionary<string, string> dict = parameters == null ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) : new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase);
            dict.Add(QueryStringKeyNames.WizardId, wizardId.ToString());
            return new UrlPathModel(ControllerNameConstants.Ascm, ActionNameConstants.GetWizardGridData, dict);
        }

        public static UrlPathModel GetQueryStringCacheUrlPath(IReadOnlyDictionary<string, string> parameters = null) 
        {
            IDictionary<string, string> dict = parameters == null ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) : new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase);
            return new UrlPathModel(ControllerNameConstants.SimpleDataCache, ActionNameConstants.Set, dict);
        }
    }
}
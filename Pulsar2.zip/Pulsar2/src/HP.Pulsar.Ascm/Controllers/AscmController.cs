﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.CommonContracts.Infrastructure.Telemetry;
using HP.Pulsar.Infrastructure.Abstractions.UserInfo;
using HP.Pulsar.Infrastructure.Extensions;
using HP.Pulsar.Infrastructure.Helpers;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Serialization;

namespace HP.Pulsar.Ascm.Controllers
{
    [DisableCors]
    public class AscmController : Controller
    {
        private readonly IAscmTabService _ascmTabService;
        private readonly IUserMemoryCache _userCache;
        private readonly ITelemetryFactory _telemetryFactory;
        private readonly IAscmAdminRepository _ascmAdminRepository;
        private readonly IAddHpPartNumberCacheWrapper _addHpPartNumberCache;
        private readonly ISimpleDataCache _dataCache;
        private readonly string _searchFeaturesQueryStringCacheKey = CacheKeyConstants.SearchFeaturesQueryStringCacheKey;

        public AscmController(IAscmTabService ascmTabService,
                              IUserMemoryCache userCache,
                              ITelemetryFactory telemetryFactory,
                              IAscmAdminRepository ascmAdminRepository,
                              IAddHpPartNumberCacheWrapper addHpPartNumberCache,
                              ISimpleDataCache dataCache)
        {
            _ascmTabService = ascmTabService;
            _userCache = userCache;
            _telemetryFactory = telemetryFactory;
            _ascmAdminRepository = ascmAdminRepository;
            _addHpPartNumberCache = addHpPartNumberCache;
            _dataCache = dataCache;
        }

        public async Task<IActionResult> Index(Dictionary<string, string> input)
        {
            if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
            {
                string reason = "AscmAdmin : Cannot get current user object";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return View(ViewUrlPathConstants.ErrorViewUrlRelativePath);
            }

            if (input == null || !input.TryGetAscmTabId(out int tabId))
            {
                tabId = 1;
            }

            if (!_ascmTabService.TryGetAscmTab(tabId, out IAscmTab ascmTab))
            {
                string reason = "AscmAdmin : Unable to find the Tab.";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return View(ViewUrlPathConstants.ErrorViewUrlRelativePath);
            }

            try
            {
                AscmPageModel ascmPage = new AscmPageModel()
                {
                    AscmTabs = _ascmTabService.GetAscmTabs(),
                    PartialViewUrl = ascmTab.PartialViewUrlPath,
                    TabContentModel = await ascmTab.GetTabContentModelAsync()
                };

                return View(ascmPage.ViewUrlPath, ascmPage);
            }
            catch (Exception ex)
            {
                string reason = "AscmAdmin : Unexpected exception";
                _telemetryFactory.SendFaultTelemetryEvent(reason, ex, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return View(ViewUrlPathConstants.ErrorViewUrlRelativePath);
            }
        }

        public async Task<IActionResult> GetGridData(Dictionary<string, string> input)
        {
            if (input == null || !input.TryGetAscmTabId(out int tabId))
            {
                string reason = "GetGridData : Query string is null or not able to get tab id.";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return View(ViewUrlPathConstants.ErrorViewUrlRelativePath);
            }

            IPaginationModel pagination = input.ToPagination();

            if (!_ascmTabService.TryGetAscmTab(tabId, out IAscmTab ascmTab))
            {
                string reason = "GetGridData : tab is null";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return View(ViewUrlPathConstants.ErrorViewUrlRelativePath);
            }

            (IReadOnlyList<IGridDataModel> DataList, int? DataCount) = await ascmTab.GetGridDataAsync(pagination);

            var result = new
            {
                page = pagination.PageNo,
                pageSize = pagination.PageSize,
                Records = DataList.AsQueryable(),
                TotalRecordsCount = DataCount
            };

            return Json(result, ascmTab.GetJsonSerializerSettings());
        }

        public async Task<IActionResult> GetProductLines()
        {
            //TODO: remove try catch
            IReadOnlyList<(int ProductLineId, string ProductLineName)> productLines;
            try
            {
                productLines = await HpPartNumberHelper.GetProductLines(_ascmAdminRepository);
            }
            catch (Exception ex)
            {
                productLines = new List<(int ProductLineId, string ProductLineName)>();
                string reason = "GetProductLines : Unexpected exception";
                _telemetryFactory.SendFaultTelemetryEvent(reason, ex, nameof(AscmController));
            }

            return Json(productLines);
        }

        public async Task<IActionResult> GetAscmCategories()
        {
            //TODO: remove try catch
            IReadOnlyList<(int AscmCategoryId, string AscmCategoryName)> categories;
            try
            {
                categories = await HpPartNumberHelper.GetAscmCategories(_ascmAdminRepository);
            }
            catch (Exception ex)
            {
                categories = new List<(int AscmCategoryId, string AscmCategoryName)>();
                string reason = "GetAscmCategories : Unexpected exception";
                _telemetryFactory.SendFaultTelemetryEvent(reason, ex, nameof(AscmController));
            }

            return Json(categories);
        }

        [HttpPost]
        public async Task<(bool Result, string Message)> BatchUpdateHpPartNumbers([FromBody]BatchUpdateHpPartNumbersModel batchUpdateHpPartNumbersModel)
        {
            try
            {
                if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
                {
                    string reason = "BatchUpdateHpPartNumbers : Cannot get current user object";
                    _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                    ViewData["ErrorReason"] = reason;
                    return (false, reason);
                }

                currentUser = await currentUser.GetSystemLevelImpersonatedUserAsync() ?? currentUser;

                string result = await HpPartNumberHelper.BatchUpdateHpPartNumbers(_ascmAdminRepository, batchUpdateHpPartNumbersModel, currentUser.Id);
                return (true, result);
            }
            catch (Exception ex)
            {
                string reason = "BatchUpdateHpPartNumbers : Unexpected exception";
                _telemetryFactory.SendFaultTelemetryEvent(reason, ex, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return (false, ex.Message);
            }
        }

        public async Task<IActionResult> GetHpPartNumber(int featureId, int productLineId, int skuTypeId, int localizationId)
        {
            if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
            {
                string reason = "GetHpPartNumber : Cannot get current user object";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return View(ViewUrlPathConstants.ErrorViewUrlRelativePath);
            }

            currentUser = await currentUser.GetSystemLevelImpersonatedUserAsync() ?? currentUser;

            HpPartNumberOutputDataModel model = null;
            if (featureId > 0 && productLineId > 0 && skuTypeId > 0 && localizationId > 0)
            {
                model = await HpPartNumberHelper.GetHpPartNumber(_ascmAdminRepository, featureId, productLineId, skuTypeId, localizationId);
                model.CurrentUserId = currentUser.Id;
            }

            return View(ViewUrlPathConstants.HpPartNumberPropertiesUrlPath, model);
        }

        [HttpPost]
        public async Task<(bool Result, string Message)> SaveHpPartNumber([FromBody]HpPartNumberInputDataModel partNumberModel)
        {
            try
            {
                if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
                {
                    string reason = "SaveHpPartNumber : Cannot get current user object";
                    _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                    ViewData["ErrorReason"] = reason;
                    return (false, reason);
                }

                currentUser = await currentUser.GetSystemLevelImpersonatedUserAsync() ?? currentUser;

                string result = await HpPartNumberHelper.SaveHpPartNumberAsync(_ascmAdminRepository, partNumberModel, currentUser.Id);
                return (true, result);
            }
            catch (Exception ex)
            {
                string reason = "SaveHpPartNumber : Unexpected exception";
                _telemetryFactory.SendFaultTelemetryEvent(reason, ex, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return (false, ex.Message);
            }
        }

        [HttpPost]
        public async Task<(bool Result, string Message)> DeleteHpPartNumber([FromBody]HpPartNumberIdsModel hpPartNumberModel)
        {
            try
            {
                if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
                {
                    string reason = "DeleteHpPartNumber : Cannot get current user object";
                    _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                    ViewData["ErrorReason"] = reason;
                    return (false, reason);
                }

                currentUser = await currentUser.GetSystemLevelImpersonatedUserAsync() ?? currentUser;

                await HpPartNumberHelper.DeleteHpPartNumberAsync(_ascmAdminRepository, hpPartNumberModel, currentUser.Id);
                return (true, string.Empty);
            }
            catch (Exception ex)
            {
                string reason = "DeleteHpPartNumber : Unexpected exception";
                _telemetryFactory.SendFaultTelemetryEvent(reason, ex, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return (false, ex.Message);
            }
        }

        public async Task<IActionResult> GetAmoFeatureClasses()
        {
            IReadOnlyList<(int FeatureClassId, string FeatureClassName)> featureClasses = await HpPartNumberHelper.GetFeatureClasses(_ascmAdminRepository);
            return Json(featureClasses);
        }

        public async Task<IActionResult> GetAmoFeatureCategories(int featureClassId)
        {
            IReadOnlyList<(int FeatureCategoryId, string FeatureCategoryName)> featureCategories = await HpPartNumberHelper.GetFeatureCategories(_ascmAdminRepository, featureClassId);
            return Json(featureCategories);
        }

        public async Task<IActionResult> GetFeatureNamingStandards(int featureCategoryId)
        {
            IReadOnlyList<(int NamingStandardId, string NamingStandardName)> namingStandards = await HpPartNumberHelper.GetFeatureNamingStandards(_ascmAdminRepository, featureCategoryId);
            return Json(namingStandards);
        }

        public async Task<IActionResult> GetWizardGridData(Dictionary<string, string> input)
        {
            if (input == null || !input.TryGetWizardId(out int currentWizardId))
            {
                string reason = "GetWizardGridData : Query string is null or not able to get wizard id.";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return View(ViewUrlPathConstants.ErrorViewUrlRelativePath);
            }

            (int FeatureCategoryId, string NamingStandardIds, string SearchText) = HpPartNumberHelper.GetQueryStringParameterFromCache(_dataCache, _searchFeaturesQueryStringCacheKey);
            IPaginationModel pagination = input.ToPagination();
            (IReadOnlyList<IGridDataModel> DataList, int? DataCount) = await HpPartNumberHelper.GetSearchNewAmoFeaturesGridDataAsync(FeatureCategoryId, NamingStandardIds, SearchText, _ascmAdminRepository, pagination);

            var result = new
            {
                page = pagination.PageNo,
                pageSize = pagination.PageSize,
                Records = DataList.AsQueryable(),
                TotalRecordsCount = DataCount
            };

            return Json(result, JsonHelper.GetJsonSerializerSettings(new DefaultContractResolver()));
        }

        public Task<(bool Result, string Message)> SetDataCache(IDictionary<string, string> inputData)
        {
            if (inputData == null || !inputData.TryGetPostBody(out string postBody) || !inputData.TryGetWizardId(out int wizardId))
            {
                string reason = "SetDataCache : Query string is null or not able to cache data/wizard id.";
                _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return Task.FromResult<(bool, string)>((false, reason));
            }

            if (!inputData.TryGetCacheKey(out string cacheKey) || string.IsNullOrWhiteSpace(cacheKey))
            {
                cacheKey = Guid.NewGuid().ToString();
            }

            try
            {
                if (!string.IsNullOrEmpty(postBody))
                {
                    _addHpPartNumberCache.SetDataToCache(wizardId, cacheKey, postBody);
                }
                else
                {
                    string reason = "SetDataCache : Unable to get post data.";
                    _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                    return Task.FromResult<(bool, string)>((false, reason));
                }
            }
            catch (Exception ex)
            {
                const string reason = "SetDataCache : Unexpected exception";
                _telemetryFactory.SendFaultTelemetryEvent(reason, ex, nameof(AscmController));
                return Task.FromResult<(bool, string)>((false, ex.Message));
            }
            return Task.FromResult<(bool, string)>((true, cacheKey));
        }

        public async Task<IActionResult> GetSkuTypes()
        {
            IReadOnlyList<(int SkuTypeId, string SkuTypeName)> skuTypes = await HpPartNumberHelper.GetSkuTypes(_ascmAdminRepository);
            return Json(skuTypes);
        }

        public async Task<IActionResult> GetRegions()
        {
            IReadOnlyList<(int RegionId, string RegionName)> regions = await HpPartNumberHelper.GetRegions(_ascmAdminRepository);
            return Json(regions);
        }

        [HttpPost]
        public async Task<(bool Result, string Message)> AddFeaturesToAscm([FromBody]IReadOnlyList<AddAmoFeaturesToAscmInputModel> featuresToAscmInputModel)
        {
            try
            {
                if (!HttpContext.TryGetCurrentUser(_userCache, out IPulsarUser currentUser))
                {
                    string reason = "AddFeaturesToAscm : Cannot get current user object";
                    _telemetryFactory.SendFaultTelemetryEvent(reason, null, nameof(AscmController));
                    ViewData["ErrorReason"] = reason;
                    return (false, reason);
                }

                currentUser = await currentUser.GetSystemLevelImpersonatedUserAsync() ?? currentUser;
                string result = await HpPartNumberHelper.AddFeaturesToAscm(_ascmAdminRepository, featuresToAscmInputModel, currentUser.Id);
                return (true, result);
            }
            catch (Exception ex)
            {
                string reason = "AddFeaturesToAscm : Unexpected exception";
                _telemetryFactory.SendFaultTelemetryEvent(reason, ex, nameof(AscmController));
                ViewData["ErrorReason"] = reason;
                return (false, ex.Message);
            }
        }
    }
}
﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.CommonContracts.Infrastructure.Pagination;
using HP.Pulsar.Infrastructure.IgGrid;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using HP.Pulsar.CommonContracts.Infrastructure.Popup;
using HP.Pulsar.Infrastructure.Popup;

namespace HP.Pulsar.Ascm.Tabs
{
    public class AllOptionsTab : IAscmTab
    {
        private readonly IAscmShortcutService _shortcutService;
        private readonly IAscmAdminRepository _repository;
        private readonly List<IgGridColumnData> _columnsData;
        private readonly IgGridFeatures _gridFeatures;
        private bool _gridCheckboxStatus;
        private string _gridDataUrlPath = "";

        public AllOptionsTab(IAscmAdminRepository repository, IAscmShortcutService shortcutService)
        {
            _shortcutService = shortcutService;
            _repository = repository;
            _columnsData = new List<IgGridColumnData>();
            _gridFeatures = IgGridHelper.GetDefaultGridFeatures();
            _gridDataUrlPath = UrlPathHelper.GetGridDataUrllPath(Id).UrlPath;
        }

        public int Id => 1;
        public string Name => "All Options";
        public string PartialViewUrlPath => ViewUrlPathConstants.AllOptionsPartialViewUrlPath;

        private IEnumerable<IAscmShortcut> GetShortcuts()
        {
            if (!_shortcutService.TryGetAscmTab(tabId: Id, out IEnumerable<IAscmShortcut> shortcuts))
            {
                shortcuts = new List<IAscmShortcut>();
            }
            return shortcuts;
        }

        private IReadOnlyList<IgGridContentModelOperation> GetContextMenuOperations()
        {
            int heightPercent = PopupSize.Big.GetHeightPercentage();
            int widthPercent = PopupSize.Big.GetWidthPercentage();
            return new List<IgGridContentModelOperation>
            {
                new IgGridContentModelOperation
                {
                    Type = GridContentModelOperationType.BindCustomJavascript,
                    OperationName = "Properties",
                    JavascriptFunctionName = $"GetHpPartNumber('{ActionNameConstants.HpPartNoPropertiesActionName}','Properties', {heightPercent}, {widthPercent})"
                },
                new IgGridContentModelOperation
                {
                    OperationName = "Delete",
                    Type = GridContentModelOperationType.BindCustomJavascript,
                    JavascriptFunctionName =$"ConfirmHpPartNumberDeletePopUp('{ActionNameConstants.DeletePartNumberActionName}')",
                    OnRenderJavascriptionFunctionName= $"ShowHideContextMenuItem('{nameof(AllOptionsGridDataModel.HpPartNumber)}', '==', '')"
                }
            };
        }

        public async Task<ITabContentModel> GetTabContentModelAsync()
        {
            _columnsData.Clear();
            _columnsData.AddColumnsData(typeof(AllOptionsGridDataModel));
            _gridCheckboxStatus = true;
            IReadOnlyList<IGridContentModelOperation> contextMenuOperations = GetContextMenuOperations();
            return new TabContentModel(ascmTab: this,
                                       canShowGridCheckBox: _gridCheckboxStatus,
                                       gridColumnsData: _columnsData,
                                       gridFeatures: _gridFeatures,
                                       gridDataUrlPath: _gridDataUrlPath,
                                       contextMenuOperations: contextMenuOperations,
                                       activeTabId: Id,
                                       shortcuts: GetShortcuts());
        }

        public Task<(IReadOnlyList<IGridDataModel> DataList, int? DataCount)> GetGridDataAsync(IPaginationModel pagination)
        {
            return _repository.GetHpPartNumbersAsync(pagination);
        }

        public JsonSerializerSettings GetJsonSerializerSettings()
        {
            return JsonHelper.GetJsonSerializerSettings(new DefaultContractResolver());
        }
    }
}
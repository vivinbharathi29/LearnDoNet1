﻿namespace HP.Pulsar.Ascm
{
    public static class TabIdConstants
    {
        public static readonly int AllOptions = 1;
    }
}
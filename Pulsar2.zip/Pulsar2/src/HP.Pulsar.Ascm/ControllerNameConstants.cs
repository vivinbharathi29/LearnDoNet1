﻿namespace HP.Pulsar.Ascm
{
    public static class ControllerNameConstants
    {
        public static readonly string Ascm = "Ascm";
        public static readonly string Wizard = "Wizard";
        public static readonly string SimpleDataCache = "SimpleDataCache";
    }
}
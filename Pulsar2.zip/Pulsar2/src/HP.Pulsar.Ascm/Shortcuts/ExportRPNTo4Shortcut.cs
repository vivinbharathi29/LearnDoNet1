﻿using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Popup;
using HP.Pulsar.Infrastructure.Popup;

namespace HP.Pulsar.Ascm.Shortcuts
{
    public class ExportRPNTo4Shortcut : IAscmShortcut
    {
        private const string _javascriptFunctionName = "OpenExportRpnPopUp";
        private const string _displayName = "Export RPN to S4";

        public ExportRPNTo4Shortcut()
        {
            int heightPercent = PopupSize.Small.GetHeightPercentage();
            int widthPercent = PopupSize.Small.GetWidthPercentage();
            JavaScriptFunctionName = $"{_javascriptFunctionName}('{GetUrlPath()}', '{Name}', {heightPercent}, {widthPercent})";
        }

        public string Name => _displayName;

        public int TabId => TabIdConstants.AllOptions;

        public ShortcutOperationType Type => ShortcutOperationType.ShowURLInPopup;

        public string JavaScriptFunctionName { get; set; }

        public string GetUrlPath()
        {
            return ShortcutUrlPathConstants.ExportRPNToS4;
        }
    }
}

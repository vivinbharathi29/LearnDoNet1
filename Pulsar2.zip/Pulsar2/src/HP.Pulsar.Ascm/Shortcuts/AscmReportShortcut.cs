﻿using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Models;

namespace HP.Pulsar.Ascm.Shortcuts
{
    public class AscmReportShortcut : IAscmShortcut
    {
        private const string _displayName = "Report";

        public string Name => _displayName;

        public int TabId => 1;

        public ShortcutOperationType Type => ShortcutOperationType.ShowURLInNewBrowserTab;

        public string JavaScriptFunctionName { get; set; }

        public string GetUrlPath()
        {
            return ShortcutUrlPathConstants.AscmReport;
        }
    }
}
﻿using System;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Ascm.Models
{
    public class AllOptionsGridDataModel : IGridDataModel
    {
        [IgGridColumnAttributes(HeaderText = "Feature ID")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(HeaderText = "HP PN")]
        public string HpPartNumber { get; set; }

        [IgGridColumnAttributes(HeaderText = "Description")]
        public string PMG100DTDescription { get; set; }

        [IgGridColumnAttributes(HeaderText = "Business Segment")]
        public string BusinessSegment { get; set; }

        [IgGridColumnAttributes(HeaderText = "ASCM Category")]
        public string AscmCategoryName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Product Line")]
        public string ProductLineName { get; set; }

        [IgGridColumnAttributes(HeaderText = "RTP/MR Date", Format = "MM/dd/yyyy")]
        public DateTime? RTPDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Select Availability (SA) Date", Format = "MM/dd/yyyy")]
        public DateTime? SaDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "General Availability (GA) Date", Format = "MM/dd/yyyy")]
        public DateTime? GaDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "End of Manufacturing (EM) Date", Format = "MM/dd/yyyy")]
        public DateTime? EmDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Global Series EOL", Format = "MM/dd/yyyy")]
        public DateTime? GsEolDate { get; set; }

        [IgGridColumnAttributes(HeaderText = "Previous Product")]
        public string PreviousProduct { get; set; }

        [IgGridColumnAttributes(HeaderText = "Comments")]
        public string Comment { get; set; }

        [IgGridColumnAttributes(HeaderText = "SKU Type")]
        public string SkuType { get; set; }

        [IgGridColumnAttributes(HeaderText = "Created by")]
        public string Creator { get; set; }

        [IgGridColumnAttributes(HeaderText = "Last Updated by")]
        public string Updater { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int ProductLineId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int SkuTypeId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int LocalizationId { get; set; }
    }
}

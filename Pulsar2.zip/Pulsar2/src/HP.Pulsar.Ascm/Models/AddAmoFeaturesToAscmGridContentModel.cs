﻿using System;
using System.Collections.Generic;
using System.Reflection;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.Infrastructure.IgGrid;

namespace HP.Pulsar.Ascm.Models
{
    public class AddAmoFeaturesToAscmGridContentModel : IGridContentModel
    {
        private readonly List<IgGridColumnData> _columnsData;
        private readonly IgGridFeatures _gridFeatures;
        private bool _gridUpdatingFeature;

        public AddAmoFeaturesToAscmGridContentModel(bool canShowGridCheckBox)
        {
            _columnsData = new List<IgGridColumnData>();
            _columnsData.AddColumnsData(typeof(AddAmoFeaturesToAscmGridDataModel));
            _gridFeatures = IgGridHelper.GetDefaultGridFeatures();
            CanShowGridCheckBox = canShowGridCheckBox;
            _gridUpdatingFeature = true;
            AddDisabledUpdateColumnSettings();
        }

        protected IgGridFeatures AddDisabledUpdateColumnSettings()
        {
            Type modelType = typeof(AddAmoFeaturesToAscmGridDataModel);

            foreach (PropertyInfo property in modelType.GetProperties())
            {
                _gridFeatures.Updating.ColumnSettings.Add(new IgGridUpdateColumnSettings(property.Name));
            }

            return _gridFeatures;
        }

        public bool CanShowGridCheckBox { get; }

        public string ColumnsData => _columnsData != null ? AscmGridHelper.GetColumnsDataJsonString(_columnsData) : string.Empty;

        public string ColumnTemplateDefinition => string.Empty;

        public IReadOnlyList<IGridContentModelOperation> ContextMenuOperations => new List<IGridContentModelOperation>();

        public ExcelExportWays ExcelExport => ExcelExportWays.None;

        //because the grid data always comes from cache
        public string GridDataUrlRelativePath => string.Empty;

        public string GridFeatures => AscmGridHelper.GetFeaturesDataJsonString(CanShowGridCheckBox, _gridFeatures, isGridUpdatingActive: _gridUpdatingFeature, isGridFilteringActive: false, isGridPagingActive: false);

        public IGridContentModelOperation GridRowOperation => null;

        public IReadOnlyList<IGridContentModelOperation> TopLinkOperations => new List<IGridContentModelOperation>();
    }
}

﻿using System.Collections.Generic;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.Infrastructure.IgGrid;

namespace HP.Pulsar.Ascm.Models
{
    public class SearchAmoFeaturesGridContentModel : IGridContentModel
    {
        private readonly List<IgGridColumnData> _columnsData;
        private readonly IgGridFeatures _gridFeatures;

        public SearchAmoFeaturesGridContentModel(bool canShowGridCheckBox, string gridDataUrlPath)
        {
            _columnsData = new List<IgGridColumnData>();
            _columnsData.AddColumnsData(typeof(SearchAmoFeaturesGridDataModel));
            _gridFeatures = IgGridHelper.GetDefaultGridFeatures();
            GridDataUrlRelativePath = gridDataUrlPath;
            CanShowGridCheckBox = canShowGridCheckBox;
        }

        public bool CanShowGridCheckBox { get; }

        public string ColumnsData => _columnsData != null ? AscmGridHelper.GetColumnsDataJsonString(_columnsData) : string.Empty;

        public string ColumnTemplateDefinition => string.Empty;

        public IReadOnlyList<IGridContentModelOperation> ContextMenuOperations => new List<IGridContentModelOperation>();

        public ExcelExportWays ExcelExport => ExcelExportWays.None;

        public string GridDataUrlRelativePath { get; }

        public string GridFeatures => AscmGridHelper.GetFeaturesDataJsonString(CanShowGridCheckBox, _gridFeatures);

        public IGridContentModelOperation GridRowOperation => null;

        public IReadOnlyList<IGridContentModelOperation> TopLinkOperations => new List<IGridContentModelOperation>();
    }
}
﻿using System.Collections.Generic;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.CommonContracts.Infrastructure;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Ascm.Models
{
    public class AddAmoFeaturesToAscmWizardContentModel : IAscmWizardContentModel, IControllerToViewDataModelShim
    {
        private const string _wizardDisplayName = "New AMO Feature(s) to be added to ASCM";

        public AddAmoFeaturesToAscmWizardContentModel(string cacheKey, IGridContentModel gridContentModel)
        {
            CacheKey = cacheKey;
            GridContentModel = gridContentModel;
        }

        public string CacheKey { get; set; }

        public bool CanGoToNext => false;

        public bool CanGoToPrevious => true;

        public string WizardControllerUrl => UrlPathHelper.GetWizardControllerUrl().UrlPath;

        public string ViewUrlPath => ViewUrlPathConstants.AddAmoFeaturesToAscmWizardUrlPath;

        public string SetCacheUrl => UrlPathHelper.GetDataCacheUrl().UrlPath;

        public int WizardId => WizardIdConstants.AddAmoFeaturesToAscm;

        public string WizardDisplayName => _wizardDisplayName;

        public string GriDataFromCached { get; set; }

        public IGridContentModel GridContentModel { get; }
    }
}
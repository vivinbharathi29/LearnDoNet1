﻿namespace HP.Pulsar.Ascm.Models
{
    public class AddNewHpPartNumberGridDataCacheModel
    {
        public int FeatureId { get; set; }

        public string FeatureFullName { get; set; }

        public string Description { get; set; }

        public int FeatureCategoryId { get; set; }

        public string FeatureCategoryName { get; set; }

        public string DeliveryType { get; set; }

        public int AscmCategoryId { get; set; }

        public string AscmCategoryName { get; set; }

        public string ProductLineIds { get; set; }

        public string ProductLineNames { get; set; }

        public string SkuTypeIds { get; set; }

        public string SkuTypeNames { get; set; }

        public string RegionIds { get; set; }

        public string RegionNames { get; set; }

        public int NamingStandardId { get; set; }

        public bool IsSelected { get; set; }
    }
}
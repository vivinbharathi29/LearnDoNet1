﻿namespace HP.Pulsar.Ascm.Models
{
    public class HpPartNumberIdsModel
    {
        public int FeatureId { get; set; }
        public int ProductLineId { get; set; }
        public int SkuTypeId { get; set; }
        public int LocalizationId { get; set; }
    }
}

﻿using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.CommonContracts.Infrastructure;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Ascm.Models
{
    public class SearchAmoFeaturesWizardContentModel : IAscmWizardContentModel, IControllerToViewDataModelShim
    {
        private const string _wizardDisplayName = "Add HP Part Number(s)";

        public SearchAmoFeaturesWizardContentModel(string cacheKey, IGridContentModel gridContentModel)
        {
            CacheKey = cacheKey;
            GridContentModel = gridContentModel;
        }

        public string CacheKey { get; }

        public bool CanGoToNext => true;

        public bool CanGoToPrevious => false;

        public string WizardControllerUrl => UrlPathHelper.GetWizardControllerUrl().UrlPath;

        public string ViewUrlPath => ViewUrlPathConstants.SearchAmoFeaturesWizardUrlPath;

        public string SetCacheUrl => UrlPathHelper.GetDataCacheUrl().UrlPath;

        public int WizardId => WizardIdConstants.SearchAmoFeatures;

        public string WizardDisplayName => _wizardDisplayName;

        public string FeatureClassesFromCache { get; set; }

        public string FeatureCategoriesFromCache { get; set; }

        public string FeatureNamingStandardsFromCache { get; set; }

        public string SearchTextFromCache { get; set; }

        public string GriDataFromCache { get; set; }

        public IGridContentModel GridContentModel { get; }

        public string SearchFeaturesQueryStringCacheKey => CacheKeyConstants.SearchFeaturesQueryStringCacheKey;

        public string QueryStringParamsCacheUrl => UrlPathHelper.GetQueryStringCacheUrlPath().UrlPath;
    }
}
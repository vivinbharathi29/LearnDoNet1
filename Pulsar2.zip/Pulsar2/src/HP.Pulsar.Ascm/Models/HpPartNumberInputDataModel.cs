﻿using System;

namespace HP.Pulsar.Ascm.Models
{
    public class HpPartNumberInputDataModel
    {
        public int FeatureId { get; set; }
        public int SkuTypeId { get; set; }
        public int LocalizationId { get; set; }
        public string HpPartNo { get; set; }
        public int? AscmCategoryId { get; set; }
        public int? ProductLineId { get; set; }
        public DateTime? RTPDate { get; set; }
        public DateTime? SaDate { get; set; }
        public DateTime? PaadDate { get; set; }
        public DateTime? GaDate { get; set; }
        public DateTime? EmDate { get; set; }
        public DateTime? GsEolDate { get; set; }
        public string Comments { get; set; }
        public int? OldFeatureId { get; set; }
        public int? OldProdcutLineId { get; set; }
    }
}

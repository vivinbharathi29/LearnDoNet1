﻿using System.Collections.Generic;
using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.Ascm.Helper;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.Infrastructure.IgGrid;

namespace HP.Pulsar.Ascm.Models
{
    public class TabContentModel : ITabContentModel
    {
        private readonly IAscmTab _ascmTab;
        private readonly IReadOnlyList<IgGridColumnData> _gridColumnsData;
        private readonly IgGridFeatures _gridFeatures;

        public TabContentModel(IAscmTab ascmTab,
                               bool canShowGridCheckBox,
                               IReadOnlyList<IgGridColumnData> gridColumnsData,
                               IgGridFeatures gridFeatures,
                               string gridDataUrlPath,
                               IReadOnlyList<IGridContentModelOperation> contextMenuOperations = null,
                               int activeTabId = 1,
                               IEnumerable<IAscmShortcut> shortcuts = null)
        {
            _ascmTab = ascmTab;
            CanShowGridCheckBox = canShowGridCheckBox;
            _gridColumnsData = gridColumnsData;
            _gridFeatures = gridFeatures;
            GridDataUrlRelativePath = gridDataUrlPath;
            ContextMenuOperations = contextMenuOperations ?? new List<IGridContentModelOperation>();
            ActiveTabId = activeTabId;
            Shortcuts = shortcuts;
        }

        public bool CanShowGridCheckBox { get; }

        public string ColumnsData => _ascmTab != null ? AscmGridHelper.GetColumnsDataJsonString(_gridColumnsData) : string.Empty;

        public string ColumnTemplateDefinition => string.Empty;

        public IReadOnlyList<IGridContentModelOperation> ContextMenuOperations { get; }

        public ExcelExportWays ExcelExport => ExcelExportWays.None;

        public string GridDataUrlRelativePath { get; }

        public string GridFeatures => AscmGridHelper.GetFeaturesDataJsonString(CanShowGridCheckBox, _gridFeatures);

        public IGridContentModelOperation GridRowOperation => null;

        public IReadOnlyList<IGridContentModelOperation> TopLinkOperations => new List<IGridContentModelOperation>();

        public int ActiveTabId { get; }

        public IEnumerable<IAscmShortcut> Shortcuts { get; }
    }
}
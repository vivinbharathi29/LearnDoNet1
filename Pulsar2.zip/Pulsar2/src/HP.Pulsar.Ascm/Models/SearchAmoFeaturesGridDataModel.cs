﻿using HP.Pulsar.Ascm.Abstrations;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;

namespace HP.Pulsar.Ascm.Models
{
    public class SearchAmoFeaturesGridDataModel : IGridDataModel
    {
        [IgGridColumnAttributes(HeaderText = "Feature ID")]
        public int FeatureId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Full Name")]
        public string FeatureFullName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Description(Marketing 100 Character - PMG)")]
        public string PMG100DTDescription { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int FeatureCategoryId { get; set; }

        [IgGridColumnAttributes(HeaderText = "Feature Category")]
        public string FeatureCategoryName { get; set; }

        [IgGridColumnAttributes(HeaderText = "Delivery Type")]
        public string DeliveryType { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int AscmCategoryId { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public string AscmCategoryName { get; set; }

        [IgGridColumnAttributes(IsHidden = true)]
        public int NamingStandardId { get; set; }
    }
}
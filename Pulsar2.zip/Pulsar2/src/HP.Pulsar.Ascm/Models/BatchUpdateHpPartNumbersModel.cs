﻿using System.Collections.Generic;

namespace HP.Pulsar.Ascm.Models
{
    public class BatchUpdateHpPartNumbersModel
    {
        public List<Dictionary<string, string>> SelectedIds { get; set; }
        public string ColumnName { get; set; }
        public int? UpdateValue { get; set; }
        public List<Dictionary<string, string>> UpdateDates { get; set; }
    }
}

﻿namespace HP.Pulsar.Ascm
{
    public static class WizardIdConstants
    {
        public static readonly int SearchAmoFeatures = 1;
        public static readonly int AddAmoFeaturesToAscm = 2;
    }
}
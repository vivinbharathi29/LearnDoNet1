﻿using System;
using System.Collections.Generic;
using System.Linq;
using HP.Pulsar.Ascm.Abstrations;
using Microsoft.Extensions.DependencyInjection;

namespace HP.Pulsar.Ascm.Service
{
    public class AscmShortcutService : IAscmShortcutService
    {
        private readonly IEnumerable<IAscmShortcut> _shortcuts;

        public AscmShortcutService(IServiceProvider serviceProvider)
        {
            _shortcuts = serviceProvider.GetServices<IAscmShortcut>();
        }

        public bool TryGetAscmTab(int tabId, out IEnumerable<IAscmShortcut> ascmShortcuts)
        {
            if (tabId == 0 || !_shortcuts.Any(s => s.TabId == tabId))
            {
                ascmShortcuts = null;
                return false;
            }

            ascmShortcuts = _shortcuts.Where(s => s.TabId == tabId);
            return ascmShortcuts.Any();
        }
    }
}
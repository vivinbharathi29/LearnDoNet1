﻿function GetDropDownOptions(actionUrl, dropdownObj, defaultValueObjId) {
    $.ajax({
        type: "POST",
        url: actionUrl,
        contentType: "application/json; charset=utf-8",
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data !== null && data !== "") {
                dropdownObj.igCombo("option", "dataSource", data);
                dropdownObj.igCombo("dataBind");
                if (defaultValueObjId !== null && defaultValueObjId !=="") {
                    dropdownObj.igCombo("value", $(defaultValueObjId).val());
                }
            }
        },
        error: function (xhr) {
            alert("Cannot get List");
        }
    });
}

function IsValidateDate(txtDate) {
    var currVal = txtDate;
    if (currVal == '')
        return false;

    var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var dtArray = currVal.match(rxDatePattern); // is format OK?

    if (dtArray == null)
        return false;

    dtMonth = dtArray[1];
    dtDay = dtArray[3];
    dtYear = dtArray[5];

    if (dtMonth < 1 || dtMonth > 12)
        return false;
    else if (dtDay < 1 || dtDay > 31)
        return false;
    else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31)
        return false;
    else if (dtMonth == 2) {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay > 29 || (dtDay == 29 && !isleap))
            return false;
    }
    return true;
}

function CalculateOtherDatesFromRtpDate(rtpDate) {
    rtpDate = new Date(rtpDate);
    var monday = GetMonday(rtpDate);
    var paadDate = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate());
    var tmpToday = new Date();
    var today = new Date(tmpToday.getFullYear(), tmpToday.getMonth(), tmpToday.getDate());
    var saDate = new Date(paadDate.getFullYear(), (paadDate.getMonth() - 1), 1);
    if (saDate < today) {
        saDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 7);
    }

    paadDate = (paadDate.getMonth() + 1) + "/" + paadDate.getDate() + "/" + paadDate.getFullYear();
    saDate = (saDate.getMonth() + 1) + "/" + saDate.getDate() + "/" + saDate.getFullYear();
    return { paadDate: paadDate, saDate: saDate };
}

function GetMonday(date) {
    date = new Date(date);
    var day = date.getDay();
    diff = date.getDate() - day + (day == 0 ? -6 : 1); // adjust when day is sunday
    return new Date(date.setDate(diff));
}

function ClosePopUpAndRefreshGrid() {
    $(popupDialog).dialog('close');
    RefreshGrid();
}
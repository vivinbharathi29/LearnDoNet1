﻿function GetDropDownOptions(actionUrl, dropdownObj, defaultValueObjId) {
    $.ajax({
        type: "POST",
        url: actionUrl,
        contentType: "application/json; charset=utf-8",
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null && data != "") {
                dropdownObj.igCombo("option", "dataSource", data);
                dropdownObj.igCombo("dataBind");
                if (defaultValueObjId != null && defaultValueObjId != "") {
                    dropdownObj.igCombo("value", $(defaultValueObjId).val());
                }
            }
        },
        error: function (xhr) {
            showMessageBox("Unable to get Dropdown Options", "Error", messageBoxImageError, messageBoxButtonOK, {});
        }
    });
}

function InitGrid() {
    $(gridId).igGrid({
        dataSource: _gridDataUrl,
        DataSourceType: "json",
        responseDataKey: "Records",
        autoGenerateColumns: true,
        columns: columnsData,
        features: igGridFeatures,
        cellClick: function (evt, ui) {
            selectedRowIndex = ui.rowIndex;
        },
        cellRightClick: function (evt, ui) {
            selectedRowIndex = ui.rowIndex;
        },
        headerCellRendered: function (evt, ui) {
        },
        rendered: function (evt, ui) {
            // If there is only one row and the row is invalid (having default values - zeros in the cells), make the row empty by removing zeros in the cells
            if (ui.owner.dataSource.dataView().length == 1 && !isGridRowValid(gridId, 0)) {
                makeGridRowEmpty(gridId, 0);
                modalMessage = new GridModalMessage(ui.owner);
                modalMessage.show("No Data Found");
            }
        },
        rowsRendered: function () {
            addToolTipToHeader();
        }
    });
}

function GetSearchResult() {
    SetQueryStringParametersToCache();
    $("#divBtn").show();
}

function SetQueryStringParametersToCache() {
    var namingStandardIds = [];
    var selectedNs = _cmbFeatureNamingStandard.igCombo("selectedItems");
    if (selectedNs != null) {
        for (var i = 0; i < selectedNs.length; i++) {
            namingStandardIds.push(selectedNs[i].data.item1);
        }
    }

    var selectedNamaingStandardIds = namingStandardIds.join(",");
    var selectedFeatureCategoryId = _cmbFeatureCategory.igCombo("value");
    var searchText = _txtFeatureSearch.val();   
    var postData = {};
    postData[_searchFeaturesQueryStringCacheKey] = selectedFeatureCategoryId + '|' + selectedNamaingStandardIds + '|' + searchText; 
    
    $.ajax({
        type: "POST",
        url: _queryStringParamsCacheUrl,
        data: postData,
        cache: false,
        dataType: "json",
        success: function () {
            GetGridData();
        },
        error: function () {
            showMessageBox("Operation failed. Please contact Pulsar support.", "Error", messageBoxImageError, messageBoxButtonOK, {});
        }
    });
}

function GetGridData() {
    if ($(gridId).data('igGrid') == null) {
        InitGrid();
    } else {
        $(gridId).igGrid("dataBind");
    }
}

function igGridTooltTipShowing(evt, args) {
    args.tooltip = args.element.innerText;
}

function addToolTipToHeader() {
    for (var itemNumber = 0; itemNumber < columnsData.length; itemNumber++) {
        var columnObject = columnsData[itemNumber];

        if (columnObject["hidden"] == false) {
            var gridColumnId = gridId + "_" + columnObject["key"];
            var toolTipText = columnObject["headerText"];
            $(gridColumnId).attr("title", toolTipText);
        }
    }
}

function isGridRowValid(grid, rowIndex) {
    var columnLength = $(grid).igGrid("option", "columns").length;
    var validRow = false;

    // check whether any of the column value in the given row has non-zero or non-blank space.
    // The row is said to be valid, if one of the column value has non-zero or non-blank space.
    for (var columnIndex = 0; columnIndex < columnLength; columnIndex++) {
        var cell = $($(grid).igGrid('cellAt', columnIndex, rowIndex));
        var cellContent = cell[0].innerHTML;

        if (cell.length > 0
            && (!cellContent == '0'
                || cellContent == ''
                || cellContent == '&nbsp;'
                || cellContent.indexOf("ui-igcheckbox") != -1
                || cellContent.indexOf("ui-igloadingmsg") != -1
                || cellContent == 'false'
                || cellContent == '1/1/0001 12:00')) {
            validRow = true;
            break;
        }
    }
    return validRow;
}

function makeGridRowEmpty(grid, rowIndex) {
    var columnLength = $(grid).igGrid("option", "columns").length;

    for (var columnIndex = 0; columnIndex < columnLength; columnIndex++) {
        var cell = $($(grid).igGrid('cellAt', columnIndex, rowIndex));
        if (cell.length > 0) {
            cell[0].innerHTML = "";
        }
    }
}

function GridModalMessage(grid) {
    var modalBackground = $("<div class='ui-widget-overlay ui-iggrid-blockarea' style='position: absolute; display: none; width: 100%; height: 100%;'><div style='position: relative;top:50%; text-align: center;'></div></div>").appendTo(grid.container());
    function _show(message) {
        modalBackground.show().find("div").text(message);
    }
    function _hide() {
        modalBackground.hide().find("div").text("");
    }
    return {
        show: _show,
        hide: _hide
    }
}

function GetFeaturesForCache() {
    var selectedFeatureIds = [];
    var selectdRows = $(gridId).igGrid("selectedRows");
    var dataview = $(gridId).data('igGrid').dataSource.dataView();
    for (var j = 0; j < selectdRows.length; j++) {
        selectedFeatureIds.push(dataview[selectdRows[j].index]["FeatureId"]);
    }

    var rows = $(gridId).igGrid("allRows");

    var features = [];
    for (var i = 0; i < rows.length; i++) {
        var featureId = dataview[i]["FeatureId"];
        var featurefullName = dataview[i]["FeatureFullName"];
        var description = dataview[i]["PMG100DTDescription"];
        var featureCategoryId = dataview[i]["FeatureCategoryId"];
        var featureCategoryName = dataview[i]["FeatureCategoryName"];
        var deliveryType = dataview[i]["DeliveryType"];
        var ascmCategoryId = dataview[i]["AscmCategoryId"];
        var ascmCategoryName = dataview[i]["AscmCategoryName"];
        var namingStandardId = dataview[i]["NamingStandardId"];
        features.push({
            featureId: featureId,
            featurefullName: featurefullName,
            description: description,
            featureCategoryId: featureCategoryId,
            featureCategoryName: featureCategoryName,
            deliveryType: deliveryType,
            ascmCategoryId: ascmCategoryId,
            ascmCategoryName: ascmCategoryName,
            namingStandardId: namingStandardId,
            isSelected: (selectedFeatureIds.indexOf(featureId) >= 0 ? true : false)
        });
    }
    return features;
}

function GetFeatureClassesForCache() {
    var allFeatureClasses = [];
    var allFeatureClassesOptions = _cmbFeatureClass.igCombo("listItems");
    for (var i = 0; i < allFeatureClassesOptions.length; i++) {
        allFeatureClasses.push({
            Id: allFeatureClassesOptions[i].dataset.value,
            Name: allFeatureClassesOptions[i].innerText,
            IsSelected: _cmbFeatureClass.igCombo("isValueSelected", allFeatureClassesOptions[i].dataset.value)
        });
    }

    return allFeatureClasses;
}

function GetFeatureCategoriesForCache() {
    var allFeatureCategories = [];
    var allFeatureCategoriesOptions = _cmbFeatureCategory.igCombo("listItems");
    for (var i = 0; i < allFeatureCategoriesOptions.length; i++) {
        allFeatureCategories.push({
            Id: allFeatureCategoriesOptions[i].dataset.value,
            Name: allFeatureCategoriesOptions[i].innerText,
            IsSelected: _cmbFeatureCategory.igCombo("isValueSelected", allFeatureCategoriesOptions[i].dataset.value)
        });
    }
    return allFeatureCategories;
}

function GetFeatureNamingStandardsForCache() {
    var allFeatureNamingStandards = [];
    var allFeatureNamingStandardsOptions = _cmbFeatureNamingStandard.igCombo("listItems");
    for (var i = 0; i < allFeatureNamingStandardsOptions.length; i++) {
        allFeatureNamingStandards.push({
            Id: allFeatureNamingStandardsOptions[i].dataset.value,
            Name: allFeatureNamingStandardsOptions[i].innerText,
            IsSelected: _cmbFeatureNamingStandard.igCombo("isValueSelected", allFeatureNamingStandardsOptions[i].dataset.value)
        });
    }
    return allFeatureNamingStandards;
}

function CacheData() {
    var postBody = {
        FeatureClasses: GetFeatureClassesForCache(),
        FeatureCategories: GetFeatureCategoriesForCache(),
        NamingStandards: GetFeatureNamingStandardsForCache(),
        SearchText: _txtFeatureSearch == null ? "" : _txtFeatureSearch.val(),
        AmoFeatures: GetFeaturesForCache()
    };

    $.ajax({
        url: _cacheDataUrl,
        data: {
            wizardId: _wizardID,
            cacheKey: _cacheKey,
            PostBody: JSON.stringify(postBody)
        },
        type: "POST",
        dataType: "json",
        success: function (result) {
            if (result.item1) {
                _cacheKey = result.item2;
                GotoAddAmoFeaturesToAscmPage();
            } else {
                showMessageBox("Unable to save data in cache: " + result.item2, "Warning", messageBoxImageError, messageBoxButtonOK, {});
            }
        },
        error: function (xhr) {
            showMessageBox("Unable to save data in cache", "Error", messageBoxImageError, messageBoxButtonOK, {});
        }
    });
}

function LoadFeatureClassesFromCache() {
    var featureClassFromCache = JSON.parse($("#featureClassFromCache").val());
    var featureClasses = [];
    var selectedFeatureClass;
    for (var i = 0; i < featureClassFromCache.length; i++) {
        featureClasses.push({
            item1: featureClassFromCache[i].Id,
            item2: featureClassFromCache[i].Name
        });
        if (featureClassFromCache[i].IsSelected) {
            selectedFeatureClass = featureClassFromCache[i].Id;
        }
    }
    if (featureClasses.length > 0) {
        _cmbFeatureClass.igCombo("option", "dataSource", featureClasses);
        _cmbFeatureClass.igCombo("dataBind");
        _cmbFeatureClass.igCombo("value", selectedFeatureClass);
    }
}

function LoadFeatureCategoriesFromCache() {
    var featureCategoryFromCache = JSON.parse($("#featureCategoryFromCache").val());
    var featureCategories = [];
    var selectedFeatureCategory;
    for (var i = 0; i < featureCategoryFromCache.length; i++) {
        featureCategories.push({
            item1: featureCategoryFromCache[i].Id,
            item2: featureCategoryFromCache[i].Name
        });
        if (featureCategoryFromCache[i].IsSelected) {
            selectedFeatureCategory = featureCategoryFromCache[i].Id;
        }
    }
    if (featureCategories.length > 0) {
        _cmbFeatureCategory.igCombo("option", "dataSource", featureCategories);
        _cmbFeatureCategory.igCombo("dataBind");
        _cmbFeatureCategory.igCombo("value", selectedFeatureCategory);
    }
}

function LoadFeatureNamingStandardsFromCache() {
    var featureNamingStandardFromCache = JSON.parse($("#featureNamingStandardFromCache").val());
    var featureNamingStandards = [];
    var selectedNamingStandard = [];
    for (var i = 0; i < featureNamingStandardFromCache.length; i++) {
        featureNamingStandards.push({
            item1: featureNamingStandardFromCache[i].Id,
            item2: featureNamingStandardFromCache[i].Name
        });
        if (featureNamingStandardFromCache[i].IsSelected) {
            selectedNamingStandard.push(featureNamingStandardFromCache[i].Id);
        }
    }

    if (featureNamingStandards.length > 0) {
        _cmbFeatureNamingStandard.igCombo("option", "dataSource", featureNamingStandards);
        _cmbFeatureNamingStandard.igCombo("dataBind");
    }

    if (selectedNamingStandard.length > 0) {
        _cmbFeatureNamingStandard.igCombo("selectAll");
        var allItems = _cmbFeatureNamingStandard.igCombo("listItems");
        for (var j = 0; j < allItems.length; j++) {
            if (selectedNamingStandard.indexOf(allItems[j].dataset.value) < 0) {
                dropdownObj.igCombo("deselectByValue", allItems[j].dataset.value);
            }
        }
    }
}

function LoadSearchTxtFromCache(){
    var searchTextFromCache = JSON.parse($("#searchTxtFromCache").val());
    _txtFeatureSearch.val(searchTextFromCache);
}

function LoadGridDataFromCache() {
    SetQueryStringParametersToCache();
    $("#divBtn").show();
  
    // this is a workaround for filtering is not working
    $(document).on("iggridfilteringdatafiltering", gridId, function (evt, ui) {
        $(gridId).igGrid("dataBind");
        $(document).off("iggridfilteringdatafiltering", gridId);
    });
}
﻿function InitDropDowns() {
    GetAscmCategories();
    GetProductLines();
    GetSkuTypes();
    GetRegions();
}

function GetDropDownOptions(actionUrl, dropdownObj, defaultValueObjId) {
    $.ajax({
        type: "POST",
        url: actionUrl,
        contentType: "application/json; charset=utf-8",
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data != null && data != "") {
                dropdownObj.igCombo("option", "dataSource", data);
                dropdownObj.igCombo("dataBind");
                if (defaultValueObjId != null && defaultValueObjId != "") {
                    dropdownObj.igCombo("value", $(defaultValueObjId).val());
                }
            }
        },
        error: function (xhr) {
            showMessageBox("Unable to get Dropdown Options", "Error", messageBoxImageError, messageBoxButtonOK, {});
        }
    });
}

function GetGridData() {
    $(gridId).igGrid({
        DataSourceType: "json",
        responseDataKey: "Records",
        autoGenerateColumns: true,
        columns: columnsData,
        features: igGridFeatures,
        primaryKey: "FeatureId",
        autoCommit: true,
        cellClick: function (evt, ui) {
            selectedRowIndex = ui.rowIndex;
        },
        cellRightClick: function (evt, ui) {
            selectedRowIndex = ui.rowIndex;
        },
        headerCellRendered: function (evt, ui) {
        },
        rendered: function (evt, ui) {
            // If there is only one row and the row is invalid (having default values - zeros in the cells), make the row empty by removing zeros in the cells
            if (ui.owner.dataSource.dataView().length == 1 && !isGridRowValid(gridId, 0)) {
                makeGridRowEmpty(gridId, 0);
                modalMessage = new GridModalMessage(ui.owner);
                modalMessage.show("No Data Found");
            }
        },
        rowsRendered: function () {
            addToolTipToHeader();
        }
    });

    $(gridId).igGrid("dataSourceObject", JSON.parse($("#gridData").val()));
    $(gridId).igGrid("dataBind");
}

function igGridTooltTipShowing(evt, args) {
    args.tooltip = args.element.innerText;
}

function addToolTipToHeader() {
    for (var itemNumber = 0; itemNumber < columnsData.length; itemNumber++) {
        var columnObject = columnsData[itemNumber];

        if (columnObject["hidden"] == false) {
            var gridColumnId = gridId + "_" + columnObject["key"];
            var toolTipText = columnObject["headerText"];
            $(gridColumnId).attr("title", toolTipText);
        }
    }
}

function isGridRowValid(grid, rowIndex) {
    var columnLength = $(grid).igGrid("option", "columns").length;
    var validRow = false;

    // check whether any of the column value in the given row has non-zero or non-blank space.
    // The row is said to be valid, if one of the column value has non-zero or non-blank space.
    for (var columnIndex = 0; columnIndex < columnLength; columnIndex++) {
        var cell = $($(grid).igGrid('cellAt', columnIndex, rowIndex));
        var cellContent = cell[0].innerHTML;

        if (cell.length > 0
            && (!cellContent == '0'
                || cellContent == ''
                || cellContent == '&nbsp;'
                || cellContent.indexOf("ui-igcheckbox") != -1
                || cellContent.indexOf("ui-igloadingmsg") != -1
                || cellContent == 'false'
                || cellContent == '1/1/0001 12:00')) {
            validRow = true;
            break;
        }
    }
    return validRow;
}

function makeGridRowEmpty(grid, rowIndex) {
    var columnLength = $(grid).igGrid("option", "columns").length;

    for (var columnIndex = 0; columnIndex < columnLength; columnIndex++) {
        var cell = $($(grid).igGrid('cellAt', columnIndex, rowIndex));
        if (cell.length > 0) {
            cell[0].innerHTML = "";
        }
    }
}

function GridModalMessage(grid) {
    var modalBackground = $("<div class='ui-widget-overlay ui-iggrid-blockarea' style='position: absolute; display: none; width: 100%; height: 100%;'><div style='position: relative;top:50%; text-align: center;'></div></div>").appendTo(grid.container());
    function _show(message) {
        modalBackground.show().find("div").text(message);
    }
    function _hide() {
        modalBackground.hide().find("div").text("");
    }
    return {
        show: _show,
        hide: _hide
    }
}

function BatchUpdateSelectedFeatures() {
    var selectedAscmCategoryId = 0;
    var selectedAscmCategoryName = "";
    if (_cmbAscmCategory.igCombo("selectedItems") != null) {
        selectedAscmCategoryId = _cmbAscmCategory.igCombo("selectedItems")[0].data.item1;
        selectedAscmCategoryName = _cmbAscmCategory.igCombo("selectedItems")[0].data.item2;
    }

    var selectedProductLines = _cmbProductLine.igCombo("selectedItems");
    var selectedProductLineNames = [];
    var selectedProductLineIds = [];
    if (selectedProductLines != null) {
        for (var i = 0; i < selectedProductLines.length; i++) {
            selectedProductLineIds.push(selectedProductLines[i].data.item1);
            selectedProductLineNames.push(selectedProductLines[i].data.item2);
        }
    }

    var selectedSkuTypes = _cmbSkuType.igCombo("selectedItems");
    var selectedSkuTypeNames = [];
    var selectedSkuTypeIds = [];
    if (selectedSkuTypes != null) {
        for (var j = 0; j < selectedSkuTypes.length; j++) {
            selectedSkuTypeIds.push(selectedSkuTypes[j].data.item1);
            selectedSkuTypeNames.push(selectedSkuTypes[j].data.item2);
        }
    }

    var selectedRegions = _cmbRegion.igCombo("selectedItems");
    var selectedRegionNames = [];
    var selectedRegionIds = [];
    if (selectedRegions != null) {
        for (var k = 0; k < selectedRegions.length; k++) {
            selectedRegionIds.push(selectedRegions[k].data.item1);
            selectedRegionNames.push(selectedRegions[k].data.item2);
        }
    }

    var selectedRows = $(gridId).igGrid("selectedRows");
    var dataview = $(gridId).data('igGrid').dataSource.dataView();
    for (var rowIndex = 0; rowIndex < selectedRows.length; rowIndex++) {
        if (selectedAscmCategoryId > 0) {
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "AscmCategoryId", selectedAscmCategoryId);
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "AscmCategoryName", selectedAscmCategoryName);
        }

        if (selectedProductLineIds.length > 0) {
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "ProductLineIds", selectedProductLineIds.join(","));
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "ProductLineNames", selectedProductLineNames.join(","));
        }

        if (selectedSkuTypeIds.length > 0) {
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "SkuTypeIds", selectedSkuTypeIds.join(","));
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "SkuTypeNames", selectedSkuTypeNames.join(","));
        }

        if (selectedRegionIds.length > 0) {
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "RegionIds", selectedRegionIds.join(","));
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "RegionNames", selectedRegionNames.join(","));
        } else {
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "RegionIds", "");
            $(gridId).igGridUpdating("setCellValue", dataview[selectedRows[rowIndex].index]["FeatureId"], "RegionNames", "");
        }
    }
}

function GetFeatures() {
    var selectedRows = $(gridId).igGrid("selectedRows");
    var dataview = $(gridId).data('igGrid').dataSource.dataView();
    var allFeatures = [];

    for (var i = 0; i < selectedRows.length; i++) {
        var featureId = dataview[selectedRows[i].index]["FeatureId"];
        var description = dataview[selectedRows[i].index]["Description"];
        var featureFullName = dataview[selectedRows[i].index]["FeatureFullName"];
        var featureCategoryId = dataview[selectedRows[i].index]["FeatureCategoryId"];
        var featureCategoryName = dataview[selectedRows[i].index]["FeatureCategoryName"];
        var deliveryType = dataview[selectedRows[i].index]["DeliveryType"];
        var ascmCategoryId = dataview[selectedRows[i].index]["AscmCategoryId"];
        var ascmCategoryName = dataview[selectedRows[i].index]["AscmCategoryName"];
        var productLineIds = dataview[selectedRows[i].index]["ProductLineIds"];
        var productLineNames = dataview[selectedRows[i].index]["ProductLineNames"];
        var skuTypeIds = dataview[selectedRows[i].index]["SkuTypeIds"];
        var skuTypeNames = dataview[selectedRows[i].index]["SkuTypeNames"];
        var regionIds = dataview[selectedRows[i].index]["RegionIds"];
        var regionNames = dataview[selectedRows[i].index]["RegionNames"];
        var namingStandardId = dataview[selectedRows[i].index]["NamingStandardId"];
        allFeatures.push({
            featureId: featureId,
            description: description,
            featureFullName: featureFullName,
            featureCategoryId: featureCategoryId,
            featureCategoryName: featureCategoryName,
            deliveryType: deliveryType,
            ascmCategoryId: ascmCategoryId,
            ascmCategoryName: ascmCategoryName,
            productLineIds: productLineIds,
            productLineNames: productLineNames,
            skuTypeIds: skuTypeIds,
            skuTypeNames: skuTypeNames,
            regionIds: regionIds,
            regionNames: regionNames,
            namingStandardId: namingStandardId
        });
    }
    return allFeatures;
}

function UpdateCurrentCachedFeatures() {
    var postBody = { AmoFeatures: GetFeatures() };

    $.ajax({
        url: _cacheDataUrl,
        data: {
            wizardId: _wizardID,
            cacheKey: _cacheKey,
            PostBody: JSON.stringify(postBody)
        },
        type: "POST",
        dataType: "json",
        success: function (result) {
            if (result.item1) {
                GotoPreviousPage();
            } else {
                $("#errMsgDiv").show();
                $("#errMsgDiv").append("Unable to save the Changes: " + result.item2);
            }
        },
        error: function (xhr) {
            showMessageBox("Unable to cache data", "Error", messageBoxImageError, messageBoxButtonOK, {});
        }
    });
}

function AddFeaturesToASCM(url) {
    var currentFeaturesInputModels = [];
    var selectedFeatures;
    var selectdRows = $(gridId).igGrid("selectedRows");
    var dataview = $(gridId).data('igGrid').dataSource.dataView();

    for (var i = 0; i < selectdRows.length; i++) {
        if (dataview[selectdRows[i].index]["ProductLineIds"] == null || dataview[selectdRows[i].index]["ProductLineIds"] == "" || dataview[selectdRows[i].index]["SkuTypeIds"] == null || dataview[selectdRows[i].index]["SkuTypeIds"] == "") {
            showMessageBox("Product Line/Sku Type cannot be empty.", "Alert", messageBoxImageError, messageBoxButtonOK, {});
            return false;
        }

        selectedFeatures = {
            FeatureId: dataview[selectdRows[i].index]["FeatureId"],
            AscmCategoryId: dataview[selectdRows[i].index]["AscmCategoryId"] > 0 ? dataview[selectdRows[i].index]["AscmCategoryId"] : null,
            ProductLineIds: dataview[selectdRows[i].index]["ProductLineIds"],
            SkuTypeIds: dataview[selectdRows[i].index]["SkuTypeIds"],
            RegionIds: dataview[selectdRows[i].index]["RegionIds"]
        };

        currentFeaturesInputModels.push(selectedFeatures);
    }

    $.ajax({
        type: "POST",
        traditional: true,
        async: true,
        cache: false,
        url: url.replace("Controller", ""),
        context: document.body,
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(currentFeaturesInputModels),
        success: function (result) {
            if (result.item1 && result.item2 == "") {
                showMessageBox(
                    "",
                    "The HP Part Number(s) been created.",
                    messageBoxImageInformation,
                    messageBoxButtonOK,
                    { onClickButtonOK: GotoAscmAdminPage, onClickButtonClose: GotoAscmAdminPage });

            } else {
                $("#errMsgDiv").show();
                $("#errMsgDiv").append("Unable to save the Changes: " + result.item2);
            }
        },
        error: function () {
            showMessageBox("Unable to create HP Part Number(s).", "Error", messageBoxImageError, messageBoxButtonOK, {});

        }
    });
}
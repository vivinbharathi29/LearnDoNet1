﻿using System.Collections.Generic;
using System.Linq;
using HP.Pulsar.Ascm.Models;
using HP.Pulsar.CommonContracts.Infrastructure.Application;
using HP.Pulsar.CommonContracts.Infrastructure.Grid;
using HP.Pulsar.Infrastructure.Application.Wizard;
using Newtonsoft.Json;

namespace HP.Pulsar.Ascm.Wizard
{
    public class AddAmoFeaturesToAscmWizard : IWizard
    {
        private readonly string _key;
        private readonly ISimpleDataCache _cache;

        public AddAmoFeaturesToAscmWizard(string cacheKey, ISimpleDataCache cache)
        {
            _key = cacheKey;
            _cache = cache;
        }

        public IWizardContentModel GetContentModel(IReadOnlyDictionary<string, string> inputData)
        {
            IGridContentModel amoFeaturesToAscmGridContentModel = new AddAmoFeaturesToAscmGridContentModel(canShowGridCheckBox: true);
            AddAmoFeaturesToAscmWizardContentModel wizardContentModel = new AddAmoFeaturesToAscmWizardContentModel(_key, amoFeaturesToAscmGridContentModel);

            if (_cache.TryGet(_key, out object cacheData) && cacheData is AddHpPartNumberDataCacheModel addNewHpPartNumberCacheData)
            {
                IEnumerable<AddNewHpPartNumberGridDataCacheModel> gridDataCacheModel = addNewHpPartNumberCacheData.AmoFeatures.Where(item => item.IsSelected);
                wizardContentModel.GriDataFromCached = JsonConvert.SerializeObject(gridDataCacheModel);
            }

            return wizardContentModel;
        }

        public int Id => WizardIdConstants.AddAmoFeaturesToAscm;
    }
}
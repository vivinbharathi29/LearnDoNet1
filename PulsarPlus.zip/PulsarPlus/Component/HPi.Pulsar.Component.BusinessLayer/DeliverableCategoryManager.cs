using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Repositories;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;

namespace HPi.Pulsar.Component.BusinessLayer
{
    public class DeliverableCategoryManager : BaseManager<IDeliverableCategoryRepository>, IDeliverableCategoryService
    {
        public DeliverableCategoryManager(IApplicationServices applicationService, IDeliverableCategoryRepository deliverableCategoryRepository) : base(applicationService, deliverableCategoryRepository)
        {
        }

        public async Task<DeliverableCategoryModel> GetDeliverableCategoryNameAsync(int Id)
        {
            return await this.Repository.GetDeliverableCategoryNameAsync(Id).ConfigureAwait(false);
        }

        public async Task<bool> TryAddSupplierCodeAsync(int vendorID, int categoryID, string supplierCode)
        {
            return await this.Repository.TryAddSupplierCodeAsync(vendorID, categoryID, supplierCode).ConfigureAwait(false);
        }
    }
}

using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Repositories;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;

namespace HPi.Pulsar.Component.BusinessLayer
{

    public class DeliverableVersionManager : BaseManager<IDeliverableVersionRepository>, IDeliverableVersionService
    {
        public DeliverableVersionManager(IApplicationServices applicationService, IDeliverableVersionRepository deliverableVersionRepository) : base(applicationService, deliverableVersionRepository)
        {
        }

        public async Task<DeliverableVersionModel> GetVersionPartNumberAsync(int Id)
        {
            return await this.Repository.GetVersionPartNumberAsync(Id).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateVersionPartNumberAsync(int id, string partNumber)
        {
            return await this.Repository.TryUpdateVersionPartNumberAsync(id, partNumber).ConfigureAwait(false);
        }

        public async Task<DeliverableVersionModel[]> GetVersionPropertiesForWebAsync(int Id)
        {
            return await this.Repository.GetVersionPropertiesForWebAsync(Id).ConfigureAwait(false);
        }

        public async Task<OtsDelVerModel[]> GetOTSByDelVersionAsync(int delVerID)
        {
            return await this.Repository.GetOTSByDelVersionAsync(delVerID).ConfigureAwait(false);
        }
        public async Task<ProductVersionModel[]> GetProductVersionsByNameAsync(string product)
        {
            return await this.Repository.GetProductVersionsByNameAsync(product).ConfigureAwait(false);
        }
    }
}

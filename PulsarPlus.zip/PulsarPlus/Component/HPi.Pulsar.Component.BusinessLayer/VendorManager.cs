using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Repositories;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;

namespace HPi.Pulsar.Component.BusinessLayer
{
    public class VendorManager : BaseManager<IVendorRepository>, IVendorService
    {
        public VendorManager(IApplicationServices applicationService, IVendorRepository vendorRepository) : base(applicationService, vendorRepository)
        {
        }

        public async Task<VendorModel> GetVendorNameAsync(int id)
        {
            return await this.Repository.GetVendorNameAsync(id).ConfigureAwait(false);
        }
    }
}

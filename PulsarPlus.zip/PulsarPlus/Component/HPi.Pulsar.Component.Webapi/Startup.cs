﻿using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.BusinessLayer;
using HPi.Pulsar.Infrastructure.Repository;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Authorization;
using HPi.Pulsar.Infrastructure.Contracts.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using HPi.Pulsar.Infrastructure.Contracts.Logging;
using HPi.Pulsar.Infrastructure.Contracts.Notification;
using HPi.Pulsar.Infrastructure.Contracts.Roles;
using HPi.Pulsar.Infrastructure.Contracts.SessionState;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using HPi.Pulsar.Component.BusinessLayer;
using HPi.Pulsar.Component.Contracts.Repositories;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Component.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace HPi.Pulsar.Component.Webapi
{
    public class Startup
    {
        #region Public Properties
        public IConfigurationRoot Configuration { get; }
        #endregion

        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder().SetBasePath(env.ContentRootPath)
                                                    .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                                                    .AddEnvironmentVariables();
            this.Configuration = builder.Build();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            this.ConfigureDependencies(services);

            services.AddApplicationInsightsTelemetry(Configuration);

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder => builder.AllowAnyOrigin().AllowAnyMethod()
                                                                                   .AllowAnyHeader()
                                                                                   .AllowCredentials());
            });
         
            services.AddMvc(options =>
            {
                options.Filters.Add(typeof(WebApiExceptionFilter));        
            });
            services.AddSingleton<IConfiguration>(this.Configuration);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(this.Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "api/{controller}/{action}/{id?}");
            });
        }

        private void ConfigureDependencies(IServiceCollection services)
        {
            services.AddTransient<IApplicationProperties, ApplicationProperties>();
            services.AddTransient<IApplicationServices, ApplicationServices>();
            services.AddTransient<IAuthorizationRepository, AuthorizationRepository>();
            services.AddTransient<IAuthorizationService, AuthorizationManager>();
            services.AddTransient<ICacheRepository, CacheRepository>();
            services.AddTransient<ICacheService, CacheManager>();
            services.AddTransient<IDeliverableCategoryRepository, DeliverableCategoryRepository>();
            services.AddTransient<IDeliverableCategoryService, DeliverableCategoryManager>();
            services.AddTransient<IDeliverableVersionRepository, DeliverableVersionRepository>();
            services.AddTransient<IDeliverableVersionService, DeliverableVersionManager>();
            services.AddTransient<IExceptionHandlingService, ExceptionHandlingManager>();
            services.AddTransient<ILoggingRepository, LoggingRepository>();
            services.AddTransient<ILoggingService, LoggingManager>();
            services.AddTransient<INotificationRepository, NotificationRepository>();
            services.AddTransient<INotificationService, NotificationManager>();
            services.AddTransient<IRoleStore<ApplicationRole>, RoleManager>();
            services.AddTransient<IRoleStore<ApplicationRole>, RoleRepository>();
            services.AddTransient<ISessionStateRepository, SessionStateRepository>();
            services.AddTransient<ISessionStateService, SessionStateManager>();
            services.AddTransient<IUserInfoRepository, UserInfoRepository>();
            services.AddTransient<IUserInfoService, UserInfoManager>();
            services.AddTransient<IUserRoleStore<ApplicationUser>, UserRoleManager>();
            services.AddTransient<IUserRoleStore<ApplicationUser>, UserRoleRepository>();
            services.AddTransient<IVendorRepository, VendorRepository>();
            services.AddTransient<IVendorService, VendorManager>();
        }
    }
}
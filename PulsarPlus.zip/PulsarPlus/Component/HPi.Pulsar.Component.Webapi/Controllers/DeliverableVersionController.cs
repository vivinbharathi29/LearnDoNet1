using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using Microsoft.AspNetCore.Mvc;

namespace HPi.Pulsar.Component.WebApi.Controllers
{
    public class DeliverableVersionController : BaseApiController<IDeliverableVersionService>
    {
        public DeliverableVersionController(IApplicationServices applicationServices, IDeliverableVersionService manager) : base(applicationServices, manager)
        {
        }

        [HttpGet]
        [Route("api/DeliverableVersion/GetVersionPartNumber")]
        [ProducesResponseType(typeof(DeliverableVersionModel), 200)]
        [ProducesResponseType(typeof(DeliverableVersionModel), 404)]
        public async Task<IActionResult> GetVersionPartNumber(int id)
        {
            DeliverableVersionModel apiResult = await this.Manager.GetVersionPartNumberAsync(id).ConfigureAwait(false);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> UpdateVersionPartNumber(int id, string partNumber)
        {
            bool isUpdated = false;
            isUpdated = await this.Manager.TryUpdateVersionPartNumberAsync(id, partNumber).ConfigureAwait(false);
            return this.Ok(isUpdated);
        }

        [HttpGet]
        [Route("api/DeliverableVersion/GetVersionPropertiesForWeb")]
        [ProducesResponseType(typeof(DeliverableVersionModel[]), 200)]
        [ProducesResponseType(typeof(DeliverableVersionModel[]), 404)]
        public async Task<IActionResult> GetVersionPropertiesForWeb(int id)
        {
            DeliverableVersionModel[] apiResult = await this.Manager.GetVersionPropertiesForWebAsync(id).ConfigureAwait(false);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }

            return this.NotFound();
        }

        [HttpGet]
        [Route("api/DeliverableVersion/GetOTSByDelVersion/")]
        [ProducesResponseType(typeof(OtsDelVerModel[]), 200)]
        [ProducesResponseType(typeof(OtsDelVerModel[]), 404)]
        public async Task<IActionResult> GetOTSByDelVersion(int delVerId)
        {
            OtsDelVerModel[] apiResult = await this.Manager.GetOTSByDelVersionAsync(delVerId).ConfigureAwait(false);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }

            return this.NotFound();
        }

        [HttpGet]
        [Route("api/DeliverableVersion/GetProductVersionsByName/")]
        [ProducesResponseType(typeof(ProductVersionModel[]), 200)]
        [ProducesResponseType(typeof(ProductVersionModel[]), 404)]
        public async Task<IActionResult> GetProductVersionsByName(string product)
        {
            ProductVersionModel[] apiResult = await this.Manager.GetProductVersionsByNameAsync(product).ConfigureAwait(false);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }

            return this.NotFound();
        }
    }
}

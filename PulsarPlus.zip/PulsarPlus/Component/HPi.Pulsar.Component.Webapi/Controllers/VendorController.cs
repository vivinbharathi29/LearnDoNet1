using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using Microsoft.AspNetCore.Mvc;

namespace HPi.Pulsar.Component.WebApi.Controllers
{

    public class VendorController : BaseApiController<IVendorService>
    {
        public VendorController(IApplicationServices applicationServices, IVendorService manager) : base(applicationServices, manager)
        {
        }

        [HttpGet]
        [Route("api/Vendor/GetVendorName")]
        [ProducesResponseType(typeof(VendorModel), 200)]
        [ProducesResponseType(typeof(VendorModel), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetVendorName(int id)
        {
            VendorModel apiResult = await this.Manager.GetVendorNameAsync(id).ConfigureAwait(false);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }

            return this.NotFound();
        }
    }
}

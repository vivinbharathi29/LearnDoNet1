using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using Microsoft.AspNetCore.Mvc;

namespace HPi.Pulsar.Component.WebApi.Controllers
{
    public class DeliverableCategoryController : BaseApiController<IDeliverableCategoryService>
    {
        public DeliverableCategoryController(IApplicationServices applicationServices, IDeliverableCategoryService manager) : base(applicationServices, manager)
        {
        }

        [HttpGet]
        [Route("api/DeliverableCategory/GetDeliverableCategoryName")]
        [ProducesResponseType(typeof(DeliverableCategoryModel), 200)]
        [ProducesResponseType(typeof(DeliverableCategoryModel), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetDeliverableCategoryName(int id)
        {
            DeliverableCategoryModel apiResult = await this.Manager.GetDeliverableCategoryNameAsync(id).ConfigureAwait(false);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }

            return this.NotFound();
        }

        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> AddSupplierCode(int vendorId, int categoryId, string supplierCode)
        {
            bool isUpdated = false;
            isUpdated = await this.Manager.TryAddSupplierCodeAsync(vendorId, categoryId, supplierCode).ConfigureAwait(false);
            return this.Ok(isUpdated);
        }

    }
}

using System;

namespace HPi.Pulsar.Component.Contracts
{
    public class ProductVersionModel
    {
        public int Id { get; set; }

        public string Version { get; set; }

        public int? ProductFamilyId { get; set; }

        public string Description { get; set; }

        public DateTime? Published { get; set; }

        public string DotsName { get; set; }

        public string Cycle { get; set; }

        public int? PlatformId { get; set; }

        public string Distribution { get; set; }

        public DateTime? PddReleased { get; set; }

        public byte? Active { get; set; }

        public byte? Sustaining { get; set; }

        public DateTime? PrdReleased { get; set; }

        public int? ProductStatusId { get; set; }

        public int? PMId { get; set; }

        public string StreetName { get; set; }

        public string Objectives { get; set; }

        public byte? OnlineReports { get; set; }

        public int? SepmId { get; set; }

        public byte? Division { get; set; }

        public int? DevCenter { get; set; }

        public int? Approver { get; set; }

        public byte? EmailActive { get; set; }

        public string BaseUnit { get; set; }

        public string CurrentROM { get; set; }

        public string OSSupport { get; set; }

        public string ImagePO { get; set; }

        public string ImageChanges { get; set; }

        public string SystemBoardId { get; set; }

        public string MachinePnpId { get; set; }

        public string CommonImages { get; set; }

        public string CertificationStatus { get; set; }

        public string SwqaStatus { get; set; }

        public string PlatformStatus { get; set; }

        public byte? TypeId { get; set; }

        public string Abbreviation { get; set; }

        public string Brands { get; set; }

        public DateTime Created { get; set; }

        public string PddPath { get; set; }

        public string ScmPath { get; set; }

        public string StlStatusPath { get; set; }

        public string ProgramMatrixPath { get; set; }

        public string ApproverList { get; set; }

        public int? SMId { get; set; }

        public int? PdeId { get; set; }

        public int? PreinstallTeam { get; set; }

        public int? ReleaseTeam { get; set; }

        public int? ComMarketingId { get; set; }

        public int? SmbMarketingId { get; set; }

        public int? ConsMarketingId { get; set; }

        public int? PlatformDevelopmentId { get; set; }

        public int? SupplyChainId { get; set; }

        public int? ServiceId { get; set; }

        public int? FinanceId { get; set; }

        public DateTime? RolloutP1 { get; set; }

        public DateTime? RolloutP2 { get; set; }

        public DateTime? RolloutP3 { get; set; }

        public byte? DcrAutoOpen { get; set; }

        public int? PartnerId { get; set; }

        public bool? OnCommodityMatrix { get; set; }

        public string ProductFilePath { get; set; }

        public int? ReferenceId { get; set; }

        public int? DocPM { get; set; }

        public int? Sepe { get; set; }

        public int? Pinpm { get; set; }

        public int? SETestLead { get; set; }

        public string PreInstallCutoff { get; set; }

        public int? SustainingMgrId { get; set; }

        public int? TdccmId { get; set; }

        public int? SustainingSepmId { get; set; }

        public string RegulatoryModel { get; set; }

        public int? PCId { get; set; }

        public int? MarketingOpsId { get; set; }

        public bool? CommodityLock { get; set; }

        public int? AccessoryPMId { get; set; }

        public int? SCFactoryEngineerID { get; set; }

        public string AccessoryPath { get; set; }

        public string ActionNotifyList { get; set; }

        public bool ShowOnWhql { get; set; }

        public int? BiosLeadId { get; set; }

        public int? CommHWPMId { get; set; }

        public int? ProcessorPMId { get; set; }

        public int? VideoMemoryPMId { get; set; }

        public int? DkcId { get; set; }

        public DateTime? ServiceLifeDate { get; set; }

        public string SystemboardComments { get; set; }

        public string MachinePnpComments { get; set; }

        public bool? AllowSmr { get; set; }

        public bool? AllowDeliverableReleases { get; set; }

        public bool? AllowDcr { get; set; }

        public string ServiceFamilyPn { get; set; }

        public string DCRApproverList { get; set; }

        public int? OdmTestLeadId { get; set; }

        public int? WwanTestLeadId { get; set; }

        public int? BuPMID { get; set; }

        public int? BuSEPMID { get; set; }

        public int? BuSMID { get; set; }

        public int? BuTdccmId { get; set; }

        public int? BuComMarketingId { get; set; }

        public int? BuSmbMarketingId { get; set; }

        public int? BuConsMarketingId { get; set; }

        public int? BuPlatformDevelopmentId { get; set; }

        public int? BuSupplyChainId { get; set; }

        public int? BuServiceId { get; set; }

        public int? BuFinanceId { get; set; }

        public int? BuPdeId { get; set; }

        public int? BuAccessoryPMId { get; set; }

        public int? BuSCFactoryEngineerId { get; set; }

        public int? BuPCId { get; set; }

        public int? BuMarketingOpsId { get; set; }

        public int? BuSustainingSepmId { get; set; }

        public int? BuSETestLeadId { get; set; }

        public int? BuOdmTestLeadId { get; set; }

        public int? BuWwanTestLeadId { get; set; }

        public int? BuPinPM { get; set; }

        public int? BuDocPM { get; set; }

        public int? BuSepe { get; set; }

        public int? BuBiosLeadId { get; set; }

        public int? BuCommHWPMId { get; set; }

        public int? BuProcessorPMId { get; set; }

        public int? BuVideoMemoryPMId { get; set; }

        public int? BuDkcId { get; set; }

        public string CurrentWebROM { get; set; }

        public string ToolAccessList { get; set; }

        public int? GraphicsControllerPMId { get; set; }

        public int? BuGraphicsControllerPMId { get; set; }

        public bool? WwanProduct { get; set; }

        public DateTime? CallDataLastUpdated { get; set; }

        public int? SETestId { get; set; }

        public int? BuSETestId { get; set; }

        public int? Spdm { get; set; }

        public int? Gplm { get; set; }

        public int? SvcBomAnalyst { get; set; }

        public string RctoSites { get; set; }

        public string RtmNotifications { get; set; }

        public bool? AllowImageBuilds { get; set; }

        public string ConveyorBuildDistribution { get; set; }

        public string ConveyorReleaseDistribution { get; set; }

        public byte AgencyVersion { get; set; }

        public int? DcrDefaultOwner { get; set; }

        public bool Fusion { get; set; }

        public bool? AVActionScorecardInactiveInclude { get; set; }

        public int? MinRoHSLevel { get; set; }

        public int? AffectedProduct { get; set; }

        public bool? BsamFlag { get; set; }

        public bool? AddDcrNotificationList { get; set; }

        public string CreatedBy { get; set; }

        public DateTime Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public int? ProductLineId { get; set; }

        public bool? FusionRequirements { get; set; }

        public int? BusinessSegmentId { get; set; }

        public string ProductName { get; set; }

        public int? SysEngrProgramCoordinatorId { get; set; }

        public int? BuSysEngrProgramCoordinatorId { get; set; }

        public bool AutoSimpleAV { get; set; }

        public int ProductVersionId { get; set; }

        public int? CMId { get; set; }

        public int? SepeId { get; set; }

        public int? PinPMId { get; set; }

        public int? SETestLeadId { get; set; }

        public DateTime? Disabled { get; set; }

        public string DisabledBy { get; set; }

        public int? ProgramBusinessManagerId { get; set; }

        public int? BuProgramBusinessManagerId { get; set; }

        public bool? IsDesktop { get; set; }

        public int? QualityId { get; set; }

        public int? BuQualityId { get; set; }

        public int? SharedAVMarketingId { get; set; }

        public int? SharedAVPCId { get; set; }

        public int? OdmSepmId { get; set; }

        public int? ProcurementPMId { get; set; }

        public int? PlanningPMId { get; set; }

        public int? OdmPimPMId { get; set; }

        public int? ScmOwnerId { get; set; }

        public int? EngineeringDataManagementId { get; set; }

        public bool? BirsProjectExplorer { get; set; }

        public int? HWPCId { get; set; }

        public int? OdmHWPMId { get; set; }
    }
}
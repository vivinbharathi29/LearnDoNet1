namespace HPi.Pulsar.Component.Contracts
{
    public class SIObservationReportModel
    {
        public int ObservationId { get; set; }

		public string ShortDescription { get; set; }

        public string GatingMilestone { get; set; }

		public string ProductFamily { get; set; }

		public string PrimaryProduct { get; set; }

		public string Priority { get; set; }

		public string ComponentType { get; set; }
    }
}
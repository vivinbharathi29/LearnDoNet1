using System;

namespace HPi.Pulsar.Component.Contracts
{
    public class DeliverableCategoryModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string OtsCategory { get; set; }

        public int DeliverableTypeId { get; set; }

        public byte? RequireCountries { get; set; }

        public string Bucket { get; set; }

        public string NameFormat { get; set; }

        public bool? Commodity { get; set; }

        public int? TeamId { get; set; }

        public bool? Accessory { get; set; }

        public bool? RequiresTts { get; set; }

        public bool? RequiresOdmTestFinalApproval { get; set; }

        public bool? RequiresWwanTestFinalApproval { get; set; }

        public bool? RequiresMitTestFinalApproval { get; set; }

        public bool? RequiresDeveloperFinalApproval { get; set; }

        public bool RequiresMissingSubAssemblyNumResolution { get; set; }

        public bool? RequiresFormattedName { get; set; }

        public bool? InitialOfferingInclude { get; set; }

        public bool? CommodityGuidanceInclude { get; set; }

        public string AVPrefix { get; set; }

        public bool? Active { get; set; }

        public byte? AutoAVCreate { get; set; }

        public int? DeleteMeIrsCategoryId { get; set; }

        public int? IrsCategoryId { get; set; }

        public bool? RoHSComplianceCheck { get; set; }

        public DateTime Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public int? DeliveryTypeId { get; set; }

        public bool? FccRequired { get; set; }

        public string FccPath { get; set; }

        public int? PrismSWType { get; set; }

        public bool? RequiredPrismSWType { get; set; }

        public int? BuildLevel { get; set; }

        public string IrsCategoryDescription { get; set; }

        public string Abbreviation { get; set; }
    }
}
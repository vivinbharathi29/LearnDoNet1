namespace HPi.Pulsar.Component.Contracts
{
    public class OtsDelVerModel
    {
		public int Id { get; set; }

        public string OtsNumber { get; set; }

        public int? DeliverableVersionId { get; set; }

        public string StepsToReproduce { get; set; }

        public SIObservationReportModel SIObservationReport { get; set; }

        public string ShortDescription { get; set; }
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Component.Contracts.Services
{
    public interface IVendorService
    {
        Task<VendorModel> GetVendorNameAsync(int id);
    }
}
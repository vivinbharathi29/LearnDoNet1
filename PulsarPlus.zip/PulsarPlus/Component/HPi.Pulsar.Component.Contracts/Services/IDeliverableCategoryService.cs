using System.Threading.Tasks;

namespace HPi.Pulsar.Component.Contracts.Services
{
    public interface IDeliverableCategoryService
    {
        Task<DeliverableCategoryModel> GetDeliverableCategoryNameAsync(int id);

        Task<bool> TryAddSupplierCodeAsync(int vendorId, int categoryId, string supplierCode);
    }
}
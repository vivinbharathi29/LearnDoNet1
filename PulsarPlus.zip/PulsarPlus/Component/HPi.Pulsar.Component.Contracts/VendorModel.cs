namespace HPi.Pulsar.Component.Contracts
{
    using System;

    public class VendorModel
    {
        public int Id { get; set; }

		public string Name { get; set; }

        public string OtsGroupName { get; set; }

        public int? OtsGroupId { get; set; }

        public string ActiveYnp { get; set; }

		public string Type { get; set; }

		public bool? CellSupplier { get; set; }

        public int? IrsId { get; set; }

		public string Website { get; set; }

        public string ApprovedIrsNameException { get; set; }

		public DateTime Created { get; set; }

		public string CreatedBy { get; set; }

		public DateTime Updated { get; set; }

		public string UpdatedBy { get; set; }

		public DateTime? Deleted { get; set; }

		public string DeletedBy { get; set; }

		public DateTime? Disabled { get; set; }

		public string DisabledBy { get; set; }
    }
}
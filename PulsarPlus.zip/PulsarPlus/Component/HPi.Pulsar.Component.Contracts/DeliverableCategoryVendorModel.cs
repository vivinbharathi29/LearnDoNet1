namespace HPi.Pulsar.Component.Contracts
{
    public class DeliverableCategoryVendorModel
    {
        public int Id { get; set; }

        public string SupplierCode { get; set; }

        public int DeliverableCategoryId { get; set; }

        public int VendorId { get; set; }
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Component.Contracts.Repositories
{
    public interface IDeliverableVersionRepository
    {
        Task<DeliverableVersionModel> GetVersionPartNumberAsync(int id);

        Task<bool> TryUpdateVersionPartNumberAsync(int id, string partNumber);

        Task<DeliverableVersionModel[]> GetVersionPropertiesForWebAsync(int id);

        Task<OtsDelVerModel[]> GetOTSByDelVersionAsync(int delVersionId);

        Task<ProductVersionModel[]> GetProductVersionsByNameAsync(string product);
    }
}
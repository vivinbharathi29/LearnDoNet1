using System.Threading.Tasks;

namespace HPi.Pulsar.Component.Contracts.Repositories
{
    public interface IVendorRepository
    {
        Task<VendorModel> GetVendorNameAsync(int id);
    }
}
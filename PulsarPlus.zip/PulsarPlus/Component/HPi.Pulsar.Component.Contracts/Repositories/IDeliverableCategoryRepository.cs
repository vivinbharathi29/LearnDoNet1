using System.Threading.Tasks;

namespace HPi.Pulsar.Component.Contracts.Repositories
{
    public interface IDeliverableCategoryRepository
    {
        Task<DeliverableCategoryModel> GetDeliverableCategoryNameAsync(int id);

        Task<bool> TryAddSupplierCodeAsync(int vendorId, int categoryId, string supplierCode);
    }
}
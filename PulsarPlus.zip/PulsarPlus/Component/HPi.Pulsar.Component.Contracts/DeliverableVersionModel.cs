using System;

namespace HPi.Pulsar.Component.Contracts
{
    public class DeliverableVersionModel
    {
        public int Id { get; set; }

        public int? DeliverableRootId { get; set; }

        public string DeliverableName { get; set; }

        public string Version { get; set; }

        public string Revision { get; set; }

        public string Pass { get; set; }

        public int? Status { get; set; }

        public string Location { get; set; }

        public string VendorVersion { get; set; }

        public bool Latest { get; set; }

        public string PartNumber { get; set; }

        public string Comments { get; set; }

        public string OtherDependencies { get; set; }

        public int? DeveloperId { get; set; }

        public string ReleaseDoc { get; set; }

        public string DeliverableSpec { get; set; }

        public string ImagePath { get; set; }

        public string TdcImagePath { get; set; }

        public DateTime? ReleaseDate { get; set; }

        public string Changes { get; set; }

        public short? SpecType { get; set; }

        public int? VendorId { get; set; }

        public DateTime? ActualReleaseDate { get; set; }

        public DateTime? IntroDate { get; set; }

        public DateTime? SampleDate { get; set; }

        public DateTime? EndOfLifeDate { get; set; }

        public string DisplayPartNumber { get; set; }

        public string Languages { get; set; }

        public byte? InstallableUpdate { get; set; }

        public string SoftpaqNumber { get; set; }

        public string Supersedes { get; set; }

        public string SoftpaqFixes { get; set; }

        public string SoftpaqFileInfo { get; set; }

        public string SoftpaqType { get; set; }

        public string SoftpaqInstructions { get; set; }

        public string SWDependencies { get; set; }

        public string OSType { get; set; }

        public string PackageType { get; set; }

        public string EndUserInstructions { get; set; }

        public string SilentInstructions { get; set; }

        public string Install { get; set; }

        public string SilentInstall { get; set; }

        public string ArcdInstall { get; set; }

        public byte? Reboot { get; set; }

        public byte? Preinstall { get; set; }

        public byte? Rompaq { get; set; }

        public byte? CDImage { get; set; }

        public byte? Cab { get; set; }

        public byte? Binary { get; set; }

        public byte? FloppyDisk { get; set; }

        public byte? PreinstallROM { get; set; }

        public byte? Admin { get; set; }

        public string Filename { get; set; }

        public bool? SsmCompliant { get; set; }

        public bool? Desktops { get; set; }

        public bool? Notebooks { get; set; }

        public bool? Workstations { get; set; }

        public bool? ThinClients { get; set; }

        public bool? Monitors { get; set; }

        public bool? Projectors { get; set; }

        public bool? Handhelds { get; set; }

        public bool? Printers { get; set; }

        public bool? PersonalAudio { get; set; }

        public bool? Scriptpaq { get; set; }

        public byte? ReleaseType { get; set; }

        public string PnpDevices { get; set; }

        public string CDPartNumber { get; set; }

        public bool? PmrComplete { get; set; }

        public byte? ReleasePriority { get; set; }

        public string ReleasePriorityJustification { get; set; }

        public byte? CertificationStatus { get; set; }

        public string CertificationDate { get; set; }

        public string CertificationId { get; set; }

        public string CertificationComments { get; set; }

        public string CatStatus { get; set; }

        public byte? MultiLanguage { get; set; }

        public DateTime? EffectiveDate { get; set; }

        public bool? Hfcn { get; set; }

        public string HfcnLocation { get; set; }

        public string HfcnNotify { get; set; }

        public DateTime? Created { get; set; }

        public bool? PreReleased { get; set; }

        public bool? IconDesktop { get; set; }

        public bool? IconMenu { get; set; }

        public bool? IconTray { get; set; }

        public bool? IconPanel { get; set; }

        public bool? PackageForWeb { get; set; }

        public string PropertyTabs { get; set; }

        public byte? Imported { get; set; }

        public byte? IsoImage { get; set; }

        public string Replicater { get; set; }

        public short? CvaVersion { get; set; }

        public byte? Archived { get; set; }

        public int? LevelId { get; set; }

        public string ModelNumber { get; set; }

        public byte? PostRtmStatus { get; set; }

        public string OtsPartNumber { get; set; }

        public byte? SamplesConfidence { get; set; }

        public byte? IntroConfidence { get; set; }

        public DateTime? PostRtmTargetDate { get; set; }

        public byte? DeveloperNotification { get; set; }

        public short? LeadFree { get; set; }

        public byte? AR { get; set; }

        public string CodeName { get; set; }

        public string PostRtmComments { get; set; }

        public string Path2Location { get; set; }

        public string Path2Description { get; set; }

        public bool? Active { get; set; }

        public string Path3Location { get; set; }

        public string Path3Description { get; set; }

        public byte? ConsumerReleaseStatus { get; set; }

        public byte? CommercialReleaseStatus { get; set; }

        public string CDKitNumber { get; set; }

        public byte? ArchivedPath2 { get; set; }

        public byte? ArchivedPath3 { get; set; }

        public byte? ArchivedTdc { get; set; }

        public string AssemblyCode { get; set; }

        public int? SWSetupCategoryId { get; set; }

        public bool? MuiAware { get; set; }

        public bool? IconInfoCenter { get; set; }

        public int? PreinstallInternalRev { get; set; }

        public string EDId { get; set; }

        public string Tts { get; set; }

        public bool? WwanFailureConfirmed { get; set; }

        public string WwanTestReport { get; set; }

        public string WwanTestSpecRev { get; set; }

        public DateTime? ServiceEoaDate { get; set; }

        public bool? ServiceActive { get; set; }

        public byte? OemReadyStatus { get; set; }

        public DateTime? OemReadyDate { get; set; }

        public string OemReadyId { get; set; }

        public string OemReadyComments { get; set; }

        public string LearnMore { get; set; }

        public string AdditionalReleaseNotifications { get; set; }

        public string SoftpaqEnhancements { get; set; }

        public string MD5 { get; set; }

        public int? CloneId { get; set; }

        public int? CloneType { get; set; }

        public string ReturnCodes { get; set; }

        public int? PreinstallInternalRevTdc { get; set; }

        public int? RoHSId { get; set; }

        public int? GreenSpecId { get; set; }

        public DateTime? PmrDate { get; set; }

        public int? PreinstallPrepStatus { get; set; }

        public int? PreinstallPnRev { get; set; }

        public int? PreinstallPnRevTdc { get; set; }

        public string FccID { get; set; }

        public string Anatel { get; set; }

        public string Icasa { get; set; }

        public bool? SecondaryRFKill { get; set; }

        public byte? Patch { get; set; }

        public int? IrsId { get; set; }

        public string IrsPath { get; set; }

        public int? IrsRootId { get; set; }

        public int? IrsVersionId { get; set; }

        public int? IrsRevisionId { get; set; }

        public byte? DriverPack { get; set; }

        public byte? AppStore { get; set; }

        public string SoftpaqNumbers { get; set; }

        public int? IrsFilesCopied { get; set; }

        public bool? Odie { get; set; }

        public string IrsPartNumber { get; set; }

        public string InitialPath { get; set; }

        public int? SubmitterId { get; set; }

        public int? MftJobId { get; set; }

        public bool? MftNotifySubmitter { get; set; }

        public bool? DpbCompliant { get; set; }

        public string DevicesInfPath { get; set; }

        public string EntryMePcr0 { get; set; }

        public string FullMePcr0 { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public DateTime? Deactivated { get; set; }

        public DateTime? ServiceDeactivated { get; set; }

        public int? SupplierId { get; set; }

        public string KoreanCertificationId { get; set; }

        public string BaseFilePath { get; set; }

        public string CvaSubPath { get; set; }

        public bool? KoreanCertificationRequired { get; set; }

        public int? TransferServerId { get; set; }

        public string SubmissionPath { get; set; }

        public DateTime? LastSentToPrism { get; set; }

        public int? TestLeadId { get; set; }

        public DateTime? RtmDate { get; set; }

        public int? PrismSWType { get; set; }

        public string DpbComment { get; set; }

        public int? DevManagerId { get; set; }

        public int? CDVerificationId { get; set; }

        public int? PrismSWStatusId { get; set; }

        public int? ML { get; set; }

        public int? PrismRevision { get; set; }

        public VendorModel Vendor { get; set; }

        public DeliverableRootModel DeliverableRoot { get; set; }
    }
}
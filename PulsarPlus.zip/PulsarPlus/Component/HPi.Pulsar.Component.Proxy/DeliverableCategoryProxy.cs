using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using Microsoft.Extensions.Options;

namespace HPi.Pulsar.Component.Proxy
{
    public class DeliverableCategoryProxy : BaseProxy, IDeliverableCategoryService
    {
        public DeliverableCategoryProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }

        public async Task<DeliverableCategoryModel> GetDeliverableCategoryNameAsync(int id)
        {

            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("id", (object)id, id.GetType()));
            var apiQueryString = await GetQueryString(dictParams).ConfigureAwait(false);
            var url = "api/DeliverableCategory/GetDeliverableCategoryName" + apiQueryString;
            return await this.GetResponse<DeliverableCategoryModel>(url).ConfigureAwait(false);
        }

        public async Task<bool> TryAddSupplierCodeAsync(int vendorId, int categoryId, string supplierCode)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("vendorId", (object)vendorId, vendorId.GetType()));
            dictParams.Add(Tuple.Create("categoryId", (object)categoryId, categoryId.GetType()));
            dictParams.Add(Tuple.Create("supplierCode", (object)supplierCode, supplierCode.GetType()));
            var apiQueryString = await GetQueryString(dictParams).ConfigureAwait(false);
            var url = "api/DeliverableCategory/AddSupplierCode" + apiQueryString;
            return await this.GetResponse<bool>(url).ConfigureAwait(false);
        }
    }
}

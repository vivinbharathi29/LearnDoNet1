using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using Microsoft.Extensions.Options;

namespace HPi.Pulsar.Component.Proxy
{
    public class DeliverableVersionProxy : BaseProxy, IDeliverableVersionService
    {
        public DeliverableVersionProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }

        public async Task<DeliverableVersionModel> GetVersionPartNumberAsync(int id)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("Id", (object)id, id.GetType()));
            var apiQueryString = await GetQueryString(dictParams).ConfigureAwait(false);
            var url = "api/DeliverableVersion/GetVersionPartNumber" + apiQueryString;
            return await this.GetResponse<DeliverableVersionModel>(url).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateVersionPartNumberAsync(int id, string partNumber)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("id", (object)id, id.GetType()));
            dictParams.Add(Tuple.Create("partNumber", (object)partNumber, partNumber.GetType()));
            var apiQueryString = await GetQueryString(dictParams).ConfigureAwait(false);
            var url = "api/DeliverableVersion/UpdateVersionPartNumber" + apiQueryString;
            return await this.GetResponse<bool>(url).ConfigureAwait(false);
        }

        public async Task<DeliverableVersionModel[]> GetVersionPropertiesForWebAsync(int id)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("id", (object)id, id.GetType()));
            var apiQueryString = await GetQueryString(dictParams).ConfigureAwait(false);
            var url = "api/DeliverableVersion/GetVersionPropertiesForWeb" + apiQueryString;
            return await this.GetResponse<DeliverableVersionModel[]>(url).ConfigureAwait(false);
        }

        public async Task<OtsDelVerModel[]> GetOTSByDelVersionAsync(int delVerId)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("delVerId", (object)delVerId, delVerId.GetType()));
            var apiQueryString = await GetQueryString(dictParams).ConfigureAwait(false);
            var url = "api/DeliverableVersion/GetOTSByDelVersion/" + apiQueryString;
            return await this.GetResponse<OtsDelVerModel[]>(url).ConfigureAwait(false);
        }

        public async Task<ProductVersionModel[]> GetProductVersionsByNameAsync(string product)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("product", (object)product, product.GetType()));
            var apiQueryString = await GetQueryString(dictParams).ConfigureAwait(false);
            var url = "api/DeliverableVersion/GetProductVersionsByName/" + apiQueryString;
            return await this.GetResponse<ProductVersionModel[]>(url).ConfigureAwait(false);
        }
    }
}

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using Microsoft.Extensions.Options;

namespace HPi.Pulsar.Component.Proxy
{
    public class VendorProxy : BaseProxy, IVendorService
	 {
		public VendorProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
		{
		}

        public async Task<VendorModel> GetVendorNameAsync(int id)
		{
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("id", (object)id, id.GetType()));
            var apiQueryString = await GetQueryString(dictParams).ConfigureAwait(false);
            var url = "api/Vendor/GetVendorName" + apiQueryString;
            return await this.GetResponse<VendorModel>(url).ConfigureAwait(false);
        }
	 }
}

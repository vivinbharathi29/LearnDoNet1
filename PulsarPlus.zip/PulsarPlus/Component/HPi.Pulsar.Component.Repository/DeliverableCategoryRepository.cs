using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Repositories;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Extension;

namespace HPi.Pulsar.Component.Repository
{
    public class DeliverableCategoryRepository : BaseRepository, IDeliverableCategoryRepository
    {
        public DeliverableCategoryRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }

        public async Task<DeliverableCategoryModel> GetDeliverableCategoryNameAsync(int id)
        {
            List<DeliverableCategoryModel> deliverableCategoryList = new List<DeliverableCategoryModel>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("ID", id);

            DeliverableCategoryModel deliverableCategory = null;

            using (SqlDataReader dataReader = await this.ExecuteReader(StoredProcedure.GetDeliverableCategoryName, parameters).ConfigureAwait(false))
            {

                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    deliverableCategory = new DeliverableCategoryModel();
                    deliverableCategory.Id = dataReader.GetValueOrDefault<int>("ID");
                    deliverableCategory.Name = dataReader.GetValueOrDefault<string>("Name");
                    deliverableCategoryList.Add(deliverableCategory);
                }
                return deliverableCategory;
            }
        }

        public async Task<bool> TryAddSupplierCodeAsync(int vendorId, int categoryId, string supplierCode)
        {
            bool status = false;
            var parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("CategoryID", categoryId);
            parameters[1] = new SqlParameter("VendorID", vendorId);
            parameters[2] = new SqlParameter("SupplierCode", supplierCode);
            int rowsAffected = await this.ExecuteNonQuery(StoredProcedure.AddSupplierCode, parameters).ConfigureAwait(false);
            status = rowsAffected == 1 ? true : false;
            return status;
        }
    }
}

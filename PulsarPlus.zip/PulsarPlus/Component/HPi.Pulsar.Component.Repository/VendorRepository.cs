using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Repositories;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Extension;

namespace HPi.Pulsar.Component.Repository
{
    public class VendorRepository : BaseRepository, IVendorRepository
    {
        public VendorRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }

        public async Task<VendorModel> GetVendorNameAsync(int id)
        {
            List<VendorModel> vendorList = new List<VendorModel>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("ID", id);

            VendorModel vendor = null;

            using (SqlDataReader dataReader = await this.ExecuteReader(StoredProcedure.GetVendorName, parameters).ConfigureAwait(false))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    vendor = new VendorModel();
                    vendor.Id = dataReader.GetValueOrDefault<int>("ID");
                    vendor.Name = dataReader.GetValueOrDefault<string>("Name");
                    vendorList.Add(vendor);
                }
                return vendor;
            }
        }
    }
}

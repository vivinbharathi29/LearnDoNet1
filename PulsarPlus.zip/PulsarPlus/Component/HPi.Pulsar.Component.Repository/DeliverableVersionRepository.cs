using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Component.Contracts;
using HPi.Pulsar.Component.Contracts.Repositories;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Extension;

namespace HPi.Pulsar.Component.Repository
{
    public class DeliverableVersionRepository : BaseRepository, IDeliverableVersionRepository
    {
        public DeliverableVersionRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }

        public async Task<DeliverableVersionModel> GetVersionPartNumberAsync(int id)
        {
            List<DeliverableVersionModel> deliverableVersions = new List<DeliverableVersionModel>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("ID", id);

            DeliverableVersionModel deliverableVersion = null;

            using (SqlDataReader dataReader = await this.ExecuteReader(StoredProcedure.GetVersionPartNumber, parameters).ConfigureAwait(false))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    deliverableVersion = new DeliverableVersionModel();
                    deliverableVersion.Vendor = new VendorModel();
                    deliverableVersion.Vendor.Name = dataReader.GetValueOrDefault<string>("Vendor");
                    deliverableVersion.Id = dataReader.GetValueOrDefault<int>("ID");
                    deliverableVersion.DeliverableName = dataReader.GetValueOrDefault<string>("DeliverableName");
                    deliverableVersion.Version = dataReader.GetValueOrDefault<string>("Version");
                    deliverableVersion.Revision = dataReader.GetValueOrDefault<string>("Revision");
                    deliverableVersion.Pass = dataReader.GetValueOrDefault<string>("Pass");
                    deliverableVersion.PartNumber = dataReader.GetValueOrDefault<string>("PartNumber");
                    deliverableVersions.Add(deliverableVersion);
                }

                return deliverableVersion;
            }
        }

        public async Task<bool> TryUpdateVersionPartNumberAsync(int id, string partNumber)
        {
            bool status = false;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("ID", id);
            parameters[1] = new SqlParameter("PartNumber", partNumber);
            int rowsAffected = await this.ExecuteNonQuery(StoredProcedure.UpdateVersionPartNumber, parameters).ConfigureAwait(false);
            status = rowsAffected == 1 ? true : false;
            return status;
        }

        public async Task<DeliverableVersionModel[]> GetVersionPropertiesForWebAsync(int id)
        {
            List<DeliverableVersionModel> deliverableVersions = new List<DeliverableVersionModel>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("ID", id);

            DeliverableVersionModel deliverableVersion = null;

            using (SqlDataReader dataReader = await this.ExecuteReader(StoredProcedure.GetVersionPropertiesForWeb, parameters).ConfigureAwait(false))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    deliverableVersion = new DeliverableVersionModel();
                    deliverableVersion.DeliverableRoot = new DeliverableRootModel();
                    deliverableVersion.Id = dataReader.GetValueOrDefault<int>("ID");
                    deliverableVersion.DeliverableRootId = dataReader.GetValueOrDefault<int?>("DeliverableRootID");
                    deliverableVersion.DeliverableName = dataReader.GetValueOrDefault<string>("DeliverableName");
                    deliverableVersion.Version = dataReader.GetValueOrDefault<string>("Version");
                    deliverableVersion.Revision = dataReader.GetValueOrDefault<string>("Revision");
                    deliverableVersion.Pass = dataReader.GetValueOrDefault<string>("Pass");
                    deliverableVersion.Status = dataReader.GetValueOrDefault<int?>("Status");
                    deliverableVersion.Changes = dataReader.GetValueOrDefault<string>("Changes");
                    deliverableVersion.DeliverableRoot.Name = dataReader.GetValueOrDefault<string>("Name");
                    deliverableVersions.Add(deliverableVersion);
                }

                return deliverableVersions.ToArray();
            }
        }

        public async Task<OtsDelVerModel[]> GetOTSByDelVersionAsync(int delVerId)
        {
            List<OtsDelVerModel> otsDelVersions = new List<OtsDelVerModel>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("DelVerID", delVerId);

            OtsDelVerModel otsDelVersion = null;

            using (SqlDataReader dataReader = await this.ExecuteReader(StoredProcedure.GetOTSByDelVersion, parameters).ConfigureAwait(false))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    otsDelVersion = new OtsDelVerModel();
                    otsDelVersion.SIObservationReport = new SIObservationReportModel();
                    otsDelVersion.Id = dataReader.GetValueOrDefault<int>("Id");
                    otsDelVersion.OtsNumber = dataReader.GetValueOrDefault<string>("OTSNumber");
                    otsDelVersion.DeliverableVersionId = dataReader.GetValueOrDefault<int?>("DeliverableVersionID");
                    otsDelVersion.SIObservationReport.PrimaryProduct = dataReader.GetValueOrDefault<string>("platform");
                    otsDelVersion.SIObservationReport.ShortDescription = dataReader.GetValueOrDefault<string>("shortdescription");
                    otsDelVersion.StepsToReproduce = dataReader.GetValueOrDefault<string>("stepstoreproduce");
                    otsDelVersions.Add(otsDelVersion);
                }

                return otsDelVersions.ToArray();
            }
        }

        public async Task<ProductVersionModel[]> GetProductVersionsByNameAsync(string productName)
        {
            List<ProductVersionModel> productVersions = new List<ProductVersionModel>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("Product", productName);

            ProductVersionModel productVersion = null;

            using (SqlDataReader dataReader = await this.ExecuteReader(StoredProcedure.GetProductVersionByName, parameters).ConfigureAwait(false))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    productVersion = new ProductVersionModel();
                    productVersion.Id = dataReader.GetValueOrDefault<int>("ID");
                    productVersion.Version = dataReader.GetValueOrDefault<string>("Version");
                    productVersion.ProductFamilyId = dataReader.GetValueOrDefault<int?>("ProductFamilyID");
                    productVersions.Add(productVersion);
                }

                return productVersions.ToArray();
            }
        }
    }
}

﻿using System;
using System.IO;
using Microsoft.Extensions.Configuration;
namespace HPi.Pulsar.Infrastructure.Contracts
{
    public static class AppSettings
    {
        public static IConfiguration Configuration { get; set; }
        public static T Get<T>(string key)
        {
            if (key == string.Empty)
            {
                return default(T);
            }
            else
            {
                string environmentName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                string currentDirectory = Directory.GetCurrentDirectory();
                var builder = new ConfigurationBuilder().SetBasePath(currentDirectory)
                                                        .AddJsonFile($"appsettings.{environmentName}.json");
                var configuration = builder.Build();
                return (T)Convert.ChangeType(configuration[key], typeof(T));
            }
        }
    }
}

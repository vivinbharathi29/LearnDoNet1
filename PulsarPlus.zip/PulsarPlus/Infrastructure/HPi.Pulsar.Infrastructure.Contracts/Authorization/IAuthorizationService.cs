﻿using System.Collections.Generic;
using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.Authorization
{
    public interface IAuthorizationService
    {
        Task<bool> IsAuthorizedAsync(int userId, string PermissionName);
        Task<List<string>> GetPermissionsAsync();
        Task<List<string>> GetUserPermissionsAsync(int userId);
    }
}
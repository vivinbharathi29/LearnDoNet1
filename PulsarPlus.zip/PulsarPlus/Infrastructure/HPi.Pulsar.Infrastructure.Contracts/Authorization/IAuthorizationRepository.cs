﻿using System.Collections.Generic;
using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.Authorization
{
    public interface IAuthorizationRepository
    {
        Task<List<string>> GetUserPermissionsAsync(int userID);
        Task<List<string>> GetPermissionsAsync();
    }
}

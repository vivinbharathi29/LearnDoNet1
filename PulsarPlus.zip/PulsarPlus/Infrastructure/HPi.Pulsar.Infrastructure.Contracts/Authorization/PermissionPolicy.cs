﻿namespace HPi.Pulsar.Infrastructure.Contracts.Authorization
{
    public class PermissionPolicy
    {
        public const string ProductSearch = "ProductSearch";
        public const string ProductEdit = "ProductEdit";
    }
}

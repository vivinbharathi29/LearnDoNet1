﻿namespace HPi.Pulsar.Infrastructure.Contracts.UserInfo
{
    public class MenuUserInfoModel
    {
        public string NtName { get; set; }
        public int ImpersonateID { get; set; }
        public int Division { get; set; }
        public int PartnerID { get; set; }
        public int PartnerTypeID { get; set; }
        public int SupportAdmin { get; set; }
        public int JupiterAdmin { get; set; }
    }
}

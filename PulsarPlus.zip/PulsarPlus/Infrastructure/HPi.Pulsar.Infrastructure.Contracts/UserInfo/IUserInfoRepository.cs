﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.UserInfo
{
    public interface IUserInfoRepository
    {
        Task<UserInfoModel> GetUserByNameAsync(string name, string domain);
        Task<UserInfoModel> GetUserByIdAsync(int? id);
        Task<UserInfoModel> GetUserByEmailAsync(string email);
        Task<UserInfoModel> GetUserInfoByUserNameAsync(string userName, string domain, bool? isCacheRequired);
        Task<UserInfoModel> GetEmployeeImpersonateIdAsync(string ntName, string domain);
        Task<UserInfoModel> GetEmployeeByIDAsync(int impersonateId);
        Task<MenuUserInfoModel> GetUserMenuRightsAsync(int userId);
        Task<UserInfoModel[]> GetImpersonationEmployeesAsync(int isImpersonate, string userNamePattern, string filter);
        Task<UserInfoModel> IsSupportAdminAsync(int employeeId);
        Task<bool> TrySaveImpersonationEmployeeAsync(int employeeId, int impersonateId);
        Task<UserInfoModel[]> GetSwitchPMEmployeesAsync(int sepmId, string userNamePattern);
        Task<bool> SavePMImpersonationEmployeeAsync(int employeeId, int impersonateId);
        Task<UserInfoModel[]> GetCmPcPHWebMarketingUsersAsync(int switchType,string userNamePattern);
        Task<bool> SaveCmPcPHWebMarketingUserAsync(int employeeId, int impersonateId, int switchType);
        Task<UserInfoModel> GetEmployeesIsSysAdminAsync(int? employeeID, int isAdmin, string ntName, string domain, int? partnerID);
        Task<UserInfoModel[]> GetEmployeesPMsActiveAsync(int typeID);
        Task<int> GetUserInRoleAsync(int? userId, int? productVersionId, string roleName);
        Task<bool> TryUpdateDCRWorkflowReassignAsync(int historyId, int reassignId);
        Task<UserInfoModel[]> GetAllAccessoryPMsAsync();
        Task<UserInfoModel[]> ListFactoryEngineersAllAsync();
        Task<UserInfoModel[]> GetEmployeeListAsync(string userNamePattern);
        Task<UserInfoModel[]> GetActionEmployeesAsync(string userType, string userNamePattern, int currentUserId, int ownerId, int id);
        Task<UserInfoModel[]> GetEngineeringCoorginatorsAsync();
        Task<bool> UpdateFavoritesAsync(UserInfoModel userInfo);
        Task<bool> UpdateDefaultProductTabAsync(int employeeId, string tab);
    }
}

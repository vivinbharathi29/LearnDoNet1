namespace HPi.Pulsar.Infrastructure.Contracts.UserInfo
{
    using System;
    using HPi.Pulsar.Infrastructure.Contracts.Partner;
    public class UserInfoModel
    {
        public int UserId { get; set; }
        public int EmployeeId { get; set; }
        public string NtName { get; set; }
        public string NtDomain { get; set; }
        public string NameExtension { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int? ManagerId { get; set; }
        public string ManagerName { get; set; }
        public bool? IsActiveInGAL { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public int? ImpersonateId { get; set; }
        public DateTime? LastActivity { get; set; }
        public DateTime? Created { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? Updated { get; set; }
        public string UpdatedBy { get; set; }
        public string DisabledBy { get; set; }
        public DateTime? Disabled { get; set; }
        public bool? IsHp { get; set; }
        public string FullName { get; set; }
        public string ShortName { get; set; }
        public Guid? UserGuid { get; set; }
        public int? IrsUserId { get; set; }
        public int? PartnerId { get; set; }
        public string Office { get; set; }
        public short? ManagerLevel { get; set; }
        public int? WorkgroupID { get; set; }
        public string WorkgroupName { get; set; }
        public byte? Division { get; set; }
        public string DivisionName { get; set; }
        public bool? ApprovalSection { get; set; }
        public bool? PastDueSection { get; set; }
        public bool? WorkingSection { get; set; }
        public bool? DueThisWeekSection { get; set; }
        public bool? AllOpenSection { get; set; }
        public bool? ISubmittedSection { get; set; }
        public bool? ClosedSection { get; set; }
        public bool? ProposedSection { get; set; }
        public int? LastStatusSection { get; set; }
        public string LastStatusCategory { get; set; }
        public int? StatusDelegate { get; set; }
        public byte? PIPMAlertSection { get; set; }
        public byte? PINewRequestSection { get; set; }
        public int? PIScripterSection { get; set; }
        public byte? PIDBTeamSection { get; set; }
        public byte? PIReassignedSection { get; set; }
        public string Favorites { get; set; }
        public short? FavCount { get; set; }
        public bool? PostRTMSection { get; set; }
        public bool? OTSSubmittedSection { get; set; }
        public bool? OTSOwnerSection { get; set; }
        public bool? OTSDeliverableSection { get; set; }
        public bool? SystemAdmin { get; set; }
        public DateTime? ResetPassword { get; set; }
        public bool? PreinstallPM { get; set; }
        public bool? CanReleaseLocalizations { get; set; }
        public bool? FindManager { get; set; }
        public bool? CommodityPM { get; set; }
        public bool? ProgramCoordinator { get; set; }
        public string DefaultProductTab { get; set; }
        public bool? AccessoryPM { get; set; }
        public int? TodayPageLoad { get; set; }
        public bool? SCFactoryEngineer { get; set; }
        public bool? MITTestLead { get; set; }
        public bool? WHQLTestTeam { get; set; }
        public byte? EngCoordinator { get; set; }
        public bool? FunctionalTestMADTSection { get; set; }
        public bool? FunctionalTestHelpAndSupportSection { get; set; }
        public bool? FunctionalTest3rdPartySection { get; set; }
        public bool? FunctionalTestOtherSection { get; set; }
        public bool? FunctionalTestDeveloperSection { get; set; }
        public bool? FunctionalTestUserGuidesSection { get; set; }
        public bool? FunctionalTest3rdPartyConsSection { get; set; }
        public bool? ServicePM { get; set; }
        public bool? ProcurementEngineer { get; set; }
        public int? PMImpersonate { get; set; }
        public bool? FunctionalTestToolsSection { get; set; }
        public bool? WWANEngineer { get; set; }
        public int? DefaultWorkingListProduct { get; set; }
        public bool? ServiceCommodityManager { get; set; }
        public byte? ODMLoginStatus { get; set; }
        public bool? ToolDeveloper { get; set; }
        public string QualityCenterID { get; set; }
        public bool? FTPAccessRequested { get; set; }
        public bool? ServiceCoordinator { get; set; }
        public bool? FunctionalTestMultimediaSection { get; set; }
        public bool? BPIAApprover { get; set; }
        public bool? FTHWEnablingSection { get; set; }
        public bool? FTIntelTechnologiesSection { get; set; }
        public bool? FTMultimediaAppsSection { get; set; }
        public bool? FTSecuritySection { get; set; }
        public bool? FTBIOSSection { get; set; }
        public bool? FTThinClientSection { get; set; }
        public int? CMImpersonate { get; set; }
        public int? PCImpersonate { get; set; }
        public int? PhWebImpersonate { get; set; }
        public int? MarketingImpersonate { get; set; }
        public bool? FTVirtualizationSection { get; set; }
        public bool? FunctionalTest3rdPartyInternalSection { get; set; }
        public string OtherPartnerNames { get; set; }
        public byte? SourceSystem { get; set; }
        public bool? DevTeam { get; set; }
        public bool? Pulsar { get; set; }
        public int? PINPMImpersonate { get; set; }
        public byte? Active { get; set; }
        public DateTime? Deactivated { get; set; }
        public bool? AccountSuspended { get; set; }
        public DateTime? Suspended { get; set; }
        ///// <summary>
        ///// Gets or sets the ActivityLog.
        ///// </summary>
        //public ActivityLogModel ActivityLog { get; set; }
        ///// <summary>
        ///// Gets or sets the Rolemembers.
        ///// </summary>
        //public RolemembersModel Rolemembers { get; set; }
        public string FullNameAuthendication => $"{FirstName} {LastName}".Trim();
        public string DisplayName => $"{LastName}, {FirstName}".Trim();
        public string AuthName => $"{NtDomain}\\{NtName}".Trim();
        public static UserInfoModel Empty()
        {
            return new UserInfoModel
            {
                UserId = 0,
                UserGuid = Guid.Empty,
                FirstName = string.Empty,
                LastName = string.Empty,
                Email = string.Empty,
                NtDomain = string.Empty,
                NtName = string.Empty,
                IsHp = false,
                ImpersonateId = 0,
                OriginalUserId = 0
            };
        }
        //TOday Page Configure Subsection.TestLeadAssignments
        public int? TestLeadAssignments { get; set; }
        public int? ConsumerSEPMProducts { get; set; }
        public int? HWProducts { get; set; }
        public int? ServiceProducts { get; set; }
        public int? SEPMProducts { get; set; }
        public int? EngCoordinatorForConfiguration { get; set; }
        public int? SMProducts { get; set; }
        public int? AVsMissingCommMarketingData { get; set; }
        public int? AVsMissingSMBMarketingData { get; set; }
        public int? AVsMissingConsMarketingData { get; set; }
        public int? PDMUser { get; set; }
        public int? CMProductCount { get; set; }
        public int? PCProductCount { get; set; }
        public int? PhWebProductCount { get; set; }
        public int? MarketingProductCount { get; set; }
        public int? PCAdmin { get; set; }
        public int? CMAdmin { get; set; }
        public int? PDMAdmin { get; set; }
        public int? MKTAdmin { get; set; }
        public int? SAAdmin { get; set; }
        public int? JupiterXLR8Admin { get; set; }
        public int? PulsarSystemAdmin { get; set; }
        public int? IsPINPM { get; set; }
        public string originalName { get; set; }
        public int? CanEditProduct { get; set; }
        public int? AgencyDataMaintainer { get; set; }
        public string CurrentName { get; set; }
        public PartnerModel Partner { get; set; }
        public string LoginUserName { get; set; }
        public int OriginalUserId { get; set; }
        public int ProductImageEdit { get; set; }
        public int Sort { get; set; }
    }
}
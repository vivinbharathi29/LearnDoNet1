﻿namespace HPi.Pulsar.Infrastructure.Contracts.UserInfo
{
    public interface ICurrentUserProfile
    {
        string Name { get; }
        string UserName { get; }
        string UserGuid { get; }
        int UserId { get; }
        string IsHp { get; }
        string NtDomain { get; }
        string NtName { get; }
        string ActualUserId { get; }
        string ActualGivenName { get; }
        string IsReverseProxyConnection { get; }
        string AuthName { get; }
        string Email { get; }
        string DisplayName { get; }
        int? ImpersonateId { get; }
        int? PMImpersonate { get; }
        int? CMImpersonate { get; }
        int? PCImpersonate { get; }
        int? PhWebImpersonate { get; }
        string CurrentName { get; }
        string originalName { get; }
        string LoginAuthName { get; }
        string LoginDomain { get; }
        string Favourites { get; }
        int? MarketingImpersonate { get; }
        bool ServicePM { get; }
        bool WWANEngineer { get; }
        bool ProcurementEngineer { get; }
        bool ServiceCommodityManager { get; }
        int SepmCount { get; }
        bool PreInstall { get; }
        int? PartnerId { get; }
        int? PartnerTypeId { get; }
        int? PulsarSystemAdmin { get; }
        int? WorkGroupId { get; }
        string UserBrowser { get; }
        int OriginalUserId { get; }
        bool? CommodityPM { get; }
        bool? SCFactoryEngineer { get; }
        bool? AccessoryPM { get; }
        int? EngCoordinator { get; }
        int? DefaultWorkingListProduct { get; }
        int? SAAdmin { get; }
        bool ServiceCoordinator { get; }
        byte? Division { get; }
        bool IsSystemAdmin { get; }
        bool IsWHQLTestTeam { get; }
        bool IsMITTestLead { get; }
        int? CMProductCount { get; }
        int? MarketingProductCount { get; }
        int? PCProductCount { get; }
        int? AgencyDataMaintainer { get; }
        int ProductImageEdit { get; }
    }
}
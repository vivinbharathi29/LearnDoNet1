﻿using HPi.Pulsar.Infrastructure.Contracts.Enumerators;

namespace HPi.Pulsar.Infrastructure.Contracts.Pagination
{
    public class PaginationModel
    {
        public int PageNo { get; set; }
        public int PageSize { get; set; }
        public string SortBy { get; set; }
        public ListSortDirectionEnum SortDirection { get; set; }
        public FilterModel[] Filters { get; set; }
    }
}

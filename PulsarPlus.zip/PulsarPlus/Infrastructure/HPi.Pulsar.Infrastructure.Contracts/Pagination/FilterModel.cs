﻿using HPi.Pulsar.Infrastructure.Contracts.Enumerators;
namespace HPi.Pulsar.Infrastructure.Contracts.Pagination
{
    public class FilterModel
    {
        public string ColumnName { get; set; }
        public string Value { get; set; }
        public FilterColumnTypeEnum ColumnType { get; set; }
        public FilterOperatorEnum Operator { get; set; }
        public string Condition { get; set; }
    }
}

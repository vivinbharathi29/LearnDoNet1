﻿namespace HPi.Pulsar.Infrastructure.Contracts.Pagination
{
    public enum ListSortDirection
    {
        Ascending,
        Descending
    }
}

﻿using System;
using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling
{
    public interface IExceptionHandlingService
    {
        Task HandleExceptionAsync(Exception exception);
        Task HandleExceptionAsync(Exception exception, bool throwException);
        Task HandleExceptionAsync(Exception exception, IErrorContext context);
    }
}

﻿namespace HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling
{
    public class WebApiExceptionResponseModel
    {
        public string ExceptionType { get; set; }
        public string ExceptionMessage { get; set; }
    }
}

﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
namespace HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling
{
    public interface IExceptionHandler
    {
        Task HandleAsync(HttpContext context);
    }
}

﻿namespace HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling
{
    public class IErrorContext
    {
        public string ApplicationName { get; set; }
        public string ApplicationVersion { get; set; }
        public string UserID { get; set; }
        public string IPAddress { get; set; }
    }
}

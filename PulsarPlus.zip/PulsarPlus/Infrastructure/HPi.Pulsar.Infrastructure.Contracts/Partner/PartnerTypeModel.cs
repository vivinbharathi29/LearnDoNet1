using System;
namespace HPi.Pulsar.Infrastructure.Contracts.Partner
{
    public class PartnerTypeModel
    {
        public int ID { get; set; }
        public string PartnerType { get; set; }
        public int PartnerTypeId { get; set; }
    }
}
﻿using System;
namespace HPi.Pulsar.Infrastructure.Contracts.ApplicationExceptions
{
    public class PulsarBusinessException : Exception
    {
        public PulsarBusinessException(string message) : base(message)
        {
        }
    }
}

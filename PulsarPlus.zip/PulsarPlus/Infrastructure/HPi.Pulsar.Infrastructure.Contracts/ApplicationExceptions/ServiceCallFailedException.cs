﻿using System;
namespace HPi.Pulsar.Infrastructure.Contracts.ApplicationExceptions
{
    public class ServiceCallFailedException : Exception
    {
        public ServiceCallFailedException(string requestUri)
        {
            this.RequestURI = requestUri;
        }
        public ServiceCallFailedException(string requestUri, string message) : base(message)
        {
            this.RequestURI = requestUri;
        }
        public string RequestURI { get; set; }
    }
}

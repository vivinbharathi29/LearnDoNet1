﻿using System.Collections.Generic;
namespace HPi.Pulsar.Infrastructure.Contracts.Models
{
    public class PaginationConfiguration
    {
        public int DefaultPageSize = 50;
        public List<int> PageSizeOptions = new List<int> { 10, 20, 50, 100, 500, 1000, 5000 };
    }
}

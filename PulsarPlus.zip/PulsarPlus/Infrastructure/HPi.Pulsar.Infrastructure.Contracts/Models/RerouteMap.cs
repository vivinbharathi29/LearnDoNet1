﻿namespace HPi.Pulsar.Infrastructure.Contracts.Models
{
    public class RerouteMap
    {
        public string NewUrl { get; set; }
        public string OldUrl { get; set; }
    }
}

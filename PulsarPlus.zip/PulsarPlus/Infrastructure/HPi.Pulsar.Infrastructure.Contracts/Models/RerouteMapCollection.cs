﻿namespace HPi.Pulsar.Infrastructure.Contracts.Models
{
    public class RerouteMapCollection
    {
        public RerouteMap[] RerouteMaps { get; set; }
    }
}

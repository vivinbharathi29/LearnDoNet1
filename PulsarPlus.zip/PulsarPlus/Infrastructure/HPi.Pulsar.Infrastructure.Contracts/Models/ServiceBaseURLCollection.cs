﻿namespace HPi.Pulsar.Infrastructure.Contracts.Models
{
    public class ServiceBaseURLCollection
    {
        public ServiceBaseURL[] ServiceBaseURLs { get; set; }
    }
}

﻿namespace HPi.Pulsar.Infrastructure.Contracts.Models
{
    public class ServiceBaseURL
    {
        public string ServiceName { get; set; }
        public string ServiceURL { get; set; }
    }
}

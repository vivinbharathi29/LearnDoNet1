﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.Caching
{
    public interface ICacheRepository
    {
        Task SetCacheAsync(string cacheKey, string value, int expiryTime, string itemType);
        Task<string> GetCacheAsync(string cacheKey);
        Task InvalidateCacheAsync(string cacheKey);
    }
}

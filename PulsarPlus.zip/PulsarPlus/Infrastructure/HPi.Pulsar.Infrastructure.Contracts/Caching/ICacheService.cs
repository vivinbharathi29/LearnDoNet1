﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.Caching
{
    public interface ICacheService
    {
        Task SetCacheAsync<T>(string cacheKey, T value, int expiryTime, string itemType);
        Task SetCacheAsync<T>(string cacheKey, T value, int expiryTime, string itemType, bool useInMemory);
        Task<T> GetCacheAsync<T>(string cacheKey);
        Task<T> GetCacheAsync<T>(string cacheKey, bool useInMemory);
        Task InvalidateCacheAsync(string cacheKey);
        Task InvalidateCacheAsync(string cacheKey, bool useInMemory);
        Task SetCacheAsync(string cacheKey, string value, int expiryTime, string itemType, bool useInMemory);
        Task<string> GetCacheAsync(string cacheKey, bool useInMemory);
    }
}

﻿namespace HPi.Pulsar.Infrastructure.Contracts.Caching
{
    public class CacheKey
    {
        public const string UserCacheCode = "UserCacheCode";
        public const string DevCenter = "DevCenter";
        public const string BusinessSegment = "BusinessSegment";
        public const string Partner = "Partner";
        public const string RCTOSite = "RCTOSite";
        public const string ProductFamily = "ProductFamily";
        public const string ProductLine = "ProductLine";
    }
}

﻿namespace HPi.Pulsar.Infrastructure.Contracts.Logging
{
    public enum LogStatus
    {
        NeedsAttention = 0,
        IssueResolved = 1,
        InformationalOnly = 2
    }
}

﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.Logging
{
    public interface ILoggingService
    {
        Task<int> LogErrorAsync(ErrorLogModel errorLogModel);
    }
}

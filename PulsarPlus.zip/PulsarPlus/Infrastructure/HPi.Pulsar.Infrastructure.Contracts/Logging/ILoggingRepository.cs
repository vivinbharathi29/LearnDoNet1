﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.Logging
{
    public interface ILoggingRepository
    {
        Task<int> LogErrorAsync(ErrorLogModel errorLogModel);
    }
}

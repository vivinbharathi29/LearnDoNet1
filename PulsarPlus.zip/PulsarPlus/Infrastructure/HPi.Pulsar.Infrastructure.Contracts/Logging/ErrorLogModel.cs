﻿using System;
using System.Diagnostics;
namespace HPi.Pulsar.Infrastructure.Contracts.Logging
{
    public class ErrorLogModel
    {
        public static ErrorLogModel Create(Exception exceptionToLog, string applicationName, string applicationVersion, string userId, string remoteIP)
        {
            string assemblyName = null;
            string assemblyversion = null;
            var errorDescription = string.Empty;
            var st = new StackTrace(exceptionToLog, true);
            var frames = st.GetFrames();
            if (frames != null && frames.Length > 0)
            {
                var declaringType = frames[0].GetMethod().DeclaringType;
                if (declaringType != null)
                {
                    assemblyName = string.Format("{0} version {1}", frames[0].GetMethod().Module.Assembly.GetName().Name, frames[0].GetMethod().Module.Assembly.GetName().Version);
                    assemblyversion = frames[0].GetMethod().Module.Assembly.GetName().Version.ToString();
                }
                else
                {
                    assemblyName = frames[0].GetMethod().ToString();
                }
                errorDescription = exceptionToLog.StackTrace + exceptionToLog.StackTrace;
            }
            return Create(exceptionToLog.Message, assemblyName, errorDescription, assemblyversion, userId, applicationName, applicationVersion, remoteIP);
        }
        public static ErrorLogModel Create(string errorMessage, string assemblyName, string errorDescription,
            string assemblyVersion, string userId, string applicationName,
            string applicationVersion = null, string remoteIP = null)
        {
            return new ErrorLogModel
            {
                ApplicationName = applicationName,
                ApplicationVersion = applicationVersion,
                ErrorMessage = errorMessage,
                AssemblyName = assemblyName,
                ErrorDescription = errorDescription,
                AssemblyVersion = assemblyVersion,
                ServerIp = remoteIP,
                UserId = userId
            };
        }
        public string ErrorMessage { get; set; }
        public string AssemblyName { get; set; }
        public string ErrorDescription { get; set; }
        public string AssemblyVersion { get; set; }
        public string ApplicationName { get; set; }
        public string UserId { get; set; }
        public string ApplicationVersion { get; set; }
        public string ServerIp { get; set; }
    }
}

﻿namespace HPi.Pulsar.Infrastructure.Contracts.ApplicationServices
{
    public interface IApplicationProperties
    {
        string Name { get; }
        string Version { get; }
        string ConnectionString { get; }
        string Environment { get; }
        string EventSourceName { get; set; }
    }
}

﻿using HPi.Pulsar.Infrastructure.Contracts.Authorization;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using HPi.Pulsar.Infrastructure.Contracts.Logging;
using HPi.Pulsar.Infrastructure.Contracts.Notification;
using HPi.Pulsar.Infrastructure.Contracts.SessionState;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
namespace HPi.Pulsar.Infrastructure.Contracts.ApplicationServices
{
    public interface IApplicationServices
    {
        ISessionStateService SessionState { get; set; }
        ICacheService Cache { get; set; }
        IApplicationProperties Properties { get; set; }
        IExceptionHandlingService ExceptionHandling { get; set; }
        ILoggingService Logging { get; set; }
        IAuthorizationService Authorization { get; set; }
        INotificationService Notification { get; set; }
        IUserInfoService UserInformation { get; set; }
    }
}

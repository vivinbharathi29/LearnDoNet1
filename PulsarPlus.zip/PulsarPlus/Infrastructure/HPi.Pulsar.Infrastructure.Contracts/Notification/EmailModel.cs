﻿using System;
using System.Collections.Generic;
namespace HPi.Pulsar.Infrastructure.Contracts.Notification
{
    public class EmailModel
    {
        public string EmailFrom { get; set; }
        public string EmailTo { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string EmailToCc { get; set; }
        public string EmailToBcc { get; set; }
        public EmailImportanceEnum EmailImportance { get; set; }
        public bool IsHtml { get; set; }
        public string DSNOptions { get; set; }
        public List<string> Attachments { get; set; }
        public string EmailType { get; set; }
        public string CreatedBy { get; set; }
        public string SecretKey { get; set; }
        public string Location { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int MessageType { get; set; }
    }
}

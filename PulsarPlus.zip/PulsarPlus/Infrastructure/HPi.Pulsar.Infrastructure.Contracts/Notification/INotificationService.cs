﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.Notification
{
    public interface INotificationService
    {
        Task<bool> SendEmailViaMessageQueuedEmail(EmailTemplateModel emailTemplateModel);

        Task<string> SendEmailViaEWSAsync(EmailTemplateModel emailTemplateModel);
    }
}

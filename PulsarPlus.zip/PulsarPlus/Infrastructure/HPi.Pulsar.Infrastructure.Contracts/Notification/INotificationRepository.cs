﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.Notification
{
    public interface INotificationRepository
    {
        Task<EmailModel> GetEmailTemplateAsync(int templateId);
        Task<int> SendEmailAsync(string emailFrom, string emailToRecipients, string emailToCc, string emailToBcc, string emailSubject, string emailBody);
    }
}

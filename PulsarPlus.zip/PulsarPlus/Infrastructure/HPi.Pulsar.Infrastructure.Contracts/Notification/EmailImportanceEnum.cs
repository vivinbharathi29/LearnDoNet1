﻿namespace HPi.Pulsar.Infrastructure.Contracts.Notification
{
    public enum EmailImportanceEnum
    {
        High = 1,
        Normal = 2,
        Low = 3
    }
}

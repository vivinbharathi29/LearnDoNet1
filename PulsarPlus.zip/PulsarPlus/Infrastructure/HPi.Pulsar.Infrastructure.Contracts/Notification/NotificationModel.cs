﻿using System;
namespace HPi.Pulsar.Infrastructure.Contracts.Notification
{
    public class NotificationModel
    {
        public int EmailId { get; set; }
        public string From { get; set; }
        public string EmailType { get; set; }
        public string To { get; set; }
        public string Cc { get; set; }
        public string Bcc { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public int SendTries { get; set; }
        public DateTime SentOn { get; set; }
        public int EmailAccountId { get; set; }
        public string Attachments { get; set; }
    }
}

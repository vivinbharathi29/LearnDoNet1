﻿namespace HPi.Pulsar.Infrastructure.Contracts.Notification
{
    public enum EmailTemplateEnum
    {
        CommHwPm = 200,
        ProcessorPM = 201,
        GraphicsControllerPM = 202,
        VideoMemoryPM = 203,
        PilotStatus = 205,
        PilotStatusPulsar = 206,
        RemoveRoot = 204,
        UpsertAction = 216,
        UpdateTicket = 208,
        AccessoryStatusPulsar = 207,
        UpdateTicketNotification = 209,
        AccessoryStatusVersion = 210,
        AccessoryStatus = 211,
        BatchUpdatePlanStatus = 217,
        BatchUpdateNewPlanStatus = 218,
        AgencyStatusUpdate = 219,
        QualStatusSubassembly = 212,
        QualStatusHardwareStatus = 213,
        QualStatusSupplyChain = 214
    }
}
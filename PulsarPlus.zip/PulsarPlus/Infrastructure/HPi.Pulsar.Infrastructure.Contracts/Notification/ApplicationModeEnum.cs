﻿namespace HPi.Pulsar.Infrastructure.Contracts.Notification
{
    public enum ApplicationModeEnum
    {
        Production = 1,
        Development = 2,
        Test = 3
    }
}

﻿namespace HPi.Pulsar.Infrastructure.Contracts.Notification
{
    public class EmailTemplateModel
    {
        public int TemplateId { get; set; }
        public EmailModel EmailModel { get; set; }
        public DictionaryItemModel[] DictionaryItems { get; set; }
    }
}

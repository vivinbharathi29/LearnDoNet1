﻿using System.Security.Claims;
namespace HPi.Pulsar.Infrastructure.Contracts.Roles
{
    public class ApplicationUser : ClaimsIdentity
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public int UserId { get; set; }
        public string EmployeeNo { get; set; }
        public string NtName { get; set; }
        public string NtDomain { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
    }
}

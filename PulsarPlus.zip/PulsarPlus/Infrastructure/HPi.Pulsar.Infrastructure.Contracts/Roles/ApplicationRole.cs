﻿namespace HPi.Pulsar.Infrastructure.Contracts.Roles
{
    public class ApplicationRole
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string Description { get; set; }
        public bool Active { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
    }
}

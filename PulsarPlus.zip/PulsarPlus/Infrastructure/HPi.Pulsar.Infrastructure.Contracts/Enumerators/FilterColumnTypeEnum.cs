﻿namespace HPi.Pulsar.Infrastructure.Contracts.Enumerators
{
    public enum FilterColumnTypeEnum
    {
        Number = 1,
        String = 2,
        Date = 3,
        Boolean = 4
    }
}

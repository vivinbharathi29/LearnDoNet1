﻿namespace HPi.Pulsar.Infrastructure.Contracts.Enumerators
{
    public enum FilterOperatorEnum
    {
        EqualTo = 1,
        NotEqualTo = 2,
        GreaterThan = 3,
        LesserThan = 4,
        GreaterThanOrEqualTo = 5,
        LesserThanOrEqualTo = 6,
        StartsWith = 7,
        EndsWith = 8,
        Contains = 9,
        NotContains = 10,
        Empty = 11,
        NotEmpty = 12,
        ContainsCaseSensitive = 13,
        NotContainsCaseSensitive = 14,
        StartsWithCaseSensitive = 15,
        EndsWithCaseSensitive = 16,
        EqualToCaseSensitive = 17,
        Null = 18,
        NotNull = 19,
        Between = 20
    }
}

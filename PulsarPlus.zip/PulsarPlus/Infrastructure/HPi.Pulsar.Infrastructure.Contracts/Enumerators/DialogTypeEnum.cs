﻿namespace HPi.Pulsar.Infrastructure.Contracts.Enumerators
{
    public enum DialogTypeEnum
    {
        Impersonate = 1,
        SwitchPM = 2,
        SwitchCM = 3,
        SwitchPC = 4,
        SwitchMarketing = 5,
        SystemTeam = 6,
        SwitchPHWeb = 7,
        ChipsetProcesser = 8,
        GraphicsController = 9,
        VideoMemory = 10,
        CommHWPM = 11,
        ReAssignMilestone = 12,
        AccessoryPMs = 13,
        CommodityPM = 14,
        ProgramFactoryEngineer = 15,
        ODMHWTestLead = 16,
        WWANTestLead = 17,
        ServicePM = 18,
        ChangeOwner = 19,
        ActionOwner = 20,
        ActionSubmitter = 21,
        ChooseApprover = 22,
        PmViewActionOwner = 23,
        PmViewActionSubmitter = 24,
    }
}

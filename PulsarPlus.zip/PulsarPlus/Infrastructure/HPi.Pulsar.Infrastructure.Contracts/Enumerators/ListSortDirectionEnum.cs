﻿namespace HPi.Pulsar.Infrastructure.Contracts.Enumerators
{
    public enum ListSortDirectionEnum
    {
        Ascending = 1,
        Descending = 2
    }
}

﻿namespace HPi.Pulsar.Infrastructure.Contracts.Enumerators
{
    public enum EnvironmentEnum
    {
        Production = 1,
        Sandbox = 2,
        Test = 3,
        Dev = 4
    }
}

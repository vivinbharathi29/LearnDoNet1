﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HPi.Pulsar.Infrastructure.Contracts.Extension;
using Microsoft.AspNetCore.Mvc.Filters;
namespace HPi.Pulsar.Infrastructure.Contracts.Security
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class EncryptedActionParametersAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            Dictionary<string, object> decryptedParameters = new Dictionary<string, object>();
            var data = AppSettings.Get<bool>("Encryption:EnableEncryption");
            if (AppSettings.Get<bool>("Encryption:EnableEncryption") == true)
            {
                if (filterContext.HttpContext.Request.QueryString.HasValue)
                {
                    string encryptedQueryString = filterContext.HttpContext.Request.QueryString.Value.Split(new char[] { '=' }, 2)[1].ToString();
                    var keybytes = Encoding.UTF8.GetBytes(AppSettings.Get<string>("Encryption:EncryptionKey"));
                    string decrptedString = AESEncryption.Decrypt(encryptedQueryString.ToString(), keybytes);
                    string[] paramsArrs = decrptedString.Split('&');
                    for (int i = 0; i < paramsArrs.Length; i++)
                    {
                        string[] paramArr = paramsArrs[i].Split('=');
                        decryptedParameters.Add(paramArr[0].Split('#')[0], StringExtension.Parse(paramArr[0].Split('#')[1], paramArr[1]));
                    }
                }
                for (int i = 0; i < decryptedParameters.Count; i++)
                {
                    filterContext.ActionArguments[decryptedParameters.Keys.ElementAt(i)] = decryptedParameters.Values.ElementAt(i);
                }
            }
            base.OnActionExecuting(filterContext);
        }
    }
}

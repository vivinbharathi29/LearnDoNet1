﻿namespace HPi.Pulsar.Infrastructure.Contracts.SessionState
{
    public class SessionKey
    {
        public const string UserPermissions = "UserPermissions";
    }
}

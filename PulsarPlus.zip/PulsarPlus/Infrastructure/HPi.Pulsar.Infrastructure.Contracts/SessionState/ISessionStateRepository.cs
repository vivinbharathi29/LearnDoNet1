﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.SessionState
{
    public interface ISessionStateRepository
    {
        Task SetAsync(string sessionGUID, string key, string value, string itemType);
        Task<string> GetAsync(string sessionGUID, string key);
    }
}

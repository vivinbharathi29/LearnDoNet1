﻿using System.Threading.Tasks;
namespace HPi.Pulsar.Infrastructure.Contracts.SessionState
{
    public interface ISessionStateService
    {
        Task SetAsync<T>(string sessionGUID, string key, T value, string itemType);
        Task SetAsync<T>(string sessionGUID, string key, T value);
        Task SetAsync<T>(string sessionGUID, string key, T value, string itemType, bool useInMemory);
        Task<T> GetAsync<T>(string sessionGUID, string key);
        Task<T> GetAsync<T>(string sessionGUID, string key, bool useInMemory);
        Task SetValuesAsync(string sessionGUID, string key, string value, string itemType, bool useInMemory);
        Task<string> GetValuesAsync(string sessionGUID, string key, bool useInMemory);
    }
}

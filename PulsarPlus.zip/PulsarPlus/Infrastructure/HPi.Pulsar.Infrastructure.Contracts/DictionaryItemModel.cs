﻿namespace HPi.Pulsar.Infrastructure.Contracts
{
    public class DictionaryItemModel
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}

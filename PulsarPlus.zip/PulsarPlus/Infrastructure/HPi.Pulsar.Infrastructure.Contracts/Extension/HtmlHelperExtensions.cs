﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
namespace HPi.Pulsar.Infrastructure.Contracts.Extension
{
    public static class HtmlHelperExtensions
    {
        public static IHtmlContent DropDownList(string controlId, List<SelectListItemCustom> selectListItems, string styles, string onChangeClientFunction)
        {
            var selectListHtml = "<select id=\"" + controlId + "\" name=\"" + controlId + "\" class=\"" + styles + "\"";
            if (!string.IsNullOrEmpty(onChangeClientFunction))
            {
                selectListHtml = selectListHtml + "onchange=\"return  " + onChangeClientFunction + "()\"";
            }
            selectListHtml = selectListHtml + ">";
            foreach (var item in selectListItems)
            {
                var attributes = new List<string>();
                if (item.itemsHtmlAttributes != null)
                {
                    foreach (KeyValuePair<string, string> dictItem in item.itemsHtmlAttributes)
                    {
                        attributes.Add(string.Format("{0}='{1}'", dictItem.Key, dictItem.Value));
                    }
                    selectListHtml += string.Format("<option value='{0}' {1} {2}>{3}</option>", item.Value, item.Selected ? "selected" : string.Empty, string.Join(" ", attributes.ToArray()), item.Text);
                }
                else
                {
                    selectListHtml += string.Format("<option value='{0}' {1}>{2}</option>", item.Value, item.Selected ? "selected" : string.Empty, item.Text);
                }
            }
            selectListHtml += "</select>";
            return new HtmlString(selectListHtml);
        }
    }
    public class SelectListItemCustom : SelectListItem
    {
        public IDictionary<string, string> itemsHtmlAttributes { get; set; }
    }
}

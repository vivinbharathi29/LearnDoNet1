﻿using System;
using System.Data.SqlClient;
namespace HPi.Pulsar.Infrastructure.Contracts.Extension
{
    public static class SqlReaderHelper
    {
        public static T GetValueOrDefault<T>(this SqlDataReader dataReader, string fieldName)
        {
            if (dataReader.ColumnExists(fieldName))
            {
                if (dataReader[fieldName] == DBNull.Value)
                    return default(T);
                return (T)dataReader[fieldName];
            }
            else
                return default(T);
        }
        public static bool ColumnExists(this SqlDataReader reader, string columnName)
        {
            for (int i = 0; i < reader.FieldCount; i++)
            {
                if (reader.GetName(i).Equals(columnName, StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Text.RegularExpressions;
namespace HPi.Pulsar.Infrastructure.Contracts.Extension
{
    public static class StringExtension
    {
        public static string SubValue(this string value, int index)
        {
            if (!string.IsNullOrEmpty(value))
            {
                if (value.Length > index)
                {
                    return value.Substring(0, index);
                }
            }
            return value;
        }
        public static bool IsNumeric(this string strTextEntry)
        {
            if (string.IsNullOrEmpty(strTextEntry))
            {
                return false;
            }
            var objNotWholePattern = new Regex("[^0-9]");
            return !objNotWholePattern.IsMatch(strTextEntry);
        }
        public static string StripSpecialCharacters(string value)
        {
            var sb = new StringBuilder();
            foreach (var c in value)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '.' || c == '_')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }
        public static object Parse(string dataType, string ValueToConvert)
        {
            Type T = Type.GetType(dataType);
            var converter = TypeDescriptor.GetConverter(T);
            var result = converter.ConvertFrom(ValueToConvert);
            return result;
        }
        public static string GetLongName(this string name)
        {
            string longName;
            string firstName;
            string lastName;
            string groupName = string.Empty;
            if (name.IndexOf(",") > 0)
            {
                firstName = name.Substring(name.IndexOf(",") + 2);
                lastName = name.Substring(0, name.IndexOf(","));
                if (firstName.IndexOf("(") > 0 && firstName.IndexOf(")") > 0 && firstName.IndexOf(")") > firstName.IndexOf("("))
                {
                    groupName = firstName.Substring(firstName.IndexOf("(")).Trim();
                    firstName = firstName.Substring(0, firstName.IndexOf("(") - 2);
                }
                firstName = firstName.Replace(" ", "");
                longName = firstName + " " + lastName + " " + groupName;
            }
            else
            {
                longName = name;
            }
            return longName;
        }
        public static string GetShortName(this string name)
        {
            string shortName = string.Empty;
            if (!string.IsNullOrEmpty(name))
            {
                if (name.IndexOf(',') > 0)
                {
                    string firstname = name.Split(',')[0];
                    string lastname = name.Split(',')[1].Replace(" ", "");
                    shortName = lastname[0] + ". " + firstname;
                }
                else
                {
                    shortName = name;
                }
            }
            return shortName;
        }
        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            HashSet<TKey> seenKeys = new HashSet<TKey>();
            foreach (TSource element in source)
            {
                if (seenKeys.Add(keySelector(element)))
                {
                    yield return element;
                }
            }
        }
    }
}

﻿using System.Collections.Generic;
using System.Text;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
namespace HPi.Pulsar.Infrastructure.Contracts.Utilities
{
    public static class HtmlHelperExtentions
    {
        public static HtmlString CheckBoxList(this HtmlHelper htmlHelper, IEnumerable<SelectListItem> listOfValues)
        {
            var sb = new StringBuilder();
            if (listOfValues != null)
            {
                sb.Append("<table>");
                foreach (var item in listOfValues)
                {
                    sb.Append("<tr>");
                    var label = htmlHelper.Label(item.Value, HtmlEncoder.Default.Encode(item.Text));
                    var checkbox = htmlHelper.CheckBox(item.Text, new { id = item.Value }).ToString();
                    sb.AppendFormat("{0}{1}", "<td>" + checkbox + "</td>", "<td>" + label + "</td>");
                    sb.Append("</tr>");
                }
            }
            sb.Append("</table>");
            return new HtmlString(sb.ToString());
        }
    }
}

﻿using System;
using System.Security.Claims;
using System.Text.RegularExpressions;
namespace HPi.Pulsar.Infrastructure.Contracts.Utilities
{
    public static class Validator
    {
        #region Validate Null Check
        public static void ValidateStringNotNullWhiteSpace(string value, string parameterName)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentNullException(parameterName);
            }
        }
        public static void ValidateObjectNotNull<T>(T value, string parameterName)
        {
            if (value == null)
            {
                throw new ArgumentNullException(parameterName);
            }
        }
        public static void ValidateIntegerNotZero(int value, string parameterName)
        {
            if (value == default(int))
            {
                throw new ArgumentNullException(parameterName);
            }
        }
        public static void ValidateDoubleNotZero(double value, string parameterName)
        {
            if (value == default(double))
            {
                throw new ArgumentNullException(parameterName);
            }
        }
        public static void ValidateDoubleNotNullOrZero(double? value, string parameterName)
        {
            if (value.HasValue == false)
            {
                throw new ArgumentNullException(parameterName);
            }
            if (value.Value == default(double))
            {
                throw new ArgumentException("Value cannot be Zero.", parameterName);
            }
        }
        public static void ValidateDateNotDefaultValue(DateTime value, string parameterName)
        {
            if (value == DateTime.MinValue)
            {
                throw new ArgumentException("Valid Date is not assigned.", parameterName);
            }
        }
        #endregion
        #region Validate Regular Expression
        public static void ValidateEmailAddress(string value, string parameterName)
        {
            var emailValidate = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                                @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                                @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            if (!string.IsNullOrEmpty(value))
            {
                if (!Regex.IsMatch(value, emailValidate))
                {
                    throw new ArgumentException("Invalid email Address", parameterName);
                }
            }
            else
            {
                throw new ArgumentException("Value is empty or null.", parameterName);
            }
        }
        public static void ValidatePhoneNumber(string value, int maxValue, string parameterName)
        {
            var phoneValidate = @"^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$";
            if (value.Length <= maxValue)
            {
                if (!Regex.IsMatch(value, phoneValidate))
                {
                    throw new ArgumentException("Invalid phone number", parameterName);
                }
            }
            else
            {
                throw new ArgumentException("Value is empty or null.", parameterName);
            }
        }
        public static void ValidateEmailFormat(string value, string parameterName)
        {
            var regex = new Regex(@"^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$");
            if (!regex.IsMatch(value))
            {
                throw new ArgumentException("Invalid email Format", parameterName);
            }
        }
        public static void ValidatePasswordFormat(string value, string parameterName)
        {
            var regex = new Regex(@"^(?=[\S]*?[a-zA-Z])(?=[\S]*?[0-9])\S{8,40}$");
            if (!regex.IsMatch(value))
            {
                throw new ArgumentException("Invalid Password Format", parameterName);
            }
        }
        public static void ValidateUserNameFormat(string value, string parameterName)
        {
            var regex = new Regex(@"^[a-zA-Z](@|\w|\.){7,23}[0-9a-zA-Z]$");
            if (!regex.IsMatch(value))
            {
                throw new ArgumentException("Invalid Name Format", parameterName);
            }
        }
        public static void ValidateStringRegularExpression(string value, string regExpression, string parameterName)
        {
            if (!Regex.IsMatch(value, regExpression))
            {
                throw new ArgumentException("Value must match to the regular expression: " + regExpression + ".", parameterName);
            }
        }
        public static void ValidateZipCodeFormat(string value, string parameterName)
        {
            ValidateStringNotNullWhiteSpace(value, parameterName);
            Regex regex = new Regex(@"^([0-9]{5})$");
            if (!regex.IsMatch(value))
            {
                throw new ArgumentException("Invalid zipcode Format", parameterName);
            }
        }
        #endregion
        #region Validate Type Check
        public static void ValidateInteger(string value, string parameterName)
        {
            if (!string.IsNullOrEmpty(value))
            {
                int n;
                if (!int.TryParse(value, out n))
                {
                    throw new ArgumentException("Value is not a valid Integer.", parameterName);
                }
            }
            else
            {
                throw new ArgumentException("Value is empty or null.", parameterName);
            }
        }
        public static void ValidateDate(string value, string parameterName)
        {
            DateTime dateTime;
            ValidateStringNotNullWhiteSpace(value, parameterName);
            if (!DateTime.TryParse(value, out dateTime))
            {
                throw new ArgumentException("Value is not a valid Datetime.", parameterName);
            }
            if (dateTime == DateTime.MinValue)
            {
                throw new ArgumentException("Valid Date is not assigned.", parameterName);
            }
        }
        public static void ValidateDateBirth(DateTime value, string parameterName)
        {
            if (value.Date >= DateTime.Now.Date || value.Date < DateTime.Now.Date.AddYears(-110))
            {
                throw new ArgumentException("Invalid Date of birth.", parameterName);
            }
        }
        #endregion
        #region Validate Range expression
        public static void ValidateIntegerGreaterThanZero(int value, string parameterName)
        {
            if (value <= 0)
            {
                throw new ArgumentException("Value must be greater than zero.", parameterName);
            }
        }
        public static void ValidateDateIsNotFuture(DateTime value, string parameterName)
        {
            if (value.Date >= DateTime.Now.Date)
            {
                throw new ArgumentException("Value should not be greater or equal to today date.", parameterName);
            }
        }
        public static void ValidateMinMaxValue(double? value1, double? value2, double? value3, string parameterName)
        {
            if (!((value1 >= value2) && (value1 <= value3)))
            {
                throw new ArgumentException("Value must be in between the range" + value1 + ".", parameterName);
            }
        }
        public static void ValidateIntegerMaxValue(int value, int max, string parameterName)
        {
            if (value > max)
            {
                throw new ArgumentException("Value must not be greater than " + max + ".", parameterName);
            }
        }
        public static void ValidateDateIsFuture(DateTime value, string parameterName)
        {
            if (value.Date < DateTime.Now.Date)
            {
                throw new ArgumentException("Value must not be lesser than current date" + value + ".", parameterName);
            }
        }
        public static void ValidateIntegerMinRange(int value, int minValue, string parameterName)
        {
            if (value < minValue)
            {
                throw new ArgumentException("Value must be greater than " + minValue + ".", parameterName);
            }
        }
        #endregion
        #region Validate Value Length
        public static void ValidateIntegerMinLength(int value, int length, string parameterName)
        {
            if (value.ToString().Length < length)
            {
                throw new ArgumentException("Value must be less than " + length + ".", parameterName);
            }
        }
        public static void ValidateIntegerMaxLength(int value, int length, string parameterName)
        {
            if (value.ToString().Length > length)
            {
                throw new ArgumentException("Value must be greater than " + length + ".", parameterName);
            }
        }
        public static void ValidateStringMinLength(string value, int length, string parameterName)
        {
            if (value.Length < length)
            {
                throw new ArgumentException("Value must be less than " + length + ".", parameterName);
            }
        }
        public static void ValidateStringMaxLength(string value, int length, string parameterName)
        {
            if (value.Length > length)
            {
                throw new ArgumentException("Value must be greater than " + length + ".", parameterName);
            }
        }
        #endregion
        public static bool ValidateUserId(this Claim claim, out int userId)
        {
            userId = 0;
            if (string.IsNullOrWhiteSpace(claim?.Value))
            {
                return false;
            }
            if (!int.TryParse(claim.Value, out userId))
            {
                return false;
            }
            return userId != 0;
        }
    }
}

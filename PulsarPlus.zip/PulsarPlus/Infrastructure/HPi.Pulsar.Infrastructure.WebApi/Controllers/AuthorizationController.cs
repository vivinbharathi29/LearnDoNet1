﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Authorization;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.WebApi
{
    public class AuthorizationController : BaseApiController<IAuthorizationService>
    {
        public AuthorizationController(IApplicationServices applicationServices, IAuthorizationService manager)
            : base(applicationServices, manager)
        {
        }
        [HttpGet]
        [ProducesResponseType(typeof(List<string>), 200)]
        [ProducesResponseType(typeof(List<string>), 404)]
        [Route("api/Authorization/GetPermissions")]
        public async Task<IActionResult> GetPermissions()
        {
            List<string> permissions = await this.Manager.GetPermissionsAsync();
            if (permissions != null)
            {
                return this.Ok(permissions);
            }
            return this.NotFound();
        }
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> IsAuthorized(int userId, string permissionName)
        {
            bool isAuthorization = false;
            isAuthorization = await this.Manager.IsAuthorizedAsync(userId, permissionName);
            return this.Ok(isAuthorization);
        }
        [HttpGet]
        [ProducesResponseType(typeof(List<string>), 200)]
        [ProducesResponseType(typeof(List<string>), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetUserPermissions(int userId)
        {
            var userPermissions = await this.Manager.GetUserPermissionsAsync(userId);
            if (userPermissions != null)
            {
                return this.Ok(userPermissions);
            }
            return this.NotFound();
        }
    }
}

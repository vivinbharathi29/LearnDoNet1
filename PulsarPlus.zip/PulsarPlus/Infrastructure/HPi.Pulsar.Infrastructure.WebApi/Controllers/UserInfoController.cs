using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.WebApi.Controllers
{
    public class UserInfoController : BaseApiController<IUserInfoService>
    {
        public UserInfoController(IApplicationServices applicationServices, IUserInfoService manager) : base(applicationServices, manager)
        {
        }
        [HttpGet]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetUserByName(string name, string domain)
        {
            UserInfoModel apiResult = await this.Manager.GetUserByNameAsync(name);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [Route("api/UserInfo/GetUserById/{id}")]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        public async Task<IActionResult> GetUserById(int id)
        {
            UserInfoModel apiResult = await this.Manager.GetUserByIdAsync(id);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [Route("api/UserInfo/GetUserByEmail/{email}")]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        public async Task<IActionResult> GetUserByEmail(string email)
        {
            UserInfoModel apiResult = await this.Manager.GetUserByEmailAsync(email);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [Route("api/UserInfo/GetUserInfoByUserName")]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        public async Task<IActionResult> GetUserInfoByUserName(string userName, string domain, bool? isCacheRequired)
        {
            UserInfoModel apiResult = await this.Manager.GetUserInfoByUserNameAsync(userName, domain, isCacheRequired);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [Route("api/UserInfo/GetEmployeeImpersonateId/{ntName}/{domain}")]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        public async Task<IActionResult> GetEmployeeImpersonateId(string ntName, string domain)
        {
            UserInfoModel apiResult = await this.Manager.GetEmployeeImpersonateIdAsync(ntName, domain);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [Route("api/UserInfo/GetEmployeeByID/{impersonateId}")]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        public async Task<IActionResult> GetEmployeeByID(int impersonateId)
        {
            UserInfoModel apiResult = await this.Manager.GetEmployeeByIDAsync(impersonateId);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [Route("api/UserInfo/GetUserMenuRights/{userId}")]
        [ProducesResponseType(typeof(MenuUserInfoModel), 200)]
        [ProducesResponseType(typeof(MenuUserInfoModel), 404)]
        public async Task<IActionResult> GetUserMenuRights(int userId)
        {
            MenuUserInfoModel apiResult = await this.Manager.GetUserMenuRightsAsync(userId);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        #region ChangeImpersonationUser
        [HttpGet]
        [ProducesResponseType(typeof(UserInfoModel[]), 200)]
        [ProducesResponseType(typeof(UserInfoModel[]), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetImpersonationEmployees(int isImpersonate, string userNamePattern, string filter)
        {
            UserInfoModel[] apiResult = await this.Manager.GetImpersonationEmployeesAsync(isImpersonate, userNamePattern, filter);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> IsSupportAdmin(int employeeId)
        {
            bool isAdmin = false;
            isAdmin = await this.Manager.IsSupportAdminAsync(employeeId);
            return this.Ok(isAdmin);
        }
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> SaveImpersonationEmployee(int employeeId, int impersonateId)
        {
            bool status = await this.Manager.TrySaveImpersonationEmployeeAsync(employeeId, impersonateId);
            return this.Ok(status);
        }
        #endregion
        #region SwitchPM
        [HttpGet]
        [ProducesResponseType(typeof(UserInfoModel[]), 200)]
        [ProducesResponseType(typeof(UserInfoModel[]), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetSwitchPMEmployees(int sepmId, string userNamePattern)
        {
            UserInfoModel[] apiResult = await this.Manager.GetSwitchPMEmployeesAsync(sepmId, userNamePattern);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> SavePMImpersonationEmployee(int employeeId, int impersonateId, string ntName, string ntDomain)
        {
            bool status = await this.Manager.TrySavePMImpersonationEmployeeAsync(employeeId, impersonateId, ntName, ntDomain);
            return this.Ok(status);
        }
        #endregion
        #region ChangeSwitchPCUser
        [HttpGet]
        [ProducesResponseType(typeof(UserInfoModel[]), 200)]
        [ProducesResponseType(typeof(UserInfoModel[]), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetCmPcPHWebMarketingUsers(int switchType, string userNamePattern)
        {
            UserInfoModel[] apiResult = await this.Manager.GetCmPcPHWebMarketingUsersAsync(switchType, userNamePattern);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> SaveCmPcPHWebMarketingUser(int employeeId, int impersonateId, int switchType, string ntName, string ntDomain)
        {
            bool status = await this.Manager.TrySaveCmPcPHWebMarketingUserAsync(employeeId, impersonateId, switchType, ntName, ntDomain);
            return this.Ok(status);
        }
        #endregion
        #region Get Employee for Save Access
        [HttpGet]
        //[Route("api/UserInfo/GetEmployeesIsSysAdmin/{employeeID}/{isAdmin}/{ntName}/{domain}/{partnerID}")]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetEmployeesIsSysAdmin(int? employeeID, int isAdmin, string ntName, string domain, int? partnerID)
        {
            UserInfoModel apiResult = await this.Manager.GetEmployeesIsSysAdminAsync(employeeID, isAdmin, ntName, domain, partnerID);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [Route("api/UserInfo/GetEmployeesPMsActive/{typeID}")]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        public async Task<IActionResult> GetEmployeesPMsActive(int typeID)
        {
            UserInfoModel[] apiResult = await this.Manager.GetEmployeesPMsActiveAsync(typeID);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        //[Route("api/UserInfo/GetUserInRole/")]
        [ProducesResponseType(typeof(UserInfoModel), 200)]
        [ProducesResponseType(typeof(UserInfoModel), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetUserInRole(int? userId, int? productVersionId, string roleName)
        {
            int? apiResult = await this.Manager.GetUserInRoleAsync(userId, productVersionId, roleName);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        #endregion
        [HttpGet]
        [Route("api/UserInfo/UpdateDCRWorkflowReassign/{historyId}/{reassignId}")]
        [ProducesResponseType(typeof(bool?), 200)]
        [ProducesResponseType(typeof(bool?), 404)]
        public async Task<IActionResult> UpdateDCRWorkflowReassign(int historyId, int reassignId)
        {
            bool? apiResult = await this.Manager.TryUpdateDCRWorkflowReassignAsync(historyId, reassignId);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        [HttpGet]
        [Route("api/UserInfo/GetAllAccessoryPMs")]
        [ProducesResponseType(typeof(UserInfoModel[]), 200)]
        [ProducesResponseType(typeof(UserInfoModel[]), 404)]
        public async Task<IActionResult> GetAllAccessoryPMs()
        {
            UserInfoModel[] apiResult = await this.Manager.GetAllAccessoryPMsAsync();
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        #region ListFactoryEngineersAll
        [HttpGet]
        [Route("api/UserInfo/ListFactoryEngineersAll")]
        [ProducesResponseType(typeof(UserInfoModel[]), 200)]
        [ProducesResponseType(typeof(UserInfoModel[]), 404)]
        public async Task<IActionResult> ListFactoryEngineersAll()
        {
            UserInfoModel[] apiResult = await this.Manager.ListFactoryEngineersAllAsync();
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        #endregion ListFactoryEngineersAll
        #region GetEmployeesListforAddressBook
        [HttpGet]
        [Route("api/UserInfo/GetEmployeeList/{userNamePattern}")]
        [ProducesResponseType(typeof(UserInfoModel[]), 200)]
        [ProducesResponseType(typeof(UserInfoModel[]), 404)]
        public async Task<IActionResult> GetEmployeeList(string userNamePattern)
        {
            UserInfoModel[] apiResult = await this.Manager.GetEmployeeListAsync(userNamePattern);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        #endregion GetEmployeesListforAddressBook
        #region GetActionEmployee
        [HttpGet]
        [ProducesResponseType(typeof(UserInfoModel[]), 200)]
        [ProducesResponseType(typeof(UserInfoModel[]), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetActionEmployees(string userType, string userNamePattern, int currentUserId, int ownerId, int id)
        {
            UserInfoModel[] apiResult = await this.Manager.GetActionEmployeesAsync(userType, userNamePattern, currentUserId, ownerId, id);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        #endregion
        #region GetEngineeringCoorginators
        [HttpGet]
        [ProducesResponseType(typeof(UserInfoModel[]), 200)]
        [ProducesResponseType(typeof(UserInfoModel[]), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetEngineeringCoorginators()
        {
            UserInfoModel[] apiResult = await this.Manager.GetEngineeringCoorginatorsAsync();
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
        #endregion
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        public async Task<IActionResult> UpdateFavorites([FromBody]UserInfoModel userInfo)
        {
            bool apiResult = await this.Manager.TryUpdateFavoritesAsync(userInfo);
            return this.Ok(apiResult);
        }
        [HttpGet]
        [Route("api/UserInfo/UpdateDefaultProductTab")]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        public async Task<IActionResult> UpdateDefaultProductTab(int employeeId, string tab)
        {
            var apiResult = await this.Manager.TryUpdateDefaultProductTabAsync(employeeId, tab);
            return this.Ok(apiResult);
        }
    }
}

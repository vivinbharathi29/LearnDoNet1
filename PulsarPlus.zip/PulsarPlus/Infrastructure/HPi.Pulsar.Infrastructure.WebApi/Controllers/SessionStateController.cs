﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using HPi.Pulsar.Infrastructure.Contracts.SessionState;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.WebApi.Controllers
{
    public class SessionStateController : BaseApiController<ISessionStateService>
    {
        public SessionStateController(IApplicationServices applicationServices, ISessionStateService manager)
            : base(applicationServices, manager)
        {
        }
        #region Public Methods
        [HttpGet]
        [EncryptedActionParameters]
        public async Task Set(string sessionGUID, string key, string value, string itemType, bool useInMemory)
        {
            await Manager.SetValuesAsync(sessionGUID, key, value, itemType, useInMemory);
        }
        [HttpGet]
        [EncryptedActionParameters]
        public async Task<string> Get(string sessionGUID, string key, bool useInMemory)
        {
            string sessionvalue = await Manager.GetValuesAsync(sessionGUID, key, useInMemory);
            return sessionvalue;
        }
        #endregion
    }
}

﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Roles;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.WebApi.Controllers
{
    public class UserRoleController : BaseApiController<IUserRoleStore<ApplicationUser>>
    {
        public UserRoleController(IApplicationServices applicationServices, IUserRoleStore<ApplicationUser> manager)
            : base(applicationServices, manager)
        {
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/AddToRoleAsync/{roleName}/{cancellationToken}")]
        public async Task<IActionResult> AddToRoleAsync([FromBody]ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            await this.Manager.AddToRoleAsync(user, roleName, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(IList<string>), 200)]
        [ProducesResponseType(typeof(IList<string>), 404)]
        [Route("api/UserRole/GetRolesAsync/{cancellationToken}")]
        public async Task<IActionResult> GetRolesAsync([FromBody]ApplicationUser user, CancellationToken cancellationToken)
        {
            var roles = await Manager.GetRolesAsync(user, cancellationToken);
            if (roles != null)
            {
                return this.Ok(roles);
            }
            return this.NotFound();
        }
        [HttpGet]
        [ProducesResponseType(typeof(IList<ApplicationUser>), 200)]
        [ProducesResponseType(typeof(IList<ApplicationUser>), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken)
        {
            var userInfo = await Manager.GetUsersInRoleAsync(roleName, cancellationToken);
            if (userInfo != null)
            {
                return this.Ok(userInfo);
            }
            return this.NotFound();
        }
        [HttpPost]
        [ProducesResponseType(typeof(bool), 200)]
        [ProducesResponseType(typeof(bool), 404)]
        [Route("api/UserRole/IsInRoleAsync/{roleName}/{cancellationToken}")]
        public async Task<bool> IsInRoleAsync([FromBody]ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            return await Manager.IsInRoleAsync(user, roleName, cancellationToken);
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/RemoveFromRoleAsync/{roleName}/{cancellationToken}")]
        public async Task<IActionResult> RemoveFromRoleAsync([FromBody]ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            await Manager.RemoveFromRoleAsync(user, roleName, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/CreateAsync/{user}/{cancellationToken}")]
        public async Task<IActionResult> CreateAsync([FromBody]ApplicationUser user, CancellationToken cancellationToken)
        {
            await Manager.CreateAsync(user, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/DeleteAsync/{cancellationToken}")]
        public async Task<IActionResult> DeleteAsync([FromBody]ApplicationUser user, CancellationToken cancellationToken)
        {
            await Manager.DeleteAsync(user, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/FindByIdAsync/{cancellationToken}")]
        public async Task<IActionResult> FindByIdAsync([FromBody]string userId, CancellationToken cancellationToken)
        {
            await Manager.FindByIdAsync(userId, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/FindByNameAsync/{cancellationToken}")]
        public async Task<IActionResult> FindByNameAsync([FromBody]string normalizedUserName, CancellationToken cancellationToken)
        {
            await Manager.FindByNameAsync(normalizedUserName, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/GetNormalizedUserNameAsync/{cancellationToken}")]
        public async Task<IActionResult> GetNormalizedUserNameAsync([FromBody]ApplicationUser user, CancellationToken cancellationToken)
        {
            await Manager.GetNormalizedUserNameAsync(user, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/GetUserIdAsync/{cancellationToken}")]
        public async Task<IActionResult> GetUserIdAsync([FromBody]ApplicationUser user, CancellationToken cancellationToken)
        {
            await Manager.GetUserIdAsync(user, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/GetUserNameAsync/{cancellationToken}")]
        public async Task<IActionResult> GetUserNameAsync([FromBody]ApplicationUser user, CancellationToken cancellationToken)
        {
            await Manager.GetUserNameAsync(user, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/SetNormalizedUserNameAsync/{normalizedName}/{cancellationToken}")]
        public async Task<IActionResult> SetNormalizedUserNameAsync([FromBody]ApplicationUser user, string normalizedName, CancellationToken cancellationToken)
        {
            await Manager.SetNormalizedUserNameAsync(user, normalizedName, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/SetUserNameAsync/{userName}/{cancellationToken}")]
        public async Task<IActionResult> SetUserNameAsync([FromBody]ApplicationUser user, string userName, CancellationToken cancellationToken)
        {
            await Manager.SetUserNameAsync(user, userName, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationUser), 200)]
        [ProducesResponseType(typeof(ApplicationUser), 404)]
        [Route("api/UserRole/UpdateAsync/{userName}/{user}/{cancellationToken}")]
        public async Task<IActionResult> UpdateAsync([FromBody]ApplicationUser user, CancellationToken cancellationToken)
        {
            await Manager.UpdateAsync(user, cancellationToken);
            return this.Ok();
        }
    }
}

﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Logging;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.WebApi.Controllers
{
    public class LoggingController : BaseApiController<ILoggingService>
    {
        public LoggingController(IApplicationServices applicationServices, ILoggingService manager)
            : base(applicationServices, manager)
        {
        }
        [HttpPost]
        [Route("api/Logging/LogError/")]
        public async Task<int> LogError([FromBody]ErrorLogModel errorLogModel)
        {
            return await this.Manager.LogErrorAsync(errorLogModel);
        }
    }
}

﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.WebApi.Controllers
{
    public class CachingController : BaseApiController<ICacheService>
    {
        public CachingController(IApplicationServices applicationServices, ICacheService manager)
            : base(applicationServices, manager)
        {
        }
        #region Public Methods
        [HttpGet]
        [EncryptedActionParameters]
        public async Task<IActionResult> SetCache(string cacheKey, string value, int expiryTime, string itemType, bool useInMemory)
        {
            await Manager.SetCacheAsync(cacheKey, value, expiryTime, itemType, useInMemory);
            return this.Ok();
        }
        [HttpGet]
        [EncryptedActionParameters]
        public async Task<string> GetCache(string cacheKey, bool useInMemory)
        {
            string cachevalue = await Manager.GetCacheAsync(cacheKey, useInMemory);
            return cachevalue;
        }
        [HttpDelete]
        [Route("api/Caching/InvalidateCache/{cacheKey}/{useInMemory}")]
        public async Task InvalidateCache(string cacheKey, bool useInMemory)
        {
            await Manager.InvalidateCacheAsync(cacheKey, useInMemory);
        }
        #endregion
    }
}

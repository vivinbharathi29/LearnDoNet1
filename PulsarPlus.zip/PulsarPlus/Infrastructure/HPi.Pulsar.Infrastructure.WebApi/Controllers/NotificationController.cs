﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Notification;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.WebApi.Controllers
{
    public class NotificationController : BaseApiController<INotificationService>
    {
        public NotificationController(IApplicationServices applicationServices, INotificationService manager)
            : base(applicationServices, manager)
        {
        }
        [HttpPost]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(typeof(string), 404)]
        [Route("api/Notification/SendEmailViaEWS/")]
        public async Task<JsonResult> SendEmailViaEWS([FromBody]EmailTemplateModel emailTemplateModel)
        {
            bool result = await this.Manager.SendEmailViaMessageQueuedEmail(emailTemplateModel);
            return this.Json(result);
        }        
    }
}

﻿using System.Threading;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Roles;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.WebApi.Controllers
{
    public class RoleController : BaseApiController<IRoleStore<ApplicationRole>>
    {
        public RoleController(IApplicationServices applicationServices, IRoleStore<ApplicationRole> manager)
            : base(applicationServices, manager)
        {
        }
        [HttpPost]
        [ProducesResponseType(typeof(IdentityResult), 200)]
        [ProducesResponseType(typeof(IdentityResult), 404)]
        [Route("api/Role/CreateAsync/{cancellationToken}")]
        public async Task<IActionResult> CreateAsync([FromBody]ApplicationRole role, CancellationToken cancellationToken)
        {
            return this.Ok(await Manager.CreateAsync(role, cancellationToken));
        }
        [HttpPost]
        [ProducesResponseType(typeof(IdentityResult), 200)]
        [ProducesResponseType(typeof(IdentityResult), 404)]
        [Route("api/Role/UpdateAsync/{cancellationToken}")]
        public async Task<IActionResult> UpdateAsync([FromBody]ApplicationRole role, CancellationToken cancellationToken)
        {
            return this.Ok(await Manager.UpdateAsync(role, cancellationToken));
        }
        [HttpPost]
        [ProducesResponseType(typeof(IdentityResult), 200)]
        [ProducesResponseType(typeof(IdentityResult), 404)]
        [Route("api/Role/DeleteAsync/{cancellationToken}")]
        public async Task<IActionResult> DeleteAsync([FromBody]ApplicationRole role, CancellationToken cancellationToken)
        {
            return this.Ok(await Manager.DeleteAsync(role, cancellationToken));
        }
        [HttpGet]
        [ProducesResponseType(typeof(ApplicationRole), 200)]
        [ProducesResponseType(typeof(ApplicationRole), 404)]
        [EncryptedActionParameters]
        public async Task<IActionResult> FindByIdAsync(string roleId, CancellationToken cancellationToken)
        {
            var applicationRole = await Manager.FindByIdAsync(roleId, cancellationToken);
            if (applicationRole != null)
            {
                return this.Ok(applicationRole);
            }
            return this.NotFound();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationRole), 200)]
        [ProducesResponseType(typeof(ApplicationRole), 404)]
        [Route("api/Role/FindByNameAsync/{normalizedRoleName}/{cancellationToken}")]
        public async Task<IActionResult> FindByNameAsync([FromBody] string normalizedName, CancellationToken cancellationToken)
        {
            await Manager.FindByNameAsync(normalizedName, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationRole), 200)]
        [ProducesResponseType(typeof(ApplicationRole), 404)]
        [Route("api/Role/GetNormalizedRoleNameAsync/{role}/{cancellationToken}")]
        public async Task<IActionResult> GetNormalizedRoleNameAsync([FromBody]ApplicationRole role, CancellationToken cancellationToken)
        {
            await Manager.GetNormalizedRoleNameAsync(role, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationRole), 200)]
        [ProducesResponseType(typeof(ApplicationRole), 404)]
        [Route("api/Role/GetRoleIdAsync/{role}/{cancellationToken}")]
        public async Task<IActionResult> GetRoleIdAsync([FromBody]ApplicationRole role, CancellationToken cancellationToken)
        {
            await Manager.GetRoleIdAsync(role, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationRole), 200)]
        [ProducesResponseType(typeof(ApplicationRole), 404)]
        [Route("api/Role/GetRoleNameAsync/{role}/{cancellationToken}")]
        public async Task<IActionResult> GetRoleNameAsync([FromBody]ApplicationRole role, CancellationToken cancellationToken)
        {
            await Manager.GetRoleNameAsync(role, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationRole), 200)]
        [ProducesResponseType(typeof(ApplicationRole), 404)]
        [Route("api/Role/SetNormalizedRoleNameAsync/{normalizedName}/{cancellationToken}")]
        public async Task<IActionResult> SetNormalizedRoleNameAsync([FromBody]ApplicationRole role, string normalizedName, CancellationToken cancellationToken)
        {
            await Manager.SetNormalizedRoleNameAsync(role, normalizedName, cancellationToken);
            return this.Ok();
        }
        [HttpPost]
        [ProducesResponseType(typeof(ApplicationRole), 200)]
        [ProducesResponseType(typeof(ApplicationRole), 404)]
        [Route("api/Role/SetRoleNameAsync/{roleName}/{cancellationToken}")]
        public async Task<IActionResult> SetRoleNameAsync([FromBody]ApplicationRole role, string roleName, CancellationToken cancellationToken)
        {
            await Manager.SetRoleNameAsync(role, roleName, cancellationToken);
            return this.Ok();
        }
    }
}

﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Logging;
namespace HPi.Pulsar.Infrastructure.BusinessLayer
{
    public class LoggingManager : ILoggingService
    {
        public LoggingManager(ILoggingRepository repository)
        {
            this.Repository = repository;
        }
        private ILoggingRepository Repository { get; set; }
        public async Task<int> LogErrorAsync(ErrorLogModel errorLogModel)
        {
            return await this.Repository.LogErrorAsync(errorLogModel);
        }
    }
}

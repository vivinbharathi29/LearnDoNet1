using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
namespace HPi.Pulsar.Infrastructure.BusinessLayer
{
    public class UserInfoManager : IUserInfoService
    {
        public UserInfoManager(IUserInfoRepository userInfoRepository, ICacheService cacheService)
        {
            this.Repository = userInfoRepository;
            this.CacheService = cacheService;
        }
        private IUserInfoRepository Repository { get; set; }
        protected ICacheService CacheService { get; set; }
        public async Task<UserInfoModel> GetUserByNameAsync(string name)
        {
            string ntDomain = string.Empty;
            string ntUserName = string.Empty;
            if (name.Contains("\\"))
            {
                ntDomain = name.Split('\\')[0];
                ntUserName = name.Split('\\')[1];
            }
            return await this.Repository.GetUserByNameAsync(ntUserName, ntDomain);
        }
        public async Task<UserInfoModel> GetUserByIdAsync(int? id)
        {
            return await this.Repository.GetUserByIdAsync(id);
        }
        public async Task<UserInfoModel> GetUserByEmailAsync(string email)
        {
            return await this.Repository.GetUserByEmailAsync(email);
        }
        public async Task<UserInfoModel> GetUserInfoByUserNameAsync(string userName, string domain, bool? isCacheRequired)
        {
            UserInfoModel userInfo = new UserInfoModel();
            if (isCacheRequired == true)
            {
                string key = "userInfo_" + userName.ToUpper() + "_" + (domain == null ? "" : domain.ToUpper());
                int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
                userInfo = await this.CacheService.GetCacheAsync<UserInfoModel>(key, true);
                if (userInfo == null)
                {
                    userInfo = await this.Repository.GetUserInfoByUserNameAsync(userName, domain, isCacheRequired);
                    if (userInfo != null)
                    {
                        await this.CacheService.SetCacheAsync<UserInfoModel>(key, userInfo, expiryTime, userInfo.GetType().Name, true);
                    }
                }
            }
            else
            {
                userInfo = await this.Repository.GetUserInfoByUserNameAsync(userName, domain, isCacheRequired);
            }
            return userInfo;
        }
        public async Task<UserInfoModel> GetEmployeeImpersonateIdAsync(string ntName, string domain)
        {
            return await this.Repository.GetEmployeeImpersonateIdAsync(ntName, domain);
        }
        public async Task<UserInfoModel> GetEmployeeByIDAsync(int impersonateId)
        {
            return await this.Repository.GetEmployeeByIDAsync(impersonateId);
        }
        public async Task<MenuUserInfoModel> GetUserMenuRightsAsync(int userId)
        {
            return await this.Repository.GetUserMenuRightsAsync(userId);
        }
        #region ChangeImpersonationUser
        public async Task<UserInfoModel[]> GetImpersonationEmployeesAsync(int isImpersonate, string userNamePattern, string filter)
        {
            return await this.Repository.GetImpersonationEmployeesAsync(isImpersonate, userNamePattern, filter);
        }
        public async Task<bool> IsSupportAdminAsync(int employeeId)
        {
            var userInfo = await this.Repository.IsSupportAdminAsync(employeeId);
            if (userInfo != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public async Task<bool> TrySaveImpersonationEmployeeAsync(int employeeId, int impersonateId)
        {
            bool status = false;
            var employee = await this.GetUserByIdAsync(employeeId);
            status = await this.Repository.TrySaveImpersonationEmployeeAsync(employeeId, impersonateId);
            string key = "userInfo_" + employee.NtName.ToUpper() + "_" + employee.NtDomain.ToUpper();
            if (status == true)
            {
                await this.CacheService.InvalidateCacheAsync(key, true);
            }
            return status;
        }
        #endregion
        #region SwitchPM
        public async Task<UserInfoModel[]> GetSwitchPMEmployeesAsync(int sepmId, string userNamePattern)
        {
            return await this.Repository.GetSwitchPMEmployeesAsync(sepmId, userNamePattern);
        }
        public async Task<bool> TrySavePMImpersonationEmployeeAsync(int employeeId, int impersonateId, string ntName, string ntDomain)
        {
            bool status = false;
            status = await this.Repository.SavePMImpersonationEmployeeAsync(employeeId, impersonateId);
            string key = "userInfo_" + ntName.ToUpper() + "_" + ntDomain.ToUpper();
            if (status == true)
            {
                await this.CacheService.InvalidateCacheAsync(key, true);
            }
            return status;
        }
        #endregion
        #region ChangeSwitchPCUser
        public async Task<UserInfoModel[]> GetCmPcPHWebMarketingUsersAsync(int switchType, string userNamePattern)
        {
            return await this.Repository.GetCmPcPHWebMarketingUsersAsync(switchType, userNamePattern);
        }
        public async Task<bool> TrySaveCmPcPHWebMarketingUserAsync(int employeeId, int impersonateId, int switchType, string ntName, string ntDomain)
        {
            bool status = false;
            var employee = await this.GetUserByIdAsync(employeeId);
            status = await this.Repository.SaveCmPcPHWebMarketingUserAsync(employeeId, impersonateId, switchType);
            string key = "userInfo_" + ntName.ToUpper() + "_" + ntDomain.ToUpper();
            if (status == true)
            {
                await this.CacheService.InvalidateCacheAsync(key, true);
            }
            return status;
        }
        #endregion
        #region Get Employee for Save Access
        public async Task<UserInfoModel> GetEmployeesIsSysAdminAsync(int? employeeID, int isAdmin, string ntName, string domain, int? partnerID)
        {
            return await this.Repository.GetEmployeesIsSysAdminAsync(employeeID, isAdmin, ntName, domain, partnerID);
        }
        public async Task<UserInfoModel[]> GetEmployeesPMsActiveAsync(int typeID)
        {
            return await this.Repository.GetEmployeesPMsActiveAsync(typeID);
        }
        public async Task<int> GetUserInRoleAsync(int? userId, int? productVersionId, string roleName)
        {
            return await this.Repository.GetUserInRoleAsync(userId, productVersionId, roleName);
        }
        #endregion
        public async Task<bool> TryUpdateDCRWorkflowReassignAsync(int historyId, int reassignId)
        {
            return await this.Repository.TryUpdateDCRWorkflowReassignAsync(historyId, reassignId);
        }
        public async Task<UserInfoModel[]> GetAllAccessoryPMsAsync()
        {
            return await this.Repository.GetAllAccessoryPMsAsync();
        }
        #region ListFactoryEngineersAll
        public async Task<UserInfoModel[]> ListFactoryEngineersAllAsync()
        {
            return await this.Repository.ListFactoryEngineersAllAsync();
        }
        #endregion
        #region Get Employees List for Address Book
        public async Task<UserInfoModel[]> GetEmployeeListAsync(string userNamePattern)
        {
            return await this.Repository.GetEmployeeListAsync(userNamePattern);
        }
        #endregion
        #region GetActionEmployee
        public async Task<UserInfoModel[]> GetActionEmployeesAsync(string userType, string userNamePattern, int currentUserId, int ownerId, int id)
        {
            return await this.Repository.GetActionEmployeesAsync(userType, userNamePattern, currentUserId, ownerId, id);
        }
        #endregion
        public async Task<UserInfoModel[]> GetEngineeringCoorginatorsAsync()
        {
            return await this.Repository.GetEngineeringCoorginatorsAsync();
        }
        public async Task<bool> TryUpdateFavoritesAsync(UserInfoModel userInfo)
        {
            return await this.Repository.UpdateFavoritesAsync(userInfo);
        }
        public async Task<bool> TryUpdateDefaultProductTabAsync(int employeeId, string tab)
        {
            return await this.Repository.UpdateDefaultProductTabAsync(employeeId, tab);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.Notification;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;
using MimeKit;
namespace HPi.Pulsar.Infrastructure.BusinessLayer
{
    public class NotificationManager : INotificationService
    {
        public NotificationManager(INotificationRepository repository)
        {
            this.Repository = repository;
        }
        private INotificationRepository Repository { get; set; }
        public static IConfiguration Configuration { get; set; }
        public object MessageBox { get; private set; }

        #region SendEmailMessageQueuedEmail
        public async Task<bool> SendEmailViaMessageQueuedEmail(EmailTemplateModel emailTemplate)
        {
            var emailFrom = "";
            var emailTestRecipients = AppSettings.Get<string>("EmailConfiguration:TestEmailRecipients");
            var emailToRecipients = string.Empty;
            var emailSubject = string.Empty;
            var emailBody = string.Empty;
            var emailMessageType = Importance.Normal;
            var emailToCc = string.Empty;
            var emailToBcc = string.Empty;
            var result = string.Empty;
            int mailStatus = 0;
            var emailTemplateItem = emailTemplate.TemplateId != 0 ? await this.Repository.GetEmailTemplateAsync(emailTemplate.TemplateId) : null;
            if (emailTemplateItem != null)
            {
                emailTemplate.EmailModel.Body = emailTemplateItem.Body;
                emailTemplate.EmailModel.Subject = emailTemplateItem.Subject;
                emailTemplate.EmailModel.DSNOptions = emailTemplateItem.DSNOptions;
                foreach (var item in emailTemplate.DictionaryItems)
                {
                    emailTemplate.EmailModel.Body = emailTemplate.EmailModel.Body.Replace(item.Key, item.Value);
                    emailTemplate.EmailModel.Subject = emailTemplate.EmailModel.Subject.Replace(item.Key, item.Value);
                }
            }
            else
            {
                emailTemplate.EmailModel.Body = emailTemplate.EmailModel.Body;
                emailTemplate.EmailModel.Subject = emailTemplate.EmailModel.Subject;
            }
            if ((emailTemplate.EmailModel.EmailTo != null && emailTemplate.EmailModel.Body != null
                && emailTemplate.EmailModel.Subject != null) || emailTemplate.EmailModel.Attachments != null)
            {
                var applicationMode = AppSettings.Get<string>("ApplicationMode:Production");
                if (Convert.ToString(emailTemplate.EmailModel.EmailImportance) != string.Empty)
                {
                    emailMessageType = emailTemplate.EmailModel.EmailImportance == EmailImportanceEnum.High ? Importance.High : emailTemplate.EmailModel.EmailImportance == EmailImportanceEnum.Normal ? Importance.Normal : emailTemplate.EmailModel.EmailImportance == EmailImportanceEnum.Low ? Importance.Low : Importance.Normal;
                }
                if (!string.IsNullOrEmpty(emailTemplate.EmailModel.Body) && (emailTemplate.EmailModel.Body.IndexOf("confidential", StringComparison.CurrentCultureIgnoreCase) != -1))
                {
                    emailTemplate.EmailModel.Body = emailTemplate.EmailModel.Body + "<br><br><strong>HP Restricted</strong>";
                }
                if (applicationMode != "Production")
                {
                    //emailTestRecipients = emailTestRecipients;
                    emailFrom = emailTemplate.EmailModel.EmailFrom;
                    emailToRecipients = emailTemplate.EmailModel.EmailTo;
                    emailToCc = emailTemplate.EmailModel.EmailToCc;
                    emailToBcc = emailTemplate.EmailModel.EmailToBcc;
                    emailSubject = "[PLEASE IGNORE THIS EMAIL]" + emailTemplate.EmailModel.Subject;
                    emailBody = "TEST MAIL : PLEASE IGNORE<br><br>" + "Actual User Email List:<br><br>" + emailTemplate.EmailModel.EmailTo + emailTemplate.EmailModel.EmailToCc + emailTemplate.EmailModel.EmailToBcc + "<br><br>" + emailTemplate.EmailModel.Body;
                }
                else
                {
                    emailFrom = emailTemplate.EmailModel.EmailFrom;
                    emailToRecipients = emailTemplate.EmailModel.EmailTo;
                    emailToCc = emailTemplate.EmailModel.EmailToCc;
                    emailToBcc = emailTemplate.EmailModel.EmailToBcc;
                    emailSubject = emailTemplate.EmailModel.Subject;
                    emailBody = emailTemplate.EmailModel.Body;
                }
                mailStatus = await this.Repository.SendEmailAsync(emailFrom, emailToRecipients, emailToCc, emailToBcc, emailSubject, emailBody);
                //result = SendIt(emailFrom, emailToRecipients, emailTestRecipients, emailToCc, emailToBcc, emailSubject, emailBody, emailMessageType, emailTemplate.EmailModel.Attachments);
            }
            return mailStatus == 1 ? true : false;
        }

        #endregion SendEmailEWS
        private void PopulateAddress(InternetAddressList addressList, string emailIds)
        {
            string regEx = AppSettings.Get<string>("EmailConfiguration:RegexValidation");
            addressList.Clear();
            foreach (var address in emailIds.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
            {
                Regex regex = new Regex(regEx, RegexOptions.IgnoreCase);
                Match match = regex.Match(address);
                if (address.Trim() != "" && !address.Contains(",") && !address.Trim().Contains(" ") && match.Success)
                {
                    addressList.Add(new MailboxAddress(address.TrimStart().TrimEnd()));
                }
            }
        }

        #region SendEmailEWS
        public async System.Threading.Tasks.Task<string> SendEmailViaEWSAsync(EmailTemplateModel emailTemplate)
        {
            var emailFrom = "";
            var emailTestRecipients = AppSettings.Get<string>("EmailConfiguration:TestEmailRecipients");
            var emailToRecipients = string.Empty;
            var emailSubject = string.Empty;
            var emailBody = string.Empty;
            var emailMessageType = Importance.Normal;
            var emailToCc = string.Empty;
            var emailToBcc = string.Empty;
            var result = string.Empty;
            var emailTemplateItem = emailTemplate.TemplateId != 0 ? await this.Repository.GetEmailTemplateAsync(emailTemplate.TemplateId) : null;
            if (emailTemplateItem != null)
            {
                emailTemplate.EmailModel.Body = emailTemplateItem.Body;
                emailTemplate.EmailModel.Subject = emailTemplateItem.Subject;
                emailTemplate.EmailModel.DSNOptions = emailTemplateItem.DSNOptions;
                foreach (var item in emailTemplate.DictionaryItems)
                {
                    emailTemplate.EmailModel.Body = emailTemplate.EmailModel.Body.Replace(item.Key, item.Value);
                    emailTemplate.EmailModel.Subject = emailTemplate.EmailModel.Subject.Replace(item.Key, item.Value);
                }
            }
            else
            {
                emailTemplate.EmailModel.Body = emailTemplate.EmailModel.Body;
                emailTemplate.EmailModel.Subject = emailTemplate.EmailModel.Subject;
            }
            if ((emailTemplate.EmailModel.EmailTo != null && emailTemplate.EmailModel.Body != null
                && emailTemplate.EmailModel.Subject != null) || emailTemplate.EmailModel.Attachments != null)
            {
                var applicationMode = AppSettings.Get<string>("ApplicationMode:Production");
                if (Convert.ToString(emailTemplate.EmailModel.EmailImportance) != string.Empty)
                {
                    emailMessageType = emailTemplate.EmailModel.EmailImportance == EmailImportanceEnum.High ? Importance.High : emailTemplate.EmailModel.EmailImportance == EmailImportanceEnum.Normal ? Importance.Normal : emailTemplate.EmailModel.EmailImportance == EmailImportanceEnum.Low ? Importance.Low : Importance.Normal;
                }
                if (!string.IsNullOrEmpty(emailTemplate.EmailModel.Body) && (emailTemplate.EmailModel.Body.IndexOf("confidential", StringComparison.CurrentCultureIgnoreCase) != -1))
                {
                    emailTemplate.EmailModel.Body = emailTemplate.EmailModel.Body + "<br><br><strong>HP Restricted</strong>";
                }
                if (applicationMode != "Production")
                {
                    //emailTestRecipients = emailTestRecipients;
                    emailFrom = emailTemplate.EmailModel.EmailFrom;
                    emailToRecipients = emailTemplate.EmailModel.EmailTo;
                    emailToCc = emailTemplate.EmailModel.EmailToCc;
                    emailToBcc = emailTemplate.EmailModel.EmailToBcc;
                    emailSubject = "[PLEASE IGNORE THIS EMAIL]" + emailTemplate.EmailModel.Subject;
                    emailBody = "TEST MAIL : PLEASE IGNORE<br><br>" + "Actual User Email List:<br><br>" + emailTemplate.EmailModel.EmailTo + emailTemplate.EmailModel.EmailToCc + emailTemplate.EmailModel.EmailToBcc + "<br><br>" + emailTemplate.EmailModel.Body;
                }
                else
                {
                    emailFrom = emailTemplate.EmailModel.EmailFrom;
                    emailToRecipients = emailTemplate.EmailModel.EmailTo;
                    emailToCc = emailTemplate.EmailModel.EmailToCc;
                    emailToBcc = emailTemplate.EmailModel.EmailToBcc;
                    emailSubject = emailTemplate.EmailModel.Subject;
                    emailBody = emailTemplate.EmailModel.Body;
                }
                result = SendIt(emailFrom, emailToRecipients, emailTestRecipients, emailToCc, emailToBcc, emailSubject, emailBody, emailMessageType, emailTemplate.EmailModel.Attachments, emailTemplate.EmailModel.SecretKey, emailTemplate.EmailModel.Location, emailTemplate.EmailModel.StartDate, emailTemplate.EmailModel.EndDate, emailTemplate.EmailModel.MessageType);
            }
            return result;
        }
        private string SendIt(string emailFrom, string emailToRecipients, string emailTestRecipients, string emailToCc, string emailToBcc, string emailSubject, string emailBody, Microsoft.Exchange.WebServices.Data.Importance emailMesageType, List<string> emailAttachments, string SecretKey,string location,DateTime? startDate,DateTime? endDate,int messageType)
        {
            var result = string.Empty;
            string OnBehalfUser = "True";
            var pulsarEmailWebApi = AppSettings.Get<string>("EmailConfiguration:PulsarEmailWebAPI");
            using (var client = new HttpClient())
            using (var form = new MultipartFormDataContent())
            {
                client.DefaultRequestHeaders.Add("API_KEY", "dummy");
                form.Add(new StringContent(emailFrom), "From");
                form.Add(new StringContent(emailToRecipients), "To");
                form.Add(new StringContent(OnBehalfUser), "OnBehalfUser");                
                if (!string.IsNullOrWhiteSpace(SecretKey))
                {
                    form.Add(new StringContent(SecretKey), "SecretKey");
                }                       
                if (!string.IsNullOrWhiteSpace(location))
                {
                    form.Add(new StringContent(location), "Location");
                }
                form.Add(new StringContent(Convert.ToString(messageType)), "MessageType");
                form.Add(new StringContent(startDate.Value.ToString("MM.dd.yyyy HH:mm")), "StartDate");
                form.Add(new StringContent(endDate.Value.ToString("MM.dd.yyyy HH:mm")), "EndDate");
                if (!string.IsNullOrWhiteSpace(emailTestRecipients))
                {
                    form.Add(new StringContent(emailTestRecipients), "TestRecipient");
                }
                if (!string.IsNullOrWhiteSpace(emailToCc))
                {
                    form.Add(new StringContent(emailToCc), "Cc");
                }
                if (!string.IsNullOrWhiteSpace(emailToBcc))
                {
                    form.Add(new StringContent(emailToBcc), "Bcc");
                }
                form.Add(new StringContent(emailSubject), "Subject");
                form.Add(new StringContent(emailBody), "Body");
                if (emailAttachments != null && emailAttachments.Count() > 0)
                {
                    foreach (string filepath in emailAttachments)
                    {
                        var files = new ByteArrayContent(File.ReadAllBytes(filepath));
                        files.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
                        {
                            Name = "File",
                            FileName = Path.GetFileName(filepath)
                        };
                        form.Add(files);
                    }
                }                
                var response = client.PostAsync(pulsarEmailWebApi, form).Result;
                result = !response.IsSuccessStatusCode ? $"Error Code:{response.StatusCode}, Error Message:{response.RequestMessage}" : "Email has been sent successfully";
                return result;
            }
        }
        #endregion SendEmailEWS        
    }
}

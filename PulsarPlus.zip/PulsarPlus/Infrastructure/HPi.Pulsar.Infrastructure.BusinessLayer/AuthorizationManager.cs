﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Authorization;
namespace HPi.Pulsar.Infrastructure.BusinessLayer
{
    public class AuthorizationManager : IAuthorizationService
    {
        public AuthorizationManager(IAuthorizationRepository repository)
        {
            this.Repository = repository;
        }
        private IAuthorizationRepository Repository { get; set; }
        public async Task<bool> IsAuthorizedAsync(int userId, string permissionName)
        {
            var isAuthorization = default(bool);
            List<string> userPermission = await this.Repository.GetUserPermissionsAsync(userId);
            if (userPermission != null && userPermission.Count > 0)
            {
                isAuthorization = userPermission.FirstOrDefault(permission => permission.ToString().ToLower() == permissionName.ToLower()) != null ? true : false;
            }
            return isAuthorization;
        }
        public async Task<List<string>> GetPermissionsAsync()
        {
            var permissions = await this.Repository.GetPermissionsAsync();
            return permissions;
        }
        public async Task<List<string>> GetUserPermissionsAsync(int userId)
        {
            List<string> userPermission = await this.Repository.GetUserPermissionsAsync(userId);
            return userPermission;
        }
    }
}

﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Roles;
using Microsoft.AspNetCore.Identity;
namespace HPi.Pulsar.Infrastructure.BusinessLayer
{
    public class UserRoleManager : IUserRoleStore<ApplicationUser>
    {
        public UserRoleManager(IUserRoleStore<ApplicationUser> repository)
        {
            this.UserRoleRepository = repository;
        }
        public IUserRoleStore<ApplicationUser> UserRoleRepository { get; set; }
        #region UserRole
        public async Task AddToRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            await UserRoleRepository.AddToRoleAsync(user, roleName, cancellationToken);
        }
        public async Task<IList<string>> GetRolesAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            return await UserRoleRepository.GetRolesAsync(user, cancellationToken);
        }
        public async Task<IList<ApplicationUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken)
        {
            return await UserRoleRepository.GetUsersInRoleAsync(roleName, cancellationToken);
        }
        public async Task<bool> IsInRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            return await UserRoleRepository.IsInRoleAsync(user, roleName, cancellationToken);
        }
        public async Task RemoveFromRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            await UserRoleRepository.RemoveFromRoleAsync(user, roleName, cancellationToken);
        }
        #endregion
        #region UserStore
        public Task<IdentityResult> CreateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.CreateAsync(user, cancellationToken);
        }
        public Task<IdentityResult> DeleteAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.DeleteAsync(user, cancellationToken);
        }
        public Task<ApplicationUser> FindByIdAsync(string userId, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.FindByIdAsync(userId, cancellationToken);
        }
        public Task<ApplicationUser> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.FindByNameAsync(normalizedUserName, cancellationToken);
        }
        public Task<string> GetNormalizedUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.GetNormalizedUserNameAsync(user, cancellationToken);
        }
        public Task<string> GetUserIdAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.GetUserIdAsync(user, cancellationToken);
        }
        public Task<string> GetUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.GetUserNameAsync(user, cancellationToken);
        }
        public Task SetNormalizedUserNameAsync(ApplicationUser user, string normalizedName, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.SetNormalizedUserNameAsync(user, normalizedName, cancellationToken);
        }
        public Task SetUserNameAsync(ApplicationUser user, string userName, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.SetUserNameAsync(user, userName, cancellationToken);
        }
        public Task<IdentityResult> UpdateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            return this.UserRoleRepository.UpdateAsync(user, cancellationToken);
        }
        public void Dispose()
        {
        }
        #endregion
    }
}

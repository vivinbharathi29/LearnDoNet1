﻿using System;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.SessionState;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
namespace HPi.Pulsar.Infrastructure.BusinessLayer
{
    public class SessionStateManager : ISessionStateService
    {
        #region Private Variables
        private string sessionTimeOut = string.Empty;
        #endregion
        public SessionStateManager(ISessionStateRepository repository, IMemoryCache memoryCache)
        {
            this.StateServerRepository = repository;
            this.MemoryCache = memoryCache;
            this.sessionTimeOut = AppSettings.Get<string>("SessionTimeOut:InMinutes");
        }
        #region Public Properties
        public IConfigurationRoot Configuration { get; set; }
        #endregion
        #region Private Properties
        private IMemoryCache MemoryCache { get; set; }
        private ISessionStateRepository StateServerRepository { get; set; }
        #endregion
        #region Public Methods
        public async Task SetAsync<T>(string sessionGUID, string key, T value, string itemType)
        {
            await this.StateServerRepository.SetAsync(sessionGUID, key, JsonConvert.SerializeObject(value), itemType);
        }
        public async Task SetAsync<T>(string sessionGUID, string key, T value)
        {
            var itemType = value.GetType().Name;
            await this.StateServerRepository.SetAsync(sessionGUID, key, JsonConvert.SerializeObject(value), itemType);
        }
        public async Task SetAsync<T>(string sessionGUID, string key, T value, string itemType, bool useInMemory)
        {
            if (useInMemory)
            {
                var cacheKey = sessionGUID + key;
                this.MemoryCache.Set(cacheKey, JsonConvert.SerializeObject(value), new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(Convert.ToDouble(this.sessionTimeOut))));
            }
            else
            {
                await this.StateServerRepository.SetAsync(sessionGUID, key, JsonConvert.SerializeObject(value), itemType);
            }
        }
        public async Task<T> GetAsync<T>(string sessionGUID, string key)
        {
            var value = await this.StateServerRepository.GetAsync(sessionGUID, key);
            return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
        }
        public async Task<T> GetAsync<T>(string sessionGUID, string key, bool useInMemory)
        {
            var sessionValue = string.Empty;
            if (useInMemory)
            {
                var cacheKey = sessionGUID + key;
                sessionValue = this.MemoryCache.Get(cacheKey).ToString();
            }
            else
            {
                sessionValue = await this.StateServerRepository.GetAsync(sessionGUID, key);
            }
            return sessionValue == null ? default(T) : JsonConvert.DeserializeObject<T>(sessionValue);
        }
        public async Task SetValuesAsync(string sessionGUID, string key, string value, string itemType, bool useInMemory)
        {
            if (useInMemory)
            {
                var cacheKey = sessionGUID + key;
                this.MemoryCache.Set(cacheKey, value, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(Convert.ToDouble(this.sessionTimeOut))));
            }
            else
            {
                await this.StateServerRepository.SetAsync(sessionGUID, key, value, itemType);
            }
        }
        public async Task<string> GetValuesAsync(string sessionGUID, string key, bool useInMemory)
        {
            var sessionValue = string.Empty;
            if (useInMemory)
            {
                var cacheKey = sessionGUID + key;
                sessionValue = this.MemoryCache.Get(cacheKey).ToString();
            }
            else
            {
                sessionValue = await this.StateServerRepository.GetAsync(sessionGUID, key);
            }
            return sessionValue;
        }
        #endregion
    }
}

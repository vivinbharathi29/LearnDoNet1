﻿using System;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
namespace HPi.Pulsar.Infrastructure.BusinessLayer
{
    public class CacheManager : ICacheService
    {
        public CacheManager(ICacheRepository repository, IMemoryCache memoryCache)
        {
            this.CachingRepository = repository;
            this.MemoryCache = memoryCache;
        }
        #region Private Properties
        private IMemoryCache MemoryCache { get; set; }
        private ICacheRepository CachingRepository { get; set; }
        #endregion
        #region Public Methods
        public async Task SetCacheAsync<T>(string cacheKey, T value, int expiryTime, string itemType)
        {
            await this.CachingRepository.SetCacheAsync(cacheKey, JsonConvert.SerializeObject(value), expiryTime, itemType);
        }
        public async Task SetCacheAsync<T>(string cacheKey, T value, int expiryTime, string itemType, bool useInMemory)
        {
            if (useInMemory)
            {
                this.MemoryCache.Set(cacheKey, JsonConvert.SerializeObject(value), new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMilliseconds(expiryTime)));
            }
            else
            {
                await this.CachingRepository.SetCacheAsync(cacheKey, JsonConvert.SerializeObject(value), expiryTime, itemType);
            }
        }
        public async Task<T> GetCacheAsync<T>(string cacheKey)
        {
            var value = await this.CachingRepository.GetCacheAsync(cacheKey);
            return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
        }
        public async Task<T> GetCacheAsync<T>(string cacheKey, bool useInMemory)
        {
            string cacheItem = string.Empty;
            if (useInMemory)
            {
                cacheItem = this.MemoryCache.Get(cacheKey) as string;
            }
            else
            {
                cacheItem = await this.CachingRepository.GetCacheAsync(cacheKey);
            }
            return cacheItem == null ? default(T) : JsonConvert.DeserializeObject<T>(cacheItem);
        }
        public async Task InvalidateCacheAsync(string cacheKey)
        {
            await this.CachingRepository.InvalidateCacheAsync(cacheKey);
        }
        public async Task SetCacheAsync(string cacheKey, string value, int expiryTime, string itemType, bool useInMemory)
        {
            if (useInMemory)
            {
                this.MemoryCache.Set(cacheKey, value, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMilliseconds(expiryTime)));
            }
            else
            {
                await this.CachingRepository.SetCacheAsync(cacheKey, value, expiryTime, itemType);
            }
        }
        public async Task<string> GetCacheAsync(string cacheKey, bool useInMemory)
        {
            var cacheValue = string.Empty;
            if (useInMemory)
            {
                if (this.MemoryCache.Get(cacheKey) != null)
                {
                    cacheValue = this.MemoryCache.Get(cacheKey).ToString();
                }
            }
            else
            {
                cacheValue = await this.CachingRepository.GetCacheAsync(cacheKey);
            }
            return cacheValue;
        }
        public async Task InvalidateCacheAsync(string cacheKey, bool useInMemory)
        {
            if (useInMemory)
            {
                this.MemoryCache.Remove(cacheKey);
            }
            else
            {
                await this.CachingRepository.InvalidateCacheAsync(cacheKey);
            }
        }
        #endregion
    }
}

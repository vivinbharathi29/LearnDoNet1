﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using HPi.Pulsar.Infrastructure.Contracts.SessionState;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
namespace HPi.Pulsar.Infrastructure.Proxy
{
    public class StateServerProxy : BaseProxy, ISessionStateService
    {
        public StateServerProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }
        public async Task SetAsync<T>(string sessionGUID, string key, T value, string itemType)
        {
            var sessionValue = JsonConvert.SerializeObject(value);
            itemType = sessionValue.GetType().Name;
            bool useInMemory = false;
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("sessionGUID", (object)sessionGUID, sessionGUID.GetType()));
            dictParams.Add(Tuple.Create("key", (object)key, key.GetType()));
            dictParams.Add(Tuple.Create("value", (object)sessionValue, sessionValue.GetType()));
            dictParams.Add(Tuple.Create("itemType", (object)itemType, itemType.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/SessionState/Set" + apiQueryString;
            await this.GetResponse<T>(str);
        }
        public async Task SetAsync<T>(string sessionGUID, string key, T value)
        {
            var sessionValue = JsonConvert.SerializeObject(value);
            var itemType = value.GetType().Name;
            bool useInMemory = false;
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("sessionGUID", (object)sessionGUID, sessionGUID.GetType()));
            dictParams.Add(Tuple.Create("key", (object)key, key.GetType()));
            dictParams.Add(Tuple.Create("value", (object)sessionValue, sessionValue.GetType()));
            dictParams.Add(Tuple.Create("itemType", (object)itemType, itemType.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/SessionState/Set" + apiQueryString;
            await this.GetResponse<T>(str);
        }
        public async Task SetAsync<T>(string sessionGUID, string key, T value, string itemType, bool useInMemory)
        {
            var sessionValue = JsonConvert.SerializeObject(value);
            itemType = sessionValue.GetType().Name;
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("sessionGUID", (object)sessionGUID, sessionGUID.GetType()));
            dictParams.Add(Tuple.Create("key", (object)key, key.GetType()));
            dictParams.Add(Tuple.Create("value", (object)sessionValue, sessionValue.GetType()));
            dictParams.Add(Tuple.Create("itemType", (object)itemType, itemType.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/SessionState/Set" + apiQueryString;
            await this.GetResponse<T>(str);
        }
        public async Task<T> GetAsync<T>(string sessionGUID, string key)
        {
            bool useInMemory = false;
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("sessionGUID", (object)sessionGUID, sessionGUID.GetType()));
            dictParams.Add(Tuple.Create("key", (object)key, key.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/SessionState/Get" + apiQueryString;
            return await this.GetResponse<T>(str);
        }
        public async Task<T> GetAsync<T>(string sessionGUID, string key, bool useInMemory)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("sessionGUID", (object)sessionGUID, sessionGUID.GetType()));
            dictParams.Add(Tuple.Create("key", (object)key, key.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/SessionState/Get" + apiQueryString;
            return await this.GetResponse<T>(str);
        }
        public async Task SetValuesAsync(string sessionGUID, string key, string value, string itemType, bool useInMemory)
        {
            await Task.Run(() =>
            {
                throw new InvalidOperationException("Use the generic overload of this method");
            });
        }
        public async Task<string> GetValuesAsync(string sessionGUID, string key, bool useInMemory)
        {
            return await Task.Run(new Func<string>(() =>
            {
                throw new InvalidOperationException("Use the generic overload of this method");
            }));
        }
    }
}

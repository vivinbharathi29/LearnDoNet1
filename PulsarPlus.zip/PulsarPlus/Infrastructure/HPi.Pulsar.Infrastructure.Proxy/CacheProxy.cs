﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
namespace HPi.Pulsar.Infrastructure.Proxy
{
    public class CacheProxy : BaseProxy, ICacheService
    {
        public CacheProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }
        public async Task SetCacheAsync<T>(string cacheKey, T value, int expiryTime, string itemType)
        {
            var cacheValue = JsonConvert.SerializeObject(value);
            bool useInMemory = false;
            itemType = cacheValue.GetType().Name;
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("cacheKey", (object)cacheKey, cacheKey.GetType()));
            dictParams.Add(Tuple.Create("value", (object)cacheValue, cacheValue.GetType()));
            dictParams.Add(Tuple.Create("expiryTime", (object)expiryTime, expiryTime.GetType()));
            dictParams.Add(Tuple.Create("itemType", (object)itemType, itemType.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/Caching/SetCache" + apiQueryString;
            await this.GetResponse<T>(str);
        }
        public async Task SetCacheAsync<T>(string cacheKey, T value, int expiryTime, string itemType, bool useInMemory)
        {
            var cacheValue = JsonConvert.SerializeObject(value);
            itemType = cacheValue.GetType().Name;
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("cacheKey", (object)cacheKey, cacheKey.GetType()));
            dictParams.Add(Tuple.Create("value", (object)cacheValue, cacheValue.GetType()));
            dictParams.Add(Tuple.Create("expiryTime", (object)expiryTime, expiryTime.GetType()));
            dictParams.Add(Tuple.Create("itemType", (object)itemType, itemType.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/Caching/SetCache" + apiQueryString;
            await this.GetResponse<T>(str);
        }
        public async Task<T> GetCacheAsync<T>(string cacheKey)
        {
            bool useInMemory = false;
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("cacheKey", (object)cacheKey, cacheKey.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/Caching/GetCache" + apiQueryString;
            return await this.GetResponse<T>(str);
        }
        public async Task<T> GetCacheAsync<T>(string cacheKey, bool useInMemory)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("cacheKey", (object)cacheKey, cacheKey.GetType()));
            dictParams.Add(Tuple.Create("useInMemory", (object)useInMemory, useInMemory.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/Caching/GetCache" + apiQueryString;
            return await this.GetResponse<T>(str);
        }
        public async Task InvalidateCacheAsync(string cacheKey)
        {
            bool useInMemory = false;
            var str = "api/Caching/InvalidateCache/" + cacheKey + "/" + useInMemory;
            await this.Delete(str);
        }
        public async Task InvalidateCacheAsync(string cacheKey, bool useInMemory)
        {
            var str = "api/Caching/InvalidateCache/" + cacheKey + "/" + useInMemory;
            await this.Delete(str);
        }
        public async Task SetCacheAsync(string cacheKey, string value, int expiryTime, string itemType, bool useInMemory)
        {
            await Task.Run(() =>
            {
                throw new InvalidOperationException("Use the generic overload of this method");
            });
        }
        public async Task<string> GetCacheAsync(string cacheKey, bool useInMemory)
        {
            return await Task.Run(new Func<string>(() =>
            {
                throw new InvalidOperationException("Use the generic overload of this method");
            }));
        }
    }
}

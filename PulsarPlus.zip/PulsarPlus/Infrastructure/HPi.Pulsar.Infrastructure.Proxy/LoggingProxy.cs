﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Logging;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using Microsoft.Extensions.Options;
namespace HPi.Pulsar.Infrastructure.Proxy
{
    public class LoggingProxy : BaseProxy, ILoggingService
    {
        public LoggingProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }
        public async Task<int> LogErrorAsync(ErrorLogModel errorLogModel)
        {
            return await this.Post<int, ErrorLogModel>("api/Logging/LogError/", errorLogModel);
        }
    }
}

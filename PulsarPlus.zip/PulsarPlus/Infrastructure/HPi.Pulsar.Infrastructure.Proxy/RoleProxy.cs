﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using HPi.Pulsar.Infrastructure.Contracts.Roles;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
namespace HPi.Pulsar.Infrastructure.Proxy
{
    public class RoleProxy : BaseProxy, IRoleStore<ApplicationRole>
    {
        public RoleProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }
        public async Task<IdentityResult> CreateAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var apiPath = "api/Role/CreateAsync/" + cancellationToken;
            return await this.Post<IdentityResult, ApplicationRole>(apiPath, role);
        }
        public async Task<IdentityResult> UpdateAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var apiPath = "api/Role/UpdateAsync/" + cancellationToken;
            return await this.Post<IdentityResult, ApplicationRole>(apiPath, role);
        }
        public async Task<IdentityResult> DeleteAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var apiPath = "api/Role/DeleteAsync/" + cancellationToken;
            return await this.Post<IdentityResult, ApplicationRole>(apiPath, role);
        }
        public async Task<ApplicationRole> FindByIdAsync(string roleId, CancellationToken cancellationToken)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("roleId", (object)roleId, roleId.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var apiPath = "api/Role/FindByIdAsync" + apiQueryString;
            return await this.GetResponse<ApplicationRole>(apiPath);
        }
        #region Not Implemented Methods
        public void Dispose()
        {
        }
        public Task<ApplicationRole> FindByNameAsync(string normalizedRoleName, CancellationToken cancellationToken)
        {
            var apiPath = "api/Role/FindByNameAsync/" + normalizedRoleName + "/" + cancellationToken;
            return this.GetResponse<ApplicationRole>(apiPath);
        }
        public Task<string> GetNormalizedRoleNameAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/GetNormalizedRoleNameAsync/" + role + "/" + cancellationToken;
            return this.GetResponse<string>(apiPath);
        }
        public Task<string> GetRoleIdAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/GetRoleIdAsync/" + role + "/" + cancellationToken;
            return this.GetResponse<string>(apiPath);
        }
        public Task<string> GetRoleNameAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/GetRoleNameAsync/" + role + "/" + cancellationToken;
            return this.GetResponse<string>(apiPath);
        }
        public Task SetNormalizedRoleNameAsync(ApplicationRole role, string normalizedName, CancellationToken cancellationToken)
        {
            var apiPath = "api/Role/SetNormalizedRoleNameAsync/" + normalizedName + "/" + cancellationToken;
            return this.Post<ApplicationRole>(apiPath, role);
        }
        public Task SetRoleNameAsync(ApplicationRole role, string roleName, CancellationToken cancellationToken)
        {
            var apiPath = "api/Role/SetRoleNameAsync/" + roleName + "/" + cancellationToken;
            return this.Post<ApplicationRole>(apiPath, role);
        }
        #endregion
    }
}

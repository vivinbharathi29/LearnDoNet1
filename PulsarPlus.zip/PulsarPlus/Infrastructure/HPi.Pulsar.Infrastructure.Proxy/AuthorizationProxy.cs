﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Authorization;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using Microsoft.Extensions.Options;
namespace HPi.Pulsar.Infrastructure.Proxy
{
    public class AuthorizationProxy : BaseProxy, IAuthorizationService
    {
        public AuthorizationProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }
        public async Task<List<string>> GetPermissionsAsync()
        {
            string path = "api/Authorization/GetPermissions";
            var permissions = await this.GetResponse<List<string>>(path);
            return permissions.ToList();
        }
        public async Task<bool> IsAuthorizedAsync(int userId, string permissionName)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("userId", (object)userId, userId.GetType()));
            dictParams.Add(Tuple.Create("permissionName", (object)permissionName, permissionName.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            string path = "api/Authorization/IsAuthorized" + apiQueryString;
            bool isAuthorization = await this.GetResponse<bool>(path);
            return isAuthorization;
        }
        public async Task<List<string>> GetUserPermissionsAsync(int userId)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("userId", (object)userId, userId.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            string path = "api/Authorization/GetUserPermissions" + apiQueryString;
            var userPermissions = await this.GetResponse<List<string>>(path);
            return userPermissions;
        }
    }
}

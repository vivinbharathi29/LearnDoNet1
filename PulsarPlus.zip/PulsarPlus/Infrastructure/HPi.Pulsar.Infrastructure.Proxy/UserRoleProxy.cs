﻿namespace HPi.Pulsar.Infrastructure.Proxy
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using HPi.Pulsar.Infrastructure.BaseClass;
    using HPi.Pulsar.Infrastructure.Contracts.Models;
    using HPi.Pulsar.Infrastructure.Contracts.Roles;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.Extensions.Options;
    public class UserRoleProxy : BaseProxy, IUserRoleStore<ApplicationUser>
    {
        public UserRoleProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }
        #region UserRole
        public async Task AddToRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/AddToRoleAsync/" + roleName + "/" + cancellationToken;
            await this.Post<ApplicationUser>(apiPath, user);
        }
        public async Task<IList<string>> GetRolesAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/GetRolesAsync/" + cancellationToken;
            return await this.Post<IList<string>, ApplicationUser>(apiPath, user);
        }
        public async Task<IList<ApplicationUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("roleName", (object)roleName, roleName.GetType()));
            dictParams.Add(Tuple.Create("cancellationToken", (object)cancellationToken, cancellationToken.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var apiPath = "api/UserRole/GetUsersInRoleAsync" + apiQueryString;
            return await this.GetResponse<IList<ApplicationUser>>(apiPath);
        }
        public async Task<bool> IsInRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/IsInRoleAsync/" + roleName + "/" + cancellationToken;
            return await this.Post<bool, ApplicationUser>(apiPath, user);
        }
        public async Task RemoveFromRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/RemoveFromRoleAsync/" + roleName + "/" + cancellationToken;
            await this.Post<ApplicationUser>(apiPath, user);
        }
        #endregion
        #region UserStore
        public Task<IdentityResult> CreateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/CreateAsync/" + cancellationToken;
            return this.Post<IdentityResult, ApplicationUser>(apiPath, user);
        }
        public Task<IdentityResult> DeleteAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/DeleteAsync/" + cancellationToken;
            return this.Post<IdentityResult, ApplicationUser>(apiPath, user);
        }
        public Task<ApplicationUser> FindByIdAsync(string userId, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/FindByIdAsync/" + cancellationToken;
            return this.Post<ApplicationUser, string>(apiPath, userId);
        }
        public Task<ApplicationUser> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/FindByNameAsync/" + cancellationToken;
            return this.Post<ApplicationUser, string>(apiPath, normalizedUserName);
        }
        public Task<string> GetNormalizedUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/GetNormalizedUserNameAsync/" + cancellationToken;
            return this.Post<string, ApplicationUser>(apiPath, user);
        }
        public Task<string> GetUserIdAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/GetUserIdAsync/" + cancellationToken;
            return this.Post<string, ApplicationUser>(apiPath, user);
        }
        public Task<string> GetUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/GetUserNameAsync/" + cancellationToken;
            return this.Post<string, ApplicationUser>(apiPath, user);
        }
        public Task SetNormalizedUserNameAsync(ApplicationUser user, string normalizedName, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/SetNormalizedUserNameAsync/" + normalizedName + "/" + cancellationToken;
            return this.Post<string, ApplicationUser>(apiPath, user);
        }
        public Task SetUserNameAsync(ApplicationUser user, string userName, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/SetUserNameAsync/" + userName + "/" + cancellationToken;
            return this.Post<string, ApplicationUser>(apiPath, user);
        }
        public Task<IdentityResult> UpdateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            var apiPath = "api/UserRole/UpdateAsync/" + user + "/" + cancellationToken;
            return this.Post<IdentityResult>(apiPath);
        }
        public void Dispose()
        {
        }
        #endregion
    }
}

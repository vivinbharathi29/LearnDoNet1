using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using Microsoft.Extensions.Options;
namespace HPi.Pulsar.Infrastructure.Proxy
{
    public class UserInfoProxy : BaseProxy, IUserInfoService
    {
        public UserInfoProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }
        public async Task<UserInfoModel> GetUserByNameAsync(string name)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("name", (object)name, name.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var str = "api/UserInfo/GetUserByName" + apiQueryString;
            return await this.GetResponse<UserInfoModel>(str);
        }
        public async Task<UserInfoModel> GetUserByIdAsync(int? id)
        {
            var url = "api/UserInfo/GetUserById/" + id;
            return await this.GetResponse<UserInfoModel>(url);
        }
        public async Task<UserInfoModel> GetUserByEmailAsync(string email)
        {
            var url = "api/UserInfo/GetUserByEmail/" + email;
            return await this.GetResponse<UserInfoModel>(url);
        }
        public async Task<UserInfoModel> GetUserInfoByUserNameAsync(string userName, string domain, bool? isCacheRequired = true)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            if (userName != null)
            {
                dictParams.Add(Tuple.Create("userName", (object)userName, userName.GetType()));
            }
            if (domain != null)
            {
                dictParams.Add(Tuple.Create("domain", (object)domain, domain.GetType()));
            }
            dictParams.Add(Tuple.Create("isCacheRequired", (object)isCacheRequired, domain.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/GetUserInfoByUserName" + apiQueryString;
            return await this.GetResponse<UserInfoModel>(url);
        }
        public async Task<UserInfoModel> GetEmployeeImpersonateIdAsync(string ntName, string domain)
        {
            var url = "api/UserInfo/GetEmployeeImpersonateId/" + ntName + "/" + domain;
            return await this.GetResponse<UserInfoModel>(url);
        }
        public async Task<UserInfoModel> GetEmployeeByIDAsync(int impersonateId)
        {
            var url = "api/UserInfo/GetEmployeeByID/" + impersonateId;
            return await this.GetResponse<UserInfoModel>(url);
        }
        public async Task<MenuUserInfoModel> GetUserMenuRightsAsync(int userId)
        {
            var url = "api/UserInfo/GetUserMenuRights/" + userId;
            return await this.GetResponse<MenuUserInfoModel>(url);
        }
        #region ChangeImpersonationUser
        public async Task<UserInfoModel[]> GetImpersonationEmployeesAsync(int isImpersonate, string userNamePattern = "", string filter = "")
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("isImpersonate", (object)isImpersonate, isImpersonate.GetType()));
            if (!string.IsNullOrEmpty(userNamePattern))
            {
                dictParams.Add(Tuple.Create("userNamePattern", (object)userNamePattern, userNamePattern.GetType()));
            }
            if (!string.IsNullOrEmpty(filter))
            {
                dictParams.Add(Tuple.Create("filter", (object)filter, filter.GetType()));
            }
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/GetImpersonationEmployees" + apiQueryString;
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        public async Task<bool> IsSupportAdminAsync(int employeeId)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("employeeId", (object)employeeId, employeeId.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/IsSupportAdmin" + apiQueryString;
            return await this.GetResponse<bool>(url);
        }
        public async Task<bool> TrySaveImpersonationEmployeeAsync(int employeeId, int impersonateId)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("employeeId", (object)employeeId, employeeId.GetType()));
            dictParams.Add(Tuple.Create("impersonateId", (object)impersonateId, impersonateId.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/SaveImpersonationEmployee" + apiQueryString;
            return await this.GetResponse<bool>(url);
        }
        #endregion
        #region SwitchPM
        public async Task<UserInfoModel[]> GetSwitchPMEmployeesAsync(int sepmId, string userNamePattern = "")
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("sepmId", (object)sepmId, sepmId.GetType()));
            if (!string.IsNullOrEmpty(userNamePattern))
            {
                dictParams.Add(Tuple.Create("userNamePattern", (object)userNamePattern, userNamePattern.GetType()));
            }
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/GetSwitchPMEmployees" + apiQueryString;
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        public async Task<bool> TrySavePMImpersonationEmployeeAsync(int employeeId, int impersonateId, string ntName, string ntDomain)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("employeeId", (object)employeeId, employeeId.GetType()));
            dictParams.Add(Tuple.Create("impersonateId", (object)impersonateId, impersonateId.GetType()));
            dictParams.Add(Tuple.Create("ntName", (object)ntName, ntName.GetType()));
            dictParams.Add(Tuple.Create("ntDomain", (object)ntDomain, ntDomain.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/SavePMImpersonationEmployee" + apiQueryString;
            return await this.GetResponse<bool>(url);
        }
        #endregion
        #region ChangeSwitchPCUser
        public async Task<UserInfoModel[]> GetCmPcPHWebMarketingUsersAsync(int switchType, string userNamePattern = "")
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("switchType", (object)switchType, switchType.GetType()));
            if (!string.IsNullOrEmpty(userNamePattern))
            {
                dictParams.Add(Tuple.Create("userNamePattern", (object)userNamePattern, userNamePattern.GetType()));
            }
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/GetCmPcPHWebMarketingUsers" + apiQueryString;
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        public async Task<bool> TrySaveCmPcPHWebMarketingUserAsync(int employeeId, int impersonateId, int switchType, string ntName, string ntDomain)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("employeeId", (object)employeeId, employeeId.GetType()));
            dictParams.Add(Tuple.Create("impersonateId", (object)impersonateId, impersonateId.GetType()));
            dictParams.Add(Tuple.Create("switchType", (object)switchType, switchType.GetType()));
            dictParams.Add(Tuple.Create("ntName", (object)ntName, ntName.GetType()));
            dictParams.Add(Tuple.Create("ntDomain", (object)ntDomain, ntDomain.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/SaveCmPcPHWebMarketingUser" + apiQueryString;
            return await this.GetResponse<bool>(url);
        }
        #endregion
        #region Get Employee for Save Access
        public async Task<UserInfoModel> GetEmployeesIsSysAdminAsync(int? employeeID, int isAdmin, string ntName, string domain, int? partnerID)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("employeeID", (object)employeeID, employeeID.GetType()));
            dictParams.Add(Tuple.Create("isAdmin", (object)isAdmin, isAdmin.GetType()));
            if (!string.IsNullOrEmpty(ntName))
            {
                dictParams.Add(Tuple.Create("ntName", (object)ntName, ntName.GetType()));
            }
            if (!string.IsNullOrEmpty(domain))
            {
                dictParams.Add(Tuple.Create("domain", (object)domain, domain.GetType()));
            }
            if (partnerID != null)
            {
                dictParams.Add(Tuple.Create("partnerID", (object)partnerID, partnerID.GetType()));
            }
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/GetEmployeesIsSysAdmin" + apiQueryString;
            return await this.GetResponse<UserInfoModel>(url);
        }
        public async Task<UserInfoModel[]> GetEmployeesPMsActiveAsync(int typeID)
        {
            var url = "api/UserInfo/GetEmployeesPMsActive/" + typeID;
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        public async Task<int> GetUserInRoleAsync(int? userId, int? productVersionId, string roleName)
        {
            //var url = "api/UserInfo/GetUserInRole/" + userId + "/" + productVersionId + "/" + roleName;
            //return await this.GetResponse<int>(url);
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            if (userId != null)
            {
                dictParams.Add(Tuple.Create("userId", (object)userId, userId.GetType()));
            }
            if (productVersionId != null)
            {
                dictParams.Add(Tuple.Create("productVersionId", (object)productVersionId, productVersionId.GetType()));
            }
            if (!string.IsNullOrEmpty(roleName))
            {
                dictParams.Add(Tuple.Create("roleName", (object)roleName, roleName.GetType()));
            }
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/GetUserInRole" + apiQueryString;
            return await this.GetResponse<int>(url);
        }
        #endregion
        public async Task<bool> TryUpdateDCRWorkflowReassignAsync(int historyId, int reassignId)
        {
            var url = "api/UserInfo/UpdateDCRWorkflowReassign/" + historyId + "/" + reassignId;
            return await this.GetResponse<bool>(url);
        }
        public async Task<UserInfoModel[]> GetAllAccessoryPMsAsync()
        {
            var url = "api/UserInfo/GetAllAccessoryPMs";
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        #region ListFactoryEngineersAll
        public async Task<UserInfoModel[]> ListFactoryEngineersAllAsync()
        {
            var url = "api/UserInfo/ListFactoryEngineersAll";
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        #endregion ListFactoryEngineersAll
        public async Task<UserInfoModel[]> GetEmployeeListAsync(string userNamePattern)
        {
            var url = "api/UserInfo/GetEmployeeList" + "/" + userNamePattern;
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        public async Task<UserInfoModel[]> GetActionEmployeesAsync(string userType, string userNamePattern, int currentUserId, int ownerId, int id)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("userType", (object)userType, userType.GetType()));
            if (!string.IsNullOrEmpty(userNamePattern))
            {
                dictParams.Add(Tuple.Create("userNamePattern", (object)userNamePattern, userNamePattern.GetType()));
            }
            dictParams.Add(Tuple.Create("currentUserId", (object)currentUserId, currentUserId.GetType()));
            dictParams.Add(Tuple.Create("ownerId", (object)ownerId, ownerId.GetType()));
            dictParams.Add(Tuple.Create("id", (object)id, id.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/GetActionEmployees" + apiQueryString;
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        public async Task<UserInfoModel[]> GetEngineeringCoorginatorsAsync()
        {
            var url = "api/UserInfo/GetEngineeringCoorginators";
            return await this.GetResponse<UserInfoModel[]>(url);
        }
        public async Task<bool> TryUpdateFavoritesAsync(UserInfoModel userInfo)
        {
            var url = "api/UserInfo/UpdateFavorites/";
            return await this.Post<bool, UserInfoModel>(url, userInfo);
        }
        public async Task<bool> TryUpdateDefaultProductTabAsync(int employeeId, string tab)
        {
            List<Tuple<string, object, Type>> dictParams = new List<Tuple<string, object, Type>>();
            dictParams.Add(Tuple.Create("employeeId", (object)employeeId, employeeId.GetType()));
            dictParams.Add(Tuple.Create("tab", (object)tab, tab.GetType()));
            var apiQueryString = await GetQueryString(dictParams);
            var url = "api/UserInfo/UpdateDefaultProductTab" + apiQueryString;
            return await this.GetResponse<bool>(url);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationExceptions;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using HPi.Pulsar.Infrastructure.Contracts.Security;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public abstract class BaseProxy
    {
        private JsonSerializerSettings jsonSerializerSettings;
        private Uri HttpClientBaseAddress { get; set; }
        protected JsonSerializerSettings JsonSerializerSettings
        {
            get
            {
                return this.jsonSerializerSettings ?? (this.jsonSerializerSettings = new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
            }
        }
        protected async Task<T> GetResponse<T>(string requestUri)
        {
            return await this.GetResponse<T>(requestUri, 0);
        }
        protected async Task<T> GetResponse<T>(string requestUri, int timeOut)
        {
            using (var client = new HttpClient())
            {
                //// If Request Time out is not set in config file, the default value of 100 seconds is set 
                //// (Refer https://msdn.microsoft.com/en-us/library/system.net.http.httpclient.timeout%28v=vs.110%29.aspx)                
                var webApiRequestTimeout = 1000;
                if (timeOut > 0)
                {
                    webApiRequestTimeout = timeOut;
                }
                client.Timeout = new TimeSpan(0, 0, webApiRequestTimeout);
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string encryptedUrl = GetEncryptedUrl(requestUri);
                var response = await client.GetAsync(encryptedUrl);
                if (response.IsSuccessStatusCode)
                {
                    try
                    {
                        return JsonConvert.DeserializeObject<T>(response.Content.ReadAsStringAsync().Result);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return default(T);
                }
                throw this.GetAPIException(response, requestUri);
            }
        }
        protected async Task GetResponse(string requestUri)
        {
            int timeOut = 0;
            using (var client = new HttpClient())
            {
                //// If Request Time out is not set in config file, the default value of 100 seconds is set 
                //// (Refer https://msdn.microsoft.com/en-us/library/system.net.http.httpclient.timeout%28v=vs.110%29.aspx)                
                var webApiRequestTimeout = 1000;
                if (timeOut > 0)
                {
                    webApiRequestTimeout = timeOut;
                }
                client.Timeout = new TimeSpan(0, 0, webApiRequestTimeout);
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string encryptedUrl = GetEncryptedUrl(requestUri);
                var response = await client.GetAsync(encryptedUrl);
                if (!response.IsSuccessStatusCode)
                {
                    throw this.GetAPIException(response, requestUri);
                }
            }
        }
        protected async Task<T> Post<T>(string requestUri, T parameter) where T : class
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = JsonConvert.SerializeObject(parameter, this.JsonSerializerSettings);
                var response =
                    await client.PostAsync(requestUri, new StringContent(content, Encoding.UTF8, "application/json"));
                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<T>(response.Content.ReadAsStringAsync().Result);
                }
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return default(T);
                }
                throw this.GetAPIException(response, requestUri);
            }
        }
        protected async Task<T> Post<T>(string requestUri) where T : class
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = JsonConvert.SerializeObject(this.JsonSerializerSettings);
                var response =
                    await client.PostAsync(requestUri, new StringContent(content, Encoding.UTF8, "application/json"));
                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<T>(response.Content.ReadAsStringAsync().Result);
                }
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return default(T);
                }
                throw this.GetAPIException(response, requestUri);
            }
        }
        protected async Task<TOutput> Post<TOutput, TInput>(string requestUri, TInput parameter) where TInput : class
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = JsonConvert.SerializeObject(parameter, this.JsonSerializerSettings);
                var response = await client.PostAsync(requestUri, new StringContent(content, Encoding.UTF8, "application/json"));
                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<TOutput>(response.Content.ReadAsStringAsync().Result);
                }
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return default(TOutput);
                }
                throw this.GetAPIException(response, requestUri);
            }
        }
        protected async Task<T> Put<T>(string requestUri, T parameter) where T : class
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = JsonConvert.SerializeObject(parameter, this.JsonSerializerSettings);
                var response =
                    await client.PutAsync(requestUri, new StringContent(content, Encoding.UTF8, "application/json"));
                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<T>(response.Content.ReadAsStringAsync().Result);
                }
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return default(T);
                }
                throw this.GetAPIException(response, requestUri);
            }
        }
        protected async Task<TOutput> Put<TOutput, TInput>(string requestUri, TInput parameter) where TInput : class
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var content = JsonConvert.SerializeObject(parameter, this.JsonSerializerSettings);
                var response =
                    await client.PutAsync(requestUri, new StringContent(content, Encoding.UTF8, "application/json"));
                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<TOutput>(response.Content.ReadAsStringAsync().Result);
                }
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return default(TOutput);
                }
                throw this.GetAPIException(response, requestUri);
            }
        }
        protected async Task<T> Delete<T>(string requestUri)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await client.DeleteAsync(requestUri);
                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<T>(response.Content.ReadAsStringAsync().Result);
                }
                throw this.GetAPIException(response, requestUri);
            }
        }
        protected async Task Delete(string requestUri)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = this.HttpClientBaseAddress;
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await client.DeleteAsync(requestUri);
                if (!response.IsSuccessStatusCode)
                {
                    throw this.GetAPIException(response, requestUri);
                }
            }
        }
        private Exception GetAPIException(HttpResponseMessage response, string requestUri)
        {
            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                WebApiExceptionResponseModel webApiResponse = JsonConvert.DeserializeObject<WebApiExceptionResponseModel>(response.Content.ReadAsStringAsync().Result);
                string[] validExceptions =
                    {
                    "HPi.Pulsar.Infrastruture.Contracts.Exception.PulsarBusinessException",
                    "System.ArgumentNullException",
                    "System.ArgumentException"
                    };
                if (validExceptions.Contains(webApiResponse.ExceptionType))
                {
                    return Activator.CreateInstance(Type.GetType(webApiResponse.ExceptionType)) as Exception;
                }
                else
                {
                    return new ServiceCallFailedException(requestUri);
                }
            }
            else
            {
                return new ServiceCallFailedException(requestUri);
            }
        }
        private string GetEncryptedUrl(string requestUri)
        {
            if (AppSettings.Get<bool>("Encryption:EnableEncryption") == true)
            {
                if (requestUri.Contains("?"))
                {
                    if (!string.IsNullOrEmpty(requestUri.Split('?')[1]))
                    {
                        var keybytes = Encoding.UTF8.GetBytes(AppSettings.Get<string>("Encryption:EncryptionKey"));
                        requestUri = requestUri.Split('?')[0] + "?q=" + AESEncryption.Encrypt(requestUri.Split('?')[1].ToString(), keybytes);
                    }
                }
            }
            return requestUri;
        }
        public async Task<string> GetQueryString(List<Tuple<string, object, Type>> parameterList)
        {
            string querystring = string.Empty;
            if (parameterList != null)
            {
                if (parameterList.Count > 0)
                {
                    querystring = await Task.Run(() =>
                    {
                        foreach (Tuple<string, object, Type> parameter in parameterList)
                        {
                            if (AppSettings.Get<bool>("Encryption:EnableEncryption") == true)
                            {
                                querystring += parameter.Item1 + "#" + parameter.Item3.FullName + "=" + parameter.Item2 + "&";
                            }
                            else
                            {
                                querystring += parameter.Item1 + "=" + parameter.Item2 + "&";
                            }
                        }
                        querystring = "?" + querystring.TrimEnd('&');
                        return querystring;
                    });
                }
            }
            return querystring;
        }
        public BaseProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection)
        {
            var key = this.GetType().Namespace;
            var serviceUrl = serviceBaseURLCollection.Value.ServiceBaseURLs.Where(x => x.ServiceName.Contains(key)).Select(x => x.ServiceURL).ToArray().FirstOrDefault();
            this.HttpClientBaseAddress = new Uri(serviceUrl);
            if (this.HttpClientBaseAddress == null)
            {
                throw new ArgumentNullException(key);
            }
        }
    }
}

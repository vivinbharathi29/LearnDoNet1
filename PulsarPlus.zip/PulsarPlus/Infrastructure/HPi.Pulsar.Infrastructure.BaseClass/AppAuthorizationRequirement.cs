﻿using Microsoft.AspNetCore.Authorization;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class AppAuthorizationRequirement : IAuthorizationRequirement
    {
        public AppAuthorizationRequirement(string permission)
        {
            this.Permission = permission;
        }
        public string Permission { get; set; }
    }
}

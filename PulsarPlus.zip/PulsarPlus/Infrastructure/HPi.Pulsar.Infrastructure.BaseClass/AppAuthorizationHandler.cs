﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.SessionState;
using Microsoft.AspNetCore.Authorization;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class AppAuthorizationHandler : AuthorizationHandler<AppAuthorizationRequirement>
    {
        private readonly HPi.Pulsar.Infrastructure.Contracts.Authorization.IAuthorizationService authorizationService;
        public AppAuthorizationHandler(IApplicationServices applicationService, HPi.Pulsar.Infrastructure.Contracts.Authorization.IAuthorizationService authorizationService)
        {
            if (authorizationService == null)
            {
                throw new ArgumentNullException(nameof(authorizationService));
            }
            this.authorizationService = authorizationService;
            this.ApplicationServices = applicationService;
        }
        #region Public Properties
        public IApplicationServices ApplicationServices { get; set; }
        #endregion
        #region Private Variables
        private const string AppCookieName = "PulsarSession";
        #endregion
        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, AppAuthorizationRequirement requirement)
        {
            var mvcContext = context.Resource as Microsoft.AspNetCore.Mvc.Filters.AuthorizationFilterContext;
            var hasPermission = default(bool);
            List<string> userPermissions = null;
            string userId = mvcContext.HttpContext.User.Identity.Name;
            int Uid = 10;
            var sessionKey = SessionKey.UserPermissions;
            var sessionCookieValue = mvcContext.HttpContext.Request.Cookies[AppCookieName];
            if (userId.Contains("\\"))
            {
                string[] userIds = userId.Split('\\');
                userId = userIds[0].ToString();
            }
            if (userId != null)
            {
                userPermissions = (List<string>)await this.ApplicationServices.SessionState.GetAsync<List<string>>(sessionCookieValue, sessionKey, false);
                if (userPermissions != null)
                {
                    hasPermission = userPermissions.Contains(requirement.Permission);
                }
                else
                {
                    userPermissions = await this.authorizationService.GetUserPermissionsAsync(Uid);
                    await this.ApplicationServices.SessionState.SetAsync<List<string>>(sessionCookieValue, sessionKey, userPermissions);
                    hasPermission = userPermissions.Contains(requirement.Permission);
                }
                if (hasPermission)
                {
                    context.Succeed(requirement);
                }
                else
                {
                    context.Fail();
                }
            }
        }
    }
}

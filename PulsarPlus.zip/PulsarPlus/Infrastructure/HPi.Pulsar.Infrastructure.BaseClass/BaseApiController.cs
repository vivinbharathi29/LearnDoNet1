﻿using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class BaseApiController<T> : Controller
    {
        protected BaseApiController(IApplicationServices applicationServices, T manager)
        {
            this.ApplicationServices = applicationServices;
            this.Manager = manager;
        }
        protected IApplicationServices ApplicationServices { get; private set; }
        protected T Manager { get; private set; }
    }
}

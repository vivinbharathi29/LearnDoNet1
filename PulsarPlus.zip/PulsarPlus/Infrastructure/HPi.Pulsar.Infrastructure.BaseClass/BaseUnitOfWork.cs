﻿using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class BaseUnitOfWork : BaseService
    {
        public BaseUnitOfWork(IApplicationServices applicationServices) : base(applicationServices)
        {
        }
    }
}

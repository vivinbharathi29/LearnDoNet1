﻿using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Authorization;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using HPi.Pulsar.Infrastructure.Contracts.Logging;
using HPi.Pulsar.Infrastructure.Contracts.Notification;
using HPi.Pulsar.Infrastructure.Contracts.SessionState;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
namespace HPi.Pulsar.Infrastructure.Contracts.BaseClass
{
    public class ApplicationServices : IApplicationServices
    {
        public ApplicationServices(IExceptionHandlingService exceptionHandling, ILoggingService logging, ISessionStateService stateServerService, ICacheService cachingService, IApplicationProperties applicationproperties, IAuthorizationService authorizationService, INotificationService notification, IUserInfoService userInformation)
        {
            this.ExceptionHandling = exceptionHandling;
            this.SessionState = stateServerService;
            this.Cache = cachingService;
            this.Properties = applicationproperties;
            this.Logging = logging;
            this.Authorization = authorizationService;
            this.Notification = notification;
            this.UserInformation = userInformation;
        }
        public IExceptionHandlingService ExceptionHandling { get; set; }
        public IApplicationProperties Properties { get; set; }
        public ILoggingService Logging { get; set; }
        public ISessionStateService SessionState { get; set; }
        public ICacheService Cache { get; set; }
        public IAuthorizationService Authorization { get; set; }
        public INotificationService Notification { get; set; }
        public IUserInfoService UserInformation { get; set; }
    }
}

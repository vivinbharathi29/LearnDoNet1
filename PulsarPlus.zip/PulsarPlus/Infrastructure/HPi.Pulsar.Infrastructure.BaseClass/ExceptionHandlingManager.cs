﻿using System;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using HPi.Pulsar.Infrastructure.Contracts.Logging;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class ExceptionHandlingManager : IExceptionHandlingService
    {
        public ExceptionHandlingManager(ILoggingService service)
        {
            this.loggingService = service;
        }
        private ILoggingService loggingService;
        public async Task HandleExceptionAsync(Exception exception)
        {
            await this.HandleExceptionAsync(exception, false);
        }
        public async Task HandleExceptionAsync(Exception exception, bool throwException)
        {
            await this.loggingService.LogErrorAsync(ErrorLogModel.Create(exception, "PulsarPlus", string.Empty, "", string.Empty));
            if (throwException)
            {
                throw exception;
            }
        }
        public async Task HandleExceptionAsync(Exception exception, IErrorContext context)
        {
            await this.loggingService.LogErrorAsync(ErrorLogModel.Create(exception, context.ApplicationName, context.ApplicationVersion, context.UserID, context.IPAddress));           
        }       
    }
}

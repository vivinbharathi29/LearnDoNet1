﻿using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class ApplicationProperties : IApplicationProperties
    {
        public ApplicationProperties(IOptions<IErrorContext> baseparamvalue, IConfiguration configuration)
        {
            this.baseparameter = baseparamvalue.Value;
            this.Name = this.baseparameter.ApplicationName;
            this.Version = this.baseparameter.ApplicationVersion;
            this.ConnectionString = configuration.GetSection("ConnectionStrings").GetSection("PulsarDatabase").Value;
            this.Environment = configuration.GetSection("Environment").GetSection("Development").Value;
        }
        public IErrorContext baseparameter { get; }
        public string EventSourceName { get; set; }
        public string Name { get; set; }
        public string Version { get; set; }
        public string ConnectionString { get; set; }
        public string Environment { get; set; }
    }
}

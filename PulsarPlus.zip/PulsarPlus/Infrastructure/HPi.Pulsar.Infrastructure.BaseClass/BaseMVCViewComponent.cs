﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class BaseMVCViewComponent<T> : ViewComponent
    {
        #region Private Variables
        private const string AppCookieName = "PulsarSession";
        #endregion
        protected BaseMVCViewComponent(IApplicationServices applicationService, T unitOfWork, IConfiguration configuration)
        {
            this.ApplicationService = applicationService;
            this.UnitOfWork = unitOfWork;
            this.ApplicationMode = configuration.GetSection("ApplicationMode").GetSection("AppMode").Value;
        }
        #region Protected Properties
        protected IApplicationServices ApplicationService { get; private set; }
        protected T UnitOfWork { get; private set; }
        public string ApplicationMode { get; set; }
        #endregion
        #region Protected Method
        protected string GetSessionGuid()
        {
            string sessionGuid = string.Empty;
            string sessionCookie = HttpContext.Request.Cookies[AppCookieName];
            if (sessionCookie != null)
            {
                sessionGuid = sessionCookie.ToString();
            }
            //else
            //{
            //    // Creates a new Session GUID
            //    sessionGuid = Guid.NewGuid().ToString().Replace("-", string.Empty);
            //    HttpContext.Response.Cookies.Append(AppCookieName, sessionGuid);
            //}
            return sessionGuid;
        }
        #endregion
        #region SessionState
        protected async Task SetSession<T1>(string key, T1 value, bool useInMemory)
        {
            var sessionGuid = this.GetSessionGuid();
            string itemType = value.GetType().Name;
            await this.ApplicationService.SessionState.SetAsync<T1>(sessionGuid, key, value, itemType, useInMemory);
        }
        protected async Task<T1> GetSession<T1>(string key)
        {
            var sessionGuid = this.GetSessionGuid();
            T1 value = await this.ApplicationService.SessionState.GetAsync<T1>(sessionGuid, key);
            return value;
        }
        #endregion
        #region Cache
        protected async Task SetCache<T1>(string cacheKey, T1 value, int expiryTime, bool useInMemory)
        {
            string itemType = value.GetType().Name;
            await this.ApplicationService.Cache.SetCacheAsync<T1>(cacheKey, value, expiryTime, itemType, useInMemory);
        }
        protected async Task<T1> GetCache<T1>(string cacheKey)
        {
            T1 value = await this.ApplicationService.Cache.GetCacheAsync<T1>(cacheKey);
            return value;
        }
        protected async Task InvalidateCache(string cacheKey)
        {
            await this.ApplicationService.Cache.InvalidateCacheAsync(cacheKey);
        }
        #endregion
    }
}

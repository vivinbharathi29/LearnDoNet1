﻿using System;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using Microsoft​.AspNetCore​.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class WebMVCExceptionHandler : IExceptionHandler
    {
        public Task HandleAsync(HttpContext context)
        {
            return Task.Run(() =>
            {
                var feature = context.Features.Get<IExceptionHandlerFeature>();
                Exception exception = feature.Error;
                if (exception != null)
                {
                    string remoteIP = context.Connection.LocalIpAddress.ToString();
                    this.ExceptionContext.IPAddress = remoteIP;
                    this.ExceptionContext.UserID = context.User.Identity.Name.ToString();
                    if (exception.Message.Contains("Userid is 0"))
                    {
                        string loginpage = "http://" + context.Request.Host.Value + "/Pulsar/user/loginfailed";
                        if (context.Request.Host.Value.ToLower().Contains("prp"))
                        {
                            loginpage = "https://" + context.Request.Host.Value + "/Pulsar/user/loginfailed";
                        }
                        context.Response.Redirect(loginpage);
                    }
                    else
                    {
                        this.applicationServices.ExceptionHandling.HandleExceptionAsync(exception, this.ExceptionContext);
                        context.Response.Redirect("/Home/Error");
                    }
                }
            });
        }
        private IErrorContext ExceptionContext { get; }
        private IApplicationServices applicationServices;
        public WebMVCExceptionHandler(IApplicationServices applicationServices, IOptions<IErrorContext> baseparamvalue)
        {
            this.applicationServices = applicationServices;
            ExceptionContext = baseparamvalue.Value;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Enumerators;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class BaseRepository
    {
        public BaseRepository(IApplicationProperties applicationProperties)
        {
            this.ApplicationProperties = applicationProperties;
        }
        protected IApplicationProperties ApplicationProperties { get; set; }
        protected object CastNullToDBNull(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return DBNull.Value;
            }
            return value;
        }
        #region Connection
        public string AppConnectionString
        {
            get
            {
                return this.ApplicationProperties.ConnectionString;
            }
        }
        #endregion
        #region prepare Command
        private void AttachParameters(SqlCommand command, IEnumerable<SqlParameter> commandParameters)
        {
            if (command == null)
            {
                throw new ArgumentNullException("command");
            }
            if (commandParameters == null)
            {
                return;
            }
            foreach (var p in commandParameters.Where(p => p != null))
            {
                // Check for derived output value with no value assigned
                if ((p.Direction == ParameterDirection.InputOutput ||
                     p.Direction == ParameterDirection.Input) &&
                    (p.Value == null))
                {
                    p.Value = DBNull.Value;
                }
                command.Parameters.Add(p);
            }
        }
        private async Task<bool> PrepareCommand(SqlCommand command, SqlConnection connection, SqlTransaction transaction, CommandType commandType, string commandText, IEnumerable<SqlParameter> commandParameters)
        {
            if (command == null)
            {
                throw new ArgumentNullException("command");
            }
            if (string.IsNullOrEmpty(commandText))
            {
                throw new ArgumentNullException("commandText");
            }
            var mustCloseConnection = false;
            //// If the provided connection is not open, we will open it
            if (connection.State != ConnectionState.Open)
            {
                mustCloseConnection = true;
                await connection.OpenAsync().ConfigureAwait(false);
            }
            // Associate the connection with the command
            command.Connection = connection;
            // Set the command text (stored procedure name or SQL statement)
            command.CommandText = commandText;
            // If we were provided a transaction, assign it
            if (transaction != null)
            {
                if (transaction.Connection == null)
                {
                    throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
                }
                command.Transaction = transaction;
            }
            // Set the command type
            command.CommandType = commandType;
            command.CommandTimeout = 0;
            // Attach the command parameters if they are provided
            if (commandParameters != null)
            {
                this.AttachParameters(command, commandParameters);
            }
            return mustCloseConnection;
        }
        #endregion
        #region ExecuteNonQuery
        public async Task<int> ExecuteNonQuery(string storedprocedureName, params SqlParameter[] commandParameters)
        {
            return await this.ExecuteNonQuery(this.AppConnectionString, storedprocedureName, commandParameters);
        }
        public async Task<int> ExecuteNonQuery(string storedprocedureName)
        {
            return await this.ExecuteNonQuery(this.AppConnectionString, storedprocedureName);
        }
        public async Task<int> ExecuteNonQuery(string connectionString, string storedprocedureName, params SqlParameter[] commandParameters)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            if (string.IsNullOrEmpty(storedprocedureName))
            {
                throw new ArgumentNullException("storedprocedureName");
            }
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync().ConfigureAwait(false);
                //// Call the overload that takes a connection in place of the connection string
                return await this.ExecuteNonQuery(connection, CommandType.StoredProcedure, storedprocedureName, commandParameters).ConfigureAwait(false);
            }
        }
        public async Task<int> ExecuteNonQuery(SqlTransaction transaction, string storedprocedureName, params SqlParameter[] commandParameters)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }
            if (string.IsNullOrEmpty(storedprocedureName))
            {
                throw new ArgumentNullException("storedprocedureName");
            }
            // Create a command and prepare it for execution
            var cmd = new SqlCommand();
            await this.PrepareCommand(cmd, transaction.Connection, transaction, CommandType.StoredProcedure, storedprocedureName, commandParameters).ConfigureAwait(false);
            // Finally, execute the command
            var retval = await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
            // Detach the SqlParameters from the command object, so they can be used again
            cmd.Parameters.Clear();
            return retval;
        }
        public async Task<int> ExecuteNonQuery(SqlTransaction transaction, string storedprocedureName)
        {
            return await this.ExecuteNonQuery(transaction, CommandType.StoredProcedure, storedprocedureName);
        }
        private async Task<int> ExecuteNonQuery(SqlConnection connection, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }
            // Create a command and prepare it for execution
            var cmd = new SqlCommand();
            var mustCloseConnection = await this.PrepareCommand(cmd, connection, null, commandType, commandText, commandParameters).ConfigureAwait(false);
            // Finally, execute the command
            var retval = await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
            // Detach the SqlParameters from the command object, so they can be used again
            cmd.Parameters.Clear();
            if (mustCloseConnection)
            {
                connection.Close();
            }
            return retval;
        }
        public Task<int> ExecuteNonQuery(string connectionString, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return this.ExecuteNonQuery(connectionString, commandType, commandText, null);
        }
        public async Task<int> ExecuteNonQuery(string connectionString, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            // Create & open a SqlConnection, and dispose of it after we are done
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync().ConfigureAwait(false);
                //// Call the overload that takes a connection in place of the connection string
                return await this.ExecuteNonQuery(connection, commandType, commandText, commandParameters).ConfigureAwait(false);
            }
        }
        private Task<int> ExecuteNonQuery(SqlTransaction transaction, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return this.ExecuteNonQuery(transaction, commandType, commandText, null);
        }
        private async Task<int> ExecuteNonQuery(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }
            // Create a command and prepare it for execution
            var cmd = new SqlCommand();
            await this.PrepareCommand(cmd, transaction.Connection, transaction, commandType, commandText, commandParameters).ConfigureAwait(false);
            // Finally, execute the command
            var retval = await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
            // Detach the SqlParameters from the command object, so they can be used again
            cmd.Parameters.Clear();
            return retval;
        }
        #endregion ExecuteNonQueryAsync
        #region ExecuteReader
        private enum SqlConnectionOwnership
        {
            /// <summary>Connection is owned and managed by Helper</summary>            
            Internal,
            /// <summary>Connection is owned and managed by the caller</summary>            
            External
        }
        public async Task<SqlDataReader> ExecuteReader(string storedprocedureName, params SqlParameter[] commandParameters)
        {
            return await this.ExecuteReader(this.AppConnectionString, storedprocedureName, commandParameters);
        }
        public async Task<SqlDataReader> ExecuteReader(string storedprocedureName)
        {
            return await this.ExecuteReader(this.AppConnectionString, storedprocedureName);
        }
        public async Task<SqlDataReader> ExecuteReader(string connectionString, string storedprocedureName, params SqlParameter[] commandParameters)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            if (string.IsNullOrEmpty(storedprocedureName))
            {
                throw new ArgumentNullException("storedprocedureName");
            }
            ////using (var connection = new SqlConnection(connectionString))
            {
                var connection = new SqlConnection(connectionString);
                await connection.OpenAsync().ConfigureAwait(false);
                //// Call the overload that takes a connection in place of the connection string
                return await this.ExecuteReader(connection, CommandType.StoredProcedure, storedprocedureName, commandParameters).ConfigureAwait(false);
            }
        }
        public async Task<SqlDataReader> ExecuteReader(string connectionString, string storedprocedureName)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            if (string.IsNullOrEmpty(storedprocedureName))
            {
                throw new ArgumentNullException("storedprocedureName");
            }
            ////using (var connection = new SqlConnection(connectionString))
            {
                var connection = new SqlConnection(connectionString);
                await connection.OpenAsync().ConfigureAwait(false);
                //// Call the overload that takes a connection in place of the connection string
                return await this.ExecuteReader(connection, CommandType.StoredProcedure, storedprocedureName, null).ConfigureAwait(false);
            }
        }
        public Task<SqlDataReader> ExecuteReader(SqlTransaction transaction, string storedprocedureName, params SqlParameter[] commandParameters)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }
            if (string.IsNullOrEmpty(storedprocedureName))
            {
                throw new ArgumentNullException("storedprocedureName");
            }
            return this.ExecuteReader(transaction, CommandType.StoredProcedure, storedprocedureName, commandParameters);
        }
        public async Task<SqlDataReader> ExecuteReader(SqlTransaction transaction, string storedprocedureName)
        {
            return await this.ExecuteReader(transaction, CommandType.StoredProcedure, storedprocedureName);
        }
        public Task<SqlDataReader> ExecuteReader(string connectionString, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return this.ExecuteReader(connectionString, commandType, commandText, null);
        }
        private async Task<SqlDataReader> ExecuteReader(SqlConnection connection, SqlTransaction transaction, CommandType commandType, string commandText, IEnumerable<SqlParameter> commandParameters, SqlConnectionOwnership connectionOwnership)
        {
            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }
            var mustCloseConnection = false;
            //// Create a command and prepare it for execution
            var cmd = new SqlCommand();
            try
            {
                mustCloseConnection = await this.PrepareCommand(cmd, connection, transaction, commandType, commandText, commandParameters).ConfigureAwait(false);
                // Create a reader
                SqlDataReader dataReader;
                cmd.CommandTimeout = 0;
                // Call ExecuteReader with the appropriate CommandBehavior
                if (connectionOwnership == SqlConnectionOwnership.External)
                {
                    dataReader = await cmd.ExecuteReaderAsync().ConfigureAwait(false);
                }
                else
                {
                    dataReader = await cmd.ExecuteReaderAsync(CommandBehavior.CloseConnection).ConfigureAwait(false);
                }
                // Detach the SqlParameters from the command object, so they can be used again.
                // HACK: There is a problem here, the output parameter values are fletched 
                // when the reader is closed, so if the parameters are detached from the command
                // then the SqlReader can´t set its values. 
                // When this happen, the parameters can´t be used again in other command.
                var canClear = true;
                foreach (SqlParameter commandParameter in cmd.Parameters)
                {
                    if (commandParameter.Direction != ParameterDirection.Input)
                    {
                        canClear = false;
                    }
                }
                if (canClear)
                {
                    cmd.Parameters.Clear();
                }
                return dataReader;
            }
            catch
            {
                if (mustCloseConnection)
                {
                    connection.Close();
                }
                throw;
            }
        }
        private async Task<SqlDataReader> ExecuteReader(string connectionString, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(connectionString);
                await connection.OpenAsync().ConfigureAwait(false);
                // Call the private overload that takes an internally owned connection in place of the connection string
                return await this.ExecuteReader(connection, null, commandType, commandText, commandParameters, SqlConnectionOwnership.Internal).ConfigureAwait(false);
            }
            catch
            {
                // If we fail to return the SqlDatReader, we need to close the connection ourselves
                if (connection != null)
                {
                    connection.Close();
                }
                throw;
            }
        }
        public Task<SqlDataReader> ExecuteReader(SqlConnection connection, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return this.ExecuteReader(connection, commandType, commandText, null);
        }
        private Task<SqlDataReader> ExecuteReader(SqlConnection connection, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            // Pass through the call to the private overload using a null transaction value and an externally owned connection
            return this.ExecuteReader(connection, null, commandType, commandText, commandParameters, SqlConnectionOwnership.Internal);
        }
        public Task<SqlDataReader> ExecuteReader(SqlTransaction transaction, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return this.ExecuteReader(transaction, commandType, commandText, null);
        }
        private Task<SqlDataReader> ExecuteReader(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }
            // Pass through to private overload, indicating that the connection is owned by the caller
            return this.ExecuteReader(transaction.Connection, transaction, commandType, commandText, commandParameters, SqlConnectionOwnership.External);
        }
        #endregion ExecuteReader
        #region ExecuteScalar
        public async Task<object> ExecuteScalar(string storedprocedureName, params SqlParameter[] commandParameters)
        {
            return await this.ExecuteScalar(this.AppConnectionString, storedprocedureName, commandParameters);
        }
        public async Task<object> ExecuteScalar(string storedprocedureName)
        {
            return await this.ExecuteScalar(this.AppConnectionString, storedprocedureName);
        }
        public Task<object> ExecuteScalar(string connectionString, string storedprocedureName, params SqlParameter[] commandParameters)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            if (string.IsNullOrEmpty(storedprocedureName))
            {
                throw new ArgumentNullException("storedprocedureName");
            }
            return this.ExecuteScalar(connectionString, CommandType.StoredProcedure, storedprocedureName, commandParameters);
        }
        public Task<object> ExecuteScalar(string connectionString, string storedprocedureName)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            if (string.IsNullOrEmpty(storedprocedureName))
            {
                throw new ArgumentNullException("storedprocedureName");
            }
            return this.ExecuteScalar(connectionString, CommandType.StoredProcedure, storedprocedureName);
        }
        public Task<object> ExecuteScalar(SqlTransaction transaction, string storedprocedureName, params SqlParameter[] commandParameters)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }
            if (string.IsNullOrEmpty(storedprocedureName))
            {
                throw new ArgumentNullException("storedprocedureName");
            }
            // If we receive parameter values, we need to figure out where they go
            if ((commandParameters != null) && (commandParameters.Length > 0))
            {
                // Call the overload that takes an array of SqlParameters
                return this.ExecuteScalar(transaction, CommandType.StoredProcedure, storedprocedureName, commandParameters);
            }
            //// Otherwise we can just call the SP without params
            return this.ExecuteScalar(transaction, CommandType.StoredProcedure, storedprocedureName);
        }
        private async Task<object> ExecuteScalar(SqlConnection connection, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }
            // Create a command and prepare it for execution
            var cmd = new SqlCommand();
            var mustCloseConnection = await this.PrepareCommand(cmd, connection, null, commandType, commandText, commandParameters).ConfigureAwait(false);
            // Execute the command & return the results
            var retval = await cmd.ExecuteScalarAsync().ConfigureAwait(false);
            // Detach the SqlParameters from the command object, so they can be used again
            cmd.Parameters.Clear();
            if (mustCloseConnection)
            {
                connection.Close();
            }
            return retval;
        }
        private Task<object> ExecuteScalar(string connectionString, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return this.ExecuteScalar(connectionString, commandType, commandText, null);
        }
        private async Task<object> ExecuteScalar(string connectionString, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            //// Create & open a SqlConnection, and dispose of it after we are done
            using (var connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync().ConfigureAwait(false);
                // Call the overload that takes a connection in place of the connection string
                return await this.ExecuteScalar(connection, commandType, commandText, commandParameters).ConfigureAwait(false);
            }
        }
        private Task<object> ExecuteScalar(SqlTransaction transaction, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return this.ExecuteScalar(transaction, commandType, commandText, null);
        }
        public async Task<object> ExecuteScalar(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }
            //// Create a command and prepare it for execution
            var cmd = new SqlCommand();
            await this.PrepareCommand(cmd, transaction.Connection, transaction, commandType, commandText, commandParameters).ConfigureAwait(false);
            //// Execute the command & return the results
            var retval = await cmd.ExecuteScalarAsync().ConfigureAwait(false);
            //// Detach the SqlParameters from the command object, so they can be used again
            cmd.Parameters.Clear();
            return retval;
        }
        public Task<object> ExecuteScalar(SqlConnection connection, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return this.ExecuteScalar(connection, commandType, commandText, null);
        }
        #endregion ExecuteScalarAsync       
        #region PaginationSortingFilter
        public async Task<string> GetWhereClause(FilterModel[] filters)
        {
            string filterApplied = string.Empty;
            if (filters != null)
            {
                foreach (var item in filters)
                {
                    string itemValue;
                    item.Value = System.Web.HttpUtility.UrlDecode(item.Value);
                    if (item.ColumnType == FilterColumnTypeEnum.String || item.ColumnType == FilterColumnTypeEnum.Date)
                    {
                        itemValue = "'" + item.Value + "'";
                    }
                    else if (item.ColumnType == FilterColumnTypeEnum.Boolean)
                    {
                        itemValue = Convert.ToString((bool.Parse(item.Value) == true ? 1 : 0));
                    }
                    else
                    {
                        itemValue = item.Value;
                    }
                    switch (item.Operator)
                    {
                        case FilterOperatorEnum.StartsWith:
                            itemValue = itemValue + "%";
                            itemValue = itemValue.Replace("'%", "%'");
                            itemValue = "'" + itemValue + "'";
                            break;
                        case FilterOperatorEnum.EndsWith:
                            itemValue = "%" + itemValue;
                            itemValue = itemValue.Replace("%'", "'%");
                            itemValue = "'" + itemValue + "'";
                            break;
                        case FilterOperatorEnum.Contains:
                        case FilterOperatorEnum.NotContains:
                            itemValue = "%" + itemValue + "%";
                            itemValue = itemValue.Replace("'", "").Insert(0, "'");
                            itemValue = itemValue.Insert(itemValue.LastIndexOf("%") + 1, "'");
                            break;
                        case FilterOperatorEnum.EqualTo:
                            itemValue = "'" + itemValue + "'";
                            break;
                        case FilterOperatorEnum.NotEqualTo:
                            itemValue = "'" + itemValue + "'";
                            break;
                    }
                    if (item.Operator == FilterOperatorEnum.Null || item.Operator == FilterOperatorEnum.NotNull)
                    {
                        filterApplied += item.ColumnName + FilterOperatorSQLOperatorMapping[item.Operator] + " AND ";
                    }
                    else if (item.Operator == FilterOperatorEnum.Empty || item.Operator == FilterOperatorEnum.NotEmpty)
                    {
                        filterApplied += item.ColumnName + FilterOperatorSQLOperatorMapping[item.Operator] + " AND ";
                    }
                    else
                    {
                        filterApplied += item.ColumnName + FilterOperatorSQLOperatorMapping[item.Operator] + itemValue + " AND ";
                    }
                }
            }
            if (!string.IsNullOrEmpty(filterApplied))
            {
                filterApplied = filterApplied.Substring(0, filterApplied.LastIndexOf(" AND"));
                filterApplied = filterApplied.Replace(":string", string.Empty);
                filterApplied = filterApplied.Replace(":number", string.Empty);
            }
            return await Task.FromResult<string>(filterApplied);
        }
        public async Task<string> GetQuickReportWhereClause(FilterModel[] filters)
        {
            string filterApplied = string.Empty;
            if (filters != null)
            {
                foreach (var item in filters)
                {
                    string itemValue;
                    item.Value = System.Web.HttpUtility.UrlDecode(item.Value);
                    if (item.ColumnName.Contains("Comments"))
                    {
                        itemValue = "'" + item.Value + "'";
                        switch (item.Operator)
                        {
                            case FilterOperatorEnum.StartsWith:
                                itemValue = itemValue + "%";
                                itemValue = itemValue.Replace("'%", "%'");
                                break;
                            case FilterOperatorEnum.EndsWith:
                                itemValue = "%" + itemValue;
                                itemValue = itemValue.Replace("%'", "'%");
                                break;
                            case FilterOperatorEnum.Contains:
                            case FilterOperatorEnum.NotContains:
                                itemValue = "%" + itemValue + "%";
                                itemValue = itemValue.Replace("'", "").Insert(0, "'");
                                itemValue = itemValue.Insert(itemValue.LastIndexOf("%") + 1, "'");
                                break;
                        }
                        if (item.Operator == FilterOperatorEnum.Null || item.Operator == FilterOperatorEnum.NotNull)
                        {
                            filterApplied += " (" + "devComments" + FilterOperatorSQLOperatorMapping[item.Operator] + " or "
                                + "QualComments" + FilterOperatorSQLOperatorMapping[item.Operator] + " or " + "PilotComments"
                                + FilterOperatorSQLOperatorMapping[item.Operator] + ") " + " AND ";
                        }
                        else if (item.Operator == FilterOperatorEnum.Empty || item.Operator == FilterOperatorEnum.NotEmpty)
                        {
                            filterApplied += " (" + "devComments" + FilterOperatorSQLOperatorMapping[item.Operator] + " or "
                                 + "QualComments" + FilterOperatorSQLOperatorMapping[item.Operator] + " or " + "PilotComments"
                                 + FilterOperatorSQLOperatorMapping[item.Operator] + ") " + " AND ";
                        }
                        else
                        {
                            filterApplied += " (" + "devComments" + FilterOperatorSQLOperatorMapping[item.Operator] + itemValue + " or "
                                + "QualComments" + FilterOperatorSQLOperatorMapping[item.Operator] + itemValue + " or " + "PilotComments"
                                + FilterOperatorSQLOperatorMapping[item.Operator] + itemValue + ") " + " AND ";
                        }
                    }
                    else
                    {
                        if (item.ColumnType == FilterColumnTypeEnum.String || item.ColumnType == FilterColumnTypeEnum.Date)
                        {
                            itemValue = "'" + item.Value + "'";
                        }
                        else if (item.ColumnType == FilterColumnTypeEnum.Boolean)
                        {
                            itemValue = Convert.ToString((bool.Parse(item.Value) == true ? 1 : 0));
                        }
                        else
                        {
                            itemValue = item.Value;
                        }
                        switch (item.Operator)
                        {
                            case FilterOperatorEnum.StartsWith:
                                itemValue = itemValue + "%";
                                itemValue = itemValue.Replace("'%", "%'");
                                break;
                            case FilterOperatorEnum.EndsWith:
                                itemValue = "%" + itemValue;
                                itemValue = itemValue.Replace("%'", "'%");
                                break;
                            case FilterOperatorEnum.Contains:
                            case FilterOperatorEnum.NotContains:
                                itemValue = "%" + itemValue + "%";
                                itemValue = itemValue.Replace("'", "").Insert(0, "'");
                                itemValue = itemValue.Insert(itemValue.LastIndexOf("%") + 1, "'");
                                break;
                        }
                        if (item.Operator == FilterOperatorEnum.Null || item.Operator == FilterOperatorEnum.NotNull)
                        {
                            filterApplied += item.ColumnName + FilterOperatorSQLOperatorMapping[item.Operator] + " AND ";
                        }
                        else if (item.Operator == FilterOperatorEnum.Empty || item.Operator == FilterOperatorEnum.NotEmpty)
                        {
                            filterApplied += item.ColumnName + FilterOperatorSQLOperatorMapping[item.Operator] + " AND ";
                        }
                        else
                        {
                            filterApplied += item.ColumnName + FilterOperatorSQLOperatorMapping[item.Operator] + itemValue + " AND ";
                        }
                    }
                }
            }
            if (!string.IsNullOrEmpty(filterApplied))
            {
                filterApplied = filterApplied.Substring(0, filterApplied.LastIndexOf(" AND"));
                filterApplied = filterApplied.Replace(":string", string.Empty);
                filterApplied = filterApplied.Replace(":number", string.Empty);
            }
            return await Task.FromResult<string>(filterApplied);
        }
        public async Task<string> GetOrderByClause(PaginationModel pagination)
        {
            string sortDirection = string.Empty;
            if (pagination.SortBy != null)
            {
                if (pagination.SortDirection == ListSortDirectionEnum.Ascending)
                {
                    sortDirection += pagination.SortBy + " ASC";
                }
                else if (pagination.SortDirection == ListSortDirectionEnum.Descending)
                {
                    sortDirection += pagination.SortBy + " DESC";
                }
                sortDirection = sortDirection.Replace(":string", "");
                sortDirection = sortDirection.Replace(":number", "");
            }
            return await Task.FromResult<string>(sortDirection);
        }
        private Dictionary<FilterOperatorEnum, string> FilterOperatorSQLOperatorMapping = new Dictionary<FilterOperatorEnum, string>()
        {
            { FilterOperatorEnum.EqualTo, " = " },
            { FilterOperatorEnum.NotEqualTo, " <> " },
            { FilterOperatorEnum.GreaterThan, " > " },
            { FilterOperatorEnum.LesserThan, " < " },
            { FilterOperatorEnum.GreaterThanOrEqualTo, " >= " },
            { FilterOperatorEnum.LesserThanOrEqualTo, " <= " },
            { FilterOperatorEnum.Contains, " LIKE " },
            { FilterOperatorEnum.NotContains, " NOT LIKE " },
            { FilterOperatorEnum.StartsWith, " LIKE " },
            { FilterOperatorEnum.EndsWith, " LIKE " },
            { FilterOperatorEnum.Null," IS NULL  "},
            { FilterOperatorEnum.NotNull," IS NOT NULL  "},
            { FilterOperatorEnum.Between, " BETWEEN " },
            { FilterOperatorEnum.Empty, " = ' ' " },
            { FilterOperatorEnum.NotEmpty, " <> ' ' " }
        };
        #endregion
    }
}
﻿namespace HPi.Pulsar.Infrastructure.BaseClass
{
    using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
    public abstract class BaseManager<T>
    {
        protected BaseManager(IApplicationServices applicationService, T repository)
        {
            this.ApplicationService = applicationService;
            this.Repository = repository;
        }
        protected IApplicationServices ApplicationService { get; private set; }
        protected T Repository { get; private set; }
        public const int CacheExpiryTime = 10000;//In MiliSeconds
        public const int CacheExpiryLongTime = 1200000;//In MiliSeconds
    }
}

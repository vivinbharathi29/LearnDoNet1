﻿using System;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class WebApiExceptionFilter : ExceptionFilterAttribute
    {
        private IApplicationServices applicationServices;
        public WebApiExceptionFilter(IApplicationServices applicationServices)
        {
            this.applicationServices = applicationServices;
        }
        public override void OnException(ExceptionContext context)
        {
            var exception = context.Exception;
            if (exception != null)
            {
                this.applicationServices.ExceptionHandling.HandleExceptionAsync(exception);                            
                context.ExceptionHandled = true; // mark exception as handled
                context.HttpContext.Response.StatusCode = Convert.ToInt16(System.Net.HttpStatusCode.InternalServerError);
                context.HttpContext.Response.ContentType = "application/json";
                WebApiExceptionResponseModel exceptionmodel = new WebApiExceptionResponseModel();
                exceptionmodel.ExceptionType = exception.GetType().ToString();
                exceptionmodel.ExceptionMessage = exception.Message;
                context.Result = new JsonResult(exceptionmodel);
            }
        }  
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public abstract class BaseMvcController<T> : Controller
    {
        #region Private Variables
        private const string AppCookieName = "PulsarSession";
        #endregion
        protected BaseMvcController(IApplicationServices applicationService, T unitOfWork, IConfiguration configuration, ICurrentUserProfile currentProfile)
        {
            this.ApplicationService = applicationService;
            this.UnitOfWork = unitOfWork;
            this.CurrentUserProfile = currentProfile;
            this.ApplicationMode = configuration.GetSection("ApplicationMode").GetSection("AppMode").Value;
        }
        #region Protected Properties
        protected IApplicationServices ApplicationService { get; private set; }
        protected T UnitOfWork { get; private set; }
        protected string ApplicationMode { get; set; }
        private ICurrentUserProfile CurrentUserProfile { get; }
        protected JsonSerializerSettings JsonSettings = new JsonSerializerSettings
        {
            ContractResolver = new DefaultContractResolver()
        };
        #endregion
        #region Protected Method
        protected string GetSessionGuid()
        {
            string sessionGuid = string.Empty;
            string sessionCookie = HttpContext.Request.Cookies[AppCookieName];
            if (sessionCookie != null)
            {
                sessionGuid = sessionCookie.ToString();
            }
            return sessionGuid;
        }
        #endregion
        #region SessionState
        protected async Task SetSession<T1>(string key, T1 value, bool useInMemory)
        {
            var sessionGuid = this.GetSessionGuid();
            string itemType = value.GetType().Name;
            await this.ApplicationService.SessionState.SetAsync<T1>(sessionGuid, key, value, itemType, useInMemory);
        }
        protected async Task<T1> GetSession<T1>(string key)
        {
            var sessionGuid = this.GetSessionGuid();
            T1 value = await this.ApplicationService.SessionState.GetAsync<T1>(sessionGuid, key);
            return value;
        }
        #endregion
        #region Cache
        protected async Task SetCache<T1>(string cacheKey, T1 value, int expiryTime, bool useInMemory)
        {
            string itemType = value.GetType().Name;
            await this.ApplicationService.Cache.SetCacheAsync<T1>(cacheKey, value, expiryTime, itemType, useInMemory);
        }
        protected async Task<T1> GetCache<T1>(string cacheKey)
        {
            T1 value = await this.ApplicationService.Cache.GetCacheAsync<T1>(cacheKey);
            return value;
        }
        protected async Task InvalidateCache(string cacheKey)
        {
            await this.ApplicationService.Cache.InvalidateCacheAsync(cacheKey);
        }
        #endregion
        #region Infragistics Grid Pagination and Filtering
        public PaginationModel GetPaginationFromInfragisticsGrid(IQueryCollection queryString, Type model)
        {
            PaginationConfiguration pageniation = new PaginationConfiguration();
            int pageNo = 0;
            int pageSize = pageniation.DefaultPageSize;
            PaginationModel pagination = new PaginationModel();
            if (!string.IsNullOrEmpty(queryString["pageNo"].ToString()))
            {
                pageNo = int.Parse(queryString["pageNo"].ToString());
            }
            if (!string.IsNullOrEmpty(queryString["page"].ToString()))
            {
                pageNo = int.Parse(queryString["page"].ToString());
            }
            if (!string.IsNullOrEmpty(queryString["pageSize"].ToString()))
            {
                pageSize = int.Parse(queryString["pageSize"].ToString());
            }
            string column = null;
            string order = null;
            List<FilterModel> filters = new List<FilterModel>();
            FilterModel filter = null;
            foreach (string item in queryString.Keys)
            {
                if (item.StartsWith("sort"))
                {
                    column = item.Split('(', ')')[1];
                    order = queryString[item];
                    pagination.SortBy = column;
                    if (order == "asc")
                    {
                        pagination.SortDirection = Infrastructure.Contracts.Enumerators.ListSortDirectionEnum.Ascending;
                    }
                    else if (order == "desc")
                    {
                        pagination.SortDirection = Infrastructure.Contracts.Enumerators.ListSortDirectionEnum.Descending;
                    }
                }
                if (item.StartsWith("filter"))
                {
                    filter = new FilterModel();
                    column = item.Split('(', ')')[1];
                    string filterOperator = queryString[item].ToString().Split('(', ')')[0];
                    string filterText = queryString[item].ToString().Split('(', ')')[1];
                    string filterType = GetFilterDataType(column, model);
                    switch (filterOperator)
                    {
                        case "equals":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.EqualTo;
                            break;
                        case "contains":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Contains;
                            break;
                        case "containsCaseSensitive":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.ContainsCaseSensitive;
                            break;
                        case "empty":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Empty;
                            break;
                        case "endsWith":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.EndsWith;
                            break;
                        case "endsWithCaseSensitive":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.EndsWithCaseSensitive;
                            break;
                        case "equalTo":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.EqualTo;
                            break;
                        case "equalToCaseSensitive":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.EqualToCaseSensitive;
                            break;
                        case "greaterThan":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.GreaterThan;
                            break;
                        case "greaterThanOrEqualTo":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.GreaterThanOrEqualTo;
                            break;
                        case "lesserThan":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.LesserThan;
                            break;
                        case "lesserThanOrEqualTo":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.LesserThanOrEqualTo;
                            break;
                        case "notContains":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.NotContains;
                            break;
                        case "notContainsCaseSensitive":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.NotContainsCaseSensitive;
                            break;
                        case "notEmpty":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.NotEmpty;
                            break;
                        case "notEqualTo":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.NotEqualTo;
                            break;
                        case "notNull":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.NotNull;
                            break;
                        case "null":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Null;
                            break;
                        case "startsWith":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.StartsWith;
                            break;
                        case "startsWithCaseSensitive":
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.StartsWithCaseSensitive;
                            break;
                        case "on":
                            filterText = DateTimeOffset.FromUnixTimeMilliseconds(long.Parse(filterText)).AddDays(1).UtcDateTime.ToString("yyyy-MM-dd");
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.EqualTo;
                            break;
                        case "notOn":
                            filterText = DateTimeOffset.FromUnixTimeMilliseconds(long.Parse(filterText)).AddDays(1).UtcDateTime.ToString("yyyy-MM-dd");
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.NotEqualTo;
                            break;
                        case "after":
                            filterText = DateTimeOffset.FromUnixTimeMilliseconds(long.Parse(filterText)).AddDays(1).UtcDateTime.ToString("yyyy-MM-dd");
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.GreaterThan;
                            break;
                        case "before":
                            filterText = DateTimeOffset.FromUnixTimeMilliseconds(long.Parse(filterText)).AddDays(1).UtcDateTime.ToString("yyyy-MM-dd");
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.LesserThan;
                            break;
                        case "today":
                            filterText = DateTime.Now.ToString("yyyy-MM-dd");
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.EqualTo;
                            break;
                        case "yesterday":
                            filterText = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
                            filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.EqualTo;
                            break;
                        case "thisMonth":
                            {
                                DateTime firstDayOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                                DateTime lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddDays(-1);
                                filterText = firstDayOfMonth.ToString("yyyy-MM-dd") + "' AND '" + lastDayOfMonth.ToString("yyyy-MM-dd");
                                filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Between;
                            }
                            break;
                        case "lastMonth":
                            {
                                DateTime firstDayOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                                DateTime lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddDays(-1);
                                filterText = firstDayOfMonth.AddMonths(-1).ToString("yyyy-MM-dd") + "' AND '" + lastDayOfMonth.AddMonths(-1).ToString("yyyy-MM-dd");
                                filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Between;
                            }
                            break;
                        case "nextMonth":
                            {
                                DateTime firstDayOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                                DateTime lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddDays(-1);
                                filterText = firstDayOfMonth.AddMonths(1).ToString("yyyy-MM-dd") + "' AND '" + lastDayOfMonth.AddMonths(1).ToString("yyyy-MM-dd");
                                filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Between;
                            }
                            break;
                        case "thisYear":
                            {
                                DateTime firstDayOfYear = new DateTime(DateTime.Now.Year, 1, 1);
                                DateTime lastDayOfYear = firstDayOfYear.AddYears(1).AddDays(-1);
                                filterText = firstDayOfYear.ToString("yyyy-MM-dd") + "' AND '" + lastDayOfYear.ToString("yyyy-MM-dd");
                                filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Between;
                            }
                            break;
                        case "lastYear":
                            {
                                DateTime firstDayOfYear = new DateTime(DateTime.Now.Year, 1, 1);
                                DateTime lastDayOfYear = firstDayOfYear.AddYears(1).AddDays(-1);
                                filterText = firstDayOfYear.AddYears(-1).ToString("yyyy-MM-dd") + "' AND '" + lastDayOfYear.AddYears(-1).ToString("yyyy-MM-dd");
                                filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Between;
                            }
                            break;
                        case "nextYear":
                            {
                                DateTime firstDayOfYear = new DateTime(DateTime.Now.Year, 1, 1);
                                DateTime lastDayOfYear = firstDayOfYear.AddYears(1).AddDays(-1);
                                filterText = firstDayOfYear.AddYears(1).ToString("yyyy-MM-dd") + "' AND '" + lastDayOfYear.AddYears(1).ToString("yyyy-MM-dd");
                                filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.Between;
                            }
                            break;
                        case "doesNotEqual":
                            {
                                filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.NotEqualTo;
                                break;
                            }
                        case "doesNotContain":
                            {
                                filter.Operator = HPi.Pulsar.Infrastructure.Contracts.Enumerators.FilterOperatorEnum.NotContains;
                                break;
                            }
                    }
                    switch (filterType)
                    {
                        case "Number":
                            filter.ColumnType = Infrastructure.Contracts.Enumerators.FilterColumnTypeEnum.Number;
                            break;
                        case "String":
                            filter.ColumnType = Infrastructure.Contracts.Enumerators.FilterColumnTypeEnum.String;
                            break;
                        case "Boolean":
                            filter.ColumnType = Infrastructure.Contracts.Enumerators.FilterColumnTypeEnum.Boolean;
                            break;
                        case "Date":
                            filter.ColumnType = Infrastructure.Contracts.Enumerators.FilterColumnTypeEnum.Date;
                            break;
                    }
                    filter.ColumnName = column;
                    filter.Value = filterText;
                    filters.Add(filter);
                }
            }
            int pageNumber = pageNo;
            pagination.PageNo = pageNumber + 1;
            pagination.PageSize = pageSize;
            if (filters.Count != 0)
            {
                pagination.Filters = filters.ToArray();
            }
            return pagination;
        }
        private string GetFilterDataType(string column, Type model)
        {
            string filterDataType = string.Empty;
            foreach (var property in model.GetProperties())
            {
                if (property.Name == column)
                {
                    filterDataType = GetDataType(property.PropertyType.ToString());
                    break;
                }
            }
            return filterDataType;
        }
        private string GetDataType(string dataTypeName)
        {
            string dataType = string.Empty;
            switch (dataTypeName)
            {
                case "System.String":
                case "System.Char":
                case "System.Nullable`1[System.String]":
                case "System.Nullable`1[System.Char]":
                    dataType = "String";
                    break;
                case "Sytem.DateTime":
                case "System.Nullable`1[System.DateTime]":
                    dataType = "Date";
                    break;
                case "System.Int32":
                case "System.Int16":
                case "System.Int64":
                case "System.UInt16":
                case "System.UInt32":
                case "System.UInt64":
                case "System.Single":
                case "System.Double":
                case "System.Decimal":
                case "System.Byte":
                case "System.Nullable`1[System.Int32]":
                case "System.Nullable`1[System.Int16]":
                case "System.Nullable`1[System.Int64]":
                case "System.Nullable`1[System.UInt16]":
                case "System.Nullable`1[System.UInt32]":
                case "System.Nullable`1[System.UInt64]":
                case "System.Nullable`1[System.Single]":
                case "System.Nullable`1[System.Double]":
                case "System.Nullable`1[System.Decimal]":
                case "System.Nullable`1[System.Byte]":
                    dataType = "Number";
                    break;
                case "System.Boolean":
                case "System.Nullable`1[System.Boolean]":
                    dataType = "Boolean";
                    break;
            }
            return dataType;
        }
        #endregion
        #region Ig Grid Filter Cookie Handling
        protected void SetGridFilterCookie(FilterModel[] filters, string gridCookieName)
        {
            string igGridFilter = string.Empty;
            if (filters != null)
            {
                foreach (FilterModel item in filters)
                {
                    if (string.IsNullOrWhiteSpace(igGridFilter))
                        igGridFilter = item.ColumnName + ":" + item.Value + ":" + item.Operator;
                    else
                        igGridFilter = igGridFilter + ";" + item.ColumnName + ":" + item.Value + ":" + item.Operator;
                }
            }
            var expireDate = DateTime.Now;
            expireDate = expireDate.AddMonths(expireDate.Month + 12);
            Microsoft.AspNetCore.Http.CookieOptions option = new Microsoft.AspNetCore.Http.CookieOptions();
            option.Expires = expireDate;
            Response.Cookies.Append(gridCookieName, igGridFilter, option);
        }
        protected FilterModel[] GetGridFilterCookie(string gridCookieName)
        {
            string cookieValue = Request.Cookies[gridCookieName];
            List<FilterModel> filters = new List<FilterModel>();
            if (!string.IsNullOrWhiteSpace(cookieValue))
            {
                foreach (string item in cookieValue.Split(';'))
                {
                    FilterModel filter = new FilterModel();
                    string[] valueArray = item.Split(':');
                    filter.ColumnName = valueArray[0];
                    filter.Value = valueArray[1];
                    filter.Condition = String.Join(" ", valueArray[2].Split().Select(i => Char.ToLower(i[0]) + i.Substring(1)));
                    filters.Add(filter);
                }
            }
            return filters.ToArray();
        }
        #endregion
        #region PM or ImpersonateId or userId
        protected int GetPmIdOrImpersonateIdOrUserId()
        {
            int userId = 0;
            if (CurrentUserProfile.PMImpersonate.Value != 0)
            {
                userId = CurrentUserProfile.PMImpersonate.Value;
            }
            else
            {
                if (CurrentUserProfile.ImpersonateId.Value != 0)
                {
                    userId = CurrentUserProfile.ImpersonateId.Value;
                }
                else
                {
                    userId = CurrentUserProfile.UserId;
                }
            }
            return userId;
        }
        protected int GetImpersonateIdOrUserId()
        {
            int userId = 0;
            if (CurrentUserProfile.ImpersonateId.Value != 0)
            {
                userId = CurrentUserProfile.ImpersonateId.Value;
            }
            else
            {
                userId = CurrentUserProfile.UserId;
            }
            return userId;
        }
        #endregion
        #region  Get User Identity for CM, PC, PhWeb or Marketing Impersonate ID
        protected int GetCurrentUserIdOrCmPcPhWebMktImpersonateId()
        {
            int impersonateId;
            impersonateId = GetCmPcPhWebMktImpersonateId();
            if (impersonateId != 0)
            {
                return impersonateId;
            }
            else
            {
                if (CurrentUserProfile.ImpersonateId.Value != 0)
                    return CurrentUserProfile.ImpersonateId.Value;
                else
                    return CurrentUserProfile.UserId;
            }
        }
        protected int GetCmPcPhWebMktImpersonateId()
        {
            int impersonateId;
            impersonateId = 0;
            if (CurrentUserProfile.CMImpersonate.HasValue && CurrentUserProfile.CMImpersonate.Value != 0)
            {
                impersonateId = CurrentUserProfile.CMImpersonate.Value;
            }
            if (CurrentUserProfile.PCImpersonate.HasValue && CurrentUserProfile.PCImpersonate.Value != 0)
            {
                impersonateId = CurrentUserProfile.PCImpersonate.Value;
            }
            if (CurrentUserProfile.PhWebImpersonate.HasValue && CurrentUserProfile.PhWebImpersonate.Value != 0)
            {
                impersonateId = CurrentUserProfile.PhWebImpersonate.Value;
            }
            if (CurrentUserProfile.MarketingImpersonate.HasValue && CurrentUserProfile.MarketingImpersonate.Value != 0)
            {
                impersonateId = CurrentUserProfile.MarketingImpersonate.Value;
            }
            return impersonateId;
        }
        #endregion
    }
}

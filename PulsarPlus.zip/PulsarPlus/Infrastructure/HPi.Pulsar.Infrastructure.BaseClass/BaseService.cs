﻿using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class BaseService
    {
        protected readonly IApplicationServices ApplicationServices;
        protected BaseService(IApplicationServices applicationServices)
        {
            this.ApplicationServices = applicationServices;
        }
    }
}

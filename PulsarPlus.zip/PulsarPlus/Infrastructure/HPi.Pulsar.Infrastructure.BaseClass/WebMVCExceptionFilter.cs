﻿using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.ExceptionHandling;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
namespace HPi.Pulsar.Infrastructure.BaseClass
{
    public class WebMVCExceptionFilter : ExceptionFilterAttribute
    {  
        public override void OnException(ExceptionContext context)
        {
            var exception = context.Exception;
            if (exception != null)
            {
                string remoteIP = context.HttpContext.Connection.RemoteIpAddress.ToString();
                this.ExceptionContext.IPAddress = remoteIP;
                this.applicationServices.ExceptionHandling.HandleExceptionAsync(exception, this.ExceptionContext);
                var result = new ViewResult { ViewName = "Error" };
                context.ExceptionHandled = true;
                context.Result = result;  
            }
        }
        private IErrorContext ExceptionContext { get; }
        private IApplicationServices applicationServices;
        public WebMVCExceptionFilter(IApplicationServices applicationServices, IOptions<IErrorContext> baseparamvalue)
        {
            this.applicationServices = applicationServices;
            this.ExceptionContext = baseparamvalue.Value;
        }
    }
}

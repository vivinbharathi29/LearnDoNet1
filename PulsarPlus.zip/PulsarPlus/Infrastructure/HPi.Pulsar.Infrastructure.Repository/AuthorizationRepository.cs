﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Authorization;
namespace HPi.Pulsar.Infrastructure.Repository
{
    public class AuthorizationRepository : BaseRepository, IAuthorizationRepository
    {
        public AuthorizationRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }
        public async Task<List<string>> GetUserPermissionsAsync(int userId)
        {
            List<string> userPermissions = new List<string>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("UserName", userId);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetUserPermissions, parameters))
            {
                if (dataReader.HasRows)
                {
                    while (await dataReader.ReadAsync().ConfigureAwait(false))
                    {
                        string permissionName = dataReader["Name"] != DBNull.Value ? (string)dataReader["Name"] : String.Empty;
                        userPermissions.Add(permissionName);
                    }
                    return userPermissions;
                }
                return null;
            }
        }
        public async Task<List<string>> GetPermissionsAsync()
        {
            List<string> permissionNames = new List<string>();
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetPermissions))
            {
                if (dataReader.HasRows)
                {
                    while (await dataReader.ReadAsync().ConfigureAwait(false))
                    {
                        string permissionName = dataReader["Name"] != DBNull.Value ? (string)dataReader["Name"] : String.Empty;
                        permissionNames.Add(permissionName);
                    }
                }
            }
            return permissionNames;
        }
    }
}

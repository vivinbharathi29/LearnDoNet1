﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Extension;
using HPi.Pulsar.Infrastructure.Contracts.Partner;
using HPi.Pulsar.Infrastructure.Contracts.UserInfo;
namespace HPi.Pulsar.Infrastructure.Repository
{
    public class UserInfoRepository : BaseRepository, IUserInfoRepository
    {
        public UserInfoRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }
        public async Task<UserInfoModel> GetUserByNameAsync(string name, string domain)
        {
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("NtDomain", domain);
            parameters[1] = new SqlParameter("NtName", name);
            UserInfoModel userModel = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetUserByName, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userModel = new UserInfoModel
                    {
                        UserId = dataReader.GetValueOrDefault<int>("UserId"),
                        UserGuid = dataReader.GetValueOrDefault<Guid>("UserGuid"),
                        FirstName = dataReader.GetValueOrDefault<string>("FirstName"),
                        LastName = dataReader.GetValueOrDefault<string>("LastName"),
                        Email = dataReader.GetValueOrDefault<string>("Email"),
                        NtDomain = dataReader.GetValueOrDefault<string>("NtDomain"),
                        NtName = dataReader.GetValueOrDefault<string>("NtName"),
                        IsHp = dataReader.GetValueOrDefault<bool>("IsHp"),
                        ImpersonateId = dataReader.GetValueOrDefault<int>("ImpersonateId")
                    };
                }
                return userModel;
            }
        }
        public async Task<UserInfoModel> GetUserByIdAsync(int? id)
        {
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("Id", id);
            UserInfoModel userModel = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetUserById, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userModel = new UserInfoModel
                    {
                        UserId = dataReader.GetValueOrDefault<int>("UserId"),
                        UserGuid = dataReader.GetValueOrDefault<Guid>("UserGuid"),
                        FirstName = dataReader.GetValueOrDefault<string>("FirstName"),
                        LastName = dataReader.GetValueOrDefault<string>("LastName"),
                        Email = dataReader.GetValueOrDefault<string>("Email"),
                        NtDomain = dataReader.GetValueOrDefault<string>("NtDomain"),
                        NtName = dataReader.GetValueOrDefault<string>("NtName"),
                        IsHp = dataReader.GetValueOrDefault<bool>("IsHp"),
                        ImpersonateId = dataReader.GetValueOrDefault<int>("ImpersonateId")
                    };
                }
                return userModel;
            }
        }
        public async Task<UserInfoModel> GetUserByEmailAsync(string email)
        {
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("Email", email);
            UserInfoModel userModel = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetUserByEmail, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userModel = new UserInfoModel
                    {
                        UserId = dataReader.GetValueOrDefault<int>("UserId"),
                        UserGuid = dataReader.GetValueOrDefault<Guid>("UserGuid"),
                        FirstName = dataReader.GetValueOrDefault<string>("FirstName"),
                        LastName = dataReader.GetValueOrDefault<string>("LastName"),
                        Email = dataReader.GetValueOrDefault<string>("Email"),
                        NtDomain = dataReader.GetValueOrDefault<string>("NtDomain"),
                        NtName = dataReader.GetValueOrDefault<string>("NtName"),
                        IsHp = dataReader.GetValueOrDefault<bool>("IsHp"),
                        ImpersonateId = dataReader.GetValueOrDefault<int>("ImpersonateId")
                    };
                }
                return userModel;
            }
        }
        public async Task<UserInfoModel> GetUserInfoByUserNameAsync(string userName, string domain, bool? isCacheRequired)
        {
            UserInfoModel userInfo = null;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("userName", userName);
            parameters[1] = new SqlParameter("Domain", domain);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetUserInfoByUserName, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.NtDomain = dataReader.GetValueOrDefault<string>("Domain");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.UserId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    userInfo.Phone = dataReader.GetValueOrDefault<string>("Phone");
                    userInfo.Division = dataReader.GetValueOrDefault<byte?>("Division");
                    userInfo.PartnerId = dataReader.GetValueOrDefault<int?>("PartnerId");
                    userInfo.ApprovalSection = dataReader.GetValueOrDefault<bool?>("ApprovalSection");
                    userInfo.WorkingSection = dataReader.GetValueOrDefault<bool?>("WorkingSection");
                    userInfo.ResetPassword = dataReader.GetValueOrDefault<System.DateTime?>("ResetPassword");
                    userInfo.PastDueSection = dataReader.GetValueOrDefault<bool?>("PastDueSection");
                    userInfo.DueThisWeekSection = dataReader.GetValueOrDefault<bool?>("DueThisWeekSection");
                    userInfo.AllOpenSection = dataReader.GetValueOrDefault<bool?>("AllOpenSection");
                    userInfo.PIReassignedSection = dataReader.GetValueOrDefault<byte?>("PIReassignedSection");
                    userInfo.ISubmittedSection = dataReader.GetValueOrDefault<bool?>("ISubmittedSection");
                    userInfo.ClosedSection = dataReader.GetValueOrDefault<bool?>("ClosedSection");
                    userInfo.PostRTMSection = dataReader.GetValueOrDefault<bool?>("PostRTMSection");
                    userInfo.OTSSubmittedSection = dataReader.GetValueOrDefault<bool?>("OTSSubmittedSection");
                    userInfo.OTSDeliverableSection = dataReader.GetValueOrDefault<bool?>("OTSDeliverableSection");
                    userInfo.OTSOwnerSection = dataReader.GetValueOrDefault<bool?>("OTSOwnerSection");
                    userInfo.SystemAdmin = dataReader.GetValueOrDefault<bool?>("SystemAdmin");
                    userInfo.PreinstallPM = dataReader.GetValueOrDefault<bool?>("PreinstallPM");
                    userInfo.DefaultProductTab = dataReader.GetValueOrDefault<string>("DefaultProductTab");
                    userInfo.CommodityPM = dataReader.GetValueOrDefault<bool?>("CommodityPM");
                    userInfo.MITTestLead = dataReader.GetValueOrDefault<bool?>("MITTestLead");
                    userInfo.SCFactoryEngineer = dataReader.GetValueOrDefault<bool?>("SCFactoryEngineer");
                    userInfo.CanReleaseLocalizations = dataReader.GetValueOrDefault<bool?>("CanReleaseLocalizations");
                    userInfo.TestLeadAssignments = dataReader.GetValueOrDefault<int?>("TestLeadAssignments");
                    userInfo.BPIAApprover = dataReader.GetValueOrDefault<bool?>("BPIAApprover");
                    userInfo.WWANEngineer = dataReader.GetValueOrDefault<bool?>("WWANEngineer");
                    userInfo.ServiceCommodityManager = dataReader.GetValueOrDefault<bool?>("ServiceCommodityManager");
                    userInfo.ProcurementEngineer = dataReader.GetValueOrDefault<bool?>("ProcurementEngineer");
                    userInfo.ServicePM = dataReader.GetValueOrDefault<bool?>("ServicePM");
                    userInfo.ProposedSection = dataReader.GetValueOrDefault<bool?>("ProposedSection");
                    userInfo.WorkgroupID = dataReader.GetValueOrDefault<int?>("WorkgroupID");
                    userInfo.ConsumerSEPMProducts = dataReader.GetValueOrDefault<int?>("ConsumerSEPMProducts");
                    userInfo.HWProducts = dataReader.GetValueOrDefault<int?>("HWProducts");
                    userInfo.ServiceProducts = dataReader.GetValueOrDefault<int?>("ServiceProducts");
                    userInfo.SEPMProducts = dataReader.GetValueOrDefault<int?>("SEPMProducts");
                    userInfo.LastStatusSection = dataReader.GetValueOrDefault<int?>("LastStatusSection");
                    userInfo.LastStatusCategory = dataReader.GetValueOrDefault<string>("LastStatusCategory");
                    userInfo.StatusDelegate = dataReader.GetValueOrDefault<int?>("StatusDelegate");
                    userInfo.PIPMAlertSection = dataReader.GetValueOrDefault<byte?>("PIPMAlertSection");
                    userInfo.PINewRequestSection = dataReader.GetValueOrDefault<byte?>("PINewRequestSection");
                    userInfo.AccountSuspended = dataReader.GetValueOrDefault<bool?>("AccountSuspended");
                    userInfo.PIScripterSection = dataReader.GetValueOrDefault<int?>("PIScripterSection");
                    userInfo.PIDBTeamSection = dataReader.GetValueOrDefault<byte?>("PIDBTeamSection");
                    userInfo.FavCount = dataReader.GetValueOrDefault<short?>("FavCount");
                    userInfo.Favorites = dataReader.GetValueOrDefault<string>("Favorites");
                    userInfo.WHQLTestTeam = dataReader.GetValueOrDefault<bool?>("WHQLTestTeam");
                    userInfo.ServiceCoordinator = dataReader.GetValueOrDefault<bool?>("ServiceCoordinator");
                    userInfo.EngCoordinatorForConfiguration = dataReader.GetValueOrDefault<int?>("EngCoordinator");
                    userInfo.AccessoryPM = dataReader.GetValueOrDefault<bool?>("AccessoryPM");
                    userInfo.FunctionalTestMADTSection = dataReader.GetValueOrDefault<bool?>("FunctionalTestMADTSection");
                    userInfo.FunctionalTestOtherSection = dataReader.GetValueOrDefault<bool?>("FunctionalTestOtherSection");
                    userInfo.FunctionalTest3rdPartySection = dataReader.GetValueOrDefault<bool?>("FunctionalTest3rdPartySection");
                    userInfo.FunctionalTestMultimediaSection = dataReader.GetValueOrDefault<bool?>("FunctionalTestMultimediaSection");
                    userInfo.FunctionalTestHelpAndSupportSection = dataReader.GetValueOrDefault<bool?>("FunctionalTestHelpAndSupportSection");
                    userInfo.FunctionalTestDeveloperSection = dataReader.GetValueOrDefault<bool?>("FunctionalTestDeveloperSection");
                    userInfo.FunctionalTestUserGuidesSection = dataReader.GetValueOrDefault<bool?>("FunctionalTestUserGuidesSection");
                    userInfo.FunctionalTestToolsSection = dataReader.GetValueOrDefault<bool?>("FunctionalTestToolsSection");
                    userInfo.FunctionalTest3rdPartyConsSection = dataReader.GetValueOrDefault<bool?>("FunctionalTest3rdPartyConsSection");
                    userInfo.FunctionalTest3rdPartyInternalSection = dataReader.GetValueOrDefault<bool?>("FunctionalTest3rdPartyInternalSection");
                    userInfo.FTVirtualizationSection = dataReader.GetValueOrDefault<bool?>("FTVirtualizationSection");
                    userInfo.FTBIOSSection = dataReader.GetValueOrDefault<bool?>("FTBIOSSection");
                    userInfo.FTThinClientSection = dataReader.GetValueOrDefault<bool?>("FTThinClientSection");
                    userInfo.FTSecuritySection = dataReader.GetValueOrDefault<bool?>("FTSecuritySection");
                    userInfo.FTMultimediaAppsSection = dataReader.GetValueOrDefault<bool?>("FTMultimediaAppsSection");
                    userInfo.FTHWEnablingSection = dataReader.GetValueOrDefault<bool?>("FTHWEnablingSection");
                    userInfo.FTIntelTechnologiesSection = dataReader.GetValueOrDefault<bool?>("FTIntelTechnologiesSection");
                    userInfo.PMImpersonate = dataReader.GetValueOrDefault<int?>("PMImpersonate");
                    userInfo.DefaultWorkingListProduct = dataReader.GetValueOrDefault<int?>("DefaultWorkingListProduct");
                    userInfo.ToolDeveloper = dataReader.GetValueOrDefault<bool?>("ToolDeveloper");
                    userInfo.SMProducts = dataReader.GetValueOrDefault<int?>("SMProducts");
                    ////userInfo.BPIAApprover = dataReader.GetValueOrDefault<bool?>("BPIAApprover");
                    userInfo.OtherPartnerNames = dataReader.GetValueOrDefault<string>("OtherPartnerNames");
                    userInfo.AVsMissingCommMarketingData = dataReader.GetValueOrDefault<int?>("AVsMissingCommMarketingData");
                    userInfo.AVsMissingSMBMarketingData = dataReader.GetValueOrDefault<int?>("AVsMissingSMBMarketingData");
                    userInfo.AVsMissingConsMarketingData = dataReader.GetValueOrDefault<int?>("AVsMissingConsMarketingData");
                    userInfo.PDMUser = dataReader.GetValueOrDefault<int?>("PDMUser");
                    userInfo.CMProductCount = dataReader.GetValueOrDefault<int?>("CMProductCount");
                    userInfo.PCProductCount = dataReader.GetValueOrDefault<int?>("PCProductCount");
                    userInfo.PhWebProductCount = dataReader.GetValueOrDefault<int?>("PhWebProductCount");
                    userInfo.CMImpersonate = dataReader.GetValueOrDefault<int?>("CMImpersonate");
                    userInfo.PCImpersonate = dataReader.GetValueOrDefault<int?>("PCImpersonate");
                    userInfo.PhWebImpersonate = dataReader.GetValueOrDefault<int?>("PhWebImpersonate");
                    userInfo.Partner = new PartnerModel();
                    userInfo.Partner.PartnerId = dataReader.GetValueOrDefault<int?>("PartnerId");
                    userInfo.Partner.PartnerTypeID = dataReader.GetValueOrDefault<int?>("PartnerTypeID");
                    userInfo.MarketingProductCount = dataReader.GetValueOrDefault<int?>("MarketingProductCount");
                    userInfo.MarketingImpersonate = dataReader.GetValueOrDefault<int?>("MarketingImpersonate");
                    userInfo.PCAdmin = dataReader.GetValueOrDefault<int?>("PCAdmin");
                    userInfo.CMAdmin = dataReader.GetValueOrDefault<int?>("CMAdmin");
                    userInfo.PDMAdmin = dataReader.GetValueOrDefault<int?>("PDMAdmin");
                    userInfo.MKTAdmin = dataReader.GetValueOrDefault<int?>("MKTAdmin");
                    userInfo.IrsUserId = dataReader.GetValueOrDefault<int?>("IrsUserId");
                    userInfo.SAAdmin = dataReader.GetValueOrDefault<int?>("SAAdmin");
                    userInfo.JupiterXLR8Admin = dataReader.GetValueOrDefault<int?>("JupiterXLR8Admin");
                    userInfo.Pulsar = dataReader.GetValueOrDefault<bool?>("Pulsar");
                    userInfo.PulsarSystemAdmin = dataReader.GetValueOrDefault<int?>("PulsarSystemAdmin");
                    userInfo.IsPINPM = dataReader.GetValueOrDefault<int?>("IsPINPM");
                    userInfo.PINPMImpersonate = dataReader.GetValueOrDefault<int?>("PINPMImpersonate");
                    userInfo.originalName = dataReader.GetValueOrDefault<string>("originalName");
                    userInfo.CanEditProduct = dataReader.GetValueOrDefault<int?>("CanEditProduct");
                    userInfo.AgencyDataMaintainer = dataReader.GetValueOrDefault<int?>("AgencyDataMaintainer");
                    userInfo.CurrentName = dataReader.GetValueOrDefault<string>("CurrentName");
                    userInfo.OriginalUserId = dataReader.GetValueOrDefault<int>("OriginalUserId");
                    userInfo.ProductImageEdit = dataReader.GetValueOrDefault<int>("ProductImageEdit");
                    userInfo.ImpersonateId = userInfo.UserId != userInfo.OriginalUserId ? userInfo.UserId : 0;
                }
                return userInfo;
            }
        }
        public async Task<UserInfoModel> GetEmployeeImpersonateIdAsync(string ntName, string domain)
        {
            UserInfoModel userInfo = null;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("NTName", ntName);
            parameters[1] = new SqlParameter("Domain", domain);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetEmployeeImpersonateID, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.ImpersonateId = dataReader.GetValueOrDefault<int?>("ImpersonateId");
                    userInfo.UserId = dataReader.GetValueOrDefault<int>("EmployeeID");
                }
                return userInfo;
            }
        }
        public async Task<UserInfoModel> GetEmployeeByIDAsync(int impersonateId)
        {
            UserInfoModel userInfo = null;
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("ID", impersonateId);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.spGetEmployeeByID, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.UserId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    userInfo.Division = dataReader.GetValueOrDefault<byte?>("Division");
                    userInfo.Phone = dataReader.GetValueOrDefault<string>("Phone");
                    userInfo.NtName = dataReader.GetValueOrDefault<string>("NTName");
                    userInfo.WorkgroupID = dataReader.GetValueOrDefault<int?>("WorkgroupID");
                    userInfo.PartnerId = dataReader.GetValueOrDefault<int?>("PartnerId");
                    userInfo.SystemAdmin = dataReader.GetValueOrDefault<bool?>("SystemAdmin");
                    userInfo.PreinstallPM = dataReader.GetValueOrDefault<bool?>("PreinstallPM");
                    userInfo.NtDomain = dataReader.GetValueOrDefault<string>("Domain");
                }
                return userInfo;
            }
        }
        public async Task<MenuUserInfoModel> GetUserMenuRightsAsync(int userId)
        {
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("UserID", userId);
            MenuUserInfoModel userModel = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetUserMenuRights, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userModel = new MenuUserInfoModel
                    {
                        NtName = dataReader.GetValueOrDefault<string>("NtName"),
                        ImpersonateID = dataReader.GetValueOrDefault<int>("ImpersonateID"),
                        Division = dataReader.GetValueOrDefault<int>("Division"),
                        PartnerID = dataReader.GetValueOrDefault<int>("PartnerID"),
                        PartnerTypeID = dataReader.GetValueOrDefault<int>("PartnerTypeID"),
                        SupportAdmin = dataReader.GetValueOrDefault<int>("SupportAdmin"),
                        JupiterAdmin = dataReader.GetValueOrDefault<int>("JupiterAdmin")
                    };
                }
                return userModel;
            }
        }
        #region ChangeImpersonationUser
        public async Task<UserInfoModel[]> GetImpersonationEmployeesAsync(int isImpersonate, string userNamePattern, string filter)
        {
            List<UserInfoModel> userInfoList = new List<UserInfoModel>();
            var parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("p_intImpersonate", isImpersonate);
            parameters[1] = new SqlParameter("UserName", userNamePattern);
            parameters[2] = new SqlParameter("FilterType", filter);
            UserInfoModel userInfo = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetAllTheUsers, parameters))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.EmployeeId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.NtName = dataReader.GetValueOrDefault<string>("NTName");
                    userInfo.NtDomain = dataReader.GetValueOrDefault<string>("Domain");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    userInfoList.Add(userInfo);
                }
                return userInfoList.ToArray();
            }
        }
        public async Task<UserInfoModel> IsSupportAdminAsync(int employeeId)
        {
            UserInfoModel userInfo = null;
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("EmployeeID", employeeId);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetTheAdminSupportStatus, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.EmployeeId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                }
                return userInfo;
            }
        }
        public async Task<bool> TrySaveImpersonationEmployeeAsync(int employeeId, int impersonateId)
        {
            bool status = false;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("EmployeeID", employeeId);
            parameters[1] = new SqlParameter("ImpersonateID", impersonateId);
            int rowsAffected = await this.ExecuteNonQuery(StoreProcedure.UpdateTheSelectedImpersonateUser, parameters);
            status = rowsAffected == 1 ? true : false;
            return status;
        }
        #endregion
        #region SwitchPM
        public async Task<UserInfoModel[]> GetSwitchPMEmployeesAsync(int sepmId, string userNamePattern)
        {
            List<UserInfoModel> userInfoList = new List<UserInfoModel>();
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("SEPMID", sepmId);
            parameters[1] = new SqlParameter("UserName", userNamePattern);
            UserInfoModel userInfo = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetSwitchPMUsers, parameters))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.EmployeeId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.NtName = dataReader.GetValueOrDefault<string>("ntname");
                    userInfo.NtDomain = dataReader.GetValueOrDefault<string>("domain");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("NAME");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    userInfoList.Add(userInfo);
                }
                return userInfoList.ToArray();
            }
        }
        public async Task<bool> SavePMImpersonationEmployeeAsync(int employeeId, int impersonateId)
        {
            bool status = false;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("EmployeeID", employeeId);
            parameters[1] = new SqlParameter("ImpersonateID", impersonateId);
            int rowsAffected = await this.ExecuteNonQuery(StoreProcedure.UpdateSwitchPMUser, parameters);
            status = rowsAffected == 1 ? true : false;
            return status;
        }
        #endregion
        #region SwitchPCUser
        public async Task<UserInfoModel[]> GetCmPcPHWebMarketingUsersAsync(int switchType, string userNamePattern)
        {
            List<UserInfoModel> userInfoList = new List<UserInfoModel>();
            UserInfoModel userInfo = null;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("UserName", userNamePattern);
            parameters[1] = new SqlParameter("SwitchType", switchType);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetCmPcPhWebMktUsers, parameters))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.EmployeeId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.NtName = dataReader.GetValueOrDefault<string>("NTName");
                    userInfo.NtDomain = dataReader.GetValueOrDefault<string>("Domain");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    userInfo.Sort = dataReader.GetValueOrDefault<int>("Sort");
                    userInfoList.Add(userInfo);
                }
                return userInfoList.ToArray();
            }
        }
        public async Task<bool> SaveCmPcPHWebMarketingUserAsync(int employeeId, int impersonateId, int switchType)
        {
            bool status = false;
            var parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("EmployeeID", employeeId);
            parameters[1] = new SqlParameter("ImpersonateID", impersonateId);
            parameters[2] = new SqlParameter("SwitchType", switchType);
            int rowsAffected = await this.ExecuteNonQuery(StoreProcedure.UpdateCmPcPhwebMktImpersonation, parameters);
            status = rowsAffected == 1 ? true : false;
            return status;
        }
        #endregion
        #region Get Employee for Save Access
        public async Task<UserInfoModel> GetEmployeesIsSysAdminAsync(int? employeeID, int isAdmin, string ntName, string domain, int? partnerID)
        {
            UserInfoModel userInfo = null;
            var parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("p_EmployeeID", employeeID);
            parameters[1] = new SqlParameter("p_IsAdmin", isAdmin);
            parameters[2] = new SqlParameter("p_NTName", ntName);
            parameters[3] = new SqlParameter("p_Domain", domain);
            parameters[4] = new SqlParameter("p_PartnerID", partnerID);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetEmployeesForSaveAccess, parameters))
            {
                if (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.UserId = dataReader.GetValueOrDefault<int>("EmployeeID");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.Office = dataReader.GetValueOrDefault<string>("Office");
                    userInfo.Phone = dataReader.GetValueOrDefault<string>("Phone");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    userInfo.ManagerLevel = dataReader.GetValueOrDefault<short?>("ManagerLevel");
                    userInfo.ManagerId = dataReader.GetValueOrDefault<int?>("ManagerId");
                    userInfo.WorkgroupID = dataReader.GetValueOrDefault<int?>("WorkgroupID");
                    userInfo.NtName = dataReader.GetValueOrDefault<string>("NtName");
                    userInfo.Division = dataReader.GetValueOrDefault<byte?>("Division");
                    userInfo.NtDomain = dataReader.GetValueOrDefault<string>("Domain");
                    userInfo.PartnerId = dataReader.GetValueOrDefault<int?>("PartnerId");
                    userInfo.ImpersonateId = dataReader.GetValueOrDefault<int?>("ImpersonateId");
                }
                return userInfo;
            }
        }
        public async Task<UserInfoModel[]> GetEmployeesPMsActiveAsync(int typeID)
        {
            List<UserInfoModel> userInfoList = new List<UserInfoModel>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("TypeID", typeID);
            UserInfoModel userInfo = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetEmployeesPMsActive, parameters))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.UserId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("name");
                    userInfoList.Add(userInfo);
                }
                return userInfoList.ToArray();
            }
        }
        public async Task<int> GetUserInRoleAsync(int? userId, int? productVersionId, string roleName)
        {
            int userRole = 0;
            var parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("p_UserId", userId);
            parameters[1] = new SqlParameter("p_ProductVersionId", productVersionId);
            parameters[2] = new SqlParameter("p_RoleCd", roleName);
            userRole = (int)await this.ExecuteScalar(StoreProcedure.GetUserInRole, parameters);
            return userRole;
        }
        #endregion
        public async Task<bool> TryUpdateDCRWorkflowReassignAsync(int historyId, int reassignId)
        {
            int rowsAffected = 0;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("p_HistoryID", historyId);
            parameters[1] = new SqlParameter("p_AssignedTo", reassignId);
            using (SqlConnection connection = new SqlConnection(this.AppConnectionString))
            {
                connection.Open();
                using (SqlTransaction sqltrans = connection.BeginTransaction())
                {
                    try
                    {
                        rowsAffected = await this.ExecuteNonQuery(sqltrans, StoreProcedure.UpdateReAssignMilestone, parameters);
                        sqltrans.Commit();
                    }
                    catch
                    {
                        sqltrans.Rollback();
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            return rowsAffected > 0 ? true : false;
        }
        public async Task<UserInfoModel[]> GetAllAccessoryPMsAsync()
        {
            List<UserInfoModel> userInfoList = new List<UserInfoModel>();
            var parameters = new SqlParameter[0];
            UserInfoModel userInfo = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetAllAccessoryPMs, parameters))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.EmployeeId = dataReader.GetValueOrDefault<int>("Id");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfoList.Add(userInfo);
                }
                return userInfoList.ToArray();
            }
        }
        #region ListFactoryEngineersAll
        public async Task<UserInfoModel[]> ListFactoryEngineersAllAsync()
        {
            List<UserInfoModel> userInfoList = new List<UserInfoModel>();
            var parameters = new SqlParameter[0];
            UserInfoModel userInfo = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.ListFactoryEngineersAll, parameters))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.EmployeeId = dataReader.GetValueOrDefault<int>("Id");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfoList.Add(userInfo);
                }
                return userInfoList.ToArray();
            }
        }
        #endregion ListFactoryEngineersAll
        public async Task<UserInfoModel[]> GetEmployeeListAsync(string userNamePattern)
        {
            List<UserInfoModel> userInfoList = new List<UserInfoModel>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("UserName", userNamePattern);
            UserInfoModel userInfo = null;
            PartnerModel partnerInfo = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetListOfEmployees, parameters))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    partnerInfo = new PartnerModel();
                    userInfo.UserId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.ManagerName = dataReader.GetValueOrDefault<string>("Manager");
                    partnerInfo.Name = dataReader.GetValueOrDefault<string>("Partner");
                    partnerInfo.ID = dataReader.GetValueOrDefault<int>("Partnerid");
                    userInfo.Partner = partnerInfo;
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    userInfo.Phone = dataReader.GetValueOrDefault<string>("Phone");
                    userInfo.DivisionName = dataReader.GetValueOrDefault<string>("Division");
                    userInfo.WorkgroupName = dataReader.GetValueOrDefault<string>("workgroup");
                    userInfo.WorkgroupID = dataReader.GetValueOrDefault<int>("WorkgroupID");
                    userInfo.NtName = dataReader.GetValueOrDefault<string>("NTName");
                    userInfo.Active = dataReader.GetValueOrDefault<byte>("Active");
                    userInfo.NtDomain = dataReader.GetValueOrDefault<string>("Domain");
                    userInfo.CommodityPM = dataReader.GetValueOrDefault<bool>("CommodityPM");
                    userInfo.AccessoryPM = dataReader.GetValueOrDefault<bool>("AccessoryPM");
                    userInfo.SCFactoryEngineer = dataReader.GetValueOrDefault<bool>("SCFactoryEngineer");
                    userInfo.ProgramCoordinator = dataReader.GetValueOrDefault<bool>("ProgramCoordinator");
                    userInfoList.Add(userInfo);
                }
                return userInfoList.ToArray();
            }
        }
        public async Task<UserInfoModel[]> GetActionEmployeesAsync(string userType, string userNamePattern, int currentUserId, int ownerId, int id)
        {
            List<UserInfoModel> actionUsers = new List<UserInfoModel>();
            UserInfoModel userInfo = null;
            var parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("EmployeeType", userType);
            parameters[1] = new SqlParameter("UserPattern", userNamePattern);
            parameters[2] = new SqlParameter("OwnerId", ownerId);
            parameters[3] = new SqlParameter("CurrentUserId", currentUserId);
            parameters[4] = new SqlParameter("Id", id);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetActionEmployees, parameters))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.EmployeeId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    actionUsers.Add(userInfo);
                }
            }
            return actionUsers.ToArray();
        }
        public async Task<UserInfoModel[]> GetEngineeringCoorginatorsAsync()
        {
            List<UserInfoModel> engineeringCoorginator = new List<UserInfoModel>();
            UserInfoModel userInfo = null;
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetEngineeringCoorginators))
            {
                while (await dataReader.ReadAsync().ConfigureAwait(false))
                {
                    userInfo = new UserInfoModel();
                    userInfo.UserId = dataReader.GetValueOrDefault<int>("ID");
                    userInfo.FullName = dataReader.GetValueOrDefault<string>("Name");
                    userInfo.Email = dataReader.GetValueOrDefault<string>("Email");
                    engineeringCoorginator.Add(userInfo);
                }
            }
            return engineeringCoorginator.ToArray();
        }
        public async Task<bool> UpdateFavoritesAsync(UserInfoModel userInfo)
        {
            bool status = false;
            int rowsAffected = 0;
            var parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("EmployeeID", userInfo.UserId);
            parameters[1] = new SqlParameter("FavCount", userInfo.FavCount);
            parameters[2] = new SqlParameter("Favorites", userInfo.Favorites);
            using (SqlConnection connection = new SqlConnection(this.AppConnectionString))
            {
                connection.Open();
                using (SqlTransaction sqltrans = connection.BeginTransaction())
                {
                    try
                    {
                        rowsAffected = await this.ExecuteNonQuery(sqltrans, StoreProcedure.UpdateFavorites, parameters);
                        if (rowsAffected == 1)
                        {
                            sqltrans.Commit();
                        }
                        else
                        {
                            sqltrans.Rollback();
                        }
                    }
                    catch
                    {
                        sqltrans.Rollback();
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            status = rowsAffected == 1 ? true : false;
            return status;
        }
        public async Task<bool> UpdateDefaultProductTabAsync(int employeeId, string tab)
        {
            bool status = false;
            int rowsAffected = 0;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("EmployeeID", employeeId);
            parameters[1] = new SqlParameter("Tab", tab);
            using (SqlConnection connection = new SqlConnection(this.AppConnectionString))
            {
                connection.Open();
                using (SqlTransaction sqltrans = connection.BeginTransaction())
                {
                    try
                    {
                        rowsAffected = await this.ExecuteNonQuery(sqltrans, StoreProcedure.UpdateDefaultProductTab, parameters);
                        if (rowsAffected == 1)
                        {
                            sqltrans.Commit();
                        }
                        else
                        {
                            sqltrans.Rollback();
                        }
                    }
                    catch
                    {
                        sqltrans.Rollback();
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            status = rowsAffected == 1 ? true : false;
            return status;
        }
    }
}

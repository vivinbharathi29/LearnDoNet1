﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Extension;
using HPi.Pulsar.Infrastructure.Contracts.Logging;
namespace HPi.Pulsar.Infrastructure.Repository
{
    public class LoggingRepository : BaseRepository, ILoggingRepository
    {
        public LoggingRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }
        public async Task<int> LogErrorAsync(ErrorLogModel errorLogModel)
        {
            var par = new SqlParameter[10];
            if (errorLogModel.ErrorDescription.Length > 7999)
            {
                errorLogModel.ErrorDescription = errorLogModel.ErrorDescription.Substring(0, 7999);
            }
            par[0] = new SqlParameter("ErrorDateTime", System.DateTime.Now);
            par[1] = new SqlParameter("ErrorMessage", this.CastNullToDBNull(errorLogModel.ErrorMessage.SubValue(510)));
            par[2] = new SqlParameter("AssemblyName", this.CastNullToDBNull(errorLogModel.AssemblyName.SubValue(100)));
            par[3] = new SqlParameter("ErrorDescription", this.CastNullToDBNull(errorLogModel.ErrorDescription.SubValue(8000)));
            par[4] = new SqlParameter("AssemblyVersion", this.CastNullToDBNull(errorLogModel.AssemblyVersion.SubValue(50)));
            par[5] = new SqlParameter("ApplicationName", this.CastNullToDBNull(errorLogModel.ApplicationName.SubValue(25)));
            par[6] = new SqlParameter("UserID", this.CastNullToDBNull(errorLogModel.UserId.SubValue(99)));
            par[7] = new SqlParameter("ApplicationVersion", this.CastNullToDBNull(errorLogModel.ApplicationVersion.SubValue(20)));
            par[8] = new SqlParameter("ServerIP", this.CastNullToDBNull(errorLogModel.ServerIp));
            par[9] = new SqlParameter("LogID", SqlDbType.Int) { Direction = ParameterDirection.Output };
            await this.ExecuteNonQuery(this.AppConnectionString, CommandType.StoredProcedure, "usp_Error_log_Insert", par);
            return Convert.ToInt32(par[9].Value);
        }
    }
}

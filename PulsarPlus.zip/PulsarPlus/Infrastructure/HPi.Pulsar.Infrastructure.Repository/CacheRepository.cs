﻿using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
namespace HPi.Pulsar.Infrastructure.Repository
{
    public class CacheRepository : BaseRepository, ICacheRepository
    {
        public CacheRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }
        #region Public Methods
        public async Task SetCacheAsync(string cacheKey, string value, int expiryTime, string itemType)
        {
            var parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("ItemKey", cacheKey);
            parameters[1] = new SqlParameter("ItemValue", value);
            parameters[2] = new SqlParameter("ItemType", itemType);
            parameters[3] = new SqlParameter("ExpiryTime", expiryTime);
            await this.ExecuteNonQuery(StoreProcedure.UpsertCacheValues, parameters);
        }
        public async Task<string> GetCacheAsync(string cacheKey)
        {
            string cacheValue = string.Empty;
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("ItemKey", cacheKey);
            var result = await this.ExecuteScalar(StoreProcedure.GetCacheValues, parameters);
            if (result != null)
            {
                cacheValue = result.ToString();
            }
            return cacheValue;
        }
        public async Task InvalidateCacheAsync(string cacheKey)
        {
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("ItemKey", cacheKey);
            await this.ExecuteNonQuery(StoreProcedure.DeleteCacheValues, parameters);
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Roles;
using Microsoft.AspNetCore.Identity;
namespace HPi.Pulsar.Infrastructure.Repository
{
    public class UserRoleRepository : BaseRepository, IUserRoleStore<ApplicationUser>
    {
        public UserRoleRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }
        #region UserRole
        public async Task AddToRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("NtName", user.UserName);
            parameters[1] = new SqlParameter("RoleName", roleName);
            await this.ExecuteNonQuery(StoreProcedure.AddToRole, parameters);
        }
        public async Task<IList<string>> GetRolesAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            IList<string> roles = new List<string>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("NtName", user.UserName);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetRoles, parameters))
            {
                if (dataReader.HasRows)
                {
                    while (await dataReader.ReadAsync().ConfigureAwait(false))
                    {
                        string role = dataReader["RoleName"] != DBNull.Value ? (string)dataReader["RoleName"] : String.Empty;
                        roles.Add(role);
                    }
                }
            }
            return roles;
        }
        public async Task<IList<ApplicationUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken)
        {
            IList<ApplicationUser> users = new List<ApplicationUser>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("RoleName", roleName);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetUsersInRole, parameters))
            {
                if (dataReader.HasRows)
                {
                    while (await dataReader.ReadAsync().ConfigureAwait(false))
                    {
                        ApplicationUser user = new ApplicationUser();
                        user.UserId = dataReader["UserId"] != DBNull.Value ? (int)dataReader["UserId"] : default(int);
                        user.NtDomain = dataReader["NtDomain"] != DBNull.Value ? (string)dataReader["NtDomain"] : String.Empty;
                        user.NtName = dataReader["NtName"] != DBNull.Value ? (string)dataReader["NtName"] : String.Empty;
                        user.EmployeeNo = dataReader["EmployeeNo"] != DBNull.Value ? (string)dataReader["EmployeeNo"] : String.Empty;
                        user.FirstName = dataReader["FirstName"] != DBNull.Value ? (string)dataReader["FirstName"] : String.Empty;
                        user.LastName = dataReader["LastName"] != DBNull.Value ? (string)dataReader["LastName"] : String.Empty;
                        user.Email = dataReader["Email"] != DBNull.Value ? (string)dataReader["Email"] : String.Empty;
                        user.Phone = dataReader["Phone"] != DBNull.Value ? (string)dataReader["Phone"] : String.Empty;
                        user.City = dataReader["City"] != DBNull.Value ? (string)dataReader["City"] : String.Empty;
                        user.State = dataReader["State"] != DBNull.Value ? (string)dataReader["State"] : String.Empty;
                        user.Country = dataReader["Country"] != DBNull.Value ? (string)dataReader["Country"] : String.Empty;
                        users.Add(user);
                    }
                }
            }
            return users;
        }
        public async Task<bool> IsInRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            bool success = false;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("NtName", user.UserName);
            parameters[1] = new SqlParameter("RoleName", roleName);
            var isInRole = await ExecuteScalar(StoreProcedure.IsInRole, parameters);
            success = Convert.ToInt32(isInRole) > 0 ? true : false;
            return success;
        }
        public async Task RemoveFromRoleAsync(ApplicationUser user, string roleName, CancellationToken cancellationToken)
        {
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("NtName", user.UserName);
            parameters[1] = new SqlParameter("RoleName", roleName);
            await this.ExecuteNonQuery(StoreProcedure.RemoveFromRole, parameters);
        }
        #endregion
        #region UserStore
        public Task<IdentityResult> CreateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<IdentityResult> DeleteAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<ApplicationUser> FindByIdAsync(string userId, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<ApplicationUser> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<string> GetNormalizedUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<string> GetUserIdAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<string> GetUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task SetNormalizedUserNameAsync(ApplicationUser user, string normalizedName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task SetUserNameAsync(ApplicationUser user, string userName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<IdentityResult> UpdateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        #endregion
        public void Dispose()
        {
        }
    }
}

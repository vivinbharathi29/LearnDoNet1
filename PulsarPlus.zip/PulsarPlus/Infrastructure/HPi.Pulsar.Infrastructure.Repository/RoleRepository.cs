﻿using System;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Roles;
using Microsoft.AspNetCore.Identity;
namespace HPi.Pulsar.Infrastructure.Repository
{
    public class RoleRepository : BaseRepository, IRoleStore<ApplicationRole>
    {
        public RoleRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }
        public async Task<IdentityResult> CreateAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("RoleId", role.RoleId);
            parameters[1] = new SqlParameter("RoleName", role.RoleName);
            parameters[2] = new SqlParameter("Description", role.Description);
            parameters[3] = new SqlParameter("CreatedBy", role.CreatedBy);
            await this.ExecuteNonQuery(StoreProcedure.CreateRole, parameters);
            return IdentityResult.Success;
        }
        public async Task<IdentityResult> UpdateAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("RoleId", role.RoleId);
            parameters[1] = new SqlParameter("RoleName", role.RoleName);
            parameters[2] = new SqlParameter("Description", role.Description);
            parameters[3] = new SqlParameter("UpdatedBy", role.UpdatedBy);
            await this.ExecuteNonQuery(StoreProcedure.UpdateRole, parameters);
            return IdentityResult.Success;
        }
        public async Task<IdentityResult> DeleteAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("RoleId", Convert.ToInt32(role.RoleId));
            await this.ExecuteNonQuery(StoreProcedure.DeleteRole, parameters);
            return IdentityResult.Success;
        }
        public async Task<ApplicationRole> FindByIdAsync(string roleId, CancellationToken cancellationToken)
        {
            ApplicationRole applicationRole = null;
            var parameter = new SqlParameter[1];
            parameter[0] = new SqlParameter("RoleId", Convert.ToInt32(roleId));
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetRoleById, parameter))
            {
                if (dataReader.HasRows)
                {
                    while (await dataReader.ReadAsync().ConfigureAwait(false))
                    {
                        applicationRole = new ApplicationRole();
                        applicationRole.RoleName = dataReader["RoleName"] != DBNull.Value ? (string)dataReader["RoleName"] : String.Empty;
                        applicationRole.RoleId = dataReader["RoleId"] != DBNull.Value ? (int)dataReader["RoleId"] : default(int);
                    }
                }
            }
            return applicationRole;
        }
        #region Not Implemented Methods
        public void Dispose()
        {
        }
        public Task<ApplicationRole> FindByNameAsync(string normalizedRoleName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<string> GetNormalizedRoleNameAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<string> GetRoleIdAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task<string> GetRoleNameAsync(ApplicationRole role, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task SetNormalizedRoleNameAsync(ApplicationRole role, string normalizedName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public Task SetRoleNameAsync(ApplicationRole role, string roleName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}

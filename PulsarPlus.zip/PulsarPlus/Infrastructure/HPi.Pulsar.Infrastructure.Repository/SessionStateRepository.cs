﻿using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.SessionState;
namespace HPi.Pulsar.Infrastructure.Repository
{
    public class SessionStateRepository : BaseRepository, ISessionStateRepository
    {
        public SessionStateRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }
        #region Public Methods
        public async Task SetAsync(string sessionGUID, string key, string value, string itemType)
        {
            var parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("SessionGuid", sessionGUID);
            parameters[1] = new SqlParameter("ItemKey", key);
            parameters[2] = new SqlParameter("ItemValue", value);
            parameters[3] = new SqlParameter("ItemType", itemType);
            await this.ExecuteNonQuery(StoreProcedure.UpsertSessionValues, parameters);
        }
        public async Task<string> GetAsync(string sessionGUID, string key)
        {
            string sessionValue = string.Empty;
            var parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("SessionGuid", sessionGUID);
            parameters[1] = new SqlParameter("ItemKey", key);
            var result = await this.ExecuteScalar(StoreProcedure.GetSessionValues, parameters);
            if (result != null)
            {
                sessionValue = result.ToString();
            }
            return sessionValue;
        }
        #endregion
    }
}

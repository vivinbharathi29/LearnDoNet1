﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Notification;
namespace HPi.Pulsar.Infrastructure.Repository
{
    public class NotificationRepository : BaseRepository, INotificationRepository
    {
        public NotificationRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }
        public async Task<EmailModel> GetEmailTemplateAsync(int templateId)
        {
            EmailModel emailModel = new EmailModel();
            Dictionary<string, string> emailParameters = new Dictionary<string, string>();
            var parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("p_intEmailID", templateId);
            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.GetEmailTemplate, parameters))
            {
                if (dataReader.HasRows)
                {
                    while (await dataReader.ReadAsync().ConfigureAwait(false))
                    {
                        emailModel.Body = dataReader["Body"] != System.DBNull.Value ? Convert.ToString(dataReader["Body"]) : default(string);
                        emailModel.Subject = dataReader["Subject"] != System.DBNull.Value ? Convert.ToString(dataReader["Subject"]) : default(string);
                    }
                }
            }
            return emailModel;
        }        

        public async Task<int> SendEmailAsync(string emailFrom, string emailToRecipients, string emailToCc, string emailToBcc,string emailSubject, string emailBody)
        {            
            int rowsAffected = 0;
            var parameters = new SqlParameter[8];
            parameters[0] = new SqlParameter("From", emailFrom);
            parameters[1] = new SqlParameter("FromName", "");
            parameters[2] = new SqlParameter("To", emailToRecipients);
            parameters[3] = new SqlParameter("ToName", "");
            parameters[4] = new SqlParameter("Cc", string.IsNullOrWhiteSpace(emailToCc) ? "" : emailToCc);
            parameters[5] = new SqlParameter("Bcc", string.IsNullOrWhiteSpace(emailToBcc) ? "" : emailToBcc);
            parameters[6] = new SqlParameter("Subject", emailSubject);
            parameters[7] = new SqlParameter("Body", emailBody);
            rowsAffected = await this.ExecuteNonQuery(StoreProcedure.AddMessageQueuedEmail, parameters);
            return rowsAffected;
        }
    }
}

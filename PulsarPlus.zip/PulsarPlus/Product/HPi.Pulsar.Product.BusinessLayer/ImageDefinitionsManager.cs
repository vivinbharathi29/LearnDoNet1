using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ImageDefinitionsManager : BaseManager<IImageDefinitionsRepository>, IImageDefinitionsService
    {
        public ImageDefinitionsManager(IApplicationServices applicationService, IImageDefinitionsRepository imageDefinitionsRepository) : base(applicationService, imageDefinitionsRepository)
        {
        }

        public async Task<ImageDefinitionModel[]> GetImageForProductRolloutAsync(int productId, int? productVersionReleaseId, PaginationModel pagination)
        {
            return await this.Repository.GetImageForProductRolloutAsync(productId, productVersionReleaseId, pagination).ConfigureAwait(false);
        }

        public async Task<ImageDefinitionModel[]> GetImageForProductLegacyRolloutAsync(int productId, PaginationModel pagination)
        {
            return await this.Repository.GetImageForProductLegacyRolloutAsync(productId,  pagination).ConfigureAwait(false);
        }
    }
}
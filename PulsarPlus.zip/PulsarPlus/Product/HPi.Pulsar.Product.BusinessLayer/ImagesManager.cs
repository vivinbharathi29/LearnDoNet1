using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ImagesManager : BaseManager<IImagesRepository>, IImagesService
    {
        public ImagesManager(IApplicationServices applicationService, IImagesRepository imagesRepository) : base(applicationService, imagesRepository)
        {
        }

        public async Task<ImageModel[]> GetImageAsync(int imageDefId)
        {
            return await this.Repository.GetImageAsync(imageDefId).ConfigureAwait(false);
        }

        public async Task<string> GetRolloutDateAsync(int productId, int priority, string dash, int? imageDefId)
        {
            return await this.Repository.GetRolloutDateAsync(productId, priority, dash, imageDefId).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateImageRampPlanAsync(ImageModel[] imageDetails)
        {
            return await this.Repository.TryUpdateImageRampPlanAsync(imageDetails).ConfigureAwait(false);
        }
    }
}
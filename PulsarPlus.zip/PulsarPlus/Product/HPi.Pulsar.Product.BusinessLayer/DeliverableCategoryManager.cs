using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DeliverableCategoryManager : BaseManager<IDeliverableCategoryRepository>, IDeliverableCategoryService
    {
        public DeliverableCategoryManager(IApplicationServices applicationService, IDeliverableCategoryRepository deliverableCategoryRepository) : base(applicationService, deliverableCategoryRepository)
        {
        }

        public async Task<DeliverableCategoryModel[]> GetDeliverableCategoryAvPrefixValuesAsync()
        {
            return await this.Repository.GetDeliverableCategoryAvPrefixValuesAsync().ConfigureAwait(false);
        }

        public async Task<DeliverableCategoryModel[]> GetDeliverableCategoriesByTypeAsync(int? typeId)
        {
            return await this.Repository.GetDeliverableCategoriesByTypeAsync(typeId).ConfigureAwait(false);
        }

        #region ProductDeliverables
        public async Task<DeliverableCategoryModel[]> GetHWCategoriesAsync()
        {
            return await this.Repository.GetHWCategoriesAsync().ConfigureAwait(false);
        }
        #endregion

        public async Task<DeliverableCategoryModel> GetListCategoryAsync(int id)
        {
            return await this.Repository.GetListCategoryAsync(id).ConfigureAwait(false);
        }

        public async Task<DeliverableCategoryModel[]> GetSelectCatListAsync()
        {
            return await this.Repository.GetSelectCatListAsync().ConfigureAwait(false);
        }
    }
}
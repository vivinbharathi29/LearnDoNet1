using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class SupportArticleManager : BaseManager<ISupportArticleRepository>, ISupportArticleService
    {
        public SupportArticleManager(IApplicationServices applicationService, ISupportArticleRepository supportArticleRepository) : base(applicationService, supportArticleRepository)
        {
        }

        #region GetSupportArticle
        public async Task<SupportArticleModel[]> GetSupportArticleAsync(SupportArticleModel supportArticle)
        {
            return await this.Repository.GetSupportArticleAsync(supportArticle);
        }
        #endregion
    }
}
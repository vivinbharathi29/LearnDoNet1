using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class EmployeeManager : BaseManager<IEmployeeRepository>, IEmployeeService
    {
        public EmployeeManager(IApplicationServices applicationService, IEmployeeRepository employeeRepository, ICacheService cacheService) : base(applicationService, employeeRepository)
        {
            this.CacheService = cacheService;
        }

        protected ICacheService CacheService { get; set; }

        #region SystemRoles
        public async Task<EmployeeModel[]> GetSystemTeamAsync(int? prodId)
        {
            return await this.Repository.GetSystemTeamAsync(prodId).ConfigureAwait(false);
        }
        #endregion

        #region SystemRolesDetails
        public async Task<EmployeeModel[]> GetSystemTeamDetailsAsync(int? prodId)
        {
            return await this.Repository.GetSystemTeamDetailsAsync(prodId).ConfigureAwait(false);
        }
        #endregion

        public async Task<EmployeeModel[]> GetToolsProjectOwnersAsync(int productID)
        {
            EmployeeModel[] employee = null;
            string key = "toolsprojectowners_" + productID;
            int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
            employee = await this.CacheService.GetCacheAsync<EmployeeModel[]>(key, true).ConfigureAwait(false);
            if (employee == null)
            {
                employee = await this.Repository.GetToolsProjectOwnersAsync(productID).ConfigureAwait(false);
                if (employee != null)
                {
                    await this.CacheService.SetCacheAsync<EmployeeModel[]>(key, employee, expiryTime, employee.GetType().Name, true).ConfigureAwait(false);
                }
            }

            return employee;
        }

		public async Task<EmployeeModel[]> GetToolsPMsAsync()
        {
            EmployeeModel[] employee = null;
            string key = "toolspm";
            int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
            employee = await this.CacheService.GetCacheAsync<EmployeeModel[]>(key, true).ConfigureAwait(false);
            if (employee == null)
            {
                employee = await this.Repository.GetToolsPMsAsync().ConfigureAwait(false);
                if (employee != null)
                {
                    await this.CacheService.SetCacheAsync<EmployeeModel[]>(key, employee, expiryTime, employee.GetType().Name, true).ConfigureAwait(false);
                }
            }

            return employee;
        }

        public async Task<EmployeeModel> GetEmployeeByIdAsync(int id)
        {
            return await this.Repository.GetEmployeeByIdAsync(id).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetDeliverableDeveloperAsync(int versionID)
        {
            return await this.Repository.GetDeliverableDeveloperAsync(versionID).ConfigureAwait(false);
        }

        public async Task<UserInfoModel[]> GetAllCommodityPMsForVersionAsync(int versionID)
        {
            return await this.Repository.GetAllCommodityPMsForVersionAsync(versionID).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetAllHardwarePMsForVersionAsync(int versionId)
        {
            return await this.Repository.GetAllHardwarePMsForVersionAsync(versionId).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetAllTestLeadsAsync(bool isSELeadTest, bool isWWANLeadTest, bool isODMLeadTest, bool? isCacheRequired)
        {
            EmployeeModel[] employee = null;
            if (isCacheRequired == true)
            {
                string key = "employee_" + isSELeadTest + "_" + isWWANLeadTest + "_" + isODMLeadTest;
                int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
                employee = await this.CacheService.GetCacheAsync<EmployeeModel[]>(key, true).ConfigureAwait(false);
                if (employee == null)
                {
                    employee = await this.Repository.GetAllTestLeadsAsync(isSELeadTest, isWWANLeadTest, isODMLeadTest, isCacheRequired).ConfigureAwait(false);
                    if (employee != null)
                    {
                        await this.CacheService.SetCacheAsync<EmployeeModel[]>(key, employee, expiryTime, employee.GetType().Name, true).ConfigureAwait(false);
                    }
                }
            }
            else
            {
                employee = await this.Repository.GetAllTestLeadsAsync(isSELeadTest, isWWANLeadTest, isODMLeadTest, isCacheRequired).ConfigureAwait(false);
            }
            return employee;
        }

        public async Task<EmployeeModel[]> GetExecutionEngineersAsync(int versionId)
        {
            return await this.Repository.GetExecutionEngineersAsync(versionId).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetTestleadsForVersionAsync(int id)
        {
            return await this.Repository.GetTestleadsForVersionAsync(id).ConfigureAwait(false);
        }

        #region GetEmployee
        public async Task<UserInfoModel> GetEmployeeAsync(int? employeeID, int isAdmin)
        {
            return await this.Repository.GetEmployeeAsync(employeeID, isAdmin).ConfigureAwait(false);
        }
        #endregion

        #region GetAllCommodityPMs
        public async Task<EmployeeModel[]> GetAllCommodityPMsAsync(int reportId)
        {
            return await this.Repository.GetAllCommodityPMsAsync(reportId).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetEmployeesProgramCommodityAsync(int type, string commodityPMsList, int? partnerId)
        {
            return await this.Repository.GetEmployeesProgramCommodityAsync(type, commodityPMsList, partnerId).ConfigureAwait(false);
        }
        #endregion

        #region ProductDeliverables
        public async Task<EmployeeModel[]> GetDeliverableVersionDevelopersAsync()
        {
            return await this.Repository.GetDeliverableVersionDevelopersAsync().ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetDeliverableRootDevManagersAsync()
        {
            return await this.Repository.GetDeliverableRootDevManagersAsync().ConfigureAwait(false);
        }
		public async Task<EmployeeModel[]> GetCommodityPMsAsync()
        {
            return await this.Repository.GetCommodityPMsAsync().ConfigureAwait(false);
        }
        #endregion

        public async Task<EmployeeModel> GetPMAsync(int ProductId)
        {
            return await this.Repository.GetPMAsync(ProductId).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetSystemTeamApproversAsync(int productVersionId)
        {
            return await this.Repository.GetSystemTeamApproversAsync(productVersionId).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetProductDcrApproversAsync(int productVersionId)
        {
            return await this.Repository.GetProductDcrApproversAsync(productVersionId).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetDeliverableRootScrApproversAsync(int deliverableRootId)
        {
            return await this.Repository.GetDeliverableRootScrApproversAsync(deliverableRootId).ConfigureAwait(false);
        }

        #region System Teams
        public async Task<EmployeeModel[]> GetPmViewSystemTeamAsync(int productVersionId, byte isAllEmployees, byte isAddBios, bool? isCacheRequired)
        {
            EmployeeModel[] employee = null;
            if (isCacheRequired == true)
            {
                string key = "employee_" + productVersionId + "_" + isAllEmployees + "_" + isAddBios;
                int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
                employee = await this.CacheService.GetCacheAsync<EmployeeModel[]>(key, true).ConfigureAwait(false);
                if (employee == null)
                {
                    employee = await this.Repository.GetPmViewSystemTeamAsync(productVersionId, isAllEmployees, isAddBios, isCacheRequired).ConfigureAwait(false);
                    if (employee != null)
                    {
                        await this.CacheService.SetCacheAsync<EmployeeModel[]>(key, employee, expiryTime, employee.GetType().Name, true).ConfigureAwait(false);
                    }
                }
            }
            else
            {
                employee = await this.Repository.GetPmViewSystemTeamAsync(productVersionId, isAllEmployees, isAddBios, isCacheRequired).ConfigureAwait(false);
            }
            return employee;
        }
        #endregion

        public async Task<ImpersonateUserModel> GetEmployeesWithPaginationAsync(string employeeType, int? impersonateId, int pageNo, int pageSize, int? ownerId, int currentUserId, int? id)
        {
            return await this.Repository.GetEmployeesWithPaginationAsync(employeeType, impersonateId, pageNo, pageSize, ownerId, currentUserId, id).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetEmployeeEmailDetailsAsync(EmployeeModel employeeInfo)
        {
            return await this.Repository.GetEmployeeEmailDetailsAsync(employeeInfo).ConfigureAwait(false);
        }

        public async Task<EmployeeModel[]> GetEmployeesAsync(int impersonateId)
        {
            return await this.Repository.GetEmployeesAsync(impersonateId).ConfigureAwait(false);
        }
    }
}
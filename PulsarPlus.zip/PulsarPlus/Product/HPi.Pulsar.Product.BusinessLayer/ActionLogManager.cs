using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ActionLogManager : BaseManager<IActionLogRepository>, IActionLogService
    {
        public ActionLogManager(IApplicationServices applicationService, IActionLogRepository actionLogRepository) : base(applicationService, actionLogRepository)
        {
        }

        public async Task<bool> TryAddActionLogAsync(ActionLogModel ActionLog)
        {
            return await this.Repository.TryAddActionLogAsync(ActionLog).ConfigureAwait(false);
        }

		public async Task<bool> TryInsertLogDeliverableUpdateAsync(ActionLogModel actionLog)
        {
            return await this.Repository.TryInsertLogDeliverableUpdateAsync(actionLog).ConfigureAwait(false);
        }
    }
}
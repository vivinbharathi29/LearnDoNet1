using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ActionStatusManager : BaseManager<IActionStatusRepository>, IActionStatusService
    {
        public ActionStatusManager(IApplicationServices applicationService, IActionStatusRepository actionStatusRepository) : base(applicationService, actionStatusRepository)
        {
        }

        public async Task<ActionStatusModel[]> GetActionStatusesByTypeAsync(int type)
        {
            return await this.Repository.GetActionStatusesByTypeAsync(type).ConfigureAwait(false);
        }
    }
}
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ProductBrandManager : BaseManager<IProductBrandRepository>, IProductBrandService
    {
        public ProductBrandManager(IApplicationServices applicationService, IProductBrandRepository productBrandRepository) : base(applicationService, productBrandRepository)
        {
        }

        public async Task<AVDescriptionModel[]> GetAVNoDescriptionsAsync(int productVersionID, int productBrandID, int scmCategoryID)
        {
            return await this.Repository.GetAVNoDescriptionsAsync(productVersionID, productBrandID, scmCategoryID);
        }

        public async Task<bool> TryUpdateAvDetailFeatureIDAsync(AVDetailModel avDetailModel)
        {
            return await this.Repository.TryUpdateAvDetailFeatureIdAsync(avDetailModel);
        }

        public async Task<ProductBrandModel[]> GetImageDefinitionBrandsAsync(int productId, int? imageDefinitionId)
        {
            return await this.Repository.GetImageDefinitionBrandsAsync(productId, imageDefinitionId);
        }

        public async Task<bool> TryImageAddObsoleteLocalizedAVAsync(int imageActionItemId, int productVersionId, int productBrandId, int actionType, string updatedBy)
        {
            return await this.Repository.TryImageAddObsoleteLocalizedAvAsync(imageActionItemId, productVersionId, productBrandId, actionType, updatedBy);
        }

        public async Task<ProductBrandModel[]> GetBaseUnitAvailability(int pvId, int bId, int avId)
        {
            return await this.Repository.GetBaseUnitAvailabilityAsync(pvId, bId, avId);
        }


        public async Task<PmasterProductModel[]> GetPlatformSOARProdDescAsync()
        {
            return await this.Repository.GetPlatformSOARProdDescAsync();
        }

        public async Task<FormFactorTouchModel[]> GetFormFactorTouchAsync()
        {
            return await this.Repository.GetFormFactorTouchAsync();
        }

    }
}

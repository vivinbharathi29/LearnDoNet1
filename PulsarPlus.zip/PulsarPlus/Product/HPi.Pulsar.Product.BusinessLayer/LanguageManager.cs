using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class LanguageManager : BaseManager<ILanguageRepository>, ILanguageService
    {
        public LanguageManager(IApplicationServices applicationService, ILanguageRepository languageRepository) : base(applicationService, languageRepository)
        {
        }

        public async Task<LanguageModel[]> GetLanguagesAsync()
        {
            return await this.Repository.GetLanguagesAsync().ConfigureAwait(false);
        }

        public async Task<LanguageModel[]> GetCountriesAsync(int? optionId, string optionName, string list, PaginationModel pagination)
        {
            return await this.Repository.GetCountriesAsync(optionId, optionName, list, pagination).ConfigureAwait(false);
        }
    }
}
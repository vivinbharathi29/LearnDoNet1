using System;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;
namespace HPi.Pulsar.Product.BusinessLayer
{
    public class PilotStatusManager : BaseManager<IPilotStatusRepository>, IPilotStatusService
    {
        public PilotStatusManager(IApplicationServices applicationService, IPilotStatusRepository pilotStatusRepository) : base(applicationService, pilotStatusRepository)
        {
        }

        public async Task<PilotStatusModel[]> GetAllPilotStatusesAsync()
        {
            return await this.Repository.GetAllPilotStatusesAsync();
        }

        public async Task<int> UpdatePilotStatusAsync(int id, int statusID, int userID, string userName, string comments, DateTime pilotDate)
        {
            return await this.Repository.UpdatePilotStatusAsync(id, statusID, userID, userName, comments, pilotDate);
        }

        public async Task<PilotStatusModel[]> GetPilotStatusListAsync()
        {
            return await this.Repository.GetPilotStatusListAsync();
        }

        public async Task<int> UpdatePilotStatusPulsarAsync(int id, int statusID, int userID, string userName, string comments, DateTime pilotDate)
        {
            return await this.Repository.UpdatePilotStatusPulsarAsync(id, statusID, userID, userName, comments, pilotDate);
        }
    }
}

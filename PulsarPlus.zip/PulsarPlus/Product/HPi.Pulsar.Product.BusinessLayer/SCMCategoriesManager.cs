using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class SCMCategoriesManager : BaseManager<ISCMCategoriesRepository>, ISCMCategoriesService
    {
        public SCMCategoriesManager(IApplicationServices applicationService, ISCMCategoriesRepository sCMCategoriesRepository) : base(applicationService, sCMCategoriesRepository)
        {
        }

        public async Task<ScmCategoryModel[]> GetSCMCategoriesProductLinesAsync()
        {
            return await this.Repository.GetSCMCategoriesProductLinesAsync();
        }

        public async Task<ScmCategoryModel> GetScmCategoryAsync(int productBrandId, int scmCategoryId)
        {
            return await this.Repository.GetScmCategoryAsync(productBrandId, scmCategoryId);
        }

        public async Task<bool> TryUpdateScmCategoryAsync(int productBrandId, int scmCategoryId, string configRules, string manufacturingNotes, string marketingDescription, int? categoryMin, int? categoryMax, string userName, string retMsg, string rulesSyntax)
        {
            return await this.Repository.TryUpdateScmCategoryAsync(productBrandId, scmCategoryId, configRules, manufacturingNotes, marketingDescription, categoryMin, categoryMax, userName, retMsg, rulesSyntax);
        }

        public async Task<ScmCategoryModel[]> GetSCMCategoriesAsync(int? catId)
        {
            return await this.Repository.GetSCMCategoriesAsync(catId);
        }
    }
}

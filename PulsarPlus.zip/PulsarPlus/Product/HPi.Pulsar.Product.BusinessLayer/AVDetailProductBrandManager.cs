using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class AVDetailProductBrandManager : BaseManager<IAVDetailProductBrandRepository>, IAVDetailProductBrandService
    {
        public AVDetailProductBrandManager(IApplicationServices applicationService, IAVDetailProductBrandRepository aVDetailProductBrandRepository) : base(applicationService, aVDetailProductBrandRepository)
        {
        }

        #region AV Detail ProductBrand Pulsar
        public async Task<string> UpdateAVDetailProductBrandPulsarAsync(AVDetailProductBrandModel avDetailProductBrand)
        {
            return await this.Repository.UpdateAVDetailProductBrandPulsarAsync(avDetailProductBrand).ConfigureAwait(false);
        }
        #endregion

        #region Base Unit for AVDetails
        public async Task<AVDetailProductBrandModel[]> GetAVDetailBaseUnitsAsync(int productVersionId, int brandId, int avDetailId)
        {
            return await this.Repository.GetAVDetailBaseUnitsAsync(productVersionId, brandId, avDetailId).ConfigureAwait(false);
        }
        #endregion

        public async Task<AVDetailProductBrandModel[]> GetAvsNotInKmatBomAsync(int? productBrandId)
        {
            return await this.Repository.GetAvsNotInKmatBomAsync(productBrandId).ConfigureAwait(false);
        }

        public async Task<AVDetailProductBrandModel[]> GetLogHistoryAsync(int brandId, int showAll, PaginationModel pagination)
        {
            return await this.Repository.GetLogHistory(brandId, showAll, pagination).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateAvHistoryAsync(string AVHistoryId, string showOnScm, string showOnPm, string updatedUser)
        {
            return await this.Repository.TryUpdateAvHistoryAsync(AVHistoryId, showOnScm, showOnPm, updatedUser).ConfigureAwait(false);
        }

        public async Task<AVDetailProductBrandModel[]> GetUnreleasedAvsAsync(int? productBrandId)
        {
            return await this.Repository.GetUnreleasedAvsAsync(productBrandId).ConfigureAwait(false);
        }
    }
}
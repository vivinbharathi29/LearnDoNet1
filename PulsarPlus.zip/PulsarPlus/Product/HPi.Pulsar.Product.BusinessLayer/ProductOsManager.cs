using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductOsManager : BaseManager<IProductOsRepository>, IProductOsService
    {
        public ProductOsManager(IApplicationServices applicationService, IProductOsRepository productOsRepository) : base(applicationService, productOsRepository)
        {
        }

        public async Task<OSLookupModel[]> GetProductOSByIdAsync(int productId, int type)
        {
            return await this.Repository.GetProductOSByIdAsync(productId, type);
        }

        public async Task<bool> TryUpdateProductOSAsync(ProductOSModel[] productOSDetails)
        {
            return await this.Repository.TryUpdateProductOsAsync(productOSDetails);
        }

    }
}

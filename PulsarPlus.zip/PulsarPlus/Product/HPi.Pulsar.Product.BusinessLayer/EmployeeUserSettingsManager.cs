using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class EmployeeUserSettingsManager : BaseManager<IEmployeeUserSettingsRepository>, IEmployeeUserSettingsService
    {
        public EmployeeUserSettingsManager(IApplicationServices applicationService, IEmployeeUserSettingsRepository employeeUserSettingsRepository) : base(applicationService, employeeUserSettingsRepository)
        {
        }

        #region ProductDeliverables
        public async Task<EmployeeUserSettingModel> GetUserSettingAsync(int employeeId, int userSettingsId)
        {
            return await this.Repository.GetUserSettingAsync(employeeId, userSettingsId).ConfigureAwait(false);
        }
        #endregion
        public async Task<int> DeleteDefaultProductFilterAsync(int employeeId, int userSettingsId)
        {
            return await this.Repository.DeleteDefaultProductFilterAsync(employeeId, userSettingsId).ConfigureAwait(false);
        }

        public async Task<EmployeeUserSettingModel> UpdateEmployeeUserSettingAsync(int employeeId, int userSettingsId, string sSettings)
        {
            return await this.Repository.UpdateEmployeeUserSettingAsync(employeeId, userSettingsId, sSettings).ConfigureAwait(false);
        }

        public async Task<EmployeeUserSettingModel> GetEmployeeUserSettingsAsync(int employeeId, int userSettingsId)
        {
            return await this.Repository.GetEmployeeUserSettingsAsync(employeeId, userSettingsId).ConfigureAwait(false);
        }

        public async Task<EmployeeUserSettingModel> GetEmployeeUserSettingAsync(int employeeId)
        {
            return await this.Repository.GetEmployeeUserSettingAsync(employeeId).ConfigureAwait(false);
        }
    }
}
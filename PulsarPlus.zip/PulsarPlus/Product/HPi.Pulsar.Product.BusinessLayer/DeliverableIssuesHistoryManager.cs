﻿namespace HPi.Pulsar.Product.BusinessLayer
{
    using System.Threading.Tasks;
    using Infrastructure.BaseClass;
    using Contracts.Repositories;
    using Contracts.Services;
    using Infrastructure.Contracts.ApplicationServices;
    using Contracts;

    /// <summary>
    /// DeliverableIssuesHistoryManager
    /// </summary>
    public class DeliverableIssuesHistoryManager : BaseManager<IDeliverableIssuesHistoryRepository>, IDeliverableIssuesHistoryService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeliverableIssuesHistoryManager"/> class.
        /// </summary>
        /// <param name="applicationService">The applicationService.</param>
        /// <param name="deliverableIssuesHistoryRepository">The deliverableIssuesHistoryRepository.</param>
        public DeliverableIssuesHistoryManager(IApplicationServices applicationService, IDeliverableIssuesHistoryRepository deliverableIssuesHistoryRepository) : base(applicationService, deliverableIssuesHistoryRepository)
        {
        }
        
        public async Task<int> AddDeliverableIssuesHistory(DeliverableIssuesHistoryModel deliverableIssue)
        {
            return await this.Repository.AddDeliverableIssuesHistory(deliverableIssue);
        }
    }
}

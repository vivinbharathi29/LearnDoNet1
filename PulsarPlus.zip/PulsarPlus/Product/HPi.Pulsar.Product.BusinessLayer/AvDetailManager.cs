using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class AvDetailManager : BaseManager<IAvDetailRepository>, IAvDetailService
    {
        public AvDetailManager(IApplicationServices applicationService, IAvDetailRepository avDetailRepository) : base(applicationService, avDetailRepository)
        {
        }

        public async Task<AVDetailModel> GetAvDetailPulsarAsync(int productVersionId, int productBrandId, int avDetailId)
        {
            return await this.Repository.GetAvDetailPulsarAsync(productVersionId, productBrandId, avDetailId).ConfigureAwait(false);
        }

        public async Task<int> UpdateAvDetailPulsarAsync(AVDetailModel avDetails)
        {
            return await this.Repository.UpdateAvDetailPulsarAsync(avDetails).ConfigureAwait(false);
        }

        #region Insert AV Details Pulsar
        public async Task<int> InsertAVDetailPulsarAsync(AVDetailModel AVDetail)
        {
            return await this.Repository.InsertAVDetailPulsarAsync(AVDetail).ConfigureAwait(false);
        }
        #endregion

        #region SCM Change Feature For AV
        public async Task<bool> TryUpdateScmChangeFeatureAVAsync(AVDetailModel avDetail)
        {
            return await this.Repository.TryUpdateScmChangeFeatureAVAsync(avDetail).ConfigureAwait(false);
        }
        #endregion

        public async Task<AVDetailModel> GetProductReleaseOnAVAsync(int pbId, int avDetailId)
        {
            return await this.Repository.GetProductReleaseOnAVAsync(pbId, avDetailId).ConfigureAwait(false);
        }

        public async Task<string> GetAVNoAsync(int avDetailId)
        {
            return await this.Repository.GetAVNoAsync(avDetailId).ConfigureAwait(false);
        }
    }
}
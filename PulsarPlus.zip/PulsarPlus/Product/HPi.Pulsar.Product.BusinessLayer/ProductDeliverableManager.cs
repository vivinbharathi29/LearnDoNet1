using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductDeliverableManager : BaseManager<IProductDeliverableRepository>, IProductDeliverableService
    {
        public ProductDeliverableManager(IApplicationServices applicationService, IProductDeliverableRepository productDeliverableRepository) : base(applicationService, productDeliverableRepository)
        {
        }

        public async Task<bool> TryUpdateExceptionsAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryUpdateExceptionsAsync(productDeliverable);
        }

        public async Task<ProductDeliverableModel> GetTargetNotesAsync(int productId, int versionId)
        {
            return await this.Repository.GetTargetNotesAsync(productId, versionId);
        }

        #region IRSComponentProductUpdateList
        public async Task<ProductDeliverableModel[]> GetComponentsToPutInIRSProductDropAsync(IrsComponentModel irsComponent)
        {
            return await this.Repository.GetComponentsToPutInIRSProductDropAsync(irsComponent);
        }
        #endregion

        public async Task<ProductDeliverableModel> GetPilotStatusAsync(int productId, int versionId)
        {
            return await this.Repository.GetPilotStatusAsync(productId, versionId);
        }


        #region Product/Update Qualification Status for Multi Test Status
        public async Task<int> UpdateCommodityStatusAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.UpdateCommodityStatusAsync(productDeliverable);
        }


        #endregion

        #region AccessoryStatus
        public async Task<ProductDeliverableModel> GetAccessoryStatusAsync(int prodId, int versionId)
        {
            return await this.Repository.GetAccessoryStatusAsync(prodId, versionId);
        }

        public async Task<bool> TryUnlinkVersionFromProductAsync(int prodId, int deliverableId)
        {
            return await this.Repository.TryUnlinkVersionFromProductAsync(prodId, deliverableId);
        }

        public async Task<bool> TryUpdateAccessoryStatusAsync(AccessoryModel accessory)
        {
            return await this.Repository.TryUpdateAccessoryStatusAsync(accessory);
        }
        #endregion

        #region PilotStatus
        public async Task<ProductDeliverableReleaseModel[]> TryGetProductDeliverableReleasesAsync(int productID, int versionID, int productDeliverableReleaseID, int defaultReleaseID, string todayPageSection)
        {
            return await this.Repository.GetProductDeliverableReleasesAsync(productID, versionID, productDeliverableReleaseID, defaultReleaseID, todayPageSection);
        }

        public async Task<ProductDeliverableReleaseModel> TryGetPilotStatusReleaseAsync(int deliverableReleaseID)
        {
            return await this.Repository.GetPilotStatusReleaseAsync(deliverableReleaseID);
        }

        public async Task<int?> GetProductDefaultReleaseIdAsync(int productID)
        {
            return await this.Repository.GetProductDefaultReleaseIdAsync(productID);
        }

        public async Task<string> GetRSLQualStatusAsync(int deliverableVersionID, int productID)
        {
            return await this.Repository.GetRSLQualStatusAsync(deliverableVersionID, productID);
        }

        public async Task<ProductDeliverableModel> GetDevProductionReleaseEmailInfoAndPulsarAsync(string productDeliverableIds)
        {
            return await this.Repository.GetDevProductionReleaseEmailInfoAndPulsarAsync(productDeliverableIds);
        }
        #endregion

        #region Update Deliverable Status
        public async Task<ProductDeliverableModel> GetProductDeliverableSummaryByIdAsync(int productDeliverableId, int? productDeliverableReleaseID)
        {
            return await this.Repository.GetProductDeliverableSummaryByIdAsync(productDeliverableId, productDeliverableReleaseID);
        }

        public async Task<ProductDeliverableModel> GetDeveloperNotificationStatusAsync(int productDeliverableId, int? productDeliverableReleaseID)
        {
            return await this.Repository.GetDeveloperNotificationStatusAsync(productDeliverableId, productDeliverableReleaseID);
        }

        public async Task<ProductDeliverableModel> GetDeliverableVersionProductPMForEmailAsync(int productDeliverableId)
        {
            return await this.Repository.GetDeliverableVersionProductPMForEmailAsync(productDeliverableId);
        }

        public async Task<ProductDeliverableModel[]> GetDeliverableVersionProductPMForEmailWithMultipleAsync(string productDeliverableId)
        {
            return await this.Repository.GetDeliverableVersionProductPmForEmailWithMultipleAsync(productDeliverableId);
        }

        public async Task<int> UpdateDeveloperTestStatusAsync(ProductDeliverableModel productDeliverableData, int userId, string deliverableIds)
        {
            return await this.Repository.UpdateDeveloperTestStatusAsync(productDeliverableData, userId, deliverableIds);
        }
        #endregion

        #region UpdateDeveloperApproval
        public async Task<int> UpdateDeveloperApprovalAsync(ProductDeliverableModel productDeliverableData, int userId)
        {
            return await this.Repository.UpdateDeveloperApprovalAsync(productDeliverableData, userId);
        }

        #endregion

        #region AdvancedSupport
        public async Task<bool> TryLinkVersionToProductAsync(LinkProductModel linkVersionProductModel)
        {
            return await this.Repository.TryLinkVersionToProductAsync(linkVersionProductModel);
        }

        #endregion

        public async Task<bool> TryUnlinkVersionFromProductReleaseAsync(int productId, int deliverableId, int productDeliverableReleaseID)
        {
            return await this.Repository.TryUnlinkVersionFromProductReleaseAsync(productId, deliverableId, productDeliverableReleaseID);
        }

        public async Task<ProductDeliverableModel[]> GetAllVersionsForSupportingAsync(int productId, int rootId, int releaseId = 0)
        {
            return await this.Repository.GetAllVersionsForSupportingAsync(productId, rootId, releaseId);
        }

        public async Task<CommodityStatusModel> GetCommodityStatusAsync(int productId, int versionId)
        {
            return await this.Repository.GetCommodityStatusAsync(productId, versionId);
        }

        public async Task<CommodityStatusModel> GetCommodityStatusReleaseAsync(int productId, int versionId, int productDeliverableReleaseId)
        {
            return await this.Repository.GetCommodityStatusReleaseAsync(productId, versionId, productDeliverableReleaseId);
        }

        public async Task<TestStatusModel[]> GetTestStatusesAsync()
        {
            return await this.Repository.GetTestStatusesAsync();
        }

        public async Task<bool> TryUpdateCommodityStatusAsync(CommodityStatusModel commodityStatusModel)
        {
            return await this.Repository.TryUpdateCommodityStatusAsync(commodityStatusModel);
        }

        public async Task<bool> TryUpdateCommodityStatusReleaseAsync(CommodityStatusModel commodityStatusModel)
        {
            return await this.Repository.TryUpdateCommodityStatusReleaseAsync(commodityStatusModel);
        }


        #region CompareRootOnLeadProduct
        public async Task<ProductDeliverableModel[]> GetRequestedDeliverablesAsync(int leadId, int productId, string idList, int fusionRequirement)
        {
            return await this.Repository.GetRequestedDeliverablesAsync(leadId, productId, idList, fusionRequirement);
        }
        #endregion

        #region Update Developer Approval
        public async Task<ProductDeliverableModel[]> GetDeliverablesForMultiDevApprovalAsync(string productDeliverablIds, string productDeliverableReleaseIds, int? partnerId)
        {
            return await this.Repository.GetDeliverablesForMultiDevApprovalAsync(productDeliverablIds, productDeliverableReleaseIds, partnerId);
        }
        #endregion

        #region MultiUpdateTestStatus/ComponentTestLead
        public async Task<ProductDeliverableModel[]> GetProductDeliverableDetailsForComponentTestLeadAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.GetProductDeliverableDetailsForComponentTestLeadAsync(productDeliverable);
        }

        public async Task<bool> TryUpdateTestLeadStatusOnlyAsync(LinkProductModel linkProductModel)
        {
            return await this.Repository.TryUpdateTestLeadStatusOnlyAsync(linkProductModel);
        }

        public async Task<bool> TryUpdateTestLeadStatusOnlyPulsarAsync(LinkProductModel linkProductModel)
        {
            return await this.Repository.TryUpdateTestLeadStatusOnlyPulsarAsync(linkProductModel);
        }

        #endregion

        public async Task<ProductDeliverableModel[]> GetProductsForVersionAsync(int id)
        {
            return await this.Repository.GetProductsForVersionAsync(id);
        }

        #region View Lead Product Usage Exceptions
        public async Task<ProductDeliverableModel[]> GetLeadProductExceptionsAsync(int pmId)
        {
            return await this.Repository.GetLeadProductExceptionsAsync(pmId);
        }

        public async Task<int> UpdateLeadProductVersionAndRootExceptionAsync(int Id, string type)
        {
            return await this.Repository.UpdateLeadProductVersionAndRootExceptionAsync(Id, type);
        }
        #endregion

        #region AccessoryStatusPulsar
        public async Task<ProductDeliverableModel> GetAccessoryStatusPulsarAsync(int prodId, int versionId, int productDeliverableReleaseId)
        {
            return await this.Repository.GetAccessoryStatusPulsarAsync(prodId, versionId, productDeliverableReleaseId);
        }

        public async Task<bool> TryUpdateAccessoryStatusPulsarAsync(AccessoryModel accessoryModel)
        {
            return await this.Repository.TryUpdateAccessoryStatusPulsarAsync(accessoryModel);
        }
        #endregion

        public async Task<ProductDeliverableModel> GetTestLeadStatusAsync(int productId, int versionId, int fieldId)
        {
            return await this.Repository.GetTestLeadStatusAsync(productId, versionId, fieldId);
        }

        public async Task<bool> TryUpdateTestLeadStatusAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryUpdateTestLeadStatusAsync(productDeliverable);
        }

        public async Task<bool> TryAddSubassemblyLinkAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryAddSubassemblyLinkAsync(productDeliverable);
        }

        public async Task<bool> TryAddSubassemblyLinkReleaseAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryAddSubassemblyLinkReleaseAsync(productDeliverable);
        }

        public async Task<ProductDeliverableModel> GetSubassemblyBridgeAsync(int productId, int rootId)
        {
            return await this.Repository.GetSubassemblyBridgeAsync(productId, rootId);
        }

        public async Task<ProductDeliverableModel> GetSubassemblyBridgeReleaseAsync(int productId, int rootId)
        {
            return await this.Repository.GetSubassemblyBridgeReleaseAsync(productId, rootId);
        }


        public async Task<bool> TryRemoveSubassemblyLinkAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryRemoveSubassemblyLinkAsync(productDeliverable);
        }

        public async Task<ProductDeliverableModel[]> GetTargetDeliverableRootDetailsAsync(int productId, int rootId, int versionId)
        {
            return await this.Repository.GetTargetDeliverableRootDetailsAsync(productId, rootId, versionId);
        }

        public async Task<ProductDeliverableModel[]> GetVersionsForTargetingAsync(int productId, int rootId)
        {
            return await this.Repository.GetVersionsForTargetingAsync(productId, rootId);
        }

        public async Task<bool> TryUpdateTargetAdvancedAsync(List<ProductDeliverableModel> productDeliverable, int userId)
        {
            return await this.Repository.TryUpdateTargetAdvancedAsync(productDeliverable, userId);
        }

        public async Task<bool> TryGetLogReleaseToProductsAsync(int versionID, int employeeID)
        {
            return await this.Repository.TryGetLogReleaseToProductsAsync(versionID, employeeID);
        }


        public async Task<bool> TryRemoveSubassemblyLinkReleaseAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryRemoveSubassemblyLinkReleaseAsync(productDeliverable);
        }

        #region ChangeImages
        public async Task<bool> TryUpdateImageActualsAsync(ProductDeliverableModel ProductDeliverable)
        {
            return await this.Repository.TryUpdateImageActualsAsync(ProductDeliverable);
        }
        #endregion

        public async Task<ProductDeliverableModel[]> GetSubassembliesBridgedForRootReleaseAsync(int productID, int rootID, int releaseID)
        {
            return await this.Repository.GetSubassembliesBridgedForRootReleaseAsync(productID, rootID, releaseID);
        }

        public async Task<ProductDeliverableModel[]> GetListSubassembliesBridgedForRootAsync(int productID, int rootID)
        {
            return await this.Repository.GetListSubassembliesBridgedForRootAsync(productID, rootID);
        }

        public async Task<bool> TryUpdateTargetDeliverableVersionWebAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryUpdateTargetDeliverableVersionWebAsync(productDeliverable);
        }

        public async Task<ProductDeliverableModel> GetDistributionsAsync(int productId, int versionId, int rootId)
        {
            return await this.Repository.GetDistributionsAsync(productId, versionId, rootId);
        }

        public async Task<ProductDeliverableModel> GetDistributionsPulsarAsync(int productId, int versionId, int rootId, int releaseId)
        {
            return await this.Repository.GetDistributionsPulsarAsync(productId, versionId, rootId, releaseId);
        }

        public async Task<int> UpdateDistributionsAsync(ProductDeliverableModel productDeliverables)
        {
            return await this.Repository.UpdateDistributionsAsync(productDeliverables);
        }

        public async Task<int> UpdateCorrectImageSummaryAsync(int productId, int deliverableId, byte scope)
        {
            return await this.Repository.UpdateCorrectImageSummaryAsync(productId, deliverableId, scope);
        }

        public async Task<int> UpdateDistributionsPulsarAsync(ProductDeliverableModel productDeliverables)
        {
            return await this.Repository.UpdateDistributionsPulsarAsync(productDeliverables);
        }

        public async Task<ProductDeliverableModel[]> GetVersionExceptionsAsync(int productId, string versionIds, int releaseId)
        {
            return await this.Repository.GetVersionExceptionsAsync(productId, versionIds, releaseId);
        }

        public async Task<ProductDeliverableModel[]> GetLeadProductRootExceptionsAsync(int productId, int rootId, int releaseId)
        {
            return await this.Repository.GetLeadProductRootExceptionsAsync(productId, rootId, releaseId);
        }

        public async Task<bool> TryAddLeadProductVersionExceptionsAsync(List<ProductDeliverableModel> productDeliverable)
        {
            return await this.Repository.TryAddLeadProductVersionExceptionsAsync(productDeliverable);
        }

        public async Task<bool> TryUpdateLeadProductRootExceptionsAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryUpdateLeadProductRootExceptionsAsync(productDeliverable);
        }

        public async Task<bool> TryResetLeadProductRootExceptionsAsync(ProductDeliverableModel productDeliverable)
        {
            return await this.Repository.TryResetLeadProductRootExceptionsAsync(productDeliverable);
        }

        public async Task<ProductDeliverableModel> GetWhqlCountDetailsAsync(int productId)
        {
            return await this.Repository.GetWhqlCountDetailsAsync(productId);
        }

        public async Task<ProductDeliverableModel[]> GetWhqlVerifyDataAsync(int productId, PaginationModel pagination)
        {
            return await this.Repository.GetWhqlVerifyDataAsync(productId, pagination);
        }

        public async Task<ProductDeliverableModel[]> GetWhqlWithWaiverAsync(int productId, PaginationModel pagination)
        {
            return await this.Repository.GetWhqlWithWaiverAsync(productId, pagination);
        }

        public async Task<ProductDeliverableModel> GetMdaComplianceAsync(string productId)
        {
            return await this.Repository.GetMdaComplianceAsync(productId);
        }

        public async Task<ProductDeliverableModel[]> GetMdaComplianceDetailsAsync(string productId, PaginationModel pagination)
        {
            return await this.Repository.GetMdaComplianceDetailsAsync(productId, pagination);
        }

        public async Task<ProductDeliverableModel> GetDeliverableMdaComplianceAsync(string productId)
        {
            return await this.Repository.GetDeliverableMdaComplianceAsync(productId);
        }

        public async Task<ProductDeliverableModel[]> GetDeliverableMdaComplianceDetailsAsync(string productId, PaginationModel pagination)
        {
            return await this.Repository.GetDeliverableMdaComplianceDetailsAsync(productId, pagination);
        }

        public async Task<ProductDeliverableModel[]> GetProductsByVersionAsync(string productId, int mdaFlag)
        {
            return await this.Repository.GetProductsByVersionAsync(productId, mdaFlag);
        }
        public async Task<DeliverableLevelModel[]> GetDeliverableLevels(int typeId)
        {
            return await this.Repository.GetDeliverableLevelsAsync(typeId);
        }

        public async Task<bool> TryUpdateAdvancedSupportedProductToRootAsync(LinkProductModel linkVersionProductModel)
        {
            return await Repository.TryUpdateAdvancedSupportedProductToRootAsync(linkVersionProductModel).ConfigureAwait(false);
        }
    }
}
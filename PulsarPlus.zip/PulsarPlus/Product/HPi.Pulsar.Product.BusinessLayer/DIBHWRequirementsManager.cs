using System.Threading.Tasks;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Services;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DIBHWRequirementsManager : BaseManager<IDIBHWRequirementsRepository>, IDIBHWRequirementsService
    {
        public DIBHWRequirementsManager(IApplicationServices applicationService, IDIBHWRequirementsRepository dIBHWRequirementsRepository) : base(applicationService, dIBHWRequirementsRepository)
        {
        }

        public async Task<DibHWRequirementModel[]> GetDIBHWRequirementsAsync()
        {
            return await this.Repository.GetDIBHWRequirementsAsync().ConfigureAwait(false);
        }
    }
}

using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProgramManager : BaseManager<IProgramRepository>, IProgramService
    {
        public ProgramManager(IApplicationServices applicationService, IProgramRepository programsRepository) : base(applicationService, programsRepository)
        {
        }

        public async Task<ProgramModel[]> GetProgramsAsync()
        {
            string key = "Programs";
            var programs = await this.ApplicationService.Cache.GetCacheAsync<ProgramModel[]>(key, true);
            if (programs == null)
            {
                programs = await this.Repository.GetProgramsAsync();
                await this.ApplicationService.Cache.SetCacheAsync<ProgramModel[]>(key, programs, CacheExpiryLongTime, programs.GetType().Name, true);
            }

            return programs;
        }

        public async Task<ProgramModel[]> GetProductGroupAsync(int businessId)
        {
            return await this.Repository.GetProductGroupAsync(businessId);
        }

        public async Task<ProgramModel[]> GetProgramTreeAsync(string productGroupIds = null)
        {
            return await this.Repository.GetProgramTreeAsync(productGroupIds);
        }

        public async Task<ProgramModel[]> GetProductProgramTreeAsync(string productGroupIds = null)
        {
            return await this.Repository.GetProductProgramTreeAsync(productGroupIds);
        }

        public async Task<ProgramModel> GetProgramPropertiesAsync(int programId)
        {
            return await this.Repository.GetProgramPropertiesAsync(programId);
        }

        public async Task<ProgramGroupModel[]> GetProgramGroupsAsync(bool? active)
        {
            return await this.Repository.GetProgramGroupsAsync(active);
        }
    }
}
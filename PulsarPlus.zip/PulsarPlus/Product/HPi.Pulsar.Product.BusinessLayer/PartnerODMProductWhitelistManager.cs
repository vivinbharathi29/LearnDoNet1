using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class PartnerODMProductWhitelistManager : BaseManager<IPartnerODMProductWhitelistRepository>, IPartnerODMProductWhitelistService
    {
        public PartnerODMProductWhitelistManager(IApplicationServices applicationService, IPartnerODMProductWhitelistRepository partnerODMProductWhitelistRepository) : base(applicationService, partnerODMProductWhitelistRepository)
        {
        }

        public async Task<PartnerODMProductWhitelistModel[]> GetProductWhitelistAsync(int partnerId)
        {
            return await this.Repository.GetProductWhitelistAsync(partnerId);
        }

    }
}

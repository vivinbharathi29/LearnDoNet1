using System;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DeliverableScheduleManager : BaseManager<IDeliverableScheduleRepository>, IDeliverableScheduleService
    {
        public DeliverableScheduleManager(IApplicationServices applicationService, IDeliverableScheduleRepository deliverableScheduleRepository) : base(applicationService, deliverableScheduleRepository)
        {
        }

        #region UpdateMilestonePlan
        public async Task<bool> TryUpdateMilestonePlanAsync(int id, DateTime? planned)
        {
            return await this.Repository.TryUpdateMilestonePlanAsync(id, planned).ConfigureAwait(false);
        }

        public async Task<DeliverableScheduleModel[]> GetDeliverableMilestonesAsync(int rootId, int versionId)
        {
            return await this.Repository.GetDeliverableMilestonesAsync(rootId, versionId).ConfigureAwait(false);
        }
        #endregion
        public async Task<DeliverableScheduleModel[]> GetWorkflowStepsInProgressAsync(int id)
        {
            return await this.Repository.GetWorkflowStepsInProgressAsync(id).ConfigureAwait(false);
        }

        public async Task<DeliverableScheduleModel[]> GetNextMilestonesAsync(int id, int milestoneId)
        {
            return await this.Repository.GetNextMilestonesAsync(id, milestoneId).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateResumeAfterFailureAsync(int delID, int milestoneID)
        {
            return await this.Repository.TryUpdateResumeAfterFailureAsync(delID, milestoneID).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateMilestoneReleaseAsync(int delID, int currentID, int nextMiletoneID)
        {
            return await this.Repository.TryUpdateMilestoneReleaseAsync(delID, currentID, nextMiletoneID).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateMilestoneFailureAsync(int delID, int milestoneID)
        {
            return await this.Repository.TryUpdateMilestoneFailureAsync(delID, milestoneID).ConfigureAwait(false);
        }
    }
}
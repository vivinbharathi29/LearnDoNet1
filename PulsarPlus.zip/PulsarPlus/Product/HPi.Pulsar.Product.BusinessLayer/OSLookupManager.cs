using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class OSLookupManager : BaseManager<IOSLookupRepository>, IOSLookupService
    {
        public OSLookupManager(IApplicationServices applicationService, IOSLookupRepository oSLookupRepository) : base(applicationService, oSLookupRepository)
        {
        }

        #region Product OS
        public async Task<OSLookupModel[]> GetAllProductOSAsync(int productVersionId)
        {
            return await this.Repository.GetAllProductOSAsync(productVersionId).ConfigureAwait(false);
        }

        #endregion

        public async Task<OSLookupModel> GetOSbyIdAsync(int osId)
        {
            return await this.Repository.GetOSbyIdAsync(osId).ConfigureAwait(false);
        }
    }
}
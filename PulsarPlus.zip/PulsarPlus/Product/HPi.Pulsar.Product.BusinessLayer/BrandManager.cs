using System;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class BrandManager : BaseManager<IBrandRepository>, IBrandService
    {
        public BrandManager(IApplicationServices applicationService, IBrandRepository brandRepository, ICacheService cacheService) : base(applicationService, brandRepository)
        {
            this.CacheService = cacheService;
        }

        #region Protected Properties
        protected ICacheService CacheService { get; set; }
        #endregion

        #region ChangeImages
        public async Task<BrandModel[]> GetAllImageDefinitionBrandsAsync(int imageDefinitionId)
        {
            return await this.Repository.GetAllImageDefinitionBrandsAsync(imageDefinitionId).ConfigureAwait(false);
        }
        #endregion

        #region GetBrand4Products
        public async Task<BrandModel[]> GetBrands4ProductAsync(int productId, int selectedOnly, bool isCacheRequired = true)
        {
            BrandModel[] brands = null;
            if (Convert.ToBoolean(isCacheRequired))
            {
                string key = "brand4products_" + productId + "_" + selectedOnly;
                int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
                brands = await this.CacheService.GetCacheAsync<BrandModel[]>(key, true).ConfigureAwait(false);
                if (brands == null)
                {
                    brands = await this.Repository.GetBrands4ProductAsync(productId, selectedOnly).ConfigureAwait(false);
                    if (brands != null)
                    {
                        await this.CacheService.SetCacheAsync<BrandModel[]>(key, brands, expiryTime, brands.GetType().Name, true).ConfigureAwait(false);
                    }
                }
            }
            else
            {
                brands = await this.Repository.GetBrands4ProductAsync(productId, selectedOnly).ConfigureAwait(false);
            }

            return brands;
        }
        #endregion

        #region ProductBrands
        public async Task<BrandModel[]> GetBrandsForProductAsync(int productId, int selected)
        {
            return await this.Repository.GetBrandsForProductAsync(productId, selected).ConfigureAwait(false);
        }
        #endregion
        public async Task<BrandModel[]> GetProductCombinedSCMsAsync(int productId, bool? isCacheRequired)
        {
            BrandModel[] brand = null;
            if (isCacheRequired == true)
            {
                string key = "getProductCombinedSCMs_" + productId;
                int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
                brand = await this.CacheService.GetCacheAsync<BrandModel[]>(key, true).ConfigureAwait(false);
                if (brand == null)
                {
                    brand = await this.Repository.GetProductCombinedSCMsAsync(productId).ConfigureAwait(false);
                    if (brand != null)
                    {
                        await this.CacheService.SetCacheAsync<BrandModel[]>(key, brand, expiryTime, brand.GetType().Name, true).ConfigureAwait(false);
                    }
                }
            }
            else
            {
                brand = await this.Repository.GetProductCombinedSCMsAsync(productId).ConfigureAwait(false);
            }

            return brand;
        }

        public async Task<BrandModel[]> GetBrandsForProductPulsarAsync(int productId, int selected)
        {
            return await this.Repository.GetBrandsForProductPulsarAsync(productId, selected).ConfigureAwait(false);
        }

    }
}
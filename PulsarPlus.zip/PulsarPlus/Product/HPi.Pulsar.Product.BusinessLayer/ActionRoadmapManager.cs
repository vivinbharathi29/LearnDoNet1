using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ActionRoadmapManager : BaseManager<IActionRoadmapRepository>, IActionRoadmapService
    {
        public ActionRoadmapManager(IApplicationServices applicationService, IActionRoadmapRepository actionRoadmapRepository) : base(applicationService, actionRoadmapRepository)
        {
        }

        public async Task<ActionRoadmapModel[]> GetActionsRoadmapByProductIdAsync(int ProductID)
        {
            return await this.Repository.GetActionsRoadmapByProductIdAsync(ProductID).ConfigureAwait(false);
        }

        public async Task<ActionRoadmapModel[]> GetActionRoadmapItemForTaskAsync(int id)
        {
            return await this.Repository.GetActionRoadmapItemForTaskAsync(id).ConfigureAwait(false);
        }
    }
}
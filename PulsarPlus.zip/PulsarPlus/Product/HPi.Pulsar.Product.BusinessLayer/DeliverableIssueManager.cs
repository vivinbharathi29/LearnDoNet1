using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DeliverableIssueManager : BaseManager<IDeliverableIssueRepository>, IDeliverableIssueService
    {
        public DeliverableIssueManager(IApplicationServices applicationService, IDeliverableIssueRepository deliverableIssueRepository) : base(applicationService, deliverableIssueRepository)
        {
        }

        public async Task<DeliverableIssueModel> GetActionPropertiesAsync(int id)
        {
            return await this.Repository.GetActionPropertiesAsync(id).ConfigureAwait(false);
        }

        public async Task<ActionItemModel[]> GetWorkingListActionItemsAsync(int ownerId)
        {
            return await this.Repository.GetWorkingListActionItemsAsync(ownerId).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateDeliverableActionDisplayOrderAsync(DeliverableIssueModel[] deliverableIssue)
        {
            bool isUpdated = false;

            foreach (var item in deliverableIssue)
            {
                isUpdated = await this.Repository.TryUpdateDeliverableActionDisplayOrderAsync(item.Id, item.DisplayOrder != null ? item.DisplayOrder.Value : 0).ConfigureAwait(false);
                if (!isUpdated)
                {
                    return isUpdated;
                }
            }


            return isUpdated;
        }

        public async Task<DeliverableIssueModel> GetActionPropertiesForPrintAsync(int id)
        {
            return await this.Repository.GetActionPropertiesForPrintAsync(id).ConfigureAwait(false);
        }

        public async Task<int> UpdateDeliverableActionWebAsync(DeliverableIssueModel deliverableIssue)
        {
            return await this.Repository.UpdateDeliverableActionWebAsync(deliverableIssue).ConfigureAwait(false);
        }

        public async Task<int> InsertDeliverableActionWebAsync(DeliverableIssueModel deliverableIssue)
        {
            return await this.Repository.InsertDeliverableActionWebAsync(deliverableIssue).ConfigureAwait(false);
        }

        public async Task<DeliverableIssueModel[]> GetApprovedDCRsAsync(int productId, int showAll)
        {
            return await this.Repository.GetApprovedDCRsAsync(productId, showAll).ConfigureAwait(false);
        }

        public async Task<bool> TryUnLinkVersionFromProductAsync(ProductDeliverableModel productDeliverableModel)
        {
            return await this.Repository.TryUnLinkVersionFromProductAsync(productDeliverableModel).ConfigureAwait(false);
        }

        public async Task<bool> TryUnLinkVersionFromProductReleaseAsync(ProductDeliverableModel productDeliverableModel)
        {
            return await this.Repository.TryUnLinkVersionFromProductReleaseAsync(productDeliverableModel).ConfigureAwait(false);
        }

        public async Task<DeliverableIssueModel[]> GetActionOwnersAsync()
        {
            string key = "ActionOwners";
            var actionOwners = await this.ApplicationService.Cache.GetCacheAsync<DeliverableIssueModel[]>(key, true).ConfigureAwait(false);
            if (actionOwners == null)
            {
                actionOwners = await this.Repository.GetActionOwnersAsync().ConfigureAwait(false);
                await this.ApplicationService.Cache.SetCacheAsync<DeliverableIssueModel[]>(key, actionOwners, CacheExpiryLongTime, actionOwners.GetType().Name, true).ConfigureAwait(false);
            }
            return actionOwners;
        }

        public async Task<DeliverableIssueModel[]> GetDeliverableIssueSubmittersAsync()
        {
            string key = "Submitters";
            var submitters = await this.ApplicationService.Cache.GetCacheAsync<DeliverableIssueModel[]>(key, true).ConfigureAwait(false);
            if (submitters == null)
            {
                submitters = await this.Repository.GetDeliverableIssueSubmittersAsync().ConfigureAwait(false);
                await this.ApplicationService.Cache.SetCacheAsync<DeliverableIssueModel[]>(key, submitters, CacheExpiryLongTime, submitters.GetType().Name, true).ConfigureAwait(false);
            }

            return submitters;
        }

        public async Task<DeliverableIssueModel[]> ListAllActionOwnersAsync()
        {
            return await this.Repository.ListAllActionOwnersAsync().ConfigureAwait(false);
        }

        public async Task<DeliverableIssueModel[]> GetChangeRequestGroupAsync(int issueId, long? changeRequestId)
        {
            return await this.Repository.GetChangeRequestGroupAsync(issueId, changeRequestId).ConfigureAwait(false);
        }

        #region  Action Report Advanced
        public async Task<DeliverableIssueModel[]> GetActionReportAdvanced(string dynamicQuery)
        {
            return await this.Repository.GetActionReportAdvancedAsync(dynamicQuery).ConfigureAwait(false);
        }

        #endregion  Action Report Advanced

        public async Task<int> AddDeliverableTodayActionAsync(DeliverableIssueModel deliverableIssue)
        {
            return await this.Repository.AddDeliverableTodayActionAsync(deliverableIssue).ConfigureAwait(false);
        }

        public async Task<int> UpdateDeliverableIssueActionWebAsync(DeliverableIssueModel deliverableIssue)
        {
            return await this.Repository.UpdateDeliverableIssueActionWebAsync(deliverableIssue).ConfigureAwait(false);
        }

        public async Task<DeliverableIssueModel> GetActionforMailAsync(int deliverableIssueId)
        {
            return await this.Repository.GetActionforMailAsync(deliverableIssueId).ConfigureAwait(false);
        }

        public async Task<int> SetApprovalForActionAsync(int actionId)
        {
            return await this.Repository.SetApprovalForActionAsync(actionId).ConfigureAwait(false);
        }

        public async Task<long?> GetChangeRequestIdAsync(int issueId)
        {
            return await this.Repository.GetChangeRequestIdAsync(issueId).ConfigureAwait(false);
        }

        public async Task<DeliverableIssueModel> GetActionProductTypeAsync(int actionId)
        {
            return await this.Repository.GetActionProductTypeAsync(actionId).ConfigureAwait(false);
        }

        public async Task<DeliverableIssueModel[]> GetReorderListAsync(int projectId, int typeId, int strId)
        {
            return await this.Repository.GetReorderListAsync(projectId, typeId, strId).ConfigureAwait(false);
        }

        #region ApproverEmail
        public async Task<DeliverableIssueModel> GetApproverEmailAsync(int approvalId)
        {
            return await this.Repository.GetApproverEmailAsync(approvalId).ConfigureAwait(false);
        }
        #endregion
    }
}
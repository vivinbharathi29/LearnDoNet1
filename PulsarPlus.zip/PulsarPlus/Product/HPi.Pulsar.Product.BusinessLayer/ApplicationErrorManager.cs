﻿using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ApplicationErrorManager : BaseManager<IApplicationErrorRepository>, IApplicationErrorService
    {

        public ApplicationErrorManager(IApplicationServices applicationService, IApplicationErrorRepository applicationErrorRepository) : base(applicationService, applicationErrorRepository)
        {
        }

        public async Task<AppErrorModel> GetApplicationErrorOutstandingAsync(int appErrorId)
        {
            return await this.Repository.GetApplicationErrorOutstandingAsync(appErrorId).ConfigureAwait(false);
        }

        public async Task<int> UpdateApplicationErrorAsync(int id, string cause)
        {
            return await this.Repository.UpdateApplicationErrorAsync(id, cause).ConfigureAwait(false);
        }
    }
}
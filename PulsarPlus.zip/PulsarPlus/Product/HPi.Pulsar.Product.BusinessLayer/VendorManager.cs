using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class VendorManager : BaseManager<IVendorRepository>, IVendorService
    {
        public VendorManager(IApplicationServices applicationService, IVendorRepository vendorRepository) : base(applicationService, vendorRepository)
        {
        }

        public async Task<VendorModel[]> GetVendors4RootAsync(int rootId)
        {
            return await this.Repository.GetVendors4RootAsync(rootId);
        }

        public async Task<VendorModel[]> GetDeliverableUsagesByVendorAsync(int rootId)
        {
            return await this.Repository.GetDeliverableUsagesByVendorAsync(rootId);
        }

        #region ProductDeliverables
        public async Task<VendorModel[]> GetVendorsAsync()
        {
            return await this.Repository.GetVendorsAsync();
        }
        #endregion

    }
}
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductDelRootReleaseManager : BaseManager<IProductDelRootReleaseRepository>, IProductDelRootReleaseService
    {
        public ProductDelRootReleaseManager(IApplicationServices applicationService, IProductDelRootReleaseRepository productDelRootReleaseRepository) : base(applicationService, productDelRootReleaseRepository)
        {
        }

        public async Task<ProductDelRootReleaseModel[]> GetSubAssembliesForBaseAsync(string baseName)
        {
            return await this.Repository.GetSubAssembliesForBaseAsync(baseName);
        }

        public async Task<ProductDelRootReleaseModel[]> GetSubAssembliesForBaseServiceAsync(string subAssemblyBase)
        {
            return await this.Repository.GetSubAssembliesForBaseServiceAsync(subAssemblyBase);
        }

    }
}

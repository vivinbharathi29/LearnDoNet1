using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class AccessoryStatusManager : BaseManager<IAccessoryStatusRepository>, IAccessoryStatusService
    {
        public AccessoryStatusManager(IApplicationServices applicationService, IAccessoryStatusRepository accessoryStatusRepository) : base(applicationService, accessoryStatusRepository)
        {
        }

        public async Task<AccessoryStatusModel[]> GetAccessoryStatusesAsync()
        {
            return await this.Repository.GetAccessoryStatusesAsync().ConfigureAwait(false);
        }

        #region AccessoryStatus
        public async Task<string> GetProductAccessoryStatusAsync(int productDeliverableId)
        {
            return await this.Repository.GetProductAccessoryStatusAsync(productDeliverableId).ConfigureAwait(false);
        }
        #endregion
    }
}
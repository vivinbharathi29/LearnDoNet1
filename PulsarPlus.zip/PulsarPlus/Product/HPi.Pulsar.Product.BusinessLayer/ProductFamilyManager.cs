using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductFamilyManager : BaseManager<IProductFamilyRepository>, IProductFamilyService
    {
        public ProductFamilyManager(IApplicationServices applicationService, IProductFamilyRepository productFamilyRepository) : base(applicationService, productFamilyRepository)
        {
        }

        public async Task<ProductFamilyModel[]> GetListProductFamilyAsync(int id)
        {
            return await this.Repository.GetListProductFamilyAsync(id);
        }

        public async Task<ProductFamilyModel[]> GetProductsAllAsync(int? type, int? partnerId)
        {
            return await this.Repository.GetProductsAllAsync(type, partnerId);
        }
    }
}

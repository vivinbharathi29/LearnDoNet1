using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class PlatformManager : BaseManager<IPlatformRepository>, IPlatformService
    {
        public PlatformManager(IApplicationServices applicationService, IPlatformRepository platformRepository) : base(applicationService, platformRepository)
        {
        }

        public async Task<PlatformModel[]> GetLisOfChassisAsync()
        {
            return await this.Repository.GetLisOfChassisAsync();
        }

        public async Task<PlatformModel> GetPlatformByIdAsync(int platFormId)
        {
            return await this.Repository.GetPlatformByIdAsync(platFormId);
        }

        public async Task<int> FusionAddPlatformAsync(PlatformModel platFormData)
        {
            return await this.Repository.FusionAddPlatformAsync(platFormData);
        }
    }
}

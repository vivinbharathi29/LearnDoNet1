using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{


    public class ScheduleDataManager : BaseManager<IScheduleDataRepository>, IScheduleDataService
    {
        public ScheduleDataManager(IApplicationServices applicationService, IScheduleDataRepository scheduleDataRepository) : base(applicationService, scheduleDataRepository)
        {
        }

        #region Milestone Pulsar ScheduleData
        public async Task<ScheduleDataModel> GetScheduleDataAsync(int id, string operation)
        {
            return await this.Repository.GetScheduleDataAsync(id, operation);
        }
        #endregion

        #region UpdateSchedule
        public async Task<ScheduleDataModel> UpdateScheduleMilestoneDataAsync(ScheduleDataModel scheduleData)
        {
            return await this.Repository.UpdateScheduleMilestoneDataAsync(scheduleData);
        }
        #endregion

        #region PDD Locked
        public async Task<int> SetPddLockedAsync(int scheduleDataId)
        {
            return await this.Repository.SetPddLockedAsync(scheduleDataId);
        }
        #endregion

        public async Task<List<ScheduleDataModel>> GetScheduleMilestonesDataAsync(int scheduleDataId)
        {
            return await this.Repository.GetScheduleMilestonesDataAsync(scheduleDataId);
        }

        public async Task<int> UpdateScheduleMilestonesAsync(List<ScheduleDataModel> scheduleData)
        {
            return await this.Repository.UpdateScheduleMilestonesAsync(scheduleData);
        }

        public async Task<bool> TryInsertScheduleDataIntoProductsAsync(ScheduleDataModel scheduleData)
        {
            return await this.Repository.TryInsertScheduleDataIntoProductsAsync(scheduleData);
        }
        public async Task<ScheduleDataModel> GetProductWithoutScheduleAsync(ScheduleDataModel scheduleData)
        {
            return await this.Repository.GetProductWithoutScheduleAsync(scheduleData);
        }
        public async Task<DateTime> GetRTPDateAsync(int productVersionId, string releaseIds = "")
        {
            return await this.Repository.GetRTPDateAsync(productVersionId);
        }

        public async Task<DateTime> GetEOMDateAsync(int productVersionId, string releaseIds = "")
        {
            return await this.Repository.GetEOMDateAsync(productVersionId, releaseIds);
        }

        public async Task<ScheduleModel[]> GetSelectScheduleAsync(ScheduleModel scheduleModel)
        {
            return await this.Repository.GetSelectScheduleAsync(scheduleModel);
        }


        public async Task<string> UpdateScheduleRTPandEOMAsync(int productId, string productReleaseName, DateTime? rtpDate, DateTime? eomDate)
        {
            return await this.Repository.UpdateScheduleRTPandEOMAsync(productId, productReleaseName, rtpDate, eomDate);
        }

    }
}
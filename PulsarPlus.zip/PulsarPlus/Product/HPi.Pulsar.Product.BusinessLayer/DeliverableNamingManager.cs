namespace HPi.Pulsar.Product.BusinessLayer
{
    using System.Threading.Tasks;
    using HPi.Pulsar.Infrastructure.BaseClass;
    using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
    using HPi.Pulsar.Product.Contracts;
    using HPi.Pulsar.Product.Contracts.Repositories;
    using HPi.Pulsar.Product.Contracts.Services;

    public class DeliverableNamingManager : BaseManager<IDeliverableNamingRepository>, IDeliverableNamingService
    {
        public DeliverableNamingManager(IApplicationServices applicationService, IDeliverableNamingRepository deliverableNamingRepository) : base(applicationService, deliverableNamingRepository)
        {
        }

        public async Task<DeliverableNamingModel[]> GetDeliverableElementsAsync()
        {
            return await this.Repository.GetDeliverableElementsAsync().ConfigureAwait(false);
        }
    }
}

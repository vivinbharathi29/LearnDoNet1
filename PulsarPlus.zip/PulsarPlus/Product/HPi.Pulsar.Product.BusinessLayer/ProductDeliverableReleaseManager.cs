using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductDeliverableReleaseManager : BaseManager<IProductDeliverableReleaseRepository>, IProductDeliverableReleaseService
    {
        public ProductDeliverableReleaseManager(IApplicationServices applicationService, IProductDeliverableReleaseRepository productDeliverableReleaseRepository) : base(applicationService, productDeliverableReleaseRepository)
        {
        }

        public async Task<bool> TryUpdateDeveloperNotificationStatusAsync(LinkProductModel linkProductModel)
        {
            return await this.Repository.TryUpdateDeveloperNotificationStatusAsync(linkProductModel);
        }

        public async Task<bool> TryUpdateDeveloperNotificationStatusPulsarAsync(LinkProductModel linkProductModel)
        {
            return await this.Repository.TryUpdateDeveloperNotificationStatusPulsarAsync(linkProductModel);
        }

        public async Task<bool> TryUpdateDeveloperNotificationWithMultipleItemAsync(LinkProductModel linkProductModel)
        {
            return await this.Repository.TryUpdateDeveloperNotificationWithMultipleItemAsync(linkProductModel);
        }

        public async Task<bool> TryUpdateDeveloperNotificationPulsarWithMultipleItemAsync(LinkProductModel linkProductModel)
        {
            return await this.Repository.TryUpdateDeveloperNotificationPulsarWithMultipleItemAsync(linkProductModel);
        }

        #region Update SE Test Status
        public async Task<ProductDeliverableReleaseModel> GetTestLeadStatusPulsarAsync(int productDeliverableReleaseId, int fieldId)
        {
            return await this.Repository.GetTestLeadStatusPulsarAsync(productDeliverableReleaseId, fieldId);
        }

        public async Task<bool> TryUpdateTestLeadStatusPulsarAsync(TestLeadStatusPulsarModel testLeadStatusPulsar)
        {
            return await this.Repository.TryUpdateTestLeadStatusPulsarAsync(testLeadStatusPulsar);
        }
        #endregion

        #region Qual Status Release
        public async Task<ProductDeliverableReleaseModel[]> GetQualStatusReleaseDetailsAsync(int productId, int releaseId, int versionId, string todayPageSection, int productDeliverableReleaseId)
        {
            return await this.Repository.GetQualStatusReleaseDetailsAsync(productId, releaseId, versionId, todayPageSection, productDeliverableReleaseId);
        }

        #endregion

        public async Task<ProductDeliverableReleaseModel[]> GetComponentProductReleasesAsync(int productId, int versionId)
        {
            return await this.Repository.GetComponentProductReleasesAsync(productId, versionId);
        }
    }
}

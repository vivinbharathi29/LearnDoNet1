using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class FeatureManager : BaseManager<IFeatureRepository>, IFeatureService
    {
        public FeatureManager(IApplicationServices applicationService, IFeatureRepository featureRepository) : base(applicationService, featureRepository)
        {
        }

        #region Get FeatureName
        public async Task<string> GetFeatureNameAsync(int id)
        {
            return await this.Repository.GetFeatureNameAsync(id).ConfigureAwait(false);
        }
        #endregion

        #region Reject Feature Request
        public async Task<bool> TryRejectFeatureRequestAsync(FeatureRootModel featureRoot)
        {
            return await this.Repository.TryRejectFeatureRequestAsync(featureRoot).ConfigureAwait(false);
        }
        #endregion

        public async Task<bool> TryUpdateOverrideRequestedFeatureAsync(int featureID, int actionType, int userID)
        {
            return await this.Repository.TryUpdateOverrideRequestedFeatureAsync(featureID, actionType, userID).ConfigureAwait(false);
        }

        public async Task<FeatureModel[]> GetOsReleaseDescriptionAsync()
        {
            return await this.Repository.GetOsReleaseDescriptionAsync().ConfigureAwait(false);
        }
    }
}
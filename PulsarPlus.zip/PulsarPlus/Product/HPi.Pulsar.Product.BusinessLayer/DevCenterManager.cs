using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DevCenterManager : BaseManager<IDevCenterRepository>, IDevCenterService
    {
        public DevCenterManager(IApplicationServices applicationService, IDevCenterRepository devCenterdRepository) : base(applicationService, devCenterdRepository)
        {
        }

        public async Task<DevCenterModel[]> GetDevCentersAsync()
        {
            string key = "DevCenter";
            var devCenter = await this.ApplicationService.Cache.GetCacheAsync<DevCenterModel[]>(key, true).ConfigureAwait(false);
            if (devCenter == null)
            {
                devCenter = await this.Repository.GetDevCentersAsync().ConfigureAwait(false);
                await this.ApplicationService.Cache.SetCacheAsync<DevCenterModel[]>(key, devCenter, CacheExpiryLongTime, devCenter.GetType().Name, true).ConfigureAwait(false);
            }

            return devCenter;
        }
    }
}
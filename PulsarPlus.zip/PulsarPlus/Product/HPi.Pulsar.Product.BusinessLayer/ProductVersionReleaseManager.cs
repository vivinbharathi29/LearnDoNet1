using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductVersionReleaseManager : BaseManager<IProductVersionReleaseRepository>, IProductVersionReleaseService
    {
        public ProductVersionReleaseManager(IApplicationServices applicationService, IProductVersionReleaseRepository productVersionReleaseRepository) : base(applicationService, productVersionReleaseRepository)
        {
        }

        #region Update SE Test Status
        public async Task<ProductVersionReleaseModel> GetProductVersionReleaseDetailsAsync(int prodId)
        {
            return await this.Repository.GetProductVersionReleaseDetailsAsync(prodId);
        }

        public async Task<ProductVersionReleaseModel[]> GetTestStatusProductDeliverableVersionReleaseDetailsAsync(int productId, int versionId)
        {
            return await this.Repository.GetTestStatusProductDeliverableVersionReleaseDetailsAsync(productId, versionId);
        }

        public async Task<ProductVersionReleaseModel[]> GetTestStatusProductVersionReleaseDetailsAsync(int productId, int versionId, int productDeliverableReleaseId, int defaultReleaseId)
        {
            return await this.Repository.GetTestStatusProductVersionReleaseDetailsAsync(productId, versionId, productDeliverableReleaseId, defaultReleaseId);
        }
        #endregion
        public async Task<ProductVersionReleaseModel[]> GetDefaultReleaseSubAssemblyAsync(int productID)
        {
            return await this.Repository.GetDefaultReleaseSubAssemblyAsync(productID);
        }

        #region Product Release
        public async Task<ProductVersionReleaseModel[]> GetProductReleasesAsync(int productVersionId, int avDetailId, int productBrandId)
        {
            return await this.Repository.GetProductReleasesAsync(productVersionId, avDetailId, productBrandId);
        }
        #endregion

        public async Task<ProductVersionReleaseModel[]> GetSelectReleasesAsync(string productIds)
        {
            return await this.Repository.GetSelectReleasesAsync(productIds);
        }

        public async Task<ProductVersionReleaseModel> GetProductVersionReleaseAsync(int productId)
        {
            return await this.Repository.GetProductVersionReleaseAsync(productId);
        }

        public async Task<ProductVersionReleaseModel[]> GetProductValuesAsync(string productPulsarId)
        {
            return await this.Repository.GetProductValuesAsync(productPulsarId);
        }
    }
}
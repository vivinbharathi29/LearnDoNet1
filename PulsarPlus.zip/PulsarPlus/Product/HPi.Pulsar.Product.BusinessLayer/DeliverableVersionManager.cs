using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DeliverableVersionManager : BaseManager<IDeliverableVersionRepository>, IDeliverableVersionService
    {
        public DeliverableVersionManager(IApplicationServices applicationService, IDeliverableVersionRepository deliverableVersionRepository) : base(applicationService, deliverableVersionRepository)
        {
        }

        public async Task<DeliverableVersionModel> GetDeliverableVersionPropertiesAsync(int versionID)
        {
            return await this.Repository.GetDeliverableVersionPropertiesAsync(versionID).ConfigureAwait(false);
        }

        #region UpdateEOLDate
        public async Task<DeliverableVersionModel[]> GetVersionPropertiesForWebAsync(int id)
        {
            return await this.Repository.GetVersionPropertiesForWebAsync(id).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateDeliverableServiceEOLAsync(int id, string eolDate, int active)
        {
            return await this.Repository.TryUpdateDeliverableServiceEOLAsync(id, eolDate, active).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateDeliverableEOLAsync(int id, string eolDate, int active)
        {
            return await this.Repository.TryUpdateDeliverableEOLAsync(id, eolDate, active).ConfigureAwait(false);
        }
        #endregion

        public async Task<DeliverableVersionModel[]> GetDeliverableVersionsAsync(int? RootID, int? ProdID, int? VersionList, int? PartnerID)
        {
            return await this.Repository.GetDeliverableVersionsAsync(RootID, ProdID, VersionList, PartnerID).ConfigureAwait(false);
        }

        #region Update WWAN TTS Status

        public async Task<DeliverableVersionModel> GetWWANTTSStausAsync(int id)
        {
            return await this.Repository.GetWWANTTSStausAsync(id).ConfigureAwait(false);
        }

        public async Task<int> UpdateWWANTTSAsync(DeliverableVersionModel deliverableVersiondata)
        {
            return await this.Repository.UpdateWWANTTSAsync(deliverableVersiondata).ConfigureAwait(false);
        }
        #endregion

        public async Task<int?> GetRootIdByVersionAsync(int versionId)
        {
            return await this.Repository.GetRootIdByVersionAsync(versionId).ConfigureAwait(false);
        }

        #region UpdateDeliverableLocation
        public async Task<bool> TryUpdateDeliverableLocationAsync(int deliverableId)
        {
            return await this.Repository.TryUpdateDeliverableLocationAsync(deliverableId).ConfigureAwait(false);
        }
        #endregion

        #region Deliverable Comparison
        public async Task<DeliverableVersionModel[]> GetVersionHistoriesAsync(int rootId, int prodId)
        {
            return await this.Repository.GetVersionHistoriesAsync(rootId, prodId).ConfigureAwait(false);
        }
        #endregion

        #region MultiEOLDate
        public async Task<DeliverableVersionModel[]> GetDeliverablesToUpdateAsync(string idList)
        {
            return await this.Repository.GetDeliverablesToUpdateAsync(idList).ConfigureAwait(false);
        }

        public async Task<bool> TrySyncServiceToFactoryEOAAsync(int id)
        {
            return await this.Repository.TrySyncServiceToFactoryEOAAsync(id).ConfigureAwait(false);
        }
        #endregion

        #region MultiTestStatus

        public async Task<DeliverableVersionModel[]> GetProductMultiTestStatusAsync(int? productId, int? rootId, string selectedVersionIds, int partnerId)
        {
            return await this.Repository.GetProductMultiTestStatusAsync(productId, rootId, selectedVersionIds, partnerId).ConfigureAwait(false);
        }

        #endregion

        #region CompareRootOnLeadProduct
        public async Task<List<string>> GetDeliverableVersionIdsAsync(int rootId, int leadId, int productId, int fusionRequirement)
        {
            return await this.Repository.GetDeliverableVersionIdsAsync(rootId, leadId, productId, fusionRequirement).ConfigureAwait(false);
        }
        #endregion

        public async Task<DeliverableVersionModel[]> GetAllLeadProductExclusionsAsync(int pmId)
        {
            return await this.Repository.GetAllLeadProductExclusionsAsync(pmId).ConfigureAwait(false);
        }

        public async Task<DeliverableVersionModel[]> GetDeliverableVersionExclusionsByVersionIdsAsync(string versionIds)
        {
            return await this.Repository.GetDeliverableVersionExclusionsByVersionIdsAsync(versionIds).ConfigureAwait(false);
        }

        #region GetRootID
        public async Task<DeliverableVersionModel[]> GetRootIdsAsync(int id)
        {
            return await this.Repository.GetRootIdsAsync(id).ConfigureAwait(false);
        }
        #endregion

        public async Task<DeliverableVersionModel[]> GetReleaseDeliverableVersionsAsync(string versionId)
        {
            return await this.Repository.GetReleaseDeliverableVersionsAsync(versionId).ConfigureAwait(false);
        }


        public async Task<bool> TryUpdateDeliverableForReleaseAsync(DeliverableVersionModel deliverableVersion)
        {
            return await this.Repository.TryUpdateDeliverableForReleaseAsync(deliverableVersion).ConfigureAwait(false);
        }

        #region Product/Update Qualification Status for Multi Test Status Pulsar
        public async Task<DeliverableVersionModel[]> GetProductMultiTestStatusPulsarAsync(string productDeliverableIds, string productIds, int? rootId, int? productId, int? bsId, int? showOnlyTargetedRelease)
        {
            return await this.Repository.GetProductMultiTestStatusPulsarAsync(productDeliverableIds, productIds, rootId, productId, bsId, showOnlyTargetedRelease).ConfigureAwait(false);
        }
        #endregion

        #region ChangeImages
        public async Task<DeliverableVersionModel> GetChangeImagesVersionPropertiesForWebAsync(int id)
        {
            return await this.Repository.GetChangeImagesVersionPropertiesForWebAsync(id).ConfigureAwait(false);
        }

        public async Task<DeliverableVersionModel> GetDistributionVersionAsync(int productId, int versionId)
        {
            return await this.Repository.GetDistributionVersionAsync(productId, versionId).ConfigureAwait(false);
        }

        #endregion

        #region Updatestoredpath
        public async Task<DeliverableVersionModel[]> GetStoredPathDataAsync(string textFind, PaginationModel pagination)
        {
            return await this.Repository.GetStoredPathDataAsync(textFind, pagination).ConfigureAwait(false);
        }
        public async Task<int> UpdateStoredPathAsync(string updateFind, string updateReplace)
        {
            return await this.Repository.UpdateStoredPathAsync(updateFind, updateReplace).ConfigureAwait(false);
        }
        #endregion

        #region Updatestoredpath
        public async Task<DeliverableVersionModel[]> GetDeliverableSyncDataAsync(PaginationModel pagination)
        {
            return await this.Repository.GetDeliverableSyncDataAsync(pagination).ConfigureAwait(false);
        }
        public async Task<int> UpdateDeliverableSyncAsync()
        {
            return await this.Repository.UpdateDeliverableSyncAsync().ConfigureAwait(false);
        }
        #endregion
    }
}
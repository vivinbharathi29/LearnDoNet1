using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class OTSDelVerManager : BaseManager<IOTSDelVerRepository>, IOTSDelVerService
    {
        public OTSDelVerManager(IApplicationServices applicationService, IOTSDelVerRepository oTSDelVerRepository) : base(applicationService, oTSDelVerRepository)
        {
        }

        #region Deliverable Comparison
        public async Task<OtsDelVerModel[]> GetOTSByDelVersionAsync(int deliverableVersionId)
        {
            return await this.Repository.GetOTSByDelVersionAsync(deliverableVersionId).ConfigureAwait(false);
        }
        #endregion

        public async Task<OtsDelVerModel[]> GetOTSIDsByDelVersionAsync(int deliverableVersionId)
        {
            return await this.Repository.GetOTSIDsByDelVersionAsync(deliverableVersionId).ConfigureAwait(false);
        }
        public async Task<OtsDelVerModel[]> GetSelectedOSAsync(int id)
        {
            return await this.Repository.GetSelectedOSAsync(id).ConfigureAwait(false);
        }
    }
}
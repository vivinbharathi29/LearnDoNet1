using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DeliverableTypeManager : BaseManager<IDeliverableTypeRepository>, IDeliverableTypeService
    {
        public DeliverableTypeManager(IApplicationServices applicationService, IDeliverableTypeRepository deliverableTypeRepository) : base(applicationService, deliverableTypeRepository)
        {
        }

        public async Task<DeliverableTypeModel[]> GetDeliverableCategoriesAsync(int productId)
        {
            return await this.Repository.GetDeliverableCategoriesAsync(productId).ConfigureAwait(false);
        }
    }
}
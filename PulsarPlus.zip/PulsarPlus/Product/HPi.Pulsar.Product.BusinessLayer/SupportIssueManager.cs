using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class SupportIssueManager : BaseManager<ISupportIssueRepository>, ISupportIssueService
    {
        public SupportIssueManager(IApplicationServices applicationService, ISupportIssueRepository supportIssueTicketRepository) : base(applicationService, supportIssueTicketRepository)
        {
        }

        public async Task<SupportIssueModel> GetSupportTicketInfoAsync(int ticketNumber)
        {
            return await this.Repository.GetSupportTicketInfoAsync(ticketNumber);
        }

        public async Task<int> UpdateSupportTicketConverted2ActionAsync(int ticketID, int actionItemID)
        {
            return await this.Repository.UpdateSupportTicketConverted2ActionAsync(ticketID, actionItemID);
        }

        #region Support Search Open Known Issues
        public async Task<SupportIssueModel[]> GetSupportSearchOpenKnownIssuesAsync(SupportIssueModel supportIssue)
        {
            return await this.Repository.GetSupportSearchOpenKnownIssuesAsync(supportIssue);
        }
        #endregion

        #region Insert Support Issues
        public async Task<int> SaveSupportIssuesAsync(SupportModel support)
        {
            return await this.Repository.SaveSupportIssuesAsync(support);
        }
        #endregion

        public async Task<List<SupportArticleModel>> GetSupportArticlesAsync(int? Id)
        {
            return await this.Repository.GetSupportArticlesAsync(Id);
        }
    }
}
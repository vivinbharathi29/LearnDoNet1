using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class PartnerManager : BaseManager<IPartnerRepository>, IPartnerService
    {
        public PartnerManager(IApplicationServices applicationService, IPartnerRepository partnerRepository) : base(applicationService, partnerRepository)
        {
        }

        public async Task<PartnerModel[]> GetPartnersAsync(int reportTypeId)
        {
            string key = "Partners";
            var partners = await this.ApplicationService.Cache.GetCacheAsync<PartnerModel[]>(key, true);
            if (partners == null)
            {
                partners = await this.Repository.GetPartnersAsync(reportTypeId);
                await this.ApplicationService.Cache.SetCacheAsync<PartnerModel[]>(key, partners, CacheExpiryLongTime, partners.GetType().Name, true);
            }

            return partners;
        }

        public async Task<PartnerModel> GetPartnerDetailAsync(int partnerId)
        {
            return await this.Repository.GetPartnerDetailAsync(partnerId);
        }
    }
}
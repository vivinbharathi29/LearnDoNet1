using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DCRWorkflowStagingManager : BaseManager<IDCRWorkflowStagingRepository>, IDCRWorkflowStagingService
    {
        public DCRWorkflowStagingManager(IApplicationServices applicationService, IDCRWorkflowStagingRepository dCRWorkflowStagingRepository) : base(applicationService, dCRWorkflowStagingRepository)
        {
        }

        public async Task<DCRWorkflowStagingModel> GetDCRWorkflowCheckAsync(int dcrId)
        {
            return await this.Repository.GetDCRWorkflowCheckAsync(dcrId).ConfigureAwait(false);
        }

        public async Task<DCRWorkflowStagingModel[]> GetScheduleRTPandEOMDatebyProductIdAsync(int productId, string releaseName)
        {
            return await this.Repository.GetScheduleRTPandEOMDatebyProductIdAsync(productId, releaseName).ConfigureAwait(false);
        }
    }
}
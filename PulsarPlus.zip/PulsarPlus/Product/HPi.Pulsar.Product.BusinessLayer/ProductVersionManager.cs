using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductVersionManager : BaseManager<IProductVersionRepository>, IProductVersionService
    {
        public ProductVersionManager(IApplicationServices applicationService, IProductVersionRepository productVersionRepository, ICacheService cacheService) : base(applicationService, productVersionRepository)
        {
            this.CacheService = cacheService;
        }

        protected ICacheService CacheService { get; set; }

        #region HardwareTeamAccess
        //public async Task<ProductVersionModel[]> GetHardwareTeamAccessList(int userId, int? prodId)
        //{
        //    string key = "HardwareTeamAccess_" + userId;
        //    var hardwareTeamAccesses = await this.ApplicationService.Cache.GetCache<ProductVersionModel[]>(key, true);
        //    if (hardwareTeamAccesses == null)
        //    {
        //        hardwareTeamAccesses = await this.Repository.GetHardwareTeamAccessList(userId, prodId);
        //        await this.ApplicationService.Cache.SetCache<ProductVersionModel[]>(key, hardwareTeamAccesses, CacheExpiryTime, hardwareTeamAccesses.GetType().Name, true);
        //    }
        //    return hardwareTeamAccesses;
        //}
        public async Task<ProductVersionModel[]> GetHardwareTeamAccessListAsync(int userId, int? prodId, bool? isCacheRequired)
        {
            ProductVersionModel[] productVersion = null;
            if (isCacheRequired == true)
            {
                string key = "productVersion_" + userId;
                int expiryTime = AppSettings.Get<int>("CacheExpiry:InMilliSeconds");
                productVersion = await this.CacheService.GetCacheAsync<ProductVersionModel[]>(key, true);
                if (productVersion == null)
                {
                    productVersion = await this.Repository.GetHardwareTeamAccessListAsync(userId, prodId, isCacheRequired);
                    if (productVersion != null)
                    {
                        await this.CacheService.SetCacheAsync<ProductVersionModel[]>(key, productVersion, expiryTime, productVersion.GetType().Name, true);
                    }
                }
            }
            else
            {
                productVersion = await this.Repository.GetHardwareTeamAccessListAsync(userId, prodId, isCacheRequired);
            }
            return productVersion;
        }
        #endregion

        #region UpdateProductVersion
        public async Task<bool> TryUpdateProductVersionHWPMAsync(ProductVersionModel productPropertiesModel)
        {
            return await this.Repository.TryUpdateProductVersionHWPMAsync(productPropertiesModel);
        }
        #endregion

        public async Task<ProductVersionModel> GetProductVersionNameAsync(int productId, int releaseId)
        {
            ProductVersionModel productVersion = new ProductVersionModel();
            string key = string.Concat("productVersionName_",productId,"_", releaseId);
            int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
            productVersion = await this.CacheService.GetCacheAsync<ProductVersionModel>(key, true);
            if (productVersion == null)
            {
                productVersion = await this.Repository.GetProductVersionNameAsync(productId, releaseId);
                if (productVersion != null)
                {
                    await this.CacheService.SetCacheAsync<ProductVersionModel>(key, productVersion, expiryTime, productVersion.GetType().Name, true);
                }
            }
            return productVersion;
        }
        public async Task<ProductVersionModel> GetProductVersionAsync(int productVersionID, bool? isCacheRequired)
        {
            ProductVersionModel productVersion = new ProductVersionModel();
            if (isCacheRequired == true)
            {
                string key = "productVersion_" + productVersionID;
                int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
                productVersion = await this.CacheService.GetCacheAsync<ProductVersionModel>(key, true);
                if (productVersion == null)
                {
                    productVersion = await this.Repository.GetProductVersionAsync(productVersionID, isCacheRequired);
                    if (productVersion != null)
                    {
                        await this.CacheService.SetCacheAsync<ProductVersionModel>(key, productVersion, expiryTime, productVersion.GetType().Name, true);
                    }
                }
            }
            else
            {
                productVersion = await this.Repository.GetProductVersionAsync(productVersionID, isCacheRequired);
            }

            return productVersion;
        }

        #region IRSComponentProductUpdateList
        public async Task<ProductVersionModel[]> GetProductDropListAsync()
        {
            return await this.Repository.GetProductDropListAsync();
        }
        #endregion

        public async Task<ProductVersionModel[]> GetProductGroupsAsync(int type)
        {
            return await this.Repository.GetProductGroupsAsync(type);
        }


        #region Product/Update Qualification Status for Multi Test Status
        public async Task<ProductVersionModel> GetOdmHwPMAsync(int productId)
        {
            return await this.Repository.GetOdmHwPMAsync(productId);
        }
        #endregion

        #region AdvancedSupport
        public async Task<ProductVersionModel[]> GetTargetedProductsForVersionAsync(int versionId)
        {
            return await this.Repository.GetTargetedProductsForVersionAsync(versionId);
        }

        #endregion
        public async Task<int> GetODMHWPMIdAsync(int productId)
        {
            return await this.Repository.GetODMHWPMIdAsync(productId);
        }

        #region CompareRootOnLeadProduct
        public async Task<ProductVersionModel> GetLeadProductDetailsAsync(int prodId, int fusionRequirement)
        {
            return await this.Repository.GetLeadProductDetailsAsync(prodId, fusionRequirement);
        }
        #endregion

        #region View Workflow Status/ Add Workflow
        public async Task<bool> IsPulsarProductAsync(int productVersionId)
        {
            return await this.Repository.IsPulsarProductAsync(productVersionId);
        }
        #endregion

        public async Task<bool> TryUpdateProductVersionAccessoryAsync(int productVersionId, int pmId)
        {
            return await this.Repository.TryUpdateProductVersionAccessoryAsync(productVersionId, pmId);
        }

        public async Task<ProductVersionModel[]> GetAllImagesForProductFusionAsync(int productId)
        {
            return await this.Repository.GetAllImagesForProductFusionAsync(productId);
        }

        public async Task<ProductVersionModel[]> GetSwitchReleaseNameSubAssmeblyAsync(int rootID, int productID)
        {
            return await this.Repository.GetSwitchReleaseNameSubAssmeblyAsync(rootID, productID);
        }
        public async Task<ProductVersionModel[]> GetSwitchReleaseNameSubAssmeblyForDeliverableAsync(int productID, int versionID, int? showOnlyTargetedRelease)
        {
            return await this.Repository.GetSwitchReleaseNameSubAssmeblyForDeliverableAsync(productID, versionID, showOnlyTargetedRelease);
        }

        #region UpdateProductVersionFactoryEngineer
        public async Task<bool> TryUpdateProductVersionFactoryEngineerAsync(int productVersionId, int feId)
        {
            return await this.Repository.TryUpdateProductVersionFactoryEngineerAsync(productVersionId, feId);
        }
        #endregion


        public async Task<ProductVersionModel[]> GetProductsOnCommodityMatrixAsync(int divisionId)
        {
            return await this.Repository.GetProductsOnCommodityMatrixAsync(divisionId);
        }


        public async Task<int> UpdateProductVersionCommodityAsync(ProductVersionModel productVersion)
        {
            return await this.Repository.UpdateProductVersionCommodityAsync(productVersion);
        }

        public async Task<ProductVersionModel[]> GetActionReportProductVersionsAsync()
        {
            return await this.Repository.GetActionReportProductVersionsAsync();
        }

        public async Task<ProductVersionModel[]> GetProductsAsync(int minimumStatusID, int maximumStatusID)
        {
            return await this.Repository.GetProductsAsync(minimumStatusID, maximumStatusID);
        }
        public async Task<ProductVersionModel> GetUserInRolesListAsync(int employeeId)
        {
            ProductVersionModel userInRoles = new ProductVersionModel();
            string key = "UserInRolesList_" + employeeId;
            int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
            userInRoles = await this.CacheService.GetCacheAsync<ProductVersionModel>(key, true);
            if (userInRoles == null)
            {
                userInRoles = await this.Repository.GetUserInRolesListAsync(employeeId);
                if (userInRoles != null)
                {
                    await this.CacheService.SetCacheAsync<ProductVersionModel>(key, userInRoles, expiryTime, userInRoles.GetType().Name, true);
                }
            }

            return userInRoles;
        }

        public async Task<bool> TrySyncSelectedProductsAsync(string values, string userProfile)
        {
            return await this.Repository.TrySyncSelectedProductsAsync(values, userProfile);
        }

        #region SCMNames
        public async Task<ProductVersionModel[]> GetScmNamesAsync(string avNumber)
        {
            return await this.Repository.GetScmNamesAsync(avNumber);
        }
        #endregion

        public async Task<string> GetDCRNotificationAsync(int programId)
        {
            return await this.Repository.GetDCRNotificationAsync(programId);
        }
        public async Task<ProductVersionModel> GetApproversAsync(int programId)
        {
            return await this.Repository.GetApproversAsync(programId);
        }

        public async Task<ProductVersionModel[]> GetProductVersionPulsarAsync(int id)
        {
            ProductVersionModel[] productVersionPulsar = null;
            string key = "productversionpulsar" + id;
            int expiryTime = AppSettings.Get<int>("CacheExpiry:InMinutes");
            productVersionPulsar = await this.CacheService.GetCacheAsync<ProductVersionModel[]>(key, true);
            if (productVersionPulsar == null)
            {
                productVersionPulsar = await this.Repository.GetProductVersionPulsarAsync(id);
                if (productVersionPulsar != null)
                {
                    await this.CacheService.SetCacheAsync<ProductVersionModel[]>(key, productVersionPulsar, expiryTime, productVersionPulsar.GetType().Name, true);
                }
            }

            return productVersionPulsar;
        }

        public async Task<ProductVersionModel[]> GetChangeRequestProductSelectionAsync(int? selectionType, int? selectionFilterId)
        {
            return await this.Repository.GetChangeRequestProductSelectionAsync(selectionType, selectionFilterId);
        }

        public async Task<ProductVersionModel[]> GetChangeRequestProductSegementSelectionAsync(int? selectionType, int? selectionFilterId)
        {
            return await this.Repository.GetChangeRequestProductSegementSelectionAsync(selectionType, selectionFilterId);
        }

        public async Task<ProductVersionModel[]> GetTodayActionProductsAsync()
        {
            return await this.Repository.GetTodayActionProductsAsync();
        }

        public async Task<ProductVersionModel[]> GetTodayActionProductsByIdAsync(string productIds)
        {
            return await this.Repository.GetTodayActionProductsByIdAsync(productIds);
        }

        public async Task<ProductVersionModel> GetDefaultDCROwnerAsync(int ProductId)
        {
            return await this.Repository.GetDefaultDCROwnerAsync(ProductId);
        }
        public async Task<ProductVersionModel> GetListProductsAsync(int id)
        {
            return await this.Repository.GetListProductsAsync(id);
        }

        public async Task<ProductVersionModel> GetListProductsPulsarAsync(int id)
        {
            return await this.Repository.GetListProductsPulsarAsync(id);
        }

        public async Task<ProductVersionReleaseModel[]> GetProductReleaseTodayActionAsync(int productId)
        {
            return await this.Repository.GetProductReleaseTodayActionAsync(productId);
        }


        #region Reference Platform
        public async Task<string> GetReferencePlatformAsync(int productVersionId)
        {
            return await this.Repository.GetReferencePlatformAsync(productVersionId);
        }
        #endregion


        public async Task<ProductVersionModel[]> GetImagesForProductRolloutFusionAsync(int productVersionId, PaginationModel pagination)
        {
            return await this.Repository.GetImagesForProductRolloutFusionAsync(productVersionId, pagination);
        }


        public async Task<ProductVersionModel[]> GetImageDefinitionBrandsAsync(int imageId)
        {
            return await this.Repository.GetImageDefinitionBrandsAsync(imageId);
        }


        public async Task<ProductVersionModel[]> GetImageDefinitionBrandsFusionAsync(int imageDefId)
        {
            return await this.Repository.GetImageDefinitionBrandsFusionAsync(imageDefId);
        }

        public async Task<ProductVersionModel[]> GetImagesForProductFusionAsync(int productId)
        {
            return await this.Repository.GetImagesForProductFusionAsync(productId);
        }

        public async Task<ProductVersionModel[]> GetImagesForDefinitionLocalizationAsync(int imageDefId)
        {
            return await this.Repository.GetImagesForDefinitionLocalizationAsync(imageDefId);
        }

        public async Task<ProductVersionModel[]> GetImagesForAllProductAsync(int productId)
        {
            return await this.Repository.GetImagesForAllProductAsync(productId);
        }

        #region GetOdmPmsEmails
        public async Task<string> GetPCEmailForTodayActionAsync(int productId)
        {
            return await this.Repository.GetPCEmailForTodayActionAsync(productId);
        }
        #endregion


        public async Task<ProductVersionModel[]> GetProductsAsync(int? type)
        {
            return await this.Repository.GetProductsAsync(type);
        }


        public async Task<ProductVersionModel[]> GetProductsForRootAsync(int deliverableRootId, int? report)
        {
            return await this.Repository.GetProductsForRootAsync(deliverableRootId, report);
        }



        #region ProductMarketingNames
        public async Task<ProductVersionModel[]> GetProductMarketingNamesAsync(PaginationModel pagination)
        {
            return await this.Repository.GetProductMarketingNamesAsync(pagination);
        }
        #endregion

        #region ProductSummary
        public async Task<ProductVersionModel[]> GetProductSummaryAsync(PaginationModel pagination, string showAll, string devCenter, string cycle, string odm)
        {
            return await this.Repository.GetProductSummaryAsync(pagination, showAll, devCenter, cycle, odm);
        }
        #endregion

        public async Task<ProductVersionModel[]> GetProductsInProgramAsync(int id)
        {
            return await this.Repository.GetProductsInProgramAsync(id);
        }
    }
}
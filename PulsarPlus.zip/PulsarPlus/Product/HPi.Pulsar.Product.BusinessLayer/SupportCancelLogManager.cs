using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class SupportCancelLogManager : BaseManager<ISupportCancelLogRepository>, ISupportCancelLogService
    {
        public SupportCancelLogManager(IApplicationServices applicationService, ISupportCancelLogRepository supportCancelLogRepository) : base(applicationService, supportCancelLogRepository)
        {
        }

        #region Cancel Support
        public async Task<bool> TryCancelSupportLogAsync(SupportModel support)
        {
            return await this.Repository.TryCancelSupportLogAsync(support);
        }
        #endregion
    }
}
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductDeliverableRootManager : BaseManager<IProductDeliverableRootRepository>, IProductDeliverableRootService
    {
        public ProductDeliverableRootManager(IApplicationServices applicationService, IProductDeliverableRootRepository productDeliverableRootRepository) : base(applicationService, productDeliverableRootRepository)
        {
        }

        public async Task<ProductDelRootModel> GetProductIDByProdRootAsync(int? prodRootID, int productDeliverableReleaseID)
        {
            return await this.Repository.GetProductIDByProdRootAsync(prodRootID, productDeliverableReleaseID);
        }

        public async Task<ProductDelRootModel> GetProductDelRootIdAsync(int productId, int rootId, int releaseId = 0)
        {
            return await this.Repository.GetProductDelRootIdAsync(productId, rootId, releaseId);
        }

        public async Task<bool> TryAddDelRootToProductAsync(LinkProductModel linkProductModel)
        {
            return await this.Repository.TryAddDelRootToProductAsync(linkProductModel);
        }

        public async Task<ProductDelRootModel> GetBridgesOnOtherVersionsCountAsync(int productId, int versionId)
        {
            return await this.Repository.GetBridgesOnOtherVersionsCountAsync(productId, versionId);
        }

        public async Task<int> GetSubassemblyCountAsync(int productId, int versionId)
        {
            return await this.Repository.GetSubassemblyCountAsync(productId, versionId);
        }

        public async Task<ProductDelRootModel> GetBridgesOnOtherVersionsReleaseCountAsync(int productId, int versionId)
        {
            return await this.Repository.GetBridgesOnOtherVersionsReleaseCountAsync(productId, versionId);
        }

        public async Task<int> GetSubassemblyReleaseCountAsync(int productId, int versionId, int productDeliverableReleaseId)
        {
            return await this.Repository.GetSubassemblyReleaseCountAsync(productId, versionId, productDeliverableReleaseId);
        }

        #region ChangeImages
        public async Task<bool> TryUpdateImageDefaultsAsync(ProductDelRootModel productDelRoot)
        {
            return await this.Repository.TryUpdateImageDefaultsAsync(productDelRoot);
        }

        #endregion

        public async Task<DeliverableRootModel[]> GetCommoditySubAssemblyNumberReleaseAsync(int productID, int rootID, int releaseID)
        {
            return await this.Repository.GetCommoditySubAssemblyNumberReleaseAsync(productID, rootID, releaseID);
        }

        public async Task<DeliverableRootModel[]> GetCommoditySubAssemblyNumberAsync(int productID, int rootID)
        {
            return await this.Repository.GetCommoditySubAssemblyNumberAsync(productID, rootID);
        }

        public async Task<ProductDelRootModel[]> GetSubassembyDefaultBaseReleaseAsync(int productVersionID, int deliverableRootID)
        {
            return await this.Repository.GetSubassembyDefaultBaseReleaseAsync(productVersionID, deliverableRootID);
        }

        public async Task<ProductDelRootModel[]> GetSubassembyDefaultBaseAsync(int productVersionID, int deliverableRootID)
        {
            return await this.Repository.GetSubassembyDefaultBaseAsync(productVersionID, deliverableRootID);
        }


        public async Task<ProductDelRootModel[]> GetServiceSubassembyDefaultBaseReleaseAsync(int productVersionID, int deliverableRootID)
        {
            return await this.Repository.GetServiceSubassembyDefaultBaseReleaseAsync(productVersionID, deliverableRootID);
        }

        public async Task<ProductDelRootModel[]> GetServiceSubassembyD0efaultBaseAsync(int productVersionID, int deliverableRootID)
        {
            return await this.Repository.GetServiceSubassembyDefaultBaseAsync(productVersionID, deliverableRootID);
        }

        public async Task<bool> TryUpdateSubassemblyNumberReleaseAsync(ProductDelRootModel productDelRoot)
        {
            return await this.Repository.TryUpdateSubassemblyNumberReleaseAsync(productDelRoot);
        }

        public async Task<bool> TryUpdateSubassemblyNumberAsync(ProductDelRootModel productDelRoot)
        {
            return await this.Repository.TryUpdateSubassemblyNumberAsync(productDelRoot);
        }

        public async Task<bool> TryUpdateSubassemblyNumberEngineeringReleaseAsync(ProductDelRootModel productDelRoot)
        {
            return await this.Repository.TryUpdateSubassemblyNumberEngineeringReleaseAsync(productDelRoot);
        }

        public async Task<bool> TryUpdateSubassemblyNumberEngineeringAsync(ProductDelRootModel productDelRoot)
        {
            return await this.Repository.TryUpdateSubassemblyNumberEngineeringAsync(productDelRoot);
        }

        public async Task<bool> TryUpdateSubassemblyNumberServiceReleaseAsync(ProductDelRootModel productDelRoot)
        {
            return await this.Repository.TryUpdateSubassemblyNumberServiceReleaseAsync(productDelRoot);
        }

        public async Task<bool> TryUpdateSubassemblyNumberServiceAsync(ProductDelRootModel productDelRoot)
        {
            return await this.Repository.TryUpdateSubassemblyNumberServiceAsync(productDelRoot);
        }
        public async Task<ProductDelRootModel[]> GetListSubassembliesForRootAsync(int rootId)
        {
            return await this.Repository.GetListSubassembliesForRootAsync(rootId);
        }

        public async Task<ProductDelRootModel[]> GetNativeSubAssemblyBaseAsync(string subAssemblyBase, int nativeRootID, int productVersionID)
        {
            return await this.Repository.GetNativeSubAssemblyBaseAsync(subAssemblyBase, nativeRootID, productVersionID);
        }
    }
}

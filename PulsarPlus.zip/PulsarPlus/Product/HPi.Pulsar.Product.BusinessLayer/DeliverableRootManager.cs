using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DeliverableRootManager : BaseManager<IDeliverableRootRepository>, IDeliverableRootService
    {
        public DeliverableRootManager(IApplicationServices applicationService, IDeliverableRootRepository deliverableRootRepository) : base(applicationService, deliverableRootRepository)
        {
        }

        public async Task<DeliverableRootModel> GetDeliverableRootInfoAsync(int rootId)
        {
            return await this.Repository.GetDeliverableRootInfoAsync(rootId).ConfigureAwait(false);
        }

        public async Task<DeliverableRootModel[]> GetSubassembliesAllAppropriateAsync(int productId, int versionId)
        {
            return await this.Repository.GetSubassembliesAllAppropriateAsync(productId, versionId).ConfigureAwait(false);
        }

        public async Task<DeliverableRootModel[]> GetSubassembliesAllAppropriateReleaseAsync(int productId, int versionId, int productDeliverableReleaseId)
        {
            return await this.Repository.GetSubassembliesAllAppropriateReleaseAsync(productId, versionId, productDeliverableReleaseId).ConfigureAwait(false);
        }

        #region DevRejectProductRequirement
        public async Task<DeliverableRootModel> GetProductDeliverableRootSummaryByIdAsync(int id, int productDeliverableReleaseId)
        {
            return await this.Repository.GetProductDeliverableRootSummaryByIdAsync(id, productDeliverableReleaseId).ConfigureAwait(false);
        }

        public async Task<DeliverableRootModel[]> GetDeliverableRootProductPMWithMultipleItemAsync(string product)
        {
            return await this.Repository.GetDeliverableRootProductPMWithMultipleItemAsync(product).ConfigureAwait(false);
        }
        #endregion

        #region ChangeImages
        public async Task<DeliverableRootModel> GetRootPropertiesForVersionAsync(int id)
        {
            return await this.Repository.GetRootPropertiesForVersionAsync(id).ConfigureAwait(false);
        }

        public async Task<DeliverableRootModel> GetDistributionRootAsync(int productId, int rootId)
        {
            return await this.Repository.GetDistributionRootAsync(productId, rootId).ConfigureAwait(false);
        }

        #endregion
		public async Task<bool> TryUpdateDeliverableRootAsync(DeliverableRootModel deliverableRoot)
        {
            return await this.Repository.TryUpdateDeliverableRootAsync(deliverableRoot).ConfigureAwait(false);
        }
        public async Task<DeliverableRootModel[]> GetDeliverableNameSubAssemblyAsync(string productDelRootId)
        {
            return await this.Repository.GetDeliverableNameSubAssemblyAsync(productDelRootId).ConfigureAwait(false);
        }

        public async Task<DeliverableRootModel[]> GetRootPropertiesAsync(int Id)
        {
            return await this.Repository.GetRootPropertiesAsync(Id).ConfigureAwait(false);
        }

        #region ProductDeliverables

        public async Task<DeliverableRootModel[]> GetDeliverableRootsAsync(int type, int pageNumber, int pageSize, string searchString)
        {
            return await this.Repository.GetDeliverableRootsAsync(type, pageNumber, pageSize,searchString).ConfigureAwait(false);
        }
        #endregion

        public async Task<DeliverableRootModel> GetRootAsync(int id)
        {
            return await this.Repository.GetRootAsync(id).ConfigureAwait(false);
        }

		public async Task<DeliverableRootModel[]> GetProductsByDeliverableReleaseAsync(int rootId,int saType,int assigned)
		{
			return await this.Repository.GetProductsByDeliverableReleaseAsync(rootId,saType,assigned).ConfigureAwait(false);	
		}

        public async Task<DeliverableRootModel[]> GetNamingStandardDeploymentValuesAsync()
        {
            return await this.Repository.GetNamingStandardDeploymentValuesAsync().ConfigureAwait(false);
        }
        public async Task<DeliverableRootModel[]> GetDeliverableRootMainDataAsync (PaginationModel pagination)
        {
            return await this.Repository.GetDeliverableRootMainDataAsync(pagination).ConfigureAwait(false);
        }
    }
}
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ScheduleDefinitionDataManager : BaseManager<IScheduleDefinitionDataRepository>, IScheduleDefinitionDataService
    {
        public ScheduleDefinitionDataManager(IApplicationServices applicationService, IScheduleDefinitionDataRepository scheduleDefinitionDataRepository) : base(applicationService, scheduleDefinitionDataRepository)
        {
        }

        #region Milestone Pulsar ScheduleDefinitionData
        public async Task<ScheduleDefinitionDataModel[]> GetMilestonePulsarScheduleDefinitionDataAsync()
        {
            return await this.Repository.GetMilestonePulsarScheduleDefinitionDataAsync();
        }

        public async Task<int> GetGenericOwnerAsync(int scheduleDefinitionDataId)
        {
            return await this.Repository.GetGenericOwnerAsync(scheduleDefinitionDataId);
        }
        #endregion

        public async Task<ScheduleDefinitionDataModel[]> GetListOwnersAsync()
        {
            return await this.Repository.GetListOwnersAsync();
        }
    }
}
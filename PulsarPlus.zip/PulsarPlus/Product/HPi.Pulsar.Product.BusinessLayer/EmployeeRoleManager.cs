using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Caching;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class EmployeeRoleManager : BaseManager<IEmployeeRoleRepository>, IEmployeeRoleService
    {
        public EmployeeRoleManager(IApplicationServices applicationService, IEmployeeRoleRepository employeeRoleRepository, ICacheService cacheService) : base(applicationService, employeeRoleRepository)
        {
            this.CacheService = cacheService;
        }

        protected ICacheService CacheService { get; set; }

        #region UserInRole
        public async Task<int> GetUserInRoleAsync(int userId, int? productVersionId, string roleName)
        {
            return await this.Repository.GetUserInRoleAsync(userId, productVersionId, roleName).ConfigureAwait(false);
        }
        #endregion
    }
}
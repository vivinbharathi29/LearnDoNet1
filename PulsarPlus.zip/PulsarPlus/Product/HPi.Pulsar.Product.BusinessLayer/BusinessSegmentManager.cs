using System.Threading.Tasks;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Services;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class BusinessSegmentManager : BaseManager<IBusinessSegmentRepository>, IBusinessSegmentService
    {
        public BusinessSegmentManager(IApplicationServices applicationService, IBusinessSegmentRepository businessSegmentRepository) : base(applicationService, businessSegmentRepository)
        {
        }

        public async Task<BusinessSegmentModel[]> GetBusinessSegmentsAsync()
        {
            return await this.Repository.GetBusinessSegmentsAsync().ConfigureAwait(false);
        }
    }
}
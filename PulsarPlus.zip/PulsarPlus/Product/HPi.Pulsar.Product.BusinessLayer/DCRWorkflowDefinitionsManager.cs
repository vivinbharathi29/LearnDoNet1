using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class DCRWorkflowDefinitionsManager : BaseManager<IDCRWorkflowDefinitionsRepository>, IDCRWorkflowDefinitionsService
    {
        public DCRWorkflowDefinitionsManager(IApplicationServices applicationService, IDCRWorkflowDefinitionsRepository dCRWorkflowDefinitionsRepository) : base(applicationService, dCRWorkflowDefinitionsRepository)
        {
        }

        #region DCRWorkflowMilestone
        public async Task<DcrWorkflowDefinitionModel[]> GetDCRWorkflowDefinitionsAsync(int userId)
        {
            return await this.Repository.GetDCRWorkflowDefinitionsAsync(userId).ConfigureAwait(false);
        }

        public async Task<int> GetDCRWorkflowDefinitionsCountAsync(int? userId)
        {
            return await this.Repository.GetDCRWorkflowDefinitionsCountAsync(userId).ConfigureAwait(false);
        }
        #endregion

        #region DCRWorkflowStatus
        public async Task<DcrWorkflowDefinitionModel[]> GetDCRWorkflowStatusAsync(int dcrId)
        {
            return await this.Repository.GetDCRWorkflowStatusAsync(dcrId).ConfigureAwait(false);
        }

        public async Task<ProductVersionModel> GetSuperUsersByProductAsync(int pvId)
        {
            return await this.Repository.GetSuperUsersByProductAsync(pvId).ConfigureAwait(false);
        }

        public async Task<DcrWorkflowDefinitionModel[]> GetDCRWorkflowEmailListAsync(int dcrId, int pvId)
        {
            return await this.Repository.GetDCRWorkflowEmailListAsync(dcrId, pvId).ConfigureAwait(false);
        }

        public async Task<bool> TryTerminateDCRWorkflowAsync(int dcrId, int userId)
        {
            return await this.Repository.TryTerminateDCRWorkflowAsync(dcrId, userId).ConfigureAwait(false);
        }
        #endregion

        #region UpdateDCRWorkflowStatus
        public async Task<bool> TryUpdateDCRWorkflowCommentsAsync(int historyId, string comments)
        {
            return await this.Repository.TryUpdateDCRWorkflowCommentsAsync(historyId, comments).ConfigureAwait(false);
        }

        public async Task<bool> TryUpdateDCRWorkflowCompleteAsync(int historyId, int dcrId, int pvId)
        {
            return await this.Repository.TryUpdateDCRWorkflowCompleteAsync(historyId, dcrId, pvId).ConfigureAwait(false);
        }
        #endregion

        #region View Workflow Status/ Add Workflow
        public async Task<DcrWorkflowDefinitionModel[]> GetAllDCRWorkflowDefinitionsAsync()
        {
            return await this.Repository.GetAllDCRWorkflowDefinitionsAsync().ConfigureAwait(false);
        }
        #endregion

    }
}
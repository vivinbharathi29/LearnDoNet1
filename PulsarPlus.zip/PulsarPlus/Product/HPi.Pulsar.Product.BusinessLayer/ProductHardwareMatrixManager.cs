using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductHardwareMatrixManager : BaseManager<IProductHardwareMatrixRepository>, IProductHardwareMatrixService
    {
        public ProductHardwareMatrixManager(IApplicationServices applicationService, IProductHardwareMatrixRepository productHardwareMatrixRepository) : base(applicationService, productHardwareMatrixRepository)
        {
        }

        public async Task<HardwareMatrixSearchModel> GetHardwareMatrixSearchResultAsync(HardwareMatrixInputModel hardwareMatrixInput)
        {
            return await this.Repository.GetHardwareMatrixSearchResultAsync(hardwareMatrixInput);
        }

        public async Task<HardwareMatrixSearchModel> GetHardwareMatrixProductListForDisplayAsync(HardwareMatrixInputModel hardwareMatrixInput)
        {
            return await this.Repository.GetHardwareMatrixProductListForDisplayAsync(hardwareMatrixInput);
        }

        public async Task<ProductVersionModel[]> GetSubassembliesExpiringProductionAsync(string productId, string categoryId, int months, PaginationModel pagination)
        {
            return await this.Repository.GetSubassembliesExpiringProductionAsync(productId, categoryId, months, pagination);
        }

        public async Task<ProductVersionModel[]> GetSubassembliesExpiringPostProductionAsync(string productId, string categoryId, int months, PaginationModel pagination)
        {
            return await this.Repository.GetSubassembliesExpiringPostProductionAsync(productId, categoryId, months, pagination);
        }

        public async Task<HardwareMatrixSearchModel> GetProductHardwareMatrixResultAsync(HardwareMatrixInputModel hardwareMatrixInput)
        {
            return await this.Repository.GetProductHardwareMatrixResultAsync(hardwareMatrixInput);
        }

        public async Task<HardwareMatrixSearchModel> GetCategoryProductReleaseCountAsync(HardwareMatrixInputModel hardwareMatrixInput)
        {
            return await this.Repository.GetCategoryProductReleaseCountAsync(hardwareMatrixInput);
        }
    }
}

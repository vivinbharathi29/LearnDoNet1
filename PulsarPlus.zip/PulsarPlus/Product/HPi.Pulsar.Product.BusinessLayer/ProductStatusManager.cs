using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductStatusManager : BaseManager<IProductStatusRepository>, IProductStatusService
    {
        public ProductStatusManager(IApplicationServices applicationService, IProductStatusRepository productStatusRepository) : base(applicationService, productStatusRepository)
        {
        }

        public async Task<ProductStatusModel[]> GetProductStatusesAsync()
        {
            string key = "ProductStatuses";
            var productStatuses = await this.ApplicationService.Cache.GetCacheAsync<ProductStatusModel[]>(key, true);
            if (productStatuses == null)
            {
                productStatuses = await this.Repository.GetProductStatusesAsync();
                await this.ApplicationService.Cache.SetCacheAsync<ProductStatusModel[]>(key, productStatuses, CacheExpiryLongTime, productStatuses.GetType().Name, true);
            }

            return productStatuses;
        }
        public async Task<ProductStatusModel> GetListPhaseAsync(int id)
        {
            return await this.Repository.GetListPhaseAsync(id);
        }

        public async Task<ProductStatusModel[]> GetSelectPhaseListAsync()
        {
            return await this.Repository.GetSelectPhaseListAsync();
        }


    }
}
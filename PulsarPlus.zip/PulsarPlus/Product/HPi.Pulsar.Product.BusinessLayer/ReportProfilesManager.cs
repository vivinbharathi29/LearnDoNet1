using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ReportProfilesManager : BaseManager<IReportProfilesRepository>, IReportProfilesService
    {
        public ReportProfilesManager(IApplicationServices applicationService, IReportProfilesRepository reportProfilesRepository) : base(applicationService, reportProfilesRepository)
        {
        }

        public async Task<ReportProfileModel[]> GetReportProfilesAsync(int employeeId, int type)
        {
            return await this.Repository.GetReportProfilesAsync(employeeId, type);
        }

        public async Task<ReportProfileModel[]> GetReportProfilesSharedAsync(int employeeID, int type)
        {
            return await this.Repository.GetReportProfilesSharedAsync(employeeID, type);
        }

        public async Task<ReportProfileModel[]> GetReportProfilesGroupSharedAsync(int employeeId, int type)
        {
            return await this.Repository.GetReportProfilesGroupSharedAsync(employeeId, type);
        }

        public async Task<ReportProfileModel[]> GetReportProfileNameAsync(int employeeId)
        {
            return await this.Repository.GetReportProfileNameAsync(employeeId);
        }

        public async Task<ReportProfileModel> GetReportProfileDetailsAsync(int Id, int? employeeId)
        {
            return await this.Repository.GetReportProfileDetailsAsync(Id, employeeId);
        }
        public async Task<int> RenameProfileAsync(int id, string profileName, int? employeeId)
        {
            return await this.Repository.RenameProfileAsync(id, profileName, employeeId);
        }

        public async Task<int> DeleteProfileAsync(int profileId, int? employeeId)
        {
            return await this.Repository.DeleteProfileAsync(profileId, employeeId);
        }

        public async Task<int> UpdateProfileAsync(ReportProfileModel reportProfile)
        {
            return await this.Repository.UpdateProfileAsync(reportProfile);
        }

        public async Task<int> AddProfileAsync(ReportProfileModel reportProfile)
        {
            return await this.Repository.AddProfileAsync(reportProfile);
        }

        public async Task<int> RemoveSharedProfileAsync(int id)
        {
            return await this.Repository.RemoveSharedProfileAsync(id);
        }

        public async Task<ReportProfileModel[]> GetReportProfileSharedAsync(int id, int? employeeId)
        {
            return await this.Repository.GetReportProfileSharedAsync(id, employeeId);
        }

        public async Task<ReportProfileModel[]> GetReportProfileGroupsAsync(int id)
        {
            return await this.Repository.GetReportProfileGroupsAsync(id);
        }

		public async Task<int> RemoveSharedProfilesAsync(ReportProfileSharedModel reportProfileShared)
		{
			return await this.Repository.RemoveSharedProfilesAsync(reportProfileShared);	
		}

		public async Task<int> RemoveSharedProfileGroupAsync(ReportProfileSharedModel reportProfileShared)
		{
			return await this.Repository.RemoveSharedProfileGroupAsync(reportProfileShared);	
		}

		public async Task<int> UpdateSharedProfileGroupAsync(ReportProfileSharedModel reportProfileShared)
		{
			return await this.Repository.UpdateSharedProfileGroupAsync(reportProfileShared);	
		}

		public async Task<int> UpdateSharedProfilesAsync(ReportProfileSharedModel reportProfileShared)
		{
			return await this.Repository.UpdateSharedProfilesAsync(reportProfileShared);	
		}

}
}
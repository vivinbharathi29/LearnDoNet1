using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{

    public class ProductLeadRootExceptionsManager : BaseManager<IProductLeadRootExceptionsRepository>, IProductLeadRootExceptionsService
    {
        public ProductLeadRootExceptionsManager(IApplicationServices applicationService, IProductLeadRootExceptionsRepository productLeadRootExceptionsRepository) : base(applicationService, productLeadRootExceptionsRepository)
        {
        }

        public async Task<bool> TryRemoveLeadProductExclusionAsync(int Id)
        {
            return await this.Repository.TryRemoveLeadProductExclusionAsync(Id);
        }

        public async Task<bool> TryAddLeadProductRootExclusionAsync(ProductLeadRootExceptionModel productLeadRootExceptionsModel)
        {
            return await this.Repository.TryAddLeadProductRootExclusionAsync(productLeadRootExceptionsModel);
        }

    }
}

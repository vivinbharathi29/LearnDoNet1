using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Product.Contracts;
using HPi.Pulsar.Product.Contracts.Repositories;
using HPi.Pulsar.Product.Contracts.Services;

namespace HPi.Pulsar.Product.BusinessLayer
{
    public class ActionApprovalManager : BaseManager<IActionApprovalRepository>, IActionApprovalService
    {
        public ActionApprovalManager(IApplicationServices applicationService, IActionApprovalRepository actionApprovalRepository) : base(applicationService, actionApprovalRepository)
        {
        }

        public async Task<ActionApprovalModel[]> GetActionApprovalAsync()
        {
            string key = "ActionApproval";
            var actionApproval = await this.ApplicationService.Cache.GetCacheAsync<ActionApprovalModel[]>(key, true).ConfigureAwait(false);
            if (actionApproval == null)
            {
                actionApproval = await this.Repository.GetActionApprovalAsync().ConfigureAwait(false);
                await this.ApplicationService.Cache.SetCacheAsync<ActionApprovalModel[]>(key, actionApproval, CacheExpiryLongTime, actionApproval.GetType().Name, true).ConfigureAwait(false);
            }

            return actionApproval;
        }

        public async Task<ActionApprovalModel[]> GetListApprovalsAsync(int actionId, int? approverId)
        {
            return await this.Repository.GetListApprovalsAsync(actionId, approverId).ConfigureAwait(false);
        }

        public async Task<ActionApprovalModel> GetVerifyAutoApproveAsync(int actionId)
        {
            return await this.Repository.GetVerifyAutoApproveAsync(actionId).ConfigureAwait(false);
        }

        public async Task<int> AddActionApproverAsync(ActionApprovalModel actionApproval)
        {
            return await this.Repository.AddActionApproverAsync(actionApproval).ConfigureAwait(false);
        }

        public async Task<int> UpdateActionApproverAsync(ActionApprovalModel actionApproval)
        {
            return await this.Repository.UpdateActionApproverAsync(actionApproval).ConfigureAwait(false);
        }

        #region UpdateApprovalStatus
        public async Task<int> UpdateApprovalStatusAsync(int approvalId, int status)
        {
            return await this.Repository.UpdateApprovalStatusAsync(approvalId, status).ConfigureAwait(false);
        }
        #endregion
    }
}
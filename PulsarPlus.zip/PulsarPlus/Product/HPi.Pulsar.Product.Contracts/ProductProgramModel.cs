﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts
{
    public class ProductProgramModel
    {
        /// <summary>
        /// Gets or sets the ProgramId.
        /// </summary>
        public int ProgramId { get; set; }

        /// <summary>
		/// Gets or sets the ProductVersionId.
		/// </summary>
		public int ProductVersionId { get; set; }

        /// <summary>
		/// Gets or sets the Id.
		/// </summary>
		public int Id { get; set; }

        /// <summary>
		/// Gets or sets the CommonBucketLink.
		/// </summary>
		public bool CommonBucketLink { get; set; }
    }
}



namespace HPi.Pulsar.Product.Contracts
{
    using Contracts;
    using System;

    /// <summary>
    /// <para>RegionsModel</para>
    /// </summary>
    public class RegionModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the OldBusiness.
        /// </summary>
        public byte? OldBusiness { get; set; }

        /// <summary>
        /// Gets or sets the Consumer.
        /// </summary>
        public bool? Consumer { get; set; }

        /// <summary>
        /// Gets or sets the Commercial.
        /// </summary>
        public bool? Commercial { get; set; }

        /// <summary>
        /// Gets or sets the SMB.
        /// </summary>
        public bool? Smb { get; set; }

        /// <summary>
        /// Gets or sets the Tablet.
        /// </summary>
        public bool? Tablet { get; set; }

        /// <summary>
        /// Gets or sets the GeoID.
        /// </summary>
        public byte? GeoId { get; set; }

        /// <summary>
        /// Gets or sets the Geo.
        /// </summary>
        public string Geo { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the Dash.
        /// </summary>
        public string Dash { get; set; }

        /// <summary>
        /// Gets or sets the OptionConfig.
        /// </summary>
        public string OptionConfig { get; set; }

        /// <summary>
        /// Gets or sets the CountryCode.
        /// </summary>
        public string CountryCode { get; set; }

        /// <summary>
        /// Gets or sets the Keyboard.
        /// </summary>
        public string Keyboard { get; set; }

        /// <summary>
        /// Gets or sets the KWL.
        /// </summary>
        public string Kwl { get; set; }

        /// <summary>
        /// Gets or sets the PowerCord.
        /// </summary>
        public string PowerCord { get; set; }

        /// <summary>
        /// Gets or sets the OSLanguage.
        /// </summary>
        public string OSLanguage { get; set; }

        /// <summary>
        /// Gets or sets the OtherLanguage.
        /// </summary>
        public string OtherLanguage { get; set; }

        /// <summary>
        /// Gets or sets the MUILanguage.
        /// </summary>
        public string MUILanguage { get; set; }

        /// <summary>
        /// Gets or sets the DocKits.
        /// </summary>
        public string DocKits { get; set; }

        /// <summary>
        /// Gets or sets the DisplayOrder.
        /// </summary>
        public int DisplayOrder { get; set; }

        /// <summary>
        /// Gets or sets the DisplayName.
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the Active.
        /// </summary>
        public bool? Active { get; set; }

        /// <summary>
        /// Gets or sets the Transitioning.
        /// </summary>
        public bool? Transitioning { get; set; }

        /// <summary>
        /// Gets or sets the MUI.
        /// </summary>
        public string Mui { get; set; }

        /// <summary>
        /// Gets or sets the RestoreMedia.
        /// </summary>
        public string RestoreMedia { get; set; }

        /// <summary>
        /// Gets or sets the ImageLanguage.
        /// </summary>
        public string ImageLanguage { get; set; }

        /// <summary>
        /// Gets or sets the PrintedDocs.
        /// </summary>
        public string PrintedDocs { get; set; }

        /// <summary>
        /// Gets or sets the Comments.
        /// </summary>
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets the ServiceGeoID.
        /// </summary>
        public byte? ServiceGeoId { get; set; }

        /// <summary>
        /// Gets or sets the IRSRegionId.
        /// </summary>
        public int? IrsRegionId { get; set; }

        /// <summary>
        /// Gets or sets the GMCode.
        /// </summary>
        public string GMCode { get; set; }

        /// <summary>
        /// Gets or sets the AndroidMobilityConsumer.
        /// </summary>
        public bool? AndroidMobilityConsumer { get; set; }

        /// <summary>
        /// Gets or sets the CreatedBy.
        /// </summary>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the UpdatedBy.
        /// </summary>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Created.
        /// </summary>
        public DateTime? Created { get; set; }

        /// <summary>
        /// Gets or sets the Updated.
        /// </summary>
        public DateTime? Updated { get; set; }

        /// <summary>
        /// Gets or sets the NewGEOId.
        /// </summary>
        public int? NewGeoId { get; set; }

        /// <summary>
        /// Gets or sets the GPSyDesc.
        /// </summary>
        public string GPSyDesc { get; set; }

        /// <summary>
        /// Gets or sets the PHWebDesc.
        /// </summary>
        public string PHWebDesc { get; set; }

        /// <summary>
        /// Gets or sets the KeyboardLayoutID.
        /// </summary>
        public int? KeyboardLayoutId { get; set; }

        /// <summary>
        /// Gets or sets the PowerCordGEOID.
        /// </summary>
        public int? PowerCordGeoId { get; set; }

        /// <summary>
        /// Gets or sets the DuckheadPowerCordGEOID.
        /// </summary>
        public int? DuckheadPowerCordGeoId { get; set; }

        /// <summary>
        /// Gets or sets the DuckheadGEOID.
        /// </summary>
        public int? DuckheadGeoId { get; set; }


        /// <summary>
        /// Gets or sets the PowerCordGEO.
        /// </summary>
        public PowerCordGEOModel PowerCordGEO { get; set; }

        /// <summary>
        /// Gets or sets the RegionKeyboardLayout.
        /// </summary>
        public RegionKeyboardLayoutModel RegionKeyboardLayout { get; set; }

        /// <summary>
        /// Gets or sets the images.
        /// </summary>
        /// <value>
        /// The images.
        /// </value>
        public ImageModel Images { get; set; }

        /// <summary>
        /// Gets or sets the image definitions.
        /// </summary>
        /// <value>
        /// The image definitions.
        /// </value>
        public ImageDefinitionModel ImageDefinitions { get; set; }


        /// <summary>
        /// Gets or sets the os lookup.
        /// </summary>
        /// <value>
        /// The os lookup.
        /// </value>
        public OSLookupModel OsLookup { get; set; }

         /// <summary>
        /// Gets or sets the business segment ids.
        /// </summary>
        /// <value>
        /// The business segment ids.
        /// </value>
        public string BusinessSegmentIds { get; set; }

        /// <summary>
        /// Gets or sets the channel partners.
        /// </summary>
        /// <value>
        /// The channel partners.
        /// </value>
        public string ChannelPartners { get; set; }

        /// <summary>
        /// Gets or sets the channel partner ids.
        /// </summary>
        /// <value>
        /// The channel partner ids.
        /// </value>
        public string ChannelPartnerIds { get; set; }

       /// <summary>
        /// Gets or sets the image.
        /// </summary>
        /// <value>
        /// The image.
        /// </value>
        public ImageModel Image { get; set; }

        /// <summary>
        /// Gets or sets the image drive definition.
        /// </summary>
        /// <value>
        /// The image drive definition.
        /// </value>
        public ImageDriveDefinitionModel ImageDriveDefinition { get; set; }
    }
}
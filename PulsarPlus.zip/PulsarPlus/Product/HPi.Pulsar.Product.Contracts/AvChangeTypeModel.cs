namespace HPi.Pulsar.Product.Contracts
{
    public class AvChangeTypeModel
    {
        public int AvChangeTypeID { get; set; }

        public string AvChangeTypeDesc { get; set; }

        public string AvChangeTypeCd { get; set; }
    }
}
namespace HPi.Pulsar.Product.Contracts
{
    public class AvSaMappingModel
    {
        public int MappingId { get; set; }

        public int DeliverableRootId { get; set; }

        public int AvFeatureCategoryId { get; set; }

        public int RegionId { get; set; }

        public string RegionIds { get; set; }
    }
}
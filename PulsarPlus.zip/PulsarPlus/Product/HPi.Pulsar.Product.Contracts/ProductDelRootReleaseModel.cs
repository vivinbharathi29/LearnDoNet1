

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductDelRootReleaseModel</para>
    /// </summary>
    public class ProductDelRootReleaseModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ProductDelRootID.
		/// </summary>
		public int ProductDelRootId { get; set; }

		/// <summary>
		/// Gets or sets the ReleaseID.
		/// </summary>
		public int ReleaseId { get; set; }

		/// <summary>
		/// Gets or sets the Base.
		/// </summary>
		public string Base { get; set; }

		/// <summary>
		/// Gets or sets the Spin.
		/// </summary>
		public string Spin { get; set; }

		/// <summary>
		/// Gets or sets the Subassembly.
		/// </summary>
		public string Subassembly { get; set; }

		/// <summary>
		/// Gets or sets the TargetNotes.
		/// </summary>
		public string TargetNotes { get; set; }

		/// <summary>
		/// Gets or sets the OOCRelease.
		/// </summary>
		public bool? OocRelease { get; set; }

		/// <summary>
		/// Gets or sets the ServiceBase.
		/// </summary>
		public string ServiceBase { get; set; }

		/// <summary>
		/// Gets or sets the ServiceSpin.
		/// </summary>
		public string ServiceSpin { get; set; }

		/// <summary>
		/// Gets or sets the ServiceSubassembly.
		/// </summary>
		public string ServiceSubassembly { get; set; }

		/// <summary>
		/// Gets or sets the Created.
		/// </summary>
		public DateTime? Created { get; set; }

		/// <summary>
		/// Gets or sets the CreatedBy.
		/// </summary>
		public string CreatedBy { get; set; }

		/// <summary>
		/// Gets or sets the Updated.
		/// </summary>
		public DateTime? Updated { get; set; }

		/// <summary>
		/// Gets or sets the UpdatedBy.
		/// </summary>
		public string UpdatedBy { get; set; }

		/// <summary>
		/// Gets or sets the DeveloperNotificationStatus.
		/// </summary>
		public byte? DeveloperNotificationStatus { get; set; }

		/// <summary>
		/// Gets or sets the DeveloperTestNotes.
		/// </summary>
		public string DeveloperTestNotes { get; set; }
        /// <summary>
        /// Gets or sets the productversion.
        /// </summary>
        /// <value>
        /// The productversion.
        /// </value>
        public ProductVersionModel ProductVersion { get; set; }


    }
}
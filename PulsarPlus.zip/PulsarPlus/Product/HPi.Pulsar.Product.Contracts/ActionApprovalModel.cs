namespace HPi.Pulsar.Product.Contracts
{
    using System;

    public class ActionApprovalModel
    {
        public int Id { get; set; }

        public int ApproverId { get; set; }

        public int ActionId { get; set; }

        public byte Status { get; set; }

        public DateTime Updated { get; set; }

        public string Comments { get; set; }

        public string Role { get; set; }

		public string Approver { get; set; }

        public int Verified { get; set; }

        public int DisapprovedCount { get; set; }

        public int RequestedCount { get; set; }

        public EmployeeModel Employee { get; set; }

        public string ActionStatus { get; set; }

        public int? ApprovalStatus { get; set; }
    }
}
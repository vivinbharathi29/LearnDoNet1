using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class FeatureModel
    {
        public int FeatureId { get; set; }

		public string FeatureName { get; set; }

		public string GpgPhWeb40NB { get; set; }

		public string GPSy40NB { get; set; }

		public string Pmg100NB { get; set; }

		public string GPSy200NB { get; set; }

		public string Pmg250NB { get; set; }

		public string GpgPhWeb40DT { get; set; }

		public string GPSy40DT { get; set; }

		public string Pmg100DT { get; set; }

		public string GPSy200DT { get; set; }

		public string Pmg250DT { get; set; }

        public int FeatureCategoryId { get; set; }

        public int NamingStandardId { get; set; }

        public int DeliveryTypeId { get; set; }

		public string CodeName { get; set; }

        public string RuleId { get; set; }

        public int StatusId { get; set; }

		public string ChinaGPIdentifier { get; set; }

		public bool RequiresRoot { get; set; }

		public DateTime Created { get; set; }

		public string CreatedBy { get; set; }

		public DateTime Updated { get; set; }

		public string UpdatedBy { get; set; }

		public DateTime? Disabled { get; set; }

		public string DisabledBy { get; set; }

		public string Notes { get; set; }

		public string Zsrp32NB { get; set; }

		public string Zsrp32DT { get; set; }

		public bool? IsCombo { get; set; }

		public bool? NameChanged { get; set; }

        public int? AliasId { get; set; }

		public string ShortDescription { get; set; }

		public bool? PartnerViewable { get; set; }

		public short? OverrideRequest { get; set; }

		public string OverrideReason { get; set; }

		public int? OverrideRequesterId { get; set; }

		public string SpecControl { get; set; }

		public int? PlatformId { get; set; }

		public int? ProductVersionId { get; set; }

        public int? OSId { get; set; }

		public string FeatureNameOverride { get; set; }

        public UserInfoModel UserInfo { get; set; }

        public int ActionType { get; set; }

        public string MarketingName { get; set; }

        public string FeatureStatus { get; set; }
    }
}
﻿namespace HPi.Pulsar.Product.Contracts
{
    public class IrsComponentModel
    {
        public string ProductIds { get; set; }

        public string OSIds { get; set; }

        public int SortField { get; set; }
    }
}


namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>SeriesModel</para>
    /// </summary>
    public class SeriesModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Gets or sets the ProductBrandID.
		/// </summary>
		public int ProductBrandID { get; set; }

		/// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the BIOSBranding.
		/// </summary>
		public string BIOSBranding { get; set; }

		/// <summary>
		/// Gets or sets the LogoBadge.
		/// </summary>
		public string LogoBadge { get; set; }

		/// <summary>
		/// Gets or sets the LongName.
		/// </summary>
		public string LongName { get; set; }

		/// <summary>
		/// Gets or sets the ShortName.
		/// </summary>
		public string ShortName { get; set; }

		/// <summary>
		/// Gets or sets the FamilyName.
		/// </summary>
		public string FamilyName { get; set; }

		/// <summary>
		/// Gets or sets the BrandName.
		/// </summary>
		public string BrandName { get; set; }


    }
}


namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductRTMAlertsModel</para>
    /// </summary>
    public class ProductRTMAlertsModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ProductRTMID.
		/// </summary>
		public int ProductRTMId { get; set; }

		/// <summary>
		/// Gets or sets the ReportSectionID.
		/// </summary>
		public int ReportSectionId { get; set; }

		/// <summary>
		/// Gets or sets the SignoffDate.
		/// </summary>
		public DateTime? SignoffDate { get; set; }

		/// <summary>
		/// Gets or sets the Comments.
		/// </summary>
		public string Comments { get; set; }

		/// <summary>
		/// Gets or sets the AlertHTML.
		/// </summary>
		public string AlertHTML { get; set; }

		/// <summary>
		/// Gets or sets the UserID.
		/// </summary>
		public int? UserId { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdated.
		/// </summary>
		public DateTime? LastUpdated { get; set; }

        /// <summary>
        /// Gets or sets the ProductId.
        /// </summary>
        public int? ProductId { get; set; }

        /// <summary>
        /// Gets or sets the Employee.
        /// </summary>
        public EmployeeModel Employee { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersion.
        /// </summary>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the ProductRtm.
        /// </summary>
        public ProductRTMModel ProductRtm { get; set; }
    }
}
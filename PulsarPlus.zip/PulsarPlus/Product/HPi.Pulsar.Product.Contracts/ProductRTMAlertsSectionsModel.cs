﻿// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Product.Contracts
// Author           : 
// Created          : 04/26/2018
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="ProductRTMAlertSectionsModel.cs" company="HP">
//     Copyright ©  2016 - 2018
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductRTMAlertSectionsModel</para>
    /// </summary>
    public class ProductRTMAlertSectionsModel
    {
        /// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

        /// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }

        /// <summary>
		/// Gets or sets the Active.
		/// </summary>
		public bool? Active { get; set; }

        /// <summary>
		/// Gets or sets the DisplayOrder.
		/// </summary>
		public int? DisplayOrder { get; set; }
    }
}

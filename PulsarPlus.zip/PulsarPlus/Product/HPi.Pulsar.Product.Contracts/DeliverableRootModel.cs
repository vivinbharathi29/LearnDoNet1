﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class DeliverableRootModel
    {
        public int Id { get; set; }

        public string DeliverableCategoryId { get; set; }

        public int Selected { get; set; }

        public bool IsRealRoot { get; set; }

        public string Name { get; set; }

        public string Name2 { get; set; }

        public string Name3 { get; set; }

        public string Name4 { get; set; }

        public string Name5 { get; set; }

        public string Name6 { get; set; }

        public string Name7 { get; set; }

        public string Name8 { get; set; }

        public string NameElements { get; set; }

        public int? TypeId { get; set; }

        public string Description { get; set; }

        public int? VendorId { get; set; }

        public string BasePartNumber { get; set; }

        public int? CategoryId { get; set; }

        public int Category { get; set; }

        public int? DevManagerId { get; set; }

        public string OtherDependencies { get; set; }

        public short? DeletemeNextPNRev { get; set; }

        public string DeleteMePreviousDash { get; set; }

        public string Notes { get; set; }

        public byte? DeleteMeKit { get; set; }

        public int? WorkflowId { get; set; }

        public int? TesterId { get; set; }

        public byte? DeletemeOnDotSheet { get; set; }

        public byte? PreInstalled { get; set; }

        public byte? MasterIdRequired { get; set; }

        public int? InstallationOrder { get; set; }

        public string MriId { get; set; }

        public int? VendorContactId { get; set; }

        public int? LeadEngineerId { get; set; }

        public byte? DropInBox { get; set; }

        public byte? Choice { get; set; }

        public byte? Active { get; set; }

        public int? SWTypeId { get; set; }

        public string RootFileName { get; set; }

        public string TargetPartition { get; set; }

        public string PackageType { get; set; }

        public string OSType { get; set; }

        public string EndUserInstructions { get; set; }

        public string SilentInstructions { get; set; }

        public string BlindInstructions { get; set; }

        public string UninstallInstructions { get; set; }

        public string MSBatchInstructions { get; set; }

        public string NtdsInstructions { get; set; }

        public string Install { get; set; }

        public string SilentInstall { get; set; }


        public string BlindInstall { get; set; }

        public string ArcdInstall { get; set; }

        public string Uninstall { get; set; }

        public string InstallRecover { get; set; }

        public string Timeout { get; set; }

        public byte? Reboot { get; set; }

        public byte? Preinstall { get; set; }

        public byte? Rompaq { get; set; }

        public byte? CDImage { get; set; }

        public byte? IsoImage { get; set; }

        public string Replicater { get; set; }

        public byte? Cab { get; set; }

        public byte? Binary { get; set; }

        public byte? FloppyDisk { get; set; }

        public byte? PreinstallROM { get; set; }

        public byte? LoggedIn { get; set; }

        public byte? SysComponents { get; set; }

        public byte? SysReboot { get; set; }

        public byte? Admin { get; set; }

        public byte? LangSubs { get; set; }

        public byte? CertRequired { get; set; }

        public string DefaultUI { get; set; }

        public string PnpDevices { get; set; }

        public byte? ScriptPaq { get; set; }

        public byte? Softpaq { get; set; }

        public byte? MultiLanguage { get; set; }

        public int? SoftpaqCategoryId { get; set; }

        public DateTime? Created { get; set; }

        public bool? UseRegions { get; set; }

        public bool? IconDesktop { get; set; }

        public bool? IconMenu { get; set; }

        public bool? IconTray { get; set; }

        public bool? IconPanel { get; set; }

        public bool? PackageForWeb { get; set; }

        public string PropertyTabs { get; set; }

        public byte? PostRtmStatus { get; set; }

        public string SubAssembly { get; set; }

        public byte? DeveloperNotification { get; set; }

        public byte? AR { get; set; }

        public bool? RoyaltyBearing { get; set; }

        public int? SWSetupCategoryId { get; set; }

        public string KitNumber { get; set; }

        public string KitDescription { get; set; }

        public string DeliverableSpec { get; set; }

        public byte? MuiAware { get; set; }

        public DateTime? MuiAwareDate { get; set; }

        public bool? Deactivate { get; set; }

        public bool? IconInfoCenter { get; set; }

        public string Notifications { get; set; }

        public bool? OemReadyRequired { get; set; }

        public string OemReadyException { get; set; }

        public bool? Hppi { get; set; }

        public int? OtsFvtOrganizationId { get; set; }

        public string LearnMore { get; set; }

        public int? TransferServerId { get; set; }

        public int? DeveloperId { get; set; }

        public string SoftpaqInstructions { get; set; }

        public int? CoreTeamId { get; set; }

        public bool? LockReleases { get; set; }

        public string ReturnCodes { get; set; }

        public string OsCode { get; set; }

        public bool? ShowOnStatus { get; set; }

        public int? InitialOfferingStatus { get; set; }

        public int? InitialOfferingChangeStatus { get; set; }

        public int? InitialOfferingChangeStatusArchive { get; set; }

        public string LtfAVNo { get; set; }

        public string LtfSubassemblyNo { get; set; }

        public byte? Patch { get; set; }

        public int? DeleteMeIrsModuleId { get; set; }

        public int? DeleteMeIrsHWId { get; set; }

        public string SystemBoardId { get; set; }

        public int? DeleteMeIrsPlatformId { get; set; }

        public byte? DriverPack { get; set; }

        public byte? AppStore { get; set; }

        public bool? Desktops { get; set; }

        public bool? SendToIrs { get; set; }

        public byte? IrsTransfers { get; set; }

        public bool? DpbCompliant { get; set; }

        public string DevicesInfPath { get; set; }

        public string TestNotes { get; set; }

        public DateTime? Deactivated { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public int? SupplierId { get; set; }

        public int? SioApproverId { get; set; }

        public bool? KoreanCertificationRequired { get; set; }

        public string BaseFilePath { get; set; }

        public string SubmissionPath { get; set; }

        public string IrsPartNumberLastSpin { get; set; }

        public string IrsBasePartNumber { get; set; }

        public int? IrsComponentCloneId { get; set; }

        public int? PrismSWType { get; set; }

        public bool? LimitFuncTestGroupVisability { get; set; }

        public int? NamingStandardId { get; set; }

        public string NamingStandardValue { get; set; }

        public int? ML { get; set; }

        public string AgencyLead { get; set; }

        public VendorModel VendorModel { get; set; }

        public DeliverableVersionModel DeliverableversionModel { get; set; }

        public EmployeeModel EmpModel { get; set; }

        public string PartNumber { get; set; }

        public string ImageSummary { get; set; }
        public int TargetVersions { get; set; }
        public string CriticalChanges { get; set; }
        public string HasIssues { get; set; }
        public string OSSupportedList { get; set; }

        public int TotalNoOfRows { get; set; }

        public string VersionRevisionPass { get; set; }

        public int? StructureCheck { get; set; }

        public string DevManagerName { get; set; }

        public ProductDelRootModel ProductDelRoot { get; set; }

        public ProductVersionModel ProductVersion { get; set; }

        public string Language { get; set; }

        public DeliverableCategoryModel DeliverableCategory { get; set; }

        public int Status { get; set; }

        public SIObservationReport SIObservationReport { get; set; }

        public ActionLogModel ActionLog { get; set; }

        public string Releases { get; set; }

        public int VersionCount { get; set; }

        public int TargetCount { get; set; }

        public int RecordCount { get; set; }

        public DeliverableTypeModel DeliverableType { get; set; }

        public ProductDeliverableModel ProductDeliverable { get; set; }

        public AvSaMappingModel AvSaMapping { get; set; }

        public RegionModel Region { get; set; }

        public AVFeatureCategoryModel AvFeatureCategory { get; set; }

        public OSFamilyModel OSFamily { get; set; }

        public OSLookupModel OSLookup { get; set; }
        public string DmiStr { get; set; }

        public int SortOrder { get; set; }

        public string Regions { get; set; }

        public string Locale { get; set; }

        public int ComponentPassId { get; set; }

        public int ComponentTypeId { get; set; }

        public string PartNo { get; set; }

        public string Version { get; set; }

        public string Revision { get; set; }

        public string Pass { get; set; }

        public int ProductDropId { get; set; }

        public string StringCategory { get; set; }
    }
}
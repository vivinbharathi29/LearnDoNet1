using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IActionRoadmapService
    {
        Task<ActionRoadmapModel[]> GetActionsRoadmapByProductIdAsync(int productId);

        Task<ActionRoadmapModel[]> GetActionRoadmapItemForTaskAsync(int id);
    }
}
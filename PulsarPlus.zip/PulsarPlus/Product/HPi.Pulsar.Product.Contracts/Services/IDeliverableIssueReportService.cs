using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDeliverableIssueReportService
    {
        Task<DeliverableIssueModel[]> GetActionReportAsync(QueryActionModel queryAction);
    }
}
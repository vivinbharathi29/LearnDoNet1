using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDCRWorkflowDefinitionsService
    {
        Task<DcrWorkflowDefinitionModel[]> GetDCRWorkflowDefinitionsAsync(int userId);

        Task<int> GetDCRWorkflowDefinitionsCountAsync(int? userId);

		Task<DcrWorkflowDefinitionModel[]> GetDCRWorkflowStatusAsync(int dcrId);

        Task<ProductVersionModel> GetSuperUsersByProductAsync(int pvId);

        Task<DcrWorkflowDefinitionModel[]> GetDCRWorkflowEmailListAsync(int dcrId, int pvId);

        Task<bool> TryTerminateDCRWorkflowAsync(int dcrId, int userId);

        Task<bool> TryUpdateDCRWorkflowCommentsAsync(int historyId, string comments);

        Task<bool> TryUpdateDCRWorkflowCompleteAsync(int historyId, int dcrId, int pvId);

        Task<DcrWorkflowDefinitionModel[]> GetAllDCRWorkflowDefinitionsAsync();
    }
}
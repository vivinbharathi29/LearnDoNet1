using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDeliverableTypeService
    {
        Task<DeliverableTypeModel[]> GetDeliverableCategoriesAsync(int productId);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IActionApprovalService
    {
        Task<ActionApprovalModel[]> GetActionApprovalAsync();

        Task<ActionApprovalModel[]> GetListApprovalsAsync(int actionId, int? approverId);

		Task<ActionApprovalModel> GetVerifyAutoApproveAsync(int actionId);

		Task<int> AddActionApproverAsync(ActionApprovalModel actionApproval);

		Task<int> UpdateActionApproverAsync(ActionApprovalModel actionApproval);

        Task<int> UpdateApprovalStatusAsync(int approvalId, int status);
    }
}
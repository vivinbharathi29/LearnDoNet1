using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IBrandService
    {
        Task<BrandModel[]> GetAllImageDefinitionBrandsAsync(int imageDefinitionId);

        Task<BrandModel[]> GetBrands4ProductAsync(int productId, int selectedOnly, bool isCacheRequired = true);

        Task<BrandModel[]> GetBrandsForProductAsync(int productId, int selected);

        Task<BrandModel[]> GetProductCombinedSCMsAsync(int productId, bool? isCacheRequired);

        Task<BrandModel[]> GetBrandsForProductPulsarAsync(int productId, int selected);
    }
}
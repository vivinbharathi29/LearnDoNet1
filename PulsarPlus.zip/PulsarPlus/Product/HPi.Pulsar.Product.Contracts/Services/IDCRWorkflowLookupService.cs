using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDCRWorkflowLookupService
    {
        Task<DcrWorkflowLookupModel[]> GetDCRWorkflowsAsync();
    }
}
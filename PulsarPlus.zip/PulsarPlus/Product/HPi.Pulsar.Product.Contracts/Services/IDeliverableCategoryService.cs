using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDeliverableCategoryService
    {
        Task<DeliverableCategoryModel[]> GetDeliverableCategoryAvPrefixValuesAsync();

        Task<DeliverableCategoryModel[]> GetDeliverableCategoriesByTypeAsync(int? typeID);

        Task<DeliverableCategoryModel[]> GetHWCategoriesAsync();

        Task<DeliverableCategoryModel> GetListCategoryAsync(int id);

        Task<DeliverableCategoryModel[]> GetSelectCatListAsync();
    }
}
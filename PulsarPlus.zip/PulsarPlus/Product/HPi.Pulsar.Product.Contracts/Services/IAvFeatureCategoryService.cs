using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IAvFeatureCategoryService
    {
        Task<AVFeatureCategoryModel[]> GetAvFeatureCategoryAvPrefixValuesAsync();
    }
}
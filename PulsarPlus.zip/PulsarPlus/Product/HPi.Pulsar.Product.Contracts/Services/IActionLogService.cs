using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IActionLogService
    {
        Task<bool> TryAddActionLogAsync(ActionLogModel ActionLog);

        Task<bool> TryInsertLogDeliverableUpdateAsync(ActionLogModel actionLog);
    }
}
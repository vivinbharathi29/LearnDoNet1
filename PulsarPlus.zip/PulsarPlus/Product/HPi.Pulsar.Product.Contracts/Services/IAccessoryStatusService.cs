using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IAccessoryStatusService
    {
        Task<AccessoryStatusModel[]> GetAccessoryStatusesAsync();

        Task<string> GetProductAccessoryStatusAsync(int productDeliverableId);
    }
}
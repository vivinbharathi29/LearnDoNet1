using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDCRWorkflowStagingService
    {
        Task<DCRWorkflowStagingModel> GetDCRWorkflowCheckAsync(int dcrId);

        Task<DCRWorkflowStagingModel[]> GetScheduleRTPandEOMDatebyProductIdAsync(int productId, string releaseName);
    }
}
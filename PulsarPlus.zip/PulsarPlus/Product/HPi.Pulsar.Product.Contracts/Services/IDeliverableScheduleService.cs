using System;
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDeliverableScheduleService
    {
        Task<bool> TryUpdateMilestonePlanAsync(int id, DateTime? planned);

        Task<DeliverableScheduleModel[]> GetDeliverableMilestonesAsync(int rootId, int versionId);

        Task<DeliverableScheduleModel[]> GetWorkflowStepsInProgressAsync(int id);

        Task<DeliverableScheduleModel[]> GetNextMilestonesAsync(int id, int milestoneId);

        Task<bool> TryUpdateResumeAfterFailureAsync(int delId, int milestoneId);

        Task<bool> TryUpdateMilestoneReleaseAsync(int delId, int currentId, int nextMiletoneId);

        Task<bool> TryUpdateMilestoneFailureAsync(int delId, int milestoneId);
    }
}
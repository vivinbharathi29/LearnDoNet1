using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDeliverableNamingService
    {
        Task<DeliverableNamingModel[]> GetDeliverableElementsAsync();
    }
}
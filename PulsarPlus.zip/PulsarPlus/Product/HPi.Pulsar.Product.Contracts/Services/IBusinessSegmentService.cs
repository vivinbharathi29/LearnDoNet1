using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IBusinessSegmentService
    {
        Task<BusinessSegmentModel[]> GetBusinessSegmentsAsync();
    }
}
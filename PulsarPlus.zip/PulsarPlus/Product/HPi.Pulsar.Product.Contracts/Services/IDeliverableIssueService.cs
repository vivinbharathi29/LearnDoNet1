using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IDeliverableIssueService
    {
        Task<DeliverableIssueModel> GetActionPropertiesAsync(int id);

        Task<ActionItemModel[]> GetWorkingListActionItemsAsync(int ownerId);
        
        Task<bool> TryUpdateDeliverableActionDisplayOrderAsync(DeliverableIssueModel[] deliverableIssue);

        Task<DeliverableIssueModel> GetActionPropertiesForPrintAsync(int id);
        
        Task<int> UpdateDeliverableActionWebAsync(DeliverableIssueModel deliverableIssue);
        
        Task<int> InsertDeliverableActionWebAsync(DeliverableIssueModel deliverableIssue);

        Task<DeliverableIssueModel[]> GetApprovedDCRsAsync(int productId, int showAll);

        Task<bool> TryUnLinkVersionFromProductAsync(ProductDeliverableModel productDeliverableModel);

        Task<bool> TryUnLinkVersionFromProductReleaseAsync(ProductDeliverableModel productDeliverableModel);

        Task<DeliverableIssueModel[]> GetActionOwnersAsync();

        Task<DeliverableIssueModel[]> GetDeliverableIssueSubmittersAsync();

        Task<DeliverableIssueModel[]> ListAllActionOwnersAsync();

        Task<DeliverableIssueModel[]> GetChangeRequestGroupAsync(int issueId, long? changeRequestId);

        Task<int> AddDeliverableTodayActionAsync(DeliverableIssueModel deliverableIssue);

        Task<int> UpdateDeliverableIssueActionWebAsync(DeliverableIssueModel deliverableIssue);

        Task<DeliverableIssueModel> GetActionforMailAsync(int deliverableIssueId);
        
        Task<int> SetApprovalForActionAsync(int actionId);

        Task<long?> GetChangeRequestIdAsync(int issueId);

        Task<DeliverableIssueModel> GetActionProductTypeAsync(int actionId);

        Task<DeliverableIssueModel[]> GetReorderListAsync(int projectId, int typeId, int strId);

        Task<DeliverableIssueModel> GetApproverEmailAsync(int approvalId);
    }
}
﻿namespace HPi.Pulsar.Product.Contracts.Services
{
    using System.Threading.Tasks;

    public interface IDeliverableIssuesHistoryService
    {        
		Task<int> AddDeliverableIssuesHistory(DeliverableIssuesHistoryModel deliverableIssue);
    }
}

﻿using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Services
{
    public interface IApplicationErrorService
    {
        Task<AppErrorModel> GetApplicationErrorOutstandingAsync(int appErrorId);

        Task<int> UpdateApplicationErrorAsync(int id, string cause);
    }
}
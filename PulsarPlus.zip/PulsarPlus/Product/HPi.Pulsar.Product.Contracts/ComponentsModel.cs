﻿namespace HPi.Pulsar.Product.Contracts
{
    public class ComponentsModel
    {
        public int ComponentsPassId { get; set; }

        public int ComponentTypeId { get; set; }

        public string Name { get; set; }

        public string PartNo { get; set; }

        public string Version { get; set; }

        public string Revision { get; set; }

        public string Pass { get; set; }

        public string Creator { get; set; }

        public int ProductDropId { get; set; }

        public string DmiStr { get; set; }

        public int SortOrder { get; set; }
    }
}

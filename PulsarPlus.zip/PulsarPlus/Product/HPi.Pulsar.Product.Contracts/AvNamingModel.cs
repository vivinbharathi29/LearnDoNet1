namespace HPi.Pulsar.Product.Contracts
{
    public class AVNamingModel
    {
        public int Id { get; set; }

        public int? CategoryId { get; set; }

        public int? ElementId { get; set; }

        public string ElementValue { get; set; }

        public int? DisplayOrder { get; set; }

        public bool? Active { get; set; }

        public string Value3 { get; set; }

        public string Value5 { get; set; }

        public string Value7 { get; set; }
    }
}
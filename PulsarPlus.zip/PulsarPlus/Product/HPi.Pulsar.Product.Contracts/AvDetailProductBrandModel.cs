using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AVDetailProductBrandModel
    {
        public int AVDetailId { get; set; }

        public int? FeatureId { get; set; }

        public int RecordCount { get; set; }

        public int ProductBrandId { get; set; }

        public string Status { get; set; }

        public string ProgramVersion { get; set; }

        public string ConfigRules { get; set; }

        public string AVId { get; set; }

        public string Group1 { get; set; }

        public string Group2 { get; set; }

        public string Group3 { get; set; }

        public string Group4 { get; set; }

        public string Group5 { get; set; }

        public string ManufacturingNotes { get; set; }

        public string IdsSkusYN { get; set; }

        public string IdsCtoYN { get; set; }

        public string RctoSkusYN { get; set; }

        public string RctoCtoYN { get; set; }

        public string ChangeNote { get; set; }

        public int SortOrder { get; set; }

        public bool ShowOnScm { get; set; }

        public bool ShowOnPm { get; set; }

        public DateTime? GSEndDt { get; set; }

        public DateTime? LastUpdDate { get; set; }

        public string LastUpdUser { get; set; }

        public bool? SdfFlag { get; set; }

        public string PhWebInstruction { get; set; }

        public int Id { get; set; }

        public int? DeliverableRootId { get; set; }

        public DateTime? Deleted { get; set; }

        public int? IrsPlatformAliasId { get; set; }

        public int? IrsPlatformId { get; set; }

        public int? IrsHwId { get; set; }

        public bool? OriginatedByDcr { get; set; }

        public int? DcrNo { get; set; }

        public int? IrsBaseUnitModuleId { get; set; }

        public string BsamSkusYN { get; set; }

        public string BsambPartsYN { get; set; }

        public string AvNo { get; set; }

        public string GpgDescription { get; set; }

        public string Comments { get; set; }

        public string NewValue { get; set; }

        public string ColumnChanged { get; set; }

        public string Oldvalue { get; set; }

        public string AvChangeTypeDesc { get; set; }

        public string AvChangeTypeCd { get; set; }

        public string RuleSyntax { get; set; }

        public int? DemandRegionId { get; set; }

        public bool? SysSwop { get; set; }

        public bool? SysGpsy { get; set; }

        public bool? SysRas { get; set; }

        public string PhWebModelNumber { get; set; }

        public string PhWebProductPin { get; set; }

        public int ChangedSmiBiosAdd { get; set; }

        public int ChangedSmiBiosRemove { get; set; }

        public bool? BkeTeamAVNotified { get; set; }

        public string Group6 { get; set; }

        public int? IrsProductId { get; set; }

        public int? ProductVersionReleaseId { get; set; }

        public int HideStatus { get; set; }

        public string Group7 { get; set; }

        public string Release { get; set; }

        public bool IsProductVersionBsam { get; set; }

        public string BUStatus { get; set; }

        public string AVStatus { get; set; }

        public string Kmat { get; set; }

        public PlatformModel Platform { get; set; }

        public AvDetailAvailModel AvDetailAvail { get; set; }

        public AVDetailModel AVDetail { get; set; }

        public ProductBrandModel ProductBrand { get; set; }
    }
}
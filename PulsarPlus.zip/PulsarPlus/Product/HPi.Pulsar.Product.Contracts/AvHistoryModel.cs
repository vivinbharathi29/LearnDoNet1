using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AvHistoryModel
    {
        public int ID { get; set; }

        public int? AvChangeTypeID { get; set; }

        public int? AvDetailID { get; set; }

        public int? ProductBrandID { get; set; }

        public bool Published { get; set; }

        public string ColumnChanged { get; set; }

        public string OldValue { get; set; }

        public string NewValue { get; set; }

        public string Comments { get; set; }

        public bool BAvNo { get; set; }

        public bool BFeatureCategory { get; set; }

        public bool BGpgDescription { get; set; }

        public bool BMarketingDescription { get; set; }

        public bool BProgramVersion { get; set; }

        public bool BCPLBlindDt { get; set; }

        public bool BRasDiscontinueDt { get; set; }

        public bool BConfigRules { get; set; }

        public bool BManufacturingNotes { get; set; }

        public bool BIdsSkus { get; set; }

        public bool BIdsCto { get; set; }

        public bool BRctoSkus { get; set; }

        public bool BRctoCto { get; set; }

        public bool BUPC { get; set; }

        public bool BWeight { get; set; }

        public bool BGSEndDt { get; set; }

        public bool BStatus { get; set; }

        public bool ShowOnScm { get; set; }

        public string LastUpdUser { get; set; }

        public DateTime LastUpdDate { get; set; }

        public bool ShowOnPM { get; set; }

        public DateTime? PMPublish { get; set; }

        public bool BAvailabilityDate { get; set; }

        public bool? BSDFFlag { get; set; }

        public bool? BPhWebInstruction { get; set; }

        public bool? BAvId { get; set; }

        public bool? BGroup1 { get; set; }

        public bool? BGroup2 { get; set; }

        public bool? BGroup3 { get; set; }

        public bool? BGroup4 { get; set; }

        public bool? BGroup5 { get; set; }

        public bool? BGroup6 { get; set; }

        public bool? BGroup7 { get; set; }

        public bool? BMarketingDescriptionPMG { get; set; }

        public bool? BGeneralAvailDt { get; set; }

        public bool? BBSAMSkus { get; set; }

        public bool? BBSAMBparts { get; set; }

        public int? SCMCategoryID { get; set; }

        public bool BPhwebDt { get; set; }

        public int? BUFeatureID { get; set; }

        public bool BSCMCategory { get; set; }

        public bool BRuleSyntax { get; set; }

        public bool BCatMin { get; set; }

        public bool BcatMax { get; set; }

        public bool BBUAvailStatus { get; set; }

        public bool BRTPDate { get; set; }

        public bool BProductLine { get; set; }

        public bool BReleases { get; set; }
    }
}
namespace HPi.Pulsar.Product.Contracts
{
    public class DevCenterModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Business { get; set; }

        public int? BusinessId { get; set; }
    }
}
﻿

namespace HPi.Pulsar.Product.Contracts
{

    /// <summary>
    /// <para>PostRTMStatusModel</para>
    /// </summary>
    public class PostRtmStatusModel
    {
        /// <summary>
        /// Gets or sets the RTMStatusId.
        /// </summary>
        public int RtmStatusId { get; set; }

        /// <summary>
        /// Gets or sets the RTMStatusDesc.
        /// </summary>
        public string RtmStatusDesc { get; set; }


    }
}

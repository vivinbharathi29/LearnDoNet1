﻿namespace HPi.Pulsar.Product.Contracts
{
    public class ImpersonateUserModel
    {
        public EmployeeModel[] Owners { get; set; }

        public EmployeeModel[] Submitters { get; set; }
    }
}

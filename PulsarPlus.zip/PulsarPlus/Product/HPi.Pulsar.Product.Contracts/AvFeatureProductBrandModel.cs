﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AvFeatureProductBrandModel
    {
        public int AVFeatureCategoryId { get; set; }

        public int ProductBrandID { get; set; }

        public string ConfigRules { get; set; }

        public string ManufacturingNotes { get; set; }

        public string MarketingDescription { get; set; }

        public DateTime LastUpdDate { get; set; }

        public string LastUpdUser { get; set; }

        public DateTime? ConfigRulesLastUpdDt { get; set; }

        public DateTime? MarketingLastUpdDt { get; set; }

        public int? CatMin { get; set; }

        public int? CatMax { get; set; }
    }
}


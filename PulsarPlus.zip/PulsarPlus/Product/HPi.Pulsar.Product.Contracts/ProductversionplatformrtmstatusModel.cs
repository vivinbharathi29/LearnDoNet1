﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts
{
    /// <summary>
    /// 
    /// </summary>
    public class ProductversionplatformrtmstatusModel
    {
        /// <summary>
        /// The Productversionid
        /// </summary>
        public int Productversionid { get; set; }

        /// <summary>
        /// The Isplatformrtm
        /// </summary>
        public int? Isplatformrtm { get; set; }
    }
}

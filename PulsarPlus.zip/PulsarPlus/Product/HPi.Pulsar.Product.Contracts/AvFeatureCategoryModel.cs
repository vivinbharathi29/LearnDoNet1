﻿namespace HPi.Pulsar.Product.Contracts
{
    public class AVFeatureCategoryModel
    {
        public int AVFeatureCategoryId { get; set; }

        public string AVFeatureCategory { get; set; }

        public int SortOrder { get; set; }

        public string AutomatedYN { get; set; }

        public string ConfigRules { get; set; }

        public bool ShowWhenEmpty { get; set; }

        public int? ParentCategoryId { get; set; }

        public int BusinessId { get; set; }

        public int? GeoId { get; set; }

        public int? OsId { get; set; }

        public int? OsId2 { get; set; }

        public bool Active { get; set; }

        public bool ShowForService { get; set; }

        public int? PhWebCategoryId { get; set; }

        public string Abbreviation { get; set; }

        public int? IrsCategoryId { get; set; }

        public int? DeliverableTypeId { get; set; }

        public string NameFormat { get; set; }

        public bool? RequiresFormattedName { get; set; }

        public string AvPrefix { get; set; }

        public int? IrsModuleCategoryId { get; set; }

        public string IrsModuleAbbreviation { get; set; }

        public bool? DowngradeOS { get; set; }

        public int? SortOrderToAgile { get; set; }

        public int? CatMin { get; set; }

        public int? CatMax { get; set; }
    }
}

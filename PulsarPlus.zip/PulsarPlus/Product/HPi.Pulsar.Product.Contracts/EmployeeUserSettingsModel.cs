namespace HPi.Pulsar.Product.Contracts
{
    public class EmployeeUserSettingModel
    {
        public int Id { get; set; }

        public int EmployeeId { get; set; }

        public int UserSettingsId { get; set; }

        public string Setting { get; set; }

        public int OperationId { get; set; }
    }
}
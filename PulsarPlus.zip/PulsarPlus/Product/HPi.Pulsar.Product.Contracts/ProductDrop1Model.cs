

namespace HPi.Pulsar.Product.Contracts
{
    /// <summary>
    /// <para>ProductDrop1Model</para>
    /// </summary>
    public class ProductDrop1Model
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }


    }
}
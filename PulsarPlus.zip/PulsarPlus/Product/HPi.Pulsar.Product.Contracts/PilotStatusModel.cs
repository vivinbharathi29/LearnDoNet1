

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>PilotStatusModel</para>
    /// </summary>
    public class PilotStatusModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the MatrixBGColor.
		/// </summary>
		public string MatrixBGColor { get; set; }

		/// <summary>
		/// Gets or sets the FontColor.
		/// </summary>
		public string FontColor { get; set; }

		/// <summary>
		/// Gets or sets the DateField.
		/// </summary>
		public byte? DateField { get; set; }

		/// <summary>
		/// Gets or sets the CommentsRequired.
		/// </summary>
		public bool? CommentsRequired { get; set; }


    }
}
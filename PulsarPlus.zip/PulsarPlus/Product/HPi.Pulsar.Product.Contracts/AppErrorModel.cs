﻿namespace HPi.Pulsar.Product.Contracts
{
    using System;

    public class AppErrorModel
    {
        public int AppErrorId { get; set; }

        public string Category { get; set; }

        public string AspCode { get; set; }

        public string ErrNumber { get; set; }

        public string AspDescription { get; set; }

        public string ErrDescription { get; set; }

        public string ServerName { get; set; }

        public string ServerIP { get; set; }

        public string RemoteIP { get; set; }

        public string ErrFile { get; set; }

        public int? ErrLine { get; set; }

        public int? ErrColumn { get; set; }

        public string ErrSource { get; set; }

        public string Browser { get; set; }

        public string Method { get; set; }

        public int? TotalBytes { get; set; }

        public string ScriptName { get; set; }

        public string RequestQueryString { get; set; }

        public string RequestForm { get; set; }

        public string AuthUser { get; set; }

        public DateTime ErrorDateTime { get; set; }

        public string Cause { get; set; }

        public string Referrer { get; set; }

        public string ServerVariables { get; set; }

        public bool? Reported { get; set; }

        public EmployeeModel EmployeeInfo { get; set; }

        public string RowStatusColour { get; set; }
    }
}
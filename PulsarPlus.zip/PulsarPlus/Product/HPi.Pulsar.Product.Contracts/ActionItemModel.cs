﻿namespace HPi.Pulsar.Product.Contracts
{
    public class ActionItemModel
    {
        public DeliverableIssueModel DeliverableIssue { get; set; }

        public EmployeeModel Employee { get; set; }

        public ActionStatusModel ActionStatus { get; set; }

        public ActionRoadmapModel ActionRoadmap { get; set; }

        public ProductVersionModel ProductVersion { get; set; }

        public ProductFamilyModel ProductFamily { get; set; }

        public CoreTeamRepModel CoreTeamRep { get; set; }

        public int TotalNoOfRows { get; set; }

        public string AVRequiredFormatted { get; set; }

        public string QualificationRequiredFormatted { get; set; }

        public string StatusFormatted { get; set; }

        public string ActualDate { get; set; }

        public string AvailableForTest { get; set; }

        public string ZsrpReadyFormatted { get; set; }
    }
}

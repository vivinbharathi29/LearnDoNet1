﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class DeliverableScheduleModel
    {
        public int Id { get; set; }

        public int? DeliverableVersionId { get; set; }

        public string Milestone { get; set; }

        public short? MilestoneOrder { get; set; }

        public DateTime? Planned { get; set; }

        public DateTime? Actual { get; set; }

        public int? StatusId { get; set; }

        public int? CancelSave { get; set; }

        public byte? ReportMilestone { get; set; }

        public int? DefinitionId { get; set; }

        public DateTime Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public DeliverableVersionModel DeliverableVersion { get; set; }

        public ScheduleStatusModel ScheduleStatus { get; set; }

        public LanguageDelVerModel LanguageDelVersion { get; set; }
    }
}
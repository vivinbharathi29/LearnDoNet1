

namespace HPi.Pulsar.Product.Contracts
{
    /// <summary>
    /// <para>PublishedSCMXDataModel</para>
    /// </summary>
    public class PublishedScmxDataModel
    {
		/// <summary>
		/// Gets or sets the SCMXID.
		/// </summary>
		public int ScmxId { get; set; }

		/// <summary>
		/// Gets or sets the SCMID.
		/// </summary>
		public int ScmId { get; set; }

		/// <summary>
		/// Gets or sets the PBID.
		/// </summary>
		public int PBId { get; set; }

		/// <summary>
		/// Gets or sets the AvDetailID.
		/// </summary>
		public int AVDetailId { get; set; }

		/// <summary>
		/// Gets or sets the SCMCategoryID.
		/// </summary>
		public int? ScmCategoryId { get; set; }

		/// <summary>
		/// Gets or sets the ChinaGPIdentifier.
		/// </summary>
		public string ChinaGPIdentifier { get; set; }

		/// <summary>
		/// Gets or sets the ShortDescription.
		/// </summary>
		public string ShortDescription { get; set; }

		/// <summary>
		/// Gets or sets the MMN.
		/// </summary>
		public string Mmn { get; set; }


    }
}
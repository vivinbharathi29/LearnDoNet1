﻿namespace HPi.Pulsar.Product.Contracts
{
    public class IrsTransferStatusModel
    {
        public int Id { get; set; }

        public string Status { get; set; }

        public string ShortName { get; set; }

        public string Description { get; set; }

        public int? DisplayOrder { get; set; }
    }
}
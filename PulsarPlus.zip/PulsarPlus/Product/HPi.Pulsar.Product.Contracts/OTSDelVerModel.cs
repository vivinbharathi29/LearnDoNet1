namespace HPi.Pulsar.Product.Contracts
{
    public class OtsDelVerModel
    {
        public int Id { get; set; }

        public string OtsNumber { get; set; }

        public int? DeliverableVersionId { get; set; }

        public string ShortDescription { get; set; }

        public string Priority { get; set; }

        public string StepStoreProduce { get; set; }

        public SIObservationReportModel SIObservationReport { get; set; }

        public OSLookupModel OSLookup { get; set; }

        public string URL { get; set; }
    }
}
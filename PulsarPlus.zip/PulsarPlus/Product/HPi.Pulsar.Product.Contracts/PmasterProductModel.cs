

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>PmasterProductModel</para>
    /// </summary>
    public class PmasterProductModel
    {
        /// <summary>
        /// Gets or sets the ProductNameOID.
        /// </summary>
        public int ProductNameOID { get; set; }

        /// <summary>
        /// Gets or sets the ProductNumberOID.
        /// </summary>
        public int ProductNumberOID { get; set; }

        /// <summary>
        /// Gets or sets the ProductName.
        /// </summary>
        public string ProductName { get; set; }
    }
}
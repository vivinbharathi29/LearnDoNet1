﻿

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class SCMDetailPulsarModel.
    /// </summary>
    public class SCMDetailPulsarModel
    {
        /// <summary>
        /// Gets or sets the AvDetailId.
        /// </summary>
        public int AvDetailId { get; set; }

        /// <summary>
        /// Gets or sets the AvNo.
        /// </summary>
        public string AvNo { get; set; }

        /// <summary>
        /// Gets or sets the FeatureId.
        /// </summary>
        public int FeatureId { get; set; }

        /// <summary>
        /// Gets or sets the ScmCategoryId.
        /// </summary>
        public int ScmCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the ParentId.
        /// </summary>
        public int ParentId { get; set; }

        /// <summary>
        /// Gets or sets the IsScmPublished.
        /// </summary>
        public int IsScmPublished { get; set; }

        /// <summary>
        /// Gets or sets the GPGDescription.
        /// </summary>
        public string GPGDescription { get; set; }

        /// <summary>
        /// Gets or sets the GPGDescSysUpdate.
        /// </summary>
        public bool? GPGDescSysUpdate { get; set; }

        /// <summary>
        /// Gets or sets the MktDescSysUpdate.
        /// </summary>
        public bool? MktDescSysUpdate { get; set; }

        /// <summary>
        /// Gets or sets the MarketingDescription.
        /// </summary>
        public string MarketingDescription { get; set; }

        /// <summary>
        /// Gets or sets the MktDescPMGUSysUpdate.
        /// </summary>
        public bool? MktDescPMGUSysUpdate { get; set; }

        /// <summary>
        /// Gets or sets the MarketingDescriptionPMG.
        /// </summary>
        public string MarketingDescriptionPMG { get; set; }

        /// <summary>
        /// Gets or sets the Releases.
        /// </summary>
        public string Releases { get; set; }

        /// <summary>
        /// Gets or sets the PAADDate.
        /// </summary>
        public DateTime? PAADDate { get; set; }

        /// <summary>
        /// Gets or sets the CplBlindSysUpdate.
        /// </summary>
        public bool? CplBlindSysUpdate { get; set; }

        /// <summary>
        /// Gets or sets the GeneralAvailSysUpdate.
        /// </summary>
        public bool? GeneralAvailSysUpdate { get; set; }

        /// <summary>
        /// Gets or sets the GeneralAvailDate.
        /// </summary>
        public DateTime? GeneralAvailDate { get; set; }

        /// <summary>
        /// Gets or sets the RasDiscoSysUpdate.
        /// </summary>
        public bool? RasDiscoSysUpdate { get; set; }

        /// <summary>
        /// Gets or sets the ProgramVersion.
        /// </summary>
        public string ProgramVersion { get; set; }

        /// <summary>
        /// Gets or sets the CPLBlindDt.
        /// </summary>
        public DateTime CPLBlindDt { get; set; }

        /// <summary>
        /// Gets or sets the RASDiscontinueDt.
        /// </summary>
        public DateTime RASDiscontinueDt { get; set; }

        /// <summary>
        /// Gets or sets the ConfigRules.
        /// </summary>
        public string ConfigRules { get; set; }

        /// <summary>
        /// Gets or sets the RuleSyntax.
        /// </summary>
        public string RuleSyntax { get; set; }

        /// <summary>
        /// Gets or sets the AVId.
        /// </summary>
        public string AVId { get; set; }

        /// <summary>
        /// Gets or sets the Group1.
        /// </summary>
        public string Group1 { get; set; }

        /// <summary>
        /// Gets or sets the Group2.
        /// </summary>
        public string Group2 { get; set; }

        /// <summary>
        /// Gets or sets the Group3.
        /// </summary>
        public string Group3 { get; set; }

        /// <summary>
        /// Gets or sets the Group4.
        /// </summary>
        public string Group4 { get; set; }

        /// <summary>
        /// Gets or sets the Group5.
        /// </summary>
        public string Group5 { get; set; }

        /// <summary>
        /// Gets or sets the Group6.
        /// </summary>
        public string Group6 { get; set; }

        /// <summary>
        /// Gets or sets the Group7.
        /// </summary>
        public string Group7 { get; set; }

        /// <summary>
        /// Gets or sets the IdsSkusYN.
        /// </summary>
        public string IdsSkusYN { get; set; }

        /// <summary>
        /// Gets or sets the IdsCtoYN.
        /// </summary>
        public string IdsCtoYN { get; set; }

        /// <summary>
        /// Gets or sets the RctoSkusYN.
        /// </summary>
        public string RctoSkusYN { get; set; }

        /// <summary>
        /// Gets or sets the RctoCtoYN.
        /// </summary>
        public string RctoCtoYN { get; set; }

        /// <summary>
        /// Gets or sets the BSAMSkusYN.
        /// </summary>
        public string BSAMSkusYN { get; set; }

        /// <summary>
        /// Gets or sets the BSAMBpartsYN.
        /// </summary>
        public string BSAMBpartsYN { get; set; }

        /// <summary>
        /// Gets or sets the Upc.
        /// </summary>
        public string Upc { get; set; }

        /// <summary>
        /// Gets or sets the Weight.
        /// </summary>
        public string Weight { get; set; }

        /// <summary>
        /// Gets or sets the ProductLineName.
        /// </summary>
        public string ProductLineName { get; set; }

        /// <summary>
        /// Gets or sets the ManufacturingNotes.
        /// </summary>
        public string ManufacturingNotes { get; set; }

        /// <summary>
        /// Gets or sets the LastUpdDate.
        /// </summary>
        public DateTime LastUpdDate { get; set; }

        /// <summary>
        /// Gets or sets the LastUpdUser.
        /// </summary>
        public string LastUpdUser { get; set; }

        /// <summary>
        /// Gets or sets the SCMCategoryName.
        /// </summary>
        public string SCMCategoryName { get; set; }

        /// <summary>
        /// Gets or sets the Status.
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the ProductBrandID.
        /// </summary>
        public int ProductBrandId { get; set; }

        /// <summary>
        /// Gets or sets the CategoryRules.
        /// </summary>
        public string CategoryRules { get; set; }

        /// <summary>
        /// Gets or sets the ConfigRulesLastUpdDt.
        /// </summary>
        public DateTime ConfigRulesLastUpdDate { get; set; }

        /// <summary>
        /// Gets or sets the CategoryMarketingDescription.
        /// </summary>
        public string CategoryMarketingDescription { get; set; }

        /// <summary>
        /// Gets or sets the CategoryNotes.
        /// </summary>
        public string CategoryNotes { get; set; }

        /// <summary>
        /// Gets or sets the CategoryRuleSyntax.
        /// </summary>
        public string CategoryRuleSyntax { get; set; }

        /// <summary>
        /// Gets or sets the CategoryAvId.
        /// </summary>
        public string CategoryAvId { get; set; }

        /// <summary>
        /// Gets or sets the SortOrder.
        /// </summary>
        public int SortOrder { get; set; }

        /// <summary>
        /// Gets or sets the GSEndDate.
        /// </summary>
        public DateTime GSEndDate { get; set; }

        /// <summary>
        /// Gets or sets the CatMin.
        /// </summary>
        public int? CatMin { get; set; }

        /// <summary>
        /// Gets or sets the CatMax.
        /// </summary>
        public int? CatMax { get; set; }

        /// <summary>
        /// Gets or sets the RowCount.
        /// </summary>
        public int RowCount { get; set; }

        /// <summary>
        /// Gets or sets the RowCount.
        /// </summary>
        public int RecordCount { get; set; }

        /// <summary>
        /// Gets or sets the AvCount.
        /// </summary>
        public int AvCount { get; set; }

        /// <summary>
        /// Gets or sets the AdpbSortOrder.
        /// </summary>
        public int AdpbSortOrder { get; set; }

        /// <summary>
        /// Gets or sets the Rules Syntax
        /// </summary>
        public string RulesSyntax { get; set; }
    }
}

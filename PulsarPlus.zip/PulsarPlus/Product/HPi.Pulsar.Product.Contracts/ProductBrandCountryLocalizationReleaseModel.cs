

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductBrandCountryLocalizationReleaseModel</para>
    /// </summary>
    public class ProductBrandCountryLocalizationReleaseModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Gets or sets the ProdBrandCountryLocalizationID.
		/// </summary>
		public int ProdBrandCountryLocalizationID { get; set; }

		/// <summary>
		/// Gets or sets the ReleaseID.
		/// </summary>
		public int ReleaseID { get; set; }

        /// <summary>
        /// Gets or sets the Releases.
        /// </summary>
        public string Releases { get; set; }
    }
}
﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AvCreateModel
    {
        public int Id { get; set; }

        public int DeliverableRootId { get; set; }

        public int ProductBrandId { get; set; }

        public DateTime CreateDate { get; set; }

        public DateTime? CompleteDate { get; set; }

        public int? NotActionable { get; set; }

        public int? AvFeatureCategoryId { get; set; }

        public int? AvDetailId { get; set; }

        public bool? IoGenerated { get; set; }
    }
}




namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>RegionKeyboardLayoutModel</para>
    /// </summary>
    public class RegionKeyboardLayoutModel
    {
		/// <summary>
		/// Gets or sets the Id.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the CreatedBy.
		/// </summary>
		public string CreatedBy { get; set; }

		/// <summary>
		/// Gets or sets the UpdatedBy.
		/// </summary>
		public string UpdatedBy { get; set; }

		/// <summary>
		/// Gets or sets the Created.
		/// </summary>
		public DateTime Created { get; set; }

		/// <summary>
		/// Gets or sets the Updated.
		/// </summary>
		public DateTime Updated { get; set; }

		/// <summary>
		/// Gets or sets the Disabled.
		/// </summary>
		public DateTime? Disabled { get; set; }

		/// <summary>
		/// Gets or sets the DisabledBy.
		/// </summary>
		public string DisabledBy { get; set; }


    }
}
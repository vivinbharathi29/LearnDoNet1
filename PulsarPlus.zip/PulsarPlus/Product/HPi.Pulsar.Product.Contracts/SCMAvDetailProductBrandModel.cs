

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>SCMAvDetailProductBrandModel</para>
    /// </summary>
    public class ScmAVDetailProductBrandModel
    {
		/// <summary>
		/// Gets or sets the SCMID.
		/// </summary>
		public int ScmId { get; set; }

		/// <summary>
		/// Gets or sets the AvDetailID.
		/// </summary>
		public int AVDetailId { get; set; }

		/// <summary>
		/// Gets or sets the ProductBrandID.
		/// </summary>
		public int ProductBrandId { get; set; }

		/// <summary>
		/// Gets or sets the Status.
		/// </summary>
		public string Status { get; set; }

		/// <summary>
		/// Gets or sets the ProgramVersion.
		/// </summary>
		public string ProgramVersion { get; set; }

		/// <summary>
		/// Gets or sets the ConfigRules.
		/// </summary>
		public string ConfigRules { get; set; }

		/// <summary>
		/// Gets or sets the AvId.
		/// </summary>
		public string AVId { get; set; }

		/// <summary>
		/// Gets or sets the Group1.
		/// </summary>
		public string Group1 { get; set; }

		/// <summary>
		/// Gets or sets the Group2.
		/// </summary>
		public string Group2 { get; set; }

		/// <summary>
		/// Gets or sets the Group3.
		/// </summary>
		public string Group3 { get; set; }

		/// <summary>
		/// Gets or sets the Group4.
		/// </summary>
		public string Group4 { get; set; }

		/// <summary>
		/// Gets or sets the Group5.
		/// </summary>
		public string Group5 { get; set; }

		/// <summary>
		/// Gets or sets the ManufacturingNotes.
		/// </summary>
		public string ManufacturingNotes { get; set; }

		/// <summary>
		/// Gets or sets the IdsSkusYN.
		/// </summary>
		public string IdsSkusYN { get; set; }

		/// <summary>
		/// Gets or sets the IdsCtoYN.
		/// </summary>
		public string IdsCtoYN { get; set; }

		/// <summary>
		/// Gets or sets the RctoSkusYN.
		/// </summary>
		public string RctoSkusYN { get; set; }

		/// <summary>
		/// Gets or sets the RctoCtoYN.
		/// </summary>
		public string RctoCtoYN { get; set; }

		/// <summary>
		/// Gets or sets the ChangeNote.
		/// </summary>
		public string ChangeNote { get; set; }

		/// <summary>
		/// Gets or sets the SortOrder.
		/// </summary>
		public int SortOrder { get; set; }

		/// <summary>
		/// Gets or sets the ShowOnScm.
		/// </summary>
		public bool ShowOnScm { get; set; }

		/// <summary>
		/// Gets or sets the GSEndDt.
		/// </summary>
		public DateTime? GSEndDt { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdDate.
		/// </summary>
		public DateTime? LastUpdDate { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdUser.
		/// </summary>
		public string LastUpdUser { get; set; }

		/// <summary>
		/// Gets or sets the SDFFlag.
		/// </summary>
		public bool? SdfFlag { get; set; }

		/// <summary>
		/// Gets or sets the PhWebInstruction.
		/// </summary>
		public string PhWebInstruction { get; set; }

		/// <summary>
		/// Gets or sets the Id.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the DeliverableRootID.
		/// </summary>
		public int? DeliverableRootId { get; set; }

		/// <summary>
		/// Gets or sets the Deleted.
		/// </summary>
		public DateTime? Deleted { get; set; }

		/// <summary>
		/// Gets or sets the IRSPlatformAliasId.
		/// </summary>
		public int? IrsPlatformAliasId { get; set; }

		/// <summary>
		/// Gets or sets the IRSPlatformId.
		/// </summary>
		public int? IrsPlatformId { get; set; }

		/// <summary>
		/// Gets or sets the IRSHwId.
		/// </summary>
		public int? IrsHwId { get; set; }

		/// <summary>
		/// Gets or sets the OriginatedByDCR.
		/// </summary>
		public bool? OriginatedByDcr { get; set; }

		/// <summary>
		/// Gets or sets the DCRNo.
		/// </summary>
		public int? DcrNo { get; set; }

		/// <summary>
		/// Gets or sets the IRSBaseUnitModuleId.
		/// </summary>
		public int? IrsBaseUnitModuleId { get; set; }

		/// <summary>
		/// Gets or sets the BSAMSkusYN.
		/// </summary>
		public string BsamSkusYN { get; set; }

		/// <summary>
		/// Gets or sets the BSAMBpartsYN.
		/// </summary>
		public string BsambPartsYN { get; set; }

		/// <summary>
		/// Gets or sets the RuleSyntax.
		/// </summary>
		public string RuleSyntax { get; set; }

		/// <summary>
		/// Gets or sets the Group6.
		/// </summary>
		public string Group6 { get; set; }

		/// <summary>
		/// Gets or sets the Group7.
		/// </summary>
		public string Group7 { get; set; }

		/// <summary>
		/// Gets or sets the Releases.
		/// </summary>
		public string Releases { get; set; }

		/// <summary>
		/// Gets or sets the IRSProductId.
		/// </summary>
		public int? IrsProductId { get; set; }

		/// <summary>
		/// Gets or sets the ProductVersionReleaseId.
		/// </summary>
		public int? ProductVersionReleaseId { get; set; }
    }
}
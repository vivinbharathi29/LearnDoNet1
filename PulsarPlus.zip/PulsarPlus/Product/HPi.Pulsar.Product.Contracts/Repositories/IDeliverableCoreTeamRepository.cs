using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDeliverableCoreTeamRepository
    {
        Task<DeliverableCoreTeamModel[]> GetDeliverableCoreTeamsAsync();
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductStatusRepository
    {
        Task<ProductStatusModel[]> GetProductStatusesAsync();

        Task<ProductStatusModel> GetListPhaseAsync(int id);

        Task<ProductStatusModel[]> GetSelectPhaseListAsync();
    }
}
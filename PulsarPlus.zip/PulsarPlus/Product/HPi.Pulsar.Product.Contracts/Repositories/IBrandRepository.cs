using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IBrandRepository
    {
        Task<BrandModel[]> GetAllImageDefinitionBrandsAsync(int imageDefinitionId);

        Task<BrandModel[]> GetBrands4ProductAsync(int productId, int selectedOnly);

        Task<BrandModel[]> GetBrandsForProductAsync(int productId, int selected);

        Task<BrandModel[]> GetProductCombinedSCMsAsync(int productId);

        Task<BrandModel[]> GetBrandsForProductPulsarAsync(int productId, int selected);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IPartnerRepository
    {
        Task<PartnerModel[]> GetPartnersAsync(int reportTypeId);

        Task<PartnerModel> GetPartnerDetailAsync(int partnerId);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IOTSDelVerRepository
    {
        Task<OtsDelVerModel[]> GetOTSByDelVersionAsync(int deliverableVersionId);

        Task<OtsDelVerModel[]> GetOTSIDsByDelVersionAsync(int deliverableVersionId);

        Task<OtsDelVerModel[]> GetSelectedOSAsync(int id);
    }
}
using System;
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IPilotStatusRepository
    {
        Task<PilotStatusModel[]> GetAllPilotStatusesAsync();

        Task<int> UpdatePilotStatusAsync(int id, int statusID, int userID, string userName, string comments, DateTime pilotDate);

        Task<PilotStatusModel[]> GetPilotStatusListAsync();

        Task<int> UpdatePilotStatusPulsarAsync(int id, int statusID, int userID, string userName, string comments, DateTime pilotDate);
    }
}
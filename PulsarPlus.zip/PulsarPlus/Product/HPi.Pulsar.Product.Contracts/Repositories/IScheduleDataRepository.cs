using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IScheduleDataRepository
    {
        Task<ScheduleDataModel> GetScheduleDataAsync(int id, string operation);

        Task<List<ScheduleDataModel>> GetScheduleMilestonesDataAsync(int scheduleDataId);

        Task<int> UpdateScheduleMilestonesAsync(List<ScheduleDataModel> scheduleData);

        Task<ScheduleDataModel> UpdateScheduleMilestoneDataAsync(ScheduleDataModel scheduleData);

        Task<int> SetPddLockedAsync(int scheduleDataId);

        Task<bool> TryInsertScheduleDataIntoProductsAsync(ScheduleDataModel scheduleData);

        Task<ScheduleDataModel> GetProductWithoutScheduleAsync(ScheduleDataModel scheduleData);

        Task<DateTime> GetRTPDateAsync(int productVersionId, string releaseIds = "");

        Task<DateTime> GetEOMDateAsync(int productVersionId, string releaseIds = "");

        Task<ScheduleModel[]> GetSelectScheduleAsync(ScheduleModel scheduleModel);

        Task<string> UpdateScheduleRTPandEOMAsync(int productId, string productReleaseName, DateTime? rtpDate, DateTime? eomDate);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IAvDetailRepository
    {
        Task<AVDetailModel> GetAvDetailPulsarAsync(int productVersionId, int productBrandId, int avDetailId);

        Task<int> UpdateAvDetailPulsarAsync(AVDetailModel avDetails);

		Task<int> InsertAVDetailPulsarAsync(AVDetailModel avDetail);

		Task<bool> TryUpdateScmChangeFeatureAVAsync(AVDetailModel avDetail);

        Task<AVDetailModel> GetProductReleaseOnAVAsync(int pbId, int avDetailId);

        Task<string> GetAVNoAsync(int avDetailId);
    }
}
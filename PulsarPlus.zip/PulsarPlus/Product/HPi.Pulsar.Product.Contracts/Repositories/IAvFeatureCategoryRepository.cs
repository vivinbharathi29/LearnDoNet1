using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IAvFeatureCategoryRepository
    {
        Task<AVFeatureCategoryModel[]> GetAvFeatureCategoryAvPrefixValuesAsync();
    }
}
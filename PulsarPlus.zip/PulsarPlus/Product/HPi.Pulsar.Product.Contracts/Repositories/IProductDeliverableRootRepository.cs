using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductDeliverableRootRepository
    {
        Task<ProductDelRootModel> GetProductIDByProdRootAsync(int? prodRootID, int productDeliverableReleaseID);

        Task<ProductDelRootModel> GetProductDelRootIdAsync(int productId, int rootId, int releaseId = 0);

        Task<bool> TryAddDelRootToProductAsync(LinkProductModel linkProductModel);

        Task<ProductDelRootModel> GetBridgesOnOtherVersionsCountAsync(int productId, int versionId);

        Task<int> GetSubassemblyCountAsync(int productId, int versionId);

        Task<ProductDelRootModel> GetBridgesOnOtherVersionsReleaseCountAsync(int productId, int versionId);

        Task<int> GetSubassemblyReleaseCountAsync(int productId, int versionId, int productDeliverableReleaseId);

        Task<bool> TryUpdateImageDefaultsAsync(ProductDelRootModel productDelRoot);

        Task<DeliverableRootModel[]> GetCommoditySubAssemblyNumberReleaseAsync(int productID, int rootID, int releaseID);

        Task<DeliverableRootModel[]> GetCommoditySubAssemblyNumberAsync(int productID, int rootID);

        Task<ProductDelRootModel[]> GetSubassembyDefaultBaseReleaseAsync(int productVersionID, int deliverableRootID);

        Task<ProductDelRootModel[]> GetSubassembyDefaultBaseAsync(int productVersionID, int deliverableRootID);

        Task<ProductDelRootModel[]> GetServiceSubassembyDefaultBaseReleaseAsync(int productVersionID, int deliverableRootID);

        Task<ProductDelRootModel[]> GetServiceSubassembyDefaultBaseAsync(int productVersionID, int deliverableRootID);

        Task<bool> TryUpdateSubassemblyNumberReleaseAsync(ProductDelRootModel productDelRoot);

        Task<bool> TryUpdateSubassemblyNumberAsync(ProductDelRootModel productDelRoot);

        Task<bool> TryUpdateSubassemblyNumberEngineeringReleaseAsync(ProductDelRootModel productDelRoot);
        
        Task<bool> TryUpdateSubassemblyNumberEngineeringAsync(ProductDelRootModel productDelRoot);
        
        Task<bool> TryUpdateSubassemblyNumberServiceReleaseAsync(ProductDelRootModel productDelRoot);

        Task<bool> TryUpdateSubassemblyNumberServiceAsync(ProductDelRootModel productDelRoot);

        Task<ProductDelRootModel[]> GetListSubassembliesForRootAsync(int rootId);

        Task<ProductDelRootModel[]> GetNativeSubAssemblyBaseAsync(string subAssemblyBase, int nativeRootID, int productVersionID);
    }
}
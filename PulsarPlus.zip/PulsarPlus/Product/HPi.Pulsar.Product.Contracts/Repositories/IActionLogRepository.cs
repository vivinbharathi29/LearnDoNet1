using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IActionLogRepository
    {
        Task<bool> TryAddActionLogAsync(ActionLogModel ActionLog);

        Task<bool> TryInsertLogDeliverableUpdateAsync(ActionLogModel actionLog);
    }
}
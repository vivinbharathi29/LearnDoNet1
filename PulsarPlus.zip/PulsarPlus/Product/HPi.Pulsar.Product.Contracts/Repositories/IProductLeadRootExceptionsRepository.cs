using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductLeadRootExceptionsRepository
    {
        Task<bool> TryRemoveLeadProductExclusionAsync(int Id);

        Task<bool> TryAddLeadProductRootExclusionAsync(ProductLeadRootExceptionModel productLeadRootExceptionsModel);
    }
}
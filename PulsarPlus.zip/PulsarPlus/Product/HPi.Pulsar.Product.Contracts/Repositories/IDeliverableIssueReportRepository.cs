using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDeliverableIssueReportRepository
    {
        Task<DeliverableIssueModel[]> GetActionReportAsync(QueryActionModel queryAction);
    }
}
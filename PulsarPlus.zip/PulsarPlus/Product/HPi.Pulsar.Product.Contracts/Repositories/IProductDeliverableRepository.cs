using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductDeliverableRepository
    {
        Task<bool> TryUpdateExceptionsAsync(ProductDeliverableModel productDeliverable);

        Task<ProductDeliverableModel> GetTargetNotesAsync(int productID, int versionID);

        Task<ProductDeliverableModel[]> GetComponentsToPutInIRSProductDropAsync(IrsComponentModel irsComponent);

        Task<ProductDeliverableModel> GetPilotStatusAsync(int productID, int versionID);

        Task<int> UpdateCommodityStatusAsync(ProductDeliverableModel productDeliverable);
        
        Task<ProductDeliverableModel> GetAccessoryStatusAsync(int prodId, int versionId);

        Task<bool> TryUnlinkVersionFromProductAsync(int prodId, int deliverableId);

        Task<bool> TryUpdateAccessoryStatusAsync(AccessoryModel accessory);

        Task<ProductDeliverableReleaseModel[]> GetProductDeliverableReleasesAsync(int productID, int versionID, int productDeliverableReleaseID, int defaultReleaseID, string todayPageSection);

        Task<ProductDeliverableReleaseModel> GetPilotStatusReleaseAsync(int deliverableReleaseID);

        Task<int?> GetProductDefaultReleaseIdAsync(int productID);

        Task<string> GetRSLQualStatusAsync(int deliverableVersionID, int productID);
        
        Task<ProductDeliverableModel> GetProductDeliverableSummaryByIdAsync(int productDeliverableId, int? productDeliverableReleaseID);

        Task<ProductDeliverableModel> GetDeveloperNotificationStatusAsync(int productDeliverableId, int? productDeliverableReleaseID);

        Task<ProductDeliverableModel> GetDeliverableVersionProductPMForEmailAsync(int productDeliverableId);

        Task<ProductDeliverableModel[]> GetDeliverableVersionProductPmForEmailWithMultipleAsync(string productDeliverableId);

        Task<int> UpdateDeveloperTestStatusAsync(ProductDeliverableModel productDeliverableData, int userId, string deliverableIds);

        Task<int> UpdateDeveloperApprovalAsync(ProductDeliverableModel productDeliverableData, int userId);

        Task<ProductDeliverableModel> GetDevProductionReleaseEmailInfoAndPulsarAsync(string productDeliverableIds);

        Task<bool> TryLinkVersionToProductAsync(LinkProductModel linkVersionProductModel);

        Task<bool> TryUnlinkVersionFromProductReleaseAsync(int productId, int deliverableId, int productDeliverableReleaseId);

        Task<ProductDeliverableModel[]> GetAllVersionsForSupportingAsync(int productId, int rootId, int releaseId = 0);

        Task<CommodityStatusModel> GetCommodityStatusAsync(int productId, int versionId);

        Task<CommodityStatusModel> GetCommodityStatusReleaseAsync(int productId, int versionId, int productDeliverableReleaseID);

        Task<TestStatusModel[]> GetTestStatusesAsync();

        Task<bool> TryUpdateCommodityStatusAsync(CommodityStatusModel commodityStatusModel);

        Task<ProductDeliverableModel[]> GetRequestedDeliverablesAsync(int leadId, int productId, string idList, int fusionRequirement);

        Task<ProductDeliverableModel[]> GetDeliverablesForMultiDevApprovalAsync(string productDeliverablIds, string productDeliverableReleaseIds, int? partnerId);

        Task<ProductDeliverableModel[]> GetProductDeliverableDetailsForComponentTestLeadAsync(ProductDeliverableModel productDeliverable);

        Task<bool> TryUpdateTestLeadStatusOnlyAsync(LinkProductModel linkProductModel);

        Task<bool> TryUpdateTestLeadStatusOnlyPulsarAsync(LinkProductModel linkProductModel);

        Task<ProductDeliverableModel[]> GetProductsForVersionAsync(int id);

        Task<ProductDeliverableModel[]> GetLeadProductExceptionsAsync(int pmId);

        Task<int> UpdateLeadProductVersionAndRootExceptionAsync(int Id, string type);

        Task<bool> TryUpdateAccessoryStatusPulsarAsync(AccessoryModel accessoryModel);

        Task<ProductDeliverableModel> GetAccessoryStatusPulsarAsync(int prodId, int versionId, int productDeliverableReleaseId);

        Task<ProductDeliverableModel> GetTestLeadStatusAsync(int productId, int versionId, int fieldId);

        Task<bool> TryUpdateTestLeadStatusAsync(ProductDeliverableModel productDeliverable);

        Task<bool> TryAddSubassemblyLinkAsync(ProductDeliverableModel productDeliverable);

        Task<ProductDeliverableModel> GetSubassemblyBridgeAsync(int productId, int rootId);

        Task<bool> TryRemoveSubassemblyLinkAsync(ProductDeliverableModel productDeliverable);

        Task<ProductDeliverableModel[]> GetTargetDeliverableRootDetailsAsync(int productId, int rootId, int versionId);

        Task<ProductDeliverableModel[]> GetVersionsForTargetingAsync(int productId, int rootId);

        Task<bool> TryUpdateTargetAdvancedAsync(List<ProductDeliverableModel> productDeliverable, int userId);

        Task<bool> TryGetLogReleaseToProductsAsync(int versionID, int employeeID);

        Task<bool> TryAddSubassemblyLinkReleaseAsync(ProductDeliverableModel productDeliverable);

        Task<ProductDeliverableModel> GetSubassemblyBridgeReleaseAsync(int productId, int rootId);

        Task<bool> TryUpdateCommodityStatusReleaseAsync(CommodityStatusModel commodityStatusModel);

        Task<bool> TryRemoveSubassemblyLinkReleaseAsync(ProductDeliverableModel productDeliverable);

        Task<bool> TryUpdateImageActualsAsync(ProductDeliverableModel ProductDeliverable);

        Task<ProductDeliverableModel[]> GetSubassembliesBridgedForRootReleaseAsync(int productID, int rootID, int releaseID);

        Task<ProductDeliverableModel[]> GetListSubassembliesBridgedForRootAsync(int productID, int rootID);

        Task<ProductDeliverableModel> GetDistributionsAsync(int productId, int versionId, int rootId);

        Task<ProductDeliverableModel> GetDistributionsPulsarAsync(int productId, int versionId, int rootId, int releaseId);

        Task<bool> TryUpdateTargetDeliverableVersionWebAsync(ProductDeliverableModel productDeliverable);

        Task<int> UpdateDistributionsAsync(ProductDeliverableModel productDeliverables);

        Task<int> UpdateDistributionsPulsarAsync(ProductDeliverableModel productDeliverables);

        Task<int> UpdateCorrectImageSummaryAsync(int productId, int deliverableId, byte scope);

        Task<ProductDeliverableModel[]> GetVersionExceptionsAsync(int productId, string versionIds, int releaseId);

        Task<ProductDeliverableModel[]> GetLeadProductRootExceptionsAsync(int productId, int rootId, int releaseId);

        Task<bool> TryAddLeadProductVersionExceptionsAsync(List<ProductDeliverableModel> productDeliverable);

        Task<bool> TryUpdateLeadProductRootExceptionsAsync(ProductDeliverableModel productDeliverable);

        Task<bool> TryResetLeadProductRootExceptionsAsync(ProductDeliverableModel productDeliverable);

        Task<ProductDeliverableModel> GetMdaComplianceAsync(string productId);

        Task<ProductDeliverableModel[]> GetMdaComplianceDetailsAsync(string productId, PaginationModel pagination);

        Task<ProductDeliverableModel> GetDeliverableMdaComplianceAsync(string productId);

        Task<ProductDeliverableModel[]> GetDeliverableMdaComplianceDetailsAsync(string productId, PaginationModel pagination);

        Task<ProductDeliverableModel[]> GetProductsByVersionAsync(string productId, int mdaFlag);

        Task<DeliverableLevelModel[]> GetDeliverableLevelsAsync(int typeId);

        Task<ProductDeliverableModel> GetWhqlCountDetailsAsync(int productId);

        Task<ProductDeliverableModel[]> GetWhqlVerifyDataAsync(int productId, PaginationModel pagination);

        Task<ProductDeliverableModel[]> GetWhqlWithWaiverAsync(int productId, PaginationModel pagination);

        Task<bool> TryUpdateAdvancedSupportedProductToRootAsync(LinkProductModel linkVersionProductModel);
    }
}
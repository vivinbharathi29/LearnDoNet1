using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IScheduleDataHistoryRepository
    {
        Task<ScheduleDataHistoryModel[]> GetScheduleItemHistoriesAsync(int id);
    }
}
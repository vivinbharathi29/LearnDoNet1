using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IEmployeeUserSettingsRepository
    {
        Task<EmployeeUserSettingModel> GetUserSettingAsync(int employeeId, int userSettingsId);    

        Task<int> DeleteDefaultProductFilterAsync(int employeeId, int userSettingsId);

        Task<EmployeeUserSettingModel> UpdateEmployeeUserSettingAsync(int employeeId, int userSettingsId, string sSettings);

        Task<EmployeeUserSettingModel> GetEmployeeUserSettingsAsync(int employeeId, int userSettingsId);

        Task<EmployeeUserSettingModel> GetEmployeeUserSettingAsync(int employeeId);
    }
}
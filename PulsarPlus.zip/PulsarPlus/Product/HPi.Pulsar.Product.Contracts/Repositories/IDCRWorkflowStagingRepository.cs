using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDCRWorkflowStagingRepository
    {
        Task<DCRWorkflowStagingModel> GetDCRWorkflowCheckAsync(int dcrId);

        Task<DCRWorkflowStagingModel[]> GetScheduleRTPandEOMDatebyProductIdAsync(int productId, string releaseName);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductOsRepository
    {
        Task<OSLookupModel[]> GetProductOSByIdAsync(int productId, int type);

        Task<bool> TryUpdateProductOsAsync(ProductOSModel[] productOSDetails);
    }
}
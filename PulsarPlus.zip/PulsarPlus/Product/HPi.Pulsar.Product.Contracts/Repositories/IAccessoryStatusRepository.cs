using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IAccessoryStatusRepository
    {
        Task<AccessoryStatusModel[]> GetAccessoryStatusesAsync();

        Task<string> GetProductAccessoryStatusAsync(int productDeliverableId);
    }
}
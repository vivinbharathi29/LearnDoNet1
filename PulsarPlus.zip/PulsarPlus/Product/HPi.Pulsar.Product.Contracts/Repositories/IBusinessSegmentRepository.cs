using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IBusinessSegmentRepository
    {
        Task<BusinessSegmentModel[]> GetBusinessSegmentsAsync();
    }
}
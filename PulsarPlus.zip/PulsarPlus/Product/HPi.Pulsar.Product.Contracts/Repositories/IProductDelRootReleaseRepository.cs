using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductDelRootReleaseRepository
    {
        Task<ProductDelRootReleaseModel[]> GetSubAssembliesForBaseAsync(string baseName);

        Task<ProductDelRootReleaseModel[]> GetSubAssembliesForBaseServiceAsync(string subAssemblyBase);
    }
}
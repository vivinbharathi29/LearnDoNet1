using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductVersionRepository
    {
        Task<ProductVersionModel[]> GetHardwareTeamAccessListAsync(int userId, int? prodId, bool? isCacheRequired);

        Task<bool> TryUpdateProductVersionHWPMAsync(ProductVersionModel productPropertiesModel);

        Task<ProductVersionModel> GetProductVersionNameAsync(int productId, int releaseId = 0);

        Task<ProductVersionModel> GetProductVersionAsync(int productVersionID, bool? isCacheRequired);

        Task<ProductVersionModel[]> GetProductDropListAsync();

        Task<ProductVersionModel[]> GetProductGroupsAsync(int type);

        Task<ProductVersionModel> GetOdmHwPMAsync(int productId);

        Task<ProductVersionModel[]> GetTargetedProductsForVersionAsync(int versionId);

        Task<int> GetODMHWPMIdAsync(int productId);

        Task<ProductVersionModel> GetLeadProductDetailsAsync(int prodId, int fusionRequirement);

        Task<bool> IsPulsarProductAsync(int productVersionId);

        Task<bool> TryUpdateProductVersionAccessoryAsync(int productVersionId, int pmId);

        Task<ProductVersionModel[]> GetAllImagesForProductFusionAsync(int productId);

        Task<ProductVersionModel[]> GetSwitchReleaseNameSubAssmeblyAsync(int rootID, int productID);

        Task<ProductVersionModel[]> GetSwitchReleaseNameSubAssmeblyForDeliverableAsync(int productID, int versionID, int? showOnlyTargetedRelease);

        Task<bool> TryUpdateProductVersionFactoryEngineerAsync(int productVersionId, int feId);

        Task<int> UpdateProductVersionCommodityAsync(ProductVersionModel productVersion);

        Task<ProductVersionModel[]> GetProductsOnCommodityMatrixAsync(int divisionId);
        
        Task<ProductVersionModel[]> GetActionReportProductVersionsAsync();

        Task<ProductVersionModel[]> GetProductsAsync(int minimumStatusID, int maximumStatusID);

        Task<ProductVersionModel> GetUserInRolesListAsync(int employeeId);

        Task<bool> TrySyncSelectedProductsAsync(string values, string userProfile);

        Task<ProductVersionModel[]> GetScmNamesAsync(string avNumber);

        Task<string> GetDCRNotificationAsync(int programId);

        Task<ProductVersionModel> GetApproversAsync(int programId);

        Task<ProductVersionModel[]> GetProductVersionPulsarAsync(int id);

        Task<ProductVersionModel[]> GetChangeRequestProductSelectionAsync(int? selectionType, int? selectionFilterId);

        Task<ProductVersionModel[]> GetChangeRequestProductSegementSelectionAsync(int? selectionType, int? selectionFilterId);

        Task<ProductVersionModel[]> GetTodayActionProductsAsync();

        Task<ProductVersionModel[]> GetTodayActionProductsByIdAsync(string productIds);

        Task<ProductVersionModel> GetDefaultDCROwnerAsync(int ProductId);

        Task<ProductVersionModel> GetListProductsAsync(int id);

        Task<ProductVersionModel> GetListProductsPulsarAsync(int id);

        Task<ProductVersionReleaseModel[]> GetProductReleaseTodayActionAsync(int productId);

        Task<string> GetReferencePlatformAsync(int productVersionId);

        Task<ProductVersionModel[]> GetImagesForProductRolloutFusionAsync(int productVersionId, PaginationModel pagination);

        Task<ProductVersionModel[]> GetImageDefinitionBrandsAsync(int imageId);

        Task<ProductVersionModel[]> GetImageDefinitionsForImageMatrixLocalozationAsync(int ProductId, int? ImageTypeId);

        Task<ProductVersionModel[]> GetImageDefinitionBrandsFusionAsync(int imageDefId);

        Task<ProductVersionModel[]> GetImagesForProductFusionAsync(int productId);

        Task<ProductVersionModel[]> GetImagesForDefinitionLocalizationAsync(int imageDefId);
        
        Task<ProductVersionModel[]> GetImagesForAllProductAsync(int productId);

        Task<string> GetPCEmailForTodayActionAsync(int productId);
        
        Task<ProductVersionModel[]> GetProductsAsync(int? type);

        Task<ProductVersionModel[]> GetProductsForRootAsync(int deliverableRootId, int? report);

        Task<ProductVersionModel[]> GetProductMarketingNamesAsync(PaginationModel pagination);

        Task<ProductVersionModel[]> GetProductSummaryAsync(PaginationModel pagination, string showAll, string devCenter, string cycle, string odm);

        Task<ProductVersionModel[]> GetProductsInProgramAsync(int id);
    }
}
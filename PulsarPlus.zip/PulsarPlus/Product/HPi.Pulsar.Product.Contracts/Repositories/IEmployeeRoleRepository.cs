using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IEmployeeRoleRepository
    {
        Task<int> GetUserInRoleAsync(int userId, int? productVersionId, string roleName);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IFeatureRepository
    {
        Task<string> GetFeatureNameAsync(int id);

        Task<bool> TryRejectFeatureRequestAsync(FeatureRootModel featureRoot);

		Task<bool> TryUpdateOverrideRequestedFeatureAsync(int featureID, int actionType, int userID);

		Task<FeatureModel[]> GetOsReleaseDescriptionAsync();
    }
}

using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IPlatformRepository
    {
        Task<PlatformModel[]> GetLisOfChassisAsync();

        Task<PlatformModel> GetPlatformByIdAsync(int platFormId);

        Task<int> FusionAddPlatformAsync(PlatformModel platFormData);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDeliverableTypeRepository
    {
        Task<DeliverableTypeModel[]> GetDeliverableCategoriesAsync(int productId);        
    }
}
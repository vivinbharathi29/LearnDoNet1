using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IEmployeeRepository
    {
        Task<EmployeeModel[]> GetSystemTeamAsync(int? prodId);

        Task<EmployeeModel[]> GetSystemTeamDetailsAsync(int? prodId);

        Task<EmployeeModel[]> GetToolsProjectOwnersAsync(int productID);

        Task<EmployeeModel[]> GetToolsPMsAsync();

        Task<EmployeeModel> GetEmployeeByIdAsync(int id);

        Task<EmployeeModel[]> GetDeliverableDeveloperAsync(int versionID);

        Task<UserInfoModel[]> GetAllCommodityPMsForVersionAsync(int versionID);

        Task<EmployeeModel[]> GetAllHardwarePMsForVersionAsync(int versionId);

        Task<EmployeeModel[]> GetAllTestLeadsAsync(bool isSELeadTest, bool isWWANLeadTest, bool isODMLeadTest, bool? isCacheRequired);

        Task<EmployeeModel[]> GetExecutionEngineersAsync(int versionId);

        Task<EmployeeModel[]> GetTestleadsForVersionAsync(int id);

        Task<UserInfoModel> GetEmployeeAsync(int? employeeID, int isAdmin);

        Task<EmployeeModel[]> GetAllCommodityPMsAsync(int reportId);

        Task<EmployeeModel[]> GetEmployeesProgramCommodityAsync(int type, string commodityPMsList, int? partnerId);

        Task<EmployeeModel[]> GetDeliverableVersionDevelopersAsync();

        Task<EmployeeModel[]> GetDeliverableRootDevManagersAsync();

        Task<EmployeeModel[]> GetCommodityPMsAsync();

        Task<EmployeeModel> GetPMAsync(int ProductId);

        Task<EmployeeModel[]> GetSystemTeamApproversAsync(int productVersionId);

        Task<EmployeeModel[]> GetProductDcrApproversAsync(int productVersionId);

        Task<EmployeeModel[]> GetDeliverableRootScrApproversAsync(int deliverableRootId);

        Task<EmployeeModel[]> GetPmViewSystemTeamAsync(int productVersionId, byte isAllEmployees, byte isAddBios, bool? isCacheRequired);

        Task<ImpersonateUserModel> GetEmployeesWithPaginationAsync(string employeeType, int? impersonateId, int pageNo, int pageSize, int? ownerId, int currentUserId, int? id);

        Task<EmployeeModel[]> GetEmployeeEmailDetailsAsync(EmployeeModel employeeInfo);

        Task<EmployeeModel[]> GetEmployeesAsync(int impersonateId);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ILanguageDelVersionRepository
    {
        Task<LanguageDelVerModel[]> GetSelectedLanguagesAsync(int id);

        Task<bool> TryUpdateLanguageLocationAsync(LanguageDelVerModel languageDelVerModel);
    }
}
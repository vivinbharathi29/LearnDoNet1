using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductVersionReleaseRepository
    {
        Task<ProductVersionReleaseModel> GetProductVersionReleaseDetailsAsync(int prodId);

        Task<ProductVersionReleaseModel[]> GetTestStatusProductDeliverableVersionReleaseDetailsAsync(int productId, int versionId);

        Task<ProductVersionReleaseModel[]> GetTestStatusProductVersionReleaseDetailsAsync(int productId, int versionId, int productDeliverableReleaseId, int defaultReleaseId);

        Task<ProductVersionReleaseModel[]> GetDefaultReleaseSubAssemblyAsync(int productID);

        Task<ProductVersionReleaseModel[]> GetProductReleasesAsync(int productVersionId, int avDetailId, int productBrandId);

        Task<ProductVersionReleaseModel[]> GetSelectReleasesAsync(string productIds);

        Task<ProductVersionReleaseModel> GetProductVersionReleaseAsync(int productId);

        Task<ProductVersionReleaseModel[]> GetProductValuesAsync(string productPulsarId);
    }
}
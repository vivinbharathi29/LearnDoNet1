using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDeliverableNamingRepository
    {
        Task<DeliverableNamingModel[]> GetDeliverableElementsAsync();
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ISupportCategoryRepository
    {
        Task<SupportCategoryModel[]> GetSupportCategoriesAsync(int? projectId);

        Task<string> GetSupportRequiredFieldsAsync(int categoryId);

        Task<SupportCategoryModel> GetSupportIssuesDefaultOwnerAsync(int supportCategoryId);
    }
}
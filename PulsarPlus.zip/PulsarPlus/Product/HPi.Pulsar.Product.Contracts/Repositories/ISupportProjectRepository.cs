using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ISupportProjectRepository
    {
        Task<SupportProjectModel[]> GetSupportProjectsAsync();
    }
}
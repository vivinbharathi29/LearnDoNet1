using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDevCenterRepository
    {
        Task<DevCenterModel[]> GetDevCentersAsync();
    }
}
﻿namespace HPi.Pulsar.Product.Contracts.Repositories
{
    using System.Threading.Tasks;

    public interface IDeliverableIssuesHistoryRepository
    {       
		Task<int> AddDeliverableIssuesHistory(DeliverableIssuesHistoryModel deliverableIssue);
    }
}

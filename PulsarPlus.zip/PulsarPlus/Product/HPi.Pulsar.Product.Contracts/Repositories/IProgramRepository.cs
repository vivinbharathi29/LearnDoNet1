using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProgramRepository
    {
        Task<ProgramModel[]> GetProgramsAsync();

        Task<ProgramModel[]> GetProductGroupAsync(int businessId);

        Task<ProgramModel[]> GetProgramTreeAsync(string productGroupIds);

        Task<ProgramModel[]> GetProductProgramTreeAsync(string productGroupIds = null);

        Task<ProgramModel> GetProgramPropertiesAsync(int programId);

        Task<ProgramGroupModel[]> GetProgramGroupsAsync(bool? active);
    }
}
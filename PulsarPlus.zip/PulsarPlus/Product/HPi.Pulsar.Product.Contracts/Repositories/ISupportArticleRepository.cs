using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ISupportArticleRepository
    {
        Task<SupportArticleModel[]> GetSupportArticleAsync(SupportArticleModel supportArticle);
    }
}
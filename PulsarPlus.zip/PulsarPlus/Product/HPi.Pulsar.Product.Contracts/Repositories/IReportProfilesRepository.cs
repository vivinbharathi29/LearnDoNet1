using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IReportProfilesRepository
    {

        Task<ReportProfileModel[]> GetReportProfilesAsync(int employeeId, int type);

        Task<ReportProfileModel[]> GetReportProfilesSharedAsync(int employeeId, int type);

        Task<ReportProfileModel[]> GetReportProfilesGroupSharedAsync(int employeeId, int type);

        Task<ReportProfileModel[]> GetReportProfileNameAsync(int employeeId);

        Task<ReportProfileModel> GetReportProfileDetailsAsync(int Id, int? employeeId);

        Task<int> RenameProfileAsync(int id, string profileName, int? employeeId);

        Task<int> DeleteProfileAsync(int profileId, int? employeeId);

        Task<int> UpdateProfileAsync(ReportProfileModel reportProfile);

        Task<int> AddProfileAsync(ReportProfileModel reportProfile);

        Task<int> RemoveSharedProfileAsync(int id);

        Task<ReportProfileModel[]> GetReportProfileSharedAsync(int id, int? employeeId);

        Task<ReportProfileModel[]> GetReportProfileGroupsAsync(int id);

        Task<int> RemoveSharedProfilesAsync(ReportProfileSharedModel reportProfileShared);

        Task<int> RemoveSharedProfileGroupAsync(ReportProfileSharedModel reportProfileShared);

        Task<int> UpdateSharedProfileGroupAsync(ReportProfileSharedModel reportProfileShared);

        Task<int> UpdateSharedProfilesAsync(ReportProfileSharedModel reportProfileShared);
    }
}
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IImageDefinitionsRepository
    {
        Task<ImageDefinitionModel[]> GetImageForProductRolloutAsync(int productId, int? productVersionReleaseId, PaginationModel pagination);

        Task<ImageDefinitionModel[]> GetImageForProductLegacyRolloutAsync(int productId, PaginationModel pagination);
    }
}
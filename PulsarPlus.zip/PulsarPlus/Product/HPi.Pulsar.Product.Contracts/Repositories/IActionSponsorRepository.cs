using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IActionSponsorRepository
    {
        Task<ActionSponsorModel[]> GetAllActionSponsorsAsync();
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductBrandRepository
    {
        Task<AVDescriptionModel[]> GetAVNoDescriptionsAsync(int productVersionID, int productBrandID, int scmCategoryID);

        Task<bool> TryUpdateAvDetailFeatureIdAsync(AVDetailModel avDetailModel);

        Task<ProductBrandModel[]> GetImageDefinitionBrandsAsync(int productId, int? imageDefinitionId);

        Task<bool> TryImageAddObsoleteLocalizedAvAsync(int imageActionItemId, int productVersionId, int productBrandId, int actionType, string updatedBy);

        Task<ProductBrandModel[]> GetBaseUnitAvailabilityAsync(int pvId, int bId, int avId);

        Task<FormFactorTouchModel[]> GetFormFactorTouchAsync();

        Task<PmasterProductModel[]> GetPlatformSOARProdDescAsync();
    }
}
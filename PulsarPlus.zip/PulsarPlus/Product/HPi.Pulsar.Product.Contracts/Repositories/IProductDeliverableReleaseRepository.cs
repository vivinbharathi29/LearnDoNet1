using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductDeliverableReleaseRepository
    {
        Task<bool> TryUpdateDeveloperNotificationStatusAsync(LinkProductModel linkProductModel);

        Task<bool> TryUpdateDeveloperNotificationStatusPulsarAsync(LinkProductModel linkProductModel);

        Task<bool> TryUpdateDeveloperNotificationWithMultipleItemAsync(LinkProductModel linkProductModel);

        Task<bool> TryUpdateDeveloperNotificationPulsarWithMultipleItemAsync(LinkProductModel linkProductModel);

        Task<ProductDeliverableReleaseModel> GetTestLeadStatusPulsarAsync(int productDeliverableReleaseId, int fieldId);

        Task<bool> TryUpdateTestLeadStatusPulsarAsync(TestLeadStatusPulsarModel testLeadStatusPulsar);

        Task<ProductDeliverableReleaseModel[]> GetQualStatusReleaseDetailsAsync(int productId, int releaseId, int versionId, string todayPageSection, int productDeliverableReleaseId);

        Task<ProductDeliverableReleaseModel[]> GetComponentProductReleasesAsync(int productId, int versionId);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDCRWorkflowLookupRepository
    {
        Task<DcrWorkflowLookupModel[]> GetDCRWorkflowsAsync();
    }
}
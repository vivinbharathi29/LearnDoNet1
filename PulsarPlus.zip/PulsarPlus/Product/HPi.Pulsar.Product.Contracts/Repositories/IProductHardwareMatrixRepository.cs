using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductHardwareMatrixRepository
    {
        Task<HardwareMatrixSearchModel> GetHardwareMatrixSearchResultAsync(HardwareMatrixInputModel hardwareMatrixInput);

        Task<HardwareMatrixSearchModel> GetHardwareMatrixProductListForDisplayAsync(HardwareMatrixInputModel hardwareMatrixInput);

        Task<ProductVersionModel[]> GetSubassembliesExpiringProductionAsync(string productId, string categoryId, int months, PaginationModel pagination);

        Task<ProductVersionModel[]> GetSubassembliesExpiringPostProductionAsync(string productId, string categoryId, int months, PaginationModel pagination);

        Task<HardwareMatrixSearchModel> GetProductHardwareMatrixResultAsync(HardwareMatrixInputModel hardwareMatrixInput);

        Task<HardwareMatrixSearchModel> GetCategoryProductReleaseCountAsync(HardwareMatrixInputModel hardwareMatrixInput);
    }
}
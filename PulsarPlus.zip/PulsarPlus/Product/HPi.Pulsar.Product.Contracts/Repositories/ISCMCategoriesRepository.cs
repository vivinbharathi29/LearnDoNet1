using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ISCMCategoriesRepository
    {
        Task<ScmCategoryModel[]> GetSCMCategoriesProductLinesAsync();

        Task<ScmCategoryModel> GetScmCategoryAsync(int productBrandId, int scmCategoryId);

        Task<bool> TryUpdateScmCategoryAsync(int productBrandId, int scmCategoryId, string configRules, string manufacturingNotes, string marketingDescription, int? categoryMin, int? categoryMax, string userName, string retMsg, string rulesSyntax);
        
        Task<ScmCategoryModel[]> GetSCMCategoriesAsync(int? catId);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IImagesRepository
    {
        Task<ImageModel[]> GetImageAsync(int imageDefId);

        Task<string> GetRolloutDateAsync(int productId, int priority, string dash, int? imageDefId);

        Task<bool> TryUpdateImageRampPlanAsync(ImageModel[] imageDetails);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IVendorRepository
    {
        Task<VendorModel[]> GetVendors4RootAsync(int rootId);

        Task<VendorModel[]> GetDeliverableUsagesByVendorAsync(int rootId);

        Task<VendorModel[]> GetVendorsAsync();
    }
}
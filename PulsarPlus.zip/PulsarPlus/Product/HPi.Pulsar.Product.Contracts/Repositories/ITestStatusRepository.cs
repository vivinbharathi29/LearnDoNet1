using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ITestStatusRepository
    {
        Task<TestStatusModel[]> GetTestStatusesAsync();
    }
}
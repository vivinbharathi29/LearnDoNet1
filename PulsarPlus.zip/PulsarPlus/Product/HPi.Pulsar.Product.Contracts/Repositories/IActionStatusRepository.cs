using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IActionStatusRepository
    {
        Task<ActionStatusModel[]> GetActionStatusesByTypeAsync(int type);
    }
}
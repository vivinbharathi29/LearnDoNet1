using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDeliverableCategoryRepository
    {
        Task<DeliverableCategoryModel[]> GetDeliverableCategoryAvPrefixValuesAsync();

        Task<DeliverableCategoryModel[]> GetDeliverableCategoriesByTypeAsync(int? typeId);

        Task<DeliverableCategoryModel[]> GetHWCategoriesAsync();

        Task<DeliverableCategoryModel> GetListCategoryAsync(int id);

        Task<DeliverableCategoryModel[]> GetSelectCatListAsync();
    }
}
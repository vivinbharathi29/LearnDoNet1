using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IAVNamingRepository
    {
        Task<AVNamingModel[]> GetAVElementsAsync();
    }
}
﻿using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IApplicationErrorRepository
    {
        Task<AppErrorModel> GetApplicationErrorOutstandingAsync(int appErrorId);

        Task<int> UpdateApplicationErrorAsync(int id, string cause);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ISupportCancelLogRepository
    {
        Task<bool> TryCancelSupportLogAsync(SupportModel support);
    }
}
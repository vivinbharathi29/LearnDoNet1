using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ILanguageRepository
    {
        Task<LanguageModel[]> GetLanguagesAsync();

        Task<LanguageModel[]> GetCountriesAsync(int? optionId, string optionName, string list, PaginationModel pagination);
    }
}
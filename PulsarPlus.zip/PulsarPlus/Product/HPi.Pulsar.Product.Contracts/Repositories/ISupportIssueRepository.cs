using System.Collections.Generic;
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface ISupportIssueRepository
    {
        Task<SupportIssueModel> GetSupportTicketInfoAsync(int ticketNumber);

        Task<int> UpdateSupportTicketConverted2ActionAsync(int ticketID, int actionItemID);

        Task<SupportIssueModel[]> GetSupportSearchOpenKnownIssuesAsync(SupportIssueModel supportIssue);

        Task<int> SaveSupportIssuesAsync(SupportModel support);

        Task<List<SupportArticleModel>> GetSupportArticlesAsync(int? Id);
    }
}
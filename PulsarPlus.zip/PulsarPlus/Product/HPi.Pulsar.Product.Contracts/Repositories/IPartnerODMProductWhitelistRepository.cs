using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IPartnerODMProductWhitelistRepository
    {
        Task<PartnerODMProductWhitelistModel[]> GetProductWhitelistAsync(int partnerId);
    }
}
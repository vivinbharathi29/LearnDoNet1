using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IProductFamilyRepository
    {
        Task<ProductFamilyModel[]> GetListProductFamilyAsync(int id);

        Task<ProductFamilyModel[]> GetProductsAllAsync(int? type, int? partnerId);
    }
}
using System.Collections.Generic;
using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDeliverableVersionRepository
    {
        Task<DeliverableVersionModel> GetDeliverableVersionPropertiesAsync(int versionID);

        Task<DeliverableVersionModel[]> GetVersionPropertiesForWebAsync(int id);

        Task<bool> TryUpdateDeliverableServiceEOLAsync(int id, string eolDate, int active);

        Task<DeliverableVersionModel[]> GetDeliverableVersionsAsync(int? rootId, int? prodId, int? versionList, int? partnerId);

        Task<bool> TryUpdateDeliverableEOLAsync(int id, string eolDate, int active);

        Task<int> UpdateWWANTTSAsync(DeliverableVersionModel deliverableVersiondata);

        Task<int?> GetRootIdByVersionAsync(int versionId);

        Task<bool> TryUpdateDeliverableLocationAsync(int deliverableId);
        
		Task<DeliverableVersionModel[]> GetVersionHistoriesAsync(int rootId, int prodId);

        Task<DeliverableVersionModel[]> GetDeliverablesToUpdateAsync(string idList);

        Task<bool> TrySyncServiceToFactoryEOAAsync(int id);

        Task<DeliverableVersionModel[]> GetProductMultiTestStatusAsync(int? productId, int? rootId, string selectedVersionIds, int partnerId);

        Task<List<string>> GetDeliverableVersionIdsAsync(int rootId, int leadId, int productId, int fusionRequirement);

        Task<DeliverableVersionModel[]> GetAllLeadProductExclusionsAsync(int pmId);

        Task<DeliverableVersionModel[]> GetDeliverableVersionExclusionsByVersionIdsAsync(string versionIds);

        Task<DeliverableVersionModel[]> GetRootIdsAsync(int id);

        Task<DeliverableVersionModel> GetWWANTTSStausAsync(int id);

        Task<DeliverableVersionModel[]> GetReleaseDeliverableVersionsAsync(string versionId);

        Task<bool> TryUpdateDeliverableForReleaseAsync(DeliverableVersionModel deliverableVersion);

        Task<DeliverableVersionModel[]> GetProductMultiTestStatusPulsarAsync(string productDeliverableIds, string productIds, int? rootId, int? productId, int? bsId, int? showOnlyTargetedRelease);

        Task<DeliverableVersionModel> GetChangeImagesVersionPropertiesForWebAsync(int id);

        Task<DeliverableVersionModel> GetDistributionVersionAsync(int productId, int versionId);

        Task<DeliverableVersionModel[]> GetStoredPathDataAsync(string textFind, PaginationModel pagination);

        Task<int> UpdateStoredPathAsync(string updateFind, string updateReplace);

        Task<DeliverableVersionModel[]> GetDeliverableSyncDataAsync(PaginationModel pagination);

        Task<int> UpdateDeliverableSyncAsync();
    }
}
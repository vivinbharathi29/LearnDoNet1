using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IOSLookupRepository
    {
        Task<OSLookupModel[]> GetAllProductOSAsync(int productVersionId);

        Task<OSLookupModel> GetOSbyIdAsync(int osId);
    }
}
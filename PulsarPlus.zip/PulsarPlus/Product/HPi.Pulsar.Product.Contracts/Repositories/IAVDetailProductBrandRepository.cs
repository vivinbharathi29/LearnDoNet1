using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IAVDetailProductBrandRepository
    {
        Task<string> UpdateAVDetailProductBrandPulsarAsync(AVDetailProductBrandModel avDetailProductBrand);

        Task<AVDetailProductBrandModel[]> GetAVDetailBaseUnitsAsync(int productVersionId, int brandId, int avDetailId);

        Task<AVDetailProductBrandModel[]> GetAvsNotInKmatBomAsync(int? productBrandId);

        Task<AVDetailProductBrandModel[]> GetLogHistory(int brandId, int showAll, PaginationModel pagination);

        Task<bool> TryUpdateAvHistoryAsync(string AVHistoryId, string showOnScm, string showOnPm, string updatedUser);

        Task<AVDetailProductBrandModel[]> GetUnreleasedAvsAsync(int? productBrandId);
    }
}
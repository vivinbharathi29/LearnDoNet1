using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IActionRoadmapRepository
    {
        Task<ActionRoadmapModel[]> GetActionsRoadmapByProductIdAsync(int productId);

        Task<ActionRoadmapModel[]> GetActionRoadmapItemForTaskAsync(int id);
    }
}
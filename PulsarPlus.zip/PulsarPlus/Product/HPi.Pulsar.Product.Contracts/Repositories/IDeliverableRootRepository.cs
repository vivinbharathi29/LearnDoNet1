using System.Threading.Tasks;
using HPi.Pulsar.Infrastructure.Contracts.Pagination;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IDeliverableRootRepository
    {
        Task<DeliverableRootModel> GetDeliverableRootInfoAsync(int rootId);

        Task<DeliverableRootModel[]> GetSubassembliesAllAppropriateAsync(int productId, int versionId);

        Task<DeliverableRootModel[]> GetSubassembliesAllAppropriateReleaseAsync(int productId, int versionId, int productDeliverableReleaseId);

        Task<DeliverableRootModel> GetProductDeliverableRootSummaryByIdAsync(int id, int productDeliverableReleaseId);

        Task<DeliverableRootModel[]> GetDeliverableRootProductPMWithMultipleItemAsync(string product);

        Task<DeliverableRootModel> GetRootPropertiesForVersionAsync(int id);

        Task<DeliverableRootModel> GetDistributionRootAsync(int productId, int rootId);

        Task<bool> TryUpdateDeliverableRootAsync(DeliverableRootModel deliverableRoot);

        Task<DeliverableRootModel[]> GetDeliverableNameSubAssemblyAsync(string productDelRootId);

        Task<DeliverableRootModel[]> GetRootPropertiesAsync(int Id);

        Task<DeliverableRootModel> GetRootAsync(int id);

        Task<DeliverableRootModel[]> GetDeliverableRootsAsync(int type, int pageNumber, int pageSize, string searchString);

        Task<DeliverableRootModel[]> GetProductsByDeliverableReleaseAsync(int rootId, int saType, int assigned);

        Task<DeliverableRootModel[]> GetNamingStandardDeploymentValuesAsync();

        Task<DeliverableRootModel[]> GetDeliverableRootMainDataAsync(PaginationModel pagination);
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts.Repositories
{
    public interface IScheduleDefinitionDataRepository
    {
        Task<ScheduleDefinitionDataModel[]> GetMilestonePulsarScheduleDefinitionDataAsync();

        Task<int> GetGenericOwnerAsync(int scheduleDefinitionDataId);

        Task<ScheduleDefinitionDataModel[]> GetListOwnersAsync();
    }
}
using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class ImageSwTypeModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int Active { get; set; }

        public DateTime? Created { get; set; }

        public int? DisplayOrder { get; set; }

        public string GPGDescriptionName { get; set; }
    }
}
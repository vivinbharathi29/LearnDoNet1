namespace HPi.Pulsar.Product.Contracts
{
    public class ActionStatusModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public bool ToolActionStatus { get; set; }

        public bool PlatformActionStatus { get; set; }

        public bool OpenStatus { get; set; }

        public short DisplayOrder { get; set; }

        public bool PlatformDcrStatus { get; set; }

        public bool? TestStatus { get; set; }

        public DeliverableIssueModel DeliverableIssue { get; set; }
    }
}
﻿namespace HPi.Pulsar.Product.Contracts
{
    using System;

    public class DeliverableVersionModel
    {
        public int Id { get; set; }

        public int? DeliverableRootId { get; set; }

        public int PathId { get; set; }

        public string DeliverableName { get; set; }

        public string Name { get; set; }

        public string PartnerName { get; set; }

        public string DeliverableRootName { get; set; }

        public string Version { get; set; }

        public string Revision { get; set; }

        public string Pass { get; set; }

        public int? Status { get; set; }

        public string Location { get; set; }

        public string VendorVersion { get; set; }

        public bool Latest { get; set; }

        public string PartNumber { get; set; }

        public string Comments { get; set; }

        public DateTime? Planned { get; set; }

        public DateTime? Actual { get; set; }

        public byte? ReportMilestone { get; set; }

        public string Milestone { get; set; }

        public string LevelDesc { get; set; }

        public string OtherDependencies { get; set; }

        public int? DeveloperId { get; set; }

        public string ReleaseDoc { get; set; }

        public string DeliverableSpec { get; set; }

        public string ImagePath { get; set; }

        public string Action { get; set; }

        public int? Pulsar { get; set; }

        public string TransferPath { get; set; }

        public string TdcImagePath { get; set; }

        public DateTime? ReleaseDate { get; set; }

        public string Changes { get; set; }

        public short? SpecType { get; set; }

        public int? VendorId { get; set; }

        public DateTime? ActualReleaseDate { get; set; }

        public string ActualReleaseDesc { get; set; }

        public DateTime? IntroDate { get; set; }

        public DateTime? SampleDate { get; set; }

        public DateTime? EndOfLifeDate { get; set; }

        public string DisplayPartNumber { get; set; }

        public string Languages { get; set; }

        public byte? InstallableUpdate { get; set; }

        public string SoftpaqNumber { get; set; }

        public string Supersedes { get; set; }

        public string SoftpaqFixes { get; set; }

        public string SoftpaqFileInfo { get; set; }

        public string SoftpaqType { get; set; }

        public string SoftpaqInstructions { get; set; }

        public string SWDependencies { get; set; }

        public string OSType { get; set; }

        public string PackageType { get; set; }

        public string EndUserInstructions { get; set; }

        public string SilentInstructions { get; set; }

        public string Install { get; set; }

        public string SilentInstall { get; set; }

        public string ArcdInstall { get; set; }

        public byte? Reboot { get; set; }

        public byte? Preinstall { get; set; }

        public byte? Rompaq { get; set; }

        public byte? CDImage { get; set; }

        public byte? Cab { get; set; }

        public byte? Binary { get; set; }

        public byte? FloppyDisk { get; set; }

        public byte? PreinstallRom { get; set; }

        public byte? Admin { get; set; }

        public string Filename { get; set; }

        public bool? SsmCompliant { get; set; }

        public bool? Desktops { get; set; }

        public bool? Notebooks { get; set; }

        public bool? Workstations { get; set; }

        public bool? ThinClients { get; set; }

        public bool? Monitors { get; set; }

        public bool? Projectors { get; set; }

        public bool? Handhelds { get; set; }

        public bool? Printers { get; set; }

        public bool? PersonalAudio { get; set; }

        public bool? Scriptpaq { get; set; }

        public byte? ReleaseType { get; set; }

        public string PnpDevices { get; set; }

        public string PackagingDesc { get; set; }

        public string RomComponentDesc { get; set; }

        public string IconInstalled { get; set; }

        public string CDPartNumber { get; set; }

        public bool? PmrComplete { get; set; }

        public byte? ReleasePriority { get; set; }

        public string ReleasePriorityJustification { get; set; }

        public int? CertificationStatus { get; set; }

        public string CertRequiredStatusDesc { get; set; }

        public string CertificationDate { get; set; }

        public string CertificationId { get; set; }

        public string CertificationComments { get; set; }

        public string CatStatus { get; set; }

        public byte? MultiLanguage { get; set; }

        public DateTime? EffectiveDate { get; set; }

        public bool? Hfcn { get; set; }

        public string HfcnLocation { get; set; }

        public string HfcnNotify { get; set; }

        public DateTime? Created { get; set; }

        public bool? PreReleased { get; set; }

        public bool? IconDesktop { get; set; }

        public bool? IconMenu { get; set; }

        public bool? IconTray { get; set; }

        public bool? IconPanel { get; set; }

        public bool? PackageForWeb { get; set; }

        public byte? PackagingForWeb { get; set; }

        public string PropertyTabs { get; set; }

        public byte? Imported { get; set; }

        public byte? IsoImage { get; set; }

        public string Replicater { get; set; }

        public short? CvaVersion { get; set; }

        public byte? Archived { get; set; }

        public int? LevelId { get; set; }

        public string ModelNumber { get; set; }

        public byte? PostRtmStatusId { get; set; }

        public string OtsPartNumber { get; set; }

        public byte? SamplesConfidence { get; set; }

        public string SamplesConfidenceDesc { get; set; }

        public byte? IntroConfidence { get; set; }

        public string IntroConfidenceDesc { get; set; }

        public DateTime? PostRtmTargetDate { get; set; }

        public byte? DeveloperNotification { get; set; }

        public short? LeadFree { get; set; }

        public byte? AR { get; set; }

        public string CodeName { get; set; }

        public string PostRtmComments { get; set; }

        public string Path2Location { get; set; }

        public string Path2Description { get; set; }

        public bool? Active { get; set; }

        public string Path3Location { get; set; }

        public string Path3Description { get; set; }

        public byte? ConsumerReleaseStatus { get; set; }

        public byte? CommercialReleaseStatus { get; set; }

        public string CDKitNumber { get; set; }

        public byte? ArchivedPath2 { get; set; }

        public byte? ArchivedPath3 { get; set; }

        public byte? ArchivedTdc { get; set; }

        public string AssemblyCode { get; set; }

        public int? SWSetupCategoryId { get; set; }

        public bool? MuiAware { get; set; }

        public bool? IconInfoCenter { get; set; }

        public int? PreinstallInternalRev { get; set; }

        public string EDId { get; set; }

        public string Tts { get; set; }

        public bool? WwanFailureConfirmed { get; set; }

        public string WwanTestReport { get; set; }

        public string WwanTestSpecRev { get; set; }

        public DateTime? ServiceEoaDate { get; set; }

        public bool? ServiceActive { get; set; }

        public byte? OemReadyStatus { get; set; }

        public string OemReadyStatusDesc { get; set; }

        public string VendorIdDesc { get; set; }

        public string SubsysVendorIdDesc { get; set; }

        public string DeviceIdDesc { get; set; }

        public string SubsysDeviceIdDesc { get; set; }

        public DateTime? OemReadyDate { get; set; }

        public string OemReadyId { get; set; }

        public string OemReadyComments { get; set; }

        public string LearnMore { get; set; }

        public string AdditionalReleaseNotifications { get; set; }

        public string SoftpaqEnhancements { get; set; }

        public string MD5 { get; set; }

        public int? CloneId { get; set; }

        public int? CloneType { get; set; }

        public string ReturnCodes { get; set; }

        public int? PreinstallInternalRevTdc { get; set; }

        public int? RoHSId { get; set; }

        public int? GreenSpecId { get; set; }

        public DateTime? PmrDate { get; set; }

        public int? PreinstallPrepStatus { get; set; }

        public int? PreinstallPnRev { get; set; }

        public int? PreinstallPnRevTdc { get; set; }

        public string FccId { get; set; }

        public string Anatel { get; set; }

        public string Icasa { get; set; }

        public bool? SecondaryRFKill { get; set; }

        public string RfkillMechanism { get; set; }

        public string HWQualStatus { get; set; }

        public string HWPilotStatus { get; set; }

        public byte? Patch { get; set; }

        public int? IrsId { get; set; }

        public string IrsPath { get; set; }

        public int? IrsRootId { get; set; }

        public int? IrsVersionId { get; set; }

        public int? IrsRevisionId { get; set; }

        public byte? DriverPack { get; set; }

        public byte? AppStore { get; set; }

        public string SoftpaqNumbers { get; set; }

        public int? IrsFilesCopied { get; set; }

        public bool? Odie { get; set; }

        public string IrsPartNumber { get; set; }

        public string InitialPath { get; set; }

        public int? SubmitterId { get; set; }

        public int? MftJobId { get; set; }

        public bool? MftNotifySubmitter { get; set; }

        public bool? DpbCompliant { get; set; }

        public string DevicesInfPath { get; set; }

        public string EntryMePcr0 { get; set; }

        public string FullMePcr0 { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public DateTime? Deactivated { get; set; }

        public DateTime? ServiceDeactivated { get; set; }

        public int? SupplierId { get; set; }

        public string KoreanCertificationId { get; set; }

        public string BaseFilePath { get; set; }

        public string CvaSubPath { get; set; }

        public int? KoreanCertificationRequired { get; set; }

        public int? TransferServerId { get; set; }

        public string SubmissionPath { get; set; }

        public DateTime? LastSentToPrism { get; set; }

        public int? TestLeadId { get; set; }

        public DateTime? RtmDate { get; set; }

        public int? PrismSWType { get; set; }

        public string DpbComment { get; set; }

        public int? DevManagerId { get; set; }

        public int? CdVerificationId { get; set; }

        public int? PrismSWStatusId { get; set; }

        public int? ML { get; set; }

        public int? PrismRevision { get; set; }

        public UserInfoModel UserInfo { get; set; }

        public DeliverableRootModel DeliverableRoot { get; set; }

        public IrsTransferStatusModel IrsTransferStatus { get; set; }

        public DeliverableScheduleModel DeliverableSchedule { get; set; }

        public VendorModel Vendor { get; set; }

        public DeliverableCategoryModel DeliverableCategory { get; set; }

        public ProductVersionModel ProductVersionModel { get; set; }

        public ScheduleStatusModel ScheduleStatus { get; set; }

        public int TotalNoOfRows { get; set; }

        public string VersionIds { get; set; }

        public ProductDeliverableModel ProductDeliverable { get; set; }

        public ProductDeliverableReleaseModel ProductDeliverableRelease { get; set; }

        public ProductVersionModel ProductVersion { get; set; }

        public EmployeeModel EmployeeModel { get; set; }

        public VendorModel VendorModel { get; set; }

        public int? TotalNumberOfRows { get; set; }

        public PostRtmStatusModel PostRtmStatus { get; set; }

        public string CustomVersion { get; set; }

        public string SupportedProducts { get; set; }

        public string BuildLevel { get; set; }

        public string FunctionalTestTeam { get; set; }

        public string TestStatus { get; set; }

        public string HfcnNewComponentReleaseOne { get; set; }

        public string Component { get; set; }

        public DeliverableLevelModel DeliverableLevel { get; set; }

        public string StrVersion { get; set; }

        public string StrOdmTestStatus { get; set; }

        public string StrMitTestStatus { get; set; }

        public string StrWwanTestStatus { get; set; }

        public string StrtargetDate { get; set; }

        public string VersionRevisionPass { get; set; }

        public string RowColor { get; set; }

        public ProductVersionReleaseModel ProductVersionRelease { get; set; }

        public SoftpaqCategoryModel SoftpaqCategory { get; set; }

        public string AccessoryStatusName { get; set; }

        public string PilotStatusName { get; set; }

        public string PilotStatusDate { get; set; }

        public TestStatusModel TestStatusModel { get; set; }

        public AccessoryStatusModel AccessoryStatusModel { get; set; }

        public ProductLeadRootExceptionModel ProductLeadRootExceptionsModel { get; set; }

        public int NextMilestoneId { get; set; }

        public int PilotStatusId { get; set; }

        public string Developer { get; set; }

        public int RptObservationId { get; set; }

        public string RptStatus { get; set; }

        public string RptState { get; set; }

        public string RptOwner { get; set; }

        public int RptPriority { get; set; }

        public string RptComponent { get; set; }

        public string RptOtsComponentVersion { get; set; }

        public string RptSummary { get; set; }

        public int RecordCount { get; set; }

        public ActionsModel Actions { get; set; }

        public int OtsCount { get; set; }

        public int InImage { get; set; }

        public bool? InOfficialImage { get; set; }

        public int ImageId { get; set; }

        public string Images { get; set; }

        public int ProductId { get; set; }

        public string Distribution { get; set; }

        public int OsId { get; set; }

        public string Issue { get; set; }

        public ActionLogModel ActionLog { get; set; }

        public string ActionName { get; set; }

        public int OTSFound { get; set; }

        public int OTSFixed { get; set; }

        public string Factoryeoa { get; set; }

        public string Serviceeoa { get; set; }

        public string Softwareeol { get; set; }

        public string CoreTeam { get; set; }

        public string Category { get; set; }

        public string SubDeviceIdDesc { get; set; }

        public string FieldName { get; set; }

        public string SIvalue { get; set; }

        public string ExcaliburValue { get; set; }
    }
}
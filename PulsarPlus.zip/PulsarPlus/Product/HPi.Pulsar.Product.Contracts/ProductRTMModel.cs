

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductRTMModel</para>
    /// </summary>
    public class ProductRTMModel
    {
		/// <summary>
		/// Gets or sets the Id.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ProductVersionId.
		/// </summary>
		public int ProductVersionId { get; set; }

		/// <summary>
		/// Gets or sets the Title.
		/// </summary>
		public string Title { get; set; }

		/// <summary>
		/// Gets or sets the RTMDate.
		/// </summary>
		public DateTime? RTMDate { get; set; }

		/// <summary>
		/// Gets or sets the Comments.
		/// </summary>
		public string Comments { get; set; }

		/// <summary>
		/// Gets or sets the SubmittedById.
		/// </summary>
		public int SubmittedById { get; set; }

		/// <summary>
		/// Gets or sets the Created.
		/// </summary>
		public DateTime? Created { get; set; }

        /// <summary>
        /// Gets or sets the RTM comments.
        /// </summary>
        /// <value>
        /// The RTM comments.
        /// </value>
        public string RTMComments { get; set; }

        /// <summary>
        /// Gets or sets the BIOSComments.
        /// </summary>
        public string BIOSComments { get; set; }

		/// <summary>
		/// Gets or sets the RestoreComments.
		/// </summary>
		public string RestoreComments { get; set; }

		/// <summary>
		/// Gets or sets the ImageComments.
		/// </summary>
		public string ImageComments { get; set; }

		/// <summary>
		/// Gets or sets the PatchComments.
		/// </summary>
		public string PatchComments { get; set; }

		/// <summary>
		/// Gets or sets the Attachment1.
		/// </summary>
		public string Attachment1 { get; set; }

		/// <summary>
		/// Gets or sets the FWComments.
		/// </summary>
		public string FWComments { get; set; }

        /// <summary>
		/// Gets or sets the Submitter.
		/// </summary>
		public EmployeeModel Submitter { get; set; }

        /// <summary>
		/// Gets or sets the TotalNoOfRows.
		/// </summary>
		public int TotalNoOfRows { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is patch checked.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is patch checked; otherwise, <c>false</c>.
        /// </value>
        public bool IsPatchChecked { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [patch ids].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [patch ids]; otherwise, <c>false</c>.
        /// </value>
        public string PatchIds { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is bios checked.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is bios checked; otherwise, <c>false</c>.
        /// </value>
        public bool IsBiosChecked { get; set; }

        /// <summary>
        /// Gets or sets the bios ids.
        /// </summary>
        /// <value>
        /// The bios ids.
        /// </value>
        public string BiosIds { get; set; }

        /// <summary>
        /// Gets or sets the bios detail.
        /// </summary>
        /// <value>
        /// The bios detail.
        /// </value>
        public string Detail { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is image checked.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is image checked; otherwise, <c>false</c>.
        /// </value>
        public bool IsImageChecked { get; set; }

        /// <summary>
        /// Gets or sets the image ids.
        /// </summary>
        /// <value>
        /// The image ids.
        /// </value>
        public string ImageIds { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is restore checked.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is restore checked; otherwise, <c>false</c>.
        /// </value>
        public bool IsRestoreChecked { get; set; }

        /// <summary>
        /// Gets or sets the restore ids.
        /// </summary>
        /// <value>
        /// The restore ids.
        /// </value>
        public string RestoreIds { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is firmware checked.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is firmware checked; otherwise, <c>false</c>.
        /// </value>
        public bool IsFirmwareChecked { get; set; }

        /// <summary>
        /// Gets or sets the firmware ids.
        /// </summary>
        /// <value>
        /// The firmware ids.
        /// </value>
        public string FirmwareIds { get; set; }

        /// <summary>
        /// Gets or sets the notify.
        /// </summary>
        /// <value>
        /// The notify.
        /// </value>
        public string Notify { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersion.
        /// </summary>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the ProductProgram.
        /// </summary>
        public ProductProgramModel ProductProgram { get; set; }

        /// <summary>
        /// Gets or sets the Program.
        /// </summary>
        public ProgramModel Program { get; set; }

        /// <summary>
		/// Gets or sets the UserInfo.
		/// </summary>
        public UserInfoModel UserInfo { get; set; }

        /// <summary>
		/// Gets or sets the Image.
		/// </summary>
        public ImageModel Image { get; set; }

        /// <summary>
		/// Gets or sets the Region.
		/// </summary>
        public RegionModel Region { get; set; }

        /// <summary>
		/// Gets or sets the ImageDefinition.
		/// </summary>
        public ImageDefinitionModel ImageDefinition { get; set; }

        /// <summary>
		/// Gets or sets the ImageSwType.
		/// </summary>
        public ImageSwTypeModel ImageSwType { get; set; }

        /// <summary>
		/// Gets or sets the OSLookup.
		/// </summary>
        public OSLookupModel OSLookup { get; set; }

        /// <summary>
		/// Gets or sets the Brand.
		/// </summary>
        public BrandModel Brand { get; set; }

        /// <summary>
		/// Gets or sets the ProductRTMDeliverableVersion.
		/// </summary>
        public ProductRTMDeliverableVersionModel ProductRTMDeliverableVersion { get; set; }

        /// <summary>
		/// Gets or sets the DeliverableVersion.
		/// </summary>
        public DeliverableVersionModel DeliverableVersion { get; set; }

        /// <summary>
		/// Gets or sets the ProductRTMAlerts.
		/// </summary>
        public ProductRTMAlertsModel ProductRTMAlerts { get; set; }

        /// <summary>
		/// Gets or sets the ProductRTMAlertSections.
		/// </summary>
        public ProductRTMAlertSectionsModel ProductRTMAlertSections { get; set; }
    }
}
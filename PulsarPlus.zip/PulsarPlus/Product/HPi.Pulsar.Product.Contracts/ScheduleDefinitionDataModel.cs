

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class ScheduleDefinitionDataModel.
    /// </summary>
    public class ScheduleDefinitionDataModel
    {
        /// <summary>
        /// Gets or sets the Scheduledefinitiondataid.
        /// </summary>
        /// <value>
        /// The scheduledefinitiondata identifier.
        /// </value>
        public int ScheduleDefinitionDataId { get; set; }

        /// <summary>
        /// Gets or sets the Scheduledefinitionid.
        /// </summary>
        /// <value>
        /// The scheduledefinition identifier.
        /// </value>
        public int ScheduleDefinitionId { get; set; }

        /// <summary>
        /// Gets or sets the Itemdescription.
        /// </summary>
        /// <value>
        /// The itemdescription.
        /// </value>
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets the Itemphase.
        /// </summary>
        /// <value>
        /// The itemphase.
        /// </value>
        public int ItemPhase { get; set; }

        /// <summary>
        /// Gets or sets the Itemorder.
        /// </summary>
        /// <value>
        /// The itemorder.
        /// </value>
        public int ItemOrder { get; set; }

        /// <summary>
        /// Gets or sets the Itemdefinition.
        /// </summary>
        /// <value>
        /// The itemdefinition.
        /// </value>
        public string ItemDefinition { get; set; }

        /// <summary>
        /// Gets or sets the Milestoneyn.
        /// </summary>
        /// <value>
        /// The milestoneyn.
        /// </value>
        public string MilestoneYN { get; set; }

        /// <summary>
        /// Gets or sets the Requiredyn.
        /// </summary>
        /// <value>
        /// The requiredyn.
        /// </value>
        public string RequiredYN { get; set; }

        /// <summary>
        /// Gets or sets the Activeyndefault.
        /// </summary>
        /// <value>
        /// The activeyndefault.
        /// </value>
        public string ActiveYNDefault { get; set; }

        /// <summary>
        /// Gets or sets the Activeyn.
        /// </summary>
        /// <value>
        /// The activeyn.
        /// </value>
        public string ActiveYN { get; set; }

        /// <summary>
        /// Gets or sets the Lastupduser.
        /// </summary>
        /// <value>
        /// The lastupduser.
        /// </value>
        public string LastUpdUser { get; set; }

        /// <summary>
        /// Gets or sets the Lastupddate.
        /// </summary>
        /// <value>
        /// The lastupddate.
        /// </value>
        public DateTime LastUpdDate { get; set; }

        /// <summary>
        /// Gets or sets the NotificationRecipients.
        /// </summary>
        /// <value>
        /// The notification recipients.
        /// </value>
        public string NotificationRecipients { get; set; }

        /// <summary>
        /// Gets or sets the OwnerRoleId.
        /// </summary>
        /// <value>
        /// The owner role identifier.
        /// </value>
        public int? OwnerRoleId { get; set; }

        /// <summary>
        /// Gets or sets the GenericOwner.
        /// </summary>
        /// <value>
        /// The generic owner.
        /// </value>
        public int? GenericOwner { get; set; }

        /// <summary>
        /// Gets or sets the ScheduleData.
        /// </summary>
        /// <value>
        /// The schedule data.
        /// </value>
        public ScheduleDataModel ScheduleData { get; set; }
    }
}
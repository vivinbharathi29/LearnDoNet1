﻿namespace HPi.Pulsar.Product.Contracts
{
    public class BusinessSegmentModel
    {
        public int BusinessSegmentId { get; set; }

        public string Name { get; set; }

        public string Abbreviation { get; set; }

        public string Description { get; set; }

        public int? BusinessId { get; set; }

        public byte Operation { get; set; }
    }
}

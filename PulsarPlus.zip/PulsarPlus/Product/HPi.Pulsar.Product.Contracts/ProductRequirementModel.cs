

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductRequirementModel</para>
    /// </summary>
    public class ProductRequirementModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Gets or sets the ProductID.
		/// </summary>
		public int? ProductID { get; set; }

		/// <summary>
		/// Gets or sets the RequirementID.
		/// </summary>
		public int? RequirementID { get; set; }

		/// <summary>
		/// Gets or sets the Specification.
		/// </summary>
		public string Specification { get; set; }

		/// <summary>
		/// Gets or sets the Deliverables.
		/// </summary>
		public string Deliverables { get; set; }

		/// <summary>
		/// Gets or sets the DeliverablesSaved.
		/// </summary>
		public byte? DeliverablesSaved { get; set; }

		/// <summary>
		/// Gets or sets the CopyProductID.
		/// </summary>
		public int? CopyProductID { get; set; }

		/// <summary>
		/// Gets or sets the AdditionalInformation.
		/// </summary>
		public string AdditionalInformation { get; set; }

        /// <summary>
		/// Gets or sets the Related Components.
		/// </summary>
		public string RelatedComponents { get; set; }
    }
}
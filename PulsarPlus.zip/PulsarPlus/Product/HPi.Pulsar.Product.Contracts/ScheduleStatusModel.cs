

namespace HPi.Pulsar.Product.Contracts
{
    /// <summary>
    /// Class ScheduleStatusModel.
    /// </summary>
    public class ScheduleStatusModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string Status { get; set; }

       
    }
}
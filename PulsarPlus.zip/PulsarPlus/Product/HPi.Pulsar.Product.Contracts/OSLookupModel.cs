using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class OSLookupModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int? DisplayOrder { get; set; }

        public string OfficialName { get; set; }

        public string CvaKey { get; set; }

        public string ShortName { get; set; }

        public bool? Active { get; set; }

        public bool? ImagePackage { get; set; }

        public int? OSFamilyId { get; set; }

        public int? OSCount { get; set; }

        public int? DocKitOsId { get; set; }

        public string PinOsCd { get; set; }

        public int? IrsId { get; set; }

        public string IrsName { get; set; }

        public int? IrsProductDropOSId { get; set; }

        public DateTime Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public bool? Components { get; set; }

        public bool? SupplyChain { get; set; }

        public int? InfPathId { get; set; }

        public string OsWeb { get; set; }

        public string OsPin { get; set; }

        public ProductOSModel ProductOS { get; set; }
    }
}
﻿namespace HPi.Pulsar.Product.Contracts
{
    public class AccessoryModel
    {
        public int Id { get; set; }

        public int StatusId { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }

        public string Comments { get; set; }

        public string KitNumber { get; set; }

        public string KitDescription { get; set; }

        public string AccessoryDate { get; set; }

        public int BatchMode { get; set; }
    }
}



namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ServiceSpareKitStatusModel</para>
    /// </summary>
    public class ServiceSpareKitStatusModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Gets or sets the Status.
		/// </summary>
		public string Status { get; set; }


    }
}
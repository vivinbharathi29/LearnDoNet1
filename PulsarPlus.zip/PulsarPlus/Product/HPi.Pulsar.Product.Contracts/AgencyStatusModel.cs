﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AgencyStatusModel
    {
        public int AgencyStatusId { get; set; }

        public string SelectedProducts { get; set; }

        public string SelectedCountries { get; set; }

        public int DeliverableRootId { get; set; }

        public string LastUpdUser { get; set; }

        public string StatusCd { get; set; }

        public DateTime? ProjectedDate { get; set; }

        public DateTime? NewProjectedDate { get; set; }

        public DateTime? ActualDate { get; set; }

        public string CertificationNo { get; set; }

        public int? LeveragedId { get; set; }

        public string Notes { get; set; }

        public int? TestOrganizer { get; set; }

        public int? TestBudget { get; set; }

        public string PORDCR { get; set; }

        public int? DcrId { get; set; }

        public string ProductName { get; set; }

        public string CountryName { get; set; }

        public string AgencyName { get; set; }

        public string LeveragedName { get; set; }

        public string StatusNotes { get; set; }

        public string DeliverableName { get; set; }

        public string MappingNotes { get; set; }

        public int ProductVersionId { get; set; }

        public int? CountryId { get; set; }

        public string AgencyStatusCd { get; set; }

        public string AgencyStatusText { get; set; }

        public DateTime AgencyStatusDate { get; set; }

        public int CurrentAgencyStatusId { get; set; }

        public string CurrentAgencyStatusCd { get; set; }

        public string CheckboxVal { get; set; }

        public DateTime CurrentAgencyStatusDate { get; set; }

        public LanguageModel Language { get; set; }
    }

    public class UpdateAgencyStatusModel
    {
        public string AgencyStatusIds { get; set; }

        public string LastUpdUsers { get; set; }

        public string StatusCds { get; set; }

        public string LeveragedIds { get; set; }

        public string ProjectedDates { get; set; }
    }
}



namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>PowerCordGEOModel</para>
    /// </summary>
    public class PowerCordGEOModel
    {
		/// <summary>
		/// Gets or sets the GEOID.
		/// </summary>
		public int GEOID { get; set; }

		/// <summary>
		/// Gets or sets the GEO.
		/// </summary>
		public string GEO { get; set; }

        /// <summary>
		/// Gets or sets the Supported.
		/// </summary>
		public int Supported { get; set; }

        /// <summary>
		/// Gets or sets the DuckheadPowerCordGEO.
		/// </summary>
		public string DuckheadPowerCordGEO { get; set; }

        /// <summary>
		/// Gets or sets the DuckheadPowerSupported.
		/// </summary>
		public int DuckheadPowerSupported { get; set; }

        /// <summary>
		/// Gets or sets the DuckheadGEO.
		/// </summary>
		public string DuckheadGEO { get; set; }

        /// <summary>
		/// Gets or sets the DuckheadSupported.
		/// </summary>
		public int DuckheadSupported { get; set; }
    }
}
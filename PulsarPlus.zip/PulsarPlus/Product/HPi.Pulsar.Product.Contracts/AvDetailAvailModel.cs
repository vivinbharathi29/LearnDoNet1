using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AvDetailAvailModel
    {
        public int AvDetailId { get; set; }

        public int ProductBrandId { get; set; }

        public int BUFeatureId { get; set; }

        public string Availstatus { get; set; }

        public int ChangeMask { get; set; }

        public DateTime? LastUpdDate { get; set; }

        public string LastUpdUser { get; set; }
    }
}
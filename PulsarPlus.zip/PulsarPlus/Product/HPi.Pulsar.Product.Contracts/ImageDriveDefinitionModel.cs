using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class ImageDriveDefinitionModel
    {
        public int Id { get; set; }

        public string DivCd { get; set; }

        public string SiteCd { get; set; }

        public string DriveName { get; set; }

        public string PartNo { get; set; }

        public string PartNoRev { get; set; }

        public bool? IsAssembly { get; set; }

        public bool? Active { get; set; }

        public string LastUpdUser { get; set; }

        public DateTime LastUpdDate { get; set; }

        public string ShortName { get; set; }
    }
}
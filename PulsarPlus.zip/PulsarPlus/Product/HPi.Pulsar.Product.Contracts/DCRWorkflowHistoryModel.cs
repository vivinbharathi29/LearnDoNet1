using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class DcrWorkflowHistoryModel
    {
        public int Id { get; set; }

        public int? DcrId { get; set; }

        public int? DefinitionId { get; set; }

        public DateTime? MilestoneStartDate { get; set; }

        public DateTime? MilestoneCompleteDate { get; set; }

        public string Comments { get; set; }

        public int? AssignedTo { get; set; }

        public int? CreatedBy { get; set; }

        public string CreateDate { get; set; }

        public bool? Reassign { get; set; }

        public string Status { get; set; }
    }
}
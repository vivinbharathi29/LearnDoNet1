﻿

namespace HPi.Pulsar.Product.Contracts
{
    using System;
    using System.Collections.Generic;
    /// <summary>
    /// Class ProductDeliverableModel
    /// </summary>
    public class ProductDeliverableModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionID.
        /// </summary>
        public int? ProductVersionId { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableVersionID.
        /// </summary>
        public int? DeliverableVersionId { get; set; }

        /// <summary>
        /// Gets or sets the Locked.
        /// </summary>
        public bool Locked { get; set; }

        /// <summary>
        /// Gets or sets the Targeted.
        /// </summary>
        public bool Targeted { get; set; }

        /// <summary>
        /// Gets or sets the AlertID.
        /// </summary>
        public int? AlertId { get; set; }

        /// <summary>
        /// Gets or sets the NewDelVersionID.
        /// </summary>
        public int? NewDelVersionId { get; set; }

        /// <summary>
        /// Gets or sets the Replaced.
        /// </summary>
        public byte? Replaced { get; set; }

        /// <summary>
        /// Gets or sets the TargetNotes.
        /// </summary>
        public string TargetNotes { get; set; }

        /// <summary>
        /// Gets or sets the InImage.
        /// </summary>
        public bool? InImage { get; set; }

        /// <summary>
        /// Gets or sets the PreInstallStatus.
        /// </summary>
        public int? PreInstallStatus { get; set; }

        /// <summary>
        /// Gets or sets the PreInstallOwner.
        /// </summary>
        public string PreInstallOwner { get; set; }

        /// <summary>
        /// Gets or sets the PMAlert.
        /// </summary>
        public int? PMAlert { get; set; }

        /// <summary>
        /// Gets or sets the Preinstall.
        /// </summary>
        public bool? Preinstall { get; set; }

        /// <summary>
        /// Gets or sets the Preload.
        /// </summary>
        public bool? Preload { get; set; }

        /// <summary>
        /// Gets or sets the DropInBox.
        /// </summary>
        public bool? DropInBox { get; set; }

        /// <summary>
        /// Gets or sets the Web.
        /// </summary>
        public bool? Web { get; set; }

        /// <summary>
        /// Gets or sets the BuildNumber.
        /// </summary>
        public string BuildNumber { get; set; }

        /// <summary>
        /// Gets or sets the ImageSummary.
        /// </summary>
        public string ImageSummary { get; set; }

        /// <summary>
        /// Gets or sets the Images.
        /// </summary>
        public string Images { get; set; }

        /// <summary>
        /// Gets or sets the SelectiveRestore.
        /// </summary>
        public bool? SelectiveRestore { get; set; }

        /// <summary>
        /// Gets or sets the ARCD.
        /// </summary>
        public bool? Arcd { get; set; }

        /// <summary>
        /// Gets or sets the InImageDesc.
        /// </summary>
        public string InImageDesc { get; set; }

        /// <summary>
        /// Gets or sets the PreInstallNotesDesc.
        /// </summary>
        public string PreInstallNotesDesc { get; set; }

        /// <summary>
        /// Gets or sets the PreInstallDesc.
        /// </summary>
        public string PreInstallDesc { get; set; }

        /// <summary>
        /// Gets or sets the PreLoadDesc.
        /// </summary>
        public string PreLoadDesc { get; set; }

        /// <summary>
        /// Gets or sets the DIBDesc.
        /// </summary>
        public string DIBDesc { get; set; }

        /// <summary>
        /// Gets or sets the WebDesc.
        /// </summary>
        public string WebDesc { get; set; }

        /// <summary>
        /// Gets or sets the SelectiveRestoreDesc.
        /// </summary>
        public string SelectiveRestoreDesc { get; set; }

        /// <summary>
        /// Gets or sets the ARCDDesc.
        /// </summary>
        public string ARCDDesc { get; set; }

        /// <summary>
        /// Gets or sets the DRDVDDesc.
        /// </summary>
        public string DRDVDDesc { get; set; }

        /// <summary>
        /// Gets or sets the DRCDDesc.
        /// </summary>
        public string DRCDDesc { get; set; }
        

        /// <summary>
        /// Gets or sets the HppiDesc.
        /// </summary>
        public string HppiDesc { get; set; }

        /// <summary>
        /// Gets or sets the RoyaltyBearingDesc.
        /// </summary>
        public string RoyaltyBearingDesc { get; set; }

        /// <summary>
        /// Gets or sets the IconDesktopDesc.
        /// </summary>
        public string IconDesktopDesc { get; set; }

        /// <summary>
        /// Gets or sets the IconPanelDesc.
        /// </summary>
        public string IconPanelDesc { get; set; }

        /// <summary>
        /// Gets or sets the IconInfoCenterDesc.
        /// </summary>
        public string IconInfoCenterDesc { get; set; }

        /// <summary>
        /// Gets or sets the IconInfoCenterDesc.
        /// </summary>
        public string IconTileDesc { get; set; }

        /// <summary>
        /// Gets or sets the IconTaskbarIconDesc.
        /// </summary>
        public string IconTaskbarIconDesc { get; set; }

        /// <summary>
        /// Gets or sets the IconMenuDesc.
        /// </summary>
        public string IconMenuDesc { get; set; }

        /// <summary>
        /// Gets or sets the IconTrayDesc.
        /// </summary>
        public string IconTrayDesc { get; set; }

        /// <summary>
        /// Gets or sets the SWSetupCategoryDesc.
        /// </summary>
        public string SWSetupCategoryDesc { get; set; }

        /// <summary>
        /// Gets or sets the CertRequiredDesc.
        /// </summary>
        public string CertRequiredDesc { get; set; }

        /// <summary>
        /// Gets or sets the RowColorDesc.
        /// </summary>
        public string RowColorDesc { get; set; }

        /// <summary>
        /// Gets or sets the DeveloperApprovalDesc.
        /// </summary>
        public string DeveloperApprovalDesc { get; set; }

        /// <summary>
        /// Gets or sets the InConveyor.
        /// </summary>
        public bool? InConveyor { get; set; }

        /// <summary>
        /// Gets or sets the PartNumber.
        /// </summary>
        public string PartNumber { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallBrand.
        /// </summary>
        public string PreinstallBrand { get; set; }

        /// <summary>
        /// Gets or sets the PreloadBrand.
        /// </summary>
        public string PreloadBrand { get; set; }

        /// <summary>
        /// Gets or sets the DropInBoxBrand.
        /// </summary>
        public string DropInBoxBrand { get; set; }

        /// <summary>
        /// Gets or sets the WebBrand.
        /// </summary>
        public string WebBrand { get; set; }

        /// <summary>
        /// Gets or sets the SelectiveRestoreBrand.
        /// </summary>
        public string SelectiveRestoreBrand { get; set; }

        /// <summary>
        /// Gets or sets the ARCDBrand.
        /// </summary>
        public string ARCDBrand { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallTeam.
        /// </summary>
        public short? PreinstallTeam { get; set; }

        /// <summary>
        /// Gets or sets the Imported.
        /// </summary>
        public bool? Imported { get; set; }

        /// <summary>
        /// Gets or sets the Urgent.
        /// </summary>
        public bool? Urgent { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallNotes.
        /// </summary>
        public string PreinstallNotes { get; set; }

        /// <summary>
        /// Gets or sets the OOCRelease.
        /// </summary>
        public bool? OocRelease { get; set; }

        /// <summary>
        /// Gets or sets the ReleasedImageSummary.
        /// </summary>
        public string ReleasedImageSummary { get; set; }

        /// <summary>
        /// Gets or sets the ReleasedImages.
        /// </summary>
        public string ReleasedImages { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallReassigned.
        /// </summary>
        public DateTime? PreinstallReassigned { get; set; }

        /// <summary>
        /// Gets or sets the StatusUpdatedDate.
        /// </summary>
        public DateTime? StatusUpdatedDate { get; set; }

        /// <summary>
        /// Gets or sets the TestStatusID.
        /// </summary>
        public int? TestStatusId { get; set; }

        /// <summary>
        /// Gets or sets the TestDate.
        /// </summary>
        public DateTime? TestDate { get; set; }

        /// <summary>
        /// Gets or sets the DateAccepted.
        /// </summary>
        public DateTime? DateAccepted { get; set; }

        /// <summary>
        /// Gets or sets the DeveloperNotificationStatus.
        /// </summary>
        public int? DeveloperNotificationStatus { get; set; }

        /// <summary>
        /// Gets or sets the DRDVD.
        /// </summary>
        public bool? DRDVD { get; set; }

        /// <summary>
        /// Gets or sets the RACDEMEA.
        /// </summary>
        public bool? RacdEmea { get; set; }

        /// <summary>
        /// Gets or sets the RACDAPD.
        /// </summary>
        public bool? RacdApd { get; set; }

        /// <summary>
        /// Gets or sets the RACDAmericas.
        /// </summary>
        public bool? RacdAmericas { get; set; }

        /// <summary>
        /// Gets or sets the DocCD.
        /// </summary>
        public bool? DocCD { get; set; }

        /// <summary>
        /// Gets or sets the OSCD.
        /// </summary>
        public bool? OSCD { get; set; }

        /// <summary>
        /// Gets or sets the DIBHWReq.
        /// </summary>
        public string DibhwReq { get; set; }

        /// <summary>
        /// Gets or sets the lead distribution.
        /// </summary>
        /// <value>
        /// The lead distribution.
        /// </value>
        public string LeadDistribution { get; set; }

        /// <summary>
        /// Gets or sets the DCRID.
        /// </summary>
        public int? DcrId { get; set; }

        /// <summary>
        /// Gets or sets the InPinImage.
        /// </summary>
        public bool? InPinImage { get; set; }

        /// <summary>
        /// Gets or sets the DistributionChange.
        /// </summary>
        public string DistributionChange { get; set; }

        /// <summary>
        /// Gets or sets the TestConfidence.
        /// </summary>
        public byte? TestConfidence { get; set; }

        /// <summary>
        /// Gets or sets the SICommodityHistory.
        /// </summary>
        public string SICommodityHistory { get; set; }

        /// <summary>
        /// Gets or sets the Created.
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// Gets or sets the PMAlertSetDt.
        /// </summary>
        public DateTime? PMAlertSetDt { get; set; }

        /// <summary>
        /// Gets or sets the TestStatusIDLastUpdDt.
        /// </summary>
        public DateTime TestStatusIDLastUpdDt { get; set; }

        /// <summary>
        /// Gets or sets the LastUpdDt.
        /// </summary>
        public DateTime? LastUpdDt { get; set; }

        /// <summary>
        /// Gets or sets the PilotStatusID.
        /// </summary>
        public int? PilotStatusId { get; set; }

        /// <summary>
        /// Gets or sets the PilotDate.
        /// </summary>
        public DateTime? PilotDate { get; set; }
        

        /// <summary>
        /// Gets or sets the PilotNotes.
        /// </summary>
        public string PilotNotes { get; set; }

        /// <summary>
        /// Gets or sets the SupplyChainRestriction.
        /// </summary>
        public byte? SupplyChainRestriction { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryStatusID.
        /// </summary>
        public int? AccessoryStatusId { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryLeveraged.
        /// </summary>
        public bool? AccessoryLeveraged { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryNotes.
        /// </summary>
        public string AccessoryNotes { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryDate.
        /// </summary>
        public DateTime? AccessoryDate { get; set; }

        /// <summary>
        /// Gets or sets the DeveloperTestStatus.
        /// </summary>
        public int? DeveloperTestStatus { get; set; }

        /// <summary>
        /// Gets or sets the IntegrationTestStatus.
        /// </summary>
        public int? IntegrationTestStatus { get; set; }

        /// <summary>
        /// Gets or sets the ODMTestStatus.
        /// </summary>
        public int? OdmTestStatus { get; set; }

        /// <summary>
        /// Gets or sets the DeveloperTestStatusDesc.
        /// </summary>
        public string DeveloperTestStatusDesc { get; set; }

        /// <summary>
        /// Gets or sets the IntegrationTestStatusDesc.
        /// </summary>
        public string IntegrationTestStatusDesc { get; set; }

        /// <summary>
        /// Gets or sets the ODMTestStatusDesc.
        /// </summary>
        public string OdmTestStatusDesc { get; set; }

        /// <summary>
        /// Gets or sets the RiskRelease.
        /// </summary>
        public byte? RiskRelease { get; set; }

        /// <summary>
        /// Gets or sets the SyncDistribution.
        /// </summary>
        public bool? SyncDistribution { get; set; }

        /// <summary>
        /// Gets or sets the SyncNotes.
        /// </summary>
        public bool? SyncNotes { get; set; }

        /// <summary>
        /// Gets or sets the SyncImages.
        /// </summary>
        public bool? SyncImages { get; set; }

        /// <summary>
        /// Gets or sets the synchronize comments.
        /// </summary>
        /// <value>
        /// The synchronize comments.
        /// </value>
        public string SyncComments { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallInternalRev.
        /// </summary>
        public int? PreinstallInternalRev { get; set; }

        /// <summary>
        /// Gets or sets the WWANTestStatus.
        /// </summary>
        public int? WwanTestStatus { get; set; }
        /// <summary>
        /// Gets or sets the WwanTestStatusDesc.
        /// </summary>
        public string WwanTestStatusDesc { get; set; }

        /// <summary>
        /// Gets or sets the DeveloperTestNotes.
        /// </summary>
        public string DeveloperTestNotes { get; set; }

        /// <summary>
        /// Gets or sets the IntegrationTestNotes.
        /// </summary>
        public string IntegrationTestNotes { get; set; }

        /// <summary>
        /// Gets or sets the ODMTestNotes.
        /// </summary>
        public string OdmTestNotes { get; set; }

        /// <summary>
        /// Gets or sets the IntegrationUnitsReceived.
        /// </summary>
        public short? IntegrationUnitsReceived { get; set; }

        /// <summary>
        /// Gets or sets the ODMUnitsReceived.
        /// </summary>
        public short? OdmUnitsReceived { get; set; }

        /// <summary>
        /// Gets or sets the WWANUnitsReceived.
        /// </summary>
        public short? WwanUnitsReceived { get; set; }

        /// <summary>
        /// Gets or sets the WWANTestNotes.
        /// </summary>
        public string WwanTestNotes { get; set; }

        /// <summary>
        /// Gets or sets the ODMSamples.
        /// </summary>
        public string ODMSamples { get; set; }
        /// <summary>
        /// Gets or sets the MITSamples.
        /// </summary>
        public string MITSamples { get; set; }

        /// <summary>
        /// Gets or sets the WWANSamples.
        /// </summary>
        public string WWANSamples { get; set; }

        /// <summary>
        /// Gets or sets the DeveloperSignoff.
        /// </summary>
        public bool? DeveloperSignoff { get; set; }

        /// <summary>
        /// Gets or sets the SMRInitiated.
        /// </summary>
        public bool? SmrInitiated { get; set; }

        /// <summary>
        /// Gets or sets the ImagesUpdatedInImage.
        /// </summary>
        public bool? ImagesUpdatedInImage { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallInternalRevSkipped.
        /// </summary>
        public int? PreinstallInternalRevSkipped { get; set; }

        /// <summary>
        /// Gets or sets the MinImageRecovery.
        /// </summary>
        public bool? MinImageRecovery { get; set; }

        /// <summary>
        /// Gets or sets the RTMDate.
        /// </summary>
        public DateTime? RtmDate { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallPnRev.
        /// </summary>
        public int? PreinstallPnRev { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallPnRevTDC.
        /// </summary>
        public int? PreinstallPnRevTdc { get; set; }

        /// <summary>
        /// Gets or sets the ConfigurationRestriction.
        /// </summary>
        public byte? ConfigurationRestriction { get; set; }

        /// <summary>
        /// Gets or sets the RestoreImages.
        /// </summary>
        public string RestoreImages { get; set; }

        /// <summary>
        /// Gets or sets the PINTestInternalRev.
        /// </summary>
        public int? PinTestInternalRev { get; set; }

        /// <summary>
        /// Gets or sets the Patch.
        /// </summary>
        public byte? Patch { get; set; }

        /// <summary>
        /// Gets or sets the DeletemeImageSummaryFusion.
        /// </summary>
        public string DeletemeImageSummaryFusion { get; set; }

        /// <summary>
        /// Gets or sets the DeletemeImagesFusion.
        /// </summary>
        public string DeleteMeImagesFusion { get; set; }

        /// <summary>
        /// Gets or sets the DeletemeRestoreImagesFusion.
        /// </summary>
        public string DeleteMeRestoreImagesFusion { get; set; }

        /// <summary>
        /// Gets or sets the CreatedBy.
        /// </summary>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Updated.
        /// </summary>
        public DateTime Updated { get; set; }

        /// <summary>
        /// Gets or sets the UpdatedBy.
        /// </summary>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Deleted.
        /// </summary>
        public DateTime? Deleted { get; set; }

        /// <summary>
        /// Gets or sets the DeletedBy.
        /// </summary>
        public string DeletedBy { get; set; }

        /// <summary>
        /// Gets or sets the BusinessSegmentId.
        /// </summary>
        /// <value>
        /// The BusinessSegmentId.
        /// </value>
        public int BusinessSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the total no of rows.
        /// </summary>
        /// <value>
        /// The total no of rows.
        /// </value>
        public int TotalNoOfRows { get; set; }

        /// <summary>
        /// Gets or sets dayslate.
        /// </summary>
        /// <value>
        /// The days late.
        /// </value>
        public int DaysLate { get; set; }

        /// <summary>
        /// Gets or sets ProductDeliverableReleaseID.
        /// </summary>
        /// <value>
        /// The ProductDeliverableReleaseID.
        /// </value>
        public int ProductDeliverableReleaseId { get; set; }

        /// <summary>
        /// Gets or sets Release.
        /// </summary>
        /// <value>
        /// The Release.
        /// </value>
        public string Release { get; set; }

        /// <summary>
        /// Gets or sets the release identifier.
        /// </summary>
        /// <value>
        /// The release identifier.
        /// </value>
        public int ReleaseId { get; set; }

        /// <summary>
        /// Gets or sets the previous version count.
        /// </summary>
        /// <value>
        /// The previous version count.
        /// </value>
        public int? PreviousVersionCount { get; set; }

        /// <summary>
        /// Gets or sets the previous vesion part numbers.
        /// </summary>
        /// <value>
        /// The previous vesion part numbers.
        /// </value>
        public string PreviousVersionPartNumbers { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [not in RCD].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [not in RCD]; otherwise, <c>false</c>.
        /// </value>
        public bool? NotInRcd { get; set; }

        /// <summary>
        /// Gets or sets the lead.
        /// </summary>
        /// <value>
        /// The lead.
        /// </value>
        public bool Lead { get; set; }

        /// <summary>
        /// Gets or sets the product ids.
        /// </summary>
        /// <value>
        /// The product ids.
        /// </value>
        public string ProductIds { get; set; }

        /// <summary>
        /// Gets or sets the user information.
        /// </summary>
        /// <value>
        /// The user information.
        /// </value>
        public UserInfoModel UserInfo { get; set; }

        /// <summary>
        /// Gets or sets the product version.
        /// </summary>
        /// <value>
        /// The product version.
        /// </value>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the deliverable root.
        /// </summary>
        /// <value>
        /// The deliverable root.
        /// </value>
        public DeliverableRootModel DeliverableRoot { get; set; }

        /// <summary>
        /// Gets or sets the deliverable version.
        /// </summary>
        /// <value>
        /// The deliverable version.
        /// </value>
        public DeliverableVersionModel DeliverableVersion { get; set; }

        /// <summary>
        /// Gets or sets the TargetDate.
        /// </summary>
        public string TargetDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ProductDeliverableModel"/> is cycle.
        /// </summary>
        /// <value>
        ///   <c>true</c> if cycle; otherwise, <c>false</c>.
        /// </value>
        public bool Cycle { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        public int Type { get; set; }

        /// <summary>
        /// Gets or sets the os list.
        /// </summary>
        /// <value>
        /// The os list.
        /// </value>
        public string OSList { get; set; }

        /// <summary>
        /// Gets or sets the irs transfer status.
        /// </summary>
        /// <value>
        /// The irs transfer status.
        /// </value>
        public IrsTransferStatusModel IrsTransferStatus { get; set; }

        /// <summary>
        /// Gets or sets the TestStatus.
        /// </summary>
        public string TestStatus { get; set; }

        /// <summary>
        /// Gets or sets the VendorModel.
        /// </summary>
        public VendorModel VendorModel { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableRootName.
        /// </summary>
        /// <value>
        /// The DeliverableRootName.
        /// </value>
        public string DeliverableRootName { get; set; }

        /// <summary>
        /// Gets or sets the pilot status.
        /// </summary>
        /// <value>
        /// The pilot status.
        /// </value>
        public PilotStatusModel PilotStatus { get; set; }

        /// <summary>
        /// Gets or sets the test status model.
        /// </summary>
        /// <value>
        /// The test status model.
        /// </value>
        public TestStatusModel TestStatusModel { get; set; }

        /// <summary>
        /// Gets or sets the Email.
        /// </summary>
        /// <value>
        /// The Email.
        /// </value>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the TypeID.
        /// </summary>
        public int? TypeId { get; set; }

        /// <summary>
        /// Gets or sets the PMFieldName.
        /// </summary>
        public string PMFieldName { get; set; }

        /// <summary>
        /// Gets or sets the employee model.
        /// </summary>
        /// <value>
        /// The employee model.
        /// </value>
        public EmployeeModel EmployeeModel { get; set; }

        /// <summary>
        /// Gets or sets the Accessory status model.
        /// </summary>
        /// <value>
        /// The Accessory status model.
        /// </value>
        public AccessoryStatusModel AccessoryStatus { get; set; }

        /// <summary>
        /// Gets or sets the Commodity.
        /// </summary>
        public bool? Commodity { get; set; }

        /// <summary>
        /// ProductId
        /// </summary>
        public int? ProductId { get; set; }
        /// <summary>
        /// Gets or sets the VersionIds.
        /// </summary>
        public string VersionIds { get; set; }
        /// <summary>
        /// Gets or sets the ProductDeliverableIds.
        /// </summary>
        public string ProductDeliverableIds { get; set; }

        /// <summary>
        /// Gets or sets the ProductReleaseIds.
        /// </summary>
        public string ProductReleaseIds { get; set; }

        /// <summary>
        /// Gets or sets the TargetedReleases.
        /// </summary>
        public string TargetedReleases { get; set; }

        /// <summary>
        /// Gets or sets the NoOfReleases.
        /// </summary>
        public int? NoOfReleases { get; set; }

        /// <summary>
        /// Gets or sets the TargetStatus.
        /// </summary>
        public string TargetStatus { get; set; }

        /// <summary>
        /// Gets or sets the TargetStatusTag.
        /// </summary>
        public string TargetStatusTag { get; set; }

        /// <summary>
        /// Gets or sets the product delete root.
        /// </summary>
        /// <value>
        /// The product delete root.
        /// </value>
        public ProductDelRootModel ProductDelRoot { get; set; }

        /// <summary>
        /// Gets or sets the product deliverable release.
        /// </summary>
        /// <value>
        /// The product deliverable release.
        /// </value>
        public ProductDeliverableReleaseModel ProductDeliverableRelease { get; set; }

        /// <summary>
        /// Gets or sets the product delete root release.
        /// </summary>
        /// <value>
        /// The product delete root release.
        /// </value>
        public ProductDelRootReleaseModel ProductDelRootRelease { get; set; }

        /// <summary>
        /// Gets or sets the bridged.
        /// </summary>
        /// <value>
        /// The bridged.
        /// </value>
        public bool Bridged { get; set; }

        /// <summary>
        /// Gets or sets the RCDOnly.
        /// </summary>
        public bool? RcdOnly { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallDev.
        /// </summary>
        public bool? PreinstallDev { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallROM.
        /// </summary>
        public bool? PreinstallRom { get; set; }

        /// <summary>
        /// Gets or sets the AR.
        /// </summary>
        public bool? AR { get; set; }

        /// <summary>
        /// Gets or sets the AR.
        /// </summary>
        public bool? CDImage { get; set; }

        /// <summary>
        /// Gets or sets the ISOImage.
        /// </summary>
        public bool? IsoImage { get; set; }

        /// <summary>
        /// Gets or sets the FloppyDisk.
        /// </summary>
        public bool? FloppyDisk { get; set; }

        /// <summary>
        /// Gets or sets the ScriptPaq.
        /// </summary>
        public bool? ScriptPaq { get; set; }

        /// <summary>
        /// Gets or sets the Softpaq.
        /// </summary>
        public bool? Softpaq { get; set; }

        /// <summary>
        /// Gets or sets the Rompaq.
        /// </summary>
        public bool? Rompaq { get; set; }

        /// <summary>
        /// Gets or sets the rejected.
        /// </summary>
        /// <value>
        /// The rejected.
        /// </value>
        public int Rejected { get; set; }

        /// <summary>
        /// Gets or sets the reset other targets.
        /// </summary>
        /// <value>
        /// The reset other targets.
        /// </value>
        public int ResetOtherTargets { get; set; }


        /// <summary>
        /// Gets or sets the target value.
        /// </summary>
        /// <value>
        /// The target value.
        /// </value>
        public int TargetValue { get; set; }

        /// <summary>
        /// Gets or sets the PINDistributionChange value.
        /// </summary>
        /// <value>
        /// The PINDistributionChange value.
        /// </value>
        public string PinDistributionChange { get; set; }

        /// <summary>
        /// Gets or sets the NoteExists value.
        /// </summary>
        /// <value>
        /// The NoteExists value.
        /// </value>
        public string NoteExists { get; set; }

        /// <summary>
        /// Gets or sets the SCRestrict value.
        /// </summary>
        /// <value>
        /// The SCRestrict value.
        /// </value>
        public string SCRestrict { get; set; }

        /// <summary>
        /// Gets or sets the DisplayImage value.
        /// </summary>
        /// <value>
        /// The DisplayImage value.
        /// </value>
        public string DisplayImage { get; set; }

        /// <summary>
        /// Gets or sets the Image value.
        /// </summary>
        /// <value>
        /// The Image value.
        /// </value>
        public string Image { get; set; }

        /// <summary>
        /// Gets or sets the Distribution value.
        /// </summary>
        /// <value>
        /// The Distribution value.
        /// </value>
        public string Distribution { get; set; }

        /// <summary>
        /// Gets or sets the DisplayImage value.
        /// </summary>
        /// <value>
        /// The DisplayImage value.
        /// </value>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the TestStatusText value.
        /// </summary>
        /// <value>
        /// The TestStatusText value.
        /// </value>
        public string TestStatusText { get; set; }

        /// <summary>
        /// Gets or sets the PilotStatusText value.
        /// </summary>
        /// <value>
        /// The PilotStatusText value.
        /// </value>
        public string PilotStatusText { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryStatusText value.
        /// </summary>
        /// <value>
        /// The AccessoryStatusText value.
        /// </value>
        public string AccessoryStatusText { get; set; }

        /// <summary>
        /// Gets or sets the Target value.
        /// </summary>
        /// <value>
        /// The Target value.
        /// </value>
        public string Target { get; set; }

        /// <summary>
        /// Gets or sets the InternalRev value.
        /// </summary>
        /// <value>
        /// The InternalRev value.
        /// </value>
        public string InternalRev { get; set; }

        /// <summary>
        /// Gets or sets the Notes value.
        /// </summary>
        /// <value>
        /// The Notes value.
        /// </value>
        public string Notes { get; set; }


        /// <summary>
        /// Gets or sets the Notes value.
        /// </summary>
        /// <value>
        /// The Notes value.
        /// </value>
        public string Alerts { get; set; }

        /// <summary>
        /// Gets or sets the LatestVersionFormatted value.
        /// </summary>
        /// <value>
        /// The LatestVersionFormatted value.
        /// </value>
        public string LatestVersionFormatted { get; set; }

        /// <summary>
        /// Gets or sets the VersionCount value.
        /// </summary>
        /// <value>
        /// The VersionCount value.
        /// </value>
        public int VersionCount { get; set; }

        /// <summary>
        /// Gets or sets the RecordCount value.
        /// </summary>
        /// <value>
        /// The RecordCount value.
        /// </value>
        public int RecordCount { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [needs support].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [needs support]; otherwise, <c>false</c>.
        /// </value>
        public bool NeedsSupport { get; set; }

        /// <summary>
        /// Gets or sets the TargetedCount value.
        /// </summary>
        /// <value>
        /// The TargetedCount value.
        /// </value>
        public int TargetedCount { get; set; }

        /// <summary>
        /// Gets or sets the WhqlCount value.
        /// </summary>
        /// <value>
        /// The WhqlCount value.
        /// </value>
        public int WhqlCount { get; set; }

        /// <summary>
        /// Gets or sets the is legacy.
        /// </summary>
        /// <value>
        /// The is legacy.
        /// </value>
        public byte? IsLegacy { get; set; }

        /// <summary>
        /// Gets or sets the OemReadyCount value.
        /// </summary>
        /// <value>
        /// The OemReadyCount value.
        /// </value>
        public int OemReadyCount { get; set; }

        /// <summary>
        /// Gets or sets the NotRequiredCount value.
        /// </summary>
        /// <value>
        /// The NotRequiredCount value.
        /// </value>
        public int NotRequiredCount { get; set; }

        /// <summary>
        /// Gets or sets the ExceptionCount value.
        /// </summary>
        /// <value>
        /// The ExceptionCount value.
        /// </value>
        public int ExceptionCount { get; set; }

        /// <summary>
        /// Revision
        /// </summary>
        public string Revision { get; set; }

        /// <summary>
        /// Pass
        /// </summary>
        public string Pass { get; set; }

        /// <summary>
        /// Gets or sets the OemReadyStatus.
        /// </summary>
        public byte? OemReadyStatus { get; set; }

        /// <summary>
        /// Gets or sets the OemReadyComments.
        /// </summary>
        public string OemReadyComments { get; set; }

        /// <summary>
        /// Gets or sets the OemReadyException.
        /// </summary>
        public string OemReadyException { get; set; }

        /// <summary>
        /// Gets or sets the OemReadyRequired.
        /// </summary>
        public byte OemReadyRequired { get; set; }

        /// <summary>
        /// Gets or sets the CertificationStatus.
        /// </summary>
        public byte? CertificationStatus { get; set; }

        /// <summary>
        /// Gets or sets the CertificationComments.
        /// </summary>
        public string CertificationComments { get; set; }

        /// <summary>
        /// Gets or sets the Certificationrequired.
        /// </summary>
        public byte? Certificationrequired { get; set; }

        /// <summary>
        /// Gets or sets the SupportedProducts.
        /// </summary>
        public string SupportedProducts { get; set; }


        /// <summary>
        /// Gets or sets the product versions.
        /// </summary>
        /// <value>
        /// The product version.
        /// </value>
        public List<ProductVersionModel> ProductVersions { get; set; }


        /// <summary>
        /// Gets or sets the irs component pass identifier.
        /// </summary>
        /// <value>
        /// The irs component pass identifier.
        /// </value>
        public int IRSComponentPassId { get; set; }

        /// <summary>
        /// Gets or sets the name of the deliverable.
        /// </summary>
        /// <value>
        /// The name of the deliverable.
        /// </value>
        public string DeliverableName { get; set; }

        /// <summary>
        /// Gets or sets the SRP.
        /// </summary>
        /// <value>
        /// The SRP.
        /// </value>
        public int SRP { get; set; }

        /// <summary>
        /// Gets or sets the not in RCD.
        /// </summary>
        /// <value>
        /// The not in RCD.
        /// </value>
        public int NotInRCD { get; set; }

        /// <summary>
        /// Gets or sets the in application recovery.
        /// </summary>
        /// <value>
        /// The in application recovery.
        /// </value>
        public int InAppRecovery { get; set; }


        /// <summary>
        /// Gets or sets the dib.
        /// </summary>
        /// <value>
        /// The dib.
        /// </value>
        public int DIB { get; set; }

        /// <summary>
        /// Gets or sets the Program.
        /// </summary>
        public ProgramModel Program { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionRelease.
        /// </summary>
        public ProductVersionReleaseModel ProductVersionRelease { get; set; }

        /// <summary>
        /// Gets or sets the SoftpaqTitle.
        /// </summary>
        public string SoftpaqTitle { get; set; }

        /// <summary>
        /// Gets or sets the SoftpaqSatausXML.
        /// </summary>
        public string SoftpaqSatausXML { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableCategory.
        /// </summary>
        public DeliverableCategoryModel DeliverableCategory { get; set; }

        /// <summary>
        /// Gets or sets the RTM.
        /// </summary>
        public int RTM { get; set; }

        /// <summary>
        /// Gets or sets the SEPM.
        /// </summary>
        public string Sepm { get; set; }

        public byte Bridge { get; set; }

        /// <summary>
        /// Gets or sets the XmlReleaseInfo.
        /// </summary>
        public string XmlReleaseInfo { get; set; }

        /// <summary>
        /// Gets or sets the OemReady.
        /// </summary>
        public string OemReady { get; set; }

        /// <summary>
        /// Gets or sets the Whql.
        /// </summary>
        public string Whql { get; set; }

    }
}
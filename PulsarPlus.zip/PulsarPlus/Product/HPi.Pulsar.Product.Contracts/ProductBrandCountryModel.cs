

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductBrandCountryModel</para>
    /// </summary>
    public class ProductBrandCountryModel
    {
		/// <summary>
		/// Gets or sets the Id.
		/// </summary>
		public int Id { get; set; }

        /// <summary>
		/// Gets or sets the ProductBrandCountryId.
		/// </summary>
		public int? ProductBrandCountryId { get; set; }

        /// <summary>
        /// Gets or sets the ProductBrandId.
        /// </summary>
        public int ProductBrandId { get; set; }

		/// <summary>
		/// Gets or sets the CountryId.
		/// </summary>
		public int CountryId { get; set; }

		/// <summary>
		/// Gets or sets the BusinessId.
		/// </summary>
		public int BusinessId { get; set; }

		/// <summary>
		/// Gets or sets the DcrId.
		/// </summary>
		public int? DcrId { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdDate.
		/// </summary>
		public DateTime LastUpdDate { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdUser.
		/// </summary>
		public string LastUpdUser { get; set; }

        /// <summary>
        /// Gets or sets the PowerCord.
        /// </summary>
        public bool? PowerCord { get; set; }

        /// <summary>
        /// Gets or sets the DuckheadPowerCord.
        /// </summary>
        public bool? DuckheadPowerCord { get; set; }

        /// <summary>
        /// Gets or sets the Duckhead.
        /// </summary>
        public bool? Duckhead { get; set; }

        /// <summary>
        /// Gets or sets the PartnerId.
        /// </summary>
        public int? PartnerId { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersion.
        /// </summary>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the Region.
        /// </summary>
        public RegionModel Region { get; set; }

        /// <summary>
        /// Gets or sets the Language.
        /// </summary>
        public LanguageModel Language { get; set; }

        /// <summary>
		/// Gets or sets the ProductBrandCountryLocalization.
		/// </summary>
		public ProductBrandCountryLocalizationModel ProductBrandCountryLocalization { get; set; }

        /// <summary>
        /// Gets or sets the TotalNoOfRows.
        /// </summary>
        public int TotalNoOfRows { get; set; }

        /// <summary>
        /// Gets or sets the CustomLanguage.
        /// </summary>
        public string CustomLanguage { get; set; }

        /// <summary>
        /// Gets or sets the Country.
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets the RegionName.
        /// </summary>
        public string RegionName { get; set; }

        /// <summary>
        /// Gets or sets the TotalLocalization.
        /// </summary>
        public int TotalLocalization { get; set; }

        /// <summary>
        /// Gets or sets the ReleaseSelected.
        /// </summary>
        public string ReleaseSelected { get; set; }
    }
}
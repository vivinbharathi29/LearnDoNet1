

namespace HPi.Pulsar.Product.Contracts
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// <para>ServiceSpareKitServiceFamilyModel</para>
    /// </summary>
    public class ServiceSpareKitServiceFamilyModel
    {
		/// <summary>
		/// Gets or sets the ServiceFamilyPn.
		/// </summary>
		public string ServiceFamilyPn { get; set; }

		/// <summary>
		/// Gets or sets the SpareKitId.
		/// </summary>
		public int SpareKitId { get; set; }

		/// <summary>
		/// Gets or sets the DeliverableRootId.
		/// </summary>
		public int? DeliverableRootId { get; set; }

		/// <summary>
		/// Gets or sets the Status.
		/// </summary>
		public byte Status { get; set; }

		/// <summary>
		/// Gets or sets the Comments.
		/// </summary>
		public string Comments { get; set; }

		/// <summary>
		/// Gets or sets the Notes.
		/// </summary>
		public string Notes { get; set; }

		/// <summary>
		/// Gets or sets the FirstServiceDt.
		/// </summary>
		public DateTime? FirstServiceDt { get; set; }

		/// <summary>
		/// Gets or sets the ChangeNote.
		/// </summary>
		public string ChangeNote { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdDate.
		/// </summary>
		public DateTime? LastUpdDate { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdUser.
		/// </summary>
		public string LastUpdUser { get; set; }

		/// <summary>
		/// Gets or sets the MfgSubAssembly.
		/// </summary>
		public string MfgSubAssembly { get; set; }

		/// <summary>
		/// Gets or sets the GeoNa.
		/// </summary>
		public bool? GeoNa { get; set; }

		/// <summary>
		/// Gets or sets the GeoLa.
		/// </summary>
		public bool? GeoLa { get; set; }

		/// <summary>
		/// Gets or sets the GeoApj.
		/// </summary>
		public bool? GeoApj { get; set; }

		/// <summary>
		/// Gets or sets the GeoEmea.
		/// </summary>
		public bool? GeoEmea { get; set; }

        /// <summary>
        /// Gets or sets the RowData identifier.
        /// </summary>
        /// <value>
        /// The RowData identifier.
        /// </value>
        public List<Dictionary<string, object>> RowData { get; set; }


    }
}
﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AvPhWebActionTypeModel
    {
        public int PhWebActionTypeId { get; set; }

        public string ActionName { get; set; }

        public bool MarketingRequired { get; set; }

        public bool AutoInput { get; set; }

        public String MarketingInput { get; set; }
    }
}

namespace HPi.Pulsar.Product.Contracts
{
    public class ActionsModel
    {
        public int ActionID { get; set; }

        public string Name { get; set; }

        public bool? Active { get; set; }

        public string ShortName { get; set; }

        public string HeaderName { get; set; }
    }
}
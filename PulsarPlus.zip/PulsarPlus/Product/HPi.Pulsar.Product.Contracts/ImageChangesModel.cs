﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class ImageChangesModel
    {
        public int Id { get; set; }

        public int EmployeeId { get; set; }

        public DateTime? Created { get; set; }

        public string Details { get; set; }

        public int? DcrId { get; set; }

        public int ImageId { get; set; }
    }
}

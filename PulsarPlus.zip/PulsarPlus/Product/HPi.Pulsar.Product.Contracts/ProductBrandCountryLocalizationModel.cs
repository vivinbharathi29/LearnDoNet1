

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductBrandCountryLocalizationModel</para>
    /// </summary>
    public class ProductBrandCountryLocalizationModel
    {
		/// <summary>
		/// Gets or sets the Id.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ProdBrandCountryId.
		/// </summary>
		public int ProdBrandCountryId { get; set; }

		/// <summary>
		/// Gets or sets the LocalizationId.
		/// </summary>
		public int LocalizationId { get; set; }

		/// <summary>
		/// Gets or sets the Keyboard.
		/// </summary>
		public string Keyboard { get; set; }

		/// <summary>
		/// Gets or sets the KWL.
		/// </summary>
		public string KWL { get; set; }

		/// <summary>
		/// Gets or sets the PowerCord.
		/// </summary>
		public string PowerCord { get; set; }

		/// <summary>
		/// Gets or sets the DocKits.
		/// </summary>
		public string DocKits { get; set; }

		/// <summary>
		/// Gets or sets the RestoreMedia.
		/// </summary>
		public string RestoreMedia { get; set; }

		/// <summary>
		/// Gets or sets the DcrId.
		/// </summary>
		public int? DcrId { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdDate.
		/// </summary>
		public DateTime LastUpdDate { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdUser.
		/// </summary>
		public string LastUpdUser { get; set; }

        /// <summary>
		/// Gets or sets the CustomLocalization.
		/// </summary>
		public string CustomLocalization { get; set; }

        /// <summary>
		/// Gets or sets the OptionConfig.
		/// </summary>
		public string OptionConfig { get; set; }

        /// <summary>
        /// Gets or sets the Dash.
        /// </summary>
        public string Dash { get; set; }

        /// <summary>
        /// Gets or sets the CountryRegion.
        /// </summary>
        public string CountryRegion { get; set; }


        /// <summary>
        /// Gets or sets the Brand.
        /// </summary>
        public string Brand { get; set; }

        /// <summary>
        /// Gets or sets the CountriesList.
        /// </summary>
        public string CountriesList { get; set; }

        /// <summary>
        /// Gets or sets the TotalNoOfRows.
        /// </summary>
        public int TotalNoOfRows { get; set; }

        /// <summary>
		/// Gets or sets the ProductBrandCountryLocalizationRelease.
		/// </summary>
		public ProductBrandCountryLocalizationReleaseModel ProductBrandCountryLocalizationRelease { get; set; }
    }
}


namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProgramModel</para>
    /// </summary>
    public class ProgramModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the Active.
		/// </summary>
		public byte? Active { get; set; }

		/// <summary>
		/// Gets or sets the OrderID.
		/// </summary>
		public int? OrderId { get; set; }

		/// <summary>
		/// Gets or sets the CurrentProgram.
		/// </summary>
		public bool? CurrentProgram { get; set; }

		/// <summary>
		/// Gets or sets the BusinessID.
		/// </summary>
		public int? BusinessId { get; set; }

		/// <summary>
		/// Gets or sets the OTSCycleName.
		/// </summary>
		public string OtsCycleName { get; set; }

		/// <summary>
		/// Gets or sets the IconRuleID.
		/// </summary>
		public int? IconRuleId { get; set; }

		/// <summary>
		/// Gets or sets the FullName.
		/// </summary>
		public string FullName { get; set; }

		/// <summary>
		/// Gets or sets the ProgramGroupID.
		/// </summary>
		public int? ProgramGroupId { get; set; }

        /// <summary>
		/// Gets or sets the ProgramGroup.
		/// </summary>
		public string ProgramGroup { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersion.
        /// </summary>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the ProductProgram.
        /// </summary>
        public ProductProgramModel ProductProgram { get; set; }

        /// <summary>
        /// Gets or sets the program groups.
        /// </summary>
        /// <value>
        /// The program groups.
        /// </value>
        public ProgramGroupModel ProgramGroups { get; set; }
    }
}


namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class SchedulePhaseModel.
    /// </summary>
    public class SchedulePhaseModel
    {
        /// <summary>
        /// Gets or sets the Schedulephaseid.
        /// </summary>
        /// <value>
        /// The schedulephase identifier.
        /// </value>
        public int SchedulePhaseId { get; set; }

        /// <summary>
        /// Gets or sets the Phasename.
        /// </summary>
        /// <value>
        /// The phasename.
        /// </value>
        public string PhaseName { get; set; }

        /// <summary>
        /// Gets or sets the Sortorder.
        /// </summary>
        /// <value>
        /// The sortorder.
        /// </value>
        public int? SortOrder { get; set; }

        /// <summary>
        /// Gets or sets the Activeyn.
        /// </summary>
        /// <value>
        /// The activeyn.
        /// </value>
        public string ActiveYN { get; set; }

        /// <summary>
        /// Gets or sets the Lastupduser.
        /// </summary>
        /// <value>
        /// The lastupduser.
        /// </value>
        public string LastUpdUser { get; set; }

        /// <summary>
        /// Gets or sets the Lastupddate.
        /// </summary>
        /// <value>
        /// The lastupddate.
        /// </value>
        public DateTime LastUpdDate { get; set; }
    }
}
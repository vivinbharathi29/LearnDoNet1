﻿

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class ProductLineModel.
    /// </summary>
    public class ProductLineModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the Division.
        /// </summary>
        /// <value>
        /// The division.
        /// </value>
        public int? Division { get; set; }

        /// <summary>
        /// Gets or sets the BusinessId.
        /// </summary>
        /// <value>
        /// The business identifier.
        /// </value>
        public int? BusinessId { get; set; }

        /// <summary>
        /// Gets or sets the BrandID.
        /// </summary>
        /// <value>
        /// The brand identifier.
        /// </value>
        public int? BrandId { get; set; }

        /// <summary>
        /// Gets or sets the BusinessSegmentID.
        /// </summary>
        /// <value>
        /// The business segment identifier.
        /// </value>
        public int? BusinessSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the Created.
        /// </summary>
        /// <value>
        /// The created.
        /// </value>
        public DateTime? Created { get; set; }

        /// <summary>
        /// Gets or sets the CreatedBy.
        /// </summary>
        /// <value>
        /// The created by.
        /// </value>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Updated.
        /// </summary>
        /// <value>
        /// The updated.
        /// </value>
        public DateTime? Updated { get; set; }

        /// <summary>
        /// Gets or sets the UpdatedBy.
        /// </summary>
        /// <value>
        /// The updated by.
        /// </value>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Disabled.
        /// </summary>
        /// <value>
        /// The disabled.
        /// </value>
        public DateTime? Disabled { get; set; }

        /// <summary>
        /// Gets or sets the DisabledBy.
        /// </summary>
        /// <value>
        /// The disabled by.
        /// </value>
        public string DisabledBy { get; set; }

        /// <summary>
        /// Gets or sets the ProductLineId.
        /// </summary>
        /// <value>
        /// The product line identifier.
        /// </value>
        public int ProductLineId { get; set; }

        /// <summary>
        /// Gets or sets the ShortName.
        /// </summary>
        /// <value>
        /// The short name.
        /// </value>
        public string ShortName { get; set; }

        /// <summary>
        /// Gets or sets the AvDetail.
        /// </summary>
        /// <value>
        /// The av detail.
        /// </value>
        public AVDetailModel AvDetail { get; set; }

        /// <summary>
        /// Gets or sets the PHWebProductPin.
        /// </summary>
        //public PHWebProductPinModel PHWebProductPin { get; set; }
    }
}
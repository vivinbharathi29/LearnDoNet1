﻿using System.Collections.Generic;

namespace HPi.Pulsar.Product.Contracts
{
    public class AgencyModel
    {
        public List<Dictionary<string,string>> ColumnData { get; set; }

        public List<Dictionary<string, object>> RowData { get; set; }
    }
}

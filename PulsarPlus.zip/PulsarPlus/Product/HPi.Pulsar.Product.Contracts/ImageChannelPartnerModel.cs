namespace HPi.Pulsar.Product.Contracts
{
    public class ImageChannelPartnerModel
    {
        public int ImageDefinitionId { get; set; }

		public int RegionId { get; set; }

		public int PartnerId { get; set; }

		public int Tier { get; set; }

       public int CopiedImageDefinitionId { get; set; }
    }
}
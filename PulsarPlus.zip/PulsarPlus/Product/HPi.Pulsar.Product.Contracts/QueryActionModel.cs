

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class QueryActionModel.
    /// </summary>
    public class QueryActionModel
    {
        public int Id { get; set; }
        public string ProductIDs { get; set; }
        public string ProductPulsarIDs { get; set; }
        public string ProductVersionIDs { get; set; }
        public string ProductReleaseIDs { get; set; }
        public string CycleIds { get; set; }
        public string ApproverIDs { get; set; }
        public string OwnerIDs { get; set; }
        public string SubmitterNames { get; set; }
        public string StatusIDs { get; set; }
        public string TypeIDs { get; set; }
        public int CategoryId { get; set; }
        public int Ecn { get; set; }
        public string Summary { get; set; }
        public string PartnerIds { get; set; }
        public string Devcenters { get; set; }
        public string ProductStatusIds { get; set; }
        public string ProgramIds { get; set; }
        public string Search { get; set; }
        public string SummarySearch { get; set; }
        public string Numbers { get; set; }
        public string DcrCategory { get; set; }
        public string DateCreatedStart { get; set; }
        public string DateCreatedEnd { get; set; }
        public string ActualDateStart { get; set; }
        public string ActualDateEnd { get; set; }
        public string TargetDateStart { get; set; }
        public string TargetDateEnd { get; set; }
        public string IncludeActions { get; set; }
        public string IncludeApprovers { get; set; }
        public string IncludeDescription { get; set; }
        public string IncludeJustification { get; set; }
        public string IncludeResolution { get; set; }
        public string Sort1Column { get; set; }
        public string Sort2Column { get; set; }
        public string Sort3Column { get; set; }
        public string Sort1Direction { get; set; }
        public string Sort2Direction { get; set; }
        public string Sort3Direction { get; set; }
        public string PulsarProdCondition { get; set; }
        public string ActionSearchChk { get; set; }
        public string DescriptionSearchChk { get; set; }
        public string ApproverCommentsChk { get; set; }
        public string SummarySearchChk { get; set; }
        public string DaysOpen { get; set; }
        public string DaysClosed { get; set; }
        public string DaysTarget { get; set; }
        public string PulsarprodCondition { get; set; }
        public string ApproverStatus { get; set; }
        public string ApproverComments { get; set; }
        public string DaysOpenCompare { get; set; }
        public string DaysTargetCompare { get; set; }
        public string DaysClosedCompare { get; set; }
        public string Function { get; set; }

        public string BusinessSegmentIds { get; set; }

        public string ProductLineIds { get; set; }
    }
}
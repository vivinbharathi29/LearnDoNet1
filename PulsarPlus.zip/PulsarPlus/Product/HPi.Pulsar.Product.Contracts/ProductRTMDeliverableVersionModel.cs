﻿

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    public class ProductRTMDeliverableVersionModel
    {
        /// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

        /// <summary>
		/// Gets or sets the ProductRtmId.
		/// </summary>
		public int ProductRtmId { get; set; }

        /// <summary>
		/// Gets or sets the DeliverableVersionID.
		/// </summary>
		public int DeliverableVersionID { get; set; }

        /// <summary>
		/// Gets or sets the TypeID.
		/// </summary>
		public int? TypeID { get; set; }

        /// <summary>
		/// Gets or sets the Details.
		/// </summary>
		public string Details { get; set; }
    }
}

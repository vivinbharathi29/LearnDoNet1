

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>SCMAvMRDatesModel</para>
    /// </summary>
    public class ScmAVMRDatesModel
    {
		/// <summary>
		/// Gets or sets the SCMID.
		/// </summary>
		public int ScmId { get; set; }

		/// <summary>
		/// Gets or sets the AvDetailID.
		/// </summary>
		public int AVDetailId { get; set; }

		/// <summary>
		/// Gets or sets the ProductBrandID.
		/// </summary>
		public int ProductBrandId { get; set; }

		/// <summary>
		/// Gets or sets the OptionConfig.
		/// </summary>
		public string OptionConfig { get; set; }

		/// <summary>
		/// Gets or sets the ReadyDate.
		/// </summary>
		public DateTime? ReadyDate { get; set; }


    }
}
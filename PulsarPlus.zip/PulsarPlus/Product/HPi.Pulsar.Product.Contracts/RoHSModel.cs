﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts
{
    public class RoHSModel
    {

        /// <summary>
        /// The Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The Displayorder
        /// </summary>
        public int? Displayorder { get; set; }

        /// <summary>
        /// The Active
        /// </summary>
        public bool? Active { get; set; }
    }
}

﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class DeliverableLevelModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int? TypeId { get; set; }

        public int? OrderId { get; set; }

        public DateTime Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }
    }
}
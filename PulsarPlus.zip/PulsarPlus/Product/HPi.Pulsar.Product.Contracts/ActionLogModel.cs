using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class ActionLogModel
    {
        public int Id { get; set; }

        public int ActionId { get; set; }

        public string UserName { get; set; }

        public DateTime Updated { get; set; }

        public int? ProductVersionId { get; set; }

        public int? DeliverableVersionId { get; set; }

        public int? DeliverableRootId { get; set; }

        public string Details { get; set; }

        public int? UserId { get; set; }

        public int? FromId { get; set; }

        public string FromInfo { get; set; }

        public int? ToId { get; set; }

        public string ToInfo { get; set; }

        public bool? Reported { get; set; }

        public int? ProductVersionReleaseId { get; set; }

        public string LogIds { get; set; }

        public string LogMessage { get; set; }
    }
}
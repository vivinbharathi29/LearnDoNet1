using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class BrandModel
    {
        public string CombinedName { get; set; }

        public bool IsValue { get; set; }

        public string DisplayName { get; set; }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Abbreviation { get; set; }

        public int? DisplayOrder { get; set; }

        public bool Active { get; set; }

        public DateTime? Created { get; set; }

        public string BGColor { get; set; }

        public string StreetName { get; set; }

        public int? BusinessId { get; set; }

        public string Suffix { get; set; }

        public string StreetName2 { get; set; }

        public string RasSegment { get; set; }

        public string StreetName3 { get; set; }

        public bool? ConfigurableAV { get; set; }

        public bool? ShowSeriesNumberInLogoBadge { get; set; }

        public bool? ShowSeriesNumberInBrandName { get; set; }

        public bool? SplitSeriesForLogoAndBrand { get; set; }

        public bool? ShowSeriesNumberInShortName { get; set; }

        public byte? Division { get; set; }

        public string CreatedBy { get; set; }

        public DateTime Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Disabled { get; set; }

        public string DisabledBy { get; set; }

        public int? BusinessSegmentId { get; set; }

        public bool? PowerCord { get; set; }

        public bool? DuckheadPowerCord { get; set; }

        public bool? Duckhead { get; set; }

        public int BranId { get; set; }

        public string Product { get; set; }

        public ProductBrandModel ProductBrand { get; set; }

        public ProductVersionModel ProductVersion { get; set; }

        public ProductFamilyModel ProductFamily { get; set; }

        public PartnerModel Partner { get; set; }

        public ProductBrandCountryModel ProductBrandCountry { get; set; }

        public string BId { get; set; }

        public int TotalNoOfRows { get; set; }
    }
}
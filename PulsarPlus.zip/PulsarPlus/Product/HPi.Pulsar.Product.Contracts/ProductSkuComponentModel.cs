﻿

namespace HPi.Pulsar.Product.Contracts
{
    /// <summary>
    /// Class ProductSkuComponentModel.
    /// </summary>
    public class ProductSkuComponentModel
    {
        /// <summary>
        /// Gets or sets the cpu av pn.
        /// </summary>
        /// <value>The cpu av pn.</value>
        public string CpuAvPN { get; set; }

        /// <summary>
        /// Gets or sets the base unit av pn.
        /// </summary>
        /// <value>The base unit av pn.</value>
        public string BaseUnitAvPN { get; set; }

        /// <summary>
        /// Gets or sets the image pn.
        /// </summary>
        /// <value>The image pn.</value>
        public string ImagePN { get; set; }
    }
}
﻿using System.Collections.Generic;

namespace HPi.Pulsar.Product.Contracts
{
    public class LinkProductModel
    {
        public int ProductId { get; set; }

        public int DeliverableId { get; set; }

        public int FieldId { get; set; }

        public int ProductVersionReleaseId { get; set; }

        public string UserName { get; set; }

        public int UserId { get; set; }

        public int ProductVersionId { get; set; }

        public int DeliverableRootId { get; set; }

        public bool IsPreinstall { get; set; }

        public bool IsPreload { get; set; }

        public bool IsDropInBox { get; set; }

        public bool IsWeb { get; set; }

        public int Patch { get; set; }

        public int RequirementId { get; set; }

        public int PDId { get; set; }

        public int PdrId { get; set; }

        public string Pdr { get; set; }

        public string Pd { get; set; }

        public int StatusId { get; set; }

        public string DeveloperTestNotes { get; set; }

        public int Type { get; set; }

        public string TypeDetails { get; set; }

        public int ProductDeliverableReleaseId { get; set; }

        public int? VersionId { get; set; }

        public string Section { get; set; }

        public bool IsRootAdded { get; set; }

        public IList<string> SupportedVersions { get; set; }

        public IList<string> LoadedVersions { get; set; }

        public IList<ProductDeliverableDetails> ProductDeliverableDetails { get; set; }
    }

    public class ProductDeliverableDetails
    {
        public int VersionId { get; set; }

        public int ProductDeliverableReleaseId { get; set; }
    }
}

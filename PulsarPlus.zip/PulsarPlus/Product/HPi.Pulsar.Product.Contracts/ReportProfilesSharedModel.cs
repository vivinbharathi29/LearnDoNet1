

namespace HPi.Pulsar.Product.Contracts
{
    /// <summary>
    /// <para>ReportProfilesSharedModel</para>
    /// </summary>
    public class ReportProfileSharedModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ReportProfileID.
		/// </summary>
		public int ReportProfileId { get; set; }

		/// <summary>
		/// Gets or sets the EmployeeID.
		/// </summary>
		public int EmployeeId { get; set; }

		/// <summary>
		/// Gets or sets the CanEdit.
		/// </summary>
		public bool CanEdit { get; set; }

		/// <summary>
		/// Gets or sets the CanDelete.
		/// </summary>
		public bool CanDelete { get; set; }

		/// <summary>
		/// Gets or sets the GroupID.
		/// </summary>
		public int? GroupId { get; set; }

        /// <summary>
		/// Gets or sets the PrimaryOwner.
		/// </summary>
		public string PrimaryOwner { get; set; }

        /// <summary>
		/// Gets or sets the ProfileName.
		/// </summary>
		public string ProfileName { get; set; }

        /// <summary>
		/// Gets or sets the SharingID.
		/// </summary>
		public int SharingId { get; set; }

        /// <summary>
		/// Gets or sets the Action.
		/// </summary>
		public int Action { get; set; }

        /// <summary>
		/// Gets or sets the AddType.
		/// </summary>
		public int? AddType { get; set; }

        /// <summary>
        /// Gets or sets the EditPermission.
        /// </summary>
        public bool EditPermission { get; set; }

        /// <summary>
        /// Gets or sets the DeletePermission.
        /// </summary>
        public bool DeletePermission { get; set; }
    }
}
using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class ImageDefinitionModel
    {
        public int Id { get; set; }

        public string SkuNumber { get; set; }

        public string OS { get; set; }

        public string Status { get; set; }

        public string ProductDrop { get; set; }

        public string Brand { get; set; }

        public string SWType { get; set; }

        public string ReleaseName { get; set; }

        public int BrandId { get; set; }

        public int ImageCount { get; set; }

        public int? OSId { get; set; }

        public int SWId { get; set; }

        public string ImageType { get; set; }

        public DateTime? Created { get; set; }

        public int? ProductVersionId { get; set; }

        public DateTime? Modified { get; set; }

        public bool? Active { get; set; }

        public int? OobeId { get; set; }

        public byte? StatusId { get; set; }

        public DateTime? RtmDate { get; set; }

        public int? CopyId { get; set; }

        public string Comments { get; set; }

        public string ImageChange { get; set; }

        public string RegionChange { get; set; }

        public bool? ImageSnapshotsSaved { get; set; }

        public int? ImageDriveDefinitionId { get; set; }

        public DateTime? EolDate { get; set; }

        public int? ImageTypeId { get; set; }

        public int? ProductDropId { get; set; }

        public int? FeatureId { get; set; }

        public int? ProductVersionReleaseId { get; set; }

        public int? SKUCount { get; set; }

        public string BrandSummary { get; set; }

        public int RecordCount { get; set; }

        public string FullSkuNumber { get; set; }

        public string DisplayName { get; set; }

        public int ImageId { get; set; }

        public string OptionConfig { get; set; }

        public string Priority { get; set; }

        public ImageModel ImagesDetails { get; set; }

        public DeliverableVersionModel DeliverableVersion { get; set; }

        public DeliverableRootModel DeliverableRoot { get; set; }

        public ComponentsModel Components { get; set; }

        public ProductDeliverableModel ProductDeliverable { get; set; }

        public int? ProductId { get; set; }

        public int? CompareType { get; set; }

        public int? IncludeIrs { get; set; }

        public string PartNumber { get; set; }

        public string Version { get; set; }

        public string Revision { get; set; }

        public string Pass { get; set; }

        public string OSReleaseName { get; set; }

        public string DllName { get; set; }

        public string RTM { get; set; }

        public int? ImageStatusId { get; set; }

        public string ImageCycle { get; set; }

        public string OSLanguage { get; set; }

        public string OtherLanguage { get; set; }

        public int TotalNoOfRows { get; set; }

        public RegionModel Region { get; set; }

        public BrandModel ProductBrand { get; set; }

        public OSLookupModel OSLookup { get; set; }

        public ImageSwTypeModel ImageSwType { get; set; }

        public ProductVersionProductDropModel ProductVersionProductDrop { get; set; }

        public ImageModel Image { get; set; }

        public ImageStatusModel ImageStatus { get; set; }

        public ImageDriveDefinitionModel ImageDriveDefinition { get; set; }

        public ExCopJobModel ExCopJob { get; set; }

        public ExCopJobStatusModel ExCopJobStatus { get; set; }

        public int CopiedImageDefinitionId { get; set; }

        public string FromEmail { get; set; }

        public int RegionId { get; set; }

        public int OSFeatureExists { get; set; }

        public string UserName { get; set; }

        public int UserId { get; set; }

        public int dcrId { get; set; }

        public string ChangeLog { get; set; }

        public int? OSReleaseId { get; set; }

        public ProductDrop1Model ProductDropOne { get; set; }

        public int AlreadyInProduct { get; set; }

        public int ImportLocalizations { get; set; }

        public int SourceProductId { get; set; }

        public int? ReleaseId { get; set; }

        public ProductDrop1Model ProductDrop1 { get; set; }

        public FeatureModel Feature { get; set; }

        public ProductVersionReleaseModel ProductVersionRelease { get; set; }

        public int IsSelectable { get; set; }

        public string RowKey { get; set; }

        public int UsedInPrl { get; set; }
    }
}


namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ServiceSpareKitModel</para>
    /// </summary>
    public class ServiceSpareKitModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Gets or sets the SpareKitNo.
		/// </summary>
		public string SpareKitNo { get; set; }

		/// <summary>
		/// Gets or sets the Description.
		/// </summary>
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets the SpareCategoryId.
		/// </summary>
		public int SpareCategoryId { get; set; }

		/// <summary>
		/// Gets or sets the CsrLevelId.
		/// </summary>
		public int? CsrLevelId { get; set; }

		/// <summary>
		/// Gets or sets the Disposition.
		/// </summary>
		public int? Disposition { get; set; }

		/// <summary>
		/// Gets or sets the WarrantyTier.
		/// </summary>
		public string WarrantyTier { get; set; }

		/// <summary>
		/// Gets or sets the LocalStockAdvice.
		/// </summary>
		public int? LocalStockAdvice { get; set; }

		/// <summary>
		/// Gets or sets the PpcProductLine.
		/// </summary>
		public string PpcProductLine { get; set; }

		/// <summary>
		/// Gets or sets the GeoNa.
		/// </summary>
		public bool? GeoNa { get; set; }

		/// <summary>
		/// Gets or sets the GeoLa.
		/// </summary>
		public bool? GeoLa { get; set; }

		/// <summary>
		/// Gets or sets the GeoApj.
		/// </summary>
		public bool? GeoApj { get; set; }

		/// <summary>
		/// Gets or sets the GeoEmea.
		/// </summary>
		public bool? GeoEmea { get; set; }

		/// <summary>
		/// Gets or sets the Revision.
		/// </summary>
		public string Revision { get; set; }

		/// <summary>
		/// Gets or sets the CrossPlantStatus.
		/// </summary>
		public string CrossPlantStatus { get; set; }

		/// <summary>
		/// Gets or sets the MfgSubAssembly.
		/// </summary>
		public string MfgSubAssembly { get; set; }

		/// <summary>
		/// Gets or sets the SvcSubAssembly.
		/// </summary>
		public string SvcSubAssembly { get; set; }

		/// <summary>
		/// Gets or sets the PPC.
		/// </summary>
		public bool PPC { get; set; }

		/// <summary>
		/// Gets or sets the GPG.
		/// </summary>
		public bool GPG { get; set; }

		/// <summary>
		/// Gets or sets the ChangeNote.
		/// </summary>
		public string ChangeNote { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdUser.
		/// </summary>
		public string LastUpdUser { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdDate.
		/// </summary>
		public DateTime? LastUpdDate { get; set; }

		/// <summary>
		/// Gets or sets the ProjectCd.
		/// </summary>
		public string ProjectCd { get; set; }

		/// <summary>
		/// Gets or sets the PpcCsrLevelSet.
		/// </summary>
		public bool PpcCsrLevelSet { get; set; }

        /// <summary>
        /// Gets or sets the av qualifiers.
        /// </summary>
        /// <value>
        /// The av qualifiers.
        /// </value>
        public string AvQualifiers { get; set; }

        /// <summary>
        /// Gets or sets the service spare category.
        /// </summary>
        /// <value>
        /// The service spare category.
        /// </value>
        public ServiceSpareCategoryModel ServiceSpareCategory { get; set; }

        /// <summary>
        /// Gets or sets the product version.
        /// </summary>
        /// <value>
        /// The product version.
        /// </value>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the service spare kit service family.
        /// </summary>
        /// <value>
        /// The service spare kit service family.
        /// </value>
        public ServiceSpareKitServiceFamilyModel ServiceSpareKitServiceFamily { get; set; }


    }
}
using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class FeatureRootModel
    {
        public int FeatureId { get; set; }

        public int ComponentRootId { get; set; }

        public string WhyRejected { get; set; }

        public int RequesterId { get; set; }

        public DateTime? RequestDate { get; set; }

        public int? RejectedByUserId { get; set; }

        public DateTime? RejectedDate { get; set; }
    }
}
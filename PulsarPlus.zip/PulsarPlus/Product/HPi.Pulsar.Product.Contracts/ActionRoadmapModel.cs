namespace HPi.Pulsar.Product.Contracts
{
    public class ActionRoadmapModel
    {
        public int Id { get; set; }

        public int ProductVersionId { get; set; }

        public int? OwnerId { get; set; }

        public string Summary { get; set; }

        public string TimeFrame { get; set; }

        public string TimeFrameNotes { get; set; }

        public int? DisplayOrder { get; set; }

        public string Notes { get; set; }

        public int? ActionStatusId { get; set; }

        public string Requirements { get; set; }

        public string Details { get; set; }

        public bool? StatusReport { get; set; }

        public string OriginalTimeFrame { get; set; }

        public ActionStatusModel ActionRoadMapStatus { get; set; }

        public EmployeeModel ActionRoadMapEmployee { get; set; }

        public int? DeliverableIssueId { get; set; }

        public int TaskCount { get; set; }

        public int CompleteCount { get; set; }

        public string Priority { get; set; }
    }
}
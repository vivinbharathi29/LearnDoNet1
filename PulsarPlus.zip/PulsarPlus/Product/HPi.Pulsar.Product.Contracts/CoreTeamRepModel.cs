namespace HPi.Pulsar.Product.Contracts
{
    public class CoreTeamRepModel
    {
        public int ID { get; set; }

        public string Name { get; set; }
    }
}
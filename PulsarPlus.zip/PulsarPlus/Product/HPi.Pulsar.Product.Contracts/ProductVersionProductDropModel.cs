

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductVersionProductDropModel</para>
    /// </summary>
    public class ProductVersionProductDropModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ProductVersionID.
		/// </summary>
		public int ProductVersionId { get; set; }

		/// <summary>
		/// Gets or sets the ProductDropID.
		/// </summary>
		public int ProductDropId { get; set; }

        /// <summary>
        /// Gets or sets the product version.
        /// </summary>
        /// <value>
        /// The product version.
        /// </value>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the image definitions.
        /// </summary>
        /// <value>
        /// The image definitions.
        /// </value>
        public ImageDefinitionModel ImageDefinitions { get; set; }

    }
}
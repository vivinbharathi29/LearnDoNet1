

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductFamilyModel</para>
    /// </summary>
    public class ProductFamilyModel
    {
		/// <summary>
		/// Gets or sets the Id.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the Active.
		/// </summary>
		public byte? Active { get; set; }

		/// <summary>
		/// Gets or sets the Created.
		/// </summary>
		public DateTime Created { get; set; }

		/// <summary>
		/// Gets or sets the CreatedBy.
		/// </summary>
		public string CreatedBy { get; set; }

		/// <summary>
		/// Gets or sets the Updated.
		/// </summary>
		public DateTime Updated { get; set; }

		/// <summary>
		/// Gets or sets the UpdatedBy.
		/// </summary>
		public string UpdatedBy { get; set; }

		/// <summary>
		/// Gets or sets the Deleted.
		/// </summary>
		public DateTime? Deleted { get; set; }

		/// <summary>
		/// Gets or sets the DeletedBy.
		/// </summary>
		public string DeletedBy { get; set; }

		/// <summary>
		/// Gets or sets the ProductFamilyId.
		/// </summary>
		public int ProductFamilyId { get; set; }

		/// <summary>
		/// Gets or sets the Disabled.
		/// </summary>
		public DateTime? Disabled { get; set; }

		/// <summary>
		/// Gets or sets the DisabledBy.
		/// </summary>
		public string DisabledBy { get; set; }

		/// <summary>
		/// Gets or sets the ProductVersion.
		/// </summary>
		public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionName.
        /// </summary>
        public string ProductVersionName { get; set; }
    }
}
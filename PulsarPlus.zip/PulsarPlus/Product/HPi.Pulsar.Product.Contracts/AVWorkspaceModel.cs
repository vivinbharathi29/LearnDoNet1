namespace HPi.Pulsar.Product.Contracts
{
    public class AVWorkspaceModel
    {
        public int AVWSId { get; set; }

        public int WSId { get; set; }

        public int ScmId { get; set; }

        public int PBId { get; set; }

        public int AVDetailId { get; set; }

        public int? ScmCategoryId { get; set; }

        public bool IsCurrentIORemoveOverrided { get; set; }

        public bool IsCurrentIOAddOverrided { get; set; }

        public int Flag { get; set; }
    }
}
using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class ImageModel
    {
		public int Id { get; set; }

		public int ImageDefinitionId { get; set; }

		public string Priority { get; set; }

		public int RegionId { get; set; }

		public DateTime? Modified { get; set; }

		public DateTime? FcsDate { get; set; }

		public DateTime? FcsActual { get; set; }

		public string FaiSku { get; set; }

		public string Comments { get; set; }

		public int? CopyId { get; set; }

		public string SkuNumber { get; set; }

		public string LockedDeliverableList { get; set; }

		public bool SigVerifyComplete { get; set; }

		public bool CheckLogo6Complete { get; set; }

		public bool WmiComplete { get; set; }

		public string LeveragedImage { get; set; }

		public string MuiLanguages { get; set; }

		public DateTime? RtmDate { get; set; }

		public int? ImageDriveDefinitionId { get; set; }

		public int? Revision { get; set; }

		public bool? Published { get; set; }

		public int? ImageSetId { get; set; }

		public int? Tier { get; set; }

		public string OSLip { get; set; }

		public bool? Rcto { get; set; }

		public DateTime? ProposedRtm { get; set; }

		public int? RtmRev { get; set; }

		public int? NewOrReplace { get; set; }

		public int? RecoveryMethod { get; set; }

		public long? ImageSize { get; set; }

		public string MD5Usb { get; set; }

		public string MD5S1 { get; set; }

		public string MD5S2 { get; set; }

		public string MD5S3 { get; set; }

		public string PartNumberUsbKit { get; set; }

		public string PartNumberDvdKit { get; set; }

		public string PartNumberDvdS1 { get; set; }

		public string PartNumberDvdS2 { get; set; }

		public string PartNumberDvdS3 { get; set; }

		public string Sdpn { get; set; }

		public DateTime? AdjustedRtmDate { get; set; }

		public string SkuImageId { get; set; }
    }
}
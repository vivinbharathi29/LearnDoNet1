﻿using System;
using System.Collections.Generic;

namespace HPi.Pulsar.Product.Contracts
{
    public class HardwareMatrixSearchModel
    {
        public string ProductIds { get; set; }

        public string Products { get; set; }

        public string ProductReleaseIds { get; set; }

        public DateTime? PVDate { get; set; }

        public DateTime? SI1Date { get; set; }

        public DateTime? SI2Date { get; set; }

        public List<ProductHardwareMatrixSearchModel> ProductsHardwareMatrix { get; set; }

        public List<ProductListForDisplayModel> ProductListForDisplay { get; set; }

        public List<ProductListForDisplayModel> ProductLists { get; set; }

        public List<Dictionary<string, string>> ColumnData { get; set; }

        public List<Dictionary<string, string>> RowData { get; set; }

        public string ErrorMessage { get; set; }
    }

    public class ProductListForDisplayModel
    {
        public int Id { get; set; }

        public string DotsName { get; set; }

        public string Name { get; set; }

        public int ProductversionId { get; set; }

        public string Subassembly { get; set; }
    }

    public class ProductSelectFamilyListModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int ProductversionId { get; set; }
    }

    public class ProductHardwareMatrixSearchModel
    {
        public int DeliverableVersionId { get; set; }

        public int? NativeSubassemblyRootId { get; set; }

        public string SupplierCode { get; set; }

        public string ModelNumber { get; set; }

        public string Version { get; set; }

        public string Revision { get; set; }

        public string Pass { get; set; }

        public string Rohs { get; set; }

        public string Greenspec { get; set; }

        public DateTime? SampleDate { get; set; }

        public string AssemblyCode { get; set; }

        public string PartNumber { get; set; }

        public string PilotStatus { get; set; }

        public DateTime? PilotDate { get; set; }

        public string PilotBGColor { get; set; }

        public string AccessoryStatus { get; set; }

        public string AccessoryBGColor { get; set; }

        public string TestStatus { get; set; }

        public byte? RiskRelease { get; set; }

        public string location { get; set; }

        public byte? TestConfidence { get; set; }

        public string MatrixBGColor { get; set; }

        public string Commodity { get; set; }

        public string TargetNotes { get; set; }

        public int? ProductversionId { get; set; }

        public int? ReleaseId { get; set; }

        public DateTime? TestDate { get; set; }

        public DateTime? AccessoryDate { get; set; }

        public string vendor { get; set; }

        public string ComponentPM { get; set; }

        public int? RootId { get; set; }

        public string VersionDeliverableName { get; set; }

        public string SubassemblyBase { get; set; }

        public string Subassembly { get; set; }

        public string DeliverableName { get; set; }

        public string FeatureName { get; set; }

        public bool? FusionRequirements { get; set; }

        public int? CategoryId { get; set; }

        public int? DCRID { get; set; }

        public string GreenSpecBGColor { get; set; }

        public DateTime? ServiceEOADate { get; set; }

        public DateTime? EOLDate { get; set; }

        public DateTime? EndOfLifeDate { get; set; }

        public bool? ServiceActive { get; set; }

        public bool? Active { get; set; }

        public string Category { get; set; }

        public string ProductIds { get; set; }

        public string VendorWithSupplier { get; set; }

        public string EOLDateDesc { get; set; }

        public string DCRDesc { get; set; }

        public string RohsGreenSpec { get; set; }

        public string SubassemblyBaseDesc { get; set; }

        public string PilotStatusDesc { get; set; }

        public string AccessoryStatusDesc { get; set; }

    }
}



namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class ScheduleDataModel.
    /// </summary>
    public class ScheduleDataModel
    {
        /// <summary>
        /// Gets or sets the Scheduledataid.
        /// </summary>
        /// <value>
        /// The scheduledata identifier.
        /// </value>
        public int ScheduleDataId { get; set; }

        /// <summary>
        /// Gets or sets the Scheduleid.
        /// </summary>
        /// <value>
        /// The schedule identifier.
        /// </value>
        public int ScheduleId { get; set; }

        /// <summary>
        /// Gets or sets the Scheduledefinitiondataid.
        /// </summary>
        /// <value>
        /// The scheduledefinitiondata identifier.
        /// </value>
        public int? ScheduleDefinitionDataId { get; set; }

        /// <summary>
        /// Gets or sets the Porstartdt.
        /// </summary>
        /// <value>
        /// The porstartdt.
        /// </value>
        public DateTime? PorStartDt { get; set; }

        /// <summary>
        /// Gets or sets the Porenddt.
        /// </summary>
        /// <value>
        /// The porenddt.
        /// </value>
        public DateTime? PorEndDt { get; set; }

        /// <summary>
        /// Gets or sets the Projectedstartdt.
        /// </summary>
        /// <value>
        /// The projectedstartdt.
        /// </value>
        public DateTime? ProjectedStartDt { get; set; }

        /// <summary>
        /// Gets or sets the Projectedenddt.
        /// </summary>
        /// <value>
        /// The projectedenddt.
        /// </value>
        public DateTime? ProjectedEndDt { get; set; }

        /// <summary>
        /// Gets or sets the Actualstartdt.
        /// </summary>
        /// <value>
        /// The actualstartdt.
        /// </value>
        public DateTime? ActualStartDt { get; set; }

        /// <summary>
        /// Gets or sets the Actualenddt.
        /// </summary>
        /// <value>
        /// The actualenddt.
        /// </value>
        public DateTime? ActualEndDt { get; set; }

        /// <summary>
        /// Gets or sets the Itemdescription.
        /// </summary>
        /// <value>
        /// The itemdescription.
        /// </value>
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets the Itemphase.
        /// </summary>
        /// <value>
        /// The itemphase.
        /// </value>
        public int? ItemPhase { get; set; }

        /// <summary>
        /// Gets or sets the Itemorder.
        /// </summary>
        /// <value>
        /// The itemorder.
        /// </value>
        public int? ItemOrder { get; set; }

        /// <summary>
        /// Gets or sets the Itemnotes.
        /// </summary>
        /// <value>
        /// The itemnotes.
        /// </value>
        public string ItemNotes { get; set; }

        /// <summary>
        /// Gets or sets the Milestoneyn.
        /// </summary>
        /// <value>
        /// The milestoneyn.
        /// </value>
        public string MilestoneYN { get; set; }

        /// <summary>
        /// Gets or sets the program.
        /// </summary>
        /// <value>
        /// The program.
        /// </value>
        public string Program { get; set; }

        /// <summary>
        /// Gets or sets the Requiredyn.
        /// </summary>
        /// <value>
        /// The requiredyn.
        /// </value>
        public string RequiredYN { get; set; }

        /// <summary>
        /// Gets or sets the Activeyn.
        /// </summary>
        /// <value>
        /// The activeyn.
        /// </value>
        public string ActiveYN { get; set; }

        /// <summary>
        /// Gets or sets the Showonreportsyn.
        /// </summary>
        /// <value>
        /// The showonreportsyn.
        /// </value>
        public string ShowOnReportsYN { get; set; }

        /// <summary>
        /// Gets or sets the Addedafterporyn.
        /// </summary>
        /// <value>
        /// The addedafterporyn.
        /// </value>
        public string AddedAfterPorYN { get; set; }

        /// <summary>
        /// Gets or sets the Dcrid.
        /// </summary>
        /// <value>
        /// The dcrid.
        /// </value>
        public int? DcrId { get; set; }

        /// <summary>
        /// Gets or sets the Lastupduser.
        /// </summary>
        /// <value>
        /// The lastupduser.
        /// </value>
        public string LastUpdUser { get; set; }

        /// <summary>
        /// Gets or sets the Lastupddate.
        /// </summary>
        /// <value>
        /// The lastupddate.
        /// </value>
        public DateTime LastUpdDate { get; set; }

        /// <summary>
        /// Gets or sets the NotificationRecipients.
        /// </summary>
        /// <value>
        /// The notification recipients.
        /// </value>
        public string NotificationRecipients { get; set; }

        /// <summary>
        /// Gets or sets the Changenotes.
        /// </summary>
        /// <value>
        /// The changenotes.
        /// </value>
        public string ChangeNotes { get; set; }

        /// <summary>
        /// Gets or sets the Customitemdefinition.
        /// </summary>
        /// <value>
        /// The customitemdefinition.
        /// </value>
        public string CustomItemDefinition { get; set; }

        /// <summary>
        /// Gets or sets the item definition.
        /// </summary>
        /// <value>
        /// The item definition.
        /// </value>
        public string ItemDefinition { get; set; }

        /// <summary>
        /// Gets or sets the projected start date old.
        /// </summary>
        /// <value>
        /// The projected start date old.
        /// </value>
        public DateTime? ProjectedStartDateOld { get; set; }

        /// <summary>
        /// Gets or sets the projected end date old.
        /// </summary>
        /// <value>
        /// The projected end date old.
        /// </value>
        public DateTime? ProjectedEndDateOld { get; set; }

        /// <summary>
        /// Gets or sets the owner identifier.
        /// </summary>
        /// <value>
        /// The owner identifier.
        /// </value>
        public int? OwnerId { get; set; }

        /// <summary>
        /// Gets or sets the selected release.
        /// </summary>
        /// <value>
        /// The selected release.
        /// </value>
        public int SelectedRelease { get; set; }

        /// <summary>
        /// Gets or sets the schedule.
        /// </summary>
        /// <value>
        /// The schedule.
        /// </value>
        public ScheduleModel Schedule { get; set; }

        /// <summary>
        /// Gets or sets the product release.
        /// </summary>
        /// <value>
        /// The product release.
        /// </value>
        public ProductReleaseModel ProductRelease { get; set; }

        /// <summary>
        /// Gets or sets the schedule phase.
        /// </summary>
        /// <value>
        /// The schedule phase.
        /// </value>
        public SchedulePhaseModel SchedulePhase { get; set; }

        /// <summary>
        /// Gets or sets the product version.
        /// </summary>
        /// <value>
        /// The product version.
        /// </value>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the system team roles.
        /// </summary>
        /// <value>
        /// The system team roles.
        /// </value>
        public SystemTeamRoleModel SystemTeamRoles { get; set; }

        /// <summary>
        /// Gets or sets the Product Version Id.
        /// </summary>
        /// <value>
        /// The Product Version Id.
        /// </value>
        public string ProductVersionId { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionWithoutSchedule.
        /// </summary>
        /// <value>
        /// The ProductVersionWithoutSchedule.
        /// </value>
        public string ProductVersionWithoutSchedule { get; set; }

        /// <summary>
        /// Gets or sets the MilestoneDate.
        /// </summary>
        /// <value>
        /// The milestoneDate.
        /// </value>
        public DateTime? MilestoneDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is copy date.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is copy date; otherwise, <c>false</c>.
        /// </value>
        public bool IsCopyDate { get; set; }

        /// <summary>
        /// Gets or sets the MilestoneDate.
        /// </summary>
        /// <value>
        /// The milestoneDate.
        /// </value>
        public DateTime? RtpDate { get; set; }

        /// <summary>
        /// Gets or sets the MilestoneDate.
        /// </summary>
        /// <value>
        /// The milestoneDate.
        /// </value>
        public DateTime? EMDate { get; set; }

        /// <summary>
        /// Gets or sets the RecordCount.
        /// </summary>
        public int RecordCount { get; set; }
    }
}
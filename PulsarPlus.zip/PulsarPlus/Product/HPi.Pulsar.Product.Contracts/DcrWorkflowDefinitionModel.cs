namespace HPi.Pulsar.Product.Contracts
{
    public class DcrWorkflowDefinitionModel
    {
        public int Id { get; set; }

        public string EmailList { get; set; }

        public int? WorkflowId { get; set; }

        public short? MilestoneOrder { get; set; }

        public string Milestone { get; set; }

        public int MilestoneCount { get; set; }

        public string SystemTeamRoleId { get; set; }

        public byte? SendEmail { get; set; }

        public bool Active { get; set; }

        public string AssignedTo { get; set; }

        public ProductVersionModel ProductVersion { get; set; }

        public UserInfoModel UserInfo { get; set; }

        public DcrWorkflowHistoryModel DcrWorkflowHistory { get; set; }

        public DcrWorkflowLookupModel DcrWorkflowLookup { get; set; }

        public DeliverableIssueModel DeliverableIssue { get; set; }

        public string RoleName { get; set; }
    }
}
﻿

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductDeliverableReleaseModel</para>
    /// </summary>
    public class ProductDeliverableReleaseModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the ProductDeliverableID.
        /// </summary>
        public int ProductDeliverableId { get; set; }

        /// <summary>
        /// Gets or sets the ReleaseID.
        /// </summary>
        public int ReleaseId { get; set; }

        /// <summary>
        /// Gets or sets the DefaultReleaseID.
        /// </summary>
        public int DefaultReleaseId { get; set; }

        /// <summary>
        /// Gets or sets the Targeted.
        /// </summary>
        public bool? Targeted { get; set; }

        /// <summary>
        /// Gets or sets the TestStatusID.
        /// </summary>
        public int? TestStatusId { get; set; }

        /// <summary>
        /// Gets or sets the TestDate.
        /// </summary>
        public DateTime? TestDate { get; set; }

        /// <summary>
        /// Gets or sets the TestStatusIDLastUpdDt.
        /// </summary>
        public DateTime TestStatusIDLastUpdDt { get; set; }

        /// <summary>
        /// Gets or sets the TestConfidence.
        /// </summary>
        public byte? TestConfidence { get; set; }

        /// <summary>
        /// Gets or sets the RiskRelease.
        /// </summary>
        public byte? RiskRelease { get; set; }

        /// <summary>
        /// Gets or sets the TargetNotes.
        /// </summary>
        public string TargetNotes { get; set; }

        /// <summary>
        /// Gets or sets the DCRID.
        /// </summary>
        public int? DcrId { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryStatusID.
        /// </summary>
        public int? AccessoryStatusId { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryLeveraged.
        /// </summary>
        public bool? AccessoryLeveraged { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryNotes.
        /// </summary>
        public string AccessoryNotes { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryDate.
        /// </summary>
        public DateTime? AccessoryDate { get; set; }

        /// <summary>
        /// Gets or sets the LastUpdatedBy.
        /// </summary>
        public string LastUpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the SupplyChainRestriction.
        /// </summary>
        public byte? SupplyChainRestriction { get; set; }

        /// <summary>
        /// Gets or sets the ConfigurationRestriction.
        /// </summary>
        public byte? ConfigurationRestriction { get; set; }

        /// <summary>
        /// Gets or sets the PilotStatusID.
        /// </summary>
        public int? PilotStatusId { get; set; }

        /// <summary>
        /// Gets or sets the PilotDate.
        /// </summary>
        public DateTime? PilotDate { get; set; }

        /// <summary>
        /// Gets or sets the PilotNotes.
        /// </summary>
        public string PilotNotes { get; set; }

        /// <summary>
        /// Gets or sets the OOCRelease.
        /// </summary>
        public bool? OocRelease { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionReleaseModel.
        /// </summary>
        public ProductVersionReleaseModel ProductVersionRelease { get; set; }

        /// <summary>
        /// Gets or sets the ProductDeliverableModel.
        /// </summary>
        public ProductDeliverableModel ProductDeliverable { get; set; }

        /// <summary>
        /// Gets or sets the TotalNoOfRows.
        /// </summary>
        public int TotalNoOfRows { get; set; }

        /// <summary>
        /// Gets or sets the IsPulsarProduct.
        /// </summary>
        public bool IsPulsarProduct { get; set; }

        /// <summary>
        /// Gets or sets the Release.
        /// </summary>
        public string Release { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableVersion.
        /// </summary>
        public DeliverableVersionModel DeliverableVersionModel { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableVersion.
        /// </summary>
        public ProductVersionModel ProductVersionModel { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableRootName.
        /// </summary>
        public string DeliverableRootName { get; set; }

        /// <summary>
        /// Gets or sets the TestStatus.
        /// </summary>
        public string TestStatus { get; set; }

        /// <summary>
        /// Gets or sets the VendorName.
        /// </summary>
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets the odm units received.
        /// </summary>
        /// <value>
        /// The odm units received.
        /// </value>
        public int UnitsReceived { get; set; }

        /// <summary>
        /// Gets or sets the odm test notes.
        /// </summary>
        /// <value>
        /// The odm test notes.
        /// </value>
        public string TestNotes { get; set; }

    }
}
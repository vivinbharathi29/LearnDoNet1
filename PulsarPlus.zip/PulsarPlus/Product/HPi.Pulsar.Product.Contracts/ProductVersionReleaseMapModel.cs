

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductVersion1ReleaseModel</para>
    /// </summary>
    public class ProductVersionReleaseMapModel
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionId.
        /// </summary>
        public int ProductVersionId { get; set; }

        /// <summary>
        /// Gets or sets the ReleaseId.
        /// </summary>
        public int ReleaseId { get; set; }

        /// <summary>
        /// Gets or sets the IsDefault.
        /// </summary>
        public byte? IsDefault { get; set; }


    }
}
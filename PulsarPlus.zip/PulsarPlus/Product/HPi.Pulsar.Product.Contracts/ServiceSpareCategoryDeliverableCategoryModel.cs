

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ServiceSpareCategoryDeliverableCategoryModel</para>
    /// </summary>
    public class ServiceSpareCategoryDeliverableCategoryModel
    {
		/// <summary>
		/// Gets or sets the ServiceSpareCategoryId.
		/// </summary>
		public int ServiceSpareCategoryId { get; set; }

		/// <summary>
		/// Gets or sets the DeliverableCategoryId.
		/// </summary>
		public int DeliverableCategoryId { get; set; }


    }
}
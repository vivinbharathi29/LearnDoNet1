using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class LanguageModel
    {
        public string Language { get; set; }

        public string Abbreviation { get; set; }

        public int? OrderId { get; set; }

        public int Id { get; set; }

        public string Dash { get; set; }

        public string OverflowDash { get; set; }

        public string Substitute1 { get; set; }

        public string Substitute2 { get; set; }

        public byte? IsLanguage { get; set; }

        public string Region { get; set; }

        public byte? Translation { get; set; }

        public string PowerCord { get; set; }

        public string CpqCode { get; set; }

        public string HPCode { get; set; }

        public bool? Active { get; set; }

        public bool? Export { get; set; }

        public string CvrCode { get; set; }

        public int? IrsId { get; set; }

        public DateTime Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public bool? ExportCompliance { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }

        public string Localizations { get; set; }

        public int? IsExport { get; set; }

        public int RecordCount { get; set; }
    }
}
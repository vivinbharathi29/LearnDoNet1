using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class DeliverableNamingModel
    {
        public int Id { get; set; }

        public int? CategoryId { get; set; }

        public int? ElementId { get; set; }

        public string ElementValue { get; set; }

        public int? DisplayOrder { get; set; }

        public bool? Active { get; set; }

        public string Value1 { get; set; }

        public string Value2 { get; set; }

        public string Value3 { get; set; }

        public string Value4 { get; set; }

        public string Value5 { get; set; }

        public string Value6 { get; set; }

        public string Value7 { get; set; }

        public string Value8 { get; set; }

        public DateTime Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public int? SupplierId { get; set; }
    }
}
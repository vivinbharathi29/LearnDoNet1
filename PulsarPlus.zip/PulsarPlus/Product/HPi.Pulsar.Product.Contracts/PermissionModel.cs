

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>PermissionModel</para>
    /// </summary>
    public class PermissionModel
    {
		/// <summary>
		/// Gets or sets the PermissionId.
		/// </summary>
		public int PermissionId { get; set; }

		/// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the Description.
		/// </summary>
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets the UpdatedBy.
		/// </summary>
		public string UpdatedBy { get; set; }

		/// <summary>
		/// Gets or sets the CreatedBy.
		/// </summary>
		public string CreatedBy { get; set; }

		/// <summary>
		/// Gets or sets the Created.
		/// </summary>
		public DateTime Created { get; set; }

		/// <summary>
		/// Gets or sets the Updated.
		/// </summary>
		public DateTime? Updated { get; set; }

		/// <summary>
		/// Gets or sets the Disabled.
		/// </summary>
		public DateTime? Disabled { get; set; }

		/// <summary>
		/// Gets or sets the DisabledBy.
		/// </summary>
		public string DisabledBy { get; set; }

		///// <summary>
		///// Gets or sets the MegaMenuOpenPermissions.
		///// </summary>
		//public MegaMenuOpenPermissionsModel MegaMenuOpenPermissions { get; set; }

		///// <summary>
		///// Gets or sets the HelpPagePermission.
		///// </summary>
		//public HelpPagePermissionModel HelpPagePermission { get; set; }

		///// <summary>
		///// Gets or sets the RoleObjectPermission.
		///// </summary>
		//public RoleObjectPermissionModel RoleObjectPermission { get; set; }


    }
}
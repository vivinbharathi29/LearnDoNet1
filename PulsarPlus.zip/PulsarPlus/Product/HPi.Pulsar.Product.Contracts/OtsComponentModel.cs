﻿namespace HPi.Pulsar.Product.Contracts
{
    public class OtsComponentModel
    {
        public int Id { get; set; }

        public string Component { get; set; }

        public int? TypeId { get; set; }

        public string ErrorType { get; set; }

        public int DefaultPmRole { get; set; }

        public int DefaultDeveloperRole { get; set; }

        public bool Active { get; set; }

        public string Category { get; set; }

        public int CategoryId { get; set; }

        public int? DefaultPmId { get; set; }

        public int? DefaultDeveloperId { get; set; }

        public string OtsPartNumber { get; set; }

        public bool? DockingStation { get; set; }

        public int CoreTeamId { get; set; }
    }
}

using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class ExCopJobModel
    {
        public int Id { get; set; }

        public int ImageBuild { get; set; }

        public int ProductVersionId { get; set; }

        public int ImageId { get; set; }

        public int BuildStatus { get; set; }

        public int? ConveyorStatus { get; set; }

        public DateTime CreatedDate { get; set; }

        public int? ExCopJobId { get; set; }

        public int? SkuRevision { get; set; }

        public string StatusText { get; set; }

        public byte? Priority { get; set; }

        public DateTime? LastUpdatedDate { get; set; }

        public bool? NotificationSent { get; set; }

        public int? ImageCycle { get; set; }

        public int? ExcaliburBuildId { get; set; }

        public int Waiting { get; set; }

        public int Processing { get; set; }

        public int Building { get; set; }
    }
}
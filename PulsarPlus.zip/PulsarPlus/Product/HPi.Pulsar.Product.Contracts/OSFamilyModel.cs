using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class OSFamilyModel
    {
        public int Id { get; set; }

        public string FamilyName { get; set; }

        public string Architecture { get; set; }

        public bool RequiresWhql { get; set; }

        public int SortOrder { get; set; }

        public bool Active { get; set; }

        public DateTime LastUpdDt { get; set; }

        public string LastUpdUser { get; set; }

        public string ShortName { get; set; }

        public DateTime Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }
    }
}
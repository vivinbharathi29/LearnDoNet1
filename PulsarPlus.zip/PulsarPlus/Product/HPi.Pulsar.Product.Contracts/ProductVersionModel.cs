

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductVersionModel</para>
    /// </summary>
    public class ProductVersionModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Version.
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the ProductFamilyID.
        /// </summary>
        public int? ProductFamilyId { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the Published.
        /// </summary>
        public DateTime? Published { get; set; }

        /// <summary>
        /// Gets or sets the DOTSName.
        /// </summary>
        public string DotsName { get; set; }

        /// <summary>
        /// Gets or sets the Cycle.
        /// </summary>
        public string Cycle { get; set; }

        /// <summary>
        /// Gets or sets the PlatformID.
        /// </summary>
        public int? PlatformId { get; set; }

        /// <summary>
        /// Gets or sets the Distribution.
        /// </summary>
        public string Distribution { get; set; }

        /// <summary>
        /// Gets or sets the PDDReleased.
        /// </summary>
        public DateTime? PddReleased { get; set; }

        /// <summary>
        /// Gets or sets the Active.
        /// </summary>
        public bool Active { get; set; }

        /// <summary>
        /// Gets or sets the Sustaining.
        /// </summary>
        public byte? Sustaining { get; set; }

        /// <summary>
        /// Gets or sets the PRDReleased.
        /// </summary>
        public DateTime? PrdReleased { get; set; }

        /// <summary>
        /// Gets or sets the ProductStatusID.
        /// </summary>
        public int? ProductStatusId { get; set; }

        /// <summary>
        /// Gets or sets the PMID.
        /// </summary>
        public int? PMId { get; set; }

        /// <summary>
        /// Gets or sets the StreetName.
        /// </summary>
        public string StreetName { get; set; }

        /// <summary>
        /// Gets or sets the Objectives.
        /// </summary>
        public string Objectives { get; set; }

        /// <summary>
        /// Gets or sets the OnlineReports.
        /// </summary>
        public byte? OnlineReports { get; set; }

        /// <summary>
        /// Gets or sets the SEPMID.
        /// </summary>
        public int? SepmId { get; set; }

        /// <summary>
        /// Gets or sets the Division.
        /// </summary>
        public byte? Division { get; set; }

        /// <summary>
        /// Gets or sets the DevCenter.
        /// </summary>
        public int? DevCenter { get; set; }

        /// <summary>
        /// Gets or sets the Approver.
        /// </summary>
        public int? Approver { get; set; }

        /// <summary>
        /// Gets or sets the EmailActive.
        /// </summary>
        public byte? EmailActive { get; set; }

        /// <summary>
        /// Gets or sets the BaseUnit.
        /// </summary>
        public string BaseUnit { get; set; }

        /// <summary>
        /// Gets or sets the CurrentROM.
        /// </summary>
        public string CurrentRom { get; set; }

        /// <summary>
        /// Gets or sets the OSSupport.
        /// </summary>
        public string OSSupport { get; set; }

        /// <summary>
        /// Gets or sets the ImagePO.
        /// </summary>
        public string ImagePO { get; set; }

        /// <summary>
        /// Gets or sets the ImageChanges.
        /// </summary>
        public string ImageChanges { get; set; }

        /// <summary>
        /// Gets or sets the SystemBoardID.
        /// </summary>
        public string SystemBoardId { get; set; }

        /// <summary>
        /// Gets or sets the MachinePNPID.
        /// </summary>
        public string MachinePnpId { get; set; }

        /// <summary>
        /// Gets or sets the CommonImages.
        /// </summary>
        public string CommonImages { get; set; }

        /// <summary>
        /// Gets or sets the CertificationStatus.
        /// </summary>
        public string CertificationStatus { get; set; }

        /// <summary>
        /// Gets or sets the SWQAStatus.
        /// </summary>
        public string SWQAStatus { get; set; }

        /// <summary>
        /// Gets or sets the PlatformStatus.
        /// </summary>
        public string PlatformStatus { get; set; }

        /// <summary>
        /// Gets or sets the TypeID.
        /// </summary>
        public byte? TypeId { get; set; }

        /// <summary>
        /// Gets or sets the Abbreviation.
        /// </summary>
        public string Abbreviation { get; set; }

        /// <summary>
        /// Gets or sets the Brands.
        /// </summary>
        public string Brands { get; set; }

        /// <summary>
        /// Gets or sets the Created.
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// Gets or sets the PDDPath.
        /// </summary>
        public string PddPath { get; set; }

        /// <summary>
        /// Gets or sets the SCMPath.
        /// </summary>
        public string ScmPath { get; set; }

        /// <summary>
        /// Gets or sets the STLStatusPath.
        /// </summary>
        public string StlStatusPath { get; set; }

        /// <summary>
        /// Gets or sets the ProgramMatrixPath.
        /// </summary>
        public string ProgramMatrixPath { get; set; }

        /// <summary>
        /// Gets or sets the ApproverList.
        /// </summary>
        public string ApproverList { get; set; }

        /// <summary>
        /// Gets or sets the SMID.
        /// </summary>
        public int? SMId { get; set; }

        /// <summary>
        /// Gets or sets the PDEID.
        /// </summary>
        public int? PdeId { get; set; }

        /// <summary>
        /// Gets or sets the PreinstallTeam.
        /// </summary>
        public int? PreinstallTeam { get; set; }

        /// <summary>
        /// Gets or sets the ReleaseTeam.
        /// </summary>
        public int? ReleaseTeam { get; set; }

        /// <summary>
        /// Gets or sets the ComMarketingID.
        /// </summary>
        public int? ComMarketingId { get; set; }

        /// <summary>
        /// Gets or sets the SMBMarketingID.
        /// </summary>
        public int? SmbMarketingId { get; set; }

        /// <summary>
        /// Gets or sets the ConsMarketingID.
        /// </summary>
        public int? ConsMarketingId { get; set; }

        /// <summary>
        /// Gets or sets the PlatformDevelopmentID.
        /// </summary>
        public int? PlatformDevelopmentId { get; set; }

        /// <summary>
        /// Gets or sets the SupplyChainID.
        /// </summary>
        public int? SupplyChainId { get; set; }

        /// <summary>
        /// Gets or sets the ServiceID.
        /// </summary>
        public int? ServiceId { get; set; }

        /// <summary>
        /// Gets or sets the FinanceID.
        /// </summary>
        public int? FinanceId { get; set; }

        /// <summary>
        /// Gets or sets the RolloutP1.
        /// </summary>
        public DateTime? RolloutP1 { get; set; }

        /// <summary>
        /// Gets or sets the RolloutP2.
        /// </summary>
        public DateTime? RolloutP2 { get; set; }

        /// <summary>
        /// Gets or sets the RolloutP3.
        /// </summary>
        public DateTime? RolloutP3 { get; set; }

        /// <summary>
        /// Gets or sets the DCRAutoOpen.
        /// </summary>
        public byte? DcrAutoOpen { get; set; }

        /// <summary>
        /// Gets or sets the PartnerID.
        /// </summary>
        public int? PartnerId { get; set; }

        /// <summary>
        /// Gets or sets the OnCommodityMatrix.
        /// </summary>
        public bool? OnCommodityMatrix { get; set; }

        /// <summary>
        /// Gets or sets the ProductFilePath.
        /// </summary>
        public string ProductFilePath { get; set; }

        /// <summary>
        /// Gets or sets the ReferenceID.
        /// </summary>
        public int? ReferenceId { get; set; }

        /// <summary>
        /// Gets or sets the DocPM.
        /// </summary>
        public int? DocPM { get; set; }

        /// <summary>
        /// Gets or sets the SEPE.
        /// </summary>
        public int? Sepe { get; set; }

        /// <summary>
        /// Gets or sets the PINPM.
        /// </summary>
        public int? PinPM { get; set; }

        /// <summary>
        /// Gets or sets the SETestLead.
        /// </summary>
        public int? SETestLead { get; set; }

        /// <summary>
        /// Gets or sets the PreInstallCutoff.
        /// </summary>
        public string PreInstallCutoff { get; set; }

        /// <summary>
        /// Gets or sets the SustainingMgrID.
        /// </summary>
        public int? SustainingMgrId { get; set; }

        /// <summary>
        /// Gets or sets the TDCCMID.
        /// </summary>
        public int? TdcCMId { get; set; }

        /// <summary>
        /// Gets or sets the SustainingSEPMID.
        /// </summary>
        public int? SustainingSepmId { get; set; }

        /// <summary>
        /// Gets or sets the RegulatoryModel.
        /// </summary>
        public string RegulatoryModel { get; set; }

        /// <summary>
        /// Gets or sets the PCID.
        /// </summary>
        public int? PCId { get; set; }

        /// <summary>
        /// Gets or sets the MarketingOpsID.
        /// </summary>
        public int? MarketingOpsId { get; set; }

        /// <summary>
        /// Gets or sets the CommodityLock.
        /// </summary>
        public bool? CommodityLock { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryPMID.
        /// </summary>
        public int? AccessoryPMId { get; set; }

        /// <summary>
        /// Gets or sets the SCFactoryEngineerID.
        /// </summary>
        public int? SCFactoryEngineerId { get; set; }

        /// <summary>
        /// Gets or sets the AccessoryPath.
        /// </summary>
        public string AccessoryPath { get; set; }

        /// <summary>
        /// Gets or sets the ActionNotifyList.
        /// </summary>
        public string ActionNotifyList { get; set; }

        /// <summary>
        /// Gets or sets the ShowOnWhql.
        /// </summary>
        public bool ShowOnWhql { get; set; }

        /// <summary>
        /// Gets or sets the BIOSLeadID.
        /// </summary>
        public int? BiosLeadId { get; set; }

        /// <summary>
        /// Gets or sets the CommHWPMID.
        /// </summary>
        public int? CommHWPMId { get; set; }

        /// <summary>
        /// Gets or sets the ProcessorPMID.
        /// </summary>
        public int? ProcessorPMId { get; set; }

        /// <summary>
        /// Gets or sets the VideoMemoryPMID.
        /// </summary>
        public int? VideoMemoryPMId { get; set; }

        /// <summary>
        /// Gets or sets the DKCID.
        /// </summary>
        public int? DkcId { get; set; }

        /// <summary>
        /// Gets or sets the ServiceLifeDate.
        /// </summary>
        public DateTime? ServiceLifeDate { get; set; }

        /// <summary>
        /// Gets or sets the SystemboardComments.
        /// </summary>
        public string SystemBoardComments { get; set; }

        /// <summary>
        /// Gets or sets the MachinePNPComments.
        /// </summary>
        public string MachinePnpComments { get; set; }

        /// <summary>
        /// Gets or sets the AllowSMR.
        /// </summary>
        public bool? AllowSmr { get; set; }

        /// <summary>
        /// Gets or sets the AllowDeliverableReleases.
        /// </summary>
        public bool? AllowDeliverableReleases { get; set; }

        /// <summary>
        /// Gets or sets the AllowDCR.
        /// </summary>
        public bool? AllowDcr { get; set; }

        /// <summary>
        /// Gets or sets the ServiceFamilyPn.
        /// </summary>
        public string ServiceFamilyPn { get; set; }

        /// <summary>
        /// Gets or sets the DCRApproverList.
        /// </summary>
        public string DcrApproverList { get; set; }

        /// <summary>
        /// Gets or sets the ODMTestLeadID.
        /// </summary>
        public int? OdmTestLeadId { get; set; }

        /// <summary>
        /// Gets or sets the WWANTestLeadID.
        /// </summary>
        public int? WwanTestLeadId { get; set; }

        /// <summary>
        /// Gets or sets the BuPMID.
        /// </summary>
        public int? BuPMId { get; set; }

        /// <summary>
        /// Gets or sets the BuSEPMID.
        /// </summary>
        public int? BuSepmId { get; set; }

        /// <summary>
        /// Gets or sets the BuSMID.
        /// </summary>
        public int? BuSMId { get; set; }

        /// <summary>
        /// Gets or sets the BuTDCCMID.
        /// </summary>
        public int? BuTdccmId { get; set; }

        /// <summary>
        /// Gets or sets the BuComMarketingID.
        /// </summary>
        public int? BuComMarketingId { get; set; }

        /// <summary>
        /// Gets or sets the BuSMBMarketingID.
        /// </summary>
        public int? BuSmbMarketingId { get; set; }

        /// <summary>
        /// Gets or sets the BuConsMarketingID.
        /// </summary>
        public int? BuConsMarketingId { get; set; }

        /// <summary>
        /// Gets or sets the BuPLatformDevelopmentID.
        /// </summary>
        public int? BuPlatformDevelopmentId { get; set; }

        /// <summary>
        /// Gets or sets the BuSupplyChainID.
        /// </summary>
        public int? BuSupplyChainId { get; set; }

        /// <summary>
        /// Gets or sets the BuServiceID.
        /// </summary>
        public int? BuServiceId { get; set; }

        /// <summary>
        /// Gets or sets the BuFinanceID.
        /// </summary>
        public int? BuFinanceId { get; set; }

        /// <summary>
        /// Gets or sets the BuPDEID.
        /// </summary>
        public int? BuPdeId { get; set; }

        /// <summary>
        /// Gets or sets the BuAccessoryPMID.
        /// </summary>
        public int? BuAccessoryPMId { get; set; }

        /// <summary>
        /// Gets or sets the BuSCFactoryEngineerID.
        /// </summary>
        public int? BuSCFactoryEngineerId { get; set; }

        /// <summary>
        /// Gets or sets the is legacy.
        /// </summary>
        /// <value>
        /// The is legacy.
        /// </value>
        public byte? IsLegacy { get; set; }

        /// <summary>
        /// Gets or sets the BuPCID.
        /// </summary>
        public int? BuPCId { get; set; }

        /// <summary>
        /// Gets or sets the BuMarketingOpsID.
        /// </summary>
        public int? BuMarketingOpsId { get; set; }

        /// <summary>
        /// Gets or sets the BuSustainingSEPMID.
        /// </summary>
        public int? BuSustainingSepmId { get; set; }

        /// <summary>
        /// Gets or sets the BuSETestLeadID.
        /// </summary>
        public int? BuSETestLeadId { get; set; }

        /// <summary>
        /// Gets or sets the BuODMTestLeadID.
        /// </summary>
        public int? BuOdmTestLeadId { get; set; }

        /// <summary>
        /// Gets or sets the BuWWANTestLeadID.
        /// </summary>
        public int? BuWwanTestLeadId { get; set; }

        /// <summary>
        /// Gets or sets the BuPINPM.
        /// </summary>
        public int? BuPinPM { get; set; }

        /// <summary>
        /// Gets or sets the BuDocPM.
        /// </summary>
        public int? BuDocPM { get; set; }

        /// <summary>
        /// Gets or sets the BuSEPE.
        /// </summary>
        public int? BuSepe { get; set; }

        /// <summary>
        /// Gets or sets the BuBIOSLeadID.
        /// </summary>
        public int? BuBiosLeadId { get; set; }

        /// <summary>
        /// Gets or sets the BuCommHWPMID.
        /// </summary>
        public int? BuCommHwpmId { get; set; }

        /// <summary>
        /// Gets or sets the BuProcessorPMID.
        /// </summary>
        public int? BuProcessorPMId { get; set; }

        /// <summary>
        /// Gets or sets the BuVideoMemoryPMID.
        /// </summary>
        public int? BuVideoMemoryPMId { get; set; }

        /// <summary>
        /// Gets or sets the BuDKCID.
        /// </summary>
        public int? BuDkcId { get; set; }

        /// <summary>
        /// Gets or sets the CurrentWebROM.
        /// </summary>
        public string CurrentWebRom { get; set; }

        /// <summary>
        /// Gets or sets the ToolAccessList.
        /// </summary>
        public string ToolAccessList { get; set; }

        /// <summary>
        /// Gets or sets the GraphicsControllerPMID.
        /// </summary>
        public int? GraphicsControllerPMId { get; set; }

        /// <summary>
        /// Gets or sets the BuGraphicsControllerPMID.
        /// </summary>
        public int? BuGraphicsControllerPMId { get; set; }

        /// <summary>
        /// Gets or sets the WWANProduct.
        /// </summary>
        public bool? WwanProduct { get; set; }

        /// <summary>
        /// Gets or sets the CallDataLastUpdated.
        /// </summary>
        public DateTime? CallDataLastUpdated { get; set; }

        /// <summary>
        /// Gets or sets the SETestID.
        /// </summary>
        public int? SETestId { get; set; }

        /// <summary>
        /// Gets or sets the BuSETestID.
        /// </summary>
        public int? BuSETestId { get; set; }

        /// <summary>
        /// Gets or sets the SPDM.
        /// </summary>
        public int? Spdm { get; set; }

        /// <summary>
        /// Gets or sets the GPLM.
        /// </summary>
        public int? Gplm { get; set; }

        /// <summary>
        /// Gets or sets the SvcBomAnalyst.
        /// </summary>
        public int? SvcBomAnalyst { get; set; }

        /// <summary>
        /// Gets or sets the RCTOSites.
        /// </summary>
        public string RctoSites { get; set; }

        /// <summary>
        /// Gets or sets the RTMNotifications.
        /// </summary>
        public string RtmNotifications { get; set; }

        /// <summary>
        /// Gets or sets the AllowImageBuilds.
        /// </summary>
        public bool? AllowImageBuilds { get; set; }

        /// <summary>
        /// Gets or sets the ConveyorBuildDistribution.
        /// </summary>
        public string ConveyorBuildDistribution { get; set; }

        /// <summary>
        /// Gets or sets the ConveyorReleaseDistribution.
        /// </summary>
        public string ConveyorReleaseDistribution { get; set; }

        /// <summary>
        /// Gets or sets the AgencyVersion.
        /// </summary>
        public byte AgencyVersion { get; set; }

        /// <summary>
        /// Gets or sets the DCRDefaultOwner.
        /// </summary>
        public int? DcrDefaultOwner { get; set; }

        /// <summary>
        /// Gets or sets the Fusion.
        /// </summary>
        public bool Fusion { get; set; }

        /// <summary>
        /// Gets or sets the AvActionScorecardInactiveInclude.
        /// </summary>
        public bool? AVActionScorecardInactiveInclude { get; set; }

        /// <summary>
        /// Gets or sets the MinRoHSLevel.
        /// </summary>
        public int? MinRoHSLevel { get; set; }

        /// <summary>
        /// Gets or sets the AffectedProduct.
        /// </summary>
        public int? AffectedProduct { get; set; }

        /// <summary>
        /// Gets or sets the BSAMFlag.
        /// </summary>
        public bool? BsamFlag { get; set; }

        /// <summary>
        /// Gets or sets the AddDCRNotificationList.
        /// </summary>
        public bool? AddDcrNotificationList { get; set; }

        /// <summary>
        /// Gets or sets the CreatedBy.
        /// </summary>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Updated.
        /// </summary>
        public DateTime Updated { get; set; }

        /// <summary>
        /// Gets or sets the UpdatedBy.
        /// </summary>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Deleted.
        /// </summary>
        public DateTime? Deleted { get; set; }

        /// <summary>
        /// Gets or sets the DeletedBy.
        /// </summary>
        public string DeletedBy { get; set; }

        /// <summary>
        /// Gets or sets the ProductLineId.
        /// </summary>
        public int? ProductLineId { get; set; }

        /// <summary>
        /// Gets or sets the FusionRequirements. 
        /// </summary>
        public bool? FusionRequirements { get; set; }

        /// <summary>
        /// Gets or sets the Requirements. 
        /// </summary>
        public string Requirements { get; set; }

        /// <summary>
        /// Gets or sets the BusinessSegmentID.
        /// </summary>
        public int? BusinessSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the ProductName.
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [product email].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [product email]; otherwise, <c>false</c>.
        /// </value>
        public bool ProductEmail { get; set; }

        /// <summary>
        /// Gets or sets the SysEngrProgramCoordinatorID.
        /// </summary>
        public int? SysEngrProgramCoordinatorId { get; set; }

        /// <summary>
        /// Gets or sets the BuSysEngrProgramCoordinatorID.
        /// </summary>
        public int? BuSysEngrProgramCoordinatorId { get; set; }

        /// <summary>
        /// Gets or sets the AutoSimpleAV.
        /// </summary>
        public bool AutoSimpleAV { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionId.
        /// </summary>
        public int ProductVersionId { get; set; }

        /// <summary>
        /// Gets or sets the CMId.
        /// </summary>
        public int? CMId { get; set; }

        /// <summary>
        /// Gets or sets the SEPEId.
        /// </summary>
        public int? SepeId { get; set; }

        /// <summary>
        /// Gets or sets the PINPMId.
        /// </summary>
        public int? PinPMId { get; set; }

        /// <summary>
        /// Gets or sets the SETestLeadId.
        /// </summary>
        public int? SETestLeadId { get; set; }

        /// <summary>
        /// Gets or sets the Disabled.
        /// </summary>
        public DateTime? Disabled { get; set; }

        /// <summary>
        /// Gets or sets the DisabledBy.
        /// </summary>
        public string DisabledBy { get; set; }

        /// <summary>
        /// Gets or sets the ProgramBusinessManagerID.
        /// </summary>
        public int? ProgramBusinessManagerId { get; set; }

        /// <summary>
        /// Gets or sets the BuProgramBusinessManagerID.
        /// </summary>
        public int? BuProgramBusinessManagerId { get; set; }

        /// <summary>
        /// Gets or sets the IsDesktop.
        /// </summary>
        public bool? IsDesktop { get; set; }

        /// <summary>
        /// Gets or sets the QualityID.
        /// </summary>
        public int? QualityId { get; set; }

        /// <summary>
        /// Gets or sets the BuQualityID.
        /// </summary>
        public int? BuQualityId { get; set; }

        /// <summary>
        /// Gets or sets the SharedAVMarketingID.
        /// </summary>
        public int? SharedAVMarketingId { get; set; }

        /// <summary>
        /// Gets or sets the SharedAVPCID.
        /// </summary>
        public int? SharedAVPCId { get; set; }

        /// <summary>
        /// Gets or sets the ODMSEPMID.
        /// </summary>
        public int? OdmSepmId { get; set; }
        /// <summary>
        /// Gets or sets the odmhwpmid.
        /// </summary>
        /// <value>
        /// The odmhwpmid.
        /// </value>
        public int? OdmHwpmID { get; set; }
        /// <summary>
        /// Gets or sets the hwpcid.
        /// </summary>
        /// <value>
        /// The hwpcid.
        /// </value>
        public int? HwpcId { get; set; }

        /// <summary>
        /// Gets or sets the ProcurementPMID.
        /// </summary>
        public int? ProcurementPMId { get; set; }

        /// <summary>
        /// Gets or sets the PlanningPMID.
        /// </summary>
        public int? PlanningPMId { get; set; }

        /// <summary>
        /// Gets or sets the ODMPIMPMID.
        /// </summary>
        public int? OdmPimpmId { get; set; }

        /// <summary>
        /// Gets or sets the SCMOwnerID.
        /// </summary>
        public int? ScmOwnerId { get; set; }

        /// <summary>
        /// Gets or sets the EngineeringDataManagementID.
        /// </summary>
        public int? EngineeringDataManagementId { get; set; }

        /// <summary>
        /// Gets or sets the BIRSProjectExplorer.
        /// </summary>
        public bool? BirsProjectExplorer { get; set; }

        /// <summary>
		/// Gets or sets the IsPulsarProduct.
		/// </summary>
		public bool IsPulsarProduct { get; set; }

        /// <summary>
        /// Gets or sets the IsExcludeIncWkfComp.
        /// </summary>
        public bool IsExcludeIncWkfComp { get; set; }

        /// <summary>
        /// Get or Set the value for TotalNoofRows.
        /// </summary>
        public int TotalNoOfRows { get; set; }

        /// <summary>
        /// Gets or sets the hw team.
        /// </summary>
        /// <value>
        /// The hw team.
        /// </value>
        public string HwTeam { get; set; }

        /// <summary>
        /// Gets or sets the product.
        /// </summary>
        /// <value>
        /// The product.
        /// </value>
        public int? ProductCount { get; set; }

        /// <summary>
        /// Gets or sets the UserInfoModel.
        /// </summary>
        public UserInfoModel UserInfo { get; set; }

        /// <summary>
        /// Gets or sets the business.
        /// </summary>
        /// <value>
        /// The business.
        /// </value>
        public string Business { get; set; }

        /// <summary>
        /// Gets or sets the FullName.
        /// </summary>
        public string FullName { get; set; }

        /// <summary>
        /// Gets or sets the PCEmail.
        /// </summary>
        public string PCEmail { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionReleaseModel.
        /// </summary>
        public ProductVersionReleaseModel ProductVersionRelease { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionReleaseMap.
        /// </summary>
        public ProductVersionReleaseMapModel ProductVersionReleaseMap { get; set; }

        /// <summary>
        /// Gets or Sets the End of Production Date.
        /// </summary>
        public DateTime? EndOfProduction { get; set; }

        /// <summary>
        /// Gets or sets the lead.
        /// </summary>
        /// <value>
        /// The lead.
        /// </value>
        public string Lead { get; set; }

        /// <summary>
        /// Gets or sets the lead identifier.
        /// </summary>
        /// <value>
        /// The lead identifier.
        /// </value>
        public int? LeadId { get; set; }

        /// <summary>
        /// Gets or sets the product deliverable.
        /// </summary>
        /// <value>
        /// The product deliverable.
        /// </value>
        public ProductDeliverableModel ProductDeliverableModel { get; set; }

        /// <summary>
        /// Gets or sets the Product Del Root.
        /// </summary>
        /// <value>
        /// The Product Del Root.
        /// </value>
        public ProductDelRootModel ProductDelRoot { get; set; }

        /// <summary>
        /// ProductVersionProductDrop
        /// </summary>
        /// <value>
        /// The ProductDrop
        /// </value>
        public ProductVersionProductDropModel ProductVersionProductDrop { get; set; }

        /// <summary>
        /// ProductDrop1
        /// </summary>
        /// <value>
        /// The ProductDrop1
        /// </value>
        public ProductDrop1Model ProductDrop1 { get; set; }

        /// <summary>
        /// ImageDefinition
        /// </summary>
        /// <value>
        /// The ImageDefinition
        /// </value>
        public ImageDefinitionModel ImageDefinition { get; set; }

        /// <summary>
        /// Images
        /// </summary>
        /// <value>
        /// The Images
        /// </value>
        public ImageModel Images { get; set; }

        /// <summary>
        /// Images
        /// </summary>
        /// <value>
        /// The Images
        /// </value>
        public RegionModel Regions { get; set; }

        /// <summary>
        /// Gets or sets the os lookup.
        /// </summary>
        /// <value>
        /// The os lookup.
        /// </value>
        public OSLookupModel OSLookup { get; set; }

        /// <summary>
        /// Image Status
        /// </summary>
        /// <value>
        /// The Image Status
        /// </value>
        public ImageStatusModel ImageStatus { get; set; }

        /// <summary>
        /// Image Status
        /// </summary>
        /// <value>
        /// The Image Status
        /// </value>
        public ImageSwTypeModel ImageSWType { get; set; }

        /// <summary>
        /// Gets or sets the PMEmployee.
        /// </summary>
        public EmployeeModel PMEmployee { get; set; }

        /// <summary>
        /// Gets or sets the SEPMEmployee.
        /// </summary>
        public EmployeeModel SepmEmployee { get; set; }

        /// <summary>
        /// Gets or sets the SMEmployee.
        /// </summary>
        public EmployeeModel SMEmployee { get; set; }

        /// <summary>
        /// Gets or sets the Product.
        /// </summary>
        public string Product { get; set; }

        /// <summary>
        /// Gets or sets the SeriesNum.
        /// </summary>
        public string SeriesNum { get; set; }

        /// <summary>
        /// Gets or sets the product family.
        /// </summary>
        /// <value>
        /// The product family.
        /// </value>
        public ProductFamilyModel ProductFamily { get; set; }

        /// <summary>
        /// Gets or sets the product status.
        /// </summary>
        /// <value>
        /// The product status.
        /// </value>
        public ProductStatusModel ProductStatus { get; set; }

        /// <summary>
        /// Gets or sets the dev center.
        /// </summary>
        /// <value>
        /// The dev center.
        /// </value>
        public DevCenterModel DevCenterData { get; set; }


        /// <summary>
        /// Gets or sets the Id as a string.
        /// </summary>
        public string stringId { get; set; }

        // <summary>
        /// Gets or sets the TeamRosterApprovers as a string.
        /// </summary>
        public string TeamRosterApprovers { get; set; }

        // <summary>
        /// Gets or sets the ProductRelease as a string.
        /// </summary>
        public string ProductRelease { get; set; }

        // <summary>
        /// Gets or sets the RTPandEMDate as a string.
        /// </summary>
        public int RTPandEMDate { get; set; }

        // <summary>
        /// Gets or sets the FactoryId as a string.
        /// </summary>
        public int FactoryId { get; set; }

        // <summary>
        /// Gets or sets the FactoryName as a string.
        /// </summary>
        public string FactoryName { get; set; }

        // <summary>
        /// Gets or sets the SelectionOrder1 as a string.
        /// </summary>
        public string SelectionOrder1 { get; set; }

        // <summary>
        /// Gets or sets the SelectionOrder2 as a string.
        /// </summary>
        public string SelectionOrder2 { get; set; }

        // <summary>
        /// Gets or sets the SelectionName2 as a string.
        /// </summary>
        public string SelectionName2 { get; set; }

        // <summary>
        /// Gets or sets the ProductIds as a string.
        /// </summary>
        public string ProductIds { get; set; }

        /// <summary>
        /// Gets or sets the kmat.
        /// </summary>
        public string kmat { get; set; }

        /// <summary>
        /// Gets or sets the BaseAVNumber.
        /// </summary>
        public string BaseAVNumber { get; set; }

        /// <summary>
        /// Gets or sets the AVParentId.
        /// </summary>
        public int AVParentId { get; set; }

        /// <summary>
        /// Gets or sets the productDOTSName.
        /// </summary>
        public string ProductDOTSName { get; set; }

        /// <summary>
        /// Gets or sets the Productline.
        /// </summary>
        public ProductLineModel Productline { get; set; }

        /// <summary>
        /// Gets or sets the BusinessSegment.
        /// </summary>
        public BusinessSegmentModel BusinessSegment { get; set; }

        /// <summary>
        /// Gets or sets the RoHS.
        /// </summary>
        public RoHSModel RoHS { get; set; }

        /// <summary>
        /// Gets or sets the GreenSpec.
        /// </summary>
        public GreenSpecModel GreenSpec { get; set; }
        

        /// <summary>
        /// Gets or sets the ProductBrand.
        /// </summary>
        public ProductBrandModel ProductBrand { get; set; }

        /// <summary>
        /// Gets or sets the Productversionplatformrtmstatus.
        /// </summary>
        public ProductversionplatformrtmstatusModel Productversionplatformrtmstatus { get; set; }

        /// <summary>
        /// Gets or sets the Partner.
        /// </summary>
        public PartnerModel Partner { get; set; }

        /// <summary>
        /// Gets or sets the employee.
        /// </summary>
        /// <value>
        /// The employee.
        /// </value>
        public EmployeeModel Employee { get; set; }

        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>
        /// The brand.
        /// </value>
        public BrandModel Brand { get; set; }

        /// <summary>
        /// Gets or sets the ProductBrand Countries.
        /// </summary>
        /// <value>
        /// The ProductBrand Countries.
        /// </value>
        public ProductBrandCountryModel[] ProductBrandCountries { get; set; }

        /// <summary>
        /// Gets or sets the OS Language.
        /// </summary>
        /// <value>
        /// The OSLanguage.
        /// </value>
        public string Language { get; set; }

        /// <summary>
        /// Gets or sets the RTM.
        /// </summary>
        /// <value>
        /// The RTM.
        /// </value>
        public string RTM { get; set; }

        /// <summary>
        /// Gets or sets the RtpDate.
        /// </summary>
        /// <value>
        /// The RtpDate.
        /// </value>
        public string RtpDate { get; set; }

        /// <summary>
        /// Gets or sets the EMDate.
        /// </summary>
        /// <value>
        /// The EMDate.
        /// </value>
        public string EMDate { get; set; }

        /// <summary>
        /// Gets or sets the Record Count.
        /// </summary>
        /// <value>
        /// The RecordCount.
        /// </value>
        public int RecordCount { get; set; }

        /// <summary>
        /// Gets or sets the Feature.
        /// </summary>
        /// <value>
        /// The Feature.
        /// </value>
        public FeatureModel Feature { get; set; }

        /// <summary>
        /// Gets or sets the PowerCardGeo
        /// </summary>
        /// <value>
        /// The PowerCordGeo.
        /// </value>
        public PowerCordGEOModel PowerCordGeo { get; set; }

        /// <summary>
        /// Gets or sets the ImageChannelPartner
        /// </summary>
        /// <value>
        /// The ImageChannelPartner.
        /// </value>
        public ImageChannelPartnerModel ImageChannelPartner { get; set; }

        /// <summary>
        /// Gets or sets the ProductReleaseDetails.
        /// </summary>
        /// <value>
        /// The ProductReleaseDetails.
        /// </value>
        public ProductReleaseModel ProductReleaseDetails { get; set; }

        /// <summary>
        /// Gets or sets the ImageSWTypeDetails.
        /// </summary>
        /// <value>
        /// The ImageSWTypeDetails.
        /// </value>
        public ImageSwTypeModel ImageSWTypeDetails { get; set; }

        /// <summary>
        /// Gets or sets the ImageTypeDetails.
        /// </summary>
        /// <value>
        /// The ImageTypeDetails.
        /// </value>
        public ImageTypeModel ImageTypeDetails { get; set; }


        /// <summary>
        /// Gets or sets the ImageDriveDefinitionDetails.
        /// </summary>
        /// <value>
        /// The ImageDriveDefinitionDetails.
        /// </value>
        public ImageDriveDefinitionModel ImageDriveDefinitionDetails { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableCategory.
        /// </summary>
        /// <value>
        /// The DeliverableCategory.
        /// </value>
        public DeliverableCategoryModel DeliverableCategory { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableRoot.
        /// </summary>
        /// <value>
        /// The DeliverableRoot.
        /// </value>
        public DeliverableRootModel DeliverableRoot { get; set; }

        /// <summary>
        /// Gets or sets the DeliverableRoot.
        /// </summary>
        /// <value>
        /// The DeliverableRoot.
        /// </value>
        public int OSId { get; set; }

        /// <summary>
        /// Gets or sets the AVDetail.
        /// </summary>
        /// <value>
        /// The AVDetail.
        /// </value>
        public AVDetailModel AVDetail { get; set; }

        /// <summary>
        /// Gets or sets the WhyIncluded.
        /// </summary>
        /// <value>
        /// The WhyIncluded.
        /// </value>
        public string WhyIncluded { get; set; }

        /// <summary>
        /// Gets or sets the WhyIncluded.
        /// </summary>
        /// <value>
        /// The WhyIncluded.
        /// </value>
        public int? Months { get; set; }

        /// <summary>
        /// Gets or sets the BusinessId.
        /// </summary>
        /// <value>
        /// The BusinessId.
        /// </value>
        public int? BusinessId { get; set; }

        /// <summary>
        /// Gets or sets the Email.
        /// </summary>
        public byte? Email { get; set; }

        /// <summary>
        /// Gets or sets the AvId.
        /// </summary>
        /// <value>
        /// The AvId.
        /// </value>
        public int AvId { get; set; }

        /// <summary>
        /// Gets or sets the Status.
        /// </summary>
        /// <value>
        /// The Status.
        /// </value>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the LocSharedAV.
        /// </summary>
        /// <value>
        /// The LocSharedAV.
        /// </value>
        public bool LocSharedAV { get; set; }

        /// <summary>
        /// Gets or sets the LocStatus.
        /// </summary>
        /// <value>
        /// The LocStatus.
        /// </value>
        public string LocStatus { get; set; }

        /// <summary>
        /// Gets or sets the InImage.
        /// </summary>
        /// <value>
        /// The InImage.
        /// </value>
        public bool InImage { get; set; }

        /// <summary>
        /// Gets or sets the IsLocUsedIOSCM.
        /// </summary>
        /// <value>
        /// The IsLocUsedIOSCM.
        /// </value>
        public int IsLocUsedIOSCM { get; set; }

        /// <summary>
        /// Gets or sets the IsUsedIOSCM.
        /// </summary>
        /// <value>
        /// The IsUsedIOSCM.
        /// </value>
        public int IsUsedIOSCM { get; set; }

        /// <summary>
        /// Gets or sets the ErrorMessage.
        /// </summary>
        /// <value>
        /// The ErrorMessage.
        /// </value>
        public string ErrorMessage { get; set; }

        /// Gets or sets the IsActive.
        /// </summary>
        /// <value>
        /// The IsActive.
        /// </value>
        public byte? IsActive { get; set; }

        /// <summary>
        /// Gets or sets the stable consistent.
        /// </summary>
        /// <value>
        /// The stable consistent.
        /// </value>
        public byte? StableConsistent { get; set; }

        /// Gets or sets the AgencyStatusModel.
        /// </summary>
        /// <value>
        /// The AgencyStatusModel.
        /// </value>
        public AgencyStatusModel AgencyStatus { get; set; }

        /// Gets or sets the ImageChangesModel.
        /// </summary>
        /// <value>
        /// The ImageChange.
        /// </value>
        public ImageChangesModel ImageChange { get; set; }

        /// Gets or sets the DeliverableIssueModel.
        /// </summary>
        /// <value>
        /// The DeliverableIssue.
        /// </value>
        public DeliverableIssueModel DeliverableIssue { get; set; }

        /// <summary>
        /// Gets or sets the IsParent.
        /// </summary>
        /// <value>
        /// The IsParent.
        /// </value>
        public bool IsParent { get; set; }

        /// <summary>
        /// Gets or sets the priority.
        /// </summary>
        /// <value>
        /// The priority.
        /// </value>
        public string Priority { get; set; }

        /// <summary>
        /// Gets or sets the summary date.
        /// </summary>
        /// <value>
        /// The summary date.
        /// </value>
        public DateTime SummaryDate { get; set; }

        /// <summary>
        /// Gets or sets LongName
        /// </summary>
        /// <value>
        /// The LongName.
        /// </value>
        public string LongName { get; set; }


        /// <summary>
        /// Gets or sets ShortName
        /// </summary>
        /// <value>
        /// The LongName.
        /// </value>
        public string ShortName { get; set; }

        /// <summary>
        /// Gets or sets FamilyName
        /// </summary>
        /// <value>
        /// The FamilyName.
        /// </value>
        public string FamilyName { get; set; }

        /// <summary>
        /// Gets or sets BrandName
        /// </summary>
        /// <value>
        /// The BrandName.
        /// </value>
        public string BrandName { get; set; }

        /// <summary>
        /// Gets or sets LogoBadge
        /// </summary>
        /// <value>
        /// The LogoBadge
        /// </value>
        public string LogoBadge { get; set; }

        /// <summary>
        /// Gets or sets the type of the division.
        /// </summary>
        /// <value>
        /// The type of the division.
        /// </value>
        public string DivisionType { get; set; }

        /// <summary>
        /// Gets or sets the generation.
        /// </summary>
        /// <value>
        /// The generation.
        /// </value>
        public string Generation { get; set; }

        /// <summary>
        /// Gets or sets the series.
        /// </summary>
        /// <value>
        /// The series.
        /// </value>
        public string Series { get; set; }

        /// <summary>
        /// Gets or sets the product program.
        /// </summary>
        /// <value>
        /// The product program.
        /// </value>
        public ProductProgramModel ProductProgram { get; set; }

        /// <summary>
        /// Gets or sets the Program.
        /// </summary>
        /// <value>
        /// The Program.
        /// </value>
        public ProgramModel Program { get; set; }
    }
}
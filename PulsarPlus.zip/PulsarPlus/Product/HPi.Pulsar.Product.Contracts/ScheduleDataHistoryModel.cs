// ***********************************************************************************************************
// Assembly         : HPi.Pulsar.Product.Contracts
// Author           : Shanmugaraj.M(auth\maniseka)
// Created          : 11/07/2017
// Last Modified By : 
// Last Modified On : 
// Created for      : HPi Pulsar
// ***********************************************************************************************************
// <copyright file="ScheduleDataHistoryModel.cs" company="HP">
//     Copyright ©  2016 - 2017
// </copyright>
// <summary></summary>
// ***********************************************************************************************************

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class ScheduleDataHistoryModel.
    /// </summary>
    public class ScheduleDataHistoryModel
    {
        /// <summary>
        /// Gets or sets the Scheduledatahistoryid.
        /// </summary>
        /// <value>
        /// The scheduledatahistory identifier.
        /// </value>
        public int ScheduleDataHistoryId { get; set; }

        /// <summary>
        /// Gets or sets the Scheduledataid.
        /// </summary>
        /// <value>
        /// The scheduledata identifier.
        /// </value>
        public int ScheduleDataId { get; set; }

        /// <summary>
        /// Gets or sets the Scheduledefinitiondataid.
        /// </summary>
        /// <value>
        /// The scheduledefinitiondata identifier.
        /// </value>
        public int? ScheduleDefinitionDataId { get; set; }

        /// <summary>
        /// Gets or sets the Oldprojectedstartdt.
        /// </summary>
        /// <value>
        /// The oldprojectedstartdt.
        /// </value>
        public DateTime? OldProjectedStartDt { get; set; }

        /// <summary>
        /// Gets or sets the Newprojectedstartdt.
        /// </summary>
        /// <value>
        /// The newprojectedstartdt.
        /// </value>
        public DateTime? NewProjectedStartDt { get; set; }

        /// <summary>
        /// Gets or sets the Oldprojectedenddt.
        /// </summary>
        /// <value>
        /// The oldprojectedenddt.
        /// </value>
        public DateTime? OldProjectedEndDt { get; set; }

        /// <summary>
        /// Gets or sets the Newprojectedenddt.
        /// </summary>
        /// <value>
        /// The newprojectedenddt.
        /// </value>
        public DateTime? NewProjectedEndDt { get; set; }

        /// <summary>
        /// Gets or sets the Oldactualstartdt.
        /// </summary>
        /// <value>
        /// The oldactualstartdt.
        /// </value>
        public DateTime? OldActualStartDt { get; set; }

        /// <summary>
        /// Gets or sets the Newactualstartdt.
        /// </summary>
        /// <value>
        /// The newactualstartdt.
        /// </value>
        public DateTime? NewActualStartDt { get; set; }

        /// <summary>
        /// Gets or sets the Oldactualenddt.
        /// </summary>
        /// <value>
        /// The oldactualenddt.
        /// </value>
        public DateTime? OldActualEndDt { get; set; }

        /// <summary>
        /// Gets or sets the Newactualenddt.
        /// </summary>
        /// <value>
        /// The newactualenddt.
        /// </value>
        public DateTime? NewActualEndDt { get; set; }

        /// <summary>
        /// Gets or sets the Notes.
        /// </summary>
        /// <value>
        /// The notes.
        /// </value>
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the Comments.
        /// </summary>
        /// <value>
        /// The comments.
        /// </value>
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets the Lastupduser.
        /// </summary>
        /// <value>
        /// The lastupduser.
        /// </value>
        public string LastUpdUser { get; set; }

        /// <summary>
        /// Gets or sets the Lastupddate.
        /// </summary>
        /// <value>
        /// The lastupddate.
        /// </value>
        public DateTime LastUpdDate { get; set; }

        /// <summary>
        /// Gets or sets the schedule data.
        /// </summary>
        /// <value>
        /// The schedule data.
        /// </value>
        public ScheduleDataModel ScheduleData { get; set; }

        /// <summary>
        /// Gets or sets the user information.
        /// </summary>
        /// <value>
        /// The user information.
        /// </value>
        public UserInfoModel UserInfo { get; set; }
    }
}
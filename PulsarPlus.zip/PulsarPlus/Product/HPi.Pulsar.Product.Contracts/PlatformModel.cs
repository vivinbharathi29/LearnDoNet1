

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>PlatformModel</para>
    /// </summary>
    public class PlatformModel
    {
		/// <summary>
		/// Gets or sets the PlatformID.
		/// </summary>
		public int PlatformId { get; set; }

		/// <summary>
		/// Gets or sets the ProductFamily.
		/// </summary>
		public string ProductFamily { get; set; }

		/// <summary>
		/// Gets or sets the PCA.
		/// </summary>
		public string Pca { get; set; }

		/// <summary>
		/// Gets or sets the CategoryID.
		/// </summary>
		public int CategoryId { get; set; }

		/// <summary>
		/// Gets or sets the MarketingName.
		/// </summary>
		public string MarketingName { get; set; }

        /// <summary>
		/// Gets or sets the BrandName.
		/// </summary>
		public string BrandName { get; set; }

        /// <summary>
        /// Gets or sets the Model.
        /// </summary>
        public string Model { get; set; }

		/// <summary>
		/// Gets or sets the IntroYear.
		/// </summary>
		public string IntroYear { get; set; }

		/// <summary>
		/// Gets or sets the SystemID.
		/// </summary>
		public string SystemId { get; set; }

		/// <summary>
		/// Gets or sets the Lock.
		/// </summary>
		public bool Lock { get; set; }

		/// <summary>
		/// Gets or sets the Creator.
		/// </summary>
		public string Creator { get; set; }

		/// <summary>
		/// Gets or sets the Updater.
		/// </summary>
		public string Updater { get; set; }

		/// <summary>
		/// Gets or sets the TimeCreated.
		/// </summary>
		public string TimeCreated { get; set; }

		/// <summary>
		/// Gets or sets the TimeChanged.
		/// </summary>
		public string TimeChanged { get; set; }

		/// <summary>
		/// Gets or sets the MktFullName.
		/// </summary>
		public string MktFullName { get; set; }

		/// <summary>
		/// Gets or sets the MktNameMaster.
		/// </summary>
		public string MktNameMaster { get; set; }

		/// <summary>
		/// Gets or sets the BIOSName.
		/// </summary>
		public string BiosName { get; set; }

		/// <summary>
		/// Gets or sets the SoftpaqNeedDate.
		/// </summary>
		public string SoftpaqNeedDate { get; set; }

		/// <summary>
		/// Gets or sets the Active.
		/// </summary>
		public bool Active { get; set; }

		/// <summary>
		/// Gets or sets the ChinaGPIdentifier.
		/// </summary>
		public string ChinaGPIdentifier { get; set; }

		/// <summary>
		/// Gets or sets the WebCycle.
		/// </summary>
		public string WebCycle { get; set; }

		/// <summary>
		/// Gets or sets the ConsumerDT.
		/// </summary>
		public short? ConsumerDT { get; set; }

		/// <summary>
		/// Gets or sets the Brand.
		/// </summary>
		public int Brand { get; set; }

		/// <summary>
		/// Gets or sets the TouchID.
		/// </summary>
		public int? TouchId { get; set; }

		/// <summary>
		/// Gets or sets the PCAGraphicsType.
		/// </summary>
		public string PcaGraphicsType { get; set; }

		/// <summary>
		/// Gets or sets the ModelNumber.
		/// </summary>
		public string ModelNumber { get; set; }

		/// <summary>
		/// Gets or sets the EMMConboard.
		/// </summary>
		public bool? EmmConboard { get; set; }

        /// <summary>
		/// Gets or sets the EmmConboardText.
		/// </summary>
		public string EmmConboardText { get; set; }

        /// <summary>
        /// Gets or sets the MemoryOnboard.
        /// </summary>
        public string MemoryOnboard { get; set; }

		/// <summary>
		/// Gets or sets the GraphicCapacity.
		/// </summary>
		public string GraphicCapacity { get; set; }

        /// <summary>
        /// Gets or sets the ProductBrandId.
        /// </summary>
        public int ProductBrandId { get; set; }

        /// <summary>
        /// Gets or sets the ActiveBaseUnits.
        /// </summary>
        public int ActiveBaseUnits { get; set; }

        /// <summary>
        /// Gets or sets the BaseUnitCount.
        /// </summary>
        public int BaseUnitCount { get; set; }

        /// <summary>
		/// Gets or sets the SystemBoardName.
		/// </summary>
		public string SystemBoardName { get; set; }

        /// <summary>
		/// Gets or sets the GenericName.
		/// </summary>
		public string GenericName { get; set; }

        /// <summary>
		/// Gets or sets the ChassisId.
		/// </summary>
		public int ChassisId { get; set; }

        /// <summary>
		/// Gets or sets the Chassis.
		/// </summary>
		public string Chassis { get; set; }

        /// <summary>
		/// Gets or sets the Display.
		/// </summary>
		public string Display { get; set; }

        /// <summary>
		/// Gets or sets the ProdutVersionPlatformId.
		/// </summary>
		public int ProdutVersionPlatformId { get; set; }

        /// <summary>
        /// Gets or sets the Deployment.
        /// </summary>
        public string Deployment { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the SOAROId.
        /// </summary>
        public int SOAROId { get; set; }

        /// <summary>
        /// Gets or sets the SOARProduct.
        /// </summary>
        public string SOARProduct { get; set; }
        
        /// <summary>
        /// Gets or sets the Comments.
        /// </summary>
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets the SystemIdComments.
        /// </summary>
        public string SystemIdComments { get; set; }

        /// <summary>
        /// Gets or sets the SelSegments.
        /// </summary>
        public string SelSegments { get; set; }

        /// <summary>
        /// Gets or sets the SelSegmentIds.
        /// </summary>
        public string SelSegmentIds { get; set; }

        /// <summary>
        /// Gets or sets the StatusId.
        /// </summary>
        public int StatusId { get; set; }

        /// <summary>
        /// Gets or sets the Status.
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the AdminEdit.
        /// </summary>
        public int AdminEdit { get; set; }

        /// <summary>
        /// Gets or sets the AdminEdit.
        /// </summary>
        public DateTime FullSoftpaqNeedDate { get; set; }
    }
}
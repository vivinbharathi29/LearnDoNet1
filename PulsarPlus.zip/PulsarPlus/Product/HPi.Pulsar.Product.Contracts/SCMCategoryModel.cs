

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>SCMCategoryModel</para>
    /// </summary>
    public class ScmCategoryModel
    {
        /// <summary>
        /// Gets or sets the SCMCategoryID.
        /// </summary>
        public int ScmCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the Abbreviation.
        /// </summary>
        public string Abbreviation { get; set; }

        /// <summary>
        /// Gets or sets the Created.
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// Gets or sets the CreatedBy.
        /// </summary>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Updated.
        /// </summary>
        public DateTime Updated { get; set; }

        /// <summary>
        /// Gets or sets the UpdatedBy.
        /// </summary>
        public string UpdatedBy { get; set; }

        /// <summary>
        /// Gets or sets the Disabled.
        /// </summary>
        public DateTime? Disabled { get; set; }

        /// <summary>
        /// Gets or sets the DisabledBy.
        /// </summary>
        public string DisabledBy { get; set; }

        /// <summary>
        /// Gets or sets the InheritProductLine.
        /// </summary>
        public bool? InheritProductLine { get; set; }

        /// <summary>
        /// Gets or sets the ConfigRules.
        /// </summary>
        public string ConfigRules { get; set; }

        /// <summary>
        /// Gets or sets the CatMin.
        /// </summary>
        public int? CatMin { get; set; }

        /// <summary>
        /// Gets or sets the CatMax.
        /// </summary>
        public int? CatMax { get; set; }

        /// <summary>
        /// Gets or sets the SortOrder.
        /// </summary>
        public int SortOrder { get; set; }

        /// <summary>
        /// Gets or sets the PhWebCategoryID.
        /// </summary>
        public int? PhWebCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the ParentCategoryID.
        /// </summary>
        public int? ParentCategoryId { get; set; }

        /// <summary>
        /// Gets or sets the GEOID.
        /// </summary>
        public int? GeoId { get; set; }

        /// <summary>
        /// Gets or sets the OSID.
        /// </summary>
        public int? OSId { get; set; }

        /// <summary>
		/// Gets or sets the AssignedProductLine.
		/// </summary>
		public string AssignedProductLine { get; set; }

        /// <summary>
        /// Gets or sets the NoOfProductLine.
        /// </summary>
        public int NoOfProductLine { get; set; }

        /// Gets or sets the SCMDetailPulsarModel.
        /// </summary>
        /// <value>
        /// The ScmDetailPulsar.
        /// </value>
        public SCMDetailPulsarModel ScmDetailPulsar { get; set; }
    }
}
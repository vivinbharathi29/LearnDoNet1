

namespace HPi.Pulsar.Product.Contracts
{
    /// <summary>
    /// <para>ProductLeadRootExceptionsModel</para>
    /// </summary>
    public class ProductLeadRootExceptionModel
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ProductVersionID.
		/// </summary>
		public int ProductVersionId { get; set; }

		/// <summary>
		/// Gets or sets the DeliverableRootID.
		/// </summary>
		public int? DeliverableRootId { get; set; }

		/// <summary>
		/// Gets or sets the DeliverableVersionID.
		/// </summary>
		public int? DeliverableVersionId { get; set; }

		/// <summary>
		/// Gets or sets the Comments.
		/// </summary>
		public string Comments { get; set; }

        /// <summary>
		/// Gets or sets the DeliverableVersionIds.
		/// </summary>
		public string DeliverableVersionIds { get; set; }

        /// <summary>
        /// Gets or sets the Type.
        /// </summary>
        public int Type { get; set; }

        /// <summary>
		/// Gets or sets the ReleaseId.
		/// </summary>
		public int? ReleaseId { get; set; }

    }
}
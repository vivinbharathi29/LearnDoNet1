

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class ProductReleaseModel.
    /// </summary>
    public class ProductReleaseModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the ProductversionID.
        /// </summary>
        /// <value>
        /// The productversion identifier.
        /// </value>
        public int ProductversionId { get; set; }

        /// <summary>
        /// Gets or sets the ReleaseID.
        /// </summary>
        /// <value>
        /// The release identifier.
        /// </value>
        public int ReleaseId { get; set; }

        /// <summary>
        /// Gets or sets the PDDLocked.
        /// </summary>
        /// <value>
        ///   <c>true</c> if [PDD locked]; otherwise, <c>false</c>.
        /// </value>
        public bool PDDLocked { get; set; }

        /// <summary>
        /// Gets or sets the PDDLockedDate.
        /// </summary>
        /// <value>
        /// </value>
        public DateTime PDDLockedDate { get; set; }

        /// <summary>
        /// Gets or sets the ReleaseName.
        /// </summary>
        /// <value>
        /// The release ReleaseName.
        /// </value>
        public string ReleaseName { get; set; }
    }
}
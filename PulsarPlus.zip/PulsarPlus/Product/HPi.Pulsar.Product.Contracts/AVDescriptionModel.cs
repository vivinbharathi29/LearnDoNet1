﻿namespace HPi.Pulsar.Product.Contracts
{
    public class AVDescriptionModel
    {
        public AVDetailModel AVDetail { get; set; }

        public AVDetailProductBrandModel AVDetailProductBrand { get; set; }

        public ProductBrandModel ProductBrand { get; set; }
    }
}

﻿

using System;

namespace HPi.Pulsar.Product.Contracts
{
    /// <summary>
    /// ProductVersionReleaseModel
    /// </summary>
    public class ProductVersionReleaseModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the Name.
        /// </summary>
        public string Name { get; set; }


        /// <summary>
        /// Gets or sets the ReleaseCount.
        /// </summary>
        public int ReleaseCount { get; set; }

        /// <summary>
        /// Gets or sets the Active.
        /// </summary>
        public byte? Active { get; set; }

        /// <summary>
        /// Gets or sets the BusinessSegmentID.
        /// </summary>
        public int? BusinessSegmentId { get; set; }

        /// <summary>
        /// Gets or sets the ReleaseMonth.
        /// </summary>
        public int ReleaseMonth { get; set; }

        /// <summary>
        /// Gets or sets the ReleaseYear.
        /// </summary>
        public int ReleaseYear { get; set; }

        /// <summary>
        /// Gets or sets the release identifier.
        /// </summary>
        /// <value>
        /// The release identifier.
        /// </value>
        public int ReleaseId { get; set; }

        /// <summary>
        /// Gets or sets the on av.
        /// </summary>
        /// <value>
        /// The on av.
        /// </value>
        public int OnAV { get; set; }

        /// <summary>
        /// Gets or sets the product deliverable release.
        /// </summary>
        /// <value>
        /// The product deliverable release.
        /// </value>
        public ProductDeliverableReleaseModel ProductDeliverableRelease { get; set; }

        /// <summary>
        /// Gets or sets the product version.
        /// </summary>
        /// <value>
        /// The product version.
        /// </value>
        public ProductVersionModel ProductVersion { get; set; }
    }
}
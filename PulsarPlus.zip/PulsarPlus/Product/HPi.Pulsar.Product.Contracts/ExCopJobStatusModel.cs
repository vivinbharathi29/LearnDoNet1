namespace HPi.Pulsar.Product.Contracts
{
    public class ExCopJobStatusModel
    {
        public int Id { get; set; }

        public string Status { get; set; }

        public bool? FailedStatus { get; set; }

        public bool? CompleteStatus { get; set; }

        public int? NotificationDelay { get; set; }
    }
}
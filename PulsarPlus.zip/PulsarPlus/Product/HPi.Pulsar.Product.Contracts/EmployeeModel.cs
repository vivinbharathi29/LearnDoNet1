﻿namespace HPi.Pulsar.Product.Contracts
{
    using System;

    public class EmployeeModel
    {
        public int Id { get; set; }

        public string EmployeeNumber { get; set; }

        public string NtName { get; set; }

        public string Domain { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Office { get; set; }

        public string Phone { get; set; }

        public short? ManagerLevel { get; set; }

        public int? ManagerId { get; set; }

        public byte? Active { get; set; }

        public int? WorkgroupId { get; set; }

        public bool? ActiveInGal { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Country { get; set; }

        public int? ImpersonateId { get; set; }

        public DateTime? Created { get; set; }

        public string Name { get; set; }

        public byte? Division { get; set; }

        public int? IrsUserId { get; set; }

        public int? PartnerId { get; set; }

        public bool? ApprovalSection { get; set; }

        public bool? PastDueSection { get; set; }

        public bool? WorkingSection { get; set; }

        public bool? DueThisWeekSection { get; set; }

        public bool? AllOpenSection { get; set; }

        public bool? ISubmittedSection { get; set; }

        public bool? ClosedSection { get; set; }

        public bool? ProposedSection { get; set; }

        public int? LastStatusSection { get; set; }

        public string LastStatusCategory { get; set; }

        public int? StatusDelegate { get; set; }

        public byte? PipmAlertSection { get; set; }

        public byte? PinewRequestSection { get; set; }

        public int? PiscripterSection { get; set; }

        public byte? PidbTeamSection { get; set; }

        public byte? PireAssignedSection { get; set; }

        public string Favorites { get; set; }

        public short? FavCount { get; set; }

        public bool? PostRtmSection { get; set; }

        public bool? OtsSubmittedSection { get; set; }

        public bool? OtsOwnerSection { get; set; }

        public bool? OtsDeliverableSection { get; set; }

        public bool? SystemAdmin { get; set; }

        public DateTime? ResetPassword { get; set; }

        public bool? PreinstallPM { get; set; }

        public bool? CanReleaseLocalizations { get; set; }

        public bool? FindManager { get; set; }

        public bool? CommodityPM { get; set; }

        public bool? ProgramCoordinator { get; set; }

        public string DefaultProductTab { get; set; }

        public bool? AccessoryPM { get; set; }

        public int? TodayPageLoad { get; set; }

        public bool? SCFactoryEngineer { get; set; }

        public bool? MitTestLead { get; set; }

        public bool? WhqlTestTeam { get; set; }

        public byte? EngCoordinator { get; set; }

        public bool? FunctionalTestmadtSection { get; set; }

        public bool? FunctionalTestHelpAndSupportSection { get; set; }

        public bool? FunctionalTest3rdPartySection { get; set; }

        public bool? FunctionalTestOtherSection { get; set; }

        public bool? FunctionalTestDeveloperSection { get; set; }

        public bool? FunctionalTestUserGuidesSection { get; set; }

        public bool? FunctionalTest3rdPartyConsSection { get; set; }

        public bool? ServicePM { get; set; }

        public bool? ProcurementEngineer { get; set; }

        public int? PMImpersonate { get; set; }

        public bool? FunctionalTestToolsSection { get; set; }

        public bool? WwanEngineer { get; set; }

        public int? DefaultWorkingListProduct { get; set; }

        public bool? ServiceCommodityManager { get; set; }

        public DateTime? LastActivity { get; set; }

        public byte? OdmLoginStatus { get; set; }

        public bool? ToolDeveloper { get; set; }

        public string QualityCenterId { get; set; }

        public bool? FtpAccessRequested { get; set; }

        public bool? ServiceCoordinator { get; set; }

        public bool? FunctionalTestMultimediaSection { get; set; }

        public bool? BpiaApprover { get; set; }

        public bool? FthwEnablingSection { get; set; }

        public bool? FTIntelTechnologiesSection { get; set; }

        public bool? FTMultimediaAppsSection { get; set; }

        public bool? FTSecuritySection { get; set; }

        public bool? FTBiosSection { get; set; }

        public bool? FTThinClientSection { get; set; }

        public bool? AccountSuspended { get; set; }

        public int? CMImpersonate { get; set; }

        public int? PCImpersonate { get; set; }

        public int? PhWebImpersonate { get; set; }

        public int? MarketingImpersonate { get; set; }

        public bool? FTVirtualizationSection { get; set; }

        public bool? FunctionalTest3rdPartyInternalSection { get; set; }

        public string OtherPartnerNames { get; set; }

        public byte? SourceSystem { get; set; }

        public bool? Pulsar { get; set; }

        public bool? DevTeam { get; set; }

        public string Role { get; set; }

        public string DevManagerEmail { get; set; }

        public string DevManagerName { get; set; }

        public string Developer { get; set; }

        public string DeveloperEmail { get; set; }

        public string FullName { get; set; }

        public int UserId { get; set; }

        public int SMid { get; set; }

        public int PrimaryTeam { get; set; }

        public int DisplayOrder { get; set; }

        public int TotalNoOfRows { get; set; }

        public ConsumerOrCommercial SystemTeam { get; set; }

        public ConsumerOrCommercial Extended { get; set; }

        public ConsumerOrCommercial Sepm { get; set; }

        public ConsumerOrCommercial Superuser { get; set; }

        public ConsumerOrCommercial SwDevelopers { get; set; }

        public ConsumerOrCommercial HwDevelopers { get; set; }

        public int HpUsers { get; set; }

        public int NonHpUsers { get; set; }

        public int UsersInventec { get; set; }

        public int UsersCompal { get; set; }

        public int UsersFlextronics { get; set; }

        public int UsersQuanta { get; set; }

        public int UsersWistron { get; set; }

        public int UsersFoxconn { get; set; }

        public int UsersModus { get; set; }

        public string PmName { get; set; }

        public int PmId { get; set; }

        public string PreinstallOwner { get; set; }

        public string ServiceManager { get; set; }

        public string StlName { get; set; }

        public string SepmName { get; set; }

        public string SepeName { get; set; }

        public string PinPm { get; set; }

        public string SetlName { get; set; }

        public string PdmName { get; set; }

        public string CommodityManager { get; set; }
    }

    public class ConsumerOrCommercial
    {
        public int Consumer { get; set; }

        public int Commercial { get; set; }
    }
}


namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ServiceSpareCategoryModel</para>
    /// </summary>
    public class ServiceSpareCategoryModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Gets or sets the CategoryName.
		/// </summary>
		public string CategoryName { get; set; }

		/// <summary>
		/// Gets or sets the SortOrder.
		/// </summary>
		public int? SortOrder { get; set; }

		/// <summary>
		/// Gets or sets the DeliverableCategoryId.
		/// </summary>
		public int? DeliverableCategoryId { get; set; }


    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HPi.Pulsar.Product.Contracts
{
    public class ProdBrandLocalizationModel
    {
        /// <summary>
        /// Gets or sets the ColumnData identifier.
        /// </summary>
        /// <value>
        /// The ColumnData identifier.
        /// </value>
        public List<Dictionary<string, string>> ColumnData { get; set; }

        /// <summary>
        /// Gets or sets the RowData identifier.
        /// </summary>
        /// <value>
        /// The RowData identifier.
        /// </value>
        public List<Dictionary<string, object>> RowData { get; set; }
    }
}

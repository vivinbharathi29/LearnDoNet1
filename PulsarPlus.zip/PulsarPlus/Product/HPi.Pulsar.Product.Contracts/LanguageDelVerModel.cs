using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class LanguageDelVerModel
    {
        public int Id { get; set; }

        public int? LanguageId { get; set; }

        public int? DeliverableVersionId { get; set; }

        public int? MilestoneId { get; set; }

        public byte? WorkflowComplete { get; set; }

        public byte? Failed { get; set; }

        public string Dash { get; set; }

        public int? Sequence { get; set; }

        public int? DmiNumber { get; set; }

        public int? PC9XCompliant { get; set; }

        public DateTime? PmrDate { get; set; }

        public string PmrPath { get; set; }

        public int? MasterId { get; set; }

        public string SoftpaqNumber { get; set; }

        public string Supersedes { get; set; }

        public string PartNumber { get; set; }

        public bool? PmrComplete { get; set; }

        public string CDKitNumber { get; set; }

        public int? PNRev { get; set; }

        public string CDPartNumber { get; set; }

        public string FbiPath { get; set; }

        public int? IrsId { get; set; }

        public bool? TranslateOnly { get; set; }

        public DateTime? Deactivated { get; set; }

        public string DeactivatedBy { get; set; }

        public DateTime? Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }

        public string IrsPartNumber { get; set; }

        public int? IrsRootId { get; set; }

        public int? IrsVersionId { get; set; }

        public int? IrsRevisionId { get; set; }

        public string IrsPath { get; set; }

        public DeliverableWorkflowDefinitionModel DeliverableWorkflowDefinitions { get; set; }

        public LanguageModel Language { get; set; }
    }
}


namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>RequirementModel</para>
    /// </summary>
    public class RequirementModel
    {
		/// <summary>
		/// Gets or sets the Id.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the Name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the CategoryId.
		/// </summary>
		public int? CategoryId { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdated.
		/// </summary>
		public DateTime? LastUpdated { get; set; }

		/// <summary>
		/// Gets or sets the SpecTemplate.
		/// </summary>
		public string SpecTemplate { get; set; }

		/// <summary>
		/// Gets or sets the ProcessRequirement.
		/// </summary>
		public bool ProcessRequirement { get; set; }

		/// <summary>
		/// Gets or sets the DisplayOrder.
		/// </summary>
		public int? DisplayOrder { get; set; }

		/// <summary>
		/// Gets or sets the Active.
		/// </summary>
		public bool? Active { get; set; }

        /// <summary>
        /// Gets or sets the added requirement ids.
        /// </summary>
        /// <value>
        /// The added requirement ids.
        /// </value>
        public string AddedRequirementIds { get; set; }

        /// <summary>
        /// Gets or sets the removed requirement ids.
        /// </summary>
        /// <value>
        /// The removed requirement ids.
        /// </value>
        public string RemovedRequirementIds { get; set; }
    }
}
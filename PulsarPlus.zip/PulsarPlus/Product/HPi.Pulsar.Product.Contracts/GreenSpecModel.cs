﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class GreenSpecModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int? Displayorder { get; set; }

        public bool? Active { get; set; }

        public string MatrixBGColor { get; set; }

        public DateTime CreateDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime DeleteddDate { get; set; }

        public string DeletedBy { get; set; }
    }
}

﻿namespace HPi.Pulsar.Product.Contracts
{
    public class CommodityStatusModel
    {
        public ProductDeliverableModel ProductDeliverable { get; set; }

        public DeliverableVersionModel DeliverableVersion { get; set; }

        public ProductVersionModel ProductVersion { get; set; }

        public VendorModel Vendor { get; set; }

        public DeliverableRootModel DeliverableRoot { get; set; }

        public DeliverableCategoryModel DeliverableCategory { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }

        public int BatchMode { get; set; }
    }
}

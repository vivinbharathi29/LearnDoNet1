
namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>RoleMemberModel</para>
    /// </summary>
    public class RoleMemberModel
    {
		/// <summary>
		/// Gets or sets the UserId.
		/// </summary>
		public int UserId { get; set; }

		/// <summary>
		/// Gets or sets the RoleId.
		/// </summary>
		public int RoleId { get; set; }

		/// <summary>
		/// Gets or sets the Created.
		/// </summary>
		public DateTime Created { get; set; }

		/// <summary>
		/// Gets or sets the CreatedBy.
		/// </summary>
		public string CreatedBy { get; set; }


    }
}


namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// ProductDelRootModel
    /// </summary>
    public class ProductDelRootModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ProductVersionID.
		/// </summary>
		public int ProductVersionId { get; set; }

		/// <summary>
		/// Gets or sets the DeliverableRootID.
		/// </summary>
		public int DeliverableRootId { get; set; }

		/// <summary>
		/// Gets or sets the Preinstall.
		/// </summary>
		public bool? Preinstall { get; set; }

		/// <summary>
		/// Gets or sets the Preload.
		/// </summary>
		public bool? Preload { get; set; }

		/// <summary>
		/// Gets or sets the DropInBox.
		/// </summary>
		public bool? DropInBox { get; set; }

		/// <summary>
		/// Gets or sets the Web.
		/// </summary>
		public bool? Web { get; set; }

		/// <summary>
		/// Gets or sets the TargetNotes.
		/// </summary>
		public string TargetNotes { get; set; }

		/// <summary>
		/// Gets or sets the ImageSummary.
		/// </summary>
		public string ImageSummary { get; set; }

		/// <summary>
		/// Gets or sets the Images.
		/// </summary>
		public string Images { get; set; }

		/// <summary>
		/// Gets or sets the SelectiveRestore.
		/// </summary>
		public bool? SelectiveRestore { get; set; }

		/// <summary>
		/// Gets or sets the ARCD.
		/// </summary>
		public bool? ARCD { get; set; }

		/// <summary>
		/// Gets or sets the OOCRelease.
		/// </summary>
		public bool? OocRelease { get; set; }

		/// <summary>
		/// Gets or sets the PostRTMStatus.
		/// </summary>
		public byte? PostRtmStatus { get; set; }

		/// <summary>
		/// Gets or sets the Base.
		/// </summary>
		public string Base { get; set; }

		/// <summary>
		/// Gets or sets the Spin.
		/// </summary>
		public string Spin { get; set; }

		/// <summary>
		/// Gets or sets the Subassembly.
		/// </summary>
		public string Subassembly { get; set; }

		/// <summary>
		/// Gets or sets the DeveloperNotificationStatus.
		/// </summary>
		public byte? DeveloperNotificationStatus { get; set; }

		/// <summary>
		/// Gets or sets the DRDVD.
		/// </summary>
		public bool? DRDvd { get; set; }

		/// <summary>
		/// Gets or sets the RACDEMEA.
		/// </summary>
		public bool? RACDEmea { get; set; }

		/// <summary>
		/// Gets or sets the RACDAPD.
		/// </summary>
		public bool? RACDApd { get; set; }

		/// <summary>
		/// Gets or sets the RACDAmericas.
		/// </summary>
		public bool? RACDAmericas { get; set; }

		/// <summary>
		/// Gets or sets the DocCD.
		/// </summary>
		public bool? DocCD { get; set; }

		/// <summary>
		/// Gets or sets the OSCD.
		/// </summary>
		public bool? OSCD { get; set; }

		/// <summary>
		/// Gets or sets the DIBHWReq.
		/// </summary>
		public string DibhwReq { get; set; }

		/// <summary>
		/// Gets or sets the DistributionChange.
		/// </summary>
		public string DistributionChange { get; set; }

		/// <summary>
		/// Gets or sets the Created.
		/// </summary>
		public DateTime Created { get; set; }

		/// <summary>
		/// Gets or sets the PreinstallBrand.
		/// </summary>
		public string PreinstallBrand { get; set; }

		/// <summary>
		/// Gets or sets the PreloadBrand.
		/// </summary>
		public string PreloadBrand { get; set; }

		/// <summary>
		/// Gets or sets the Accessoryold.
		/// </summary>
		public bool? AccessoryOld { get; set; }

		/// <summary>
		/// Gets or sets the Commodityold.
		/// </summary>
		public bool? CommodityOld { get; set; }

		/// <summary>
		/// Gets or sets the SyncDistribution.
		/// </summary>
		public bool? SyncDistribution { get; set; }

		/// <summary>
		/// Gets or sets the SyncNotes.
		/// </summary>
		public bool? SyncNotes { get; set; }

		/// <summary>
		/// Gets or sets the SyncImages.
		/// </summary>
		public bool? SyncImages { get; set; }

		/// <summary>
		/// Gets or sets the SyncComments.
		/// </summary>
		public string SyncComments { get; set; }

		/// <summary>
		/// Gets or sets the DeveloperTestNotes.
		/// </summary>
		public string DeveloperTestNotes { get; set; }

		/// <summary>
		/// Gets or sets the ServiceBase.
		/// </summary>
		public string ServiceBase { get; set; }

		/// <summary>
		/// Gets or sets the ServiceSpin.
		/// </summary>
		public string ServiceSpin { get; set; }

		/// <summary>
		/// Gets or sets the ServiceSubassembly.
		/// </summary>
		public string ServiceSubassembly { get; set; }

		/// <summary>
		/// Gets or sets the AutoSelect4NewVersions.
		/// </summary>
		public byte? AutoSelect4NewVersions { get; set; }

		/// <summary>
		/// Gets or sets the MinImageRecovery.
		/// </summary>
		public bool? MinImageRecovery { get; set; }

		/// <summary>
		/// Gets or sets the RestoreImages.
		/// </summary>
		public string RestoreImages { get; set; }

		/// <summary>
		/// Gets or sets the Patch.
		/// </summary>
		public byte? Patch { get; set; }

		/// <summary>
		/// Gets or sets the DeleteMe.
		/// </summary>
		public bool? DeleteMe { get; set; }

		/// <summary>
		/// Gets or sets the ImagesFusion.
		/// </summary>
		public string ImagesFusion { get; set; }

		/// <summary>
		/// Gets or sets the ImageSummaryFusion.
		/// </summary>
		public string ImageSummaryFusion { get; set; }

		/// <summary>
		/// Gets or sets the RestoreImagesFusion.
		/// </summary>
		public string RestoreImagesFusion { get; set; }

		/// <summary>
		/// Gets or sets the CreatedBy.
		/// </summary>
		public string CreatedBy { get; set; }

		/// <summary>
		/// Gets or sets the Updated.
		/// </summary>
		public DateTime Updated { get; set; }

		/// <summary>
		/// Gets or sets the UpdatedBy.
		/// </summary>
		public string UpdatedBy { get; set; }

		/// <summary>
		/// Gets or sets the Deleted.
		/// </summary>
		public DateTime? Deleted { get; set; }

		/// <summary>
		/// Gets or sets the DeletedBy.
		/// </summary>
		public string DeletedBy { get; set; }

		/// <summary>
		/// Gets or sets the RCDOnly.
		/// </summary>
		public bool RCDOnly { get; set; }


        /// <summary>
		/// Gets or sets the ReleaseID.
		/// </summary>
		public int? ReleaseId { get; set; }


        /// <summary>
        /// Gets or sets the ProductVersionReleaseModel.
        /// </summary>
        public ProductVersionReleaseModel ProductVersionReleaseModel { get; set; }

        /// <summary>
        /// Gets or sets the bridge count.
        /// </summary>
        /// <value>
        /// The bridge count.
        /// </value>
        public int BridgeCount { get; set; }

        /// <summary>
        /// Gets or sets the bridged i ds.
        /// </summary>
        /// <value>
        /// The bridged i ds.
        /// </value>
        public string BridgedIds { get; set; }

        /// <summary>
        /// Gets or sets the bridged.
        /// </summary>
        /// <value>
        /// The bridged.
        /// </value>
        public bool? Bridged { get; set; }

        /// <summary>
        /// Gets or sets the product delete root release.
        /// </summary>
        /// <value>
        /// The product delete root release.
        /// </value>
        public ProductDelRootReleaseModel ProductDelRootRelease { get; set; }


        /// <summary>
        /// Gets or sets the deliverable root.
        /// </summary>
        /// <value>
        /// The deliverable root.
        /// </value>
        public DeliverableRootModel DeliverableRoot { get; set; }

        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        public int UserId { get; set; }

        /// <summary>
        /// Gets or sets the name of the user.
        /// </summary>
        /// <value>
        /// The name of the user.
        /// </value>
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets the type identifier.
        /// </summary>
        /// <value>
        /// The type identifier.
        /// </value>
        public int TypeId { get; set; }

        /// <summary>
        /// Gets or sets the product deliverable.
        /// </summary>
        /// <value>
        /// The product deliverable.
        /// </value>
        public ProductDeliverableModel ProductDeliverable { get; set; }

        /// <summary>
        /// Gets or sets the service spare category deliverable category.
        /// </summary>
        /// <value>
        /// The service spare category deliverable category.
        /// </value>
        public ServiceSpareCategoryDeliverableCategoryModel ServiceSpareCategoryDeliverableCategory { get; set; }

        /// <summary>
        /// Gets or sets the service spare category.
        /// </summary>
        /// <value>
        /// The service spare category.
        /// </value>
        public ServiceSpareCategoryModel ServiceSpareCategory { get; set; }

        /// <summary>
        /// Gets or sets the deliverable category.
        /// </summary>
        /// <value>
        /// The deliverable category.
        /// </value>
        public DeliverableCategoryModel DeliverableCategory { get; set; }

        /// <summary>
        /// Gets or sets the service spare kit.
        /// </summary>
        /// <value>
        /// The service spare kit.
        /// </value>
        public ServiceSpareKitModel ServiceSpareKit { get; set; }

        /// <summary>
        /// Gets or sets the service spare kit status.
        /// </summary>
        /// <value>
        /// The service spare kit status.
        /// </value>
        public ServiceSpareKitStatusModel ServiceSpareKitStatus { get; set; }

        /// <summary>
        /// Gets or sets the service spare kit service family.
        /// </summary>
        /// <value>
        /// The service spare kit service family.
        /// </value>
        public ServiceSpareKitServiceFamilyModel ServiceSpareKitServiceFamily { get; set; }

        /// <summary>
        /// Gets or sets the total no of rows.
        /// </summary>
        /// <value>
        /// The total no of rows.
        /// </value>
        public int TotalNoOfRows { get; set; }

        /// <summary>
        /// Gets or sets the OptScope.
        /// </summary>
        /// <value>
        /// The Opt Scope.
        /// </value>
        public int OptScope { get; set; }
    }
}




namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ProductBrandModel</para>
    /// </summary>
    public class ProductBrandModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the ProductVersionID.
		/// </summary>
		public int ProductVersionId { get; set; }

		/// <summary>
		/// Gets or sets the BrandID.
		/// </summary>
		public int BrandId { get; set; }

		/// <summary>
		/// Gets or sets the SeriesSummary.
		/// </summary>
		public string SeriesSummary { get; set; }

		/// <summary>
		/// Gets or sets the KMAT.
		/// </summary>
		public string Kmat { get; set; }

		/// <summary>
		/// Gets or sets the EZCKMAT.
		/// </summary>
		public string EzcKmat { get; set; }

		/// <summary>
		/// Gets or sets the ProjectCd.
		/// </summary>
		public string ProjectCd { get; set; }

		/// <summary>
		/// Gets or sets the PlantCd.
		/// </summary>
		public string PlantCd { get; set; }

		/// <summary>
		/// Gets or sets the SalesOrg.
		/// </summary>
		public string SalesOrg { get; set; }

		/// <summary>
		/// Gets or sets the LastPublishDt.
		/// </summary>
		public DateTime? LastPublishDt { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdDate.
		/// </summary>
		public DateTime? LastUpdDate { get; set; }

		/// <summary>
		/// Gets or sets the LastUpdUser.
		/// </summary>
		public string LastUpdUser { get; set; }

		/// <summary>
		/// Gets or sets the ConfigCd.
		/// </summary>
		public string ConfigCd { get; set; }

		/// <summary>
		/// Gets or sets the ShowOnPm.
		/// </summary>
		public bool ShowOnPm { get; set; }

		/// <summary>
		/// Gets or sets the ShowPhWebActionItems.
		/// </summary>
		public bool? ShowPhWebActionItems { get; set; }

		/// <summary>
		/// Gets or sets the AVSeriesName.
		/// </summary>
		public string AVSeriesName { get; set; }

		/// <summary>
		/// Gets or sets the DeletemeIRSPlatformAliasID.
		/// </summary>
		public int? DeleteMeIrsPlatformAliasId { get; set; }

		/// <summary>
		/// Gets or sets the IrsAvListId.
		/// </summary>
		public int? IrsAvListId { get; set; }

		/// <summary>
		/// Gets or sets the ServiceTag.
		/// </summary>
		public string ServiceTag { get; set; }

		/// <summary>
		/// Gets or sets the BIOSBranding.
		/// </summary>
		public string BiosBranding { get; set; }

		/// <summary>
		/// Gets or sets the LogoBadge.
		/// </summary>
		public string LogoBadge { get; set; }

		/// <summary>
		/// Gets or sets the LongName.
		/// </summary>
		public string LongName { get; set; }

		/// <summary>
		/// Gets or sets the ShortName.
		/// </summary>
		public string ShortName { get; set; }

		/// <summary>
		/// Gets or sets the FamilyName.
		/// </summary>
		public string FamilyName { get; set; }

		/// <summary>
		/// Gets or sets the BrandName.
		/// </summary>
		public string BrandName { get; set; }

		/// <summary>
		/// Gets or sets the Generation.
		/// </summary>
		public string Generation { get; set; }

		/// <summary>
		/// Gets or sets the FormFactor.
		/// </summary>
		public string FormFactor { get; set; }

		/// <summary>
		/// Gets or sets the SCMNumber.
		/// </summary>
		public int? ScmNumber { get; set; }

		/// <summary>
		/// Gets or sets the CombinedName.
		/// </summary>
		public string CombinedName { get; set; }

		/// <summary>
		/// Gets or sets the CombinedProductBrandId.
		/// </summary>
		public int? CombinedProductBrandId { get; set; }

		/// <summary>
		/// Gets or sets the ABTBusinessSegmentId.
		/// </summary>
		public int? AbtBusinessSegmentId { get; set; }

		/// <summary>
		/// Gets or sets the IRSProductId.
		/// </summary>
		public int? IrsProductId { get; set; }

		/// <summary>
		/// Gets or sets the KETeamNotification.
		/// </summary>
		public bool? KETeamNotification { get; set; }

		/// <summary>
		/// Gets or sets the MasterLabel.
		/// </summary>
		public string MasterLabel { get; set; }

		/// <summary>
		/// Gets or sets the BTOServiceTagName.
		/// </summary>
		public string BtoServiceTagName { get; set; }

		/// <summary>
		/// Gets or sets the CTOModelNumber.
		/// </summary>
		public string CtoModelNumber { get; set; }

		/// <summary>
		/// Gets or sets the ProductModelNumber.
		/// </summary>
		public string ProductModelNumber { get; set; }

		/// <summary>
		/// Gets or sets the ProductVersionReleaseId.
		/// </summary>
		public int? ProductVersionReleaseId { get; set; }

        /// <summary>
        /// Gets or sets the Brand.
        /// </summary>
        public BrandModel Brand { get; set; }


        /// <summary>
        /// Gets or sets the Series.
        /// </summary>
        public SeriesModel Series { get; set; }

        /// <summary>
        /// Gets or sets the NameType.
        /// </summary>
        public int NameType { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ProductBrandModel"/> is selected.
        /// </summary>
        /// <value>
        ///   <c>true</c> if selected; otherwise, <c>false</c>.
        /// </value>
        public int Selected { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersion.
        /// </summary>
        public ProductVersionModel ProductVersion { get; set; }

        /// <summary>
        /// Gets or sets the AVDetail.
        /// </summary>
        public AVDetailModel AVDetail { get; set; }
    }
}
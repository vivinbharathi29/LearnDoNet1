

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>ReportProfilesModel</para>
    /// </summary>
    public class ReportProfileModel
    {
		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int Id { get; set; }

		/// <summary>
		/// Gets or sets the EmployeeID.
		/// </summary>
		public int? EmployeeId { get; set; }

		/// <summary>
		/// Gets or sets the ProfileType.
		/// </summary>
		public int? ProfileType { get; set; }

		/// <summary>
		/// Gets or sets the Value1.
		/// </summary>
		public string Value1 { get; set; }

		/// <summary>
		/// Gets or sets the Value2.
		/// </summary>
		public string Value2 { get; set; }

		/// <summary>
		/// Gets or sets the Value3.
		/// </summary>
		public string Value3 { get; set; }

		/// <summary>
		/// Gets or sets the Value4.
		/// </summary>
		public string Value4 { get; set; }

		/// <summary>
		/// Gets or sets the Value5.
		/// </summary>
		public int? Value5 { get; set; }

		/// <summary>
		/// Gets or sets the Value6.
		/// </summary>
		public string Value6 { get; set; }

		/// <summary>
		/// Gets or sets the Value7.
		/// </summary>
		public int? Value7 { get; set; }

		/// <summary>
		/// Gets or sets the Value8.
		/// </summary>
		public int? Value8 { get; set; }

		/// <summary>
		/// Gets or sets the Value9.
		/// </summary>
		public string Value9 { get; set; }

		/// <summary>
		/// Gets or sets the Value10.
		/// </summary>
		public string Value10 { get; set; }

		/// <summary>
		/// Gets or sets the ProfileName.
		/// </summary>
		public string ProfileName { get; set; }

		/// <summary>
		/// Gets or sets the Value11.
		/// </summary>
		public string Value11 { get; set; }

		/// <summary>
		/// Gets or sets the Value12.
		/// </summary>
		public string Value12 { get; set; }

		/// <summary>
		/// Gets or sets the Value13.
		/// </summary>
		public string Value13 { get; set; }

		/// <summary>
		/// Gets or sets the Value14.
		/// </summary>
		public string Value14 { get; set; }

		/// <summary>
		/// Gets or sets the Value15.
		/// </summary>
		public string Value15 { get; set; }

		/// <summary>
		/// Gets or sets the Value16.
		/// </summary>
		public int? Value16 { get; set; }

		/// <summary>
		/// Gets or sets the Value17.
		/// </summary>
		public bool? Value17 { get; set; }

		/// <summary>
		/// Gets or sets the Value18.
		/// </summary>
		public bool? Value18 { get; set; }

		/// <summary>
		/// Gets or sets the Value19.
		/// </summary>
		public bool? Value19 { get; set; }

		/// <summary>
		/// Gets or sets the Value20.
		/// </summary>
		public bool? Value20 { get; set; }

		/// <summary>
		/// Gets or sets the Value21.
		/// </summary>
		public bool? Value21 { get; set; }

		/// <summary>
		/// Gets or sets the Value22.
		/// </summary>
		public int? Value22 { get; set; }

		/// <summary>
		/// Gets or sets the Value23.
		/// </summary>
		public string Value23 { get; set; }

		/// <summary>
		/// Gets or sets the Value24.
		/// </summary>
		public int? Value24 { get; set; }

		/// <summary>
		/// Gets or sets the Value25.
		/// </summary>
		public string Value25 { get; set; }

		/// <summary>
		/// Gets or sets the Value26.
		/// </summary>
		public string Value26 { get; set; }

		/// <summary>
		/// Gets or sets the Value27.
		/// </summary>
		public string Value27 { get; set; }

		/// <summary>
		/// Gets or sets the Value28.
		/// </summary>
		public string Value28 { get; set; }

		/// <summary>
		/// Gets or sets the Value29.
		/// </summary>
		public string Value29 { get; set; }

		/// <summary>
		/// Gets or sets the Value30.
		/// </summary>
		public string Value30 { get; set; }

		/// <summary>
		/// Gets or sets the Value31.
		/// </summary>
		public string Value31 { get; set; }

		/// <summary>
		/// Gets or sets the Value32.
		/// </summary>
		public string Value32 { get; set; }

		/// <summary>
		/// Gets or sets the Value33.
		/// </summary>
		public bool? Value33 { get; set; }

		/// <summary>
		/// Gets or sets the Value34.
		/// </summary>
		public bool? Value34 { get; set; }

		/// <summary>
		/// Gets or sets the Value35.
		/// </summary>
		public bool? Value35 { get; set; }

		/// <summary>
		/// Gets or sets the Value36.
		/// </summary>
		public bool? Value36 { get; set; }

		/// <summary>
		/// Gets or sets the Value37.
		/// </summary>
		public bool? Value37 { get; set; }

		/// <summary>
		/// Gets or sets the Value38.
		/// </summary>
		public bool? Value38 { get; set; }

		/// <summary>
		/// Gets or sets the Value39.
		/// </summary>
		public string Value39 { get; set; }

		/// <summary>
		/// Gets or sets the Value40.
		/// </summary>
		public string Value40 { get; set; }

		/// <summary>
		/// Gets or sets the Value41.
		/// </summary>
		public string Value41 { get; set; }

		/// <summary>
		/// Gets or sets the Value42.
		/// </summary>
		public string Value42 { get; set; }

		/// <summary>
		/// Gets or sets the Value43.
		/// </summary>
		public string Value43 { get; set; }

		/// <summary>
		/// Gets or sets the Value44.
		/// </summary>
		public bool? Value44 { get; set; }

		/// <summary>
		/// Gets or sets the DefaultSQL.
		/// </summary>
		public string DefaultSQL { get; set; }

		/// <summary>
		/// Gets or sets the CommodityMatrix.
		/// </summary>
		public bool? CommodityMatrix { get; set; }

		/// <summary>
		/// Gets or sets the ReportFilters.
		/// </summary>
		public string ReportFilters { get; set; }

		/// <summary>
		/// Gets or sets the Value45.
		/// </summary>
		public string Value45 { get; set; }

		/// <summary>
		/// Gets or sets the DisplayOrder.
		/// </summary>
		public int? DisplayOrder { get; set; }

		/// <summary>
		/// Gets or sets the Value46.
		/// </summary>
		public string Value46 { get; set; }

		/// <summary>
		/// Gets or sets the Value47.
		/// </summary>
		public string Value47 { get; set; }

		/// <summary>
		/// Gets or sets the Value48.
		/// </summary>
		public bool? Value48 { get; set; }

		/// <summary>
		/// Gets or sets the Value49.
		/// </summary>
		public bool? Value49 { get; set; }

		/// <summary>
		/// Gets or sets the Value50.
		/// </summary>
		public bool? Value50 { get; set; }

		/// <summary>
		/// Gets or sets the Value51.
		/// </summary>
		public bool? Value51 { get; set; }

		/// <summary>
		/// Gets or sets the Value52.
		/// </summary>
		public string Value52 { get; set; }

		/// <summary>
		/// Gets or sets the Value53.
		/// </summary>
		public string Value53 { get; set; }

		/// <summary>
		/// Gets or sets the Value54.
		/// </summary>
		public string Value54 { get; set; }

		/// <summary>
		/// Gets or sets the PageLayout.
		/// </summary>
		public string PageLayout { get; set; }

		/// <summary>
		/// Gets or sets the SelectedFilters.
		/// </summary>
		public string SelectedFilters { get; set; }

		/// <summary>
		/// Gets or sets the Value55.
		/// </summary>
		public string Value55 { get; set; }

        /// <summary>
		/// Gets or sets the Value56.
		/// </summary>
		public string Value56 { get; set; }

        /// <summary>
		/// Gets or sets the Value57.
		/// </summary>
		public string Value57 { get; set; }

        /// <summary>
        /// Gets or sets the DefaultReport.
        /// </summary>
        public int? DefaultReport { get; set; }

		/// <summary>
		/// Gets or sets the TodayPageLink.
		/// </summary>
		public int? TodayPageLink { get; set; }

		/// <summary>
		/// Gets or sets the TodayPageDisplayOrder.
		/// </summary>
		public int? TodayPageDisplayOrder { get; set; }

        /// <summary>
		/// Gets or sets the ReportProfilesSharedModel.
		/// </summary>
        public ReportProfileSharedModel ReportProfilesShared { get; set; }

        /// <summary>
		/// Gets or sets the Employee.
		/// </summary>
        public EmployeeModel Employee { get; set; }

        /// <summary>
		/// Gets or sets the EmployeeUserSettings.
		/// </summary>
        public EmployeeUserSettingModel EmployeeUserSettings { get; set; }
    }
}
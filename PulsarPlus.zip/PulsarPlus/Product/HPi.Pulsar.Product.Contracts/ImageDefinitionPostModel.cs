using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class ImageDefinitionPostModel
    {
        public int Id { get; set; }

        public string SkuNumber { get; set; }

        public string OS { get; set; }

        public string OSTag { get; set; }

        public string Status { get; set; }

        public string StatusTag { get; set; }

        public string ProductDrop { get; set; }

        public string ProductDropTag { get; set; }

        public string Brand { get; set; }

        public string BrandTag { get; set; }

        public string SWType { get; set; }

        public string ReleaseName { get; set; }

        public string ReleaseNameTag { get; set; }

        public int BrandId { get; set; }

        public int ImageCount { get; set; }

        public int? OSId { get; set; }

        public int SWId { get; set; }

        public string ImageType { get; set; }

        public DateTime? Created { get; set; }

        public int? ProductVersionId { get; set; }

        public DateTime? Modified { get; set; }

        public bool? Active { get; set; }

        public int? OobeId { get; set; }

        public byte? StatusId { get; set; }

        public byte? StatusTagId { get; set; }

        public DateTime? RtmDate { get; set; }

        public DateTime? RtmDateTag { get; set; }

        public int? CopyId { get; set; }

        public string Comments { get; set; }

        public string CommentsTag { get; set; }

        public string ImageRegionIds { get; set; }

        public string ImageChange { get; set; }

        public string RegionChange { get; set; }

        public bool IsRegionChanged { get; set; }

        public bool IsDefinitionChanged { get; set; }

        public int? ImageDriveDefinitionId { get; set; }

        public DateTime? EolDate { get; set; }

        public int? ImageTypeId { get; set; }

        public int? ProductDropId { get; set; }

        public int? FeatureId { get; set; }

        public int? ProductVersionReleaseId { get; set; }

        public int ImageId { get; set; }

        public string ImageIds { get; set; }

        public string OptionConfig { get; set; }

        public string Priority { get; set; }

        public int? ProductId { get; set; }

        public RegionModel[] Region { get; set; }

        public string DriveDefinition { get; set; }

        public string DriveDefinitionTag { get; set; }

        public string BrandIdsRemoved { get; set; }

        public string BrandIdsAdded { get; set; }


        public string FromEmail { get; set; }

        public int RegionId { get; set; }

        public int OSFeatureExists { get; set; }

        public int UserId { get; set; }

        public int? dcrId { get; set; }

        public string ChangeLog { get; set; }

        public string PublishIds { get; set; }

        public string PublishTagIds { get; set; }

        public string RegionIds { get; set; }

        public string RegionTagIds { get; set; }

        public string TierIds { get; set; }

        public string TierTagIds { get; set; }

        public string ChannelPartnerIds { get; set; }

        public string ChannelPartnerTagIds { get; set; }

        public string BrandIds { get; set; }

        public string BrandTagIds { get; set; }

        public string OSReleaseName { get; set; }

        public string OSReleaseNameTag { get; set; }

        public int? OSReleaseId { get; set; }

        public int? OSReleaseTagId { get; set; }

        public string ImageNames { get; set; }

        public bool Published { get; set; }

        public string PublishedIds { get; set; }

        public string PublishedTagIds { get; set; }

        public string ChannelPartners { get; set; }

        public string ChannelPartnersTag { get; set; }

        public string UserName { get; set; }

        public string XmlChangeLog { get; set; }

        public string RegionIdsRemoved { get; set; }

        public string RegionIdsAdded { get; set; }

        public string PublishIdsRemoved { get; set; }

        public string PublishIdsAdded { get; set; }

        public string RegionIdsInfoUpdated { get; set; }

        public string TierIdsInfoUpdated { get; set; }

        public string ChannelPartnerIdsInfoUpdated { get; set; }

        public string PublishIdsAdd { get; set; }

        public string RegionIdsAddToImage { get; set; }

        public string PublishedAddToImage { get; set; }

        public string TierIdsAddToImage { get; set; }

        public string ChannelPartnerIdsAddToImage { get; set; }

        public string RegionIdsRemoveFromImage { get; set; }

        public string TierIdsRemoveFromImage { get; set; }

        public string PriorityRegionIds { get; set; }

        public string RegionChangeLog { get; set; }

        public bool? ProductEmail { get; set; }

        public bool? CopyWithTarget { get; set; }
    }

    public class ImageRegionsPostModel
    {
        public int? Id { get; set; }

        public int ProductId { get; set; }

        public int ImageTypeId { get; set; }

        public string OS { get; set; }

        public string OSTag { get; set; }

        public int? OSId { get; set; }

        public int? OSTagId { get; set; }

        public string Status { get; set; }

        public string StatusTag { get; set; }

        public string ProductDrop { get; set; }

        public string ProductDropTag { get; set; }

        public string BrandNames { get; set; }

        public string BrandNamesTag { get; set; }

        public string ReleaseName { get; set; }

        public string ReleaseNameTag { get; set; }

        public byte? StatusId { get; set; }

        public byte? StatusTagId { get; set; }

        public DateTime? RtmDate { get; set; }

        public DateTime? RtmDateTag { get; set; }

        public int? CopyId { get; set; }

        public string Comments { get; set; }

        public string CommentsTag { get; set; }

        public string ImageRegionIds { get; set; }

        public int? DriveDefinitionId { get; set; }

        public int? DriveDefinitionTagId { get; set; }

        public string DriveDefinition { get; set; }

        public string DriveDefinitionTag { get; set; }

        public string FromEmail { get; set; }

        public int? dcrId { get; set; }

        public string PublishIds { get; set; }

        public string PublishTagIds { get; set; }

        public string ImageRegionAllIds { get; set; }

        public string ImageRegionTagIdsChecked { get; set; }

        public string ImageRegionIdsChecked { get; set; }

        public string TierIds { get; set; }

        public string TierTagIds { get; set; }

        public string ChannelPartnerIds { get; set; }

        public string ChannelPartnerTagIds { get; set; }

        public string ImageNames { get; set; }

        public string BrandIds { get; set; }

        public string BrandTagIds { get; set; }

        public string BrandIdsAdded { get; set; }

        public string BrandIdsRemoved { get; set; }

        public string OSReleaseName { get; set; }

        public string OSReleaseNameTag { get; set; }

        public string PublishedIds { get; set; }

        public string PublishedTagIds { get; set; }

        public string ChannelPartners { get; set; }

        public string ChannelPartnersTag { get; set; }

        public string PriorityRegionIds { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }

        public bool? CopyWithTarget { get; set; }

        public int? ProductVersionReleaseId { get; set; }

        public int? OSReleaseId { get; set; }

        public int? OSReleaseTagId { get; set; }
    }
}
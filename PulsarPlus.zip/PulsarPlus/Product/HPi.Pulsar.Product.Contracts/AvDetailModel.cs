using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AVDetailModel
    {
        public int AVDetailId { get; set; }

        public int UserId { get; set; }

        public string ReleaseIDs { get; set; }

        public int ImageId { get; set; }

        public string AVNo { get; set; }

        public int? FeatureCategoryID { get; set; }

        public string GpgDescription { get; set; }

        public string AVNoGpgDescription { get; set; }

        public string MarketingDescriptionPmg { get; set; }

        public string MarketingDescription { get; set; }

        public DateTime? CPLBlindDt { get; set; }

        public DateTime? GeneralAvailDt { get; set; }

        public DateTime? RasDiscontinueDt { get; set; }

        public string Upc { get; set; }

        public decimal? Weight { get; set; }

        public string ChangeNote { get; set; }

        public bool ShowOnScm { get; set; }

        public DateTime? LastUpdDate { get; set; }

        public string LastUpdUser { get; set; }

        public string ConfigCode { get; set; }

        public int? ParentId { get; set; }

        public int? ExportRpn { get; set; }

        public DateTime? RtpDate { get; set; }

        public DateTime? EMDate { get; set; }

        public bool? RasDiscoSysUpdate { get; set; }

        public bool? MktDescSysUpdate { get; set; }

        public bool? CplBlindSysUpdate { get; set; }

        public bool? GeneralAvailSysUpdate { get; set; }

        public int? IrsModuleId { get; set; }

        public string NameElements { get; set; }

        public DateTime Created { get; set; }

        public bool? UploadedToPmg { get; set; }

        public int DeliverableRootId { get; set; }

        public bool? GpgDescSysUpdate { get; set; }

        public bool? MktDescPmguSysUpdate { get; set; }

        public string ConflictingGpgDesc { get; set; }

        public string ConflictingMarketingDesc { get; set; }

        public string ConflictingMarketingDescPmg { get; set; }

        public int? FeatureId { get; set; }

        public int? ScmCategoryId { get; set; }

        public int? ProductLineId { get; set; }

        public DateTime? PhWebDate { get; set; }

        public bool SharedAV { get; set; }

        public string DefaultConfigRules { get; set; }

        public string Comments { get; set; }

        public string CreatedBy { get; set; }

        public int? IrsProductId { get; set; }

        public bool? RequireNotification { get; set; }

        public bool DefaultDatesUsed { get; set; }

        public string Name { get; set; }

        public string ProductLine { get; set; }

        public int? BId { get; set; }

        public int? ProductVersionId { get; set; }

        public string Releases { get; set; }

        public string BUAvailList { get; set; }

        public ScmAVDetailProductBrandModel ScmAVDetailProductBrand { get; set; }

        public ScmAVMRDatesModel ScmAVMRDates { get; set; }

        public AVWorkspaceModel AVWorkspace { get; set; }

        public PublishedScmxDataModel PublishedScmxData { get; set; }

        public AVDetailProductBrandModel AVDetailProductBrand { get; set; }

        public ScmCategoryModel ScmCategory { get; set; }

        public PlatformModel Platform { get; set; }

        public int ImageDefinitionId { get; set; }

        public FeatureModel Feature { get; set; }

        public AVFeatureCategoryModel AvFeatureCategory { get; set; }

        public string PRLOfferingConstraints { get; set; }

        public int ViaAvCreate { get; set; }

        public int BaseParent { get; set; }

        public int? BUFeatureId { get; set; }

        public string SortAvNo { get; set; }

        public string VerList { get; set; }

        public string Version { get; set; }

        public string aVersion { get; set; }

        public string aAvNo { get; set; }

        public string CountryCode { get; set; }

        public int GeoId { get; set; }

        public int OSId { get; set; }

        public string SeriesNo { get; set; }

        public int RecordCount { get; set; }

        public string ReleaseIds { get; set; }

        public AvFeatureProductBrandModel AvFeatureProductBrand { get; set; }

        public AvCreateModel AvCreate { get; set; }

        public string GpgDescriptionCpu { get; set; }

        public AvPhWebActionTypeModel AvPhWebActionType { get; set; }

        public AvActionItemModel AvActionItem { get; set; }

        public AvHistoryModel AvHistoryModel { get; set; }

        public AvChangeTypeModel AvChangeTypeModel { get; set; }
    }
}
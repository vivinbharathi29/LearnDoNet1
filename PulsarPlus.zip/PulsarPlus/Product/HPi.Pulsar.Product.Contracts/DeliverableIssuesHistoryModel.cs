﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class DeliverableIssuesHistoryModel
    {
        /// <summary>
        /// Gets and sets the ChangeDt
        /// </summary>
        public DateTime ChangeDt { get; set; }

        /// <summary>
        /// Gets and sets the DCRId
        /// </summary>
        public int DCRId { get; set; }

        /// <summary>
        /// Gets and sets the DeliverableRootId
        /// </summary>
        public int DeliverableRootId { get; set; }

        /// <summary>
        /// Gets and sets the ProductVersionId
        /// </summary>
        public int ProductVersionId { get; set; }

        /// <summary>
        /// Gets and sets the Type
        /// </summary>
        public int? Type { get; set; }

        /// <summary>
        /// Gets and sets the Status
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// Gets and sets the OwnerId
        /// </summary>
        public int? OwnerId { get; set; }

        /// <summary>
        /// Gets and sets the ActualDate
        /// </summary>
        public DateTime? ActualDate { get; set; }

        /// <summary>
        /// Gets and sets the LastUpdUser
        /// </summary>
        public string LastUpdUser { get; set; }

        /// <summary>
        /// Gets and sets the UserInfo
        /// </summary>
        public UserInfoModel UserInfo { get; set; }

        /// <summary>
        /// Gets and sets the ActionStatus
        /// </summary>
        public ActionStatusModel ActionStatus { get; set; }
    }
}

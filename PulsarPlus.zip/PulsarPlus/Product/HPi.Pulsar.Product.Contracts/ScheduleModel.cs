

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class ScheduleModel.
    /// </summary>
    public class ScheduleModel
    {
        /// <summary>
        /// Gets or sets the Scheduleid.
        /// </summary>
        /// <value>
        /// The schedule identifier.
        /// </value>
        public int ScheduleId { get; set; }

        /// <summary>
        /// Gets or sets the Productreleaseid.
        /// </summary>
        /// <value>
        /// The productrelease identifier.
        /// </value>
        public int? ProductReleaseId { get; set; }

        /// <summary>
        /// Gets or sets the Schedulename.
        /// </summary>
        /// <value>
        /// The schedulename.
        /// </value>
        public string ScheduleName { get; set; }

        /// <summary>
        /// Gets or sets the Description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the Porlockedyn.
        /// </summary>
        /// <value>
        /// The porlockedyn.
        /// </value>
        public string PorLockedYN { get; set; }

        /// <summary>
        /// Gets or sets the Activeyn.
        /// </summary>
        /// <value>
        /// The activeyn.
        /// </value>
        public string ActiveYN { get; set; }

        /// <summary>
        /// Gets or sets the Lastupduser.
        /// </summary>
        /// <value>
        /// The lastupduser.
        /// </value>
        public string LastUpdUser { get; set; }

        /// <summary>
        /// Gets or sets the Lastupddate.
        /// </summary>
        /// <value>
        /// The lastupddate.
        /// </value>
        public DateTime LastUpdDate { get; set; }

        /// <summary>
        /// Gets or sets the Showoncharts.
        /// </summary>
        /// <value>
        ///   <c>true</c> if showoncharts; otherwise, <c>false</c>.
        /// </value>
        public bool ShowOnCharts { get; set; }

        /// <summary>
        /// Gets or sets the ScheduleData.
        /// </summary>
        /// <value>
        /// The schedule data.
        /// </value>
        public ScheduleDataModel ScheduleData { get; set; }

        /// <summary>
        /// Gets or sets the PDDLocked.
        /// </summary>
        /// <value>
        /// The PDDLocked.
        /// </value>
        public bool PDDLocked { get; set; }

        /// <summary>
        /// Gets or sets the ProductRelease.
        /// </summary>
        /// <value>
        /// The ProductRelease.
        /// </value>
        public ProductReleaseModel ProductRelease { get; set; }
    }
}
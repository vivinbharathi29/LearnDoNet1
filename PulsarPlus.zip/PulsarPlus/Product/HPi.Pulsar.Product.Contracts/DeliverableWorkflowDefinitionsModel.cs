using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class DeliverableWorkflowDefinitionModel
    {
        public int Id { get; set; }

        public string Milestone { get; set; }

        public short? MilestoneOrder { get; set; }

        public int? WorkflowId { get; set; }

        public byte? ReportMilestone { get; set; }

        public string Notify { get; set; }

        public string NotifyConsumerSpecific { get; set; }

        public string NotifyCommercialSpecific { get; set; }

        public DateTime? Created { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? Updated { get; set; }

        public string UpdatedBy { get; set; }

        public DateTime? Deleted { get; set; }

        public string DeletedBy { get; set; }

        public DateTime? Deactivated { get; set; }

        public string DeactivatedBy { get; set; }
    }
}
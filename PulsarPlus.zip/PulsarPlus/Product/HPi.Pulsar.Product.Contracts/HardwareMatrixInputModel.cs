﻿namespace HPi.Pulsar.Product.Contracts
{
    using Infrastructure.Contracts.Pagination;
    public class HardwareMatrixInputModel
    {
        public string FileType { get; set; }

        public int Type { get; set; }

        public int PartnerId { get; set; }

        public string chkTest { get; set; }

        public string chkRelease { get; set; }

        public string chkComplete { get; set; }

        public int IsShowTestStep { get; set; }

        public int IsShowReleaseStep { get; set; }

        public int IsShowCompleteStep { get; set; }

        public int IsShowDevelopmentStep { get; set; }

        public int IsFilterSelected { get; set; }

        public int IsAllowQuickFilters { get; set; }

        public string lstVendor { get; set; }

        public int cboRohs { get; set; }

        public int cboEOL { get; set; }

        public string lstPartner { get; set; }

        public string lstQualStatus { get; set; }

        public string lstDevInput { get; set; }

        public string chkSCRestricted { get; set; }

        public string lstDevManager { get; set; }

        public string lstCommodityPM { get; set; }

        public string lstPhase { get; set; }

        public string lstCategory { get; set; }

        public string lstRoot { get; set; }

        public string lstSubassembly { get; set; }

        public int ReportFormat { get; set; }

        public int txtFunction { get; set; }

        public string lstFamily { get; set; }

        public string lstProductGroups { get; set; }

        public string lstTeamID { get; set; }

        public string txtAdvanced { get; set; }

        public int ReportSplit { get; set; }

        public string chkChangeType { get; set; }

        public string SelectedTypes { get; set; }

        public string HighlightRow { get; set; }

        public string lstProductsPulsar { get; set; }

        public int FullReport { get; set; }

        public string QueryString { get; set; }

        public string txtCompleteDateStart { get; set; }

        public string txtCompleteDateEnd { get; set; }

        public string SpecificPilotStatus { get; set; }

        public string SpecificQualStatus { get; set; }

        public string HistoryRange { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }

        public int NoOfHistoryDays { get; set; }

        public string txtTitle { get; set; }

        public string lstProducts { get; set; }

        public string RequestParameter { get; set; }

        public string RequestValue { get; set; }

        public string VendorIds { get; set; }

        public string fileType { get; set; }

        public PaginationModel Pagination { get; set; }

        public int UserId { get; set; }

        public int GridColumnLimit { get; set; }

        public int ExcelColumnLimit { get; set; }

        public int IsExcel { get; set; }

        public string Columns { get; set; }

        public string OsIds { get; set; }

        public string Languages { get; set; }

        public string SearchInfo { get; set; }

        public string Numbers { get; set; }

        public bool IsTarget { get; set; }

        public bool IsInImage { get; set; }

        public bool IsSearchByChanges { get; set; }

        public bool IsSearchByDesc { get; set; }

        public bool IsSearchByComments { get; set; }

        public bool IsFailed { get; set; }

        public bool IsSearchByName { get; set; }

        public string DownloadToken { get; set; }
    }
}
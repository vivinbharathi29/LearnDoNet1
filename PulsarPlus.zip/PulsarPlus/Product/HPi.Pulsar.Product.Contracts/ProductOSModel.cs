

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// Class ProductOSModel.
    /// </summary>
    public class ProductOSModel
    {
        /// <summary>
        /// Gets or sets the ID.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the ProductVersionID.
        /// </summary>
        /// <value>
        /// The product version identifier.
        /// </value>
        public int ProductVersionId { get; set; }

        /// <summary>
        /// Gets or sets the OSID.
        /// </summary>
        /// <value>
        /// The os identifier.
        /// </value>
        public int OSId { get; set; }

		/// <summary>
		/// Gets or sets the Preinstall.
		/// </summary>
		public bool Preinstall { get; set; }

		/// <summary>
		/// Gets or sets the Web.
		/// </summary>
		public bool Web { get; set; }
    }
}
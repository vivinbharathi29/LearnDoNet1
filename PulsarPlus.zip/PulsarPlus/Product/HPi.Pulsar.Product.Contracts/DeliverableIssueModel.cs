using System;

namespace HPi.Pulsar.Product.Contracts
{

    public class DeliverableIssueModel
    {
        public int Id { get; set; }

        public int? DeliverableRootId { get; set; }

        public int? ProductVersionId { get; set; }

        public string ProductName { get; set; }

        public byte? Type { get; set; }

        public byte? ProductType { get; set; }

        public byte? Status { get; set; }

        public string StatusName { get; set; }

        public string DeliverableStatus { get; set; }

        public int? OwnerId { get; set; }

        public string OwnerName { get; set; }

        public DateTime? TargetDate { get; set; }

        public DateTime? ActualDate { get; set; }

        public string Description { get; set; }

        public string Impact { get; set; }

        public string Actions { get; set; }

        public string Resolution { get; set; }

        public DateTime? Created { get; set; }

        public string Observations { get; set; }

        public string Notify { get; set; }

        public string BtoOld { get; set; }

        public string CtoOld { get; set; }

        public string NAOld { get; set; }

        public string LAOld { get; set; }

        public string ApdOld { get; set; }

        public string CkkOld { get; set; }

        public string EmeaOld { get; set; }

        public string Submitter { get; set; }

        public string GcdOld { get; set; }

        public byte? OnStatusReport { get; set; }

        public int? CategoryId { get; set; }

        public int? CoreTeamRep { get; set; }
        
        public string Summary { get; set; }

        public DateTime? LastModified { get; set; }

        public string Justification { get; set; }

        public string Distribution { get; set; }

        public DateTime? BtoDate { get; set; }

        public DateTime? CtoDate { get; set; }

        public string AddChangeOld { get; set; }

        public string RemoveChangeOld { get; set; }

        public string ModifyChangeOld { get; set; }

        public string Approvals { get; set; }

        public byte? Priority { get; set; }

        public byte? AffectsCustomers { get; set; }

        public byte? ReleaseNotification { get; set; }

        public int? PreinstallOwnerId { get; set; }

        public DateTime? AvailableForTest { get; set; }

        public string AvailableNotes { get; set; }

        public bool? ImageChange { get; set; }

        public bool? SkuChange { get; set; }

        public bool? CategoryBiosChange { get; set; }

        public bool? ReqChange { get; set; }

        public bool? DocChange { get; set; }

        public bool? CommodityChange { get; set; }

        public bool? PendingImplementation { get; set; }

        public bool? OtherChange { get; set; }

        public DateTime? EcnDate { get; set; }

        public bool? Consumer { get; set; }

        public bool? Commercial { get; set; }

        public bool? Smb { get; set; }

        public int? ActionRoadmapId { get; set; }

        public bool? Americas { get; set; }

        public bool? Apj { get; set; }

        public bool? Emea { get; set; }

        public bool? Bto { get; set; }

        public bool? Cto { get; set; }

        public bool? Rcto { get; set; }

        public bool? AddChange { get; set; }

        public bool? RemoveChange { get; set; }

        public bool? ModifyChange { get; set; }

        public bool? NA { get; set; }

        public bool? LA { get; set; }

        public bool? Apd { get; set; }

        public bool? Ckk { get; set; }

        public bool? Gcd { get; set; }

        public string Details { get; set; }

        public int? DeliverableScheduleId { get; set; }

        public int? DeliverableVersionId { get; set; }

        public int? SponsorId { get; set; }

        public int? Duration { get; set; }

        public int? DisplayOrder { get; set; }

        public bool? BiosChange { get; set; }

        public string LastUpdUser { get; set; }

        public bool? SwChange { get; set; }

        public bool? Reported { get; set; }

        public DateTime? ZsrpReadyTargetDt { get; set; }

        public DateTime? ZsrpReadyActualDt { get; set; }

        public bool ZsrpRequired { get; set; }

        public string SpareKitPn { get; set; }

        public string SubAssemblyPn { get; set; }

        public int? InventoryDisposition { get; set; }

        public int? InitiatedBy { get; set; }

        public DateTime? QSpecSubmittedDt { get; set; }

        public DateTime? CompEcoSubmittedDt { get; set; }

        public string CompEcoNo { get; set; }

        public DateTime? SaEcoSubmittedDt { get; set; }

        public string SaEcoNo { get; set; }

        public DateTime? SpsEcoSubmittedDt { get; set; }

        public string SpsEcoNo { get; set; }
        
        public int? SubmitterId { get; set; }

        public bool? IDChange { get; set; }

        public DateTime? StatusNotesUpdatedDt { get; set; }

        public DateTime? OriginalTargetDt { get; set; }

        public string StatusNotes { get; set; }

        public DateTime? RtpDate { get; set; }

        public DateTime? RasDiscoDate { get; set; }

        public int TotalNoOfRows { get; set; }

        public ProductVersionModel ProductVersion { get; set; }

        public UserInfoModel Owner { get; set; }

        public UserInfoModel UserInfo { get; set; }

        public string CoreTeamRepText { get; set; }

        public int? OnStatus { get; set; }

        public DateTime? TestDate { get; set; }

        public string TestNote { get; set; }

        public DateTime? TargetApprovalDate { get; set; }

        public bool? AVRequired { get; set; }

        public bool? QualificationRequired { get; set; }

        public string Attachment1 { get; set; }

        public string Attachment2 { get; set; }
        public string Attachment3 { get; set; }

        public string Attachment4 { get; set; }

        public string Attachment5 { get; set; }

        public bool? Important { get; set; }

        public string ProductFamily { get; set; }

        public string ProductVersionRelease { get; set; }

        public string Category { get; set; }

        public string CoreTeamRepAction { get; set; }

        public DeliverableRootModel DeliverableRoot { get; set; }

        public int ProductId { get; set; }

        public int NetAffectsCustomers { get; set; }

        public int? ActionPriority { get; set; }

        public int ChangeRequestId { get; set; }

        public string ActionTypeName { get; set; }

        public string Product { get; set; }

        public CoreTeamRepModel CoreTeamReps { get; set; }

        public EmployeeModel Employee { get; set; }

        public string Deliverable { get; set; }

        public int NewDeliverableIssueId { get; set; }
    }
}
﻿using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class AvActionItemModel
    {
        public int PhWebActionTypeId { get; set; }

        public bool AutoInput { get; set; }

        public AVDetailModel AVDetail { get; set; }

        public DateTime PCDate { get; set; }
    }
}

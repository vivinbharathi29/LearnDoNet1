using System;

namespace HPi.Pulsar.Product.Contracts
{
    public class DCRWorkflowStagingModel
    {
        public int ID { get; set; }

        public int DCRID { get; set; }

        public int WorkflowID { get; set; }

        public int UserID { get; set; }

        public int PVID { get; set; }

        public int OpenWorkflowCount { get; set; }

        public int ScheduleDefinitionDataId { get; set; }

        public string ScheduleName { get; set; }

        public DateTime? ProjectedStartDate { get; set; }

        public DateTime? ProjectEndDate { get; set; }
    }
}
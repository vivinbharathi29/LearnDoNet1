

namespace HPi.Pulsar.Product.Contracts
{
    using System;

    /// <summary>
    /// <para>RoleModel</para>
    /// </summary>
    public class RoleModel
    {
		/// <summary>
		/// Gets or sets the RoleId.
		/// </summary>
		public int RoleId { get; set; }

		/// <summary>
		/// Gets or sets the RoleName.
		/// </summary>
		public string RoleName { get; set; }

		/// <summary>
		/// Gets or sets the RoleCd.
		/// </summary>
		public string RoleCd { get; set; }

		/// <summary>
		/// Gets or sets the Description.
		/// </summary>
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets the Active.
		/// </summary>
		public bool Active { get; set; }

		/// <summary>
		/// Gets or sets the CreatedBy.
		/// </summary>
		public string CreatedBy { get; set; }

		/// <summary>
		/// Gets or sets the UpdatedBy.
		/// </summary>
		public string UpdatedBy { get; set; }

		/// <summary>
		/// Gets or sets the Created.
		/// </summary>
		public DateTime Created { get; set; }

		/// <summary>
		/// Gets or sets the Updated.
		/// </summary>
		public DateTime Updated { get; set; }

		/// <summary>
		/// Gets or sets the RoleGuid.
		/// </summary>
		public Guid? RoleGuid { get; set; }

		/// <summary>
		/// Gets or sets the TeamId.
		/// </summary>
		public int? TeamId { get; set; }

		/// <summary>
		/// Gets or sets the Primary.
		/// </summary>
		public bool? Primary { get; set; }

		/// <summary>
		/// Gets or sets the Disabled.
		/// </summary>
		public DateTime? Disabled { get; set; }

		/// <summary>
		/// Gets or sets the DisabledBy.
		/// </summary>
		public string DisabledBy { get; set; }

		/// <summary>
		/// Gets or sets the ID.
		/// </summary>
		public int ID { get; set; }

		/// <summary>
		/// Gets or sets the Permission.
		/// </summary>
		public PermissionModel Permission { get; set; }

        /// <summary>
        /// Gets or sets the RoleMember.
        /// </summary>
        public RoleMemberModel RoleMember { get; set; }
    }
}
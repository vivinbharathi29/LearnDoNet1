namespace HPi.Pulsar.Product.Contracts
{
    public class AccessoryStatusModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string MatrixBGColor { get; set; }

        public string FontColor { get; set; }

        public byte? DateField { get; set; }

        public bool? CommentsRequired { get; set; }
    }
}
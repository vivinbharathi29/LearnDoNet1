using System.Threading.Tasks;
using HPi.Pulsar.Admin.Contracts;
using HPi.Pulsar.Admin.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.Models;
using Microsoft.Extensions.Options;
namespace HPi.Pulsar.Admin.Proxy
{
    public class OSFamilyProxy : BaseProxy, IOSFamilyService
    {
        public OSFamilyProxy(IOptions<ServiceBaseURLCollection> serviceBaseURLCollection) : base(serviceBaseURLCollection)
        {
        }

        public async Task<OSFamilyModel[]> GetOSFamilyDetailsAsync()
        {
            var url = "api/OSFamily/GetOSFamilyDetails/";
            return await this.GetResponse<OSFamilyModel[]>(url).ConfigureAwait(false);
        }
    }
}
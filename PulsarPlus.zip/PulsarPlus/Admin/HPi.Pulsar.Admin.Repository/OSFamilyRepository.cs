using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using HPi.Pulsar.Admin.Contracts;
using HPi.Pulsar.Admin.Contracts.Repositories;
using HPi.Pulsar.Admin.Resources;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using HPi.Pulsar.Infrastructure.Contracts.Extension;
namespace HPi.Pulsar.Admin.Repository
{
    public class OSFamilyRepository : BaseRepository, IOSFamilyRepository
    {
        public OSFamilyRepository(IApplicationProperties applicationProperties) : base(applicationProperties)
        {
        }

        public async Task<OSFamilyModel[]> GetOSFamilyDetailsAsync()
        {
            List<OSFamilyModel> osFamilies = new List<OSFamilyModel>();
            var parameters = new SqlParameter[0];
            OSFamilyModel osFamily = null;

            using (SqlDataReader dataReader = await this.ExecuteReader(StoreProcedure.OSFamilyDetails, parameters))
            {
                while (dataReader.Read())
                {
                    osFamily = new OSFamilyModel();
                    osFamily.Id = dataReader.GetValueOrDefault<int>("ID");
                    osFamily.FamilyName = dataReader.GetValueOrDefault<string>("FamilyName");
                    osFamily.ShortName = dataReader.GetValueOrDefault<string>("ShortName");
                    osFamily.SortOrder = dataReader.GetValueOrDefault<int>("SortOrder");
                    osFamilies.Add(osFamily);
                }

                return osFamilies.ToArray();
            }
        }
    }
}
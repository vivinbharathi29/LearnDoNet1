using System.Threading.Tasks;
using HPi.Pulsar.Admin.Contracts;
using HPi.Pulsar.Admin.Contracts.Repositories;
using HPi.Pulsar.Admin.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
namespace HPi.Pulsar.Admin.BusinessLayer
{
    public class OSFamilyManager : BaseManager<IOSFamilyRepository>, IOSFamilyService
    {
        public OSFamilyManager(IApplicationServices applicationService, IOSFamilyRepository oSFamilyRepository) : base(applicationService, oSFamilyRepository)
        {
        }

        public async Task<OSFamilyModel[]> GetOSFamilyDetailsAsync()
        {
            return await this.Repository.GetOSFamilyDetailsAsync().ConfigureAwait(false);
        }
    }
}
using System.Threading.Tasks;

namespace HPi.Pulsar.Admin.Contracts.Services
{

    public interface IOSFamilyService
    {
        Task<OSFamilyModel[]> GetOSFamilyDetailsAsync();
    }
}
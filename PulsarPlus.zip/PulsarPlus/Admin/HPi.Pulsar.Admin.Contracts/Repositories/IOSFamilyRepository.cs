using System.Threading.Tasks;

namespace HPi.Pulsar.Admin.Contracts.Repositories
{

    public interface IOSFamilyRepository
    {
        Task<OSFamilyModel[]> GetOSFamilyDetailsAsync();
    }
}
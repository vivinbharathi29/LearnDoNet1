using System.Threading.Tasks;
using HPi.Pulsar.Admin.Contracts;
using HPi.Pulsar.Admin.Contracts.Services;
using HPi.Pulsar.Infrastructure.BaseClass;
using HPi.Pulsar.Infrastructure.Contracts.ApplicationServices;
using Microsoft.AspNetCore.Mvc;
namespace HPi.Pulsar.Admin.WebApi.Controllers
{
    public class OSFamilyController : BaseApiController<IOSFamilyService>
    {
        public OSFamilyController(IApplicationServices applicationServices, IOSFamilyService manager) : base(applicationServices, manager)
        {
        }

        [HttpGet]
        [Route("api/OSFamily/GetOSFamilyDetails")]
        [ProducesResponseType(typeof(OSFamilyModel[]), 200)]
        [ProducesResponseType(typeof(OSFamilyModel[]), 404)]
        public async Task<IActionResult> GetOSFamilyDetails()
        {
            OSFamilyModel[] apiResult = await this.Manager.GetOSFamilyDetailsAsync().ConfigureAwait(false);
            if (apiResult != null)
            {
                return this.Ok(apiResult);
            }
            return this.NotFound();
        }
    }
}